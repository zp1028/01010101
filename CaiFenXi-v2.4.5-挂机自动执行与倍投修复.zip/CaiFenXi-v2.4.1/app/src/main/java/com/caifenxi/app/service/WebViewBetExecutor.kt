package com.caifenxi.app.service

import android.os.Handler
import android.os.Looper
import android.webkit.WebSettings
import android.webkit.WebView
import com.caifenxi.app.domain.execution.BetAction
import com.caifenxi.app.domain.execution.BetCommand
import com.caifenxi.app.domain.execution.ExecutionResult
import com.caifenxi.app.domain.execution.GenericSiteAdapter
import com.caifenxi.app.domain.execution.SiteAdapter
import com.caifenxi.app.util.RuntimeLog

/**
 * WebView DOM 执行器：注入通用评分脚本，识别真正的大小单双并点击。
 */
class WebViewBetExecutor {

    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile
    private var webView: WebView? = null

    /** 正在执行的 cmdId，防止同一指令被重复触发（重复点确定/重复下注） */
    @Volatile
    private var runningCmdId: String? = null

    @Volatile
    var siteAdapter: SiteAdapter = GenericSiteAdapter

    val isAvailable: Boolean
        get() = webView != null

    fun attachWebView(webView: WebView) {
        initWebView(webView)
    }

    fun initWebView(webView: WebView) {
        // 始终更新引用，防止 Compose 重组后旧引用失效
        this.webView = webView
        mainHandler.post {
            try {
                val s = webView.settings
                s.javaScriptEnabled = true
                s.domStorageEnabled = true
                s.databaseEnabled = true
                s.useWideViewPort = true
                s.loadWithOverviewMode = true
                s.cacheMode = WebSettings.LOAD_DEFAULT
                s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                s.javaScriptCanOpenWindowsAutomatically = true
                s.mediaPlaybackRequiresUserGesture = false
                val ua = s.userAgentString ?: ""
                if (!ua.contains("Chrome")) {
                    s.userAgentString =
                        "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
                RuntimeLog.info("WebViewBet", "WebView 已挂载并开启 JS (ref更新)")
            } catch (e: Exception) {
                RuntimeLog.warn("WebViewBet", "initWebView: ${e.message}")
            }
        }
    }

    fun clearWebView() {
        webView = null
    }

    fun execute(command: BetCommand, onResult: (ExecutionResult) -> Unit): Boolean {
        val wv = webView
        if (wv == null) {
            onResult(
                ExecutionResult.fail(
                    command.cmdId,
                    ExecutionResult.WEBVIEW_DISCONNECTED,
                    "WebView 未连接，请先打开「内置网页挂机」并加载投注站"
                )
            )
            return false
        }
        if (command.isExpired) {
            onResult(
                ExecutionResult.fail(
                    command.cmdId,
                    ExecutionResult.COMMAND_EXPIRED,
                    "指令已过期"
                )
            )
            return false
        }
        val adapter = siteAdapter
        val dryRun = command.options["dryRun"] == "1" || command.options["dryRun"] == "true"
        val phase1Js = try { adapter.buildInjectScript(command) } catch (e: Exception) {
            onResult(ExecutionResult.fail(command.cmdId, ExecutionResult.ACTION_FAILED, "构建脚本失败: ${e.message}"))
            return false
        }
        val phase2Js = adapter.buildPhase2Script(command)
        val phase2VerifyJs = adapter.buildPhase2VerifyScript(command)
        val phase3Js = adapter.buildPhase3Script(command)
        val balJs = adapter.balanceSnapshotScript
        val start = System.currentTimeMillis()
        RuntimeLog.info("WebViewBet", "执行(分阶段) cmdId=${command.cmdId} issue=${command.issue} bets=${command.bets.size} dryRun=$dryRun")

        // —— 防重入：同一 cmdId 已在执行中（或已完成）时直接拒绝，避免重复确定弹窗 ——
        synchronized(this) {
            val running = runningCmdId
            if (running != null && running == command.cmdId) {
                RuntimeLog.warn("WebViewBet", "cmdId=${command.cmdId} 已在执行中，跳过重复触发")
                onResult(
                    ExecutionResult.fail(
                        command.cmdId,
                        ExecutionResult.DUPLICATE_COMMAND,
                        "该指令正在执行中，已忽略重复触发"
                    )
                )
                return false
            }
            runningCmdId = command.cmdId
        }

        mainHandler.post {
            try {
                // 0) 每轮指令开始时重置确认指纹表，防止上一期点击记录导致本期"确认"按钮被跳过
                wv.evaluateJavascript("window.__CFX_CONFIRMED_FPS = {};", null)
                // ① 余额前
                wv.evaluateJavascript(balJs) { beforeRaw ->
                    val before = unescapeJsResult(beforeRaw).trim().trim('"')
                    RuntimeLog.info("WebViewBet", "余额前=$before cmdId=${command.cmdId}")
                    // ② Phase1: 点击玩法按钮
                    wv.evaluateJavascript(phase1Js) { r1Raw ->
                        val r1 = unescapeJsResult(r1Raw)
                        RuntimeLog.info("WebViewBet", "Phase1(点击) cmdId=${command.cmdId} raw=${r1.take(200)}")
                        val receipt1 = adapter.parseReceipt(r1)
                        if (!receipt1.isSuccess) {
                            returnResult(wv, command, onResult, start, before, before, false, "Phase1失败: ${receipt1.message}", dryRun)
                            return@evaluateJavascript
                        }
                        // ③ 等待 600ms 让页面 UI 更新（金额框可能出现）
                        mainHandler.postDelayed({
                            // ④ Phase2: 输入金额
                            wv.evaluateJavascript(phase2Js) { r2Raw ->
                                val r2 = unescapeJsResult(r2Raw)
                                RuntimeLog.info("WebViewBet", "Phase2(金额) cmdId=${command.cmdId} raw=${r2.take(200)}")
                                val receipt2 = adapter.parseReceipt(r2)
                                if (!receipt2.isSuccess) {
                                    returnResult(wv, command, onResult, start, before, before, false, "Phase2失败: ${receipt2.message}", dryRun)
                                    return@evaluateJavascript
                                }
                                // ⑤ 等待 400ms 让站点异步联动（input 联动可能把 10 改写成 100 / 1 改写成 10）
                                mainHandler.postDelayed({
                                    // ⑤b Phase2.5: 金额复核——再次读取页面金额框实际值，若被改写则强制重设
                                    wv.evaluateJavascript(phase2VerifyJs) { vRaw ->
                                        val v = unescapeJsResult(vRaw)
                                        RuntimeLog.info("WebViewBet", "Phase2.5(金额复核) cmdId=${command.cmdId} raw=${v.take(200)}")
                                        val vOk = v.contains("\"ok\":true") || v.contains("\"ok\": true")
                                        if (!vOk) {
                                            // 复核无法把金额稳定在期望值（站点强联动改写）→ 阻止确认，避免错单
                                            returnResult(wv, command, onResult, start, before, before, false, "金额复核失败: ${v.take(160)}", dryRun)
                                            return@evaluateJavascript
                                        }
                                        // ⑥ Phase3: 点击确认（Kotlin 侧延时驱动单轮循环，JS 内零忙等 → 不再卡黑屏）
                                        var confirmStopped = false
                                        fun confirmRound(round: Int) {
                                            if (confirmStopped) return
                                            wv.evaluateJavascript(phase3Js) { r3Raw ->
                                                if (confirmStopped) return@evaluateJavascript
                                                val r3 = unescapeJsResult(r3Raw)
                                                RuntimeLog.info("WebViewBet", "Phase3(确认#$round) cmdId=${command.cmdId} raw=${r3.take(200)}")
                                                val receipt3 = adapter.parseReceipt(r3)
                                                val finished = r3.contains("\"finished\":true") || r3.contains("\"finished\": true")
                                                val clicked = r3.contains("\"clicked\":true") || r3.contains("\"clicked\": true")
                                                if (finished || !clicked || round >= 3) {
                                                    confirmStopped = true
                                                    // ⑦ 等待 600ms 让页面处理确认
                                                    mainHandler.postDelayed({
                                                        // ⑧ 余额后
                                                        wv.evaluateJavascript(balJs) { afterRaw ->
                                                            val after = unescapeJsResult(afterRaw).trim().trim('"')
                                                            val changed = before.isNotBlank() && after.isNotBlank() && before != after && after != "null" && before != "null"
                                                            val ok = receipt3.isSuccess
                                                            val msg = "玩法→金额→确认 " + (if (ok) "成功" else "失败") + " $before→$after · ${receipt3.message}"
                                                            returnResult(wv, command, onResult, start, before, after, ok && (changed || dryRun), msg, dryRun)
                                                        }
                                                    }, 600)
                                                } else {
                                                    mainHandler.postDelayed({ confirmRound(round + 1) }, 800)
                                                }
                                            }
                                        }
                                        confirmRound(1)
                                    }
                                }, 400)
                            }
                        }, 600)
                    }
                }
            } catch (e: Exception) {
                synchronized(this) {
                    if (runningCmdId == command.cmdId) runningCmdId = null
                }
                RuntimeLog.error("WebViewBet", "execute 异常: ${e.message}")
                onResult(ExecutionResult.fail(command.cmdId, ExecutionResult.ACTION_FAILED, "执行异常: ${e.message}", System.currentTimeMillis() - start))
            }
        }
        return true
    }

    private fun returnResult(
        wv: WebView, command: BetCommand, onResult: (ExecutionResult) -> Unit,
        start: Long, before: String, after: String, ok: Boolean, msg: String, dryRun: Boolean
    ) {
        val duration = System.currentTimeMillis() - start
        /* 同一指令执行结束，释放防重入标记 */
        synchronized(this) {
            if (runningCmdId == command.cmdId) runningCmdId = null
        }
        com.caifenxi.app.domain.execution.ExecutionTicketStore.updateStatus(
            command.cmdId,
            if (ok) "SUCCESS" else "FAILED",
            msg,
            balanceBefore = before,
            balanceAfter = after
        )
        val result = if (ok) {
            ExecutionResult.ok(command.cmdId, msg, duration)
        } else {
            ExecutionResult.fail(command.cmdId, ExecutionResult.ACTION_FAILED, msg, duration)
        }
        onResult(result)
    }

    fun executeWebViewBet(
        dx: String?,
        ds: String?,
        amountText: String?,
        combo: String?,
        predNumbers: List<String> = emptyList(),
        onResult: ((ExecutionResult) -> Unit)? = null
    ): Boolean {
        val bets = buildList {
            if (dx == "大" || dx == "小") {
                add(BetAction(BetAction.CAT_DX, dx))
            }
            if (ds == "单" || ds == "双") {
                add(BetAction(BetAction.CAT_DS, ds))
            }
            if (combo != null) {
                add(BetAction(BetAction.CAT_COMBO, combo))
            }
            predNumbers.forEach {
                add(BetAction(BetAction.CAT_NUMBER, it))
            }
        }
        if (bets.isEmpty()) return false
        val cmd = BetCommand(
            cmdId = "legacy-${System.currentTimeMillis()}",
            lotteryKey = "",
            issue = "",
            bets = bets,
            amountText = amountText
        )
        return execute(cmd) { r -> onResult?.invoke(r) }
    }

    private fun unescapeJsResult(raw: String?): String {
        if (raw.isNullOrBlank() || raw == "null") return ""
        var s = raw.trim()
        if (s.startsWith("\"") && s.endsWith("\"")) {
            s = s.substring(1, s.length - 1)
                .replace("\\\"", "\"")
                .replace("\\\\", "\\")
                .replace("\\n", "\n")
        }
        return s
    }
}
