# P64 — Unified Crypto WebSocket Provider Failover

## 本次完成

### 1. 下游 WebSocket 不再绑定 Binance

新增统一 `CryptoWsGateway`：

`Android -> /api/v1/ws/market -> CryptoWsGateway -> Binance / OKX / Bybit`

Android 继续只连接 Smart Trader 后端，不直接连接任何交易所 WebSocket。

### 2. 三个公共行情适配器

- Binance USD-M：复用现有标准化 adapter
- OKX：ticker / trades + business candlestick channel
- Bybit：ticker / publicTrade / kline

全部转换成统一 EventBus 事件：

- `MarketTickEvent`
- `TradeEvent`
- `CandleEvent`
- Bybit derivatives ticker 同步 `FundingRateEvent` / `OpenInterestEvent`

### 3. 自动故障切换

默认顺序：

`Binance -> OKX -> Bybit`

可通过 `SMART_TRADER_CRYPTO_PROVIDER_ORDER` 调整顺序。

当活动 provider 长时间处于 `RECONNECTING / STALE / DOWN`，网关会自动切换到下一 provider，并重新派发当前订阅品种，不需要 Android 重建订阅逻辑。

### 4. K 线恢复也统一 provider

`CandleRecoveryService` 不再只调用 Binance K 线；缺口恢复和冷启动 bootstrap 均走 `CryptoProviderGateway`，因此 Binance 失败时可以使用 OKX / Bybit。

### 5. 健康状态真实暴露

`connection.ready` / `provider.health` 增加 `providers[]`，包含：

- provider
- active
- status
- reconnect_count
- error_count
- last_error
- last_message

不会把 OKX / Bybit 数据标成 Binance。

## 真实性规则

- 不生成模拟行情。
- 不用 0 填充缺失 provider 字段。
- provider 切换后事件的 `venue` 保留真实来源。
- OKX candle 使用官方 business WebSocket；Bybit 使用官方 V5 public linear WebSocket。
- REST provider 仍负责市场发现、报价、K 线和逐字段衍生品补偿；WS 是实时事件通道。

## 验证

- `python -m compileall -q app tests`：PASS
- Backend pytest：**114 passed**
- FastAPI import smoke test：PASS
- Android `:app:compileDebugKotlin`：本机未完成，Gradle Wrapper 下载 Gradle 8.9 时 `services.gradle.org` DNS 不可达；没有将其记为 PASS。

## 当前仍保留的 Binance URL

Backend provider adapter 内仍保留 Binance REST/WS endpoint，这是 Binance provider 本身的实现，不再由 Android 或市场路由直接选择。Terminal/derivatives/multi-exchange 等独立分析 adapter 仍包含其各自的 Binance REST 地址；这些属于下一层 provider-specific 分析适配器，不影响 P64 的市场列表与统一实时 WS failover。
