# P62 Provider Gateway Audit

## 架构

`Android -> /api/v1/markets + /api/v1/candles -> CryptoProviderGateway -> Binance / OKX / Bybit`

Android 不再持有交易所市场 REST URL。

## Failover

1. Binance
2. OKX
3. Bybit

顺序可配置；同一 symbol 首次命中的 provider 同时提供 universe + quote。

## 已覆盖

- market universe
- 24h quote
- OHLCV K线
- derivatives mark/index/funding/open-interest 缺字段补偿
- Android 市场页 provider 来源

## 尚未统一为多供应商 WS

当前 WebSocket runtime 仍保留 Binance `BinanceWsClient`，用于事件总线实时流。REST 市场页/K线已完成 provider gateway；下一阶段可将 WS 也升级为 Binance/OKX/Bybit 可切换 provider，但本次不伪称已经完成。
