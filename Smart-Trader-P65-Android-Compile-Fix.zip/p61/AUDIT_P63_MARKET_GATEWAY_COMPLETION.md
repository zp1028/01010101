# P63 Market Gateway Completion Audit

## 1. 已修复的实际问题

### 市场列表
`/api/v1/markets?market=crypto` 现在直接使用 `CryptoProviderGateway.market_rows()`。

因此不会再出现：

- universe 由 OKX/Bybit 返回；
- quote 又从 Binance 单独查询；
- 最终因为 symbol/provider 不一致导致页面 `provider_unavailable` 或空列表。

同一行必须同时满足：

`instrument + live quote -> same provider`

### 市场详情
`/api/v1/markets/{symbol}` 对 crypto 直接读取 unified gateway，保留真实：

- provider
- venue
- price
- quote_status
- metadata

不再用 Binance WebSocket subscription 判断某个 crypto 是否存在。

## 2. 真实数据规则

- Binance HTTP 451 / DNS / timeout：继续尝试 OKX，再尝试 Bybit。
- Provider 顺序由 `SMART_TRADER_CRYPTO_PROVIDER_ORDER` 控制。
- 不生成模拟价格。
- 不把 OKX/Bybit 数据标成 Binance。
- provider 全部不可用时返回明确错误，页面保持真实空状态。

## 3. Android

Android 市场 REST/K线层已经不直接访问 Binance/OKX/Bybit；交易所 URL 只存在于 backend provider adapters。

## 4. 验证

- `python -m compileall -q app tests`：PASS
- Backend pytest：**111 passed**
- 本机公网 DNS 当前不可用，因此没有把本机网络请求结果当作 Binance/OKX/Bybit 实时可用性证明。
- Android Gradle 真机/CI 编译未在本阶段伪造为 PASS；需要 CI 环境继续验证。

## 5. 仍然明确存在的下一层

- Backend 事件总线 WebSocket 当前仍由 `BinanceWsClient` 提供；没有声称已经完成多交易所 WS failover。
- Terminal adapter 已有 Binance -> OKX fallback，但尚未纳入统一 provider registry 的完整 WS/terminal adapter 体系。
