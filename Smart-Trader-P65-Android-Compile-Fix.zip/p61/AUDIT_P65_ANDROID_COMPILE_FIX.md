# P65 Android Compile Fix / Provider Boundary Audit

## 触发问题

GitHub Actions `:app:compileDebugKotlin` 在 `AppState.kt` 失败，核心错误是：

- `Unresolved reference: fetchCryptoMarketsDirect`
- 随后的 `items / copy / symbol / price / quoteStatus / hasMore` 均为级联类型推断错误。

原因：P64 已将 Android 市场链路收口为 `Android -> Smart Trader backend -> Crypto Provider Gateway`，但 `AppState.kt` 仍残留 P61/P62 时代的 `fetchCryptoMarketsDirect(...)` 直连交易所备用分支，而 P64 的 `RestClient` 已移除该方法。

## 修复

1. 删除 `AppState.loadUniverse()` 对不存在的 `fetchCryptoMarketsDirect()` 调用。
2. 删除 `AppState.loadMoreMarkets()` 对不存在的 `fetchCryptoMarketsDirect()` 调用。
3. Android 不再在市场列表层直接访问 Binance / OKX / Bybit。
4. 加密市场故障切换统一交给后端 `CryptoProviderGateway`。
5. 后端网关不可用时保留真实错误状态，不生成固定币种、不生成模拟价格、不把缺失字段填成 0。
6. Android 源码扫描确认 `android/app/src/main/java` 不再包含 Binance / OKX / Bybit URL。

## 数据链路

```text
Android AppState
    -> RestClient.fetchMarketsPage()
    -> /api/v1/markets
    -> Crypto Provider Gateway
       -> Binance
       -> OKX
       -> Bybit
    -> normalized MarketItem
```

实时 WS 仍为：

```text
Android
    -> /api/v1/ws/market
    -> CryptoWsGateway
       -> Binance / OKX / Bybit
```

## 验证

- Backend `python3 -m compileall -q app tests`: PASS
- Backend `pytest -q`: **114 passed**
- Android 源码交易所 URL 扫描: PASS（无 Binance/OKX/Bybit URL）
- Android `:app:compileDebugKotlin`: 本环境无法执行，因为 Gradle Wrapper 需要下载 Gradle 8.9，而当前容器无法解析 `services.gradle.org`；因此不将 Android 编译标记为 PASS。
