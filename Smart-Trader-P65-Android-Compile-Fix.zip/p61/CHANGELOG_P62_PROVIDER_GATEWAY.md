# P62 — Unified Crypto Provider Gateway

## 本次交付

- 新增 `CryptoProviderGateway`，统一 Binance / OKX / Bybit 的只读加密市场发现与行情入口。
- Provider 顺序可通过 `SMART_TRADER_CRYPTO_PROVIDER_ORDER` 配置，默认 `binance,okx,bybit`。
- 市场品种与报价必须来自同一 provider，避免“OKX 品种 + Binance 报价”的交叉污染。
- Binance HTTP 451 / DNS / timeout 时，市场页自动使用 OKX / Bybit 公共实时数据。
- K 线统一走同一 provider failover 链，Android 不再直接请求交易所。
- Android `RestClient` 删除 Binance / OKX / Bybit 直连市场与 K 线 fallback，统一通过 Smart Trader backend。
- 衍生品字段改为逐字段 fallback：Binance 部分字段可用时，缺失的 mark/index/funding/OI 可由 OKX/Bybit 补齐；不支持字段仍保持 unavailable。
- 保留 analysis-only：没有账户连接、下单、撤单、交易执行。

## 真实性规则

- 不生成模拟价格、不补 0、不把 fallback provider 标成 Binance。
- 每个市场行带 `provider` / `venue` / `quote_status`。
- Provider 全部不可用时返回明确 provider error，市场页保持空状态，不伪造数据。

## 验证

- Backend：`109 passed`。
- 新增 Provider Gateway fallback / provider-order 测试。
- 当前运行环境无法访问公网 DNS，因此未把本地联网结果当成真实 provider 可用性证明。
- Android `:app:compileDebugKotlin` 未完成：Gradle Wrapper 下载 `services.gradle.org` 时 DNS 失败。
