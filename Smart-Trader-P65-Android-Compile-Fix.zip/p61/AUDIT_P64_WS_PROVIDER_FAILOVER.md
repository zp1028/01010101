# P64 WebSocket Provider Failover Audit

## 架构结论

市场实时链路已经从单一 Binance WS 改为统一 provider gateway：

```text
Android
  -> Smart Trader /api/v1/ws/market
      -> CryptoWsGateway
          -> BinanceWsClient
          -> OkxWsClient
          -> BybitWsClient
      -> EventBus normalized events
```

## Failover 行为

1. 启动按 `SMART_TRADER_CRYPTO_PROVIDER_ORDER` 选择第一 provider。
2. provider 建立连接后保持 `HEALTHY`。
3. 出现 `RECONNECTING / STALE / DOWN` 并超过 `ws_failover_grace_seconds` 后切换。
4. 切换前保存订阅集合。
5. 新 provider 启动后自动恢复同一批 symbol 订阅。
6. WebSocket 下游协议不发生交易所格式泄漏。

## Provider 覆盖

| Provider | Ticker | Trade | Kline | 衍生实时字段 |
|---|---:|---:|---:|---:|
| Binance | ✓ | ✓ | ✓ | funding/mark |
| OKX | ✓ | ✓ | ✓ | REST 补偿 |
| Bybit | ✓ | ✓ | ✓ | funding/OI |

## K 线冷启动/断线恢复

`CandleRecoveryService` 已从 Binance-only 改为 `CryptoProviderGateway.fetch_klines()`。

因此：

`Binance fail -> OKX -> Bybit`

仍可用于冷启动和 WS gap recovery。

## 测试

- Provider gateway failover subscription preservation：PASS
- Bybit normalized ticker/trade/kline：PASS
- 全量 Backend：**114 passed**
- Python compileall：PASS

## Android

Android `MarketWsClient` 仍只连接后端 `/api/v1/ws/market`；本次无需增加交易所 URL。

## 未伪称项目

以下仍是独立 provider-specific 分析适配器，尚未全部改造成同一个 `CryptoProviderGateway`：

- Terminal snapshot
- Crypto derivatives research aggregation
- Crypto multi-exchange research comparison

这些模块不会改变市场页 provider pairing 和统一 WS failover 的正确性，但后续如果要实现“所有 crypto 分析数据都由同一个 provider registry 调度”，应继续收口。
