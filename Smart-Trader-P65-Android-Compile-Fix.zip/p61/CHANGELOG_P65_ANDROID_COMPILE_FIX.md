# P65 — Android Compile Fix / Provider Boundary Cleanup

## 修复内容

- 修复 `AppState.kt` 对已删除 `RestClient.fetchCryptoMarketsDirect()` 的残留引用。
- 移除由该引用引发的 `items/copy/symbol/price/quoteStatus/hasMore` 全部级联 Kotlin 编译错误。
- 市场列表继续只通过 Smart Trader 后端 provider gateway 获取真实数据。
- Android 不再保留 Binance / OKX / Bybit 直连市场列表 URL。
- 后端 Binance -> OKX -> Bybit failover 不变。

## 真实性规则

- 不生成模拟币种。
- 不生成模拟价格。
- 不以默认值伪造 provider 数据。
- provider 切换后由后端返回真实 `venue/provider` 信息。

## 验证结果

- Backend compileall: PASS
- Backend tests: 114 passed
- Android provider URL scan: PASS
- Android Gradle compile: 未完成（环境 DNS 无法访问 services.gradle.org），未虚报为 PASS。
