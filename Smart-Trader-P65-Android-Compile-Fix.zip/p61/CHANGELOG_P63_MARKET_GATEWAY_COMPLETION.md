# P63 — Market Gateway Completion

## 本次完成

- 修正 `/api/v1/markets?market=crypto` 的最后一处 provider 拼接问题：Crypto 市场现在直接消费 `CryptoProviderGateway.market_rows()`，不再先从独立 universe 再二次拼报价。
- 修正 crypto detail：`/api/v1/markets/{symbol}` 直接从统一 gateway 获取当前 live instrument，保留真实 `provider` / `venue` / `quote_status`。
- 修正 Binance 451 / DNS fallback 场景下的“品种来自 OKX、报价却来自 Binance/旧缓存”风险。
- 保留 US/HK/commodities 原有配置化 universe 路径；没有配置实时 provider 的字段继续明确显示 unavailable，不填 0。
- 增加市场 gateway pairing/detail 回归测试。

## 当前数据链

`Android -> /api/v1/markets -> CryptoProviderGateway -> Binance / OKX / Bybit`

同一市场行必须由同一个 provider 同时提供 instrument + quote。

## 未伪称完成

WebSocket 事件流仍是独立 provider adapter；本阶段没有把 Binance WS 伪装成多交易所 WS failover。
