import pytest
from app.services.crypto_provider_gateway import CryptoProviderGateway


@pytest.mark.asyncio
async def test_gateway_falls_back_without_cross_provider_pairing(monkeypatch):
    gateway = CryptoProviderGateway()

    async def fake_rows(provider):
        if provider == "binance":
            raise RuntimeError("HTTP 451")
        if provider == "okx":
            return (
                [{"symbol": "BTCUSDT", "name": "BTC-USDT-SWAP", "venue": "okx", "currency": "USDT", "metadata": {}}],
                {"BTCUSDT": {"price": 100.0, "change_pct": 1.0, "source": "OKX SWAP", "quote_status": "live"}},
            )
        return ([], {})

    monkeypatch.setattr(gateway, "_provider_rows", fake_rows)
    rows = await gateway.market_rows()
    assert len(rows) == 1
    assert rows[0]["provider"] == "okx"
    assert rows[0]["venue"] == "okx"
    assert rows[0]["price"] == 100.0


@pytest.mark.asyncio
async def test_gateway_prefers_configured_provider_order(monkeypatch):
    gateway = CryptoProviderGateway()

    async def fake_rows(provider):
        return (
            [{"symbol": "BTCUSDT", "name": provider, "venue": provider, "currency": "USDT", "metadata": {}}],
            {"BTCUSDT": {"price": {"binance": 101.0, "okx": 102.0, "bybit": 103.0}[provider], "quote_status": "live"}},
        )

    monkeypatch.setattr(gateway, "_provider_rows", fake_rows)
    monkeypatch.setenv("SMART_TRADER_CRYPTO_PROVIDER_ORDER", "okx,binance,bybit")
    rows = await gateway.market_rows()
    assert rows[0]["provider"] == "okx"
    assert rows[0]["price"] == 102.0
