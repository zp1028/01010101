import pytest

from app.api.v1 import markets as markets_api


@pytest.mark.asyncio
async def test_crypto_market_route_uses_gateway_rows_directly(monkeypatch):
    async def fake_rows():
        return [
            {
                "symbol": "BTCUSDT",
                "name": "BTC-USDT-SWAP",
                "market": "crypto",
                "asset_type": "crypto",
                "venue": "okx",
                "currency": "USDT",
                "provider": "okx",
                "price": 101.5,
                "change_pct": 2.0,
                "quote_status": "live",
                "metadata": {"provider": "okx"},
            }
        ]

    monkeypatch.setattr(markets_api._crypto_gateway, "market_rows", fake_rows)
    result = await markets_api.markets(market="crypto", q=None, limit=100, offset=0, sort="symbol")
    assert result["total"] == 1
    assert result["markets"][0]["provider"] == "okx"
    assert result["markets"][0]["venue"] == "okx"
    assert result["markets"][0]["price"] == 101.5
    assert result["markets"][0]["quote_status"] == "live"


@pytest.mark.asyncio
async def test_crypto_market_detail_keeps_provider_source(monkeypatch):
    async def fake_rows():
        return [{
            "symbol": "ETHUSDT", "name": "ETH-USDT-SWAP", "market": "crypto",
            "asset_type": "crypto", "venue": "bybit", "currency": "USDT",
            "provider": "bybit", "price": 2020.0, "quote_status": "live",
        }]

    monkeypatch.setattr(markets_api._crypto_gateway, "market_rows", fake_rows)
    result = await markets_api.market("ETHUSDT")
    assert result["provider"] == "bybit"
    assert result["venue"] == "bybit"
    assert result["price"] == 2020.0
