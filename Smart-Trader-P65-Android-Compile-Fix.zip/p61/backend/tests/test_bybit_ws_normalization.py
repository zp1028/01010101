import pytest

from app.core.event_bus import EventBus
from app.core.events import CandleEvent, MarketTickEvent, TradeEvent
from app.models.instrument import InstrumentRegistry
from app.providers.crypto.bybit.ws import BybitWsClient


@pytest.mark.asyncio
async def test_bybit_ws_normalizes_ticker_trade_and_kline():
    settings = type("S", (), {"binance_kline_interval": "1m"})()
    bus = EventBus()
    instruments = InstrumentRegistry()
    events = []
    async def collect(event):
        events.append(event)
    for kind in (MarketTickEvent, TradeEvent, CandleEvent):
        bus.subscribe(kind, collect)
    client = BybitWsClient(settings, bus, instruments)
    await client._handle_raw('{"topic":"tickers.BTCUSDT","ts":1000,"data":{"symbol":"BTCUSDT","lastPrice":"100","bid1Price":"99.9","ask1Price":"100.1","bid1Size":"2","ask1Size":"3"}}')
    await client._handle_raw('{"topic":"publicTrade.BTCUSDT","ts":1001,"data":[{"T":1001,"s":"BTCUSDT","S":"Buy","v":"0.2","p":"100.0"}]}')
    await client._handle_raw('{"topic":"kline.1.BTCUSDT","ts":1002,"data":[{"start":1000,"end":1999,"interval":"1","open":"99","high":"101","low":"98","close":"100","volume":"12","confirm":true,"timestamp":1002,"symbol":"BTCUSDT"}]}')
    assert any(isinstance(e, MarketTickEvent) and e.venue == "bybit" and e.last == 100.0 for e in events)
    assert any(isinstance(e, TradeEvent) and e.venue == "bybit" and e.price == 100.0 for e in events)
    assert any(isinstance(e, CandleEvent) and e.venue == "bybit" and e.interval == "1m" and e.is_closed for e in events)
