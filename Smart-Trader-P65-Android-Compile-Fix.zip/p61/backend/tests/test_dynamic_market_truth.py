import os

import pytest

from app.core.config import Settings
from app.services.market_universe import MarketUniverseService, UniverseItem


def test_default_symbol_configuration_is_not_hard_coded():
    settings = Settings(_env_file=None)
    assert settings.symbols == []


@pytest.mark.asyncio
async def test_crypto_universe_uses_unified_gateway(monkeypatch):
    service = MarketUniverseService()

    class FakeGateway:
        async def market_rows(self):
            return [{
                "symbol": "LIVEUSDT", "name": "LIVEUSDT", "venue": "okx",
                "provider": "okx", "currency": "USDT", "metadata": {},
                "quote_status": "live", "price": 123.0,
            }]

    monkeypatch.setattr("app.services.crypto_provider_gateway.CryptoProviderGateway", FakeGateway)
    items = await service.crypto()
    assert {x.symbol for x in items} == {"LIVEUSDT"}
    assert items[0].venue == "okx"
