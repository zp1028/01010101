import pytest

from app.api.v1 import markets as markets_api


@pytest.mark.asyncio
async def test_crypto_markets_does_not_require_other_market_providers(monkeypatch):
    async def gateway_rows():
        return [{
            "symbol": "BTCUSDT",
            "name": "BTC-USDT-SWAP",
            "market": "crypto",
            "asset_type": "crypto",
            "venue": "okx",
            "currency": "USDT",
            "provider": "okx",
            "price": 100000.0,
            "change_pct": 1.25,
            "quote_status": "live",
            "metadata": {"provider": "okx"},
        }]

    async def fail_other():
        raise AssertionError("non-crypto provider must not be called for crypto market")

    monkeypatch.setattr(markets_api._crypto_gateway, "market_rows", gateway_rows)
    monkeypatch.setattr(markets_api.universe, "us", fail_other)
    monkeypatch.setattr(markets_api.universe, "hk", fail_other)
    monkeypatch.setattr(markets_api.universe, "commodities", fail_other)

    result = await markets_api.markets(market="crypto", q=None, limit=250, offset=0, sort="symbol")
    assert result["total"] == 1
    assert result["markets"][0]["symbol"] == "BTCUSDT"
    assert result["markets"][0]["price"] == 100000.0
    assert result["markets"][0]["provider"] == "okx"
    assert result["markets"][0]["quote_status"] == "live"
