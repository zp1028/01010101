import asyncio

import pytest

from app.models.provider import ProviderHealth, ProviderStatus
from app.providers.crypto.gateway import CryptoWsGateway


class FakeProvider:
    def __init__(self, name: str, status=ProviderStatus.HEALTHY):
        self.name = name
        self.health = ProviderHealth(name=name, status=status)
        self.subscriptions = set()
        self.started = 0
        self.stopped = 0

    async def start(self):
        self.started += 1
        self.health.status = ProviderStatus.HEALTHY

    async def stop(self):
        self.stopped += 1
        self.health.status = ProviderStatus.DOWN

    async def subscribe(self, symbols):
        self.subscriptions.update(s.upper() for s in symbols)

    async def unsubscribe(self, symbols):
        self.subscriptions.difference_update(s.upper() for s in symbols)


@pytest.mark.asyncio
async def test_ws_gateway_preserves_subscriptions_on_failover(monkeypatch):
    gateway = CryptoWsGateway.__new__(CryptoWsGateway)
    gateway.settings = type("S", (), {"ws_failover_grace_seconds": 0.1})()
    gateway._providers = {
        "binance": FakeProvider("binance", ProviderStatus.RECONNECTING),
        "okx": FakeProvider("okx", ProviderStatus.HEALTHY),
        "bybit": FakeProvider("bybit", ProviderStatus.HEALTHY),
    }
    gateway._active_name = "binance"
    gateway._index = 0
    gateway._subscriptions = {"BTCUSDT", "ETHUSDT"}
    gateway._monitor_task = None
    gateway._started = True
    gateway._bad_since = None
    await gateway._activate("okx")
    assert gateway.active_name == "okx"
    assert gateway._providers["okx"].subscriptions == {"BTCUSDT", "ETHUSDT"}
    assert gateway._providers["binance"].stopped == 1


@pytest.mark.asyncio
async def test_ws_gateway_health_snapshot_marks_active_provider():
    gateway = CryptoWsGateway.__new__(CryptoWsGateway)
    gateway._providers = {
        "binance": FakeProvider("binance"),
        "okx": FakeProvider("okx", ProviderStatus.DOWN),
    }
    gateway._active_name = "binance"
    gateway._subscriptions = set()
    gateway._index = 0
    gateway._started = False
    gateway._monitor_task = None
    gateway._bad_since = None
    snapshot = gateway.health_snapshot()
    assert snapshot[0]["active"] is True
    assert snapshot[1]["active"] is False
