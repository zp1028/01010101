package com.caifenxi.app.domain.execution

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityNodeInfo
import com.caifenxi.app.util.RuntimeLog
import kotlinx.coroutines.*
import java.util.concurrent.atomic.AtomicBoolean

/**
 * AI 视觉执行器：用多模态 LLM 替代 DOM 评分和文字匹配
 *
 * 接入 ExecutorManager，与 WebViewExecutor / AccessibilityExecutor 并列
 * 执行流程：截图 → LLM 分析 → 结构化 Action → 无障碍手势执行 → 结果校验
 */
class AiVisionExecutor(
    private val a11yService: AccessibilityService,
    private val llmClient: LlmClient,
    private val perception: PerceptionEngine
) : Executor {

    override val id: String = "ai_vision"

    override val isAvailable: Boolean
        get() = llmClient.isReady && perception.canCapture()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val pipelineRunning = AtomicBoolean(false)

    // 最大执行步数，防止无限循环
    private val maxSteps = 15
    // 单步超时（含 LLM API 调用）
    private val stepTimeoutMs = 15_000L
    // 最低置信度阈值
    private val minConfidence = 0.75f
    // 执行后等待页面响应时间
    private val actionDelayMs = 600L

    override fun execute(command: BetCommand, onResult: (ExecutionResult) -> Unit): Boolean {
        if (!isAvailable) {
            onResult(ExecutionResult.fail(
                command.cmdId,
                ExecutionResult.WEBVIEW_DISCONNECTED,
                "AI视觉执行器不可用（LLM未配置或无截图权限）"
            ))
            return false
        }

        scope.launch {
            val result = runAiLoop(command)
            onResult(result)
        }
        return true
    }

    /**
     * AI 视觉执行主循环
     */
    private suspend fun runAiLoop(command: BetCommand): ExecutionResult {
        val history = mutableListOf<ActionRecord>()
        val startTime = System.currentTimeMillis()
        val actionResults = mutableListOf<ActionResult>()

        RuntimeLog.info("AiVision", "开始AI视觉执行 cmdId=${command.cmdId} 彩种=${command.lotteryKey} 期号=${command.issue}")

        for (step in 0 until maxSteps) {
            // 检查是否过期
            if (command.isExpired) {
                return ExecutionResult.fail(
                    command.cmdId,
                    ExecutionResult.COMMAND_EXPIRED,
                    "指令已过期",
                    System.currentTimeMillis() - startTime
                ).copy(actionResults = actionResults)
            }

            try {
                val result = withTimeout(stepTimeoutMs) {
                    executeSingleStep(command, history, step)
                }

                when (result) {
                    is StepResult.Action -> {
                        history.add(ActionRecord(step, result.action.toString(), System.currentTimeMillis()))
                        actionResults.add(result.actionResult)
                        delay(actionDelayMs)
                    }
                    is StepResult.Finish -> {
                        return result.executionResult.copy(actionResults = actionResults)
                    }
                    is StepResult.Fail -> {
                        return result.executionResult.copy(actionResults = actionResults)
                    }
                }
            } catch (e: TimeoutCancellationException) {
                RuntimeLog.warn("AiVision", "cmdId=${command.cmdId} 单步超时")
                return ExecutionResult.timeout(command.cmdId, "AI执行单步超时(${stepTimeoutMs}ms)")
                    .copy(actionResults = actionResults)
            } catch (e: Exception) {
                RuntimeLog.warn("AiVision", "cmdId=${command.cmdId} 执行异常: ${e.message}")
                return ExecutionResult.fail(
                    command.cmdId,
                    ExecutionResult.ACTION_FAILED,
                    "AI执行异常: ${e.message}",
                    System.currentTimeMillis() - startTime
                ).copy(actionResults = actionResults)
            }
        }

        return ExecutionResult.timeout(command.cmdId, "AI执行步数超限($maxSteps)")
            .copy(actionResults = actionResults)
    }

    /**
     * 单步执行：感知 → LLM决策 → 执行
     */
    private suspend fun executeSingleStep(
        command: BetCommand,
        history: List<ActionRecord>,
        step: Int
    ): StepResult {
        // 1. 感知：截图
        val screenshotBase64 = perception.captureScreenshot()
        if (screenshotBase64.isBlank()) {
            return StepResult.Fail(ExecutionResult.fail(
                command.cmdId,
                ExecutionResult.ACTION_FAILED,
                "截图失败，无法获取页面状态"
            ))
        }

        // 2. 感知：节点树
        val nodeTree = perception.extractNodeTree()
        val currentIssue = perception.extractIssueNumber(nodeTree)

        // 3. 构建 Prompt
        val prompt = AiPromptBuilder.build(
            command = command,
            screenshotBase64 = screenshotBase64,
            nodeTree = nodeTree,
            history = history,
            currentIssue = currentIssue
        )

        // 4. LLM 决策
        val llmStart = System.currentTimeMillis()
        val llmResponse = llmClient.chat(prompt)
        val llmDuration = System.currentTimeMillis() - llmStart

        val action = when (llmResponse) {
            is LlmResponse.Success -> {
                RuntimeLog.info("AiVision", "LLM响应(${llmDuration}ms): ${llmResponse.content.take(200)}")
                val parsed = ActionParser.parse(llmResponse.content)
                ActionParser.validate(parsed, minConfidence)
            }
            is LlmResponse.Error -> {
                RuntimeLog.warn("AiVision", "LLM请求失败: ${llmResponse.message}")
                ActionParser.Action(type = "fail", reason = llmResponse.message)
            }
        }

        // 5. 执行动作
        return when (action.type) {
            "click" -> {
                performClick(action.x, action.y)
                showClickFeedback(action.x, action.y, action.target)
                val actionResult = ActionResult(
                    category = "click",
                    value = action.target,
                    success = true,
                    durationMs = llmDuration
                )
                StepResult.Action(action, actionResult)
            }
            "type" -> {
                performType(action.x, action.y, action.text)
                val actionResult = ActionResult(
                    category = "type",
                    value = action.text,
                    success = true,
                    durationMs = llmDuration
                )
                StepResult.Action(action, actionResult)
            }
            "scroll" -> {
                performScroll(action.direction, action.amount)
                val actionResult = ActionResult(
                    category = "scroll",
                    value = action.direction,
                    success = true,
                    durationMs = llmDuration
                )
                StepResult.Action(action, actionResult)
            }
            "wait" -> {
                delay(action.delayMs)
                val actionResult = ActionResult(
                    category = "wait",
                    value = "${action.delayMs}ms",
                    success = true,
                    durationMs = llmDuration
                )
                StepResult.Action(action, actionResult)
            }
            "finish" -> {
                // 最终校验：再次截图确认
                val verifyResult = verifyExecution(command, history)
                StepResult.Finish(verifyResult)
            }
            "fail" -> {
                StepResult.Fail(ExecutionResult.fail(
                    command.cmdId,
                    ExecutionResult.ACTION_FAILED,
                    "AI决策失败: ${action.reason}"
                ))
            }
            else -> {
                StepResult.Fail(ExecutionResult.fail(
                    command.cmdId,
                    ExecutionResult.ACTION_FAILED,
                    "未知操作类型: ${action.type}"
                ))
            }
        }
    }

    /**
     * 执行后校验：截图让 LLM 确认是否成功
     */
    private suspend fun verifyExecution(
        command: BetCommand,
        history: List<ActionRecord>
    ): ExecutionResult {
        val startTime = System.currentTimeMillis()

        // 短暂等待页面更新
        delay(800)

        val screenshot = perception.captureScreenshot()
        val nodeTree = perception.extractNodeTree()
        val currentIssue = perception.extractIssueNumber(nodeTree)

        // 构建校验 Prompt
        val verifyPrompt = AiPromptBuilder.build(
            command = command.copy(options = command.options + ("verify" to "true")),
            screenshotBase64 = screenshot,
            nodeTree = nodeTree,
            history = history,
            currentIssue = currentIssue
        )

        val verifyResponse = llmClient.chat(verifyPrompt)
        val isSuccess = when (verifyResponse) {
            is LlmResponse.Success -> {
                val content = verifyResponse.content.lowercase()
                content.contains("success") ||
                content.contains("成功") ||
                content.contains("完成") ||
                content.contains("投注成功")
            }
            else -> false
        }

        val duration = System.currentTimeMillis() - startTime
        return if (isSuccess) {
            ExecutionResult.ok(
                command.cmdId,
                "AI视觉执行成功，页面状态确认",
                duration
            )
        } else {
            ExecutionResult.unknown(
                command.cmdId,
                "执行后校验不确定，需人工核实"
            )
        }
    }

    // ========== 底层执行方法 ==========

    private fun performClick(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 150))
            .build()
        a11yService.dispatchGesture(gesture, null, null)
        RuntimeLog.info("AiVision", "点击坐标: ($x, $y)")
    }

    private fun performType(x: Float, y: Float, text: String) {
        // 先点击聚焦
        performClick(x, y)
        Thread.sleep(300)
        // 通过 Accessibility 输入文本
        val node = findNodeAt(x, y)
        if (node != null && node.isEditable) {
            node.performAction(
                AccessibilityNodeInfo.ACTION_SET_TEXT,
                Bundle().apply {
                    putString(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
                }
            )
            RuntimeLog.info("AiVision", "输入文本: $text at ($x, $y)")
        } else {
            // 如果找不到可编辑节点，尝试逐个字符输入
            RuntimeLog.warn("AiVision", "未找到可编辑节点，尝试逐字输入")
            for (char in text) {
                // 通过手势点击数字键盘
                // 这里简化处理，实际应该映射数字键盘位置
            }
        }
    }

    private fun performScroll(direction: String, amount: Int) {
        val (dx, dy) = when (direction.lowercase()) {
            "up" -> 0f to -amount.toFloat()
            "down" -> 0f to amount.toFloat()
            "left" -> -amount.toFloat() to 0f
            "right" -> amount.toFloat() to 0f
            else -> 0f to -500f // 默认向上滚动
        }
        val path = Path().apply {
            moveTo(540f, 960f)
            rLineTo(dx, dy)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 300))
            .build()
        a11yService.dispatchGesture(gesture, null, null)
        RuntimeLog.info("AiVision", "滚动: $direction $amount")
    }

    private fun findNodeAt(x: Float, y: Float): AccessibilityNodeInfo? {
        val root = a11yService.rootInActiveWindow ?: return null
        return findNodeRecursive(root, x, y)
    }

    private fun findNodeRecursive(node: AccessibilityNodeInfo, x: Float, y: Float): AccessibilityNodeInfo? {
        val bounds = android.graphics.Rect()
        node.getBoundsInScreen(bounds)
        if (bounds.contains(x.toInt(), y.toInt())) {
            if (node.isClickable || node.isEditable) {
                return node
            }
        }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                findNodeRecursive(child, x, y)?.let { return it }
            }
        }
        return null
    }

    private fun showClickFeedback(x: Float, y: Float, label: String) {
        try {
            com.caifenxi.app.service.ClickFeedbackOverlay.show(
                a11yService, x, y, label, fromA11y = true
            )
        } catch (_: Exception) {
            // 反馈覆盖层可选，失败不影响主流程
        }
    }

    override fun cancel(cmdId: String) {
        RuntimeLog.info("AiVision", "取消 cmdId=$cmdId（AI视觉单流水线，新任务会自然顶替）")
    }

    override fun queryState(cmdId: String): ExecutionResult? = null

    // ========== 内部状态密封类 ==========

    private sealed class StepResult {
        data class Action(val action: ActionParser.Action, val actionResult: ActionResult) : StepResult()
        data class Finish(val executionResult: ExecutionResult) : StepResult()
        data class Fail(val executionResult: ExecutionResult) : StepResult()
    }
}
