package com.caifenxi.app.ui.screens

import android.annotation.SuppressLint
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import com.caifenxi.app.automation.LocalSelectorLoader
import com.caifenxi.app.domain.execution.ClickMatchConfig
import com.caifenxi.app.domain.execution.ExecutorManager
import com.caifenxi.app.domain.execution.ExecutionTicketStore
import com.caifenxi.app.service.WebViewExecutor
import com.caifenxi.app.ui.ExecutorViewModel
import com.caifenxi.app.ui.MainViewModel

/**
 * 一级导航全屏网页执行台：
 * - 主区域 WebView
 * - 顶部可折叠状态条：期号/口径/方向金额/执行器/选择器
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebBetScreen(
    mainViewModel: MainViewModel = viewModel(),
    executorViewModel: ExecutorViewModel = viewModel(),
    onBack: () -> Unit = {},
    onWorkbench: () -> Unit = {},
    onBet: () -> Unit = {}
) {
    val context = LocalContext.current
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    val executorStatus by executorViewModel.executorStatus.collectAsState()
    val currentTask by executorViewModel.currentTask.collectAsState()
    val executorLogs by executorViewModel.executorLogs.collectAsState()
    val ticket by ExecutionTicketStore.ticket.collectAsState()

    var urlInput by remember { mutableStateOf("https://www.baidu.com") }
    var pageTitle by remember { mutableStateOf("未加载") }
    var pageStatus by remember { mutableStateOf("待命") }
    var panelExpanded by remember { mutableStateOf(true) }
    var dryRun by remember { mutableStateOf(true) }
    var selectorInfo by remember {
        mutableStateOf(LocalSelectorLoader.current(context))
    }

    val lotteryName = mainViewModel.currentLottery.value.name
    val targetIssue = mainViewModel.nextIssueText.value
    val webReady = WebViewExecutor.isAvailable
    val mode = ExecutorManager.getMode()
    val clickProfile = remember { ClickMatchConfig.load(context) }

    BackHandler {
        val wv = webViewRef
        if (wv?.canGoBack() == true) wv.goBack() else onBack()
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface)) {
        // —— 顶栏状态（功能可视化）——
        Surface(tonalElevation = 2.dp, shadowElevation = 2.dp) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "返回")
                    }
                    Column(Modifier.weight(1f)) {
                        Text("网页执行台", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(
                            "$lotteryName · 目标期 $targetIssue · 识别:大→${clickProfile.labelBig}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    TextButton(onClick = onWorkbench) { Text("工作台", fontSize = 12.sp) }
                    TextButton(onClick = onBet) { Text("挂机", fontSize = 12.sp) }
                    IconButton(onClick = { panelExpanded = !panelExpanded }) {
                        Icon(
                            if (panelExpanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                            contentDescription = "展开状态"
                        )
                    }
                }

                // 一行关键状态
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatusChip(
                        "WebView",
                        if (webReady) "已连接" else "未连接",
                        if (webReady) Color(0xFF2E7D32) else Color(0xFFC62828)
                    )
                    StatusChip(
                        "执行",
                        when (executorStatus) {
                            ExecutorViewModel.ExecutorStatus.IDLE -> "待机"
                            ExecutorViewModel.ExecutorStatus.RUNNING -> "执行中"
                            ExecutorViewModel.ExecutorStatus.COMPLETED -> "完成"
                            else -> executorStatus.name
                        },
                        MaterialTheme.colorScheme.primary
                    )
                    StatusChip(
                        "模式",
                        if (dryRun) "仅识别" else "实盘",
                        if (dryRun) Color(0xFFF9A825) else Color(0xFFC62828)
                    )
                }

                if (panelExpanded) {
                    Spacer(Modifier.height(8.dp))
                    // 选择器
                    val selText = when (val s = selectorInfo) {
                        is LocalSelectorLoader.State.Ok ->
                            "选择器: ${if (s.source == LocalSelectorLoader.Source.EXTERNAL) "外部" else "内置"} v${s.version}"
                        is LocalSelectorLoader.State.ExternalBroken ->
                            "选择器损坏: ${s.message.take(40)}"
                    }
                    Text(selText, style = MaterialTheme.typography.bodySmall,
                        color = if (selectorInfo is LocalSelectorLoader.State.ExternalBroken)
                            MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.onSurfaceVariant)

                    // 工单条：计划 / 口径 / 方向 / 金额 / 回执 / 余额
                    val tk = ticket
                    if (tk.cmdId.isNotBlank()) {
                        Text(
                            "工单 ${ExecutionTicketStore.stageLabel(tk.stage, tk.leg)} · ${tk.planLabel.ifBlank { "挂机" }}",
                            fontWeight = FontWeight.SemiBold,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            "期号 ${tk.issue} · 方向 ${tk.dx ?: "-"}/${tk.ds ?: "-"} · 金额 ${tk.amountText ?: "-"}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            "状态 ${tk.status} · ${tk.message}",
                            style = MaterialTheme.typography.bodySmall,
                            color = when (tk.status) {
                                "SUCCESS" -> Color(0xFF2E7D32)
                                "FAILED", "SKIPPED" -> Color(0xFFC62828)
                                "CLICKED" -> Color(0xFFF9A825)
                                else -> MaterialTheme.colorScheme.onSurfaceVariant
                            }
                        )
                        if (tk.balanceBefore.isNotBlank() || tk.balanceAfter.isNotBlank()) {
                            Text(
                                "余额 ${tk.balanceBefore.ifBlank { "?" }} → ${tk.balanceAfter.ifBlank { "?" }}" +
                                    if (tk.balanceBefore.isNotBlank() && tk.balanceAfter.isNotBlank() && tk.balanceBefore != tk.balanceAfter)
                                        "（已变动，视为点站成功）" else "（未变动，可能未成功或重复）",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    } else {
                        Text(
                            "工单: 等待挂机派发（选计划 → 挂机开启并派发 → 本页执行）",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Text("页面: $pageStatus · $pageTitle", style = MaterialTheme.typography.bodySmall)

                    // URL
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = urlInput,
                            onValueChange = { urlInput = it },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            label = { Text("投注站地址") },
                            textStyle = LocalTextStyle.current.copy(fontSize = 13.sp)
                        )
                        IconButton(onClick = { webViewRef?.loadUrl(urlInput) }) {
                            Icon(Icons.Filled.Refresh, contentDescription = "加载")
                        }
                    }

                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = dryRun,
                            onClick = { dryRun = true },
                            label = { Text("仅识别") }
                        )
                        FilterChip(
                            selected = !dryRun,
                            onClick = { dryRun = false },
                            label = { Text("实盘点击") }
                        )
                        TextButton(onClick = {
                            selectorInfo = LocalSelectorLoader.reload(context)
                        }) { Text("重载选择器") }
                        TextButton(onClick = {
                            LocalSelectorLoader.exportTemplate(context)
                            selectorInfo = LocalSelectorLoader.reload(context)
                        }) { Text("导出模板") }
                    }

                    // 操作
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                val t = executorViewModel.generateTestTask()
                                executorViewModel.startTask(t)
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("测试执行") }
                        OutlinedButton(
                            onClick = { executorViewModel.clearLogs() },
                            modifier = Modifier.weight(1f)
                        ) { Text("清空日志") }
                    }

                    // 日志
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .heightIn(max = 100.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        if (executorLogs.isEmpty()) {
                            Text("日志空 · 挂机下单后将自动派发到本页", fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        } else {
                            executorLogs.takeLast(8).forEach { log ->
                                Text(
                                    log,
                                    fontSize = 11.sp,
                                    color = when {
                                        log.contains("成功") -> Color(0xFF2E7D32)
                                        log.contains("失败") || log.contains("未找到") -> Color(0xFFC62828)
                                        else -> MaterialTheme.colorScheme.onSurface
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // —— 全屏 WebView ——
        AndroidView(
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.useWideViewPort = true
                    settings.loadWithOverviewMode = true
                    settings.domStorageEnabled = true
                    settings.userAgentString =
                        "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                    webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView?, url: String?) {
                            pageStatus = "已加载"
                            pageTitle = view?.title ?: url ?: ""
                            if (url != null) urlInput = url
                            WebViewExecutor.attach(this@apply)
                        }
                    }
                    webChromeClient = object : WebChromeClient() {
                        override fun onReceivedTitle(view: WebView?, title: String?) {
                            if (!title.isNullOrBlank()) pageTitle = title
                        }
                    }
                    WebViewExecutor.attach(this)
                    webViewRef = this
                    loadUrl(urlInput)
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            update = { wv ->
                webViewRef = wv
            }
        )
    }
}

@Composable
private fun StatusChip(label: String, value: String, color: Color) {
    Surface(
        shape = MaterialTheme.shapes.small,
        color = color.copy(alpha = 0.12f)
    ) {
        Text(
            "$label $value",
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            fontSize = 11.sp,
            color = color,
            fontWeight = FontWeight.Medium
        )
    }
}
