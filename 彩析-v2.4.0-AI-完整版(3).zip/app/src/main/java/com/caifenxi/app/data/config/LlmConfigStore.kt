package com.caifenxi.app.data.config

import android.content.Context
import com.caifenxi.app.domain.execution.LlmClient

/**
 * LLM API 配置本地存储
 */
object LlmConfigStore {

    private const val PREFS_NAME = "llm_config"

    fun load(context: Context): LlmClient.LlmConfig {
        val sp = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return LlmClient.LlmConfig(
            provider = try {
                LlmClient.LlmProvider.valueOf(sp.getString("provider", "OPENAI") ?: "OPENAI")
            } catch (_: Exception) {
                LlmClient.LlmProvider.OPENAI
            },
            baseUrl = sp.getString("base_url", "https://api.openai.com/v1") ?: "https://api.openai.com/v1",
            apiKey = sp.getString("api_key", "") ?: "",
            model = sp.getString("model", "gpt-4o-mini") ?: "gpt-4o-mini",
            maxTokens = sp.getInt("max_tokens", 512),
            temperature = sp.getFloat("temperature", 0.1f).toDouble(),
            imageDetail = sp.getString("image_detail", "low") ?: "low"
        )
    }

    fun save(context: Context, config: LlmClient.LlmConfig) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().apply {
            putString("provider", config.provider.name)
            putString("base_url", config.baseUrl)
            putString("api_key", config.apiKey)
            putString("model", config.model)
            putInt("max_tokens", config.maxTokens)
            putFloat("temperature", config.temperature.toFloat())
            putString("image_detail", config.imageDetail)
            apply()
        }
    }
}
