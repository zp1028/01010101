package com.caifenxi.app.domain.execution

/**
 * 通用站点适配：不绑死具体域名，用 DOM 评分识别真正的大小单双下注按钮。
 * 过滤历史/说明里同名文字；供 WebView evaluateJavascript 注入。
 */
object GenericSiteAdapter : SiteAdapter {

    override val siteId: String = "generic"

    override val whitelistDomains: List<String> = emptyList()

    override fun getUrl(lotteryKey: String): String = "about:blank"

    override val issueSelector: String =
        "[class*='issue'],[class*='period'],[id*='issue'],[id*='period'],.qihao,.issue,.period"

    override val balanceSnapshotScript: String = """
        (function(){
          var t = document.body ? (document.body.innerText||'') : '';
          var m = t.match(/(余额|可用|金额)[^0-9]{0,6}([0-9]+(?:\.[0-9]+)?)/);
          return m ? m[2] : String((t.length||0));
        })()
    """.trimIndent()

    override fun buildInjectScript(command: BetCommand): String {
        val profile = try {
            ClickMatchConfig.load(com.caifenxi.app.CaiFenXiApplication.instance)
        } catch (_: Exception) {
            ClickMatchConfig.Profile()
        }
        // 逻辑值（大/小/单/双）映射为用户配置的页面真实文字
        val betsJson = command.bets.joinToString(",") { bet ->
            val mapped = profile.mapLabel(bet.value)
            """{"cat":${jsonStr(bet.category)},"value":${jsonStr(bet.value)},"pageText":${jsonStr(mapped)}}"""
        }
        val amount = command.amountText?.let { jsonStr(it) } ?: "null"
        val issue = jsonStr(command.issue)
        val dryRun = command.options["dryRun"] == "1" || command.options["dryRun"] == "true"
        return """
            (function(){
              var CMD = {
                cmdId: ${jsonStr(command.cmdId)},
                issue: $issue,
                amount: $amount,
                dryRun: ${if (dryRun) "true" else "false"},
                bets: [$betsJson],
                labelMap: {
                  "大": ${jsonStr(profile.labelBig)},
                  "小": ${jsonStr(profile.labelSmall)},
                  "单": ${jsonStr(profile.labelOdd)},
                  "双": ${jsonStr(profile.labelEven)}
                },
                region: {
                  enabled: ${if (profile.regionEnabled) "true" else "false"},
                  left: ${profile.regionLeft},
                  top: ${profile.regionTop},
                  right: ${profile.regionRight},
                  bottom: ${profile.regionBottom}
                }
              };
              $CORE_JS
              return JSON.stringify(window.__caiFenXiRunCommand(CMD));
            })()
        """.trimIndent()
    }

    override fun parseReceipt(rawJson: String): ExecutionReceipt {
        val raw = rawJson.trim().removeSurrounding("\"").replace("\\\"", "\"")
        if (raw.isBlank() || raw == "null") {
            return ExecutionReceipt(false, true, "空回执")
        }
        return try {
            val ok = raw.contains("\"ok\":true") || raw.contains("\"ok\": true")
            val err = raw.contains("\"ok\":false") || raw.contains("\"ok\": false")
            val msg = Regex("\"message\"\\s*:\\s*\"([^\"]*)\"").find(raw)?.groupValues?.getOrNull(1)
                ?: raw.take(120)
            ExecutionReceipt(isSuccess = ok, isError = err && !ok, message = msg)
        } catch (e: Exception) {
            ExecutionReceipt(false, true, "解析失败: ${e.message}")
        }
    }

    private fun jsonStr(s: String): String =
        "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n") + "\""

    /** 核心识别与点击逻辑（评分选真按钮） */
    private val CORE_JS: String = """
function __cfxNorm(s){ return (s||'').replace(/\s+/g,'').trim(); }
function __cfxVisible(el){
  if(!el||el.disabled) return false;
  var st=window.getComputedStyle(el);
  if(st.display==='none'||st.visibility==='hidden'||parseFloat(st.opacity||'1')===0) return false;
  var r=el.getBoundingClientRect();
  return r.width>8&&r.height>8&&r.bottom>0&&r.top<innerHeight&&r.right>0&&r.left<innerWidth;
}
function __cfxBlob(el){
  var bits=[el.className&&String(el.className), el.id,
    el.getAttribute('data-type'), el.getAttribute('data-play'),
    el.getAttribute('data-name'), el.getAttribute('data-value'),
    el.getAttribute('aria-label'), el.name, el.getAttribute('title')];
  return bits.filter(Boolean).join(' ').toLowerCase();
}
function __cfxPath(el){
  var s='', cur=el, d=0;
  while(cur&&d<6){ s+=' '+__cfxBlob(cur); cur=cur.parentElement; d++; }
  return s.toLowerCase();
}
function __cfxOwnText(el){
  // 只取自身文本节点，避免把整块区域文字拼进来乱匹配
  var t='';
  for(var i=0;i<el.childNodes.length;i++){
    var n=el.childNodes[i];
    if(n.nodeType===3) t+=n.nodeValue||'';
  }
  var own=__cfxNorm(t);
  if(own) return own;
  if(el.tagName&&el.tagName.toLowerCase()==='input') return __cfxNorm(el.value||el.getAttribute('value')||'');
  // 无子元素时才用 textContent
  if(!el.children||el.children.length===0) return __cfxNorm(el.innerText||el.textContent||'');
  return '';
}
var __CFX_BET_HINTS=['bet','play','wager','order','touzhu','xz','chip','game-bet','betting','handicap','盘口','投注','下注','玩法','赔率','选号'];
var __CFX_NOISE=['history','record','trend','chart','help','rule','notice','news','draw','open','result','statistic','统计','历史','走势','说明','开奖','记录','规则','公告','新闻','教程','客服','关于'];
function __cfxInRegion(el){
  var R=window.__CFX_REGION;
  if(!R||!R.enabled) return true;
  var r=el.getBoundingClientRect();
  var cx=r.left+r.width/2, cy=r.top+r.height/2;
  var L=innerWidth*(R.left||0)/100, T=innerHeight*(R.top||0)/100;
  var Rt=innerWidth*(R.right||100)/100, B=innerHeight*(R.bottom||100)/100;
  return cx>=L&&cx<=Rt&&cy>=T&&cy<=B;
}
function __cfxScore(el, label){
  if(!__cfxVisible(el)) return -1e9;
  if(!__cfxInRegion(el)) return -1e9;
  var own=__cfxOwnText(el);
  var full=__cfxNorm(el.innerText||el.textContent||'');
  // 严格：优先自身文本精确等于 label；禁止长文里夹带单字
  if(own!==label && full!==label){
    // 允许极短文案包含且长度<=2（如「大」「小」）
    if(!(own.indexOf(label)>=0 && own.length<=2)) return -1e9;
  }
  if(full.length>12 && full!==label) return -1e9; // 整块过长且不是精确匹配则丢弃
  if(el.children && el.children.length>6) return -1e9; // 容器级元素不点
  var rect=el.getBoundingClientRect();
  var blob=__cfxPath(el);
  var score=0;
  var tag=(el.tagName||'').toLowerCase();
  if(own===label || full===label) score+=50; // 精确匹配强加成
  if(tag==='button'||tag==='a') score+=40;
  if(el.getAttribute('role')==='button') score+=30;
  if(typeof el.onclick==='function'||el.hasAttribute('ng-click')||el.hasAttribute('@click')||el.hasAttribute('onclick')) score+=25;
  if(tag==='input'&&/button|submit/.test(el.type||'')) score+=35;
  if(tag==='div'||tag==='span'||tag==='li'||tag==='label'||tag==='p'||tag==='i'||tag==='em') score+=5;
  for(var i=0;i<__CFX_BET_HINTS.length;i++){ if(blob.indexOf(__CFX_BET_HINTS[i])>=0) score+=28; }
  for(var j=0;j<__CFX_NOISE.length;j++){ if(blob.indexOf(__CFX_NOISE[j])>=0) score-=80; }
  var area=rect.width*rect.height;
  if(rect.width>=24&&rect.width<=200&&rect.height>=22&&rect.height<=90) score+=30;
  if(area<180||area>60000) score-=30;
  // 投注区通常在中下半屏，顶栏/导航不点
  var cy=rect.top+rect.height/2;
  if(cy>innerHeight*0.18&&cy<innerHeight*0.92) score+=15;
  if(cy<innerHeight*0.12) score-=40;
  if(cy>innerHeight*0.96) score-=20;
  // 兄弟区同时出现大小或单双，说明是盘口按钮
  var parent=el.parentElement;
  if(parent){
    var sib=__cfxNorm(parent.innerText||'');
    if(sib.length<=20){
      if((label==='大'||label==='小')&&sib.indexOf('大')>=0&&sib.indexOf('小')>=0) score+=35;
      if((label==='单'||label==='双')&&sib.indexOf('单')>=0&&sib.indexOf('双')>=0) score+=35;
    } else {
      // 父级文字太长，降低可信度
      score-=15;
    }
  }
  if(/active|selected|on|checked|current|choose/.test(blob)) score+=8;
  return score;
}
function __cfxFindBest(label){
  // label 已是页面真实文字（如「总和大」），只匹配该文案 + 区域
  var nodes=document.querySelectorAll('button,a,[role=button],input[type=button],input[type=submit],label,li,span,div,p,i,em');
  var best=null, bestScore=50;
  var want=__cfxNorm(label);
  for(var i=0;i<nodes.length;i++){
    var el=nodes[i];
    if(el.closest && el.closest('header,nav,footer,aside')) continue;
    if(!__cfxInRegion(el)) continue;
    var own=__cfxOwnText(el);
    var full=__cfxNorm(el.innerText||el.textContent||'');
    // 用户指定了完整玩法名时：必须精确相等或自身文本相等
    if(want.length>=2){
      if(own!==want && full!==want) continue;
      // 精确命中直接高分
      var sc=__cfxScore(el, want);
      if(own===want||full===want) sc+=40;
      if(sc>bestScore){ bestScore=sc; best=el; }
      continue;
    }
    var sc2=__cfxScore(el, want);
    if(sc2>bestScore){ bestScore=sc2; best=el; }
  }
  return best?{el:best,score:bestScore}:null;
}
function __cfxHighlight(el, ok){
  if(!el) return;
  var prev=el.style.outline;
  el.style.outline=ok?'3px solid #00c853':'3px solid #ff1744';
  setTimeout(function(){ el.style.outline=prev; }, 1200);
}
function __cfxClick(el){
  el.scrollIntoView({block:'center',inline:'center'});
  var o={bubbles:true,cancelable:true,view:window};
  el.dispatchEvent(new MouseEvent('mouseover',o));
  el.dispatchEvent(new MouseEvent('mousedown',o));
  el.dispatchEvent(new MouseEvent('mouseup',o));
  el.dispatchEvent(new MouseEvent('click',o));
  if(typeof el.click==='function') el.click();
}
function __cfxSleep(ms){
  var t0=Date.now();
  while(Date.now()-t0<ms){ /* 短等待给弹窗渲染 */ }
}
function __cfxFindConfirm(){
  // 主确认 + 二次验证常见文案
  var texts=['确认投注','立即下注','马上投注','确认下注','提交订单','立即投注','确认','确定','提交','下注','是的','同意','继续','我知道了','知道了','OK','Ok','ok','YES','Yes','验证通过','二次确认'];
  var nodes=document.querySelectorAll('button,a,[role=button],input[type=button],input[type=submit],div,span');
  var best=null, bestScore=25;
  for(var i=0;i<nodes.length;i++){
    var el=nodes[i];
    if(!__cfxVisible(el)) continue;
    // 确认弹窗可在全屏，不强制区域
    var text=__cfxNorm(el.innerText||el.value||el.getAttribute('aria-label')||'');
    if(!text||text.length>16) continue;
    var hit=-1;
    for(var t=0;t<texts.length;t++){
      if(text===texts[t]||text.indexOf(texts[t])>=0){ hit=t; break; }
    }
    if(hit<0) continue;
    var sc=40-Math.min(hit,15); // 越靠前的文案优先级越高
    var blob=__cfxPath(el);
    for(var h=0;h<__CFX_BET_HINTS.length;h++) if(blob.indexOf(__CFX_BET_HINTS[h])>=0) sc+=15;
    for(var n=0;n<__CFX_NOISE.length;n++) if(blob.indexOf(__CFX_NOISE[n])>=0) sc-=50;
    // 弹层内的按钮加分
    if(el.closest && (el.closest('.modal')||el.closest('[class*=dialog]')||el.closest('[class*=popup]')||el.closest('[class*=mask]')||el.closest('[class*=confirm]'))) sc+=25;
    var r=el.getBoundingClientRect();
    if(r.width>=48&&r.height>=28) sc+=12;
    if(sc>bestScore){ bestScore=sc; best=el; }
  }
  return best;
}
function __cfxInputAmount(amount){
  if(!amount) return {ok:true,message:'无金额'};
  var inputs=document.querySelectorAll('input[type=text],input[type=number],input:not([type]),textarea');
  var target=null, bestSc=-1;
  for(var i=0;i<inputs.length;i++){
    var el=inputs[i];
    if(!__cfxVisible(el)) continue;
    var blob=(__cfxPath(el)+' '+(el.placeholder||'')+' '+(el.name||'')).toLowerCase();
    var sc=0;
    if(/金额|额度|amount|money|bet|投注|下注|元/.test(blob)) sc+=30;
    if(/search|user|pass|账号|密码|手机/.test(blob)) sc-=50;
    if(__cfxInRegion(el)) sc+=10;
    if(sc>bestSc){ bestSc=sc; target=el; }
  }
  if(!target||bestSc<0){
    var chip=__cfxFindBest(String(amount));
    if(chip){ __cfxHighlight(chip.el,true); __cfxClick(chip.el); return {ok:true,message:'点筹码'+amount}; }
    return {ok:false,message:'未找到金额框'};
  }
  target.focus();
  target.value='';
  target.value=String(amount);
  try{ target.dispatchEvent(new InputEvent('input',{bubbles:true,data:String(amount)})); }catch(e){ target.dispatchEvent(new Event('input',{bubbles:true})); }
  target.dispatchEvent(new Event('change',{bubbles:true}));
  target.dispatchEvent(new Event('blur',{bubbles:true}));
  return {ok:true,message:'已填金额'+amount};
}
/** 多轮确认：主确认 + 验证弹窗继续点 */
function __cfxConfirmLoop(dryRun, maxRound){
  var rounds=[];
  maxRound = maxRound||4;
  for(var r=0;r<maxRound;r++){
    var conf=__cfxFindConfirm();
    if(!conf){
      rounds.push({round:r+1,ok:false,detail:'无确认钮'});
      break;
    }
    var txt=__cfxNorm(conf.innerText||conf.value||'');
    __cfxHighlight(conf,true);
    if(!dryRun) __cfxClick(conf);
    rounds.push({round:r+1,ok:true,text:txt});
    __cfxSleep(350);
  }
  return rounds;
}
window.__caiFenXiRunCommand=function(CMD){
  var steps=[];
  try{
    window.__CFX_REGION = CMD.region || {enabled:false};
    if(!CMD||!CMD.bets||!CMD.bets.length){
      return {ok:false,message:'指令无注项',steps:steps};
    }
    // ===== 1) 点击玩法（总和大/小/单/双等）=====
    for(var i=0;i<CMD.bets.length;i++){
      var bet=CMD.bets[i];
      var logical=bet.value||'';
      var label=bet.pageText|| (CMD.labelMap&&CMD.labelMap[logical]) || logical;
      if(!label) continue;
      var hit=__cfxFindBest(label);
      if(!hit){
        steps.push({step:'play:'+logical+'→'+label,ok:false});
        return {ok:false,message:'未找到玩法【'+label+'】',steps:steps};
      }
      __cfxHighlight(hit.el,true);
      if(!CMD.dryRun) __cfxClick(hit.el);
      steps.push({step:'play:'+logical+'→'+label,ok:true,score:hit.score});
      __cfxSleep(280);
    }
    // ===== 2) 输入金额 =====
    var amt=__cfxInputAmount(CMD.amount);
    steps.push({step:'amount',ok:!!amt.ok,detail:amt.message});
    if(!amt.ok) return {ok:false,message:amt.message,steps:steps};
    __cfxSleep(280);
    // ===== 3) 确定 + 4) 若有验证弹窗继续确认 =====
    var confirms=__cfxConfirmLoop(!!CMD.dryRun, 4);
    steps.push({step:'confirm',ok:confirms.some(function(x){return x.ok;}),rounds:confirms});
    var anyConfirm=confirms.some(function(x){return x.ok;});
    if(!anyConfirm){
      return {ok:false,message:'未找到确认/验证按钮',steps:steps};
    }
    return {
      ok:true,
      message:'完成:玩法→金额→确认'+(confirms.length>1?('×'+confirms.filter(function(x){return x.ok;}).length):''),
      steps:steps
    };
  }catch(err){
    return {ok:false,message:String(err&&err.message||err),steps:steps};
  }
};
""".trimIndent()
}
