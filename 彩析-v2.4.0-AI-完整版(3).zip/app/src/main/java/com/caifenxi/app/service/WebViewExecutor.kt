package com.caifenxi.app.service

import android.webkit.WebView
import com.caifenxi.app.domain.execution.BetCommand
import com.caifenxi.app.domain.execution.ExecutionResult
import com.caifenxi.app.domain.execution.Executor
import com.caifenxi.app.util.RuntimeLog

/**
 * WebView 统一执行器（接入 ExecutorManager）。
 * UI 在 WebBetScreen 挂载 WebView 后调用 [attach]；detach 后回落到无障碍。
 */
object WebViewExecutor : Executor {

    override val id: String = "webview"

    @Volatile
    private var executor: WebViewBetExecutor? = null

    @Volatile
    override var isAvailable: Boolean = false
        private set

    /** App 启动时绑定与调度器同一实例，避免 UI attach 与调度器各用各的 WebView */
    fun bindShared(ex: WebViewBetExecutor) {
        executor = ex
        isAvailable = ex.isAvailable
    }

    fun attach(webView: WebView) {
        val ex = executor ?: WebViewBetExecutor().also { executor = it }
        ex.initWebView(webView)
        isAvailable = true
        RuntimeLog.info("Execution", "WebView 执行器已就绪")
    }

    fun detach() {
        try {
            executor?.clearWebView()
        } catch (_: Exception) {
        }
        executor = null
        isAvailable = false
        RuntimeLog.info("Execution", "WebView 执行器已断开")
    }

    /** 供调度器复用同一实例时挂载 */
    fun bindExecutor(ex: WebViewBetExecutor) {
        executor = ex
        isAvailable = ex.isAvailable
    }

    override fun execute(command: BetCommand, onResult: (ExecutionResult) -> Unit): Boolean {
        val ex = executor
        if (ex == null || !ex.isAvailable) {
            RuntimeLog.warn("Execution", "WebView 未注入，cmdId=${command.cmdId}")
            onResult(
                ExecutionResult.fail(
                    command.cmdId,
                    ExecutionResult.WEBVIEW_DISCONNECTED,
                    "WebView 未连接，请打开「更多 → 内置网页执行」并登录投注站"
                )
            )
            return false
        }
        RuntimeLog.info(
            "Execution",
            "WebView 受理 cmdId=${command.cmdId} 彩种=${command.lotteryKey} 期号=${command.issue} stage=${command.stage} leg=${command.leg}"
        )
        return ex.execute(command, onResult)
    }

    override fun cancel(cmdId: String) {
        RuntimeLog.info("Execution", "WebView 取消 cmdId=$cmdId")
    }

    override fun queryState(cmdId: String): ExecutionResult? = null
}
