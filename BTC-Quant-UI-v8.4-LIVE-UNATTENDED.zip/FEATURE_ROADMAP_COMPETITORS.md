# 竞品功能对照与路线图（BTC Quant UI）

调研来源：OKZ Quant、AlphaFox、QuantDinger、Otrading、CoinQuant、币安模拟盘/策略工具、聪明钱跟单等（2025–2026）。

## 已落地（本轮）
- [x] 策略池点击崩溃修复（ThreeWayBar weight(0)、Slider NaN、卡片展开）
- [x] K 线空数据兜底：自动/手动 Demo，看板明确 LIVE/DEMO
- [x] 策略池使用说明卡片

## 竞品高频能力 → 建议优先级

### P0（实盘前必须）
| 竞品常见能力 | 我们状态 | 动作 |
|---|---|---|
| Paper / Live 强隔离 + 安全开关 | 部分文案有，模式弱 | 统一交易 Tab 顶部 SIM/LIVE 切换 + 二次确认 |
| 市价开仓 + 止损止盈条件单 | 信号有 SL/TP，下单未强制挂 | BinanceFuturesBroker 下单后挂 STOP/TP |
| 持仓/订单轮询对账 | 有 positionRisk，未产品化 | 交易页持仓卡片 3s 刷新 |
| 日损熔断 / 最大杠杆 | 日级控制偏二元期权 | 合约侧 DailyRiskGate |
| K 线稳定可见 | 本轮已加强 Demo | 代理设置 + 本地缓存 |

### P1（体验与留存）
| 能力 | 参考 | 动作 |
|---|---|---|
| 权益曲线 + 回撤 | OKZ / Backtest App | 回测与模拟共用 EquityChart |
| 策略说明 / 人话解读 | quantify 决策台 | 每个 planId 固定「逻辑一句话」 |
| 恐惧贪婪 / 情绪条 | Otrading | 用新闻净情绪映射 0–100 条 |
| 多账户 Demo/Testnet/Mainnet | OKZ | 设置页 Endpoint 三选一 |
| 订单日志可导出 | 多数专业端 | CSV 导出已有部分，补合约日志 |

### P2（差异化）
| 能力 | 参考 | 动作 |
|---|---|---|
| 网格 / DCA 机器人模板 | 币安策略、Otrading | 独立「机器人」实验室，勿混主路径 |
| AI 自然语言策略 | CoinQuant / QuantPilot | 仅生成参数建议，不直接实盘 |
| 跟单/策略排行 | 币安聪明钱、AlphaFox | 需后端，暂不做 |
| Pine Script | Otrading | 工作量大，不做 |

## 产品主路径（对齐竞品成功路径）
看 K 线 → 看策略共识 → 模拟验证 →（可选）小资金实盘

禁止：未经验证的自动全仓、伪装成可用的半截入口。
