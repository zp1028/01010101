package com.caifenxi.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.broker.BinanceFuturesEndpoint
import com.caifenxi.app.domain.btc.broker.BrokerCredentials
import com.caifenxi.app.domain.btc.runtime.BtcRunMode
import com.caifenxi.app.domain.btc.runtime.BtcRuntimeStatus
import com.caifenxi.app.ui.BtcQuantViewModel
import com.caifenxi.app.ui.components.SectionTitle
import com.caifenxi.app.ui.theme.CaiTokens
import kotlinx.coroutines.delay

/**
 * 交易 Tab：周期涨跌预测交易 + 账户配置 + 运行时控制
 */
@Composable
fun TradeTab(viewModel: BtcQuantViewModel) {
    val state by viewModel.state.collectAsState()
    val creds by viewModel.credentials.collectAsState()
    val tradeMode by viewModel.tradeMode.collectAsState()
    val livePos by viewModel.livePosition.collectAsState()
    val ticket by viewModel.lastTradeTicket.collectAsState()
    val busy by viewModel.tradeBusy.collectAsState()
    val risk by viewModel.tradeRisk.collectAsState()

    // 持仓轻量轮询
    LaunchedEffect(tradeMode, state.symbol) {
        while (true) {
            viewModel.refreshLivePosition(state.symbol)
            kotlinx.coroutines.delay(3000)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
    ) {
        TradeModeBar(
            mode = tradeMode,
            dayPnl = viewModel.realizedPnlToday(),
            onMode = { viewModel.setTradeMode(it) },
            onResetDay = { viewModel.resetDailyPnl() }
        )
        PositionCard(livePos, busy) { viewModel.closeLivePosition() }
        PredictionTradePanel(viewModel, state, tradeMode, risk, busy, ticket)
        AccountConfigPanel(viewModel, creds)
        RuntimePanel(viewModel, state)
        Spacer(Modifier.height(40.dp))
    }
}

@Composable
private fun TradeModeBar(
    mode: BtcQuantViewModel.TradeExecMode,
    dayPnl: Double,
    onMode: (BtcQuantViewModel.TradeExecMode) -> Unit,
    onResetDay: () -> Unit
) {
    Card(
        Modifier.padding(horizontal = 24.dp, vertical = 8.dp).fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (mode == BtcQuantViewModel.TradeExecMode.LIVE)
                MaterialTheme.colorScheme.errorContainer
            else MaterialTheme.colorScheme.secondaryContainer
        )
    ) {
        Column(Modifier.padding(14.dp)) {
            Text("交易模式", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = mode == BtcQuantViewModel.TradeExecMode.SIM,
                    onClick = { onMode(BtcQuantViewModel.TradeExecMode.SIM) },
                    label = { Text("SIM 模拟") }
                )
                FilterChip(
                    selected = mode == BtcQuantViewModel.TradeExecMode.LIVE,
                    onClick = { onMode(BtcQuantViewModel.TradeExecMode.LIVE) },
                    label = { Text("LIVE 实盘") }
                )
            }
            Text(
                if (mode == BtcQuantViewModel.TradeExecMode.SIM)
                    "默认模拟：本地撮合，不触及交易所。"
                else
                    "⚠ LIVE：将向配置的 Binance 端点提交真实订单（含测试网/主网）。下单需二次确认。",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "今日已实现 PnL: ${"%.2f".format(dayPnl)} USDT（持久化，跨重启）",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
                TextButton(onClick = onResetDay) { Text("清零日统计", fontSize = 11.sp) }
            }
        }
    }
}

@Composable
private fun PositionCard(
    pos: BtcQuantViewModel.LivePositionUi?,
    busy: Boolean,
    onClose: () -> Unit
) {
    Card(
        Modifier.padding(horizontal = 24.dp, vertical = 4.dp).fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            SectionTitleInline("当前持仓（约 3s 刷新）")
            if (pos == null) {
                Text("无持仓", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                val side = if (pos.positionAmt > 0) "LONG" else "SHORT"
                MetricLine("方向", side)
                MetricLine("数量", "%.4f".format(kotlin.math.abs(pos.positionAmt)))
                MetricLine("开仓价", "%.2f".format(pos.entryPrice))
                MetricLine("标记价", "%.2f".format(pos.markPrice))
                MetricLine("未实现盈亏", "%.2f USDT".format(pos.unrealizedPnl))
                MetricLine("杠杆", "${pos.leverage}x · ${pos.marginType}")
                Button(onClick = onClose, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                    Text("市价平仓")
                }
            }
        }
    }
}

// ==================== 周期涨跌预测交易 ====================

@Composable
private fun PredictionTradePanel(
    viewModel: BtcQuantViewModel,
    state: com.caifenxi.app.domain.btc.BtcDashboardState,
    tradeMode: BtcQuantViewModel.TradeExecMode,
    risk: BtcQuantViewModel.TradeRiskLimits,
    busy: Boolean,
    ticket: BtcQuantViewModel.TradeTicketResult?
) {
    val consensus = state.consensus
    var positionSize by remember { mutableStateOf("0.001") }
    var leverageCap by remember { mutableStateOf(3) }
    var showLiveConfirm by remember { mutableStateOf(false) }
    val pos = positionSize.toDoubleOrNull() ?: 0.0
    val signal = remember(consensus, state.candles, state.plans, pos) {
        viewModel.buildPerpSignalPreview(if (pos > 0) pos else 0.001)
    }

    if (showLiveConfirm && signal != null) {
        AlertDialog(
            onDismissRequest = { showLiveConfirm = false },
            title = { Text("确认 LIVE 下单") },
            text = {
                Text(
                    "将向交易所提交：${signal.direction.name} ${pos} BTC\n" +
                        "入场≈${"%.2f".format(signal.entry)} SL=${"%.2f".format(signal.stopLoss)} TP=${"%.2f".format(signal.takeProfit)}\n" +
                        "杠杆 ${leverageCap}x · 名义≈${"%.2f".format(pos * signal.entry)} USDT\n" +
                        "请确认 API 权限与资金风险。"
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showLiveConfirm = false
                    viewModel.placePerpWithBracket(pos, leverageCap, confirmLive = true)
                }) { Text("确认下单") }
            },
            dismissButton = {
                TextButton(onClick = { showLiveConfirm = false }) { Text("取消") }
            }
        )
    }

    Card(
        Modifier.padding(horizontal = 24.dp, vertical = 8.dp).fillMaxWidth(),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SectionTitleInline("周期涨跌预测交易")
            Text(
                "风控：杠杆≤${risk.maxLeverage}x · 名义≤${risk.maxNotionalUsdt} · 日损熔断 ${risk.maxDailyLossUsdt} USDT",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (consensus == null || signal == null) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Text(
                        "暂无预测信号 · 需要共识方向非 FLAT（可先到看板刷新/Demo）",
                        modifier = Modifier.padding(16.dp),
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                return@Card
            }

            // === 信号概览 ===
            val dirColor = when (signal.direction) {
                BtcDirection.UP -> CaiTokens.Success
                BtcDirection.DOWN -> CaiTokens.Danger
                BtcDirection.FLAT -> CaiTokens.Warning
            }

            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 方向标签
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = dirColor.copy(alpha = 0.15f)
                ) {
                    Text(
                        if (signal.direction == BtcDirection.UP) "看涨 LONG" else "看跌 SHORT",
                        color = dirColor,
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        "概率 %.0f%% \u00b7 置信 %.0f%%".format(
                            signal.probability * 100,
                            signal.confidence * 100
                        ),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        "预期波动 %.2f%% \u00b7 ${signal.horizonBars} K线".format(signal.expectedMovePct),
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // === Entry / SL / TP ===
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            ) {
                Column(Modifier.padding(12.dp)) {
                    // Entry
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("入场价", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("%.2f".format(signal.entry), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(6.dp))

                    // 止损
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("止损 (SL)", fontSize = 12.sp, color = CaiTokens.Danger)
                        Text("%.2f".format(signal.stopLoss), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = CaiTokens.Danger)
                    }
                    val slDist = ((signal.entry - signal.stopLoss) / signal.entry * 100)
                    Text(
                        "距 SL: %.2f%%".format(kotlin.math.abs(slDist)),
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(Modifier.height(6.dp))

                    // 止盈
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("止盈 (TP)", fontSize = 12.sp, color = CaiTokens.Success)
                        Text("%.2f".format(signal.takeProfit), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = CaiTokens.Success)
                    }
                    val tpDist = ((signal.takeProfit - signal.entry) / signal.entry * 100)
                    Text(
                        "距 TP: %.2f%% \u00b7 盈亏比 %.1f:1".format(
                            kotlin.math.abs(tpDist),
                            kotlin.math.abs(tpDist / slDist)
                        ),
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // === 仓位和杠杆配置 ===
            Text("交易参数", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)

            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = positionSize,
                    onValueChange = { positionSize = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("仓位 (BTC)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("杠杆上限 ${leverageCap}x", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row {
                        listOf(1, 3, 5, 10).forEach { lev ->
                            FilterChip(
                                selected = leverageCap == lev,
                                onClick = { leverageCap = lev },
                                label = { Text("${lev}x", fontSize = 10.sp) }
                            )
                            Spacer(Modifier.width(4.dp))
                        }
                    }
                }
            }

            // 风险计算
            val pos = positionSize.toDoubleOrNull() ?: 0.0
            val notional = pos * signal.entry
            val slDistPct = kotlin.math.abs((signal.entry - signal.stopLoss) / signal.entry * 100)
            val tpDistPct = kotlin.math.abs((signal.takeProfit - signal.entry) / signal.entry * 100)
            val slRisk = notional * slDistPct / 100
            val tpReward = notional * tpDistPct / 100
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
            ) {
                Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("名义价值", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("%.2f USDT".format(notional), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("最大亏损", fontSize = 10.sp, color = CaiTokens.Danger)
                        Text("%.2f".format(slRisk), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = CaiTokens.Danger)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("最大盈利", fontSize = 10.sp, color = CaiTokens.Success)
                        Text("%.2f".format(tpReward), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = CaiTokens.Success)
                    }
                }
            }

            // === 信号来源 ===
            if (signal.reasonPlanIds.isNotEmpty()) {
                Spacer(Modifier.height(2.dp))
                Text("信号来源", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Text(
                    signal.reasonPlanIds.joinToString(" \u00b7 "),
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // === 下单按钮：SIM 直接下；LIVE 弹确认 ===
            Spacer(Modifier.height(4.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        if (tradeMode == BtcQuantViewModel.TradeExecMode.LIVE) {
                            showLiveConfirm = true
                        } else {
                            viewModel.placePerpWithBracket(pos, leverageCap, confirmLive = false)
                        }
                    },
                    enabled = !busy && pos > 0 && consensus.direction != BtcDirection.FLAT,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(if (busy) "提交中…" else if (tradeMode == BtcQuantViewModel.TradeExecMode.SIM) "模拟开仓+SL/TP" else "LIVE 开仓+SL/TP")
                }
                OutlinedButton(
                    onClick = { viewModel.runMultiEngineTickWithKeys(paperPerp = true) },
                    enabled = !busy && pos > 0,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("多引擎纸面一轮")
                }
            }

            ticket?.let { t ->
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (t.ok) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                    else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.45f)
                ) {
                    Text(
                        t.message,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            // 黑天鹅警告
            if (state.newsBlackSwan) {
                Spacer(Modifier.height(4.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.errorContainer
                ) {
                    Text(
                        "\u26a0 当前新闻黑天鹅标记 \u2014 建议停止交易",
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }
        }
    }
}

// ==================== 账户配置 ====================

@Composable
private fun AccountConfigPanel(viewModel: BtcQuantViewModel, creds: BrokerCredentials) {
    var key by remember(creds.binanceApiKey) { mutableStateOf(creds.binanceApiKey) }
    var secret by remember(creds.binanceSecret) { mutableStateOf(creds.binanceSecret) }
    var endpoint by remember(creds.binanceEndpoint) { mutableStateOf(creds.binanceEndpoint) }
    var polyDry by remember(creds.polymarketDryRun) { mutableStateOf(creds.polymarketDryRun) }
    var saved by remember { mutableStateOf(false) }

    Card(
        Modifier.padding(horizontal = 24.dp, vertical = 8.dp).fillMaxWidth(),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SectionTitleInline("交易账户配置（API Key）")
            Text(
                "密钥仅存本机，禁止写进安装包。建议 DEMO/TESTNET 先测通。",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            OutlinedTextField(
                value = key,
                onValueChange = { key = it; saved = false },
                label = { Text("币安 API Key") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = secret,
                onValueChange = { secret = it; saved = false },
                label = { Text("币安 Secret") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth()
            )
            Text("环境", fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                BinanceFuturesEndpoint.entries.forEach { ep ->
                    FilterChip(
                        selected = endpoint == ep,
                        onClick = { endpoint = ep; saved = false },
                        label = { Text(ep.label) }
                    )
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = polyDry, onCheckedChange = { polyDry = it; saved = false })
                Text("Polymarket dry-run", fontSize = 12.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    viewModel.saveBrokerCredentials(
                        BrokerCredentials(
                            binanceApiKey = key.trim(),
                            binanceSecret = secret.trim(),
                            binanceEndpoint = endpoint,
                            polymarketDryRun = polyDry
                        )
                    )
                    saved = true
                }) { Text("保存密钥") }
                OutlinedButton(onClick = { viewModel.testBinanceConnectivity() }) { Text("测试连通") }
                OutlinedButton(onClick = { viewModel.refreshExchangeFilters() }) { Text("同步精度") }
            }
            if (saved) {
                Text("已保存", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp)
            }
        }
    }
}

// ==================== 运行时控制 ====================

@Composable
private fun RuntimePanel(viewModel: BtcQuantViewModel, state: com.caifenxi.app.domain.btc.BtcDashboardState) {
    val runtime by viewModel.runtimeState.collectAsState()
    val cfg by viewModel.runtimeConfig.collectAsState()
    val running = runtime.status == BtcRuntimeStatus.RUNNING
    val killed = runtime.killSwitch

    LaunchedEffect(runtime.status) {
        viewModel.refreshRuntimeState()
    }

    Card(
        Modifier.padding(horizontal = 24.dp, vertical = 8.dp).fillMaxWidth(),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("挂机运行控制", fontWeight = FontWeight.Bold)
                    Text(
                        "${cfg.runMode.name} \u00b7 ${cfg.symbol} ${cfg.timeframe}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                AssistChip(
                    onClick = {},
                    label = { Text(runtime.status.name) },
                    leadingIcon = {
                        Icon(
                            if (killed) Icons.Filled.Warning
                            else if (running) Icons.Filled.PlayArrow
                            else Icons.Filled.Pause,
                            null
                        )
                    }
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "心跳 ${fmtTime(runtime.lastHeartbeatAt)} \u00b7 已处理 ${runtime.processedBars} 根 \u00b7 末向 ${runtime.lastSignal?.name ?: "\u2014"}",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            MetricLine("运行时 Funding", runtime.lastFundingRate?.let { "%.6f".format(it) } ?: "\u2014")
            MetricLine("运行时 OI\u0394%", runtime.lastOiChangePct?.let { "%.2f".format(it) } ?: "\u2014")
            MetricLine("运行时衍分", runtime.lastDerivScore?.let { "%.2f".format(it) } ?: "\u2014")
            runtime.lastError?.let {
                Text(it, color = MaterialTheme.colorScheme.error, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
            }
            if (state.newsBlackSwan) {
                Text("当前新闻黑天鹅标记：建议保持停止/全停", color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
            }
            Spacer(Modifier.height(10.dp))
            Text(
                "风控: 杠杆≤${cfg.maxLeverage}x · 名义≤${cfg.maxNotionalUsdt}U · 日损≤${cfg.maxDailyLossUsdt}U · LIVE授权=${cfg.liveAutoAuthorized}",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                "连续失败 ${runtime.consecutiveErrors} · 今日PnL ${"%.2f".format(viewModel.realizedPnlToday())}U",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            var confirmText by remember { mutableStateOf("") }
            var authMsg by remember { mutableStateOf<String?>(null) }
            OutlinedTextField(
                value = confirmText,
                onValueChange = { confirmText = it },
                label = { Text("LIVE 授权确认语") },
                placeholder = { Text(BtcQuantViewModel.LIVE_AUTO_CONFIRM_PHRASE) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    authMsg = viewModel.authorizeLiveUnattended(confirmText, authorize = true)
                }) { Text("授权真钱自动") }
                TextButton(onClick = {
                    authMsg = viewModel.authorizeLiveUnattended("", authorize = false)
                    confirmText = ""
                }) { Text("撤销授权") }
            }
            authMsg?.let {
                Text(it, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
            }
            Text(
                "真钱无人值守有爆仓与亏损风险。请先 PAPER/TESTNET。仅使用可承受损失的资金。",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.error
            )
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = !running && !killed, onClick = {
                    viewModel.setRuntimeEnabled(true, BtcRunMode.PAPER)
                }) { Text("启动模拟") }
                Button(
                    enabled = !running && !killed && cfg.liveAutoAuthorized,
                    onClick = { viewModel.setRuntimeEnabled(true, BtcRunMode.LIVE) },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text("启动LIVE") }
                OutlinedButton(enabled = running, onClick = {
                    viewModel.setRuntimeEnabled(false)
                }) { Text("停止") }
                OutlinedButton(enabled = !killed, onClick = { viewModel.killRuntime() }) { Text("全停") }
                if (killed) OutlinedButton(onClick = { viewModel.resumeRuntime() }) { Text("解除") }
            }
        }
    }
}
