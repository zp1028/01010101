package com.caifenxi.app.domain.btc.broker

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 按自然日持久化已实现盈亏，用于日损熔断（跨进程重启仍有效）。
 */
class DailyPnlStore(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("btc_daily_pnl", Context.MODE_PRIVATE)
    private val dayFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    private fun today(): String = dayFmt.format(Date())

    fun realizedPnlToday(): Double {
        val d = today()
        val storedDay = sp.getString("day", "") ?: ""
        if (storedDay != d) return 0.0
        return Double.fromBits(sp.getLong("pnl_bits", 0.0.toBits()))
    }

    fun addRealized(delta: Double) {
        val d = today()
        val storedDay = sp.getString("day", "") ?: ""
        val current = if (storedDay == d) realizedPnlToday() else 0.0
        val next = current + delta
        sp.edit()
            .putString("day", d)
            .putLong("pnl_bits", next.toBits())
            .apply()
    }

    fun resetToday() {
        sp.edit()
            .putString("day", today())
            .putLong("pnl_bits", 0.0.toBits())
            .apply()
    }
}
