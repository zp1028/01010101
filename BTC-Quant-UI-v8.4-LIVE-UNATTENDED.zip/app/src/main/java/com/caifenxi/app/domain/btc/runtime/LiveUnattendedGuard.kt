package com.caifenxi.app.domain.btc.runtime

import com.caifenxi.app.domain.btc.BtcConsensus
import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.TradingSignal
import com.caifenxi.app.domain.btc.broker.BrokerCredentials
import com.caifenxi.app.domain.btc.broker.ExchangeFilters

/**
 * LIVE 无人值守多层闸门。任一失败则禁止开仓。
 * 设计原则：默认拒绝；显式授权；小仓位；必挂止损止盈；失败自停。
 */
object LiveUnattendedGuard {

    data class Decision(val allowed: Boolean, val reason: String)

    fun authorizeStart(
        cfg: BtcRuntimeConfig,
        creds: BrokerCredentials,
        state: BtcRuntimeState
    ): Decision {
        if (state.killSwitch) return Decision(false, "全局 Kill Switch 已触发")
        if (!cfg.enabled) return Decision(false, "运行时未启用")
        when (cfg.runMode) {
            BtcRunMode.PAPER -> return Decision(true, "PAPER OK")
            BtcRunMode.TESTNET -> {
                if (creds.binanceApiKey.isBlank() || creds.binanceSecret.isBlank()) {
                    return Decision(false, "TESTNET 需要 API Key")
                }
                return Decision(true, "TESTNET OK")
            }
            BtcRunMode.LIVE -> {
                if (!cfg.liveAutoAuthorized) {
                    return Decision(false, "LIVE 自动未授权：请在交易页完成「真钱无人值守」授权")
                }
                if (creds.binanceApiKey.isBlank() || creds.binanceSecret.isBlank()) {
                    return Decision(false, "LIVE 需要 API Key/Secret")
                }
                // 建议 DEMO 端点试跑；主网也允许但提示在 UI
                return Decision(true, "LIVE authorized · endpoint=${creds.binanceEndpoint.label}")
            }
        }
    }

    fun authorizeOrder(
        cfg: BtcRuntimeConfig,
        state: BtcRuntimeState,
        consensus: BtcConsensus,
        signal: TradingSignal.ContractSignal,
        dayRealizedPnl: Double,
        nowMs: Long = System.currentTimeMillis()
    ): Decision {
        if (state.killSwitch) return Decision(false, "Kill Switch")
        if (state.consecutiveErrors >= cfg.maxConsecutiveErrors) {
            return Decision(false, "连续失败 ${state.consecutiveErrors} 次，已禁止开仓")
        }
        if (dayRealizedPnl <= -cfg.maxDailyLossUsdt) {
            return Decision(false, "日损熔断 ${"%.2f".format(dayRealizedPnl)} / -${cfg.maxDailyLossUsdt}")
        }
        if (consensus.direction == BtcDirection.FLAT) return Decision(false, "共识 FLAT")
        if (consensus.probability < cfg.minProbability) {
            return Decision(false, "概率 ${"%.0f%%".format(consensus.probability * 100)} < 门槛 ${"%.0f%%".format(cfg.minProbability * 100)}")
        }
        if (signal.direction == BtcDirection.FLAT) return Decision(false, "信号 FLAT")
        if (signal.direction != consensus.direction) return Decision(false, "信号与共识方向不一致")

        val qty = ExchangeFilters.roundQty(signal.symbol, signal.positionSize.coerceAtMost(cfg.maxPositionQty))
        if (qty <= 0) return Decision(false, "数量过小")
        val notional = qty * signal.entry
        if (notional > cfg.maxNotionalUsdt) {
            return Decision(false, "名义 ${"%.2f".format(notional)} > 上限 ${cfg.maxNotionalUsdt}")
        }
        if (signal.leverageCap > cfg.maxLeverage) {
            return Decision(false, "杠杆 ${signal.leverageCap}x > 上限 ${cfg.maxLeverage}x")
        }
        if (cfg.requireBracketOrders && (signal.stopLoss <= 0 || signal.takeProfit <= 0)) {
            return Decision(false, "缺少 SL/TP")
        }
        // SL 必须在正确一侧
        if (signal.direction == BtcDirection.UP && signal.stopLoss >= signal.entry) {
            return Decision(false, "多单止损价必须低于入场价")
        }
        if (signal.direction == BtcDirection.DOWN && signal.stopLoss <= signal.entry) {
            return Decision(false, "空单止损价必须高于入场价")
        }
        if (state.lastOrderAt > 0 && nowMs - state.lastOrderAt < cfg.minOrderIntervalSec * 1000L) {
            return Decision(false, "下单冷却中")
        }
        return Decision(true, "OK qty=$qty notional=${"%.2f".format(notional)}")
    }
}
