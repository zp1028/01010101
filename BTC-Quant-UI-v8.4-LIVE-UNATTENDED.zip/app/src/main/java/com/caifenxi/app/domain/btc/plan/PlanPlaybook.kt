package com.caifenxi.app.domain.btc.plan

import com.caifenxi.app.domain.btc.BtcConsensus
import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.BtcPlanSignal
import com.caifenxi.app.domain.btc.TradingSignal

/**
 * 策略「人话」说明与操作方案摘要，供策略池 / 看板展示。
 */
object PlanPlaybook {

    fun describePlan(planId: String): String = when (planId) {
        "BTC-TURTLE", "BTC-STRUCTURE" -> "突破类：价格站上近期通道上沿偏多，跌破下沿偏空；适合趋势行情，震荡易假突破。"
        "BTC-EMA-TREND", "BTC-TREND" -> "均线趋势：短均线在长均线上方且价格沿均线运行时顺势；均线缠绕时降权。"
        "BTC-MACD", "BTC-MOMENTUM" -> "动量：MACD 柱由负转正/金叉偏多，死叉偏空；适合动能延续，不适合极端超买超卖硬扛。"
        "BTC-MTF-PULLBACK" -> "多周期回踩：大级别趋势向上时，小级别回踩均线/结构低点寻找多单；反之做空。"
        "BTC-RSI-RANGE", "BTC-MOMENTUM-RSI" -> "均值回归：RSI 超卖区偏多、超买区偏空；只在震荡市提高权重，单边市慎用。"
        "BTC-BB-ATR", "BTC-VOLATILITY" -> "波动突破：布林收窄后打开 + ATR 放大，顺突破方向；假突破需严格止损。"
        "BTC-VWAP-VOLUME", "BTC-VOLUME" -> "量价：放量站上 VWAP 偏多，放量跌破偏空；无量推动时信号降权。"
        "BTC-FUNDING-FADE", "BTC-DERIVATIVES" -> "资金费率拥挤：费率极高时倾向做空拥挤多头，极低时倾向做多；需结合价格结构。"
        "BTC-AI-ASSISTED", "BTC-AI" -> "AI 辅助：综合新闻与计划池输出方向建议；默认不直接驱动实盘。"
        else -> "综合技术计划：结合趋势/动量/结构评分给出方向权重，仅作研究参考。"
    }

    fun actionPlan(
        consensus: BtcConsensus?,
        signal: TradingSignal.ContractSignal?,
        topPlans: List<BtcPlanSignal>
    ): String {
        if (consensus == null) return "暂无共识。请先在看板刷新行情或加载 Demo。"
        val dir = consensus.direction
        val header = when (dir) {
            BtcDirection.UP -> "方案倾向：偏多（做多/看涨）"
            BtcDirection.DOWN -> "方案倾向：偏空（做空/看跌）"
            BtcDirection.FLAT -> "方案倾向：观望（震荡/信号不足）"
        }
        val prob = "共识概率约 ${"%.0f%%".format(consensus.probability * 100)}，强度 ${"%.0f%%".format(consensus.consensusStrength * 100)}。"
        val levels = if (signal != null && dir != BtcDirection.FLAT) {
            "参考入场 ${"%.2f".format(signal.entry)} · 止损 ${"%.2f".format(signal.stopLoss)} · 止盈 ${"%.2f".format(signal.takeProfit)}。"
        } else {
            "当前无有效开仓价位（FLAT 或信号未生成）。"
        }
        val tops = topPlans.take(3).joinToString("；") {
            "${it.name}(${it.direction.name}, 贡献 ${"%.2f".format(it.contribution)})"
        }.ifBlank { "无启用计划贡献" }
        val risk = "风险提示：仅供研究/模拟；实盘需 SIM 验证与严格仓位控制。"
        return listOf(header, prob, levels, "主导计划：$tops", risk).joinToString("\n")
    }
}
