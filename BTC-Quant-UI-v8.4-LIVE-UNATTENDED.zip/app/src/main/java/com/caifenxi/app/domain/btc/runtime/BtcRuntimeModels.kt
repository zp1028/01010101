package com.caifenxi.app.domain.btc.runtime

import com.caifenxi.app.domain.btc.BtcDirection

/** Runtime state is deliberately separate from trading signals. */
enum class BtcRunMode { PAPER, TESTNET, LIVE }
enum class BtcRuntimeStatus { STOPPED, RUNNING, PAUSED, KILLED, ERROR }

/**
 * 运行时配置。LIVE 无人值守必须同时满足：
 * - enabled=true
 * - runMode=LIVE
 * - liveAutoAuthorized=true（用户显式授权，默认 false）
 * - API Key 已配置
 * - killSwitch=false
 * - 日损/仓位/连续失败等闸门未触发
 */
data class BtcRuntimeConfig(
    val symbol: String = "BTCUSDT",
    val timeframe: String = "5m",
    val runMode: BtcRunMode = BtcRunMode.PAPER,
    val enabled: Boolean = false,
    val maxPositionQty: Double = 0.001,
    val pollSeconds: Long = 20L,
    /** 用户显式授权 LIVE 自动交易（持久化，默认关闭） */
    val liveAutoAuthorized: Boolean = false,
    /** 最大杠杆（LIVE 强制上限） */
    val maxLeverage: Int = 3,
    /** 单笔最大名义价值 USDT */
    val maxNotionalUsdt: Double = 100.0,
    /** 日最大亏损 USDT（与 DailyPnlStore 对齐） */
    val maxDailyLossUsdt: Double = 50.0,
    /** 连续下单失败次数后自动 KILL */
    val maxConsecutiveErrors: Int = 3,
    /** 两笔成交最小间隔秒 */
    val minOrderIntervalSec: Long = 60L,
    /** 必须挂 SL/TP */
    val requireBracketOrders: Boolean = true,
    /** 最小共识概率 */
    val minProbability: Double = 0.62
)

data class BtcRuntimeState(
    val status: BtcRuntimeStatus = BtcRuntimeStatus.STOPPED,
    val lastHeartbeatAt: Long = 0L,
    val lastBarId: Long = 0L,
    val lastSignal: BtcDirection? = BtcDirection.FLAT,
    val lastOrderClientId: String? = null,
    val lastError: String? = null,
    val killSwitch: Boolean = false,
    val processedBars: Long = 0L,
    val lastFundingRate: Double? = null,
    val lastOiChangePct: Double? = null,
    val lastDerivScore: Double? = null,
    val consecutiveErrors: Int = 0,
    val lastOrderAt: Long = 0L
)
