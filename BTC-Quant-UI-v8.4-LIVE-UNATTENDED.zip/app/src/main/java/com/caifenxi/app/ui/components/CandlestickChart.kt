package com.caifenxi.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.btc.BtcCandle
import com.caifenxi.app.ui.theme.CaiTokens
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * 专业 K 线图表组件：蜡烛图 + 成交量 + EMA 均线 + 手势缩放/平移 + 十字光标
 *
 * @param candles K 线数据列表（按时间正序）
 * @param showEma9 是否叠加 EMA9 均线
 * @param showEma21 是否叠加 EMA21 均线
 * @param showEma50 是否叠加 EMA50 均线
 * @param showVolume 是否显示成交量柱
 */
/**
 * 可选叠加层：入场 / 止损 / 止盈水平线 + 最近信号标记索引。
 */
data class ChartOverlay(
    val entry: Double? = null,
    val stopLoss: Double? = null,
    val takeProfit: Double? = null,
    /** 在最后一根附近画方向三角；1=多 -1=空 0=无 */
    val signalDir: Int = 0
)

@Composable
fun CandlestickChart(
    candles: List<BtcCandle>,
    modifier: Modifier = Modifier,
    showEma9: Boolean = true,
    showEma21: Boolean = true,
    showEma50: Boolean = true,
    showVolume: Boolean = true,
    overlay: ChartOverlay? = null,
    upColor: Color = CaiTokens.Success,
    downColor: Color = CaiTokens.Danger,
    ema9Color: Color = Color(0xFFFFB74D),
    ema21Color: Color = Color(0xFF64B5F6),
    ema50Color: Color = Color(0xFFCE93D8)
) {
    if (candles.size < 2) {
        Box(
            modifier.fillMaxWidth().height(200.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("K 线数据不足", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        return
    }

    // 缩放和平移状态
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var crosshair by remember { mutableStateOf<CrosshairState?>(null) }

    // 计算 EMA
    val closes = remember(candles) { candles.map { it.close } }
    val ema9Values = remember(closes) { ema(closes, 9) }
    val ema21Values = remember(closes) { ema(closes, 21) }
    val ema50Values = remember(closes) { ema(closes, 50) }

    // 全局价格范围（含叠加线，避免 SL/TP 画在画布外）
    val priceMin = remember(candles, overlay) {
        val baseMin = candles.minOf { it.low }
        listOfNotNull(baseMin, overlay?.entry, overlay?.stopLoss, overlay?.takeProfit).minOrNull() ?: baseMin
    }
    val priceMax = remember(candles, overlay) {
        val baseMax = candles.maxOf { it.high }
        listOfNotNull(baseMax, overlay?.entry, overlay?.stopLoss, overlay?.takeProfit).maxOrNull() ?: baseMax
    }
    val priceSpan = (priceMax - priceMin).coerceAtLeast(1e-9)
    val volMax = remember(candles) { candles.maxOf { it.volume }.coerceAtLeast(1e-9) }

    // 成交量区域高度占比
    val volRatio = if (showVolume) 0.18f else 0f
    val priceRatio = 1f - volRatio

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(12.dp)) {
            // 图例
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (showEma9) LegendDot("EMA9", ema9Color)
                if (showEma21) LegendDot("EMA21", ema21Color)
                if (showEma50) LegendDot("EMA50", ema50Color)
                if (overlay?.entry != null) LegendDot("Entry", Color(0xFFE0E0E0))
                if (overlay?.stopLoss != null) LegendDot("SL", downColor)
                if (overlay?.takeProfit != null) LegendDot("TP", upColor)
                Spacer(Modifier.weight(1f))
                Text(
                    "${candles.size} 根",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(Modifier.height(4.dp))

            // 当前价位或十字光标信息
            crosshair?.let { ch ->
                val candle = candles.getOrNull(ch.candleIndex)
                if (candle != null) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        InfoChip("O", "%.2f".format(candle.open))
                        InfoChip("H", "%.2f".format(candle.high))
                        InfoChip("L", "%.2f".format(candle.low))
                        InfoChip("C", "%.2f".format(candle.close))
                        InfoChip("V", "%.1f".format(candle.volume))
                    }
                }
            } ?: run {
                val last = candles.last()
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    InfoChip("O", "%.2f".format(last.open))
                    InfoChip("H", "%.2f".format(last.high))
                    InfoChip("L", "%.2f".format(last.low))
                    InfoChip("C", "%.2f".format(last.close))
                    val change = last.close - last.open
                    val changePct = if (last.open != 0.0) change / last.open * 100 else 0.0
                    InfoChip("+/-", "%.2f%%".format(changePct))
                }
            }

            Spacer(Modifier.height(6.dp))

            // 主图表 + 成交量 Canvas
            BoxWithConstraints(
                Modifier
                    .fillMaxWidth()
                    .heightIn(min = 240.dp)
            ) {
                val canvasW = constraints.maxWidth.toFloat()
                val canvasH = constraints.maxHeight.toFloat()
                val priceH = canvasH * priceRatio
                val volH = canvasH * volRatio
                val candleCount = candles.size

                Canvas(
                    Modifier
                        .fillMaxSize()
                        .pointerInput(candles) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                val newScale = (scale * zoom).coerceIn(0.5f, 5f)
                                val chartW = constraints.maxWidth.toFloat()
                                val candleSpacing = chartW / candleCount * newScale
                                val maxOffset = (candleSpacing * candleCount - chartW).coerceAtLeast(0f)
                                offsetX = (offsetX + pan.x).coerceIn(-maxOffset, 0f)
                                scale = newScale
                            }
                        }
                        .pointerInput(candles) {
                            awaitPointerEventScope {
                                while (true) {
                                    val event = awaitPointerEvent()
                                    val pos = event.changes.firstOrNull()?.position
                                    if (pos != null && pos.x >= 0 && pos.y >= 0) {
                                        val w = constraints.maxWidth.toFloat()
                                        val visibleCount = candles.size
                                        val adjustedX = pos.x - offsetX
                                        val candleWidth = w * scale / visibleCount
                                        val idx = (adjustedX / candleWidth).toInt()
                                            .coerceIn(0, candles.size - 1)
                                        crosshair = CrosshairState(
                                            candleIndex = idx,
                                            touchX = pos.x,
                                            touchY = pos.y
                                        )
                                    } else {
                                        crosshair = null
                                    }
                                }
                            }
                        }
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.background)
                ) {
                    val w = this.size.width
                    val totalChartW = w * scale
                    val candleSpace = totalChartW / candleCount
                    val candleBodyW = (candleSpace * 0.7f).coerceAtLeast(2f)

                    // === 价格区域 ===
                    // 水平网格线
                    val gridLines = 5
                    val gridColor = Color.White.copy(alpha = 0.06f)
                    for (i in 0..gridLines) {
                        val y = priceH * i / gridLines
                        drawLine(
                            gridColor,
                            start = Offset(0f, y),
                            end = Offset(w, y),
                            strokeWidth = 1f
                        )
                        // 价格标签
                        val price = priceMax - (priceSpan * i / gridLines)
                    }

                    // 蜡烛图
                    for (i in 0 until candleCount) {
                        val candle = candles[i]
                        val x = i * candleSpace + candleSpace / 2 + offsetX
                        if (x < -candleSpace || x > w + candleSpace) continue

                        val isUp = candle.close >= candle.open
                        val color = if (isUp) upColor else downColor

                        // 影线（高-低）
                        val highY = priceH - ((candle.high - priceMin) / priceSpan * priceH).toFloat()
                        val lowY = priceH - ((candle.low - priceMin) / priceSpan * priceH).toFloat()
                        drawLine(
                            color,
                            start = Offset(x, highY),
                            end = Offset(x, lowY),
                            strokeWidth = 1.5f
                        )

                        // 蜡烛实体
                        val openY = priceH - ((candle.open - priceMin) / priceSpan * priceH).toFloat()
                        val closeY = priceH - ((candle.close - priceMin) / priceSpan * priceH).toFloat()
                        val bodyTop = min(openY, closeY)
                        val bodyBot = max(openY, closeY)
                        val bodyH = (bodyBot - bodyTop).coerceAtLeast(1f)

                        if (isUp) {
                            drawRect(
                                color,
                                topLeft = Offset(x - candleBodyW / 2, bodyTop),
                                size = Size(candleBodyW, bodyH)
                            )
                        } else {
                            drawRect(
                                color,
                                topLeft = Offset(x - candleBodyW / 2, bodyTop),
                                size = Size(candleBodyW, bodyH)
                            )
                        }
                    }

                    // EMA 均线
                    if (showEma9 && ema9Values.size == candleCount) {
                        drawEmaLine(ema9Values, priceMin, priceSpan, priceH, candleSpace, offsetX, w, ema9Color, candleCount)
                    }
                    if (showEma21 && ema21Values.size == candleCount) {
                        drawEmaLine(ema21Values, priceMin, priceSpan, priceH, candleSpace, offsetX, w, ema21Color, candleCount)
                    }
                    if (showEma50 && ema50Values.size == candleCount) {
                        drawEmaLine(ema50Values, priceMin, priceSpan, priceH, candleSpace, offsetX, w, ema50Color, candleCount)
                    }

                    // === 成交量区域 ===
                    if (showVolume) {
                        val volTop = priceH + 4f
                        for (i in 0 until candleCount) {
                            val candle = candles[i]
                            val x = i * candleSpace + candleSpace / 2 + offsetX
                            if (x < -candleSpace || x > w + candleSpace) continue

                            val isUp = candle.close >= candle.open
                            val color = if (isUp) upColor.copy(alpha = 0.5f) else downColor.copy(alpha = 0.5f)
                            val barH = (candle.volume / volMax * volH).toFloat()
                            drawRect(
                                color,
                                topLeft = Offset(x - candleBodyW / 2, volTop + volH - barH),
                                size = Size(candleBodyW, barH)
                            )
                        }
                    }

                    // 信号叠加：Entry / SL / TP 水平线
                    fun priceY(p: Double): Float =
                        priceH - ((p - priceMin) / priceSpan * priceH).toFloat()

                    overlay?.entry?.let { p ->
                        val y = priceY(p)
                        drawLine(
                            Color(0xFFE0E0E0).copy(alpha = 0.85f),
                            start = Offset(0f, y),
                            end = Offset(w, y),
                            strokeWidth = 1.5f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 6f))
                        )
                    }
                    overlay?.stopLoss?.let { p ->
                        val y = priceY(p)
                        drawLine(
                            downColor.copy(alpha = 0.9f),
                            start = Offset(0f, y),
                            end = Offset(w, y),
                            strokeWidth = 2f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 5f))
                        )
                    }
                    overlay?.takeProfit?.let { p ->
                        val y = priceY(p)
                        drawLine(
                            upColor.copy(alpha = 0.9f),
                            start = Offset(0f, y),
                            end = Offset(w, y),
                            strokeWidth = 2f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 5f))
                        )
                    }
                    // 最近一根上的方向标记
                    if (overlay != null && overlay.signalDir != 0 && candleCount > 0) {
                        val i = candleCount - 1
                        val x = i * candleSpace + candleSpace / 2 + offsetX
                        if (x in -candleSpace..(w + candleSpace)) {
                            val last = candles[i]
                            val y = priceY(last.close)
                            val markColor = if (overlay.signalDir > 0) upColor else downColor
                            // 小三角标记（用短竖线+横线近似，避免 Path 依赖）
                            val tri = 8f
                            if (overlay.signalDir > 0) {
                                drawLine(markColor, Offset(x, y - tri * 2), Offset(x - tri, y), strokeWidth = 3f)
                                drawLine(markColor, Offset(x, y - tri * 2), Offset(x + tri, y), strokeWidth = 3f)
                            } else {
                                drawLine(markColor, Offset(x, y + tri * 2), Offset(x - tri, y), strokeWidth = 3f)
                                drawLine(markColor, Offset(x, y + tri * 2), Offset(x + tri, y), strokeWidth = 3f)
                            }
                        }
                    }

                    // 十字光标
                    crosshair?.let { ch ->
                        val cx = ch.touchX.coerceIn(0f, w)
                        val cy = ch.touchY.coerceIn(0f, canvasH)
                        drawLine(
                            Color.White.copy(alpha = 0.3f),
                            start = Offset(cx, 0f),
                            end = Offset(cx, canvasH),
                            strokeWidth = 1f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
                        )
                        drawLine(
                            Color.White.copy(alpha = 0.3f),
                            start = Offset(0f, cy),
                            end = Offset(w, cy),
                            strokeWidth = 1f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
                        )
                    }
                }
            }

            Spacer(Modifier.height(4.dp))

            // 交互提示
            Text(
                "双指缩放 / 拖动平移 / 触摸显示十字光标",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

// === 辅助 ===

private data class CrosshairState(
    val candleIndex: Int,
    val touchX: Float,
    val touchY: Float
)

@Composable
private fun LegendDot(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Canvas(Modifier.size(8.dp)) {
            drawCircle(color)
        }
        Spacer(Modifier.width(4.dp))
        Text(label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun InfoChip(label: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.width(2.dp))
        Text(value, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawEmaLine(
    values: List<Double>,
    priceMin: Double,
    priceSpan: Double,
    priceH: Float,
    candleSpace: Float,
    offsetX: Float,
    w: Float,
    color: Color,
    count: Int
) {
    if (values.size < 2) return
    val path = Path()
    var first = true
    for (i in 0 until count) {
        val v = values.getOrNull(i) ?: continue
        val x = i * candleSpace + candleSpace / 2 + offsetX
        if (x < -candleSpace * 2 || x > w + candleSpace * 2) {
            first = true
            continue
        }
        val y = priceH - ((v - priceMin) / priceSpan * priceH).toFloat()
        if (first) {
            path.moveTo(x, y)
            first = false
        } else {
            path.lineTo(x, y)
        }
    }
    drawPath(path, color = color, style = Stroke(width = 1.5f, cap = StrokeCap.Round))
}

/** EMA 计算（与 BtcPlanEngine 内部逻辑一致） */
private fun ema(values: List<Double>, period: Int): List<Double> {
    if (values.size < period) return emptyList()
    val k = 2.0 / (period + 1)
    val out = ArrayList<Double>(values.size)
    var prev = values.take(period).average()
    repeat(period) { out.add(prev) }
    for (i in period until values.size) {
        prev = values[i] * k + prev * (1 - k)
        out.add(prev)
    }
    return out
}
