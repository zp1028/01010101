package com.caifenxi.app.domain.btc.broker

import kotlin.math.floor
import kotlin.math.round
import org.json.JSONObject

/**
 * 交易所精度对齐。
 * 默认 BTCUSDT 步进；可通过 [updateFromExchangeInfoJson] 用 /fapi/v1/exchangeInfo 覆盖。
 */
object ExchangeFilters {
    data class SymbolFilter(
        val qtyStep: Double = 0.001,
        val qtyMin: Double = 0.001,
        val priceTick: Double = 0.10,
        val qtyPrecision: Int = 3,
        val pricePrecision: Int = 2
    )

    private val defaults = mapOf(
        "BTCUSDT" to SymbolFilter(),
        "ETHUSDT" to SymbolFilter(
            qtyStep = 0.001, qtyMin = 0.001, priceTick = 0.01,
            qtyPrecision = 3, pricePrecision = 2
        )
    )

    /** 运行时覆盖（线程简单场景：主线程/IO 写，读时可见即可） */
    @Volatile
    private var runtime: Map<String, SymbolFilter> = emptyMap()

    fun forSymbol(symbol: String): SymbolFilter {
        val key = symbol.uppercase()
        return runtime[key] ?: defaults[key] ?: SymbolFilter()
    }

    fun put(symbol: String, filter: SymbolFilter) {
        val key = symbol.uppercase()
        runtime = runtime + (key to filter)
    }

    /**
     * 解析 exchangeInfo 单 symbol 节点或完整 JSON。
     * 支持 filters 中 LOT_SIZE / MARKET_LOT_SIZE / PRICE_FILTER。
     */
    fun updateFromExchangeInfoJson(body: String, preferSymbol: String? = null): Boolean {
        return runCatching {
            val root = JSONObject(body)
            val symbols = root.optJSONArray("symbols")
            if (symbols != null) {
                for (i in 0 until symbols.length()) {
                    val s = symbols.getJSONObject(i)
                    val sym = s.optString("symbol")
                    if (preferSymbol != null && !sym.equals(preferSymbol, ignoreCase = true)) continue
                    parseSymbolObject(s)?.let { put(sym, it) }
                    if (preferSymbol != null) break
                }
            } else if (root.has("symbol")) {
                parseSymbolObject(root)?.let { put(root.getString("symbol"), it) }
            }
            true
        }.getOrDefault(false)
    }

    private fun parseSymbolObject(s: JSONObject): SymbolFilter? {
        val filters = s.optJSONArray("filters") ?: return null
        var step = 0.001
        var minQty = 0.001
        var tick = 0.10
        var qtyPrec = 3
        var pxPrec = 2
        for (i in 0 until filters.length()) {
            val f = filters.getJSONObject(i)
            when (f.optString("filterType")) {
                "LOT_SIZE", "MARKET_LOT_SIZE" -> {
                    step = f.optString("stepSize", "0.001").toDoubleOrNull() ?: step
                    minQty = f.optString("minQty", "0.001").toDoubleOrNull() ?: minQty
                    qtyPrec = precisionFromStep(step)
                }
                "PRICE_FILTER" -> {
                    tick = f.optString("tickSize", "0.10").toDoubleOrNull() ?: tick
                    pxPrec = precisionFromStep(tick)
                }
            }
        }
        return SymbolFilter(step, minQty, tick, qtyPrec, pxPrec)
    }

    private fun precisionFromStep(step: Double): Int {
        if (step <= 0) return 2
        val s = ("%.12f".format(step)).trimEnd('0')
        val dot = s.indexOf('.')
        return if (dot < 0) 0 else (s.length - dot - 1).coerceIn(0, 8)
    }

    fun roundQty(symbol: String, qty: Double): Double {
        val f = forSymbol(symbol)
        if (qty < f.qtyMin) return 0.0
        val steps = floor(qty / f.qtyStep + 1e-12)
        return (steps * f.qtyStep).coerceAtLeast(f.qtyMin)
    }

    fun roundPrice(symbol: String, price: Double): Double {
        val f = forSymbol(symbol)
        if (f.priceTick <= 0) return price
        val steps = round(price / f.priceTick)
        return steps * f.priceTick
    }

    fun formatQty(symbol: String, qty: Double): String {
        val f = forSymbol(symbol)
        val q = roundQty(symbol, qty)
        return "%.${f.qtyPrecision}f".format(q)
    }

    fun formatPrice(symbol: String, price: Double): String {
        val f = forSymbol(symbol)
        val p = roundPrice(symbol, price)
        return "%.${f.pricePrecision}f".format(p)
    }
}
