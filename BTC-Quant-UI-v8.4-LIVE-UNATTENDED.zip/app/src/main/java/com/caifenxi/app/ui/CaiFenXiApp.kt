package com.caifenxi.app.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.caifenxi.app.ui.screens.BetScreen
import com.caifenxi.app.ui.screens.BtcQuantScreen
import com.caifenxi.app.ui.screens.HistoryScreen
import com.caifenxi.app.ui.screens.HomeScreen
import com.caifenxi.app.ui.screens.LabScreen
import com.caifenxi.app.ui.screens.PlanScreen
import com.caifenxi.app.ui.screens.PredictScreen
import com.caifenxi.app.ui.screens.MoreScreen
import com.caifenxi.app.ui.screens.NovaPlanScreen
import com.caifenxi.app.ui.screens.ChartScreen
import com.caifenxi.app.ui.screens.PlanWorkbenchScreen
import com.caifenxi.app.ui.screens.WebBetScreen
import com.caifenxi.app.ui.screens.ExecutorControlScreen
import com.caifenxi.app.ui.screens.ExecutorLogScreen
import com.caifenxi.app.ui.screens.AiSettingsScreen
import com.caifenxi.app.ui.screens.AiAgentLabScreen
import com.caifenxi.app.ui.components.GlobalStatusBar

private enum class Tab(val route: String, val label: String, val icon: ImageVector) {
    Home("home", "首页", Icons.Filled.Home),
    Predict("predict", "预测", Icons.Filled.Analytics),
    Plan("plan", "原计划", Icons.Filled.ListAlt),
    Nova("nova", "新计划", Icons.Filled.ListAlt),
    Chart("chart", "图表", Icons.Filled.ShowChart),
    Workbench("workbench", "工作台", Icons.Filled.ListAlt),
    Bet("bet", "挂机", Icons.Filled.ListAlt),
    Web("web_bet", "网页", Icons.Filled.Public),
    More("more", "更多", Icons.Filled.MoreHoriz),
    Btc("btc_quant", "BTC量化", Icons.Filled.ShowChart),
}

@Composable
fun CaiFenXiApp(viewModel: MainViewModel, btcViewModel: BtcQuantViewModel) {
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route

    val lottery = viewModel.currentLottery.value
    val history = viewModel.history.value
    val latest = history.lastOrNull()?.issue ?: "-"
    val target = viewModel.nextIssueText.value
    val status = viewModel.statusText.value
    val err = viewModel.errorMessage.value

    val isWebFull = currentRoute == Tab.Web.route

    Scaffold(
        topBar = {
            if (!isWebFull) {
                GlobalStatusBar(
                    lotteryName = lottery.name,
                    latestIssue = latest,
                    targetIssue = target,
                    statusText = status,
                    errorMessage = err,
                    historySize = history.size,
                    onSync = { viewModel.loadData() }
                )
            }
        },
        bottomBar = {
            // 底栏精简：首页 / 预测 / BTC量化 / 挂机 / 更多
            val bottomTabs = listOf(Tab.Home, Tab.Predict, Tab.Btc, Tab.Bet, Tab.More)
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                bottomTabs.forEach { tab ->
                    NavigationBarItem(
                        selected = currentRoute == tab.route ||
                            (tab == Tab.More && currentRoute != null && currentRoute !in bottomTabs.map { it.route }),
                        onClick = {
                            navController.navigate(tab.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label, fontSize = 10.sp) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Tab.Home.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(Tab.Home.route) {
                HomeScreen(
                    vm = viewModel,
                    btcVm = btcViewModel,
                    onOpenBtc = {
                        navController.navigate(Tab.Btc.route) { launchSingleTop = true }
                    }
                )
            }
            composable(Tab.Predict.route) { PredictScreen(viewModel) }
            composable(Tab.More.route) { MoreScreen(viewModel, navController) }
            composable("more") { MoreScreen(viewModel, navController) }
            composable("stats") { HistoryScreen(viewModel) }
            composable("lab") { LabScreen(viewModel) }
            composable("settings") { com.caifenxi.app.ui.screens.SettingsScreen(viewModel) { navController.navigate("accessibility") } }
            composable("accessibility") { com.caifenxi.app.ui.screens.AccessibilityScreen(viewModel) }
            composable(Tab.Plan.route) { PlanScreen(viewModel) { navController.navigate(Tab.Nova.route) { launchSingleTop = true } } }
            composable(Tab.Nova.route) { NovaPlanScreen(viewModel) }
            composable(Tab.Chart.route) { ChartScreen(viewModel) }
            composable(Tab.Workbench.route) { PlanWorkbenchScreen(viewModel) }
            composable(Tab.Bet.route) { BetScreen(viewModel) }
            // 修复：底栏 BTC 量化此前无路由，点击空白
            composable(Tab.Btc.route) { BtcQuantScreen(btcViewModel) }
            composable(Tab.Web.route) {
                WebBetScreen(
                    mainViewModel = viewModel,
                    onBack = { navController.navigate(Tab.Home.route) { launchSingleTop = true } },
                    onWorkbench = { navController.navigate(Tab.Workbench.route) { launchSingleTop = true } },
                    onBet = { navController.navigate(Tab.Bet.route) { launchSingleTop = true } }
                )
            }

            composable("executor_control") { ExecutorControlScreen() }
            composable("executor_logs") { ExecutorLogScreen() }
            composable("ai_settings") { AiSettingsScreen(onBack = { navController.popBackStack() }) }
            composable("ai_agent_lab") { AiAgentLabScreen(onBack = { navController.popBackStack() }) }
        }
    }
}