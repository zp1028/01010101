import asyncio

import pytest

from app.core.event_bus import EventBus
from app.core.events import AttentionEvent, CandleEvent, SignalEvent
from app.quant.attention.engine import AttentionEngine


@pytest.mark.asyncio
async def test_attention_from_signal_and_candle():
    bus = EventBus()
    eng = AttentionEngine(bus, decay_seconds=600)
    eng.subscribe()

    seen: list[AttentionEvent] = []

    async def on_att(e: AttentionEvent):
        seen.append(e)

    bus.subscribe(AttentionEvent, on_att)

    now = 1_700_000_000_000
    await bus.publish(
        SignalEvent(
            instrument_id="binance:BTCUSDT",
            symbol="BTCUSDT",
            signal_name="rsi_oversold",
            direction="long",
            strength=0.8,
            timeframe="1m",
            features={"rsi_14": 25.0},
            source_timestamp=now,
            generated_at=now,
        )
    )
    await bus.publish(
        CandleEvent(
            instrument_id="binance:BTCUSDT",
            symbol="BTCUSDT",
            interval="1m",
            open=100,
            high=102,
            low=99,
            close=101.5,
            volume=5000,
            open_time=now,
            close_time=now + 59_999,
            is_closed=True,
            source_timestamp=now + 59_999,
            received_at=now + 60_000,
        )
    )

    assert len(seen) >= 1
    top = eng.ranking(1)
    assert top
    assert top[0].instrument_id == "binance:BTCUSDT"
    assert top[0].score >= 0
