from app.providers.crypto.binance.ws import BinanceWsClient


class S:
    binance_kline_interval = "1m"
    reconnect_base_seconds = 1.0
    reconnect_max_seconds = 30.0


def test_stream_generation():
    client = BinanceWsClient(S(), None)
    streams = client._streams_for({"btcusdt"})
    assert "btcusdt@ticker" in streams
    assert "btcusdt@trade" in streams
    assert "btcusdt@bookTicker" in streams
    assert "btcusdt@kline_1m" in streams
