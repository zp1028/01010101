import pytest
from app.core.event_bus import EventBus

class E: pass

@pytest.mark.asyncio
async def test_event_bus_dispatch():
    bus = EventBus()
    seen = []
    async def handler(event):
        seen.append(event)
    bus.subscribe(E, handler)
    await bus.publish(E())
    assert len(seen) == 1
