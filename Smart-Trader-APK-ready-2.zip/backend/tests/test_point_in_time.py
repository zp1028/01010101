from dataclasses import dataclass

import pytest

from app.data.point_in_time import (
    assert_no_lookahead,
    filter_available,
    is_available,
    pit_slice,
)


@dataclass
class Rec:
    available_at: int
    value: str


def test_is_available():
    assert is_available(Rec(100, "a"), 100) is True
    assert is_available(Rec(100, "a"), 101) is True
    assert is_available(Rec(100, "a"), 99) is False


def test_filter_available():
    records = [Rec(10, "a"), Rec(20, "b"), Rec(30, "c")]
    kept = filter_available(records, 20)
    assert [r.value for r in kept] == ["a", "b"]


def test_assert_no_lookahead_passes():
    records = [Rec(10, "a"), Rec(20, "b")]
    assert_no_lookahead(records, 25)


def test_assert_no_lookahead_raises():
    records = [Rec(10, "a"), Rec(30, "b")]
    with pytest.raises(ValueError, match="Look-ahead"):
        assert_no_lookahead(records, 25, context="unit-test")


def test_pit_slice_dicts():
    rows = [
        {"available_at": 10, "x": 1},
        {"available_at": 50, "x": 2},
        {"available_at": 100, "x": 3},
    ]
    assert pit_slice(rows, 50) == [
        {"available_at": 10, "x": 1},
        {"available_at": 50, "x": 2},
    ]
