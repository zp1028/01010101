import asyncio

import pytest

from app.core.event_bus import EventBus
from app.core.events import MarketTickEvent
from app.execution.models import OrderRequest
from app.execution.paper import PaperExecutionEngine
from app.risk.engine import RiskEngine
from app.risk.models import AccountState, RiskLimits


@pytest.mark.asyncio
async def test_paper_buy_then_sell():
    bus = EventBus()
    risk = RiskEngine(bus, account=AccountState(equity=10_000, cash=10_000))
    ex = PaperExecutionEngine(bus, risk, initial_cash=10_000)
    ex.subscribe()

    # seed price
    await bus.publish(
        MarketTickEvent(
            instrument_id="binance:BTCUSDT",
            symbol="BTCUSDT",
            bid=99,
            ask=101,
            last=100.0,
            bid_size=1,
            ask_size=1,
            source_timestamp=1,
            received_at=1,
            processed_at=1,
        )
    )

    buy = await ex.submit(
        OrderRequest(
            instrument_id="binance:BTCUSDT",
            symbol="BTCUSDT",
            side="buy",
            position_pct=0.1,
            source="test",
        )
    )
    assert buy.status == "filled"
    assert buy.avg_fill_price is not None
    positions = ex.list_positions()
    assert len(positions) == 1
    assert positions[0].side == "long"

    sell = await ex.submit(
        OrderRequest(
            instrument_id="binance:BTCUSDT",
            symbol="BTCUSDT",
            side="sell",
            quantity=positions[0].quantity,
            source="test",
        )
    )
    assert sell.status == "filled"
    assert len(ex.list_positions()) == 0
    pf = ex.portfolio()
    assert pf.equity > 0


@pytest.mark.asyncio
async def test_risk_blocks_oversize():
    bus = EventBus()
    risk = RiskEngine(
        bus,
        account=AccountState(equity=10_000, cash=10_000),
        limits=RiskLimits(max_position_pct=0.15),
    )
    ex = PaperExecutionEngine(bus, risk, initial_cash=10_000)
    await bus.publish(
        MarketTickEvent(
            instrument_id="binance:ETHUSDT",
            symbol="ETHUSDT",
            bid=None,
            ask=None,
            last=2000.0,
            bid_size=None,
            ask_size=None,
            source_timestamp=1,
            received_at=1,
            processed_at=1,
        )
    )
    order = await ex.submit(
        OrderRequest(
            instrument_id="binance:ETHUSDT",
            symbol="ETHUSDT",
            side="buy",
            position_pct=0.8,
        )
    )
    assert order.status == "rejected"
    assert order.risk_decision is not None
