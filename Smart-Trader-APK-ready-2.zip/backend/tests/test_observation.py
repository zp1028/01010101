import asyncio

import pytest

from app.core.event_bus import EventBus
from app.core.events import MarketTickEvent, ObservationTriggeredEvent
from app.quant.observation.engine import ObservationEngine


@pytest.mark.asyncio
async def test_price_cross_triggers():
    bus = EventBus()
    eng = ObservationEngine(bus, cooldown_ms=0)
    eng.subscribe()

    node = eng.add(
        "binance:BTCUSDT",
        "BTCUSDT",
        trigger_value=100.0,
        direction="cross",
    )

    triggered: list[ObservationTriggeredEvent] = []

    async def on_obs(e: ObservationTriggeredEvent):
        triggered.append(e)

    bus.subscribe(ObservationTriggeredEvent, on_obs)

    async def tick(last: float, ts: int):
        await bus.publish(
            MarketTickEvent(
                instrument_id="binance:BTCUSDT",
                symbol="BTCUSDT",
                bid=last - 0.5,
                ask=last + 0.5,
                last=last,
                bid_size=1,
                ask_size=1,
                source_timestamp=ts,
                received_at=ts,
                processed_at=ts,
            )
        )

    await tick(99.0, 1000)   # below, establish last_price
    await tick(100.5, 2000)  # cross above → should trigger

    assert len(triggered) == 1
    assert triggered[0].observation_id == node.observation_id
    assert triggered[0].current_value == 100.5


@pytest.mark.asyncio
async def test_above_direction():
    bus = EventBus()
    eng = ObservationEngine(bus, cooldown_ms=0)
    eng.subscribe()
    eng.add("binance:ETHUSDT", "ETHUSDT", 2000.0, direction="above")

    triggered: list = []

    async def on_obs(e):
        triggered.append(e)

    bus.subscribe(ObservationTriggeredEvent, on_obs)

    async def tick(last: float, ts: int):
        await bus.publish(
            MarketTickEvent(
                instrument_id="binance:ETHUSDT",
                symbol="ETHUSDT",
                bid=None,
                ask=None,
                last=last,
                bid_size=None,
                ask_size=None,
                source_timestamp=ts,
                received_at=ts,
                processed_at=ts,
            )
        )

    await tick(1999.0, 1)
    await tick(2000.5, 2)
    assert len(triggered) == 1
