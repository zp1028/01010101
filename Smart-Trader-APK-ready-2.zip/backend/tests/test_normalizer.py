import pytest

from app.core.event_bus import EventBus
from app.core.events import MarketTickEvent
from app.models.instrument import InstrumentRegistry
from app.providers.crypto.binance.ws import BinanceWsClient


@pytest.mark.asyncio
async def test_book_ticker_normalizes():
    class S:
        binance_kline_interval = "1m"

    bus = EventBus()
    seen: list = []

    async def handler(event):
        seen.append(event)

    bus.subscribe(MarketTickEvent, handler)
    instruments = InstrumentRegistry()
    client = BinanceWsClient(S(), bus, instruments)
    await client._handle_raw(
        '{"stream":"btcusdt@bookTicker","data":{"e":"bookTicker","u":1,'
        '"s":"BTCUSDT","b":"100.0","B":"2","a":"101.0","A":"3","E":123}}'
    )
    assert len(seen) == 1
    event = seen[0]
    assert event.symbol == "BTCUSDT"
    assert event.instrument_id == "binance:BTCUSDT"
    assert event.bid == 100.0
    assert event.ask == 101.0
    assert event.bid_size == 2.0
    assert event.ask_size == 3.0
    assert event.venue == "binance"


@pytest.mark.asyncio
async def test_trade_normalizes():
    class S:
        binance_kline_interval = "1m"

    bus = EventBus()
    seen: list = []

    async def handler(event):
        seen.append(event)

    from app.core.events import TradeEvent

    bus.subscribe(TradeEvent, handler)
    instruments = InstrumentRegistry()
    client = BinanceWsClient(S(), bus, instruments)
    await client._handle_raw(
        '{"stream":"btcusdt@trade","data":{"e":"trade","s":"BTCUSDT",'
        '"p":"50000.5","q":"0.01","m":true,"E":456}}'
    )
    assert len(seen) == 1
    event = seen[0]
    assert event.symbol == "BTCUSDT"
    assert event.instrument_id == "binance:BTCUSDT"
    assert event.price == 50000.5
    assert event.quantity == 0.01
    assert event.is_buyer_maker is True
