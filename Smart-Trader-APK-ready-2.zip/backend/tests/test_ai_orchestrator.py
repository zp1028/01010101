import asyncio

import pytest

from app.ai.orchestrator.engine import AIOrchestrator
from app.core.event_bus import EventBus
from app.core.events import (
    AIAnalysisCompletedEvent,
    CandleEvent,
    SignalEvent,
)
from app.quant.features.engine import FeatureEngine
from app.quant.signals.engine import SignalEngine


def _candle(i: int, close: float) -> CandleEvent:
    t = 1_700_000_000_000 + i * 60_000
    return CandleEvent(
        instrument_id="binance:BTCUSDT",
        symbol="BTCUSDT",
        interval="1m",
        open=close - 1,
        high=close + 2,
        low=close - 2,
        close=close,
        volume=1000 + i * 10,
        open_time=t,
        close_time=t + 59_999,
        is_closed=True,
        source_timestamp=t + 59_999,
        received_at=t + 60_000,
    )


@pytest.mark.asyncio
async def test_orchestrator_produces_structured_result():
    bus = EventBus()
    fe = FeatureEngine(bus)
    se = SignalEngine(bus, fe)
    fe.subscribe()
    se.subscribe()
    orch = AIOrchestrator(bus, fe, se, attention_engine=None, auto_on_attention=False)

    completed: list[AIAnalysisCompletedEvent] = []

    async def on_done(e: AIAnalysisCompletedEvent):
        completed.append(e)

    bus.subscribe(AIAnalysisCompletedEvent, on_done)

    # warm features with declining prices → RSI oversold path more likely
    price = 120.0
    for i in range(50):
        price -= 0.8
        await bus.publish(_candle(i, price))

    result = await orch.run(
        instrument_id="binance:BTCUSDT",
        symbol="BTCUSDT",
        trigger="manual",
        timeframe="1m",
    )

    assert result.analysis_id
    assert result.instrument_id == "binance:BTCUSDT"
    assert 0 <= result.confidence <= 1
    assert 0 <= result.data_quality <= 1
    assert isinstance(result.bull_case, list)
    assert isinstance(result.bear_case, list)
    assert isinstance(result.evidence, list)
    assert result.technical.get("close") is not None
    assert len(completed) == 1
    assert completed[0].analysis_id == result.analysis_id
