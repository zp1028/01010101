from app.backtest.models import BacktestConfig
from app.backtest.vectorized.engine import run_vectorized
from app.backtest.walk_forward import run_walk_forward, split_bars


def _synthetic_bars(n: int = 80) -> list[dict]:
    bars = []
    price = 100.0
    t0 = 1_700_000_000_000
    for i in range(n):
        # mild mean-reverting path
        price += (50 - (i % 20)) * 0.05
        bars.append(
            {
                "open": price - 0.2,
                "high": price + 0.5,
                "low": price - 0.5,
                "close": price,
                "volume": 1000 + i,
                "open_time": t0 + i * 60_000,
                "close_time": t0 + i * 60_000 + 59_999,
            }
        )
    return bars


def test_vectorized_rsi_runs():
    cfg = BacktestConfig(
        instrument_id="binance:BTCUSDT",
        symbol="BTCUSDT",
        bars=_synthetic_bars(100),
        strategy="rsi",
        strategy_params={"period": 14, "low": 30, "high": 70},
    )
    result = run_vectorized(cfg)
    assert result.engine == "vectorized"
    assert result.final_equity > 0
    assert result.trade_count >= 0
    assert result.pit_enforced is True


def test_buy_hold():
    cfg = BacktestConfig(
        instrument_id="binance:BTCUSDT",
        symbol="BTCUSDT",
        bars=_synthetic_bars(50),
        strategy="buy_hold",
    )
    result = run_vectorized(cfg)
    assert result.trade_count >= 1


def test_walk_forward_splits():
    bars = _synthetic_bars(100)
    train, val, oos = split_bars(bars)
    assert len(train) + len(val) + len(oos) == 100
    cfg = BacktestConfig(
        instrument_id="binance:BTCUSDT",
        symbol="BTCUSDT",
        bars=bars,
        strategy="rsi",
    )
    out = run_walk_forward(cfg)
    assert "splits" in out
    assert "results" in out
