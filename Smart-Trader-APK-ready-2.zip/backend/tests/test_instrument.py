from app.models.instrument import (
    AssetType,
    ContractType,
    Instrument,
    InstrumentRegistry,
)


def test_ensure_crypto_creates_and_reuses():
    reg = InstrumentRegistry()
    a = reg.ensure_crypto("BTCUSDT", venue="binance")
    b = reg.ensure_crypto("BTCUSDT", venue="binance")
    assert a is b
    assert a.instrument_id == "binance:BTCUSDT"
    assert a.symbol == "BTC/USDT"
    assert a.asset_type == AssetType.CRYPTO
    assert a.contract_type == ContractType.PERPETUAL
    assert a.base_currency == "BTC"
    assert a.quote_currency == "USDT"


def test_get_by_symbol():
    reg = InstrumentRegistry()
    reg.ensure_crypto("ETHUSDT")
    found = reg.get_by_symbol("ETH/USDT", "binance")
    assert found is not None
    assert found.instrument_id == "binance:ETHUSDT"


def test_list_all():
    reg = InstrumentRegistry()
    reg.ensure_crypto("BTCUSDT")
    reg.ensure_crypto("SOLUSDT")
    assert len(reg.list_all()) == 2
