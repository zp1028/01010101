from app.ai.advice import build_trading_advice
from app.ai.models import AnalysisResult
from app.quant.features.engine import FeatureSnapshot
from app.risk.models import RiskLimits


def test_long_advice_from_bullish_analysis():
    analysis = AnalysisResult(
        analysis_id="a1",
        instrument_id="binance:BTCUSDT",
        symbol="BTC/USDT",
        timestamp=1,
        trend="bullish",
        confidence=0.7,
        data_quality=0.8,
        bull_case=["RSI 超卖回升"],
        bear_case=[],
        support=[82000.0],
        resistance=[85000.0],
    )
    snap = FeatureSnapshot(
        instrument_id="binance:BTCUSDT",
        symbol="BTC/USDT",
        timeframe="1m",
        computed_at=1,
        available_at=1,
        features={
            "close": 84000.0,
            "rsi_14": 28.0,
            "macd_hist": 0.5,
            "bb_pct": 0.05,
            "bb_lower": 82000.0,
            "bb_upper": 86000.0,
            "bb_mid": 84000.0,
        },
        source_close_time=1,
    )
    adv = build_trading_advice(
        instrument_id="binance:BTCUSDT",
        symbol="BTC/USDT",
        analysis=analysis,
        snapshot=snap,
        last_price=84000.0,
        risk_limits=RiskLimits(),
    )
    assert adv.entry.direction == "long"
    assert adv.entry.suggested_entry is not None
    assert adv.entry.stop_loss is not None
    assert adv.entry.stop_loss < adv.entry.suggested_entry
    assert adv.position.action in ("open", "wait")
    assert adv.entry.position_pct is not None
    assert adv.entry.position_pct <= 0.25


def test_wait_when_mixed():
    analysis = AnalysisResult(
        analysis_id="a2",
        instrument_id="binance:ETHUSDT",
        symbol="ETH/USDT",
        timestamp=1,
        trend="mixed",
        confidence=0.4,
        data_quality=0.5,
    )
    adv = build_trading_advice(
        instrument_id="binance:ETHUSDT",
        symbol="ETH/USDT",
        analysis=analysis,
        snapshot=None,
        last_price=3000.0,
    )
    assert adv.entry.direction == "wait"
    assert adv.position.action == "wait"


def test_reduce_when_holding_against_trend():
    analysis = AnalysisResult(
        analysis_id="a3",
        instrument_id="binance:BTCUSDT",
        symbol="BTC/USDT",
        timestamp=1,
        trend="bearish",
        confidence=0.65,
        data_quality=0.7,
    )
    snap = FeatureSnapshot(
        instrument_id="binance:BTCUSDT",
        symbol="BTC/USDT",
        timeframe="1m",
        computed_at=1,
        available_at=1,
        features={"close": 84000.0, "rsi_14": 75.0, "macd_hist": -0.2},
        source_close_time=1,
    )
    adv = build_trading_advice(
        instrument_id="binance:BTCUSDT",
        symbol="BTC/USDT",
        analysis=analysis,
        snapshot=snap,
        last_price=84000.0,
        has_open_long=True,
    )
    assert adv.entry.direction == "short"
    assert adv.position.action == "reduce"
