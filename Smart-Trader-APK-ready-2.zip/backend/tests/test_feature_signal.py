import asyncio

import pytest

from app.core.event_bus import EventBus
from app.core.events import CandleEvent, SignalEvent
from app.quant.features.engine import FeatureEngine
from app.quant.signals.engine import SignalEngine


def _candle(i: int, close: float, closed: bool = True) -> CandleEvent:
    t = 1_700_000_000_000 + i * 60_000
    return CandleEvent(
        instrument_id="binance:BTCUSDT",
        symbol="BTCUSDT",
        interval="1m",
        open=close - 1,
        high=close + 1,
        low=close - 2,
        close=close,
        volume=100.0 + i,
        open_time=t,
        close_time=t + 59_999,
        is_closed=closed,
        source_timestamp=t + 59_999,
        received_at=t + 60_000,
        venue="binance",
    )


@pytest.mark.asyncio
async def test_feature_and_signal_pipeline():
    bus = EventBus()
    fe = FeatureEngine(bus, max_bars=100)
    se = SignalEngine(bus, fe)
    fe.subscribe()
    se.subscribe()

    signals: list[SignalEvent] = []

    async def on_sig(e: SignalEvent):
        signals.append(e)

    bus.subscribe(SignalEvent, on_sig)

    # feed enough closed candles for indicators to warm up
    base = 100.0
    for i in range(60):
        # mild oscillation so RSI / BB can produce values
        close = base + (i % 10) - 5
        await bus.publish(_candle(i, close, closed=True))

    snap = fe.get_latest("binance:BTCUSDT", "1m")
    assert snap is not None
    assert snap.features.get("close") is not None
    assert "rsi_14" in snap.features
    assert "macd" in snap.features
    assert snap.available_at == snap.source_close_time

    # signals may or may not fire depending on the synthetic path;
    # the important part is the pipeline did not crash and features exist.
    assert isinstance(signals, list)
