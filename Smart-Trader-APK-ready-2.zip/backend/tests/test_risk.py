from app.risk.engine import RiskEngine
from app.risk.models import AccountState, RiskLimits, TradeProposal


def test_approve_small_long():
    eng = RiskEngine(account=AccountState(equity=10_000, cash=10_000))
    d = eng.validate(
        TradeProposal(
            instrument_id="binance:BTCUSDT",
            symbol="BTCUSDT",
            side="long",
            entry_price=50_000,
            stop_price=49_000,
            position_pct=0.1,
            leverage=1.0,
        )
    )
    assert d.approved is True
    assert d.risk_score < 0.8


def test_block_oversize():
    eng = RiskEngine(limits=RiskLimits(max_position_pct=0.2))
    d = eng.validate(
        TradeProposal(
            instrument_id="binance:BTCUSDT",
            symbol="BTCUSDT",
            side="long",
            entry_price=50_000,
            position_pct=0.5,
            leverage=1.0,
        )
    )
    assert d.approved is False
    codes = [v.code for v in d.violations]
    assert "MAX_POSITION" in codes
    assert d.adjusted is not None
    assert d.adjusted.position_pct == 0.2


def test_block_leverage():
    eng = RiskEngine(limits=RiskLimits(max_leverage=2.0))
    d = eng.validate(
        TradeProposal(
            instrument_id="binance:BTCUSDT",
            symbol="BTCUSDT",
            side="long",
            entry_price=50_000,
            position_pct=0.1,
            leverage=10.0,
        )
    )
    assert d.approved is False
    assert any(v.code == "LEVERAGE_EXCEEDED" for v in d.violations)


def test_stop_too_tight():
    eng = RiskEngine(limits=RiskLimits(min_stop_distance_pct=0.01))
    d = eng.validate(
        TradeProposal(
            instrument_id="binance:BTCUSDT",
            symbol="BTCUSDT",
            side="long",
            entry_price=100.0,
            stop_price=99.5,  # 0.5%
            position_pct=0.1,
        )
    )
    assert d.approved is False
    assert any(v.code == "STOP_TOO_TIGHT" for v in d.violations)


def test_account_halt():
    eng = RiskEngine(
        account=AccountState(equity=8_000),
        limits=RiskLimits(max_account_loss_pct=0.1),
    )
    eng._session_start_equity = 10_000
    d = eng.validate(
        TradeProposal(
            instrument_id="binance:BTCUSDT",
            symbol="BTCUSDT",
            side="long",
            entry_price=50_000,
            position_pct=0.05,
        )
    )
    assert d.approved is False
    assert any(v.code == "ACCOUNT_LOSS_HALT" for v in d.violations)
    assert eng.is_halted is True
