from app.quant.indicators.basic import bollinger, ema, latest, macd, rsi, sma


def test_sma():
    values = [1.0, 2.0, 3.0, 4.0, 5.0]
    result = sma(values, 3)
    assert result[0] is None
    assert result[1] is None
    assert result[2] == 2.0
    assert result[3] == 3.0
    assert result[4] == 4.0


def test_ema_seed():
    values = [10.0, 11.0, 12.0, 13.0, 14.0, 15.0]
    result = ema(values, 3)
    assert result[2] is not None
    assert latest(result) is not None


def test_rsi_range():
    # steadily rising → RSI should be high
    closes = [float(i) for i in range(1, 40)]
    series = rsi(closes, 14)
    val = latest(series)
    assert val is not None
    assert 50 < val <= 100


def test_macd_shapes():
    closes = [float(i) + (i % 5) * 0.1 for i in range(1, 60)]
    line, sig, hist = macd(closes)
    assert len(line) == len(closes)
    assert latest(line) is not None
    assert latest(sig) is not None
    assert latest(hist) is not None


def test_bollinger():
    closes = [100.0 + (i % 7) - 3 for i in range(40)]
    mid, upper, lower = bollinger(closes, 20)
    m, u, l = latest(mid), latest(upper), latest(lower)
    assert m is not None and u is not None and l is not None
    assert l < m < u
