from fastapi import APIRouter
from pydantic import BaseModel, Field
from typing import Any, Literal

from app.main import risk_engine
from app.risk.models import AccountState, RiskLimits, TradeProposal

router = APIRouter(tags=["risk"])


class ValidateRequest(BaseModel):
    instrument_id: str
    symbol: str
    side: Literal["long", "short", "flat"]
    entry_price: float | None = None
    stop_price: float | None = None
    take_profit: float | None = None
    position_pct: float | None = None
    quantity: float | None = None
    leverage: float = 1.0
    reason: str = ""
    source: str = "manual"


class AccountUpdate(BaseModel):
    equity: float | None = None
    cash: float | None = None
    used_margin: float | None = None
    open_positions: list[dict[str, Any]] | None = None


@router.post("/risk/validate")
async def validate_proposal(body: ValidateRequest):
    proposal = TradeProposal(**body.model_dump())
    decision = await risk_engine.validate_and_publish(proposal)
    return decision.model_dump()


@router.get("/risk/limits")
async def get_limits():
    return risk_engine.limits.model_dump()


@router.put("/risk/limits")
async def put_limits(body: RiskLimits):
    risk_engine.set_limits(body)
    return risk_engine.limits.model_dump()


@router.get("/risk/account")
async def get_account():
    return {
        "account": risk_engine.account.model_dump(),
        "halted": risk_engine.is_halted,
        "last_decision": risk_engine.last_decision.model_dump()
        if risk_engine.last_decision
        else None,
    }


@router.post("/risk/account")
async def post_account(body: AccountUpdate):
    kwargs = {k: v for k, v in body.model_dump().items() if v is not None}
    risk_engine.update_account(**kwargs)
    return risk_engine.account.model_dump()


@router.post("/risk/session/reset")
async def reset_session():
    risk_engine.reset_session()
    return {"halted": risk_engine.is_halted, "equity": risk_engine.account.equity}
