from fastapi import APIRouter, HTTPException
from app.main import binance

router = APIRouter(tags=["markets"])

@router.get("/markets")
async def markets():
    return {
        "provider": binance.health.model_dump(),
        "symbols": [s.upper() for s in sorted(binance.subscriptions)],
    }

@router.get("/markets/{symbol}")
async def market(symbol: str):
    if symbol.lower() not in binance.subscriptions:
        raise HTTPException(404, "symbol not subscribed")
    return {"symbol": symbol.upper(), "provider": binance.health.model_dump()}
