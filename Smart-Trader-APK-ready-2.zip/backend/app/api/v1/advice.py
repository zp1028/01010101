"""Single-instrument analysis + long/short entry & position advice."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field

from app.ai.advice import TradingAdvice, build_trading_advice
from app.main import (
    ai_orchestrator,
    feature_engine,
    instruments,
    paper_execution,
    risk_engine,
)

router = APIRouter(tags=["advice"])


class AdviceRequest(BaseModel):
    instrument_id: str | None = None
    symbol: str | None = None
    timeframe: str = "1m"
    run_analysis: bool = True  # refresh AI analysis first


def _resolve(instrument_id: str | None, symbol: str | None) -> tuple[str, str]:
    if instrument_id and symbol:
        return instrument_id, symbol
    if instrument_id:
        inst = instruments.get(instrument_id)
        if inst:
            return inst.instrument_id, inst.symbol
        # tolerate raw id
        return instrument_id, instrument_id.split(":")[-1]
    if symbol:
        raw = symbol.upper().replace("/", "")
        iid = f"binance:{raw}"
        inst = instruments.get(iid) or instruments.get_by_symbol(
            symbol if "/" in symbol else f"{raw[:-4]}/USDT" if raw.endswith("USDT") else symbol,
            "binance",
        )
        if inst:
            return inst.instrument_id, inst.symbol
        return iid, symbol.upper()
    raise HTTPException(400, "instrument_id or symbol required")


@router.get("/advice/{instrument_key}", response_model=TradingAdvice)
async def get_advice(
    instrument_key: str,
    timeframe: str = Query("1m"),
    run_analysis: bool = Query(True),
):
    """
    instrument_key: instrument_id (binance:BTCUSDT) or symbol (BTCUSDT / BTC/USDT)
    """
    if ":" in instrument_key:
        iid, sym = _resolve(instrument_key, None)
    else:
        iid, sym = _resolve(None, instrument_key)
    return await _build(iid, sym, timeframe, run_analysis)


@router.post("/advice", response_model=TradingAdvice)
async def post_advice(body: AdviceRequest):
    iid, sym = _resolve(body.instrument_id, body.symbol)
    return await _build(iid, sym, body.timeframe, body.run_analysis)


async def _build(instrument_id: str, symbol: str, timeframe: str, run_analysis: bool) -> TradingAdvice:
    analysis = ai_orchestrator.get_latest(instrument_id)
    if run_analysis or analysis is None:
        analysis = await ai_orchestrator.run(
            instrument_id=instrument_id,
            symbol=symbol,
            trigger="advice",
            timeframe=timeframe,
        )

    snap = feature_engine.get_latest(instrument_id, timeframe)
    last_price = None
    if snap and snap.features.get("close") is not None:
        last_price = float(snap.features["close"])

    has_long = has_short = False
    try:
        for p in paper_execution.list_positions():
            if p.instrument_id == instrument_id:
                if p.side == "long":
                    has_long = True
                elif p.side == "short":
                    has_short = True
    except Exception:
        pass

    return build_trading_advice(
        instrument_id=instrument_id,
        symbol=symbol,
        analysis=analysis,
        snapshot=snap,
        last_price=last_price,
        has_open_long=has_long,
        has_open_short=has_short,
        risk_limits=risk_engine.limits,
    )
