from fastapi import APIRouter, HTTPException

from app.execution.models import OrderRequest
from app.main import paper_execution

router = APIRouter(tags=["execution"])


@router.post("/orders")
async def place_order(body: OrderRequest):
    order = await paper_execution.submit(body)
    return order.model_dump()


@router.get("/orders")
async def list_orders():
    return [o.model_dump() for o in paper_execution.list_orders()]


@router.get("/orders/{order_id}")
async def get_order(order_id: str):
    o = paper_execution.get_order(order_id)
    if not o:
        raise HTTPException(status_code=404, detail="order not found")
    return o.model_dump()


@router.get("/positions")
async def list_positions():
    return [p.model_dump() for p in paper_execution.list_positions()]


@router.get("/fills")
async def list_fills():
    return [f.model_dump() for f in paper_execution.list_fills()]


@router.get("/portfolio")
async def get_portfolio():
    return paper_execution.portfolio().model_dump()
