"""Multi-timeframe indicator + oversold/overbought analysis API."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query

from app.data.klines import SUPPORTED_INTERVALS, fetch_binance_klines
from app.quant.indicators.analysis import IndicatorReport, analyze_bars

router = APIRouter(tags=["indicators"])


@router.get("/timeframes")
async def list_timeframes():
    return {
        "intervals": sorted(SUPPORTED_INTERVALS, key=lambda x: (
            {"1m": 1, "3m": 3, "5m": 5, "15m": 15, "30m": 30, "1h": 60, "2h": 120,
             "4h": 240, "6h": 360, "12h": 720, "1d": 1440, "1w": 10080}.get(x, 9999)
        )),
        "default": "15m",
    }


@router.get("/indicators/{symbol}", response_model=IndicatorReport)
async def get_indicators(
    symbol: str,
    timeframe: str = Query("15m", description="1m/5m/15m/1h/4h/1d/..."),
    limit: int = Query(200, ge=30, le=500),
    rsi_period: int = Query(14, ge=2, le=50),
    rsi_oversold: float = Query(30.0, ge=1, le=40),
    rsi_overbought: float = Query(70.0, ge=60, le=99),
):
    """
    Switch period via `timeframe`. Returns RSI/MACD/Bollinger/SMA/EMA,
    oversold/overbought states, and active signals for that period.
    """
    tf = timeframe.strip().lower()
    if tf not in SUPPORTED_INTERVALS:
        raise HTTPException(
            status_code=400,
            detail=f"unsupported timeframe '{tf}', choose from {sorted(SUPPORTED_INTERVALS)}",
        )

    raw = symbol.upper().replace("/", "").replace("-", "")
    instrument_id = f"binance:{raw}"
    display = symbol if "/" in symbol else (raw[:-4] + "/USDT" if raw.endswith("USDT") else raw)

    try:
        bars = await fetch_binance_klines(raw, interval=tf, limit=limit)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"kline fetch failed: {exc}") from exc

    if len(bars) < 30:
        raise HTTPException(status_code=422, detail="not enough bars for indicators")

    return analyze_bars(
        instrument_id=instrument_id,
        symbol=display,
        timeframe=tf,
        bars=bars,
        rsi_period=rsi_period,
        rsi_os=rsi_oversold,
        rsi_ob=rsi_overbought,
    )


@router.get("/signals/{symbol}")
async def get_signals_for_timeframe(
    symbol: str,
    timeframe: str = Query("15m"),
    limit: int = Query(200, ge=30, le=500),
):
    """Convenience: only active signals (oversold/overbought/macd/bb/volume) for period."""
    report = await get_indicators(symbol, timeframe=timeframe, limit=limit)
    return {
        "instrument_id": report.instrument_id,
        "symbol": report.symbol,
        "timeframe": report.timeframe,
        "last_price": report.last_price,
        "summary": report.summary,
        "oscillators": [o.model_dump() for o in report.oscillators],
        "signals": report.active_signals,
    }
