"""Fetch OHLCV klines for an arbitrary timeframe (crypto first).

Uses Binance public REST so indicator analysis can switch period without
depending only on the live 1m WebSocket window.
"""

from __future__ import annotations

from typing import Any

import httpx

# Binance USD-M futures interval whitelist
SUPPORTED_INTERVALS = {
    "1m",
    "3m",
    "5m",
    "15m",
    "30m",
    "1h",
    "2h",
    "4h",
    "6h",
    "12h",
    "1d",
    "1w",
}

BINANCE_FUTURES_KLINES = "https://fapi.binance.com/fapi/v1/klines"


async def fetch_binance_klines(
    symbol: str,
    interval: str = "15m",
    limit: int = 200,
) -> list[dict[str, Any]]:
    """
    Returns list of bars:
      open, high, low, close, volume, open_time, close_time
    symbol: BTCUSDT or BTC/USDT
    """
    if interval not in SUPPORTED_INTERVALS:
        raise ValueError(f"unsupported interval {interval}; use one of {sorted(SUPPORTED_INTERVALS)}")

    raw_sym = symbol.upper().replace("/", "").replace("-", "")
    limit = max(10, min(limit, 1500))

    params = {"symbol": raw_sym, "interval": interval, "limit": limit}
    async with httpx.AsyncClient(timeout=15.0) as client:
        resp = await client.get(BINANCE_FUTURES_KLINES, params=params)
        resp.raise_for_status()
        data = resp.json()

    bars: list[dict[str, Any]] = []
    for row in data:
        # [open_time, o, h, l, c, vol, close_time, ...]
        bars.append(
            {
                "open_time": int(row[0]),
                "open": float(row[1]),
                "high": float(row[2]),
                "low": float(row[3]),
                "close": float(row[4]),
                "volume": float(row[5]),
                "close_time": int(row[6]),
            }
        )
    return bars
