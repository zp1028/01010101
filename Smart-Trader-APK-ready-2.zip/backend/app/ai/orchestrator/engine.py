"""AI Orchestrator — builds structured AnalysisResult from quant context.

V1 uses deterministic TechnicalAgent (features + signals). Hooks are ready
for real LLM agents (News / Sentiment / Macro / Bull-Bear Debate) later.
Never emits free-text BUY/SELL as the sole decision — only structured result.
"""

from __future__ import annotations

import time
import uuid
from typing import Any

from app.ai.agents.technical import analyze_technical
from app.ai.models import AnalysisResult, EvidenceItem, Scenario
from app.core.event_bus import EventBus
from app.core.events import (
    AIAnalysisCompletedEvent,
    AIAnalysisStartedEvent,
    AttentionEvent,
    ObservationTriggeredEvent,
    SignalEvent,
)
from app.quant.attention.engine import AttentionEngine
from app.quant.features.engine import FeatureEngine
from app.quant.signals.engine import SignalEngine


class AIOrchestrator:
    def __init__(
        self,
        bus: EventBus,
        feature_engine: FeatureEngine,
        signal_engine: SignalEngine,
        attention_engine: AttentionEngine | None = None,
        *,
        auto_on_attention: bool = True,
        attention_threshold: float = 0.55,
        auto_on_observation: bool = True,
    ):
        self.bus = bus
        self.features = feature_engine
        self.signals = signal_engine
        self.attention = attention_engine
        self.auto_on_attention = auto_on_attention
        self.attention_threshold = attention_threshold
        self.auto_on_observation = auto_on_observation
        self._history: dict[str, list[AnalysisResult]] = {}
        self._latest: dict[str, AnalysisResult] = {}

    def subscribe(self) -> None:
        if self.auto_on_attention:
            self.bus.subscribe(AttentionEvent, self.on_attention)
        if self.auto_on_observation:
            self.bus.subscribe(ObservationTriggeredEvent, self.on_observation)

    async def on_attention(self, event: AttentionEvent) -> None:
        if event.score < self.attention_threshold:
            return
        await self.run(
            instrument_id=event.instrument_id,
            symbol=event.symbol,
            trigger="attention",
            timeframe="1m",
            extra_context={"attention_score": event.score, "regime": event.regime},
        )

    async def on_observation(self, event: ObservationTriggeredEvent) -> None:
        await self.run(
            instrument_id=event.instrument_id,
            symbol=event.symbol,
            trigger="observation",
            timeframe="1m",
            extra_context={
                "observation_id": event.observation_id,
                "trigger_value": event.trigger_value,
                "current_value": event.current_value,
            },
        )

    async def run(
        self,
        instrument_id: str,
        symbol: str,
        *,
        trigger: str = "manual",
        timeframe: str = "1m",
        extra_context: dict[str, Any] | None = None,
    ) -> AnalysisResult:
        analysis_id = str(uuid.uuid4())
        started = int(time.time() * 1000)

        await self.bus.publish(
            AIAnalysisStartedEvent(
                instrument_id=instrument_id,
                symbol=symbol,
                analysis_id=analysis_id,
                trigger=trigger,
                started_at=started,
            )
        )

        snap = self.features.get_latest(instrument_id, timeframe)
        # collect recent signals for this instrument from signal engine cache
        recent_signals: list[SignalEvent] = []
        for name in (
            "rsi_oversold",
            "rsi_overbought",
            "macd_bullish",
            "macd_bearish",
            "bb_lower_touch",
            "bb_upper_touch",
            "volume_spike",
        ):
            s = self.signals.get_latest(instrument_id, name)
            if s:
                recent_signals.append(s)

        technical, bull, bear, evidence, trend, conf = analyze_technical(snap, recent_signals)

        # support / resistance from bollinger if present
        support: list[float] = []
        resistance: list[float] = []
        if snap:
            bl = snap.features.get("bb_lower")
            bu = snap.features.get("bb_upper")
            mid = snap.features.get("bb_mid")
            if bl:
                support.append(float(bl))
            if mid:
                support.append(float(mid))
                resistance.append(float(mid))
            if bu:
                resistance.append(float(bu))

        # data quality: based on feature completeness
        data_quality = 0.0
        if snap:
            keys = ["close", "rsi_14", "macd", "bb_pct", "volume_ratio"]
            present = sum(1 for k in keys if snap.features.get(k) is not None)
            data_quality = present / len(keys)

        regime = None
        if self.attention:
            att = self.attention.get_latest(instrument_id)
            if att:
                regime = att.regime
                evidence.append(
                    EvidenceItem(
                        source="feature",
                        agent="AttentionEngine",
                        summary=f"attention_score={att.score}, regime={att.regime}",
                        confidence=att.score,
                        raw={"score": att.score, "reasons": att.reasons},
                    )
                )

        scenarios = [
            Scenario(
                name="bull",
                thesis="; ".join(bull) if bull else "暂无明显多头依据",
                probability=0.55 if trend == "bullish" else (0.35 if trend == "mixed" else 0.25),
            ),
            Scenario(
                name="base",
                thesis="延续当前区间震荡，等待更明确的动量确认",
                probability=0.40 if trend == "neutral" else 0.30,
            ),
            Scenario(
                name="bear",
                thesis="; ".join(bear) if bear else "暂无明显空头依据",
                probability=0.55 if trend == "bearish" else (0.35 if trend == "mixed" else 0.25),
            ),
        ]
        # normalize scenario probabilities roughly
        total_p = sum(s.probability for s in scenarios) or 1.0
        for s in scenarios:
            s.probability = round(s.probability / total_p, 3)

        completed = int(time.time() * 1000)
        result = AnalysisResult(
            analysis_id=analysis_id,
            instrument_id=instrument_id,
            symbol=symbol,
            timestamp=completed,
            market_state=regime or "unknown",
            trend=trend,
            technical=technical,
            money_flow={"volume_ratio": technical.get("volume_ratio")},
            sentiment={},
            macro={},
            bull_case=bull,
            bear_case=bear,
            support=support,
            resistance=resistance,
            scenarios=scenarios,
            risk={
                "note": "AI output is advisory only; Risk Engine must validate any action",
                "data_quality": data_quality,
            },
            confidence=round(conf * (0.5 + 0.5 * data_quality), 3),
            data_quality=round(data_quality, 3),
            evidence=evidence,
            trigger=trigger,
            regime=regime,
        )

        self._latest[instrument_id] = result
        self._history.setdefault(instrument_id, []).append(result)
        # keep last 50 per instrument
        if len(self._history[instrument_id]) > 50:
            self._history[instrument_id] = self._history[instrument_id][-50:]

        await self.bus.publish(
            AIAnalysisCompletedEvent(
                instrument_id=instrument_id,
                symbol=symbol,
                analysis_id=analysis_id,
                result=result.model_dump(),
                completed_at=completed,
                duration_ms=completed - started,
                data_quality=result.data_quality,
            )
        )
        return result

    def get_latest(self, instrument_id: str) -> AnalysisResult | None:
        return self._latest.get(instrument_id)

    def get_history(self, instrument_id: str, limit: int = 20) -> list[AnalysisResult]:
        return list(reversed(self._history.get(instrument_id, [])[-limit:]))
