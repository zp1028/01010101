"""Single-instrument trading advice from latest analysis + market state.

Produces actionable long/short entry zones, stops, targets and position
guidance. This is still a *proposal* — RiskEngine must approve before any order.
"""

from __future__ import annotations

import time
from typing import Any, Literal

from pydantic import BaseModel, Field

from app.ai.models import AnalysisResult
from app.quant.features.engine import FeatureSnapshot
from app.risk.models import RiskLimits


class EntryPlan(BaseModel):
    direction: Literal["long", "short", "wait"]
    conviction: float = Field(ge=0.0, le=1.0)
    entry_zone_low: float | None = None
    entry_zone_high: float | None = None
    suggested_entry: float | None = None
    stop_loss: float | None = None
    take_profit_1: float | None = None
    take_profit_2: float | None = None
    risk_reward: float | None = None
    position_pct: float | None = None  # suggested fraction of equity
    rationale: list[str] = Field(default_factory=list)


class PositionAdvice(BaseModel):
    action: Literal["open", "add", "hold", "reduce", "close", "wait"]
    side: Literal["long", "short", "flat"] | None = None
    note: str = ""
    max_position_pct: float | None = None


class TradingAdvice(BaseModel):
    instrument_id: str
    symbol: str
    generated_at: int
    last_price: float | None
    market_bias: str  # bullish | bearish | neutral | mixed
    analysis_id: str | None = None
    entry: EntryPlan
    position: PositionAdvice
    risk_notes: list[str] = Field(default_factory=list)
    disclaimer: str = (
        "建议仅供参考，不构成投资建议。下单前必须通过 Risk Engine 校验。"
    )
    technical_snapshot: dict[str, Any] = Field(default_factory=dict)


def build_trading_advice(
    *,
    instrument_id: str,
    symbol: str,
    analysis: AnalysisResult | None,
    snapshot: FeatureSnapshot | None,
    last_price: float | None = None,
    has_open_long: bool = False,
    has_open_short: bool = False,
    risk_limits: RiskLimits | None = None,
) -> TradingAdvice:
    limits = risk_limits or RiskLimits()
    now = int(time.time() * 1000)

    price = last_price
    tech: dict[str, Any] = {}
    if snapshot:
        tech = dict(snapshot.features)
        if price is None:
            price = snapshot.features.get("close")

    trend = analysis.trend if analysis else "neutral"
    conf = analysis.confidence if analysis else 0.3
    support = list(analysis.support) if analysis else []
    resistance = list(analysis.resistance) if analysis else []

    # enrich support/resistance from bollinger if needed
    if snapshot:
        bl = snapshot.features.get("bb_lower")
        bu = snapshot.features.get("bb_upper")
        mid = snapshot.features.get("bb_mid")
        if bl and bl not in support:
            support.append(float(bl))
        if mid and mid not in support:
            support.append(float(mid))
        if mid and mid not in resistance:
            resistance.append(float(mid))
        if bu and bu not in resistance:
            resistance.append(float(bu))

    support = sorted({round(x, 6) for x in support if x})
    resistance = sorted({round(x, 6) for x in resistance if x})

    rsi = tech.get("rsi_14")
    macd_h = tech.get("macd_hist")
    bb_pct = tech.get("bb_pct")

    direction: Literal["long", "short", "wait"] = "wait"
    rationale: list[str] = []
    conviction = conf

    if trend == "bullish":
        direction = "long"
        rationale.append(f"综合趋势偏多 (confidence={conf:.2f})")
    elif trend == "bearish":
        direction = "short"
        rationale.append(f"综合趋势偏空 (confidence={conf:.2f})")
    elif trend == "mixed":
        direction = "wait"
        rationale.append("多空依据并存，建议观望等待方向明确")
    else:
        direction = "wait"
        rationale.append("趋势中性，暂无明确方向优势")

    # refine with indicators
    if rsi is not None:
        if rsi < 30 and direction != "short":
            direction = "long"
            conviction = max(conviction, 0.55)
            rationale.append(f"RSI={rsi:.1f} 超卖，倾向做多反弹")
        elif rsi > 70 and direction != "long":
            direction = "short"
            conviction = max(conviction, 0.55)
            rationale.append(f"RSI={rsi:.1f} 超买，倾向做空回落")

    if macd_h is not None:
        if macd_h > 0 and direction == "long":
            rationale.append(f"MACD柱为正 ({macd_h:.4f})，动量配合多头")
            conviction = min(1.0, conviction + 0.05)
        elif macd_h < 0 and direction == "short":
            rationale.append(f"MACD柱为负 ({macd_h:.4f})，动量配合空头")
            conviction = min(1.0, conviction + 0.05)

    if bb_pct is not None:
        if bb_pct < 0.1 and direction == "long":
            rationale.append(f"价格接近布林下轨 (pct={bb_pct:.2f})")
        elif bb_pct > 0.9 and direction == "short":
            rationale.append(f"价格接近布林上轨 (pct={bb_pct:.2f})")

    if analysis:
        for b in analysis.bull_case[:3]:
            if direction == "long":
                rationale.append(b)
        for b in analysis.bear_case[:3]:
            if direction == "short":
                rationale.append(b)

    # entry / stop / targets
    entry_low = entry_high = suggested = stop = tp1 = tp2 = None
    rr = None
    pos_pct = None

    if price and price > 0 and direction in ("long", "short"):
        if direction == "long":
            # buy near support or slight pullback
            nearest_sup = max([s for s in support if s <= price], default=price * 0.995)
            entry_low = round(min(nearest_sup, price * 0.998), 6)
            entry_high = round(price, 6)
            suggested = round((entry_low + entry_high) / 2, 6)
            stop = round(min(entry_low * 0.992, price * 0.985), 6)
            # enforce min stop distance
            min_stop = price * (1 - limits.min_stop_distance_pct)
            if stop > min_stop:
                stop = round(min_stop, 6)
            risk = suggested - stop
            tp1 = round(suggested + risk * 1.5, 6)
            tp2 = round(suggested + risk * 2.5, 6)
            if nearest_sup in resistance or (resistance and resistance[0] > price):
                pass
            if resistance:
                above = [r for r in resistance if r > suggested]
                if above:
                    tp1 = min(tp1, above[0])
        else:
            nearest_res = min([r for r in resistance if r >= price], default=price * 1.005)
            entry_high = round(max(nearest_res, price * 1.002), 6)
            entry_low = round(price, 6)
            suggested = round((entry_low + entry_high) / 2, 6)
            stop = round(max(entry_high * 1.008, price * 1.015), 6)
            max_tight = price * (1 + limits.min_stop_distance_pct)
            if stop < max_tight:
                stop = round(max_tight, 6)
            risk = stop - suggested
            tp1 = round(suggested - risk * 1.5, 6)
            tp2 = round(suggested - risk * 2.5, 6)
            if support:
                below = [s for s in support if s < suggested]
                if below:
                    tp1 = max(tp1, below[-1])

        if suggested and stop and suggested != stop:
            risk = abs(suggested - stop)
            reward = abs((tp1 or suggested) - suggested)
            rr = round(reward / risk, 2) if risk > 0 else None

        # position sizing: scale with conviction, cap by risk limits
        base = limits.max_position_pct * 0.5
        pos_pct = round(min(limits.max_position_pct, base * (0.5 + conviction)), 4)
        if conviction < 0.4:
            pos_pct = round(pos_pct * 0.5, 4)
            rationale.append("置信度偏低，建议减小仓位")

    # position management advice
    if has_open_long:
        if direction == "short":
            pos_adv = PositionAdvice(
                action="reduce",
                side="long",
                note="出现空头信号，建议减仓或止盈多单",
                max_position_pct=pos_pct,
            )
        elif direction == "long":
            pos_adv = PositionAdvice(
                action="hold" if conviction < 0.7 else "add",
                side="long",
                note="趋势仍偏多，可持有；高置信时可轻仓加仓",
                max_position_pct=pos_pct,
            )
        else:
            pos_adv = PositionAdvice(action="hold", side="long", note="方向不明，持仓观望")
    elif has_open_short:
        if direction == "long":
            pos_adv = PositionAdvice(
                action="reduce",
                side="short",
                note="出现多头信号，建议减仓或平空",
                max_position_pct=pos_pct,
            )
        elif direction == "short":
            pos_adv = PositionAdvice(
                action="hold" if conviction < 0.7 else "add",
                side="short",
                note="趋势仍偏空，可持有；高置信时可轻仓加仓",
                max_position_pct=pos_pct,
            )
        else:
            pos_adv = PositionAdvice(action="hold", side="short", note="方向不明，持仓观望")
    else:
        if direction == "wait":
            pos_adv = PositionAdvice(action="wait", side="flat", note="暂不建议开仓")
        else:
            pos_adv = PositionAdvice(
                action="open",
                side=direction,
                note=f"可按建议区间尝试{('多' if direction == 'long' else '空')}单，先过风控",
                max_position_pct=pos_pct,
            )

    risk_notes = [
        f"单标的上限 {limits.max_position_pct:.0%}",
        f"最大杠杆 {limits.max_leverage}x",
        f"止损距离建议 ≥ {limits.min_stop_distance_pct:.1%}",
    ]
    if rr is not None and rr < 1.0:
        risk_notes.append(f"当前盈亏比约 {rr}，偏低，可等待更好入场点")

    entry = EntryPlan(
        direction=direction,
        conviction=round(min(1.0, conviction), 3),
        entry_zone_low=entry_low,
        entry_zone_high=entry_high,
        suggested_entry=suggested,
        stop_loss=stop,
        take_profit_1=tp1,
        take_profit_2=tp2,
        risk_reward=rr,
        position_pct=pos_pct,
        rationale=rationale[:8],
    )

    return TradingAdvice(
        instrument_id=instrument_id,
        symbol=symbol,
        generated_at=now,
        last_price=price,
        market_bias=trend,
        analysis_id=analysis.analysis_id if analysis else None,
        entry=entry,
        position=pos_adv,
        risk_notes=risk_notes,
        technical_snapshot={
            k: tech.get(k)
            for k in ("close", "rsi_14", "macd", "macd_hist", "bb_pct", "sma_20", "volume_ratio")
            if tech.get(k) is not None
        },
    )
