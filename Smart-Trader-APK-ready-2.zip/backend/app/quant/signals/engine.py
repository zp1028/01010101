"""Signal Engine — turns FeatureSnapshots into SignalEvents.

Simple, explainable rules for V1. Strategy Registry will replace hard-coded
rules in a later phase; this engine already emits the frozen SignalEvent shape.
"""

from __future__ import annotations

import time
from typing import Any

from app.core.event_bus import EventBus
from app.core.events import CandleEvent, SignalEvent
from app.quant.features.engine import FeatureEngine, FeatureSnapshot


class SignalEngine:
    def __init__(self, bus: EventBus, feature_engine: FeatureEngine):
        self.bus = bus
        self.features = feature_engine
        self._last_signals: dict[str, SignalEvent] = {}

    def subscribe(self) -> None:
        # Re-use candle stream: after FeatureEngine processes the closed bar,
        # we generate signals from the latest snapshot.
        self.bus.subscribe(CandleEvent, self.on_candle)

    async def on_candle(self, event: CandleEvent) -> None:
        if not event.is_closed:
            return
        snap = self.features.get_latest(event.instrument_id, event.interval)
        if snap is None:
            return
        signals = self._evaluate(snap)
        for sig in signals:
            self._last_signals[f"{sig.instrument_id}:{sig.signal_name}"] = sig
            await self.bus.publish(sig)

    def get_latest(self, instrument_id: str, signal_name: str) -> SignalEvent | None:
        return self._last_signals.get(f"{instrument_id}:{signal_name}")

    def _evaluate(self, snap: FeatureSnapshot) -> list[SignalEvent]:
        f = snap.features
        now = int(time.time() * 1000)
        out: list[SignalEvent] = []

        rsi_v = f.get("rsi_14")
        if rsi_v is not None:
            if rsi_v < 30:
                out.append(
                    self._sig(
                        snap,
                        "rsi_oversold",
                        "long",
                        strength=min(1.0, (30 - rsi_v) / 30),
                        features={"rsi_14": rsi_v},
                        now=now,
                    )
                )
            elif rsi_v > 70:
                out.append(
                    self._sig(
                        snap,
                        "rsi_overbought",
                        "short",
                        strength=min(1.0, (rsi_v - 70) / 30),
                        features={"rsi_14": rsi_v},
                        now=now,
                    )
                )

        macd_h = f.get("macd_hist")
        macd_v = f.get("macd")
        macd_s = f.get("macd_signal")
        if macd_h is not None and macd_v is not None and macd_s is not None:
            # simple cross approximation using hist sign
            if macd_h > 0 and macd_v > macd_s:
                out.append(
                    self._sig(
                        snap,
                        "macd_bullish",
                        "long",
                        strength=min(1.0, abs(macd_h) * 10),
                        features={"macd": macd_v, "macd_signal": macd_s, "macd_hist": macd_h},
                        now=now,
                    )
                )
            elif macd_h < 0 and macd_v < macd_s:
                out.append(
                    self._sig(
                        snap,
                        "macd_bearish",
                        "short",
                        strength=min(1.0, abs(macd_h) * 10),
                        features={"macd": macd_v, "macd_signal": macd_s, "macd_hist": macd_h},
                        now=now,
                    )
                )

        bb_pct = f.get("bb_pct")
        if bb_pct is not None:
            if bb_pct < 0.05:
                out.append(
                    self._sig(
                        snap,
                        "bb_lower_touch",
                        "long",
                        strength=min(1.0, (0.05 - bb_pct) / 0.05),
                        features={"bb_pct": bb_pct},
                        now=now,
                    )
                )
            elif bb_pct > 0.95:
                out.append(
                    self._sig(
                        snap,
                        "bb_upper_touch",
                        "short",
                        strength=min(1.0, (bb_pct - 0.95) / 0.05),
                        features={"bb_pct": bb_pct},
                        now=now,
                    )
                )

        vol_ratio = f.get("volume_ratio")
        if vol_ratio is not None and vol_ratio >= 2.0:
            out.append(
                self._sig(
                    snap,
                    "volume_spike",
                    "neutral",
                    strength=min(1.0, vol_ratio / 5.0),
                    features={"volume_ratio": vol_ratio},
                    now=now,
                )
            )

        return out

    def _sig(
        self,
        snap: FeatureSnapshot,
        name: str,
        direction: str,
        strength: float,
        features: dict[str, float],
        now: int,
    ) -> SignalEvent:
        return SignalEvent(
            instrument_id=snap.instrument_id,
            symbol=snap.symbol,
            signal_name=name,
            direction=direction,
            strength=round(min(1.0, max(0.0, strength)), 4),
            timeframe=snap.timeframe,
            features=features,
            source_timestamp=snap.source_close_time,
            generated_at=now,
        )
