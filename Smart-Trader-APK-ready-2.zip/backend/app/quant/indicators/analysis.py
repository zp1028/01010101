"""Full indicator + oversold/overbought report for one symbol @ one timeframe."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field

from app.quant.indicators.basic import bollinger, ema, macd, rsi, sma


class OscillatorState(BaseModel):
    name: str
    value: float | None
    state: Literal["oversold", "overbought", "neutral", "unknown"] = "unknown"
    signal: Literal["long", "short", "none"] = "none"
    note: str = ""


class IndicatorReport(BaseModel):
    instrument_id: str
    symbol: str
    timeframe: str
    bars: int
    last_price: float | None
    last_close_time: int | None

    # core series latest values
    sma_20: float | None = None
    sma_50: float | None = None
    ema_12: float | None = None
    ema_26: float | None = None
    rsi_14: float | None = None
    macd: float | None = None
    macd_signal: float | None = None
    macd_hist: float | None = None
    bb_mid: float | None = None
    bb_upper: float | None = None
    bb_lower: float | None = None
    bb_pct: float | None = None  # 0=lower band, 1=upper
    volume_sma_20: float | None = None
    volume_ratio: float | None = None

    # regime helpers
    trend_sma: Literal["bullish", "bearish", "neutral", "unknown"] = "unknown"
    price_vs_bb: Literal["below_lower", "lower_half", "upper_half", "above_upper", "unknown"] = "unknown"

    oscillators: list[OscillatorState] = Field(default_factory=list)
    active_signals: list[dict[str, Any]] = Field(default_factory=list)
    summary: str = ""


def _last(series: list[float | None]) -> float | None:
    for v in reversed(series):
        if v is not None:
            return float(v)
    return None


def analyze_bars(
    *,
    instrument_id: str,
    symbol: str,
    timeframe: str,
    bars: list[dict[str, Any]],
    rsi_period: int = 14,
    rsi_os: float = 30.0,
    rsi_ob: float = 70.0,
) -> IndicatorReport:
    closes = [float(b["close"]) for b in bars]
    volumes = [float(b.get("volume") or 0) for b in bars]
    n = len(closes)
    last_price = closes[-1] if closes else None
    last_ct = int(bars[-1]["close_time"]) if bars else None

    sma20 = sma(closes, 20)
    sma50 = sma(closes, 50)
    ema12 = ema(closes, 12)
    ema26 = ema(closes, 26)
    rsi_s = rsi(closes, rsi_period)
    macd_line, macd_sig, macd_hist = macd(closes)
    bb_mid, bb_up, bb_lo = bollinger(closes, 20)
    vol_sma = sma(volumes, 20)

    l_sma20 = _last(sma20)
    l_sma50 = _last(sma50)
    l_ema12 = _last(ema12)
    l_ema26 = _last(ema26)
    l_rsi = _last(rsi_s)
    l_macd = _last(macd_line)
    l_msig = _last(macd_sig)
    l_hist = _last(macd_hist)
    l_bbm = _last(bb_mid)
    l_bbu = _last(bb_up)
    l_bbl = _last(bb_lo)
    l_vsma = _last(vol_sma)

    bb_pct = None
    if last_price is not None and l_bbu is not None and l_bbl is not None and l_bbu != l_bbl:
        bb_pct = (last_price - l_bbl) / (l_bbu - l_bbl)

    vol_ratio = None
    if l_vsma and l_vsma > 0 and volumes:
        vol_ratio = volumes[-1] / l_vsma

    # trend by SMA stack
    trend: Literal["bullish", "bearish", "neutral", "unknown"] = "unknown"
    if last_price is not None and l_sma20 is not None and l_sma50 is not None:
        if last_price > l_sma20 > l_sma50:
            trend = "bullish"
        elif last_price < l_sma20 < l_sma50:
            trend = "bearish"
        else:
            trend = "neutral"

    price_vs_bb: Literal["below_lower", "lower_half", "upper_half", "above_upper", "unknown"] = "unknown"
    if bb_pct is not None:
        if bb_pct < 0:
            price_vs_bb = "below_lower"
        elif bb_pct < 0.5:
            price_vs_bb = "lower_half"
        elif bb_pct <= 1.0:
            price_vs_bb = "upper_half"
        else:
            price_vs_bb = "above_upper"

    oscillators: list[OscillatorState] = []
    signals: list[dict[str, Any]] = []

    # RSI oversold / overbought
    if l_rsi is not None:
        if l_rsi < rsi_os:
            st: Literal["oversold", "overbought", "neutral", "unknown"] = "oversold"
            sig: Literal["long", "short", "none"] = "long"
            note = f"RSI({rsi_period})={l_rsi:.1f} < {rsi_os} 超卖"
            signals.append(
                {
                    "name": "rsi_oversold",
                    "direction": "long",
                    "strength": min(1.0, (rsi_os - l_rsi) / rsi_os),
                    "timeframe": timeframe,
                    "value": l_rsi,
                }
            )
        elif l_rsi > rsi_ob:
            st = "overbought"
            sig = "short"
            note = f"RSI({rsi_period})={l_rsi:.1f} > {rsi_ob} 超买"
            signals.append(
                {
                    "name": "rsi_overbought",
                    "direction": "short",
                    "strength": min(1.0, (l_rsi - rsi_ob) / (100 - rsi_ob)),
                    "timeframe": timeframe,
                    "value": l_rsi,
                }
            )
        else:
            st = "neutral"
            sig = "none"
            note = f"RSI({rsi_period})={l_rsi:.1f} 中性区"
        oscillators.append(OscillatorState(name="RSI", value=l_rsi, state=st, signal=sig, note=note))

    # Stochastic-like via Bollinger % as mean-reversion proxy
    if bb_pct is not None:
        if bb_pct < 0.05:
            oscillators.append(
                OscillatorState(
                    name="Bollinger",
                    value=bb_pct,
                    state="oversold",
                    signal="long",
                    note=f"价格贴近/跌破下轨 (bb_pct={bb_pct:.2f})",
                )
            )
            signals.append(
                {
                    "name": "bb_lower_touch",
                    "direction": "long",
                    "strength": min(1.0, max(0.0, 0.15 - bb_pct) / 0.15),
                    "timeframe": timeframe,
                    "value": bb_pct,
                }
            )
        elif bb_pct > 0.95:
            oscillators.append(
                OscillatorState(
                    name="Bollinger",
                    value=bb_pct,
                    state="overbought",
                    signal="short",
                    note=f"价格贴近/突破上轨 (bb_pct={bb_pct:.2f})",
                )
            )
            signals.append(
                {
                    "name": "bb_upper_touch",
                    "direction": "short",
                    "strength": min(1.0, max(0.0, bb_pct - 0.85) / 0.15),
                    "timeframe": timeframe,
                    "value": bb_pct,
                }
            )
        else:
            oscillators.append(
                OscillatorState(
                    name="Bollinger",
                    value=bb_pct,
                    state="neutral",
                    signal="none",
                    note=f"布林带位置 bb_pct={bb_pct:.2f}",
                )
            )

    # MACD momentum
    if l_hist is not None:
        if l_hist > 0:
            oscillators.append(
                OscillatorState(
                    name="MACD",
                    value=l_hist,
                    state="neutral",
                    signal="long",
                    note=f"MACD柱为正 ({l_hist:.6f})，动量偏多",
                )
            )
            signals.append(
                {
                    "name": "macd_bullish",
                    "direction": "long",
                    "strength": 0.55,
                    "timeframe": timeframe,
                    "value": l_hist,
                }
            )
        else:
            oscillators.append(
                OscillatorState(
                    name="MACD",
                    value=l_hist,
                    state="neutral",
                    signal="short",
                    note=f"MACD柱为负 ({l_hist:.6f})，动量偏空",
                )
            )
            signals.append(
                {
                    "name": "macd_bearish",
                    "direction": "short",
                    "strength": 0.55,
                    "timeframe": timeframe,
                    "value": l_hist,
                }
            )

    # volume spike
    if vol_ratio is not None and vol_ratio >= 2.0:
        signals.append(
            {
                "name": "volume_spike",
                "direction": "neutral",
                "strength": min(1.0, vol_ratio / 4.0),
                "timeframe": timeframe,
                "value": vol_ratio,
            }
        )

    # summary
    os_hits = [o for o in oscillators if o.state == "oversold"]
    ob_hits = [o for o in oscillators if o.state == "overbought"]
    parts = [f"{timeframe} 周期", f"趋势(SMA)={trend}"]
    if os_hits:
        parts.append("出现超卖: " + ", ".join(o.name for o in os_hits))
    if ob_hits:
        parts.append("出现超买: " + ", ".join(o.name for o in ob_hits))
    if not os_hits and not ob_hits:
        parts.append("无明显超买超卖")
    summary = "；".join(parts)

    return IndicatorReport(
        instrument_id=instrument_id,
        symbol=symbol,
        timeframe=timeframe,
        bars=n,
        last_price=last_price,
        last_close_time=last_ct,
        sma_20=l_sma20,
        sma_50=l_sma50,
        ema_12=l_ema12,
        ema_26=l_ema26,
        rsi_14=l_rsi,
        macd=l_macd,
        macd_signal=l_msig,
        macd_hist=l_hist,
        bb_mid=l_bbm,
        bb_upper=l_bbu,
        bb_lower=l_bbl,
        bb_pct=round(bb_pct, 4) if bb_pct is not None else None,
        volume_sma_20=l_vsma,
        volume_ratio=round(vol_ratio, 4) if vol_ratio is not None else None,
        trend_sma=trend,
        price_vs_bb=price_vs_bb,
        oscillators=oscillators,
        active_signals=signals,
        summary=summary,
    )
