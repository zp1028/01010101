"""Walk-forward skeleton — train/validate/OOS split helper.

Does not optimize parameters yet; provides the split + sequential run
harness that later phases will plug Hyperopt / grid search into.
"""

from __future__ import annotations

from typing import Any

from app.backtest.models import BacktestConfig, BacktestResult
from app.backtest.vectorized.engine import run_vectorized


def split_bars(
    bars: list[dict[str, Any]],
    train_ratio: float = 0.6,
    val_ratio: float = 0.2,
) -> tuple[list, list, list]:
    n = len(bars)
    t = int(n * train_ratio)
    v = int(n * (train_ratio + val_ratio))
    return bars[:t], bars[t:v], bars[v:]


def run_walk_forward(
    base: BacktestConfig,
    *,
    train_ratio: float = 0.6,
    val_ratio: float = 0.2,
) -> dict[str, Any]:
    train, val, oos = split_bars(base.bars, train_ratio, val_ratio)
    results: dict[str, BacktestResult] = {}
    for name, segment in (("train", train), ("validation", val), ("oos", oos)):
        if len(segment) < 20:
            continue
        cfg = base.model_copy(deep=True)
        cfg.bars = segment
        results[name] = run_vectorized(cfg)
    return {
        "splits": {
            "train_bars": len(train),
            "validation_bars": len(val),
            "oos_bars": len(oos),
        },
        "results": {k: v.model_dump() for k, v in results.items()},
    }
