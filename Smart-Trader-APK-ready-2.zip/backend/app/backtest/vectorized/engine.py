"""Vectorized backtest — fast signal scan on OHLCV arrays.

Uses the same indicator functions as live FeatureEngine for parity.
PIT: signals at bar i only use closes[0..i] (no future bars).
"""

from __future__ import annotations

import time
import uuid
from typing import Any

from app.backtest.models import BacktestConfig, BacktestResult, TradeRecord
from app.quant.indicators.basic import bollinger, macd, rsi


def _apply_slippage(price: float, side: str, bps: float) -> float:
    adj = price * (bps / 10_000.0)
    if side == "long":
        return price + adj  # buy higher
    return price - adj  # sell lower


def run_vectorized(config: BacktestConfig) -> BacktestResult:
    bars = config.bars
    warnings: list[str] = []
    if len(bars) < 30:
        warnings.append("insufficient bars (<30); results may be unstable")

    closes = [float(b["close"]) for b in bars]
    times = [int(b.get("close_time") or b.get("open_time") or i) for i, b in enumerate(bars)]

    # --- generate signals bar-by-bar (causal / PIT) ---
    long_entries = [False] * len(closes)
    long_exits = [False] * len(closes)

    if config.strategy == "rsi":
        period = int(config.strategy_params.get("period", 14))
        low_th = float(config.strategy_params.get("low", 30))
        high_th = float(config.strategy_params.get("high", 70))
        series = rsi(closes, period)
        for i, v in enumerate(series):
            if v is None:
                continue
            if v < low_th:
                long_entries[i] = True
            elif v > high_th:
                long_exits[i] = True

    elif config.strategy == "macd":
        line, sig, hist = macd(closes)
        for i in range(1, len(closes)):
            if hist[i] is None or hist[i - 1] is None:
                continue
            if hist[i - 1] <= 0 < hist[i]:
                long_entries[i] = True
            elif hist[i - 1] >= 0 > hist[i]:
                long_exits[i] = True

    elif config.strategy == "bb":
        mid, upper, lower = bollinger(closes, int(config.strategy_params.get("period", 20)))
        for i, c in enumerate(closes):
            if lower[i] is not None and c <= lower[i]:
                long_entries[i] = True
            if upper[i] is not None and c >= upper[i]:
                long_exits[i] = True

    elif config.strategy == "buy_hold":
        if closes:
            long_entries[0] = True
            # exit on last bar handled below

    # --- simulate positions ---
    cash = config.initial_cash
    position_qty = 0.0
    entry_price = 0.0
    entry_time = 0
    trades: list[TradeRecord] = []
    equity_curve: list[dict[str, Any]] = []
    peak = cash
    max_dd = 0.0

    for i, c in enumerate(closes):
        t = times[i]
        # exit first
        if position_qty > 0 and (long_exits[i] or (config.strategy == "buy_hold" and i == len(closes) - 1)):
            px = _apply_slippage(c, "short", config.slippage_bps)
            proceeds = position_qty * px
            fee = proceeds * config.fee_rate
            cash += proceeds - fee
            pnl = (px - entry_price) * position_qty - fee
            pnl_pct = (px / entry_price - 1.0) * 100 if entry_price else 0.0
            trades.append(
                TradeRecord(
                    entry_time=entry_time,
                    exit_time=t,
                    side="long",
                    entry_price=entry_price,
                    exit_price=px,
                    quantity=position_qty,
                    pnl=round(pnl, 4),
                    pnl_pct=round(pnl_pct, 4),
                    fee=round(fee, 4),
                )
            )
            position_qty = 0.0

        # entry
        if position_qty == 0 and long_entries[i] and i < len(closes) - 1:
            px = _apply_slippage(c, "long", config.slippage_bps)
            fee = cash * config.fee_rate
            spendable = cash - fee
            if spendable > 0 and px > 0:
                qty = spendable / px
                cost = qty * px + fee
                if cost <= cash:
                    cash -= cost
                    position_qty = qty
                    entry_price = px
                    entry_time = t

        equity = cash + position_qty * c
        peak = max(peak, equity)
        dd = (peak - equity) / peak if peak > 0 else 0.0
        max_dd = max(max_dd, dd)
        equity_curve.append({"time": t, "equity": round(equity, 4)})

    # force close
    if position_qty > 0:
        c = closes[-1]
        t = times[-1]
        px = _apply_slippage(c, "short", config.slippage_bps)
        proceeds = position_qty * px
        fee = proceeds * config.fee_rate
        cash += proceeds - fee
        pnl = (px - entry_price) * position_qty - fee
        pnl_pct = (px / entry_price - 1.0) * 100 if entry_price else 0.0
        trades.append(
            TradeRecord(
                entry_time=entry_time,
                exit_time=t,
                side="long",
                entry_price=entry_price,
                exit_price=px,
                quantity=position_qty,
                pnl=round(pnl, 4),
                pnl_pct=round(pnl_pct, 4),
                fee=round(fee, 4),
            )
        )
        position_qty = 0.0

    final_equity = cash
    total_ret = (final_equity / config.initial_cash - 1.0) * 100 if config.initial_cash else 0.0
    wins = [t for t in trades if t.pnl is not None and t.pnl > 0]
    win_rate = len(wins) / len(trades) if trades else None

    return BacktestResult(
        run_id=str(uuid.uuid4()),
        config_summary={
            "instrument_id": config.instrument_id,
            "symbol": config.symbol,
            "strategy": config.strategy,
            "strategy_params": config.strategy_params,
            "bars": len(bars),
            "fee_rate": config.fee_rate,
            "slippage_bps": config.slippage_bps,
        },
        engine="vectorized",
        initial_cash=config.initial_cash,
        final_equity=round(final_equity, 4),
        total_return_pct=round(total_ret, 4),
        max_drawdown_pct=round(max_dd * 100, 4),
        trade_count=len(trades),
        win_rate=round(win_rate, 4) if win_rate is not None else None,
        trades=trades,
        equity_curve=equity_curve[:: max(1, len(equity_curve) // 200)],  # downsample
        metrics={
            "avg_trade_pnl": round(
                sum(t.pnl or 0 for t in trades) / len(trades), 4
            )
            if trades
            else 0.0,
        },
        pit_enforced=config.enforce_pit,
        warnings=warnings,
    )
