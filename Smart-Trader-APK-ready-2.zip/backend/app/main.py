from contextlib import asynccontextmanager

from fastapi import FastAPI

from app.ai.orchestrator.engine import AIOrchestrator
from app.risk.engine import RiskEngine
from app.execution.paper import PaperExecutionEngine
from app.api.v1.analysis import router as analysis_router
from app.api.v1.advice import router as advice_router
from app.api.v1.indicators import router as indicators_router
from app.api.v1.backtests import router as backtests_router
from app.api.v1.risk import router as risk_router
from app.api.v1.execution import router as execution_router
from app.api.v1.markets import router as markets_router
from app.api.v1.observations import router as observations_router
from app.api.v1.websocket import router as ws_router
from app.core.config import settings
from app.core.event_bus import EventBus
from app.db.session import init_db
from app.models.instrument import InstrumentRegistry
from app.providers.crypto.binance.ws import BinanceWsClient
from app.providers.registry import ProviderRegistry
from app.quant.attention.engine import AttentionEngine
from app.quant.features.engine import FeatureEngine
from app.quant.observation.engine import ObservationEngine
from app.quant.signals.engine import SignalEngine
from app.repositories.instrument_repo import load_all_into_registry, upsert_instrument

bus = EventBus()
instruments = InstrumentRegistry()
registry = ProviderRegistry()
binance = BinanceWsClient(settings, bus, instruments)

feature_engine = FeatureEngine(bus)
signal_engine = SignalEngine(bus, feature_engine)
attention_engine = AttentionEngine(bus)
observation_engine = ObservationEngine(bus)
risk_engine = RiskEngine(bus)
paper_execution = PaperExecutionEngine(bus, risk_engine)

ai_orchestrator = AIOrchestrator(
    bus,
    feature_engine,
    signal_engine,
    attention_engine,
    auto_on_attention=True,
    attention_threshold=0.55,
    auto_on_observation=True,
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    try:
        init_db()
        loaded = load_all_into_registry(instruments)
        print(f"[startup] database ready, loaded {loaded} instruments")
    except Exception as exc:
        print(f"[startup] database init skipped/failed: {exc}")

    feature_engine.subscribe()
    signal_engine.subscribe()
    attention_engine.subscribe()
    observation_engine.subscribe()
    ai_orchestrator.subscribe()
    paper_execution.subscribe()

    registry.register("binance", binance)
    await binance.start()

    try:
        for inst in instruments.list_all():
            upsert_instrument(inst)
    except Exception as exc:
        print(f"[startup] instrument persist skipped: {exc}")

    yield
    await binance.stop()


app = FastAPI(title="Smart Trader API", version="1.0.2", lifespan=lifespan)
app.include_router(markets_router, prefix="/api/v1")
app.include_router(observations_router, prefix="/api/v1")
app.include_router(analysis_router, prefix="/api/v1")
app.include_router(advice_router, prefix="/api/v1")
app.include_router(indicators_router, prefix="/api/v1")
app.include_router(backtests_router, prefix="/api/v1")
app.include_router(risk_router, prefix="/api/v1")
app.include_router(execution_router, prefix="/api/v1")
app.include_router(ws_router, prefix="/api/v1")


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "version": "1.0.2",
        "provider": binance.health.model_dump(),
        "symbols": sorted(binance.subscriptions),
        "instruments": [i.model_dump() for i in instruments.list_all()],
        "database_url_scheme": settings.database_url.split("://")[0],
        "quant": {
            "feature_engine": True,
            "signal_engine": True,
            "attention_engine": True,
            "observation_engine": True,
            "ai_orchestrator": True,
            "backtest": True,
            "risk_engine": True,
            "paper_execution": True,
            "trading_advice": True,
            "indicators_mtf": True,
            "attention_top": [
                {"symbol": e.symbol, "score": e.score, "regime": e.regime}
                for e in attention_engine.ranking(5)
            ],
            "observation_count": len(observation_engine.list_all()),
        },
    }
