"""Execution domain models — orders, fills, positions."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


OrderSide = Literal["buy", "sell"]
OrderType = Literal["market", "limit"]
OrderStatus = Literal["pending", "submitted", "filled", "partially_filled", "rejected", "cancelled"]


class OrderRequest(BaseModel):
    instrument_id: str
    symbol: str
    side: OrderSide
    order_type: OrderType = "market"
    quantity: float | None = None
    position_pct: float | None = None  # alternative to quantity
    limit_price: float | None = None
    stop_price: float | None = None
    leverage: float = 1.0
    reason: str = ""
    source: str = "manual"


class Order(BaseModel):
    order_id: str
    instrument_id: str
    symbol: str
    side: OrderSide
    order_type: OrderType
    quantity: float
    limit_price: float | None = None
    stop_price: float | None = None
    leverage: float = 1.0
    status: OrderStatus = "pending"
    filled_quantity: float = 0.0
    avg_fill_price: float | None = None
    reject_reason: str | None = None
    created_at: int = 0
    updated_at: int = 0
    source: str = "manual"
    risk_decision: dict[str, Any] | None = None


class Fill(BaseModel):
    fill_id: str
    order_id: str
    instrument_id: str
    symbol: str
    side: OrderSide
    price: float
    quantity: float
    fee: float = 0.0
    filled_at: int = 0


class Position(BaseModel):
    instrument_id: str
    symbol: str
    side: Literal["long", "short", "flat"] = "flat"
    quantity: float = 0.0
    entry_price: float = 0.0
    unrealized_pnl: float = 0.0
    realized_pnl: float = 0.0
    notional: float = 0.0
    updated_at: int = 0


class PortfolioSnapshot(BaseModel):
    account_id: str = "paper"
    cash: float
    equity: float
    used_margin: float = 0.0
    positions: list[Position] = Field(default_factory=list)
    open_orders: list[Order] = Field(default_factory=list)
    realized_pnl: float = 0.0
