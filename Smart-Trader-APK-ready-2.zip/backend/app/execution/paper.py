"""Paper trading execution — simulates fills after mandatory Risk validation.

Flow:
  OrderRequest → size resolution → TradeProposal → RiskEngine.validate
              → reject OR submit → market fill (last price) → Position update
"""

from __future__ import annotations

import time
import uuid
from typing import Any

from app.core.event_bus import EventBus
from app.core.events import (
    MarketTickEvent,
    OrderFilledEvent,
    OrderRejectedEvent,
    OrderSubmittedEvent,
    PositionChangedEvent,
)
from app.execution.models import (
    Fill,
    Order,
    OrderRequest,
    PortfolioSnapshot,
    Position,
)
from app.risk.engine import RiskEngine
from app.risk.models import TradeProposal


class PaperExecutionEngine:
    def __init__(
        self,
        bus: EventBus,
        risk_engine: RiskEngine,
        *,
        initial_cash: float = 10_000.0,
        fee_rate: float = 0.0004,
        slippage_bps: float = 1.0,
    ):
        self.bus = bus
        self.risk = risk_engine
        self.fee_rate = fee_rate
        self.slippage_bps = slippage_bps
        self.cash = initial_cash
        self.initial_cash = initial_cash
        self._orders: dict[str, Order] = {}
        self._fills: list[Fill] = []
        self._positions: dict[str, Position] = {}
        self._last_price: dict[str, float] = {}
        self.realized_pnl = 0.0

        # keep risk account in sync
        self.risk.update_account(
            equity=initial_cash,
            cash=initial_cash,
            open_positions=[],
        )

    def subscribe(self) -> None:
        self.bus.subscribe(MarketTickEvent, self.on_tick)

    async def on_tick(self, event: MarketTickEvent) -> None:
        if event.last is not None:
            self._last_price[event.instrument_id] = event.last
            self._mark_position(event.instrument_id, event.last)

    def _mark_position(self, instrument_id: str, price: float) -> None:
        pos = self._positions.get(instrument_id)
        if not pos or pos.quantity == 0:
            return
        if pos.side == "long":
            pos.unrealized_pnl = (price - pos.entry_price) * pos.quantity
        elif pos.side == "short":
            pos.unrealized_pnl = (pos.entry_price - price) * pos.quantity
        pos.notional = abs(pos.quantity * price)
        pos.updated_at = int(time.time() * 1000)
        self._sync_risk_account()

    def _equity(self) -> float:
        upnl = sum(p.unrealized_pnl for p in self._positions.values())
        return self.cash + upnl

    def _sync_risk_account(self) -> None:
        open_pos = []
        for p in self._positions.values():
            if p.quantity > 0:
                open_pos.append(
                    {
                        "instrument_id": p.instrument_id,
                        "side": p.side,
                        "quantity": p.quantity,
                        "entry_price": p.entry_price,
                        "notional": p.notional,
                    }
                )
        self.risk.update_account(
            equity=self._equity(),
            cash=self.cash,
            open_positions=open_pos,
        )

    def _resolve_qty(self, req: OrderRequest, price: float) -> float:
        if req.quantity and req.quantity > 0:
            return req.quantity
        if req.position_pct and req.position_pct > 0 and price > 0:
            return (self._equity() * req.position_pct) / price
        return 0.0

    def _slip(self, price: float, side: str) -> float:
        adj = price * (self.slippage_bps / 10_000.0)
        return price + adj if side == "buy" else price - adj

    async def submit(self, req: OrderRequest) -> Order:
        now = int(time.time() * 1000)
        order_id = str(uuid.uuid4())
        price = req.limit_price or self._last_price.get(req.instrument_id)
        if price is None or price <= 0:
            order = Order(
                order_id=order_id,
                instrument_id=req.instrument_id,
                symbol=req.symbol,
                side=req.side,
                order_type=req.order_type,
                quantity=req.quantity or 0,
                status="rejected",
                reject_reason="no market price available",
                created_at=now,
                updated_at=now,
                source=req.source,
            )
            self._orders[order_id] = order
            await self.bus.publish(
                OrderRejectedEvent(
                    order_id=order_id,
                    instrument_id=req.instrument_id,
                    reason=order.reject_reason or "",
                    rejected_at=now,
                )
            )
            return order

        qty = self._resolve_qty(req, price)
        if qty <= 0:
            order = Order(
                order_id=order_id,
                instrument_id=req.instrument_id,
                symbol=req.symbol,
                side=req.side,
                order_type=req.order_type,
                quantity=0,
                status="rejected",
                reject_reason="quantity/position_pct required",
                created_at=now,
                updated_at=now,
                source=req.source,
            )
            self._orders[order_id] = order
            return order

        # --- mandatory Risk gate ---
        side_risk = "long" if req.side == "buy" else "short"
        # selling existing long → flat/reduce, treat as long exit for risk simplicity
        pos = self._positions.get(req.instrument_id)
        if req.side == "sell" and pos and pos.side == "long":
            side_risk = "flat"

        proposal = TradeProposal(
            instrument_id=req.instrument_id,
            symbol=req.symbol,
            side=side_risk if side_risk != "flat" else "flat",
            entry_price=price,
            stop_price=req.stop_price,
            position_pct=req.position_pct,
            quantity=qty if side_risk != "flat" else 0,
            leverage=req.leverage,
            reason=req.reason,
            source=req.source,
        )
        decision = await self.risk.validate_and_publish(proposal)

        if not decision.approved and side_risk != "flat":
            # allow reduce/close even if new risk blocked
            order = Order(
                order_id=order_id,
                instrument_id=req.instrument_id,
                symbol=req.symbol,
                side=req.side,
                order_type=req.order_type,
                quantity=qty,
                status="rejected",
                reject_reason="; ".join(v.message for v in decision.violations) or "risk rejected",
                created_at=now,
                updated_at=now,
                source=req.source,
                risk_decision=decision.model_dump(),
            )
            self._orders[order_id] = order
            await self.bus.publish(
                OrderRejectedEvent(
                    order_id=order_id,
                    instrument_id=req.instrument_id,
                    reason=order.reject_reason or "risk",
                    rejected_at=now,
                )
            )
            return order

        # use adjusted size if risk clipped
        if decision.adjusted and decision.adjusted.quantity and side_risk != "flat":
            qty = decision.adjusted.quantity

        order = Order(
            order_id=order_id,
            instrument_id=req.instrument_id,
            symbol=req.symbol,
            side=req.side,
            order_type=req.order_type,
            quantity=qty,
            limit_price=req.limit_price,
            stop_price=req.stop_price,
            leverage=req.leverage,
            status="submitted",
            created_at=now,
            updated_at=now,
            source=req.source,
            risk_decision=decision.model_dump(),
        )
        self._orders[order_id] = order
        await self.bus.publish(
            OrderSubmittedEvent(
                order_id=order_id,
                instrument_id=req.instrument_id,
                side=req.side,
                quantity=qty,
                order_type=req.order_type,
                submitted_at=now,
            )
        )

        # paper market fill immediately
        return await self._fill_market(order, price)

    async def _fill_market(self, order: Order, ref_price: float) -> Order:
        now = int(time.time() * 1000)
        fill_price = self._slip(ref_price, order.side)
        fee = order.quantity * fill_price * self.fee_rate
        fill = Fill(
            fill_id=str(uuid.uuid4()),
            order_id=order.order_id,
            instrument_id=order.instrument_id,
            symbol=order.symbol,
            side=order.side,
            price=fill_price,
            quantity=order.quantity,
            fee=fee,
            filled_at=now,
        )
        self._fills.append(fill)

        order.status = "filled"
        order.filled_quantity = order.quantity
        order.avg_fill_price = fill_price
        order.updated_at = now

        await self._apply_fill(fill)
        await self.bus.publish(
            OrderFilledEvent(
                order_id=order.order_id,
                instrument_id=order.instrument_id,
                fill_price=fill_price,
                fill_quantity=order.quantity,
                filled_at=now,
            )
        )
        return order

    async def _apply_fill(self, fill: Fill) -> None:
        now = fill.filled_at
        pos = self._positions.get(fill.instrument_id) or Position(
            instrument_id=fill.instrument_id,
            symbol=fill.symbol,
        )
        if fill.side == "buy":
            cost = fill.quantity * fill.price + fill.fee
            if pos.quantity > 0 and pos.side == "long":
                # average up
                total_qty = pos.quantity + fill.quantity
                pos.entry_price = (
                    pos.entry_price * pos.quantity + fill.price * fill.quantity
                ) / total_qty
                pos.quantity = total_qty
            else:
                pos.side = "long"
                pos.quantity = fill.quantity
                pos.entry_price = fill.price
            self.cash -= cost
        else:  # sell
            proceeds = fill.quantity * fill.price - fill.fee
            if pos.side == "long" and pos.quantity > 0:
                closed = min(pos.quantity, fill.quantity)
                pnl = (fill.price - pos.entry_price) * closed - fill.fee
                self.realized_pnl += pnl
                pos.quantity -= closed
                if pos.quantity <= 1e-12:
                    pos.quantity = 0
                    pos.side = "flat"
                    pos.entry_price = 0
                    pos.unrealized_pnl = 0
            else:
                # open short (if allowed by risk already)
                pos.side = "short"
                pos.quantity = fill.quantity
                pos.entry_price = fill.price
            self.cash += proceeds

        pos.notional = abs(pos.quantity * fill.price)
        pos.updated_at = now
        self._positions[fill.instrument_id] = pos
        self._sync_risk_account()

        await self.bus.publish(
            PositionChangedEvent(
                instrument_id=pos.instrument_id,
                symbol=pos.symbol,
                side=pos.side,
                quantity=pos.quantity,
                entry_price=pos.entry_price or None,
                unrealized_pnl=pos.unrealized_pnl,
                changed_at=now,
            )
        )

    def get_order(self, order_id: str) -> Order | None:
        return self._orders.get(order_id)

    def list_orders(self) -> list[Order]:
        return list(self._orders.values())

    def list_positions(self) -> list[Position]:
        return [p for p in self._positions.values() if p.quantity > 0]

    def list_fills(self) -> list[Fill]:
        return list(self._fills)

    def portfolio(self) -> PortfolioSnapshot:
        return PortfolioSnapshot(
            account_id="paper",
            cash=round(self.cash, 4),
            equity=round(self._equity(), 4),
            positions=self.list_positions(),
            open_orders=[o for o in self._orders.values() if o.status in ("pending", "submitted")],
            realized_pnl=round(self.realized_pnl, 4),
        )
