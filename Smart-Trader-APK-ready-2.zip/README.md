# Smart Trader v1.0.2

Quant + AI 分析 + 多周期超买超卖 + 入场建议 + Risk + 纸交易 + Android

## 构建 APK（安装包）

### 快速

```bash
# 1. 配置 SDK
cd android
cp local.properties.example local.properties
# 编辑 sdk.dir=你的 Android SDK 路径

# 2. 编译
chmod +x gradlew
./gradlew assembleDebug

# 3. 安装
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

或使用脚本（自动探测 `ANDROID_HOME`）：

```bash
./scripts/build-apk.sh
```

详细说明：**[docs/BUILD_APK.md](docs/BUILD_APK.md)**  
GitHub：推送后 Actions 会产出 Debug APK Artifact。

### 后端

```bash
cd backend && pip install -e ".[dev]"
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

真机改 `ApiConfig.baseUrl` 为电脑局域网 IP。

## 主要 API

- `GET /api/v1/indicators/BTCUSDT?timeframe=15m` — 多周期指标 / 超买超卖  
- `GET /api/v1/advice/BTCUSDT` — 多空入场与持仓建议  
- `WS /api/v1/ws/market` — 实时行情  
