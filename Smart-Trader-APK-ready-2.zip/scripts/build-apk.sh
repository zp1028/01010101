#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT/android"

if [[ ! -f local.properties ]]; then
  if [[ -n "${ANDROID_HOME:-}" ]]; then
    echo "sdk.dir=${ANDROID_HOME}" > local.properties
  elif [[ -n "${ANDROID_SDK_ROOT:-}" ]]; then
    echo "sdk.dir=${ANDROID_SDK_ROOT}" > local.properties
  elif [[ -d "$HOME/Library/Android/sdk" ]]; then
    echo "sdk.dir=$HOME/Library/Android/sdk" > local.properties
  elif [[ -d "$HOME/Android/Sdk" ]]; then
    echo "sdk.dir=$HOME/Android/Sdk" > local.properties
  else
    echo "ERROR: create android/local.properties with sdk.dir=..."
    echo "See android/local.properties.example"
    exit 1
  fi
  echo "Wrote local.properties from detected SDK"
fi

chmod +x gradlew
./gradlew assembleDebug --stacktrace

APK="app/build/outputs/apk/debug/app-debug.apk"
echo ""
echo "OK: $ROOT/android/$APK"
ls -lh "$APK"
