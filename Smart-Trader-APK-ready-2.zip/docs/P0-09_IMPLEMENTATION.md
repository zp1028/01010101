# P0-09 Implementation — Paper Execution

## 流程（强制风控）

```
OrderRequest
  → 解析仓位 / 价格
  → TradeProposal
  → RiskEngine.validate  （不可跳过）
  → reject 或 submitted
  → 市价成交（滑点 + 手续费）
  → Position / Portfolio 更新
  → OrderFilled / PositionChanged 事件
```

## 模块

- `app/execution/models.py` — Order / Fill / Position / Portfolio  
- `app/execution/paper.py` — `PaperExecutionEngine`

## API

- `POST /api/v1/orders`  
- `GET  /api/v1/orders`  
- `GET  /api/v1/orders/{id}`  
- `GET  /api/v1/positions`  
- `GET  /api/v1/fills`  
- `GET  /api/v1/portfolio`

## 特性

- 订阅 `MarketTickEvent` 更新标记价格与浮盈  
- 风险拒绝时写入 `reject_reason` + `risk_decision`  
- 平仓（sell 已有 long）不受「新开仓」风控拦阻  
- 与 RiskEngine 账户状态双向同步  

## 尚未接入

- 真实交易所 Adapter  
- 限价单挂单簿  
- 部分成交  
