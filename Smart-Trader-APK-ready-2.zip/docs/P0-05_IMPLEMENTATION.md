# P0-05 Implementation — Attention Engine + Observation Node

## Attention Engine (`app/quant/attention/engine.py`)

动态关注度评分，输入：
- `SignalEvent`（带衰减）
- `CandleEvent`（成交量比、价格波动）

输出：`AttentionEvent`
- `score` 0–1
- `reasons[]` 可解释原因
- `regime`：`normal` / `high_volatility` / `momentum` / `mean_reversion_zone`

权重（可配置）：
- signal 0.45
- volume 0.25
- volatility 0.20
- RSI extreme 0.10

`ranking(limit)` 供 Discovery 页面使用。

## Observation Node (`app/quant/observation/engine.py`)

用户设定价格观察点：
- `direction`: `above` | `below` | `cross`
- 触发后发布 `ObservationTriggeredEvent`
- 冷却时间避免刷屏（默认 60s）

REST：
- `GET  /api/v1/observations`
- `POST /api/v1/observations`
- `DELETE /api/v1/observations/{id}`

WebSocket 事件：
- `attention.updated`
- `observation.triggered`

## 全链路（当前）

```
Tick / Candle
  → Feature → Signal → Attention
Tick
  → Observation (条件触发)
  → （后续可接 AI 全链路重分析）
```

## Tests
- `test_attention.py`
- `test_observation.py`
