# P0-07 Implementation — Backtest Dual Engine + PIT + Walk-Forward

## Engines

### Vectorized (`app/backtest/vectorized/engine.py`)
- Causal indicators (same functions as live FeatureEngine)
- Strategies: `rsi` / `macd` / `bb` / `buy_hold`
- Fee + slippage model
- Equity curve + trades + max drawdown
- **PIT**: signals at bar i only use closes[0..i]

### Event-Driven (`app/backtest/event_driven/engine.py`)
- Replays bars as `CandleEvent` through FeatureEngine + SignalEngine
- Closer to live parity; slower
- Sorted by time when `enforce_pit=True`

### Walk-Forward (`app/backtest/walk_forward.py`)
- train / validation / OOS split
- Runs vectorized on each segment
- Ready for later parameter optimization

## REST

`POST /api/v1/backtests`

```json
{
  "instrument_id": "binance:BTCUSDT",
  "symbol": "BTCUSDT",
  "bars": [{"open":1,"high":2,"low":0.5,"close":1.5,"volume":100,"open_time":...,"close_time":...}],
  "strategy": "rsi",
  "engine": "vectorized",
  "enforce_pit": true
}
```

`engine`: `vectorized` | `event` | `walk_forward`

## Result contract
`BacktestResult`: final_equity, total_return_pct, max_drawdown_pct, trades, equity_curve, pit_enforced, warnings

## Next
- Persist BacktestRun to PostgreSQL
- Hyperparameter grid / Hyperopt
- Funding / leverage models for perps
