# P0-10 Android UI — 简洁深色 Material 3

## 设计原则
- 深色背景 `#0B0D10`，卡片 `#14181F`，细边框
- 涨绿 `#3DDC97` / 跌红 `#FF6B6B` / 强调蓝 `#5B8CFF`
- 大标题 + 弱化副文案，信息密度适中
- 底部四栏：发现 · 市场 · 分析 · 账户

## 页面
1. **发现** — 关注度排序 + 最新信号  
2. **市场** — 标的列表与涨跌  
3. **分析** — 趋势 / 置信度 / 数据质量 / 多空依据（对接 AnalysisResult）  
4. **账户** — 纸交易权益、持仓、风控摘要  

当前使用 `SampleData` 演示布局与交互；后续可接 WebSocket / REST。

## 结构
```
ui/theme/     Color + Theme
ui/components/  AppCard, MetricBar, TagChip, PctBadge
ui/screens/   Discover / Market / Analysis / Account
navigation/   Bottom NavHost
data/         UI models + sample
```
