# P0-06 Implementation — AI Orchestrator

## Structured contract (`app/ai/models.py`)

唯一允许的 AI 输出：`AnalysisResult`

- trend / market_state / technical / money_flow / sentiment / macro  
- bull_case[] / bear_case[]  
- support[] / resistance[]  
- scenarios[] (bull / base / bear + probability)  
- risk / confidence / data_quality  
- evidence[]（每条带 source / agent / summary / confidence）

**禁止**仅输出自由文本 BUY/SELL 作为最终决策。

## Technical Agent (`app/ai/agents/technical.py`)

基于 FeatureSnapshot + SignalEvent 的可解释规则：
- RSI / MACD / Bollinger / SMA 结构  
- 生成 bull/bear 论据与 EvidenceItem  

后续可替换/并联 LLM Agent（News / Sentiment / Macro / Debate），契约不变。

## Orchestrator (`app/ai/orchestrator/engine.py`)

- 手动：`POST /api/v1/analysis/run`  
- 自动：Attention score ≥ 阈值 → 触发  
- 自动：Observation 触发 → 触发  
- 发布 `AIAnalysisStartedEvent` / `AIAnalysisCompletedEvent`  
- 内存历史（每标的最近 50 条）

## REST

- `GET  /api/v1/analysis/{instrument_id}`  
- `GET  /api/v1/analysis/{instrument_id}/history`  
- `POST /api/v1/analysis/run`

## WebSocket

- `ai.analysis.started`  
- `ai.analysis.completed`（含完整 result）

## 原则保持

AI 只提出结构化分析；Risk Engine 仍是后续独立校验层，不可被绕过。
