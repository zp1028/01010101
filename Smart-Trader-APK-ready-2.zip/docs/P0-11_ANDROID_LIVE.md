# P0-11 Android Live WebSocket

## 能力
- OkHttp WebSocket 连接后端 `/api/v1/ws/market`
- 解析 `market.tick` / `signal.generated` / `attention.updated`
- 发现页「实时」按钮：连接 / 断开
- 断线或未连接时使用 SampleData

## 配置
`ApiConfig.baseUrl` 默认 `http://10.0.2.2:8000`（模拟器访问本机）  
真机请改为电脑局域网 IP，例如 `http://192.168.1.8:8000`

## 文件
- `network/ApiConfig.kt`
- `network/MarketWsClient.kt`
- `viewmodel/AppState.kt`
