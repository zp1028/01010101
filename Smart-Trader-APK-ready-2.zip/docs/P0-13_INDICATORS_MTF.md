# P0-13 多周期指标 + 超买超卖

## 原先已有
- 实时 FeatureEngine：RSI / MACD / Bollinger / SMA（按 candle interval 分窗）
- SignalEngine：`rsi_oversold` / `rsi_overbought` / macd / bb / volume

## 本次补齐
**可切换周期**的指标分析 API（不依赖仅 1m WS 窗口）：

```
GET /api/v1/timeframes
GET /api/v1/indicators/BTCUSDT?timeframe=15m
GET /api/v1/indicators/BTCUSDT?timeframe=1h&rsi_period=14&rsi_oversold=30&rsi_overbought=70
GET /api/v1/signals/BTCUSDT?timeframe=4h
```

支持周期：`1m 3m 5m 15m 30m 1h 2h 4h 6h 12h 1d 1w`

返回：
- RSI / MACD / 布林 / SMA20·50 / EMA12·26 / 量比
- `oscillators[]`：超卖 `oversold` / 超买 `overbought` / 中性
- `active_signals[]`：rsi_oversold、rsi_overbought、bb_lower_touch、macd_bullish…
- `summary` 中文摘要

K 线来自 Binance Futures 公开 REST，按所选 `timeframe` 拉取后本地计算。
