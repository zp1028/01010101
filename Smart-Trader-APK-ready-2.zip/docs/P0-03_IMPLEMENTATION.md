# P0-03 Implementation — PostgreSQL Schema + Point-in-Time

## What was added

### 1. Database layer (`app/db/`)
- `base.py` — DeclarativeBase + TimestampMixin
- `models.py` — Core tables:
  - `instruments`
  - `market_snapshots` (with `available_at` / `published_at` / `source_version`)
  - `feature_snapshots`
  - `ai_analyses`
  - `observation_nodes`
  - `analysis_replays`
- `session.py` — Engine + session factory  
  Default: `sqlite:///./smart_trader.db` (zero-config)  
  Production: set `DATABASE_URL=postgresql+psycopg://...`

### 2. Point-in-Time module (`app/data/point_in_time/`)
- `is_available(record, analysis_time)`
- `filter_available(records, analysis_time)`
- `assert_no_lookahead(...)` — hard guard for tests / backtests
- `pit_slice(...)` — for raw dict/JSONB payloads

**Hard rule**: only `available_at <= analysis_time` is legal.  
Never use `source_timestamp` alone for historical correctness.

### 3. Instrument repository
- `upsert_instrument`
- `load_all_into_registry`
- `list_instruments`

On startup the API:
1. Creates schema
2. Hydrates the in-memory `InstrumentRegistry` from DB
3. Persists any instruments auto-registered by the Binance adapter

### 4. Config
- New setting: `database_url` (env `DATABASE_URL`)

### 5. Docker
- `postgres` service added to `docker-compose.yml`
- Backend depends on it and receives `DATABASE_URL`

### 6. Tests
- `test_point_in_time.py` covers the PIT filter rules

## Not yet implemented (next phases)
- Live writing of MarketSnapshot / FeatureSnapshot on every tick
- Full Replay engine
- Async SQLAlchemy / connection pool tuning
- Migration tool (Alembic) — currently `create_all` only
