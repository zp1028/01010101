# 构建 Smart Trader APK

## 方式一：本机 Android Studio / 命令行

### 1. 环境
- JDK **17**
- Android SDK（API 35）
- 环境变量可选：`ANDROID_HOME` 或 `ANDROID_SDK_ROOT`

### 2. 配置 SDK 路径

```bash
cd android
cp local.properties.example local.properties
# 编辑 local.properties，例如：
# macOS:  sdk.dir=/Users/你的用户名/Library/Android/sdk
# Linux:  sdk.dir=/home/你的用户名/Android/Sdk
# Windows: sdk.dir=C\:\\Users\\你\\AppData\\Local\\Android\\Sdk
```

### 3. 编译 Debug APK

```bash
cd android
chmod +x gradlew
./gradlew assembleDebug
```

产物路径：

```
android/app/build/outputs/apk/debug/app-debug.apk
```

安装到手机：

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

### 4. Release（可选）

```bash
./gradlew assembleRelease
# 需自行配置签名；未签名可用 debug 包测试
```

### 5. 连接后端

模拟器默认 `ApiConfig.baseUrl = http://10.0.2.2:8000`  
真机改为电脑局域网 IP，例如 `http://192.168.1.8:8000`  
（文件：`android/app/src/main/java/com/smarttrader/app/network/ApiConfig.kt`）

---

## 方式二：GitHub Actions

推送到 `main`/`master` 或手动 **Actions → Build Android APK → Run workflow**。

完成后在 **Artifacts** 下载 `smart-trader-debug-apk`。

---

## 方式三：一键脚本

```bash
./scripts/build-apk.sh
```
