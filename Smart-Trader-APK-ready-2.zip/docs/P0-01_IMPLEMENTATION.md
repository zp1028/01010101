# P0-01 Implementation

Implemented source boundaries:
- Provider abstraction + registry
- Binance combined market WebSocket
- runtime subscription/unsubscription
- exponential reconnect
- stale detection
- proactive connection rotation before configured lifecycle limit
- normalized ticker/trade/bookTicker/kline events
- EventBus
- FastAPI downstream WebSocket
- provider health endpoint
- Android Compose starter
- backend unit tests
- CI/Docker skeleton

Not yet claimed as implemented:
- PostgreSQL repositories
- Redis
- Feature Engine
- Signal Engine
- AI Orchestrator
- Risk Engine
- Execution
- Android realtime repository
- signed release APK

Those are next phases.
