# P0-08 Implementation — Risk Engine

## 原则（冻结）

```
AI / Strategy  →  TradeProposal  →  RiskEngine  →  Approved / Rejected / Adjusted
                                              ↘ 永远不可被 AI 绕过
```

## 校验项

| 规则 | 默认 | 代码 |
|------|------|------|
| 单标的仓位上限 | 25% equity | MAX_POSITION |
| 最大杠杆 | 3x | LEVERAGE_EXCEEDED |
| 组合总敞口 | 100% | PORTFOLIO_EXPOSURE |
| 账户亏损熔断 | 10% session | ACCOUNT_LOSS_HALT |
| 止损过近 | < 0.5% | STOP_TOO_TIGHT |
| 止损过远 | > 15% (warn+clip) | STOP_TOO_WIDE |
| 禁止做空 | 可配置 | SHORT_NOT_ALLOWED |

## API

- `POST /api/v1/risk/validate` — 校验提案  
- `GET/PUT /api/v1/risk/limits`  
- `GET/POST /api/v1/risk/account`  
- `POST /api/v1/risk/session/reset`

## 输出 `RiskDecision`

- `approved`  
- `violations[]` (block | warn)  
- `adjusted` 提案（仓位/杠杆/止损裁剪后）  
- `risk_score` 0–1  
- `metrics`

## 事件

发布 `RiskChangedEvent` 供监控 / UI。
