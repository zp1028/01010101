# P0-04 Implementation — Feature Engine + Signal Engine

## What was added

### 1. Indicators (`app/quant/indicators/basic.py`)
Pure-Python (no numpy dependency):
- `sma`, `ema`
- `rsi`
- `macd` (line / signal / histogram)
- `bollinger` (mid / upper / lower)
- `latest` helper

### 2. Feature Engine (`app/quant/features/engine.py`)
- Subscribes to `CandleEvent` (closed bars only)
- Maintains rolling window per `(instrument_id, interval)`
- Computes standard feature set:
  - close / high / low / volume
  - rsi_14, macd, macd_signal, macd_hist
  - bb_mid / bb_upper / bb_lower / bb_width / bb_pct
  - sma_20 / sma_50 / ema_12 / ema_26
  - volume_sma_20 / volume_ratio
- Produces `FeatureSnapshot` with `available_at = candle.close_time` (PIT-safe for live)

### 3. Signal Engine (`app/quant/signals/engine.py`)
- Subscribes to the same candle stream
- Reads latest FeatureSnapshot and emits `SignalEvent`s:
  - `rsi_oversold` / `rsi_overbought`
  - `macd_bullish` / `macd_bearish`
  - `bb_lower_touch` / `bb_upper_touch`
  - `volume_spike`
- Strength is normalized to 0–1 and features are attached for explainability

### 4. Wiring
- `main.py` creates and subscribes both engines at startup
- WebSocket broadcasts `signal.generated` events to Android / clients
- `/health` reports quant pipeline status

### 5. Tests
- `test_indicators.py` — unit tests for all indicators
- `test_feature_signal.py` — end-to-end closed-candle → feature → signal path

## Intentionally deferred
- Strategy Registry (parameterized / versioned strategies)
- Attention Engine
- Persisting FeatureSnapshot / Signal to PostgreSQL
- Multi-timeframe feature fusion
