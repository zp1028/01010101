# CI APK 构建失败修复说明

## 原因

`android-actions/setup-android@v3` 在 **Accepting Android SDK licenses** 时进入交互提示：

```text
Review licenses that have not been accepted (y/N)?
```

GitHub Actions 无交互输入，任务挂起后失败。

## 修复

1. **不要**依赖会交互的 license 步骤  
2. 预先写入 `$ANDROID_HOME/licenses/*` 哈希  
3. 用 `yes | sdkmanager --licenses` 吞掉提示  
4. 用 Runner 自带 SDK：`/usr/local/lib/android/sdk`

已更新：

- `.github/workflows/android-apk.yml`
- `.github/workflows/build-apk.yml`（推荐手动/推送触发）

## 使用

推送到 `main`/`master`，或 Actions 里手动跑 **Build APK (stable)**。  
成功后 Artifacts 下载 `smart-trader-debug-apk`。
