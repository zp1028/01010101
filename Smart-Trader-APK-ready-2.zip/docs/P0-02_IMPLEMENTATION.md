# P0-02 Implementation — Unified Market Model + Full Event Contract

## What was added

### 1. Unified Market Model (`app/models/instrument.py`)
- `Instrument` — canonical identity used by every upper layer
  - `instrument_id`, `symbol`, `market`, `asset_type`, `venue`
  - `quote_currency`, `base_currency`, `contract_type`
  - `tick_size`, `lot_size`, `timezone`, `metadata`
- `InstrumentRegistry` — in-memory registry (will be PostgreSQL-backed later)
- Convenience helper `ensure_crypto()` used by the Binance adapter

### 2. Complete Event Contract (`app/core/events.py`)
Market data:
- `MarketTickEvent` (replaces old `MarketTick`)
- `TradeEvent`
- `CandleEvent`
- `OrderBookEvent`
- `FundingRateEvent`
- `OpenInterestEvent`

External data:
- `NewsEvent` (with `published_at` + `available_at` for PIT)
- `MacroEvent`

Quant / signal:
- `SignalEvent`
- `AttentionEvent`
- `ObservationTriggeredEvent`

AI:
- `AIAnalysisStartedEvent`
- `AIAnalysisCompletedEvent`

Portfolio / risk / execution (stubs ready for later phases):
- `PositionChangedEvent`
- `RiskChangedEvent`
- `OrderSubmittedEvent` / `OrderFilledEvent` / `OrderRejectedEvent`

All events carry `instrument_id` + `symbol` + venue and explicit timestamps
(`source_timestamp`, `received_at`, optional `processed_at` / `available_at`).

### 3. Binance Adapter update
- Now accepts and uses `InstrumentRegistry`
- Publishes fully-typed `MarketTickEvent` / `TradeEvent` / `CandleEvent`
  with `instrument_id`
- Pre-registers instruments on `start()` and on dynamic `subscribe()`

### 4. Downstream WebSocket & Health
- `/health` and WS `connection.ready` now expose the registered instruments
- Broadcast payloads include `instrument_id`

### 5. Tests
- Updated normalizer tests
- New `test_instrument.py` covering registry behaviour

## Intentionally left for later phases
- PostgreSQL persistence of Instrument + snapshots
- Point-in-Time filter implementation
- FundingRate / OpenInterest live streams
- Feature / Signal / Attention / AI engines
- Android realtime repository consuming the new contract

## Compatibility
- Old name `MarketTick` is kept as an alias of `MarketTickEvent`
  so any external code still importing it continues to work.
