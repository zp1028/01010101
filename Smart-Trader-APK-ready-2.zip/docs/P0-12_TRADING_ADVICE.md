# P0-12 单标的行情分析 + 多空入场/持仓建议

## 能力

针对**单一币种或股票标的**（当前以 crypto instrument_id 为主）：

1. 拉取/刷新 AI 结构化分析（趋势、多空依据、支撑阻力）
2. 结合最新 Feature（RSI/MACD/布林等）
3. 输出 **TradingAdvice**：
   - 方向：`long` / `short` / `wait`
   - 入场区间、建议价、止损、止盈 1/2
   - 建议仓位占比（受 RiskLimits 约束）
   - 盈亏比 RR
   - 持仓动作：`open` / `add` / `hold` / `reduce` / `close` / `wait`

## API

```
GET  /api/v1/advice/BTCUSDT
GET  /api/v1/advice/binance:BTCUSDT?run_analysis=true
POST /api/v1/advice
{"symbol":"BTCUSDT","run_analysis":true}
```

## 原则

- 建议 = 提案，**不是**自动下单
- 实际下单仍走 `POST /orders` → **RiskEngine 强制校验**
- 股票市场接入后沿用同一 `instrument_id` 与 Advice 契约

## 模块

- `app/ai/advice.py` — `build_trading_advice`
- `app/api/v1/advice.py` — REST
