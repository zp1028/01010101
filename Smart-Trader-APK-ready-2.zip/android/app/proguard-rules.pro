# Smart Trader — keep for release if minify enabled later
-keepclassmembers class * {
    @androidx.compose.** *;
}
