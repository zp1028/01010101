package com.smarttrader.app.network

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class LiveTick(
    val symbol: String,
    val instrumentId: String,
    val last: Double?,
    val bid: Double?,
    val ask: Double?,
    val timestamp: Long,
)

data class LiveSignal(
    val symbol: String,
    val name: String,
    val direction: String,
    val strength: Double,
    val timeframe: String,
)

data class LiveAttention(
    val symbol: String,
    val score: Double,
    val regime: String?,
    val reasons: List<String>,
)

class MarketWsClient(
    private val onTick: (LiveTick) -> Unit,
    private val onSignal: (LiveSignal) -> Unit,
    private val onAttention: (LiveAttention) -> Unit,
    private val onStatus: (String) -> Unit,
) {
    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private var socket: WebSocket? = null

    fun connect() {
        onStatus("connecting")
        val req = Request.Builder().url(ApiConfig.wsUrl).build()
        socket = client.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                onStatus("connected")
                // optional: subscribe extra symbols
                webSocket.send("""{"action":"subscribe","symbols":["BTCUSDT","ETHUSDT","SOLUSDT"]}""")
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val root = JSONObject(text)
                    when (root.optString("event")) {
                        "market.tick" -> {
                            val data = root.optJSONObject("data") ?: return
                            onTick(
                                LiveTick(
                                    symbol = data.optString("symbol", root.optString("instrument")),
                                    instrumentId = root.optString("instrument_id"),
                                    last = data.optDoubleOrNull("last"),
                                    bid = data.optDoubleOrNull("bid"),
                                    ask = data.optDoubleOrNull("ask"),
                                    timestamp = root.optLong("timestamp"),
                                )
                            )
                        }
                        "signal.generated" -> {
                            val data = root.optJSONObject("data") ?: return
                            onSignal(
                                LiveSignal(
                                    symbol = root.optString("instrument"),
                                    name = data.optString("signal_name"),
                                    direction = data.optString("direction"),
                                    strength = data.optDouble("strength"),
                                    timeframe = data.optString("timeframe", "1m"),
                                )
                            )
                        }
                        "attention.updated" -> {
                            val data = root.optJSONObject("data") ?: return
                            val reasonsJson = data.optJSONArray("reasons")
                            val reasons = mutableListOf<String>()
                            if (reasonsJson != null) {
                                for (i in 0 until reasonsJson.length()) {
                                    reasons.add(reasonsJson.getString(i))
                                }
                            }
                            onAttention(
                                LiveAttention(
                                    symbol = root.optString("instrument"),
                                    score = data.optDouble("score"),
                                    regime = data.optString("regime", null),
                                    reasons = reasons,
                                )
                            )
                        }
                        "connection.ready" -> onStatus("ready")
                        else -> Unit
                    }
                } catch (_: Exception) {
                    // ignore malformed frames
                }
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                onStatus("closing")
                webSocket.close(1000, null)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                onStatus("closed")
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                onStatus("error: ${t.message ?: "unknown"}")
            }
        })
    }

    fun disconnect() {
        socket?.close(1000, "bye")
        socket = null
    }
}

private fun JSONObject.optDoubleOrNull(key: String): Double? {
    if (!has(key) || isNull(key)) return null
    return optDouble(key)
}
