package com.smarttrader.app.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.smarttrader.app.data.MarketItem
import com.smarttrader.app.data.SampleData
import com.smarttrader.app.data.SignalItem
import com.smarttrader.app.network.ApiConfig
import com.smarttrader.app.network.LiveAttention
import com.smarttrader.app.network.LiveSignal
import com.smarttrader.app.network.LiveTick
import com.smarttrader.app.network.MarketWsClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.DecimalFormat

class AppState : ViewModel() {
    var markets by mutableStateOf(SampleData.markets)
        private set
    var signals by mutableStateOf(SampleData.signals)
        private set
    var connectionStatus by mutableStateOf("offline · sample data")
        private set
    var live by mutableStateOf(false)
        private set

    private var ws: MarketWsClient? = null
    private val priceFmt = DecimalFormat("#,##0.00")

    fun startLive() {
        if (ws != null) return
        live = true
        connectionStatus = "connecting…"
        ws = MarketWsClient(
            onTick = { tick -> viewModelScope.launch(Dispatchers.Main) { applyTick(tick) } },
            onSignal = { sig -> viewModelScope.launch(Dispatchers.Main) { applySignal(sig) } },
            onAttention = { att -> viewModelScope.launch(Dispatchers.Main) { applyAttention(att) } },
            onStatus = { s -> viewModelScope.launch(Dispatchers.Main) { connectionStatus = s } },
        ).also { it.connect() }
    }

    fun stopLive() {
        ws?.disconnect()
        ws = null
        live = false
        connectionStatus = "offline · sample data"
        markets = SampleData.markets
        signals = SampleData.signals
    }

    private fun applyTick(tick: LiveTick) {
        val last = tick.last ?: return
        val sym = normalizeSymbol(tick.symbol)
        markets = markets.map { m ->
            if (m.symbol == sym || m.symbol.replace("/", "") == tick.symbol) {
                val prev = parsePrice(m.price)
                val chg = if (prev > 0) (last - prev) / prev * 100.0 else m.changePct
                m.copy(price = formatPrice(last), changePct = chg)
            } else m
        }.let { list ->
            if (list.none { it.symbol == sym || it.symbol.replace("/", "") == tick.symbol }) {
                list + MarketItem(sym, sym, formatPrice(last), 0.0, 0.0, "normal")
            } else list
        }
    }

    private fun applySignal(sig: LiveSignal) {
        val item = SignalItem(
            symbol = normalizeSymbol(sig.symbol),
            name = sig.name,
            direction = sig.direction,
            strength = sig.strength,
            timeframe = sig.timeframe,
        )
        signals = (listOf(item) + signals.filterNot { it.symbol == item.symbol && it.name == item.name })
            .take(20)
    }

    private fun applyAttention(att: LiveAttention) {
        val sym = normalizeSymbol(att.symbol)
        markets = markets.map { m ->
            if (m.symbol == sym || m.symbol.replace("/", "") == att.symbol) {
                m.copy(
                    attention = att.score,
                    regime = att.regime ?: m.regime,
                )
            } else m
        }
    }

    private fun normalizeSymbol(raw: String): String {
        val u = raw.uppercase().replace("/", "")
        return when {
            u.endsWith("USDT") && u.length > 4 -> u.dropLast(4) + "/USDT"
            else -> raw
        }
    }

    private fun parsePrice(s: String): Double =
        s.replace(",", "").toDoubleOrNull() ?: 0.0

    private fun formatPrice(v: Double): String =
        if (v >= 100) priceFmt.format(v) else DecimalFormat("#,##0.####").format(v)

    override fun onCleared() {
        stopLive()
        super.onCleared()
    }

    companion object {
        fun backendHint(): String = "Backend: ${ApiConfig.baseUrl}"
    }
}
