package com.smarttrader.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.smarttrader.app.navigation.AppNav
import com.smarttrader.app.ui.theme.Bg
import com.smarttrader.app.ui.theme.SmartTraderTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SmartTraderTheme {
                Surface(Modifier.fillMaxSize(), color = Bg) {
                    AppNav()
                }
            }
        }
    }
}
