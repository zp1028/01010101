package com.smarttrader.app.network

/**
 * Default points to local backend. On a real device use your LAN IP, e.g.
 * http://192.168.1.8:8000 and ws://192.168.1.8:8000
 */
object ApiConfig {
    var baseUrl: String = "http://10.0.2.2:8000" // Android emulator → host loopback
    val wsUrl: String
        get() {
            val http = baseUrl.trimEnd('/')
            return when {
                http.startsWith("https://") -> "wss://" + http.removePrefix("https://") + "/api/v1/ws/market"
                else -> "ws://" + http.removePrefix("http://") + "/api/v1/ws/market"
            }
        }
    val healthUrl: String get() = baseUrl.trimEnd('/') + "/health"
    val analysisRunUrl: String get() = baseUrl.trimEnd('/') + "/api/v1/analysis/run"
    val portfolioUrl: String get() = baseUrl.trimEnd('/') + "/api/v1/portfolio"
}
