package com.smarttrader.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.smarttrader.app.data.SampleData
import com.smarttrader.app.ui.components.*
import com.smarttrader.app.ui.theme.*
import com.smarttrader.app.viewmodel.AppState

@Composable
fun DiscoverScreen(state: AppState) {
    LazyColumn(
        Modifier.fillMaxSize().background(Bg).padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 20.dp, bottom = 88.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column {
                    Text("发现", style = MaterialTheme.typography.displaySmall, color = TextPrimary)
                    Spacer(Modifier.height(4.dp))
                    Text(state.connectionStatus, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                }
                TextButton(onClick = {
                    if (state.live) state.stopLive() else state.startLive()
                }) {
                    Text(if (state.live) "断开" else "实时", color = Accent)
                }
            }
            Spacer(Modifier.height(16.dp))
            SectionTitle("关注度 Top")
        }
        items(state.markets.sortedByDescending { it.attention }) { m ->
            AppCard {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column {
                        Text(m.symbol, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                        Text(m.name, style = MaterialTheme.typography.bodyMedium, color = TextMuted)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(m.price, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(4.dp))
                        PctBadge(m.changePct)
                    }
                }
                Spacer(Modifier.height(12.dp))
                MetricBar("关注度", m.attention, Accent)
                Spacer(Modifier.height(8.dp))
                TagChip(m.regime.replace('_', ' '))
            }
        }
        item {
            Spacer(Modifier.height(8.dp))
            SectionTitle("最新信号")
        }
        items(state.signals) { s ->
            AppCard {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column {
                        Text(s.symbol, style = MaterialTheme.typography.titleMedium)
                        Text(s.name, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                    }
                    TagChip(
                        text = s.direction.uppercase(),
                        color = when (s.direction) {
                            "long" -> Bull
                            "short" -> Bear
                            else -> Neutral
                        },
                    )
                }
                Spacer(Modifier.height(10.dp))
                MetricBar("强度", s.strength, if (s.direction == "short") Bear else Bull)
            }
        }
    }
}

@Composable
fun MarketScreen(state: AppState) {
    LazyColumn(
        Modifier.fillMaxSize().background(Bg).padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 20.dp, bottom = 88.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Text("市场", style = MaterialTheme.typography.displaySmall, color = TextPrimary)
            Spacer(Modifier.height(4.dp))
            Text(
                if (state.live) "Binance · 实时推送" else "Binance · 样例 / 等待连接",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
            )
            Spacer(Modifier.height(16.dp))
        }
        items(state.markets) { m ->
            AppCard {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column {
                        Text(m.symbol, style = MaterialTheme.typography.titleLarge, color = TextPrimary)
                        Text(m.name, style = MaterialTheme.typography.bodyMedium, color = TextMuted)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(m.price, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Medium)
                        Spacer(Modifier.height(6.dp))
                        PctBadge(m.changePct)
                    }
                }
            }
        }
    }
}

@Composable
fun AnalysisScreen() {
    val a = SampleData.analysis
    LazyColumn(
        Modifier.fillMaxSize().background(Bg).padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 20.dp, bottom = 88.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Text("分析", style = MaterialTheme.typography.displaySmall, color = TextPrimary)
            Spacer(Modifier.height(4.dp))
            Text("结构化结论 · 可切换周期 · 超买超卖", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("1m", "5m", "15m", "1h", "4h", "1d").forEach { tf ->
                    TagChip(tf, if (tf == "15m") Accent else Neutral)
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("指标接口 GET /api/v1/indicators/BTCUSDT?timeframe=15m", style = MaterialTheme.typography.bodyMedium, color = TextMuted)
            Spacer(Modifier.height(16.dp))
        }
        item {
            AppCard {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column {
                        Text(a.symbol, style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(6.dp))
                        TagChip(
                            a.trend.uppercase(),
                            when (a.trend) {
                                "bullish" -> Bull
                                "bearish" -> Bear
                                else -> Neutral
                            },
                        )
                    }
                    if (a.regime != null) {
                        TagChip(a.regime.replace('_', ' '), Accent)
                    }
                }
                Spacer(Modifier.height(16.dp))
                MetricBar("置信度", a.confidence, Accent)
                Spacer(Modifier.height(12.dp))
                MetricBar("数据质量", a.dataQuality, Bull)
            }
        }
        item {
            AppCard {
                Text("多头依据", style = MaterialTheme.typography.titleMedium, color = Bull)
                Spacer(Modifier.height(10.dp))
                a.bull.forEach {
                    Text("·  $it", style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
                    Spacer(Modifier.height(6.dp))
                }
            }
        }
        item {
            AppCard {
                Text("空头依据", style = MaterialTheme.typography.titleMedium, color = Bear)
                Spacer(Modifier.height(10.dp))
                a.bear.forEach {
                    Text("·  $it", style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
                    Spacer(Modifier.height(6.dp))
                }
            }
        }
        item {
            AppCard {
                Text("入场建议", style = MaterialTheme.typography.titleMedium, color = Accent)
                Spacer(Modifier.height(10.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    TagChip("LONG", Bull)
                    Text("置信 62%", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                }
                Spacer(Modifier.height(12.dp))
                Text("建议入场  83,800 – 84,200", style = MaterialTheme.typography.bodyLarge)
                Spacer(Modifier.height(4.dp))
                Text("止损  82,900", style = MaterialTheme.typography.bodyMedium, color = Bear)
                Spacer(Modifier.height(4.dp))
                Text("目标  85,400 / 86,600", style = MaterialTheme.typography.bodyMedium, color = Bull)
                Spacer(Modifier.height(4.dp))
                Text("仓位  约 12% 权益  ·  RR ≈ 1.5", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                Spacer(Modifier.height(10.dp))
                Text("持仓：无仓 → 可轻仓试多；有多单可持有，有空单建议减仓。", style = MaterialTheme.typography.bodyMedium, color = TextMuted)
            }
        }
        item {
            AppCard {
                Text("说明", style = MaterialTheme.typography.titleMedium, color = TextSecondary)
                Spacer(Modifier.height(8.dp))
                Text(
                    "单标的分析与多空建议仅供参考。下单前必须经过 Risk Engine。接口：GET /api/v1/advice/BTCUSDT",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextMuted,
                )
            }
        }
    }
}

@Composable
fun AccountScreen() {
    LazyColumn(
        Modifier.fillMaxSize().background(Bg).padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 20.dp, bottom = 88.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Text("账户", style = MaterialTheme.typography.displaySmall, color = TextPrimary)
            Spacer(Modifier.height(4.dp))
            Text("纸交易 · 本地模拟", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
            Spacer(Modifier.height(16.dp))
        }
        item {
            AppCard {
                Text("权益", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                Spacer(Modifier.height(4.dp))
                Text("10,025.56", style = MaterialTheme.typography.displaySmall, color = TextPrimary)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Column {
                        Text("可用", style = MaterialTheme.typography.labelMedium, color = TextMuted)
                        Text("9,012.00", style = MaterialTheme.typography.titleMedium)
                    }
                    Column {
                        Text("已实现", style = MaterialTheme.typography.labelMedium, color = TextMuted)
                        Text("+25.56", style = MaterialTheme.typography.titleMedium, color = Bull)
                    }
                }
            }
        }
        item { SectionTitle("持仓") }
        items(SampleData.positions) { p ->
            AppCard {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column {
                        Text(p.symbol, style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(4.dp))
                        TagChip(p.side.uppercase(), if (p.side == "long") Bull else Bear)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(p.pnl, style = MaterialTheme.typography.titleLarge, color = Bull)
                        Text("%.2f%%".format(p.pnlPct), style = MaterialTheme.typography.bodyMedium, color = Bull)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("数量 ${p.qty}", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                    Text("成本 ${p.entry}", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                }
            }
        }
        item {
            AppCard {
                Text("风控", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Text("单标的 ≤ 25% · 杠杆 ≤ 3x · 亏损熔断 10%", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                Spacer(Modifier.height(8.dp))
                Text(AppState.backendHint(), style = MaterialTheme.typography.bodyMedium, color = TextMuted)
            }
        }
    }
}
