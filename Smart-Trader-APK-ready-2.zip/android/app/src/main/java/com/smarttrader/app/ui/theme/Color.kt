package com.smarttrader.app.ui.theme

import androidx.compose.ui.graphics.Color

// Clean dark palette — minimal, high contrast
val Bg = Color(0xFF0B0D10)
val Surface = Color(0xFF14181F)
val SurfaceAlt = Color(0xFF1C222B)
val Border = Color(0xFF2A3340)

val TextPrimary = Color(0xFFF2F4F7)
val TextSecondary = Color(0xFF9AA3B2)
val TextMuted = Color(0xFF6B7380)

val Accent = Color(0xFF5B8CFF)
val AccentSoft = Color(0xFF2A3A5C)

val Bull = Color(0xFF3DDC97)
val Bear = Color(0xFFFF6B6B)
val Warn = Color(0xFFFFC857)
val Neutral = Color(0xFF8B95A8)
