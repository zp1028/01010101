package com.smarttrader.app.data

data class MarketItem(
    val symbol: String,
    val name: String,
    val price: String,
    val changePct: Double,
    val attention: Double,
    val regime: String,
)

data class SignalItem(
    val symbol: String,
    val name: String,
    val direction: String,
    val strength: Double,
    val timeframe: String,
)

data class AnalysisUi(
    val symbol: String,
    val trend: String,
    val confidence: Double,
    val dataQuality: Double,
    val bull: List<String>,
    val bear: List<String>,
    val regime: String?,
)

data class PositionUi(
    val symbol: String,
    val side: String,
    val qty: String,
    val entry: String,
    val pnl: String,
    val pnlPct: Double,
)

object SampleData {
    val markets = listOf(
        MarketItem("BTC/USDT", "Bitcoin", "84,230.50", 1.24, 0.82, "momentum"),
        MarketItem("ETH/USDT", "Ethereum", "3,412.10", -0.68, 0.61, "normal"),
        MarketItem("SOL/USDT", "Solana", "178.45", 2.91, 0.74, "high_volatility"),
        MarketItem("BNB/USDT", "BNB", "612.30", 0.35, 0.28, "normal"),
        MarketItem("XRP/USDT", "XRP", "0.6234", -1.12, 0.41, "mean_reversion_zone"),
    )

    val signals = listOf(
        SignalItem("BTC/USDT", "rsi_oversold", "long", 0.72, "1m"),
        SignalItem("SOL/USDT", "macd_bullish", "long", 0.58, "1m"),
        SignalItem("ETH/USDT", "volume_spike", "neutral", 0.64, "1m"),
    )

    val analysis = AnalysisUi(
        symbol = "BTC/USDT",
        trend = "bullish",
        confidence = 0.62,
        dataQuality = 0.85,
        bull = listOf(
            "RSI(14) 进入超卖后回升",
            "MACD 柱线转正，动量偏多",
            "价格站上 SMA20",
        ),
        bear = listOf(
            "上方接近布林带中轨阻力",
            "资金费率偏高需警惕拥挤",
        ),
        regime = "momentum",
    )

    val positions = listOf(
        PositionUi("BTC/USDT", "long", "0.012", "82,100", "+25.56", 2.59),
    )
}
