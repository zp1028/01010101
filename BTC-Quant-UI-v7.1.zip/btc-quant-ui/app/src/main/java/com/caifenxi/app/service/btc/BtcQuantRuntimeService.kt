package com.caifenxi.app.service.btc

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.caifenxi.app.R
import com.caifenxi.app.domain.btc.runtime.BtcRuntimeController
import com.caifenxi.app.domain.btc.runtime.BtcRuntimeStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class BtcQuantRuntimeService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var loopJob: Job? = null
    private lateinit var store: BtcRuntimeStore

    override fun onCreate() {
        super.onCreate()
        store = BtcRuntimeStore(this)
        createChannel()
        startForeground(NOTIFICATION_ID, notification("BTC Quant · 初始化"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopRuntime()
            ACTION_KILL -> {
                store.setKillSwitch(true)
                stopRuntime()
            }
            ACTION_RESUME -> {
                store.setKillSwitch(false)
                startRuntime()
            }
            else -> startRuntime()
        }
        return START_STICKY
    }

    private fun startRuntime() {
        val cfg = store.config()
        if (!cfg.enabled || store.state().killSwitch) {
            stopRuntime()
            return
        }
        if (loopJob?.isActive == true) return
        store.update { it.copy(status = com.caifenxi.app.domain.btc.runtime.BtcRuntimeStatus.RUNNING, lastError = null) }
        loopJob = scope.launch {
            BtcRuntimeController(store = store).loop { !isStopped && store.config().enabled && !store.state().killSwitch }
        }
        updateNotification("BTC Quant · ${cfg.runMode.name} · ${cfg.symbol} ${cfg.timeframe}")
    }

    private fun stopRuntime() {
        loopJob?.cancel()
        loopJob = null
        store.update { it.copy(status = com.caifenxi.app.domain.btc.runtime.BtcRuntimeStatus.STOPPED) }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        loopJob?.cancel()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "BTC Quant Runtime", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun notification(text: String): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("BTC Quant")
            .setContentText(text)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(text))
    }

    companion object {
        const val ACTION_STOP = "com.caifenxi.btcquant.STOP"
        const val ACTION_KILL = "com.caifenxi.btcquant.KILL"
        const val ACTION_RESUME = "com.caifenxi.btcquant.RESUME"
        private const val CHANNEL_ID = "btc_quant_runtime"
        private const val NOTIFICATION_ID = 4201
    }
}
