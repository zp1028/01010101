package com.caifenxi.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.backtest.BacktestConfig
import com.caifenxi.app.domain.btc.backtest.BacktestResult
import com.caifenxi.app.domain.btc.backtest.BacktestTrade
import com.caifenxi.app.ui.BtcQuantViewModel
import com.caifenxi.app.ui.theme.CaiTokens
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * 回测 Tab：K 线时间回测计算 — 策略选择 / 参数配置 / 收益曲线 / 统计指标 / 交易明细
 */
@Composable
fun BacktestTab(viewModel: BtcQuantViewModel) {
    val state by viewModel.state.collectAsState()
    val btState by viewModel.backtestState.collectAsState()

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
    ) {
        // 标题
        Row(
            Modifier.fillMaxWidth().padding(24.dp, 18.dp, 24.dp, 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("K 线回测", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                Text(
                    "${state.symbol} \u00b7 ${state.timeframe} \u00b7 ${state.candles.size} 根 K 线",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // 数据概况
        Card(
            Modifier.padding(horizontal = 24.dp, vertical = 4.dp).fillMaxWidth(),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(Modifier.padding(16.dp)) {
                SectionTitleInline("回测数据")
                MetricLine("Symbol", state.symbol)
                MetricLine("周期", state.timeframe)
                MetricLine("K 线数量", "${state.candles.size}")
                MetricLine("数据起点", state.candles.firstOrNull()?.openTime?.let { fmtTime(it) } ?: "\u2014")
                MetricLine("数据终点", state.candles.lastOrNull()?.openTime?.let { fmtTime(it) } ?: "\u2014")
                if (state.candles.size < 80) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "\u26a0 数据不足 80 根，需先在看板加载行情",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        // 策略选择
        Card(
            Modifier.padding(horizontal = 24.dp, vertical = 4.dp).fillMaxWidth(),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(Modifier.padding(16.dp)) {
                SectionTitleInline("策略选择")
                viewModel.availablePlans.forEach { (id, name) ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = btState.planId == id,
                            onClick = { viewModel.selectBacktestPlan(id) }
                        )
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text(id, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Text(name, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        // 参数配置
        BacktestConfigCard(
            config = btState.config,
            onUpdate = { viewModel.updateBacktestConfig(it) }
        )

        Spacer(Modifier.height(8.dp))

        // 运行按钮
        Button(
            onClick = { viewModel.runBacktest() },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp),
            enabled = !btState.loading && state.candles.size >= 80
        ) {
            Icon(Icons.Filled.PlayArrow, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text(if (btState.loading) "回测中..." else "运行回测")
        }

        // 错误
        btState.error?.let {
            Text(
                it,
                color = MaterialTheme.colorScheme.error,
                fontSize = 12.sp,
                modifier = Modifier.padding(24.dp, 8.dp)
            )
        }

        // 加载指示器
        if (btState.loading) {
            LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp))
        }

        // 回测结果
        btState.result?.let { result ->
            Spacer(Modifier.height(12.dp))
            BacktestResultSection(result)
        }

        Spacer(Modifier.height(40.dp))
    }
}

@Composable
private fun BacktestConfigCard(
    config: BacktestConfig,
    onUpdate: (BacktestConfig) -> Unit
) {
    Card(
        Modifier.padding(horizontal = 24.dp, vertical = 4.dp).fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            SectionTitleInline("回测参数")

            // 初始资金
            ConfigSlider(
                label = "初始资金 (USDT)",
                value = config.initialEquity.toFloat(),
                range = 1000f..100000f,
                steps = 49,
                format = { "%.0f".format(it) },
                onValueChange = { onUpdate(config.copy(initialEquity = it.toDouble())) }
            )

            // 单笔风险
            ConfigSlider(
                label = "单笔风险 (%)",
                value = config.riskPerTradePct.toFloat(),
                range = 0.1f..5f,
                steps = 48,
                format = { "%.2f%%".format(it) },
                onValueChange = { onUpdate(config.copy(riskPerTradePct = it.toDouble())) }
            )

            // 手续费
            ConfigSlider(
                label = "手续费 (%)",
                value = config.feeRatePct.toFloat(),
                range = 0.01f..0.2f,
                steps = 18,
                format = { "%.3f%%".format(it) },
                onValueChange = { onUpdate(config.copy(feeRatePct = it.toDouble())) }
            )

            // 滑点
            ConfigSlider(
                label = "滑点 (%)",
                value = config.slippagePct.toFloat(),
                range = 0f..0.1f,
                steps = 9,
                format = { "%.3f%%".format(it) },
                onValueChange = { onUpdate(config.copy(slippagePct = it.toDouble())) }
            )

            // 最大持仓K线数
            ConfigSlider(
                label = "最大持仓 (K线)",
                value = config.maxHoldingBars.toFloat(),
                range = 4f..96f,
                steps = 22,
                format = { "%.0f".format(it) },
                onValueChange = { onUpdate(config.copy(maxHoldingBars = it.toInt())) }
            )
        }
    }
}

@Composable
private fun ConfigSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    steps: Int,
    format: (Float) -> String,
    onValueChange: (Float) -> Unit
) {
    Column(Modifier.padding(vertical = 4.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(format(value), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            steps = steps
        )
    }
}

@Composable
private fun BacktestResultSection(result: BacktestResult) {
    // 统计指标
    Card(
        Modifier.padding(horizontal = 24.dp, vertical = 4.dp).fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            SectionTitleInline("回测结果 \u00b7 ${result.planId}")

            // 核心指标网格
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("总收益", "%.2f%%".format(result.totalReturnPct), result.totalReturnPct >= 0)
                StatCard("胜率", "%.1f%%".format(result.winRatePct), result.winRatePct >= 50)
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("盈亏比", "%.2f".format(result.profitFactor), result.profitFactor >= 1.0)
                StatCard("最大回撤", "%.2f%%".format(result.maxDrawdownPct), false)
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("交易次数", "${result.sampleSize}", true)
                val sharpe = computeSharpe(result)
                StatCard("夏普比率", "%.2f".format(sharpe), sharpe >= 1.0)
            }

            Spacer(Modifier.height(8.dp))
            MetricLine("平均盈亏", "%.3f%%".format(result.averagePnlPct))
            MetricLine("平均持仓", "%.1f K线".format(result.averageHoldingBars))
            MetricLine("平均 MFE", "%.2f%%".format(result.averageMfePct))
            MetricLine("平均 MAE", "%.2f%%".format(result.averageMaePct))
            MetricLine("资金费率拖累", "%.4f%%".format(result.totalFundingPct))
            MetricLine("手续费拖累", "%.4f%%".format(result.totalFeePct))
        }
    }

    Spacer(Modifier.height(8.dp))

    // 收益曲线
    Card(
        Modifier.padding(horizontal = 24.dp, vertical = 4.dp).fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            SectionTitleInline("权益曲线")
            EquityCurveChart(
                equityCurve = result.equityCurve,
                modifier = Modifier.fillMaxWidth().height(200.dp)
            )
        }
    }

    Spacer(Modifier.height(8.dp))

    // 交易明细
    if (result.trades.isNotEmpty()) {
        Card(
            Modifier.padding(horizontal = 24.dp, vertical = 4.dp).fillMaxWidth(),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(Modifier.padding(16.dp)) {
                SectionTitleInline("交易明细 (${result.trades.size} 笔)")
                result.trades.take(50).forEachIndexed { idx, trade ->
                    TradeRow(idx + 1, trade)
                    if (idx < min(49, result.trades.size - 1)) {
                        HorizontalDivider(Modifier.padding(vertical = 4.dp))
                    }
                }
                if (result.trades.size > 50) {
                    Spacer(Modifier.height(4.dp))
                    Text("\u2026 仅显示前 50 笔", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, positive: Boolean) {
    Column(
        Modifier
            .weight(1f)
            .background(
                if (positive) CaiTokens.Success.copy(alpha = 0.1f) else CaiTokens.Danger.copy(alpha = 0.1f),
                RoundedCornerShape(8.dp)
            )
            .padding(8.dp)
    ) {
        Text(label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            value,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = if (positive) CaiTokens.Success else CaiTokens.Danger
        )
    }
}

@Composable
private fun TradeRow(index: Int, trade: BacktestTrade) {
    val dirColor = when (trade.direction) {
        BtcDirection.UP -> CaiTokens.Success
        BtcDirection.DOWN -> CaiTokens.Danger
        BtcDirection.FLAT -> CaiTokens.Warning
    }
    val pnlColor = if (trade.pnlCash > 0) CaiTokens.Success else CaiTokens.Danger

    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("#$index", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.width(30.dp))
        Text(trade.direction.name, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = dirColor, modifier = Modifier.width(50.dp))
        Column(Modifier.weight(1f)) {
            Text("Entry %.2f \u2192 Exit %.2f".format(trade.entry, trade.exit), fontSize = 11.sp)
            Text(
                "SL %.2f | TP %.2f | ${trade.reason} | ${trade.holdingBars}K".format(trade.stopLoss, trade.takeProfit),
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Column(horizontalAlignment = Alignment.End) {
            Text("%.2f%%".format(trade.pnlPct), fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = pnlColor)
            Text("%.2f".format(trade.pnlCash), fontSize = 10.sp, color = pnlColor)
        }
    }
}

@Composable
private fun EquityCurveChart(
    equityCurve: List<Double>,
    modifier: Modifier = Modifier
) {
    if (equityCurve.size < 2) return
    val upColor = CaiTokens.Success
    val downColor = CaiTokens.Danger
    val gridColor = Color.White.copy(alpha = 0.06f)
    val lineColor = CaiTokens.Accent

    val minVal = equityCurve.min()
    val maxVal = equityCurve.max()
    val span = (maxVal - minVal).coerceAtLeast(1e-9)
    val isProfit = equityCurve.last() >= equityCurve.first()

    Card(modifier, shape = RoundedCornerShape(12.dp)) {
        BoxWithConstraints(
            Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
        ) {
            val w = constraints.maxWidth.toFloat()
            val h = constraints.maxHeight.toFloat()

            Canvas(Modifier.fillMaxSize()) {
                // 网格线
                val gridLines = 4
                for (i in 0..gridLines) {
                    val y = h * i / gridLines
                    drawLine(gridColor, Offset(0f, y), Offset(w, y), strokeWidth = 1f)
                }

                // 基准线（初始资金）
                val baselineY = h - ((equityCurve.first() - minVal) / span * h).toFloat()
                if (baselineY in 0f..h) {
                    drawLine(
                        Color.White.copy(alpha = 0.15f),
                        Offset(0f, baselineY),
                        Offset(w, baselineY),
                        strokeWidth = 1f
                    )
                }

                // 权益曲线
                val path = Path()
                val stepX = w / (equityCurve.size - 1)
                for (i in equityCurve.indices) {
                    val x = i * stepX
                    val y = h - ((equityCurve[i] - minVal) / span * h).toFloat()
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawPath(path, lineColor, style = Stroke(width = 2f, cap = StrokeCap.Round))

                // 填充区域
                val fillPath = Path()
                fillPath.moveTo(0f, h)
                for (i in equityCurve.indices) {
                    val x = i * stepX
                    val y = h - ((equityCurve[i] - minVal) / span * h).toFloat()
                    if (i == 0) fillPath.lineTo(x, y) else fillPath.lineTo(x, y)
                }
                fillPath.lineTo(w, h)
                fillPath.close()
                drawPath(
                    fillPath,
                    if (isProfit) upColor.copy(alpha = 0.12f) else downColor.copy(alpha = 0.12f)
                )
            }

            // 标签
            Text(
                "%.0f".format(maxVal),
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(4.dp)
            )
            Text(
                "%.0f".format(minVal),
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.align(Alignment.BottomStart).padding(4.dp)
            )
        }
    }
}

/** 从权益曲线计算近似夏普比率 */
private fun computeSharpe(result: BacktestResult): Double {
    val curve = result.equityCurve
    if (curve.size < 3) return 0.0
    val returns = (1 until curve.size).map { (curve[it] / curve[it - 1] - 1.0) }
    if (returns.isEmpty()) return 0.0
    val mean = returns.average()
    val variance = returns.map { (it - mean).let { d -> d * d } }.average()
    val std = sqrt(variance)
    if (std < 1e-9) return 0.0
    // 年化因子：假设 15m K 线，96 根/天，365 天
    val barsPerYear = 96 * 365
    val annFactor = sqrt(barsPerYear.toDouble())
    return (mean / std) * annFactor
}
