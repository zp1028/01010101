package com.caifenxi.app.domain.btc.runtime

import java.util.concurrent.ConcurrentHashMap

/** Idempotency gate: one decision per plan/symbol/timeframe/bar. */
class BtcExecutionGate {
    private val seen = ConcurrentHashMap.newKeySet<String>()

    fun key(planId: String, symbol: String, timeframe: String, barId: Long): String =
        "$planId|$symbol|$timeframe|$barId"

    fun claim(planId: String, symbol: String, timeframe: String, barId: Long): Boolean =
        seen.add(key(planId, symbol, timeframe, barId))

    fun release(key: String) { seen.remove(key) }
}
