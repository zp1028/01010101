package com.caifenxi.app.domain.btc.runtime

import com.caifenxi.app.domain.btc.broker.BrokerAccountSnapshot
import com.caifenxi.app.domain.btc.broker.BrokerOrderResult

/** Minimal reconciliation result. Production cloud can persist the full order ledger. */
data class ReconciliationResult(
    val healthy: Boolean,
    val availableBalance: Double,
    val walletBalance: Double,
    val unrealizedPnl: Double,
    val lastOrderStatus: String? = null,
    val message: String = "OK"
)

class BtcOrderReconciler {
    fun reconcile(account: BrokerAccountSnapshot, lastOrder: BrokerOrderResult?): ReconciliationResult =
        ReconciliationResult(
            healthy = account.availableBalance >= 0.0 && account.totalWalletBalance >= 0.0,
            availableBalance = account.availableBalance,
            walletBalance = account.totalWalletBalance,
            unrealizedPnl = account.unrealizedPnl,
            lastOrderStatus = lastOrder?.status,
            message = if (lastOrder?.success == false) lastOrder.message.ifBlank { "订单失败" } else "OK"
        )
}
