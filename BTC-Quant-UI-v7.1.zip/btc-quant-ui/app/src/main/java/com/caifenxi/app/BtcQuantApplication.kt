package com.caifenxi.app

import android.app.Application
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.caifenxi.app.service.btc.BtcWatchdogWorker
import java.util.concurrent.TimeUnit

/** Standalone BTC Quant product shell. Lottery runtime/services are not initialized. */
class BtcQuantApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        instance = this
        val request = PeriodicWorkRequestBuilder<BtcWatchdogWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "btc-quant-watchdog",
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }

    companion object {
        @Volatile
        lateinit var instance: BtcQuantApplication
            private set
    }
}
