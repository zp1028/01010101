package com.caifenxi.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.btc.BtcConsensus
import com.caifenxi.app.domain.btc.BtcDashboardState
import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.BtcPlanSignal
import com.caifenxi.app.ui.BtcQuantViewModel
import com.caifenxi.app.ui.components.SectionTitle
import com.caifenxi.app.ui.theme.CaiTokens
import kotlin.math.abs

/**
 * 策略 Tab：计划策略池管理 + 多引擎编排
 *
 * 六维计划池：趋势 / 动量 / 结构 / 量价 / 波动 / 衍生品
 * 功能：计划列表 / 启用禁用 / 权重调整 / 贡献度可视化 / 共识方向汇总 / 动态权重详情
 */
@Composable
fun StrategyTab(viewModel: BtcQuantViewModel) {
    val state by viewModel.state.collectAsState()
    val poolConfig by viewModel.planPoolConfig.collectAsState()
    val orchNote by viewModel.orchestratorNote.collectAsState()

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
    ) {
        // 标题栏
        Row(
            Modifier.fillMaxWidth().padding(24.dp, 18.dp, 24.dp, 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("策略池", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                Text(
                    "六维计划池 \u00b7 动态权重 \u00b7 共识方向",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = { viewModel.refresh() }) {
                Icon(Icons.Filled.Refresh, contentDescription = "刷新")
            }
        }

        // 分析周期选择
        SectionTitle("分析周期")
        MultiTimeframeHint(state.timeframe.ifBlank { "15m" }) {
            viewModel.refresh(timeframe = it)
        }

        Spacer(Modifier.height(8.dp))

        // 共识方向汇总
        ConsensusSummaryCard(state)

        Spacer(Modifier.height(8.dp))

        // 计划策略池
        SectionTitle("计划策略池")
        PlanPoolManager(
            state = state,
            poolConfig = poolConfig,
            onToggle = viewModel::togglePlan,
            onWeightChange = viewModel::updatePlanWeight,
            onReset = viewModel::resetPlanPool
        )

        Spacer(Modifier.height(16.dp))

        // 多引擎编排
        MultiEnginePanel(viewModel, orchNote)

        Spacer(Modifier.height(40.dp))
    }
}

// ==================== 共识方向汇总 ====================

@Composable
private fun ConsensusSummaryCard(state: BtcDashboardState) {
    val c = state.consensus ?: return
    val dir = c.direction
    val dirColor = when (dir) {
        BtcDirection.UP -> CaiTokens.Success
        BtcDirection.DOWN -> CaiTokens.Danger
        BtcDirection.FLAT -> CaiTokens.Warning
    }

    Card(
        Modifier.padding(horizontal = 24.dp, vertical = 4.dp).fillMaxWidth(),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(Modifier.padding(18.dp)) {
            SectionTitleInline("共识方向（计划池加权汇总）")

            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 大方向标签
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = dirColor.copy(alpha = 0.15f)
                ) {
                    Text(
                        dir.name,
                        color = dirColor,
                        fontWeight = FontWeight.Black,
                        fontSize = 24.sp,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                    )
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        "概率 %.0f%% \u00b7 强度 %.0f%%".format(c.probability * 100, c.consensusStrength * 100),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        "预期波动 %.2f%% \u00b7 风险分 %.2f".format(c.expectedMovePct, c.riskScore),
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(Modifier.height(10.dp))

            // 多/空/震荡三向分布条
            ThreeWayBar(
                upPct = c.upScore,
                downPct = c.downScore,
                flatPct = c.flatScore
            )

            Spacer(Modifier.height(6.dp))

            // 市场环境
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(onClick = {}, label = { Text(c.regime.label()) })
                AssistChip(onClick = {}, label = { Text("趋势分 %.2f".format(c.trendScore)) })
                AssistChip(onClick = {}, label = { Text("波动率 %.4f".format(c.volatility)) })
            }
        }
    }
}

@Composable
private fun ThreeWayBar(upPct: Double, downPct: Double, flatPct: Double) {
    val total = (upPct + downPct + flatPct).coerceAtLeast(1e-9)
    val upRatio = (upPct / total).toFloat()
    val downRatio = (downPct / total).toFloat()
    val flatRatio = (1f - upRatio - downRatio).coerceAtLeast(0f)

    Column {
        // 标签行
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("多 %.0f%%".format(upPct * 100), fontSize = 10.sp, color = CaiTokens.Success)
            Text("震荡 %.0f%%".format(flatPct * 100), fontSize = 10.sp, color = CaiTokens.Warning)
            Text("空 %.0f%%".format(downPct * 100), fontSize = 10.sp, color = CaiTokens.Danger)
        }
        Spacer(Modifier.height(4.dp))
        // 分布条
        Surface(
            Modifier.fillMaxWidth().height(12.dp),
            shape = RoundedCornerShape(6.dp),
            color = MaterialTheme.colorScheme.surfaceVariant
        ) {
            Row {
                Box(Modifier.weight(upRatio).background(CaiTokens.Success))
                Box(Modifier.weight(flatRatio).background(CaiTokens.Warning))
                Box(Modifier.weight(downRatio).background(CaiTokens.Danger))
            }
        }
    }
}

// ==================== 计划策略池管理 ====================

@Composable
private fun PlanPoolManager(
    state: BtcDashboardState,
    poolConfig: BtcQuantViewModel.PlanPoolConfig,
    onToggle: (String, Boolean) -> Unit,
    onWeightChange: (String, Double) -> Unit,
    onReset: () -> Unit
) {
    // 合并引擎输出的计划信号和配置中的启用状态
    val allPlans = state.plans.sortedByDescending { abs(it.contribution) }
    val enabledSet = poolConfig.enabledPlans

    Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        // 工具栏
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "启用 ${enabledSet.size}/${allPlans.size} \u00b7 总贡献 %.2f".format(
                    allPlans.filter { it.planId in enabledSet }.sumOf { abs(it.contribution) }
                ),
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            TextButton(onClick = onReset) { Text("重置", fontSize = 12.sp) }
        }

        if (allPlans.isEmpty()) {
            Card(shape = RoundedCornerShape(16.dp)) {
                Text(
                    "暂无信号，等待更多 K 线或刷新",
                    modifier = Modifier.padding(24.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            allPlans.forEach { signal ->
                PlanCard(
                    signal = signal,
                    enabled = signal.planId in enabledSet,
                    weightOverride = poolConfig.weightOverrides[signal.planId],
                    onToggle = { onToggle(signal.planId, it) },
                    onWeightChange = { onWeightChange(signal.planId, it) }
                )
            }
        }
    }
}

@Composable
private fun PlanCard(
    signal: BtcPlanSignal,
    enabled: Boolean,
    weightOverride: Double?,
    onToggle: (Boolean) -> Unit,
    onWeightChange: (Double) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    val dirColor = when (signal.direction) {
        BtcDirection.UP -> CaiTokens.Success
        BtcDirection.DOWN -> CaiTokens.Danger
        BtcDirection.FLAT -> CaiTokens.Warning
    }
    val effectiveWeight = weightOverride ?: signal.weight
    val contributionAbs = abs(signal.contribution)
    val maxContribution = 2.0 // 用于贡献度条归一化

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (enabled) MaterialTheme.colorScheme.surface
            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(Modifier.padding(14.dp)) {
            // 第一行：启用开关 + 名称 + 方向 + 贡献度
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Switch(
                    checked = enabled,
                    onCheckedChange = onToggle,
                    modifier = Modifier.scale(0.8f)
                )
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        signal.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = if (enabled) MaterialTheme.colorScheme.onSurface
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        "${signal.planId} \u00b7 ${signal.family.label()}",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                // 方向标签
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = dirColor.copy(alpha = 0.15f)
                ) {
                    Text(
                        signal.direction.name,
                        color = dirColor,
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
                Spacer(Modifier.width(8.dp))
                // 展开按钮
                Icon(
                    Icons.Filled.ExpandMore,
                    contentDescription = if (expanded) "收起" else "展开",
                    modifier = Modifier
                        .rotate(if (expanded) 180f else 0f)
                        .clickable { expanded = !expanded },
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(Modifier.height(8.dp))

            // 贡献度可视化条
            ContributionBar(contributionAbs, maxContribution, dirColor)

            Spacer(Modifier.height(6.dp))

            // 核心指标行
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                MetricChip("贡献", "%.2f".format(signal.contribution))
                MetricChip("权重", "%.2f".format(effectiveWeight))
                MetricChip("置信", "%.0f%%".format(signal.confidence * 100))
                MetricChip("拟合", "%.2f".format(signal.regimeFit))
            }

            // 展开详情：权重调整 + 动态权重分解
            AnimatedVisibility(visible = expanded) {
                Column(Modifier.padding(top = 12.dp)) {
                    HorizontalDivider(Modifier.padding(vertical = 8.dp))

                    // 权重调整滑块
                    Text("权重调整", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    Text(
                        "覆盖动态权重引擎的计算结果，手动调整该计划的权重倍数",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(4.dp))
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("0.2x", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            "%.2fx".format(effectiveWeight),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = CaiTokens.Accent
                        )
                        Text("2.5x", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Slider(
                        value = effectiveWeight.toFloat(),
                        onValueChange = { onWeightChange(it.toDouble()) },
                        valueRange = 0.2f..2.5f,
                        steps = 22
                    )

                    Spacer(Modifier.height(8.dp))

                    // 动态权重详情
                    Text("动态权重分解", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    Spacer(Modifier.height(4.dp))
                    MetricLine("原始分", "%.4f".format(signal.rawScore))
                    MetricLine("置信度", "%.4f".format(signal.confidence))
                    MetricLine("Regime 拟合", "%.4f".format(signal.regimeFit))
                    MetricLine("基础权重", "%.2f".format(signal.weight))
                    MetricLine("有效权重", "%.2f".format(effectiveWeight))
                    MetricLine("贡献度", "%.4f = %.4f \u00d7 %.4f \u00d7 %.2f \u00d7 %.4f".format(
                        signal.contribution,
                        signal.rawScore,
                        signal.confidence,
                        effectiveWeight,
                        signal.regimeFit
                    ))
                    MetricLine("样本数", "${signal.samples}")
                    MetricLine("命中率(初始)", "%.0f%%".format(signal.hitRate * 100))

                    Spacer(Modifier.height(6.dp))
                    Text(
                        "\u26a0 权重调整仅影响 UI 层展示，实际交易信号由 BtcPlanEngine + DynamicWeightEngine 统一计算",
                        fontSize = 9.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun ContributionBar(value: Double, max: Double, color: androidx.compose.ui.graphics.Color) {
    val ratio = (value / max).toFloat().coerceIn(0f, 1f)
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("贡献度", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("%.2f".format(value), fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(2.dp))
        Surface(
            Modifier.fillMaxWidth().height(6.dp),
            shape = RoundedCornerShape(3.dp),
            color = MaterialTheme.colorScheme.surfaceVariant
        ) {
            Box(
                Modifier
                    .fillMaxWidth(ratio)
                    .background(color, RoundedCornerShape(3.dp))
            )
        }
    }
}

@Composable
private fun MetricChip(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

// ==================== 分析周期 ====================

@Composable
private fun MultiTimeframeHint(selected: String, onSelect: (String) -> Unit) {
    Row(
        Modifier.padding(horizontal = 24.dp).horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        listOf("5m", "15m", "30m", "1h", "4h").forEach { tf ->
            FilterChip(selected = selected == tf, onClick = { onSelect(tf) }, label = { Text(tf) })
        }
    }
}

// ==================== 多引擎编排 ====================

@Composable
private fun MultiEnginePanel(viewModel: BtcQuantViewModel, orchNote: String?) {
    Card(
        Modifier.padding(horizontal = 24.dp, vertical = 8.dp).fillMaxWidth(),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SectionTitleInline("多引擎编排（永续 / 事件 / Polymarket）")
            Text(
                "共享特征，分信号分 Broker；组合风控限制同向暴露。",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { viewModel.runMultiEngineTick() }) { Text("纸面一轮") }
                OutlinedButton(onClick = { viewModel.runMultiEngineTickWithKeys(paperPerp = true) }) {
                    Text("带密钥PAPER")
                }
                OutlinedButton(onClick = { viewModel.runMultiEngineTickWithKeys(paperPerp = false) }) {
                    Text("密钥真单试跑")
                }
            }
            Text(
                orchNote ?: "尚未执行编排。结果将显示永续/事件/Poly 回报。",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
