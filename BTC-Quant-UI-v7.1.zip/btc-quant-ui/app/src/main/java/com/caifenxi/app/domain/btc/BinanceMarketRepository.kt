package com.caifenxi.app.domain.btc

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray

class BinanceMarketRepository(
    private val client: OkHttpClient = OkHttpClient()
) {
    suspend fun loadKlines(symbol: String, interval: String, limit: Int = 300): List<BtcCandle> = withContext(Dispatchers.IO) {
        val url = "https://fapi.binance.com/fapi/v1/klines?symbol=$symbol&interval=$interval&limit=$limit"
        val request = Request.Builder().url(url).get().build()
        client.newCall(request).execute().use { response ->
            check(response.isSuccessful) { "行情请求失败: HTTP ${response.code}" }
            val body = response.body?.string().orEmpty()
            val arr = JSONArray(body)
            buildList(arr.length()) {
                for (i in 0 until arr.length()) {
                    val k = arr.getJSONArray(i)
                    add(BtcCandle(
                        openTime = k.getLong(0),
                        open = k.getString(1).toDouble(),
                        high = k.getString(2).toDouble(),
                        low = k.getString(3).toDouble(),
                        close = k.getString(4).toDouble(),
                        volume = k.getString(5).toDouble()
                    ))
                }
            }
        }
    }
}
