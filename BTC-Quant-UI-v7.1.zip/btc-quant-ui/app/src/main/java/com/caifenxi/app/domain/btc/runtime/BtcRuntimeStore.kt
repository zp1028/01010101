package com.caifenxi.app.domain.btc.runtime

import android.content.Context
import org.json.JSONObject

/** Persists runtime control/state only. API secrets are never persisted here. */
class BtcRuntimeStore(context: Context) {
    private val prefs = context.getSharedPreferences("btc_quant_runtime", Context.MODE_PRIVATE)

    fun config(): BtcRuntimeConfig = BtcRuntimeConfig(
        symbol = prefs.getString("symbol", "BTCUSDT") ?: "BTCUSDT",
        timeframe = prefs.getString("timeframe", "5m") ?: "5m",
        runMode = runCatching { BtcRunMode.valueOf(prefs.getString("mode", BtcRunMode.PAPER.name)!!) }.getOrDefault(BtcRunMode.PAPER),
        enabled = prefs.getBoolean("enabled", false),
        maxPositionQty = prefs.getString("maxQty", "0.001")?.toDoubleOrNull() ?: 0.001,
        pollSeconds = prefs.getLong("pollSeconds", 20L).coerceIn(10L, 60L)
    )

    fun saveConfig(value: BtcRuntimeConfig) {
        prefs.edit()
            .putString("symbol", value.symbol)
            .putString("timeframe", value.timeframe)
            .putString("mode", value.runMode.name)
            .putBoolean("enabled", value.enabled)
            .putString("maxQty", value.maxPositionQty.toString())
            .putLong("pollSeconds", value.pollSeconds)
            .apply()
    }

    fun state(): BtcRuntimeState = BtcRuntimeState(
        status = runCatching { BtcRuntimeStatus.valueOf(prefs.getString("status", BtcRuntimeStatus.STOPPED.name)!!) }.getOrDefault(BtcRuntimeStatus.STOPPED),
        lastHeartbeatAt = prefs.getLong("heartbeat", 0L),
        lastBarId = prefs.getLong("barId", 0L),
        lastSignal = runCatching { com.caifenxi.app.domain.btc.BtcDirection.valueOf(prefs.getString("direction", "FLAT")!!) }.getOrDefault(com.caifenxi.app.domain.btc.BtcDirection.FLAT),
        lastOrderClientId = prefs.getString("clientOrderId", null),
        lastError = prefs.getString("error", null),
        killSwitch = prefs.getBoolean("killSwitch", false),
        processedBars = prefs.getLong("processedBars", 0L)
    )

    fun update(transform: (BtcRuntimeState) -> BtcRuntimeState) {
        val s = transform(state())
        prefs.edit()
            .putString("status", s.status.name)
            .putLong("heartbeat", s.lastHeartbeatAt)
            .putLong("barId", s.lastBarId)
            .putString("direction", s.lastSignal.name)
            .apply { s.lastOrderClientId?.let { putString("clientOrderId", it) } ?: remove("clientOrderId") }
            .apply { s.lastError?.let { putString("error", it) } ?: remove("error") }
            .putBoolean("killSwitch", s.killSwitch)
            .putLong("processedBars", s.processedBars)
            .apply()
    }

    fun setKillSwitch(killed: Boolean) {
        update { it.copy(killSwitch = killed, status = if (killed) BtcRuntimeStatus.KILLED else BtcRuntimeStatus.STOPPED) }
    }
}
