package com.caifenxi.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.TradingSignal
import com.caifenxi.app.domain.btc.broker.BinanceFuturesEndpoint
import com.caifenxi.app.domain.btc.broker.BrokerCredentials
import com.caifenxi.app.domain.btc.runtime.BtcRunMode
import com.caifenxi.app.domain.btc.runtime.BtcRuntimeStatus
import com.caifenxi.app.ui.BtcQuantViewModel
import com.caifenxi.app.ui.components.SectionTitle
import com.caifenxi.app.ui.theme.CaiTokens

/**
 * 交易 Tab：周期涨跌预测交易 + 账户配置 + 运行时控制
 */
@Composable
fun TradeTab(viewModel: BtcQuantViewModel) {
    val state by viewModel.state.collectAsState()
    val creds by viewModel.credentials.collectAsState()

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
    ) {
        // 周期涨跌预测交易面板（核心功能）
        PredictionTradePanel(viewModel, state)

        // 账户配置
        AccountConfigPanel(viewModel, creds)

        // 运行时控制
        RuntimePanel(viewModel, state)

        Spacer(Modifier.height(40.dp))
    }
}

// ==================== 周期涨跌预测交易 ====================

@Composable
private fun PredictionTradePanel(
    viewModel: BtcQuantViewModel,
    state: com.caifenxi.app.domain.btc.BtcDashboardState
) {
    val consensus = state.consensus
    val signal = remember(consensus, state.candles, state.plans) {
        viewModel.buildPerpSignalPreview(0.001)
    }

    // 可调仓位
    var positionSize by remember { mutableStateOf("0.001") }
    var leverageCap by remember { mutableStateOf(3) }
    var orderResult by remember { mutableStateOf<String?>(null) }

    Card(
        Modifier.padding(horizontal = 24.dp, vertical = 8.dp).fillMaxWidth(),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SectionTitleInline("周期涨跌预测交易")

            if (consensus == null || signal == null) {
                // 无信号状态
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Text(
                        "暂无预测信号 \u00b7 需要共识方向非 FLAT",
                        modifier = Modifier.padding(16.dp),
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                return@Card
            }

            // === 信号概览 ===
            val dirColor = when (signal.direction) {
                BtcDirection.UP -> CaiTokens.Success
                BtcDirection.DOWN -> CaiTokens.Danger
                BtcDirection.FLAT -> CaiTokens.Warning
            }

            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 方向标签
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = dirColor.copy(alpha = 0.15f)
                ) {
                    Text(
                        if (signal.direction == BtcDirection.UP) "看涨 LONG" else "看跌 SHORT",
                        color = dirColor,
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        "概率 %.0f%% \u00b7 置信 %.0f%%".format(
                            signal.probability * 100,
                            signal.confidence * 100
                        ),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        "预期波动 %.2f%% \u00b7 ${signal.horizonBars} K线".format(signal.expectedMovePct),
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // === Entry / SL / TP ===
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            ) {
                Column(Modifier.padding(12.dp)) {
                    // Entry
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("入场价", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("%.2f".format(signal.entry), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(6.dp))

                    // 止损
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("止损 (SL)", fontSize = 12.sp, color = CaiTokens.Danger)
                        Text("%.2f".format(signal.stopLoss), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = CaiTokens.Danger)
                    }
                    val slDist = ((signal.entry - signal.stopLoss) / signal.entry * 100)
                    Text(
                        "距 SL: %.2f%%".format(kotlin.math.abs(slDist)),
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(Modifier.height(6.dp))

                    // 止盈
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("止盈 (TP)", fontSize = 12.sp, color = CaiTokens.Success)
                        Text("%.2f".format(signal.takeProfit), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = CaiTokens.Success)
                    }
                    val tpDist = ((signal.takeProfit - signal.entry) / signal.entry * 100)
                    Text(
                        "距 TP: %.2f%% \u00b7 盈亏比 %.1f:1".format(
                            kotlin.math.abs(tpDist),
                            kotlin.math.abs(tpDist / slDist)
                        ),
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // === 仓位和杠杆配置 ===
            Text("交易参数", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)

            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = positionSize,
                    onValueChange = { positionSize = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("仓位 (BTC)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("杠杆上限 ${leverageCap}x", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row {
                        listOf(1, 3, 5, 10).forEach { lev ->
                            FilterChip(
                                selected = leverageCap == lev,
                                onClick = { leverageCap = lev },
                                label = { Text("${lev}x", fontSize = 10.sp) }
                            )
                            Spacer(Modifier.width(4.dp))
                        }
                    }
                }
            }

            // 风险计算
            val pos = positionSize.toDoubleOrNull() ?: 0.0
            val notional = pos * signal.entry
            val slRisk = notional * kotlin.math.abs(slDist) / 100
            val tpReward = notional * kotlin.math.abs(tpDist) / 100
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
            ) {
                Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("名义价值", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("%.2f USDT".format(notional), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("最大亏损", fontSize = 10.sp, color = CaiTokens.Danger)
                        Text("%.2f".format(slRisk), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = CaiTokens.Danger)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("最大盈利", fontSize = 10.sp, color = CaiTokens.Success)
                        Text("%.2f".format(tpReward), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = CaiTokens.Success)
                    }
                }
            }

            // === 信号来源 ===
            if (signal.reasonPlanIds.isNotEmpty()) {
                Spacer(Modifier.height(2.dp))
                Text("信号来源", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Text(
                    signal.reasonPlanIds.joinToString(" \u00b7 "),
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // === 下单按钮 ===
            Spacer(Modifier.height(4.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        orderResult = "PAPER \u2192 ${signal.direction.name} $pos BTC @ ${"%.2f".format(signal.entry)}\nSL=${"%.2f".format(signal.stopLoss)} TP=${"%.2f".format(signal.takeProfit)} ${leverageCap}x\n\u26a0 模拟下单（Paper Trading），不触及实盘"
                    },
                    enabled = pos > 0 && consensus.direction != BtcDirection.FLAT,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("模拟下单")
                }
                OutlinedButton(
                    onClick = {
                        viewModel.runMultiEngineTickWithKeys(paperPerp = true)
                        orderResult = "已发送纸面永续一轮（带密钥 PAPER）"
                    },
                    enabled = pos > 0,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("纸面执行")
                }
            }

            // 下单结果
            orderResult?.let {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                ) {
                    Text(
                        it,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            // 黑天鹅警告
            if (state.newsBlackSwan) {
                Spacer(Modifier.height(4.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.errorContainer
                ) {
                    Text(
                        "\u26a0 当前新闻黑天鹅标记 \u2014 建议停止交易",
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }
        }
    }
}

// ==================== 账户配置 ====================

@Composable
private fun AccountConfigPanel(viewModel: BtcQuantViewModel, creds: BrokerCredentials) {
    var key by remember(creds.binanceApiKey) { mutableStateOf(creds.binanceApiKey) }
    var secret by remember(creds.binanceSecret) { mutableStateOf(creds.binanceSecret) }
    var endpoint by remember(creds.binanceEndpoint) { mutableStateOf(creds.binanceEndpoint) }
    var polyDry by remember(creds.polymarketDryRun) { mutableStateOf(creds.polymarketDryRun) }
    var saved by remember { mutableStateOf(false) }

    Card(
        Modifier.padding(horizontal = 24.dp, vertical = 8.dp).fillMaxWidth(),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SectionTitleInline("交易账户配置（API Key）")
            Text(
                "密钥仅存本机，禁止写进安装包。建议 DEMO/TESTNET 先测通。",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            OutlinedTextField(
                value = key,
                onValueChange = { key = it; saved = false },
                label = { Text("币安 API Key") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = secret,
                onValueChange = { secret = it; saved = false },
                label = { Text("币安 Secret") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth()
            )
            Text("环境", fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                BinanceFuturesEndpoint.entries.forEach { ep ->
                    FilterChip(
                        selected = endpoint == ep,
                        onClick = { endpoint = ep; saved = false },
                        label = { Text(ep.label) }
                    )
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = polyDry, onCheckedChange = { polyDry = it; saved = false })
                Text("Polymarket dry-run", fontSize = 12.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    viewModel.saveBrokerCredentials(
                        BrokerCredentials(
                            binanceApiKey = key.trim(),
                            binanceSecret = secret.trim(),
                            binanceEndpoint = endpoint,
                            polymarketDryRun = polyDry
                        )
                    )
                    saved = true
                }) { Text("保存密钥") }
                OutlinedButton(onClick = { viewModel.testBinanceConnectivity() }) { Text("测试连通") }
            }
            if (saved) {
                Text("已保存", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp)
            }
        }
    }
}

// ==================== 运行时控制 ====================

@Composable
private fun RuntimePanel(viewModel: BtcQuantViewModel, state: com.caifenxi.app.domain.btc.BtcDashboardState) {
    val runtime by viewModel.runtimeState.collectAsState()
    val cfg by viewModel.runtimeConfig.collectAsState()
    val running = runtime.status == BtcRuntimeStatus.RUNNING
    val killed = runtime.killSwitch

    LaunchedEffect(runtime.status) {
        viewModel.refreshRuntimeState()
    }

    Card(
        Modifier.padding(horizontal = 24.dp, vertical = 8.dp).fillMaxWidth(),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("挂机运行控制", fontWeight = FontWeight.Bold)
                    Text(
                        "${cfg.runMode.name} \u00b7 ${cfg.symbol} ${cfg.timeframe}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                AssistChip(
                    onClick = {},
                    label = { Text(runtime.status.name) },
                    leadingIcon = {
                        Icon(
                            if (killed) Icons.Filled.Warning
                            else if (running) Icons.Filled.PlayArrow
                            else Icons.Filled.Pause,
                            null
                        )
                    }
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "心跳 ${fmtTime(runtime.lastHeartbeatAt)} \u00b7 已处理 ${runtime.processedBars} 根 \u00b7 末向 ${runtime.lastSignal?.name ?: "\u2014"}",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            MetricLine("运行时 Funding", runtime.lastFundingRate?.let { "%.6f".format(it) } ?: "\u2014")
            MetricLine("运行时 OI\u0394%", runtime.lastOiChangePct?.let { "%.2f".format(it) } ?: "\u2014")
            MetricLine("运行时衍分", runtime.lastDerivScore?.let { "%.2f".format(it) } ?: "\u2014")
            runtime.lastError?.let {
                Text(it, color = MaterialTheme.colorScheme.error, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
            }
            if (state.newsBlackSwan) {
                Text("当前新闻黑天鹅标记：建议保持停止/全停", color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = !running && !killed, onClick = {
                    viewModel.setRuntimeEnabled(true, BtcRunMode.PAPER)
                }) { Text("启动模拟") }
                OutlinedButton(enabled = running, onClick = {
                    viewModel.setRuntimeEnabled(false)
                }) { Text("停止") }
                OutlinedButton(enabled = !killed, onClick = { viewModel.killRuntime() }) { Text("全停") }
                if (killed) OutlinedButton(onClick = { viewModel.resumeRuntime() }) { Text("解除") }
            }
        }
    }
}
