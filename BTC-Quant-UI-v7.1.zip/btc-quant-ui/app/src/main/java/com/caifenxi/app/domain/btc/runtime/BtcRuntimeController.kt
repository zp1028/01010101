package com.caifenxi.app.domain.btc.runtime

import com.caifenxi.app.domain.btc.BinanceDerivativesRepository
import com.caifenxi.app.domain.btc.BinanceMarketRepository
import com.caifenxi.app.domain.btc.BtcPlanEngine
import com.caifenxi.app.domain.btc.BtcSignalFactory
import com.caifenxi.app.domain.btc.DerivativesFeatureEngine
import com.caifenxi.app.domain.btc.news.CryptoNewsRepository
import com.caifenxi.app.domain.btc.ai.AiBrain
import com.caifenxi.app.domain.btc.ai.AiPolicy
import com.caifenxi.app.domain.btc.ai.AiPolicyConfig
import com.caifenxi.app.domain.btc.broker.PerpBroker
import com.caifenxi.app.domain.btc.risk.BtcRiskEngine
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope

/** P2 runtime loop + P3 derivatives features. Default PAPER; TESTNET needs injected broker. */
class BtcRuntimeController(
    private val market: BinanceMarketRepository = BinanceMarketRepository(),
    private val derivatives: BinanceDerivativesRepository = BinanceDerivativesRepository(),
    private val newsRepo: CryptoNewsRepository = CryptoNewsRepository(),
    private val aiBrain: AiBrain = AiBrain(),
    private val aiPolicy: AiPolicyConfig = AiPolicyConfig(allowLiveAiOrders = false),
    private val engine: BtcPlanEngine = BtcPlanEngine(),
    private val signalFactory: BtcSignalFactory = BtcSignalFactory(),
    private val risk: BtcRiskEngine = BtcRiskEngine(),
    private val store: BtcRuntimeStore,
    private val broker: PerpBroker? = null,
    private val gate: BtcExecutionGate = BtcExecutionGate()
) {
    suspend fun runOnce() {
        val cfg = store.config()
        if (!cfg.enabled || store.state().killSwitch) return
        coroutineScope {
            val candlesDef = async { market.loadKlines(cfg.symbol, cfg.timeframe, 300) }
            val fundingDef = async {
                runCatching { derivatives.fundingHistory(cfg.symbol, 100) }.getOrDefault(emptyList())
            }
            val oiDef = async {
                runCatching { derivatives.openInterestHistory(cfg.symbol, cfg.timeframe.ifBlank { "15m" }, 100) }
                    .getOrDefault(emptyList())
            }
            val snapDef = async {
                runCatching { derivatives.snapshot(cfg.symbol) }.getOrNull()
            }
            val candles = candlesDef.await()
            if (candles.isEmpty()) return@coroutineScope
            val last = candles.last()
            val current = store.state()
            if (current.lastBarId == last.openTime) {
                store.update {
                    it.copy(status = BtcRuntimeStatus.RUNNING, lastHeartbeatAt = System.currentTimeMillis())
                }
                return@coroutineScope
            }
            val funding = fundingDef.await()
            val oi = oiDef.await()
            val snap = snapDef.await()
            val prev = candles.getOrNull(candles.lastIndex - 1)
            val deriv = DerivativesFeatureEngine.build(
                barTime = last.openTime,
                close = last.close,
                prevClose = prev?.close,
                fundingHistory = funding,
                oiHistory = oi,
                snapshot = snap
            )
            val news = runCatching { newsRepo.snapshot() }.getOrNull()
            val (basePlans, baseConsensus) = engine.evaluate(candles, deriv)
            val aiCand = aiBrain.generateCandidate(candles, basePlans, baseConsensus, news, deriv)
            if (news?.blackSwan == true && aiPolicy.haltOnBlackSwan) {
                store.update { it.copy(
                    status = BtcRuntimeStatus.PAUSED,
                    lastError = "新闻黑天鹅熔断",
                    lastHeartbeatAt = System.currentTimeMillis(),
                    lastBarId = last.openTime
                ) }
                return@coroutineScope
            }
            val aiPlan = AiPolicy.toPlanSignal(aiCand, aiPolicy)
            val (plans, consensus) = if (aiPlan != null) {
                engine.evaluate(candles, deriv, extraSignals = listOf(aiPlan))
            } else basePlans to baseConsensus
            val signal = if (consensus != null) {
                signalFactory.buildPerpSignal(cfg.symbol, candles, plans, consensus, cfg.maxPositionQty)
            } else null
            store.update {
                it.copy(
                    status = BtcRuntimeStatus.RUNNING,
                    lastHeartbeatAt = System.currentTimeMillis(),
                    lastBarId = last.openTime,
                    lastSignal = consensus?.direction,
                    processedBars = it.processedBars + 1,
                    lastError = null,
                    lastFundingRate = deriv.fundingRate,
                    lastOiChangePct = deriv.oiChangePct,
                    lastDerivScore = deriv.derivativesScore
                )
            }
            if (signal == null || consensus == null) return@coroutineScope
            val decision = risk.authorize(consensus, dailyPnlPct = 0.0, currentDrawdownPct = 0.0, requestedNotionalPct = 5.0)
            if (!decision.allowed) {
                store.update { it.copy(status = BtcRuntimeStatus.PAUSED, lastError = decision.reason) }
                return@coroutineScope
            }
            if (!gate.claim(signal.planId, signal.symbol, cfg.timeframe, signal.barId)) return@coroutineScope
            try {
                when (cfg.runMode) {
                    BtcRunMode.PAPER -> {
                        // no live order
                    }
                    BtcRunMode.TESTNET, BtcRunMode.LIVE -> {
                        val b = broker ?: run {
                            store.update { it.copy(lastError = "Broker 未注入") }
                            return@coroutineScope
                        }
                        b.place(signal)
                    }
                }
            } catch (e: Exception) {
                store.update { it.copy(lastError = e.message) }
            }
        }
    }
}
