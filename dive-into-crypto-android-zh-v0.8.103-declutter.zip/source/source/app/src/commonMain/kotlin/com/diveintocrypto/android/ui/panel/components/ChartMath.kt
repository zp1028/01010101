package com.diveintocrypto.android.ui.panel.components

import com.diveintocrypto.android.domain.cvd.CvdBucket
import com.diveintocrypto.android.domain.model.Candle
import com.diveintocrypto.android.platform.format
import kotlin.math.abs

/**
 * PURE chart-scale math for the Panel candlestick chart (no Compose, no clock,
 * no I/O — fully unit-tested in commonTest). The composable in [CandleChart.kt]
 * consumes these; every mapping decision lives here so the visual code stays
 * dumb and the math stays honest.
 */
object ChartMath {

    /** Inclusive price domain of a chart viewport. */
    data class ChartRange(val min: Double, val max: Double) {
        val width: Double get() = max - min
    }

    /**
     * Price domain over the candle highs/lows UNIONed with every finite Bollinger
     * band value (the band must never be clipped outside the viewport), padded
     * symmetrically so candles don't kiss the frame. Degenerate inputs degrade
     * honestly: no finite data → 0..1; flat series → ±1% around the single value.
     */
    fun chartPriceRange(
        candles: List<Candle>,
        bbUpper: List<Double?> = emptyList(),
        bbLower: List<Double?> = emptyList(),
        padFraction: Double = 0.06,
    ): ChartRange {
        var min = Double.MAX_VALUE
        var max = -Double.MAX_VALUE
        // Market prices must be finite and strictly positive. A malformed
        // candle or indicator value (e.g. 0, negative, NaN, +/-Infinity)
        // must not stretch the entire vertical domain and make valid candles
        // appear flattened or detached from their overlays.
        for (c in candles) {
            // Treat OHLC as one record: accepting only a low/high pair while
            // open/close are malformed can still admit a corrupt candle into
            // the domain. Require a coherent, positive OHLC envelope.
            val ohlc = listOf(c.open, c.high, c.low, c.close)
            val validOhlc = ohlc.all { it.isFinite() && it > 0.0 } &&
                c.low <= minOf(c.open, c.close) &&
                c.high >= maxOf(c.open, c.close) &&
                c.low <= c.high
            if (validOhlc) {
                min = minOf(min, c.low)
                max = maxOf(max, c.high)
            }
        }
        for (series in listOf(bbUpper, bbLower)) {
            for (v in series) {
                if (v != null && v.isFinite() && v > 0.0) {
                    min = minOf(min, v)
                    max = maxOf(max, v)
                }
            }
        }
        if (min > max) return ChartRange(0.0, 1.0) // nothing finite
        if (min == max) {
            val pad = if (min != 0.0) abs(min) * 0.01 else 1.0
            return ChartRange(min - pad, max + pad)
        }
        // Callers may eventually expose padding as a UI setting. Never let NaN,
        // infinity, or a negative/oversized value invert or explode the chart range.
        val safePadFraction = if (padFraction.isFinite()) padFraction.coerceIn(0.0, 0.25) else 0.06
        val rawWidth = max - min
        // A finite pair of extreme Double values can still overflow when subtracted.
        // In that pathological case, avoid an infinite pad and keep the finite bounds.
        val pad = if (rawWidth.isFinite()) rawWidth * safePadFraction else 0.0
        val paddedMin = min - pad
        val paddedMax = max + pad
        return ChartRange(
            min = if (paddedMin.isFinite() && paddedMin > 0.0) paddedMin else min,
            max = if (paddedMax.isFinite()) paddedMax else max,
        )
    }

    /**
     * Extends a candle price domain to include finite positive overlay/reference levels.
     * Candles, EMA/AVL/SMC and entry/SL/TP lines must share this exact domain so the
     * lines stay aligned instead of being clipped or pinned to a chart edge.
     */
    fun includeOverlayPrices(range: ChartRange, prices: List<Double>, edgePadFraction: Double = 0.035): ChartRange {
        if (!range.min.isFinite() || !range.max.isFinite() || range.max <= range.min) return range
        val valid = prices.filter { it.isFinite() && it > 0.0 }
        if (valid.isEmpty()) return range
        val overlayMin = valid.minOrNull()!!
        val overlayMax = valid.maxOrNull()!!
        val lo = minOf(range.min, overlayMin)
        val hi = maxOf(range.max, overlayMax)
        if (!lo.isFinite() || !hi.isFinite() || hi <= lo) return range
        val extends = overlayMin < range.min || overlayMax > range.max
        val fraction = edgePadFraction.takeIf { it.isFinite() }?.coerceIn(0.0, 0.10) ?: 0.035
        val pad = if (extends) (hi - lo).takeIf { it.isFinite() }?.times(fraction) ?: 0.0 else 0.0
        val newMin = (lo - pad).coerceAtLeast(0.0)
        val newMax = hi + pad
        return if (newMin.isFinite() && newMax.isFinite() && newMax > newMin) ChartRange(newMin, newMax) else range
    }

    /**
     * Maps a price to a pixel Y inside [topPx, bottomPx] (top = range.max).
     * Clamped to the area; degenerate range maps to the middle (honest flat line).
     */
    fun scaleY(value: Double, range: ChartRange, topPx: Float, bottomPx: Float): Float {
        // Never propagate NaN/Infinity into Canvas coordinates. A midpoint is
        // a deterministic neutral fallback for malformed values or geometry.
        if (!value.isFinite() || !range.min.isFinite() || !range.max.isFinite() ||
            !topPx.isFinite() || !bottomPx.isFinite()) {
            return midpoint(topPx, bottomPx)
        }
        val width = range.max - range.min
        // Finite endpoints can still produce an infinite width (e.g. -MAX..MAX).
        // Dividing an infinite numerator by infinite width yields NaN, which must
        // never reach Canvas coordinates. Invalid/reversed domains use a neutral Y.
        if (!width.isFinite() || width <= 0.0) return midpoint(topPx, bottomPx)
        val numerator = value - range.min
        if (!numerator.isFinite()) return midpoint(topPx, bottomPx)
        val fraction = numerator / width
        if (!fraction.isFinite()) return midpoint(topPx, bottomPx)
        val t = fraction.toFloat().coerceIn(0f, 1f)
        val y = bottomPx - t * (bottomPx - topPx)
        return if (y.isFinite()) y else midpoint(topPx, bottomPx)
    }

    private fun midpoint(topPx: Float, bottomPx: Float): Float = when {
        topPx.isFinite() && bottomPx.isFinite() -> topPx / 2f + bottomPx / 2f
        else -> 0f
    }

    /**
     * Shared right-side label gutter for Panel and Analysis mini-charts so
     * TP/ENTRY/SL text never sits on top of the rightmost candles.
     */
    fun labelGutterPx(
        canvasWidth: Float,
        minGutter: Float = 48f,
        maxGutter: Float = 72f,
        maxFraction: Float = 0.28f,
    ): Float {
        if (!canvasWidth.isFinite() || canvasWidth <= 0f) return minGutter
        val byFraction = canvasWidth * maxFraction.coerceIn(0.1f, 0.4f)
        return byFraction.coerceIn(minGutter, maxGutter).coerceAtMost(canvasWidth * 0.4f)
    }

    /** Plot area width once the right label gutter is reserved. */
    fun plotRightPx(canvasWidth: Float, gutter: Float = labelGutterPx(canvasWidth)): Float {
        if (!canvasWidth.isFinite() || canvasWidth <= 0f) return 0f
        val g = gutter.coerceIn(0f, canvasWidth * 0.4f)
        return (canvasWidth - g).coerceAtLeast(canvasWidth * 0.6f)
    }

    /**
     * Decimal count for the right-edge price-axis labels, chosen from the
     * viewport WIDTH (not the price magnitude): a $60k chart with a $40 range
     * needs more decimals than a $0.02 chart with a $0.01 range.
     */
    fun axisDecimals(range: ChartRange): Int = when {
        range.width <= 0.0 -> 2
        range.width < 0.001 -> 6
        range.width < 0.01 -> 5
        range.width < 0.1 -> 4
        range.width < 1.0 -> 3
        range.width < 100.0 -> 2
        range.width < 1000.0 -> 1
        else -> 0
    }

    /**
     * Decimal count for ONE price value (magnitude-based) — used for threshold
     * formatting and the live-price cell, where there is no viewport to measure.
     */
    fun priceDecimalsFor(price: Double): Int = when {
        price <= 0.0 -> 2
        price < 0.01 -> 6
        price < 0.1 -> 5
        price < 1.0 -> 4
        price < 10.0 -> 3
        else -> 2
    }

    /** Axis label text (un-grouped so the right gutter stays narrow). */
    fun formatAxisPrice(value: Double, decimals: Int): String = value.format(decimals.coerceIn(0, 8))

    /** Largest candle volume in the viewport (0 when empty). */
    fun maxVolume(candles: List<Candle>): Double =
        candles.fold(0.0) { acc, c -> if (c.volume.isFinite()) maxOf(acc, c.volume) else acc }

    /** Largest |delta| across the CVD minute buckets (0 when empty). */
    fun maxAbsDelta(buckets: List<CvdBucket>): Double =
        buckets.fold(0.0) { acc, b -> if (b.delta.isFinite()) maxOf(acc, abs(b.delta)) else acc }
}
