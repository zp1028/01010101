package com.diveintocrypto.android.domain.scanner

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import com.diveintocrypto.android.platform.format
import kotlinx.serialization.Serializable

/**
 * Pure, local-first generator for PREPARATORY entry plans.
 *
 * This engine intentionally does not place orders and does not claim that a trigger has
 * happened. It only emits plans when the currently available snapshot has enough structure
 * and volatility information to define a falsifiable scenario. A caller must refresh the
 * snapshot and revalidate the trigger before showing a plan as actionable.
 */
object ForwardEntryPlanEngine {
    @Serializable
    enum class Direction { LONG, SHORT }
    @Serializable
    enum class Type { BREAKOUT_PREPARATION, RETEST_PREPARATION, REVERSAL_PREPARATION, TREND_CONTINUATION }
    @Serializable
    enum class Status { PREPARING, WAITING_TRIGGER, CONDITION_MET, INVALID, EXPIRED, COMPLETED }

    @Serializable
    data class TimeframeEvidence(
        val timeframe: String,
        val direction: Int,
        val confidence: Int,
        val timeWeight: Int = 50,
    )

    data class Input(
        val symbol: String,
        val currentPrice: Double,
        val atrPercent: Double?,
        val support: Double?,
        val resistance: Double?,
        val dominantDirection: Int,
        val mtfDirection: Int,
        val mtfGate: Boolean,
        val regime: String,
        val evidence: List<TimeframeEvidence>,
        val divergenceDirection: Int = 0,
        val candleOpenTimeMs: Long?,
        val candleTimeframeMs: Long?,
        val generatedAtMs: Long,
        val nowMs: Long = generatedAtMs,
        val validForMs: Long = 4 * 60 * 60 * 1000L,
        val targetR: Double = 1.5,
        /** Estimated fee and slippage per side, expressed as percent of notional. */
        val feeSidePct: Double = 0.05,
        val slippageSidePct: Double = 0.02,
        val maxEntryDistanceAtr: Double = 1.5,
        val minQuality: Int = 55,
    )

    @Serializable
    data class Plan(
        val id: String,
        val symbol: String,
        val direction: Direction,
        val type: Type,
        val primaryTimeframe: String,
        val generatedAtMs: Long,
        val expiresAtMs: Long,
        val referencePrice: Double,
        /** Maximum price drift from the captured reference before mandatory revalidation. */
        val maxAllowedPriceMovePct: Double,
        val entryLow: Double,
        val entryHigh: Double,
        val triggerPrice: Double,
        val stopLoss: Double,
        val takeProfit: Double,
        val riskRewardRatio: Double,
        val quality: Int,
        val status: Status,
        val triggerRule: String,
        val invalidationRule: String,
        val validationNotes: List<String>,
        val snapshotKey: String,
    )

    data class Result(val plans: List<Plan>, val rejectionReasons: Map<String, Int>)

    /** Generate deterministic candidate plans from a single completed scanner snapshot. */
    fun generate(input: Input): Result {
        val rejected = linkedMapOf<String, Int>()
        fun reject(reason: String) { rejected[reason] = (rejected[reason] ?: 0) + 1 }
        val symbol = input.symbol.trim().uppercase()
        if (symbol.isBlank()) { reject("symbol_missing"); return Result(emptyList(), rejected) }
        if (!input.currentPrice.isFinite() || input.currentPrice <= 0.0) { reject("price_invalid"); return Result(emptyList(), rejected) }
        val atrPct = input.atrPercent?.takeIf { it.isFinite() && it in 0.01..25.0 }
        if (atrPct == null) { reject("atr_missing_or_invalid"); return Result(emptyList(), rejected) }
        if (input.dominantDirection !in -1..1 || input.mtfDirection !in -1..1) { reject("direction_invalid"); return Result(emptyList(), rejected) }
        if (input.generatedAtMs <= 0L || input.validForMs <= 0L || input.targetR <= 0.0 || !input.targetR.isFinite() ||
            !input.feeSidePct.isFinite() || input.feeSidePct !in 0.0..1.0 ||
            !input.slippageSidePct.isFinite() || input.slippageSidePct !in 0.0..2.0) {
            reject("plan_parameters_invalid"); return Result(emptyList(), rejected)
        }
        val freshness = MarketDataFreshness.assess(
            input.candleOpenTimeMs, input.candleTimeframeMs, input.nowMs,
        )
        if (freshness.status != MarketDataFreshness.Status.FRESH) {
            reject("market_data_${freshness.status.name.lowercase()}"); return Result(emptyList(), rejected)
        }
        if (input.dominantDirection == 0) { reject("no_directional_bias"); return Result(emptyList(), rejected) }
        if (input.mtfDirection != 0 && input.mtfDirection != input.dominantDirection) {
            reject("timeframe_conflict"); return Result(emptyList(), rejected)
        }

        val direction = if (input.dominantDirection > 0) Direction.LONG else Direction.SHORT
        val atr = input.currentPrice * atrPct / 100.0
        if (!atr.isFinite() || atr <= 0.0) { reject("atr_invalid"); return Result(emptyList(), rejected) }
        val primaryTf = choosePrimaryTimeframe(input.evidence, input.dominantDirection)
        val expires = input.generatedAtMs + input.validForMs
        if (expires <= input.generatedAtMs) { reject("expiry_overflow"); return Result(emptyList(), rejected) }
        if (input.nowMs < input.generatedAtMs) { reject("snapshot_time_invalid"); return Result(emptyList(), rejected) }
        if (input.nowMs >= expires) { reject("plan_expired"); return Result(emptyList(), rejected) }
        val notes = mutableListOf<String>()
        notes += "本地量化预备计划；尚未确认触发"
        if (!input.mtfGate) notes += "高周期共振未完全确认，质量分已受限"

        val candidates = mutableListOf<Plan>()
        val support = input.support?.takeIf { it.isFinite() && it > 0.0 && it < input.currentPrice }
        val resistance = input.resistance?.takeIf { it.isFinite() && it > input.currentPrice }
        val maxDistance = atr * input.maxEntryDistanceAtr.coerceIn(0.25, 5.0)

        fun add(type: Type, entryLow: Double, entryHigh: Double, trigger: Double, structuralStop: Double?, baseQuality: Int, rule: String, invalidation: String) {
            if (!entryLow.isFinite() || !entryHigh.isFinite() || !trigger.isFinite() || entryLow <= 0.0 || entryHigh < entryLow || trigger <= 0.0) {
                reject("${type.name.lowercase()}_entry_invalid"); return
            }
            val entry = (entryLow + entryHigh) / 2.0
            val atrStop = if (direction == Direction.LONG) entry - atr * 1.25 else entry + atr * 1.25
            val candidateStop = structuralStop?.takeIf { it.isFinite() && it > 0.0 }
            val stop = when {
                candidateStop == null -> atrStop
                direction == Direction.LONG -> min(atrStop, candidateStop)
                else -> max(atrStop, candidateStop)
            }
            if (!stop.isFinite() || stop <= 0.0 || (direction == Direction.LONG && stop >= entry) || (direction == Direction.SHORT && stop <= entry)) {
                reject("${type.name.lowercase()}_stop_invalid"); return
            }
            val risk = abs(entry - stop)
            val target = if (direction == Direction.LONG) entry + risk * input.targetR else entry - risk * input.targetR
            if (!target.isFinite() || target <= 0.0) { reject("${type.name.lowercase()}_target_invalid"); return }
            val oneSideCostRate = (input.feeSidePct + input.slippageSidePct) / 100.0
            val entryAndExitCosts = (entry + stop) * oneSideCostRate
            val netRisk = risk + entryAndExitCosts
            val grossReward = abs(target - entry)
            val netReward = grossReward - (entry + target) * oneSideCostRate
            if (!netRisk.isFinite() || netRisk <= 0.0 || !netReward.isFinite() || netReward <= 0.0) {
                reject("${type.name.lowercase()}_net_reward_after_costs_invalid"); return
            }
            val netRr = netReward / netRisk
            val distAtr = abs(input.currentPrice - entry) / atr
            val distancePenalty = (distAtr * 12.0).toInt().coerceIn(0, 30)
            val conflictPenalty = if (input.mtfDirection == 0 || !input.mtfGate) 10 else 0
            val quality = (baseQuality - distancePenalty - conflictPenalty).coerceIn(0, 100)
            if (quality < input.minQuality.coerceIn(0, 100)) { reject("${type.name.lowercase()}_quality_below_threshold"); return }
            val snapshotKey = listOf(symbol, direction.name, type.name, primaryTf, input.generatedAtMs.toString()).joinToString("|")
            candidates += Plan(
                id = snapshotKey,
                symbol = symbol,
                direction = direction,
                type = type,
                primaryTimeframe = primaryTf,
                generatedAtMs = input.generatedAtMs,
                expiresAtMs = expires,
                referencePrice = input.currentPrice,
                maxAllowedPriceMovePct = max(0.20, atrPct * 1.5),
                entryLow = entryLow,
                entryHigh = entryHigh,
                triggerPrice = trigger,
                stopLoss = stop,
                takeProfit = target,
                riskRewardRatio = netRr,
                quality = quality,
                status = Status.WAITING_TRIGGER,
                triggerRule = rule,
                invalidationRule = invalidation,
                validationNotes = notes + "风险收益比已扣估算双边手续费${input.feeSidePct}%与双边滑点${input.slippageSidePct}%",
                snapshotKey = snapshotKey,
            )
        }

        when (direction) {
            Direction.LONG -> {
                resistance?.takeIf { it - input.currentPrice in 0.0..maxDistance }?.let { level ->
                    val trigger = level + atr * 0.10
                    val low = trigger - atr * 0.15
                    val high = trigger + atr * 0.15
                    add(Type.BREAKOUT_PREPARATION, low, high, trigger, support?.minus(atr * 0.15), 78,
                        "价格突破阻力 ${fmt(level)}，并由已收盘 K 线确认；触发后重新校验追价距离与净风险收益比",
                        "收盘重新跌回阻力下方并破坏整理结构，或计划到期")
                }
                support?.takeIf { input.currentPrice - it in 0.0..(atr * 0.65) }?.let { level ->
                    val low = level - atr * 0.10
                    val high = level + atr * 0.25
                    val trigger = high
                    add(Type.RETEST_PREPARATION, low, high, trigger, level - atr * 0.35, 82,
                        "价格回到支撑区后，已收盘 K 线重新站上区间上沿且方向信号未反转",
                        "有效跌破支撑缓冲区、方向反转或计划到期")
                    if (input.divergenceDirection > 0) {
                        add(Type.REVERSAL_PREPARATION, low, high, trigger, level - atr * 0.35, 68,
                            "支撑附近出现看涨背离后，等待收盘确认；背离本身不构成入场",
                            "支撑失守、背离消失或计划到期")
                    }
                }
                if (input.regime.equals("TREND", true) && input.mtfGate && support != null && input.currentPrice - support <= atr * 0.65) {
                    add(Type.TREND_CONTINUATION, support - atr * 0.10, support + atr * 0.25, support + atr * 0.25,
                        support - atr * 0.35, 80, "高周期趋势仍有效；回踩支撑区后收盘确认恢复上行",
                        "高周期趋势失效、支撑失守或计划到期")
                }
            }
            Direction.SHORT -> {
                support?.takeIf { input.currentPrice - it in 0.0..maxDistance }?.let { level ->
                    val trigger = level - atr * 0.10
                    val low = trigger - atr * 0.15
                    val high = trigger + atr * 0.15
                    add(Type.BREAKOUT_PREPARATION, low, high, trigger, resistance?.plus(atr * 0.15), 78,
                        "价格跌破支撑 ${fmt(level)}，并由已收盘 K 线确认；触发后重新校验追价距离与净风险收益比",
                        "收盘重新站回支撑上方并破坏下跌结构，或计划到期")
                }
                resistance?.takeIf { it - input.currentPrice in 0.0..(atr * 0.65) }?.let { level ->
                    val low = level - atr * 0.25
                    val high = level + atr * 0.10
                    val trigger = low
                    add(Type.RETEST_PREPARATION, low, high, trigger, level + atr * 0.35, 82,
                        "价格回到阻力区后，已收盘 K 线重新跌回区间下沿且方向信号未反转",
                        "有效突破阻力缓冲区、方向反转或计划到期")
                    if (input.divergenceDirection < 0) {
                        add(Type.REVERSAL_PREPARATION, low, high, trigger, level + atr * 0.35, 68,
                            "阻力附近出现看跌背离后，等待收盘确认；背离本身不构成入场",
                            "阻力突破、背离消失或计划到期")
                    }
                }
                if (input.regime.equals("TREND", true) && input.mtfGate && resistance != null && resistance - input.currentPrice <= atr * 0.65) {
                    add(Type.TREND_CONTINUATION, resistance - atr * 0.25, resistance + atr * 0.10, resistance - atr * 0.25,
                        resistance + atr * 0.35, 80, "高周期下行趋势仍有效；反弹至阻力区后收盘确认恢复下行",
                        "高周期趋势失效、阻力突破或计划到期")
                }
            }
        }
        if (candidates.isEmpty() && rejected.isEmpty()) reject("no_nearby_confirmed_structure")
        // Prefer the strongest candidate when two strategy labels describe effectively
        // the same price structure; avoid filling the board with duplicate plans.
        val sorted = candidates.sortedWith(compareByDescending<Plan> { it.quality }.thenBy { it.expiresAtMs })
        val unique = mutableListOf<Plan>()
        for (candidate in sorted) {
            val duplicate = unique.any { existing ->
                if (existing.symbol != candidate.symbol || existing.direction != candidate.direction || existing.primaryTimeframe != candidate.primaryTimeframe) false
                else {
                    val triggerGapPct = abs(existing.triggerPrice - candidate.triggerPrice) / input.currentPrice * 100.0
                    val overlap = max(existing.entryLow, candidate.entryLow) <= min(existing.entryHigh, candidate.entryHigh)
                    overlap && triggerGapPct <= 0.10
                }
            }
            if (!duplicate) unique += candidate
        }
        return Result(unique, rejected)
    }

    /** Select the highest-weighted timeframe supporting the proposed direction. */
    fun choosePrimaryTimeframe(evidence: List<TimeframeEvidence>, direction: Int): String {
        val weights = mapOf("1d" to 100, "12h" to 95, "8h" to 90, "6h" to 85, "4h" to 80, "2h" to 70, "1h" to 65, "30m" to 55, "15m" to 50, "5m" to 35, "1m" to 20)
        return evidence.asSequence()
            .filter { it.direction == direction && it.confidence in 0..100 }
            .maxByOrNull { (weights[it.timeframe.lowercase()] ?: it.timeWeight.coerceIn(0, 100)) * 2 + it.confidence }
            ?.timeframe ?: evidence.maxByOrNull { it.timeWeight }?.timeframe ?: "1h"
    }

    private fun fmt(value: Double): String = if (value >= 1000.0) value.format(2) else value.format(6).trimEnd('0').trimEnd('.')
}
