package com.diveintocrypto.android.ui.scanner

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.diveintocrypto.android.ui.theme.DiveColors
import com.diveintocrypto.android.ui.theme.DiveFonts

/**
 * 扫描结果榜切换（AI十佳 / 共识 / 启动 / 前瞻）。
 */

/** 排行分页：AI十佳 = 决策面；共识 = 原引擎顺序；启动 = 仅展示层另算；前瞻 = 计划回放。 */
internal enum class RankBoard { AI_TOP, CONSENSUS, EARLY, FORWARD }


@Composable
internal fun RankBoardToggle(
    selected: RankBoard,
    aiTopCount: Int,
    consensusCount: Int,
    earlyCount: Int,
    forwardCount: Int,
    onSelect: (RankBoard) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            RankBoardPill(
                label = "AI 十佳",
                sub = "$aiTopCount",
                selected = selected == RankBoard.AI_TOP,
                modifier = Modifier.weight(1f),
                onClick = { onSelect(RankBoard.AI_TOP) },
            )
            RankBoardPill(
                label = "共识排行",
                sub = "$consensusCount",
                selected = selected == RankBoard.CONSENSUS,
                modifier = Modifier.weight(1f),
                onClick = { onSelect(RankBoard.CONSENSUS) },
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            RankBoardPill(
                label = "启动排行",
                sub = "$earlyCount",
                selected = selected == RankBoard.EARLY,
                modifier = Modifier.weight(1f),
                onClick = { onSelect(RankBoard.EARLY) },
            )
            RankBoardPill(
                label = "前瞻计划",
                sub = "$forwardCount",
                selected = selected == RankBoard.FORWARD,
                modifier = Modifier.weight(1f),
                onClick = { onSelect(RankBoard.FORWARD) },
            )
        }
    }
}

@Composable
internal fun RankBoardPill(
    label: String,
    sub: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) DiveColors.Accent.copy(alpha = 0.18f) else DiveColors.BgCard)
            .border(
                1.dp,
                if (selected) DiveColors.Accent else DiveColors.Border,
                RoundedCornerShape(10.dp),
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
    ) {
        Text(
            text = label,
            color = if (selected) DiveColors.Accent else DiveColors.TextMuted,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = DiveFonts.body,
        )
        Spacer(Modifier.height(2.dp))
        Text(
            text = "候选 $sub",
            color = DiveColors.TextDim,
            fontSize = 10.sp,
        )
    }

