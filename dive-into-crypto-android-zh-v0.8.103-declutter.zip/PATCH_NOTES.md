# Declutter pack

## Structure
- ScannerAiTopUi.kt — AiTopPickCard + fusion status labels
- ScannerRankBoardUi.kt — RankBoard enum + toggle pills
- ScannerRiskAdvisorUi.kt — RiskAdvisorBlock + price/metric cells
- ScannerScreen.kt ~4200 → ~3670 lines (behavior unchanged)

## Prior features retained
AI Top-10 judgment ranking, progressive scan, chart gutter, cache, etc.
