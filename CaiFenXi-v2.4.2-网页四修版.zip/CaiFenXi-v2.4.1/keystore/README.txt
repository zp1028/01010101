彩析 Release 签名密钥

文件: caifenxi-release.jks
alias: caifenxi
storePassword / keyPassword: caifenxi2026

覆盖安装必须使用同一把 keystore。请自行备份，不要公开上传到开源仓库。
