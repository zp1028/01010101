/* cfx_inject.js - Core DOM scoring & click logic for GenericSiteAdapter
 * Loaded from assets at runtime, injected via WebView.evaluateJavascript
 * This file contains all __cfx* helper functions and the main __caiFenXiRunCommand entry point
 */

function __cfxNorm(s){ return (s||'').replace(/\s+/g,'').trim(); }
function __cfxVisible(el){
  if(!el||el.disabled) return false;
  var st=window.getComputedStyle(el);
  if(st.display==='none'||st.visibility==='hidden'||parseFloat(st.opacity||'1')===0) return false;
  var r=el.getBoundingClientRect();
  return r.width>8&&r.height>8&&r.bottom>0&&r.top<innerHeight&&r.right>0&&r.left<innerWidth;
}
function __cfxBlob(el){
  var bits=[el.className&&String(el.className), el.id,
    el.getAttribute('data-type'), el.getAttribute('data-play'),
    el.getAttribute('data-name'), el.getAttribute('data-value'),
    el.getAttribute('aria-label'), el.name, el.getAttribute('title')];
  return bits.filter(Boolean).join(' ').toLowerCase();
}
function __cfxPath(el){
  var s='', cur=el, d=0;
  while(cur&&d<6){ s+=' '+__cfxBlob(cur); cur=cur.parentElement; d++; }
  return s.toLowerCase();
}
function __cfxOwnText(el){
  var t='';
  for(var i=0;i<el.childNodes.length;i++){
    var n=el.childNodes[i];
    if(n.nodeType===3) t+=n.nodeValue||'';
  }
  var own=__cfxNorm(t);
  if(own) return own;
  if(el.tagName&&el.tagName.toLowerCase()==='input') return __cfxNorm(el.value||el.getAttribute('value')||'');
  if(!el.children||el.children.length===0) return __cfxNorm(el.innerText||el.textContent||'');
  return '';
}
var __CFX_BET_HINTS=['bet','play','wager','order','touzhu','xz','chip','game-bet','betting','handicap','盘口','投注','下注','玩法','赔率','选号'];
var __CFX_NOISE=['history','record','trend','chart','help','rule','notice','news','draw','open','result','statistic','统计','历史','走势','说明','开奖','记录','规则','公告','新闻','教程','客服','关于'];
function __cfxInRegion(el){
  var R=window.__CFX_REGION;
  if(!R||!R.enabled) return true;
  var r=el.getBoundingClientRect();
  var cx=r.left+r.width/2, cy=r.top+r.height/2;
  var L=innerWidth*(R.left||0)/100, T=innerHeight*(R.top||0)/100;
  var Rt=innerWidth*(R.right||100)/100, B=innerHeight*(R.bottom||100)/100;
  return cx>=L&&cx<=Rt&&cy>=T&&cy<=B;
}
function __cfxScore(el, label){
  if(!__cfxVisible(el)) return -1e9;
  if(!__cfxInRegion(el)) return -1e9;
  var own=__cfxOwnText(el);
  var full=__cfxNorm(el.innerText||el.textContent||'');
  if(own!==label && full!==label){
    var ownHasLabel = own.indexOf(label)>=0 && own.length<=8;
    var labelHasOwn = own.length>0 && label.indexOf(own)>=0;
    if(!ownHasLabel && !labelHasOwn) return -1e9;
  }
  if(full.length>30 && full!==label) return -1e9;
  if(el.children && el.children.length>12) return -1e9;
  var rect=el.getBoundingClientRect();
  var blob=__cfxPath(el);
  var score=0;
  var tag=(el.tagName||'').toLowerCase();
  if(own===label || full===label) score+=50;
  if(tag==='button'||tag==='a') score+=40;
  if(el.getAttribute('role')==='button') score+=30;
  if(typeof el.onclick==='function'||el.hasAttribute('ng-click')||el.hasAttribute('@click')||el.hasAttribute('onclick')) score+=25;
  if(tag==='input'&&/button|submit/.test(el.type||'')) score+=35;
  if(tag==='div'||tag==='span'||tag==='li'||tag==='label'||tag==='p'||tag==='i'||tag==='em') score+=5;
  for(var i=0;i<__CFX_BET_HINTS.length;i++){ if(blob.indexOf(__CFX_BET_HINTS[i])>=0) score+=28; }
  for(var j=0;j<__CFX_NOISE.length;j++){ if(blob.indexOf(__CFX_NOISE[j])>=0) score-=80; }
  var area=rect.width*rect.height;
  if(rect.width>=24&&rect.width<=200&&rect.height>=22&&rect.height<=90) score+=30;
  if(area<180||area>60000) score-=30;
  var cy=rect.top+rect.height/2;
  if(cy>innerHeight*0.18&&cy<innerHeight*0.92) score+=15;
  if(cy<innerHeight*0.12) score-=40;
  if(cy>innerHeight*0.96) score-=20;
  var parent=el.parentElement;
  if(parent){
    var sib=__cfxNorm(parent.innerText||'');
    if(sib.length<=20){
      if((label==='大'||label==='小')&&sib.indexOf('大')>=0&&sib.indexOf('小')>=0) score+=35;
      if((label==='单'||label==='双')&&sib.indexOf('单')>=0&&sib.indexOf('双')>=0) score+=35;
    } else {
      score-=15;
    }
  }
  if(/active|selected|on|checked|current|choose/.test(blob)) score+=8;
  return score;
}
function __cfxFindBest(label){
  var want=__cfxNorm(label);
  var best=null, bestScore=20;
  // Round 1: high-priority elements only (button, a, role=button, input)
  var prioritySelector='button,a,[role=button],input[type=button],input[type=submit],label,li';
  var allNodes=[];
  try{
    allNodes=allNodes.concat(Array.prototype.slice.call(document.querySelectorAll(prioritySelector)));
  }catch(e){}
  // Round 2: if no hit, expand to all tags
  if(!best){
    var expandedSelector='button,a,[role=button],input[type=button],input[type=submit],label,li,span,div,p,i,em';
    try{
      allNodes=allNodes.concat(Array.prototype.slice.call(document.querySelectorAll(expandedSelector)));
    }catch(e){}
    try{
      var frames=document.querySelectorAll('iframe');
      for(var fi=0;fi<frames.length;fi++){
        try{
          var fd=frames[fi].contentDocument||frames[fi].contentWindow.document;
          if(fd){
            allNodes=allNodes.concat(Array.prototype.slice.call(fd.querySelectorAll(expandedSelector)));
          }
        }catch(e){ }
      }
    }catch(e){}
  }
  for(var i=0;i<allNodes.length;i++){
    var el=allNodes[i];
    if(el.closest && el.closest('header,nav,footer,aside')) continue;
    if(!__cfxInRegion(el)) continue;
    var own=__cfxOwnText(el);
    var full=__cfxNorm(el.innerText||el.textContent||'');
    if(want.length>=2){
      if(own!==want && full!==want && !(own.length>0 && want.indexOf(own)>=0) && !(full.length<=20 && full.indexOf(want)>=0)) continue;
      var sc=__cfxScore(el, want);
      if(own===want||full===want) sc+=40;
      if(sc>bestScore){ bestScore=sc; best=el; }
      continue;
    }
    var sc2=__cfxScore(el, want);
    if(sc2>bestScore){ bestScore=sc2; best=el; }
  }
  return best?{el:best,score:bestScore}:null;
}
function __cfxHighlight(el, ok){
  if(!el) return;
  var prev=el.style.outline;
  el.style.outline=ok?'3px solid #00c853':'3px solid #ff1744';
  setTimeout(function(){ el.style.outline=prev; }, 1200);
}
/* 跨 document 查询 selector（主文档 + 同源 iframe） */
function __cfxQuerySelector(sel){
  if(!sel) return null;
  try{
    var el=document.querySelector(sel);
    if(el) return el;
  }catch(e){}
  try{
    var frames=document.querySelectorAll('iframe');
    for(var i=0;i<frames.length;i++){
      try{
        var fd=frames[i].contentDocument||frames[i].contentWindow.document;
        if(fd){
          el=fd.querySelector(sel);
          if(el) return el;
        }
      }catch(e){}
    }
  }catch(e){}
  return null;
}
function __cfxClick(el){
  el.scrollIntoView({block:'center',inline:'center'});
  var o={bubbles:true,cancelable:true,view:window};
  el.dispatchEvent(new MouseEvent('mouseover',o));
  el.dispatchEvent(new MouseEvent('mousedown',o));
  el.dispatchEvent(new MouseEvent('mouseup',o));
  el.dispatchEvent(new MouseEvent('click',o));
  if(typeof el.click==='function') el.click();
}
function __cfxSleep(ms){
  var t0=Date.now();
  while(Date.now()-t0<ms){ }
}
function __cfxFindConfirm(){
  var texts=['确认投注','立即下注','马上投注','确认下注','提交订单','立即投注','确认','确定','提交','下注','是的','同意','继续','我知道了','知道了','OK','Ok','ok','YES','Yes','验证通过','二次确认'];
  var nodes=document.querySelectorAll('button,a,[role=button],input[type=button],input[type=submit],div,span');
  /* 也搜索同源 iframe 内的确认按钮 */
  try{
    var frames=document.querySelectorAll('iframe');
    for(var fi=0;fi<frames.length;fi++){
      try{
        var fd=frames[fi].contentDocument||frames[fi].contentWindow.document;
        if(fd) nodes=Array.prototype.concat.call(nodes, fd.querySelectorAll('button,a,[role=button],input[type=button],input[type=submit],div,span'));
      }catch(e){}
    }
  }catch(e){}
  var best=null, bestScore=25;
  for(var i=0;i<nodes.length;i++){
    var el=nodes[i];
    if(!__cfxVisible(el)) continue;
    var text=__cfxNorm(el.innerText||el.value||el.getAttribute('aria-label')||'');
    if(!text||text.length>16) continue;
    var hit=-1;
    for(var t=0;t<texts.length;t++){
      if(text===texts[t]||text.indexOf(texts[t])>=0){ hit=t; break; }
    }
    if(hit<0) continue;
    var sc=40-Math.min(hit,15);
    var blob=__cfxPath(el);
    for(var h=0;h<__CFX_BET_HINTS.length;h++) if(blob.indexOf(__CFX_BET_HINTS[h])>=0) sc+=15;
    for(var n=0;n<__CFX_NOISE.length;n++) if(blob.indexOf(__CFX_NOISE[n])>=0) sc-=50;
    if(el.closest && (el.closest('.modal')||el.closest('[class*=dialog]')||el.closest('[class*=popup]')||el.closest('[class*=mask]')||el.closest('[class*=confirm]'))) sc+=25;
    var r=el.getBoundingClientRect();
    if(r.width>=48&&r.height>=28) sc+=12;
    if(sc>bestScore){ bestScore=sc; best=el; }
  }
  return best;
}
function __cfxInputAmount(amount){
  if(!amount) return {ok:true,message:'无金额'};
  var inputs=document.querySelectorAll('input[type=text],input[type=number],input:not([type]),textarea');
  /* 也搜索同源 iframe 内的输入框 */
  try{
    var frames=document.querySelectorAll('iframe');
    for(var fi=0;fi<frames.length;fi++){
      try{
        var fd=frames[fi].contentDocument||frames[fi].contentWindow.document;
        if(fd) inputs=Array.prototype.concat.call(inputs, fd.querySelectorAll('input[type=text],input[type=number],input:not([type]),textarea'));
      }catch(e){}
    }
  }catch(e){}
  var target=null, bestSc=0;
  for(var i=0;i<inputs.length;i++){
    var el=inputs[i];
    if(!__cfxVisible(el)) continue;
    var blob=(__cfxPath(el)+' '+(el.placeholder||'')).toLowerCase();
    var sc=0;
    /* 强正选：语义明确指向“金额”的输入框 */
    if(/(金额|下注额|投注额|额度|金额框|amount|money)/.test(blob)) sc+=50;
    if(/金额|额度|amount|money|bet|投注|下注|元/.test(blob)) sc+=25;
    /* 强排除：数量/倍数/注数/搜索类输入框，避免误填 */
    if(/(倍数|倍率|注数|份数|数量|期数|份|count|times|multiple|quantity|share|search|user|pass|账号|密码|手机|验证码)/.test(blob)) sc-=80;
    /* 数字输入 & placeholder 清晰 → 加分 */
    if((el.type==='number'||el.inputMode==='decimal'||el.pattern==='[0-9.]*') && /(金额|元|额度|amount|money)/.test(blob)) sc+=20;
    if(__cfxInRegion(el)) sc+=10;
    if(sc>bestSc){ bestSc=sc; target=el; }
  }
  if(!target||bestSc<=0){
    var chip=__cfxFindBest(String(amount));
    if(chip){ __cfxHighlight(chip.el,true); __cfxClick(chip.el); return {ok:true,message:'点筹码'+amount}; }
    return {ok:false,message:'未找到金额框'};
  }
  /* 设置后回读校验：若站点把值改写为 100 等，如实上报实际值，便于用户调整 */
  var actual = __cfxSetInputValue(target, String(amount));
  var note = (actual===String(amount)) ? ('已填金额'+amount) : ('已填金额'+amount+'，页面显示为'+actual);
  return {ok:true,message:note,actual:actual};
}
function __cfxSetInputValue(el, value){
  if(!el) return '';
  el.focus();
  el.scrollIntoView({block:'center',inline:'center'});
  var proto = el.tagName && el.tagName.toLowerCase()==='textarea' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
  function put(val){
    el.value='';
    try{
      var setter = Object.getOwnPropertyDescriptor(proto, 'value');
      if(setter && setter.set) setter.set.call(el, val);
      else el.value = val;
    }catch(e){
      el.value = val;
    }
    try{ el.dispatchEvent(new InputEvent('input',{bubbles:true,data:val,inputType:'insertText'})); }catch(e){ el.dispatchEvent(new Event('input',{bubbles:true})); }
    el.dispatchEvent(new Event('change',{bubbles:true}));
  }
  put(value);
  /* 回读校验：部分 React/Vue 受控组件会覆盖值（如 10 被改写成 100），
     发现不一致时再整体重设一次并再次回读，返回最终实际值供日志展示 */
  var actual = el.value;
  if(String(actual)!==String(value)){
    put(value);
    actual = el.value;
  }
  el.dispatchEvent(new Event('blur',{bubbles:true}));
  return String(actual);
}
/* 按钮指纹：用于确认循环去重，防止同一按钮被重复点击 */
function __cfxConfirmFingerprint(el){
  if(!el) return '';
  try{
    var r=el.getBoundingClientRect();
    var cls=typeof el.className==='string'?el.className:'';
    return (el.tagName||'')+'|'+(el.id||'')+'|'+cls+'|'+(el.innerText||el.value||'').slice(0,12)+'|'+Math.round(r.left)+','+Math.round(r.top);
  }catch(e){ return ''; }
}
/* 成功文案检测：出现这些文案视为确认已完成，停止循环 */
function __cfxHasSuccessText(){
  var t=document.body?(document.body.innerText||document.body.textContent||''):'';
  try{
    var frames=document.querySelectorAll('iframe');
    for(var fi=0;fi<frames.length;fi++){
      try{
        var fd=frames[fi].contentDocument||frames[fi].contentWindow.document;
        if(fd&&fd.body) t+=' '+(fd.body.innerText||fd.body.textContent||'');
      }catch(e){}
    }
  }catch(e){}
  var marks=['投注成功','下单成功','提交成功','出票成功','已成功提交','下单已成功','投注已提交','订单已提交','已受理','成功投注','下注成功','恭喜投注','等待开奖','投注完成','已下注'];
  for(var i=0;i<marks.length;i++){ if(t.indexOf(marks[i])>=0) return marks[i]; }
  return '';
}
/* 失败/余额不足等终止文案 */
function __cfxHasBlockText(){
  var t=document.body?(document.body.innerText||document.body.textContent||''):'';
  try{
    var frames=document.querySelectorAll('iframe');
    for(var fi=0;fi<frames.length;fi++){
      try{
        var fd=frames[fi].contentDocument||frames[fi].contentWindow.document;
        if(fd&&fd.body) t+=' '+(fd.body.innerText||fd.body.textContent||'');
      }catch(e){}
    }
  }catch(e){}
  var marks=['余额不足','下单失败','投注失败','提交失败','超出限额','不能超过','已达上限','请先登录','登录已过期','账户被锁定'];
  for(var i=0;i<marks.length;i++){ if(t.indexOf(marks[i])>=0) return marks[i]; }
  return '';
}
function __cfxConfirmLoop(dryRun, maxRound, confirmSelector){
  var rounds=[];
  maxRound = maxRound||3;
  /* 已点击按钮指纹，防止重复触发同一「确定」动作 */
  var clicked={};
  var lastFp='';
  var doneText='';
  for(var r=0;r<maxRound;r++){
    var conf=null;
    /* ① selector 精确优先 */
    if(confirmSelector){
      try{ conf=__cfxQuerySelector(confirmSelector); }catch(e){}
      if(conf && !__cfxVisible(conf)) conf=null;
      /* selector 指定的按钮若已点过 → 视为完成，不再重复点 */
      if(conf){
        var fpSel=__cfxConfirmFingerprint(conf);
        if(clicked[fpSel]){
          rounds.push({round:r+1,ok:true,detail:'selector确认已完成',finished:true,text:__cfxNorm(conf.innerText||conf.value||'')});
          break;
        }
      }
    }
    /* ② 无 selector 或失配 → 评分兜底（跳过已点击过的按钮） */
    if(!conf){
      var cand=__cfxFindConfirm();
      if(cand){
        var fpC=__cfxConfirmFingerprint(cand);
        if(!clicked[fpC]) conf=cand;
      }
    }
    if(!conf){
      /* 没有新确认按钮：成功则结束，否则说明已是最终态 */
      doneText=__cfxHasSuccessText();
      var blockText=__cfxHasBlockText();
      if(doneText){
        rounds.push({round:r+1,ok:true,detail:'完成：'+doneText,finished:true});
      } else if(blockText){
        rounds.push({round:r+1,ok:false,detail:'阻止：'+blockText,finished:true});
      } else {
        rounds.push({round:r+1,ok:false,detail:'无确认钮'});
      }
      break;
    }
    var txt=__cfxNorm(conf.innerText||conf.value||'');
    var fp=__cfxConfirmFingerprint(conf);
    /* 与上一轮完全相同的按钮（未发生变化）→ 停止，避免重复确定弹窗动作 */
    if(fp===lastFp){
      rounds.push({round:r+1,ok:true,detail:'确认已完成(按钮未变)',finished:true,text:txt});
      break;
    }
    clicked[fp]=true;
    lastFp=fp;
    __cfxHighlight(conf,true);
    if(!dryRun) __cfxClick(conf);
    rounds.push({round:r+1,ok:true,text:txt});
    /* 点击后等待页面响应再判断是否还有新的确认弹窗 */
    if(r<maxRound-1){
      __cfxSleep(900);
      doneText=__cfxHasSuccessText();
      if(doneText){
        rounds.push({round:r+1,ok:true,detail:'确认完成：'+doneText,finished:true});
        break;
      }
      if(__cfxHasBlockText()){
        rounds.push({round:r+1,ok:false,detail:'阻止：'+__cfxHasBlockText(),finished:true});
        break;
      }
    }
  }
  return rounds;
}
window.__caiFenXiRunCommand=function(CMD){
  var steps=[];
  try{
    window.__CFX_REGION = CMD.region || {enabled:false};
    if(!CMD||!CMD.bets||!CMD.bets.length){
      return {ok:false,message:'指令无注项',steps:steps};
    }
    for(var i=0;i<CMD.bets.length;i++){
      var bet=CMD.bets[i];
      var logical=bet.value||'';
      var label=bet.pageText|| (CMD.labelMap&&CMD.labelMap[logical]) || logical;
      if(!label) continue;
      /* ① selector 精确优先（用户标注过） */
      var selStr=CMD.selectors && CMD.selectors[logical];
      if(selStr){
        try{
          var selEl=__cfxQuerySelector(selStr);
          if(selEl && __cfxVisible(selEl)){
            __cfxHighlight(selEl,true);
            if(!CMD.dryRun) __cfxClick(selEl);
            steps.push({step:'play:'+logical+'→selector',ok:true,method:'selector'});
            continue;
          }
        }catch(e){}
      }
      /* ② 无 selector 或失配 → DOM 评分兜底 */
      var hit=__cfxFindBest(label);
      if(!hit){
        hit=__cfxFindBest(label.replace(/\s+/g,''));
      }
      if(!hit){
        var core=label.replace(/[^大小单双龙虎]/g,'');
        if(core && core!==label) hit=__cfxFindBest(core);
      }
      if(!hit){
        steps.push({step:'play:'+logical+'→'+label,ok:false});
        return {ok:false,message:'未找到玩法【'+label+'】',steps:steps};
      }
      __cfxHighlight(hit.el,true);
      if(!CMD.dryRun) __cfxClick(hit.el);
      steps.push({step:'play:'+logical+'→'+label,ok:true,score:hit.score});
    }
    return {ok:true,message:'bets_done',steps:steps};
  }catch(err){
    return {ok:false,message:String(err&&err.message||err),steps:steps};
  }
};
/* ===== 分阶段执行（供 Kotlin 侧 postDelayed 调用）===== */
window.__cfxPhase2Amount=function(CMD){
  var amtOk=false, amtMsg='';
  if(CMD.selectors && CMD.selectors.selector_amount && CMD.amount){
    try{
      var amtEl=__cfxQuerySelector(CMD.selectors.selector_amount);
      if(amtEl && __cfxVisible(amtEl)){
        var actual=__cfxSetInputValue(amtEl, String(CMD.amount));
        amtOk=true;
        amtMsg=(actual===String(CMD.amount)) ? ('selector已填金额'+CMD.amount) : ('selector已填金额'+CMD.amount+'，页面显示为'+actual);
      }
    }catch(e){}
  }
  if(!amtOk){
    var amt=__cfxInputAmount(CMD.amount);
    amtOk=!!amt.ok; amtMsg=amt.message;
  }
  return {ok:amtOk,message:amtMsg};
};
window.__cfxPhase3Confirm=function(CMD){
  var confirms=__cfxConfirmLoop(!!CMD.dryRun, CMD.maxConfirmRounds||3, CMD.selectors&&CMD.selectors.selector_confirm);
  var anyOk=confirms.some(function(x){return x.ok;});
  var finished=confirms.some(function(x){return x.finished;});
  /* 实际点击次数 = 首次出现点击文本的口径：只有 ok 且无 detail 的轮次算作真实点击 */
  var realClicks=confirms.filter(function(x){return x.ok && !x.detail;}).length;
  var message=anyOk
    ? ((finished||realClicks>0) ? ('确认完成×'+realClicks) : '确认完成×'+realClicks)
    : '未找到确认按钮';
  return {ok:anyOk,finished:finished,message:message,rounds:confirms};
};
