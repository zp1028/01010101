package com.caifenxi.app.service

import android.webkit.WebView
import com.caifenxi.app.domain.execution.BetCommand
import com.caifenxi.app.domain.execution.ExecutionResult
import com.caifenxi.app.domain.execution.Executor
import com.caifenxi.app.util.RuntimeLog

/**
 * WebView 统一执行器（接入 ExecutorManager）。
 * UI 在 WebBetScreen 挂载 WebView 后调用 [attach]；detach 后回落到无障碍。
 */
object WebViewExecutor : Executor {

    override val id: String = "webview"

    @Volatile
    private var executor: WebViewBetExecutor? = null

    @Volatile
    override var isAvailable: Boolean = false
        private set

    @Volatile
    private var lastHeartbeatMs: Long = 0L

    /** 心跳窗口：配合周期 keep-alive（15~30s 探活一次），此处给足 5 分钟兜底 */
    private const val HEARTBEAT_TIMEOUT_MS = 300_000L

    /** 页面加载完成时调用，更新心跳；WebView 崩溃/导航走 about:blank 后心跳超时自动标记不可用 */
    fun heartbeat() {
        lastHeartbeatMs = System.currentTimeMillis()
        if (!isAvailable && executor?.isAvailable == true) {
            isAvailable = true
            RuntimeLog.info("Execution", "WebView 心跳恢复，标记为可用")
        }
    }

    /** 周期探活：向页面注入探针 JS，能收到真实回包才视为连接存活（保持持久连接） */
    fun keepAlive(webView: WebView?) {
        if (webView == null) return
        try {
            webView.evaluateJavascript(
                "(function(){ try { return document.readyState; } catch(e) { return 'dead'; } })()"
            ) { result ->
                if (result != null && result != "null" && !result.contains("dead")) {
                    heartbeat()
                    if (!isAvailable && executor?.isAvailable == true) {
                        isAvailable = true
                        RuntimeLog.info("Execution", "WebView keep-alive 恢复连接")
                    }
                }
            }
        } catch (_: Exception) {
            // 注入异常不立刻判死，交给 checkHeartbeat 超时兜底
        }
    }

    /** 检查心跳是否超时（5 分钟无更新才标记不可用）；超时后尝试恢复而不是直接失联 */
    fun checkHeartbeat(): Boolean {
        if (lastHeartbeatMs == 0L) return isAvailable
        val elapsed = System.currentTimeMillis() - lastHeartbeatMs
        if (elapsed > HEARTBEAT_TIMEOUT_MS && isAvailable) {
            isAvailable = false
            RuntimeLog.warn("Execution", "WebView 心跳超时(${elapsed}ms)，标记为不可用")
        }
        return isAvailable
    }

    /** App 启动时绑定与调度器同一实例，避免 UI attach 与调度器各用各的 WebView */
    fun bindShared(ex: WebViewBetExecutor) {
        executor = ex
        isAvailable = ex.isAvailable
    }

    /** 重新绑定 WebView（页面导航/重组时调用，确保 executor 引用最新） */
    fun reattach(webView: WebView) {
        val ex = executor ?: WebViewBetExecutor().also { executor = it }
        ex.initWebView(webView)
        isAvailable = true
        lastHeartbeatMs = System.currentTimeMillis()
        RuntimeLog.info("Execution", "WebView 重新绑定执行器")
    }

    fun attach(webView: WebView) {
        val ex = executor ?: WebViewBetExecutor().also { executor = it }
        ex.initWebView(webView)
        isAvailable = true
        lastHeartbeatMs = System.currentTimeMillis()
        RuntimeLog.info("Execution", "WebView 执行器已就绪")
    }

    fun detach() {
        try {
            executor?.clearWebView()
        } catch (_: Exception) {
        }
        executor = null
        isAvailable = false
        RuntimeLog.info("Execution", "WebView 执行器已断开")
    }

    /** 供调度器复用同一实例时挂载 */
    fun bindExecutor(ex: WebViewBetExecutor) {
        executor = ex
        isAvailable = ex.isAvailable
    }

    override fun execute(command: BetCommand, onResult: (ExecutionResult) -> Unit): Boolean {
        checkHeartbeat()
        val ex = executor
        if (ex == null || !ex.isAvailable) {
            RuntimeLog.warn("Execution", "WebView 未注入，cmdId=${command.cmdId}")
            onResult(
                ExecutionResult.fail(
                    command.cmdId,
                    ExecutionResult.WEBVIEW_DISCONNECTED,
                    "WebView 未连接，请打开「更多 → 内置网页执行」并登录投注站"
                )
            )
            return false
        }
        RuntimeLog.info(
            "Execution",
            "WebView 受理 cmdId=${command.cmdId} 彩种=${command.lotteryKey} 期号=${command.issue} stage=${command.stage} leg=${command.leg}"
        )
        return ex.execute(command, onResult)
    }

    override fun cancel(cmdId: String) {
        RuntimeLog.info("Execution", "WebView 取消 cmdId=$cmdId")
    }

    override fun queryState(cmdId: String): ExecutionResult? = null
}
