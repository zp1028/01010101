package com.caifenxi.app.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.caifenxi.app.domain.execution.BetAction
import com.caifenxi.app.domain.execution.BetCommand
import com.caifenxi.app.domain.execution.ExecutionResult
import com.caifenxi.app.domain.execution.ExecutionTask
import com.caifenxi.app.domain.execution.ExecutorManager
import com.caifenxi.app.service.AutoBetController
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * 网页执行台 ViewModel：真实派发 ExecutorManager，日志供 UI 展示。
 */
class ExecutorViewModel : ViewModel() {

    private val _executorStatus = MutableStateFlow(ExecutorStatus.IDLE)
    val executorStatus: StateFlow<ExecutorStatus> = _executorStatus.asStateFlow()

    private val _currentTask = MutableStateFlow<ExecutionTask?>(null)
    val currentTask: StateFlow<ExecutionTask?> = _currentTask.asStateFlow()

    private val _executorLogs = MutableStateFlow<List<String>>(emptyList())
    val executorLogs: StateFlow<List<String>> = _executorLogs.asStateFlow()

    private val _lastFailedTask = MutableStateFlow<ExecutionTask?>(null)
    val lastFailedTask: StateFlow<ExecutionTask?> = _lastFailedTask.asStateFlow()

    private val _executorStats = MutableStateFlow(ExecutorStats())
    val executorStats: StateFlow<ExecutorStats> = _executorStats.asStateFlow()

    private val _autoRunning = MutableStateFlow(false)
    val autoRunning: StateFlow<Boolean> = _autoRunning.asStateFlow()

    private val _executionMode = MutableStateFlow(ExecutorManager.getMode())
    val executionMode: StateFlow<String> = _executionMode.asStateFlow()

    init {
        addLog("执行器就绪 · 等待挂机指令或测试执行")
        addLog("WebView=${if (ExecutorManager.isAvailable("webview")) "可用" else "未连接"} 无障碍=${if (ExecutorManager.isAvailable("accessibility")) "可用" else "未开启"} 模式=${ExecutorManager.getMode()}")
    }

    /** 切换执行模式：webview（DOM注入）或 accessibility（无障碍手势） */
    fun setExecutionMode(mode: String) {
        ExecutorManager.setMode(mode)
        _executionMode.value = mode
        addLog("执行模式切换为: ${if (mode == "accessibility") "无障碍" else "WebView DOM"}")
    }

    /** 开始自动挂机：标记运行状态，后续 BetScheduler 下单会自动派发 */
    fun startAuto() {
        _autoRunning.value = true
        addLog("▶ 自动挂机已开启 · 模式=${if (_executionMode.value == "accessibility") "无障碍" else "WebView DOM"}")
    }

    /** 停止自动挂机 */
    fun stopAuto() {
        _autoRunning.value = false
        stopAllTasks()
        addLog("■ 自动挂机已停止")
    }

    /** 测试点击：用当前执行模式执行一次简单点击测试 */
    fun testClick(context: android.content.Context) {
        val mode = _executionMode.value
        if (mode == "accessibility") {
            // 无障碍模式：调用 AutoBetController 试跑
            addLog("测试点击(无障碍) → 触发流水线试跑")
            try {
                AutoBetController.tryNow(context)
                addLog("无障碍试跑已触发，请观察屏幕红点")
            } catch (e: Exception) {
                addLog("无障碍试跑失败: ${e.message}")
            }
        } else {
            // WebView 模式：生成测试任务并执行
            addLog("测试点击(WebView DOM) → 注入JS点击大小单双")
            val task = generateTestTask(dryRun = false)
            startTask(task)
        }
    }

    fun startTask(task: ExecutionTask) {
        viewModelScope.launch {
            _executorStatus.value = ExecutorStatus.RUNNING
            _currentTask.value = task
            addLog("开始 ${task.cmdId} ${task.lotteryKey}/${task.issue} ${task.dx ?: "-"}/${task.ds ?: "-"} 金额=${task.amountText}")

            val cmd = task.command ?: BetCommand(
                cmdId = task.cmdId,
                lotteryKey = task.lotteryKey,
                issue = task.issue,
                stage = task.stage,
                leg = task.leg,
                bets = buildList {
                    task.dx?.let { add(BetAction(BetAction.CAT_DX, it)) }
                    task.ds?.let { add(BetAction(BetAction.CAT_DS, it)) }
                    task.combo?.let { add(BetAction(BetAction.CAT_COMBO, it)) }
                    task.predNumbers.forEach { add(BetAction(BetAction.CAT_NUMBER, it)) }
                },
                amountText = task.amountText,
                source = task.source,
                expireAt = task.expireAt
            )

            if (cmd.bets.isEmpty()) {
                addLog("失败: 无注项")
                _executorStatus.value = ExecutorStatus.FAILED
                _currentTask.value = null
                return@launch
            }

            val result = suspendCancellableCoroutine { cont ->
                val accepted = ExecutorManager.execute(cmd) { r ->
                    if (cont.isActive) cont.resume(r)
                }
                if (!accepted) {
                    if (cont.isActive) {
                        cont.resume(
                            com.caifenxi.app.domain.execution.ExecutionResult.fail(
                                cmd.cmdId,
                                com.caifenxi.app.domain.execution.ExecutionResult.WEBVIEW_DISCONNECTED,
                                "无可用执行器（需开启无障碍服务+配置LLM以启用AI视觉，或打开网页加载投注站）"
                            )
                        )
                    }
                }
            }

            val stats = _executorStats.value
            if (result.success) {
                _executorStatus.value = ExecutorStatus.COMPLETED
                addLog("成功: ${result.message}")
                _lastFailedTask.value = null
                _executorStats.value = stats.copy(
                    totalTasks = stats.totalTasks + 1,
                    successfulTasks = stats.successfulTasks + 1
                )
            } else {
                _executorStatus.value = ExecutorStatus.FAILED
                addLog("失败: ${result.message}")
                _lastFailedTask.value = task
                _executorStats.value = stats.copy(
                    totalTasks = stats.totalTasks + 1,
                    failedTasks = stats.failedTasks + 1
                )
            }
            _currentTask.value = null
            _executorStatus.value = ExecutorStatus.IDLE
        }
    }

    fun stopAllTasks() {
        _executorStatus.value = ExecutorStatus.IDLE
        _currentTask.value = null
        addLog("已停止")
    }

    /** 重试上一次失败的任务：生成新 cmdId 避免去重拦截 */
    fun retryLastTask() {
        val failed = _lastFailedTask.value ?: run {
            addLog("无可重试的失败任务")
            return
        }
        val newCmdId = "retry_${System.currentTimeMillis()}"
        val retried = failed.copy(cmdId = newCmdId, command = null)
        addLog("重试任务 $newCmdId（原 ${failed.cmdId}）")
        startTask(retried)
    }

    fun clearLogs() {
        _executorLogs.value = emptyList()
        addLog("日志已清空")
    }

    fun generateTestTask(dryRun: Boolean = true): ExecutionTask {
        val cmd = BetCommand(
            cmdId = "test_${System.currentTimeMillis()}",
            lotteryKey = "pk10",
            issue = "test-issue",
            bets = listOf(
                BetAction(BetAction.CAT_DX, "大"),
                BetAction(BetAction.CAT_DS, "单")
            ),
            amountText = "10",
            source = "test",
            expireAt = System.currentTimeMillis() + 300_000,
            options = mapOf("dryRun" to if (dryRun) "true" else "false")
        )
        return ExecutionTask.fromCommand(cmd, source = "test").copy(executor = _executionMode.value)
    }

    private fun addLog(message: String) {
        val line = "${java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())} $message"
        _executorLogs.value = (_executorLogs.value + line).takeLast(50)
    }

    enum class ExecutorStatus { IDLE, RUNNING, COMPLETED, FAILED, CANCELLED }

    data class ExecutorStats(
        val totalTasks: Int = 0,
        val successfulTasks: Int = 0,
        val failedTasks: Int = 0
    )
}
