# 彩析 v2.4.2 WebView 交互修复（网页四修）

## 🛠 修复内容

### 1. 点击"确定下注"弹窗卡黑屏
- **根因**：WebView 未实现 `onJsAlert`/`onJsConfirm`/`onJsPrompt`，站点 JS 弹窗阻塞渲染线程导致黑屏；WebView 设置不完整导致页面显示残缺。
- **修复**：
  - `WebChromeClient` 接管 JS 弹窗：alert/confirm 自动确认并在界面上以 Toast 展示弹窗内容，prompt 直接取消返回空串，弹窗不再卡黑屏。
  - 补齐 WebView 设置：mixedContent ALWAYS_ALLOW、新窗口（`javaScriptCanOpenWindowsAutomatically`）、缩放（setSupportZoom + builtInZoomControls + textZoom）、图片加载、`onCreateWindow` 将 target=_blank 转回主 WebView 页内打开。
  - WebViewClient 补 `shouldOverrideUrlLoading`（留页内）、`onRenderProcessGone`（渲染进程崩溃自动重建恢复）。

### 2. 金额输入错误（10 会输入成 100）
- **根因**：金额框定位弱匹配命中倍数/注数框，且注入后无回读校验，站点联动逻辑改写了输入值。
- **修复**（`cfx_inject.js`）：
  - `__cfxInputAmount` 强权重定位：金额词 +50/+25、倍数/注数/搜索类强排除 -80、type=number 加分，bestSc=0 阈值兜底。
  - `__cfxSetInputValue` 改为 focus + scrollIntoView + 原生 setter 写入，写入后**回读校验**，不一致则重写一次，最终返回页面真实值。
  - 结果 message 形如"已填金额10（页面显示为10）"，便于确认无 ×10 偏差。

### 3. 确定下注后重复弹出"确定"弹窗
- **根因**：`__cfxConfirmLoop` 无条件循环 4 轮点击"确认"，无完成判定、无去重。
- **修复**：重构 `__cfxConfirmLoop`——指纹去重（同一确认框不重复点）、点击后等待 900ms 检测"投注成功/下单成功/余额不足/下单失败"等 14+10 个完成/阻断文案即提前结束、按钮未变化即结束、已点过的 selector 不再点；返回真实点击次数。

### 4. WebView 容易断开连接，改为长驻
- **根因**：`checkHeartbeat` 120s 无回调即判死，`heartbeat()` 仅在 `onPageFinished` 触发一次，长驻页面 120s 后必断连。
- **修复**：
  - `HEARTBEAT_TIMEOUT_MS` 提升到 300s（5 分钟兜底）。
  - 新增 `WebViewExecutor.keepAlive(webView)`：周期性 `evaluateJavascript(document.readyState)` 真实探测，确认存活才刷新心跳。
  - `WebBetScreen` 新增 `LaunchedEffect` 每 15s 调用 keepAlive，WebView 不可用时自动 reattach 重建。
  - `WebViewBetExecutor.execute` 入口 synchronized 防重入（同命令并发时返回 DUPLICATE_COMMAND），避免重复提交命令。

## 📦 技术说明
- 编译验证：`./gradlew :app:compileDebugKotlin` 通过（Gradle 8.9 / AGP 8.5.2 / JDK 21）。
- 版本号升级：VERSION_CODE 36 → 37，VERSION_NAME 2.4.1 → 2.4.2。

---

# 彩析 v2.4.0-AI 更新日志

## 🧠 AI 大模型视觉执行（核心功能）

### 新增功能
- **AI 视觉执行器**：基于多模态 LLM 的页面理解与自动化执行
- **三种 LLM 提供商支持**：
  - OpenAI (GPT-4o / GPT-4o-mini)
  - Anthropic (Claude 3.5 Sonnet)
  - Google (Gemini 1.5 Pro / Flash)
- **智能执行模式**：AI 视觉 → WebView → 无障碍，自动降级
- **执行后校验**：截图二次确认，失败自动重试
- **AI 设置页面**：完整的 LLM 配置、测试、保存界面

### 技术架构
```
BetCommand → ExecutorManager → [AI Vision] → [WebView] → [Accessibility]
                ↓
         PerceptionEngine (截图 + Accessibility节点树)
                ↓
         LlmClient (多模态API调用)
                ↓
         AiVisionExecutor (手势执行 + 结果校验)
```

### 新增文件
| 文件 | 路径 | 说明 |
|------|------|------|
| AiVisionExecutor.kt | domain/execution/ | AI视觉执行器核心 |
| LlmClient.kt | domain/execution/ | LLM API客户端 |
| PerceptionEngine.kt | domain/execution/ | 截图+节点树提取 |
| AiPromptBuilder.kt | domain/execution/ | 多模态Prompt构建 |
| ActionParser.kt | domain/execution/ | LLM响应解析 |
| LlmConfigStore.kt | data/config/ | LLM配置本地存储 |
| AiSettingsScreen.kt | ui/screens/ | AI设置UI界面 |
| AiSettingsActivity.kt | ui/screens/ | AI设置Activity |

### 修改文件
| 文件 | 修改内容 |
|------|---------|
| accessibility_service_config.xml | 添加 canTakeScreenshot="true" |
| ExecutorManager.kt | 添加 ai_vision 优先级 |
| CaiFenXiApplication.kt | 注册AI执行器 |
| build.gradle.kts | 添加 kotlinx-datetime依赖，版本号2.4.0-AI |
| AndroidManifest.xml | 添加 AiSettingsActivity |
| MoreScreen.kt | 添加AI设置入口 |
| CaiFenXiApp.kt | 添加 ai_settings 路由 |
| SettingsScreen.kt | 添加AI设置导航 |
| README.md | 更新AI功能说明 |

### 使用说明
1. 打开「更多 → 🧠 AI 大模型设置」
2. 选择提供商并输入API Key
3. 选择模型（推荐GPT-4o-mini降低成本）
4. 选择执行模式（自动/仅AI/仅网页/仅无障碍）
5. 点击「测试连接」验证
6. 保存配置即可使用

### 成本参考
| 模型 | 单次投注 | 月费用(1000次) |
|------|---------|---------------|
| GPT-4o-mini | ~¥0.03 | ~¥30 |
| GPT-4o | ~¥0.15 | ~¥150 |
| Claude 3.5 | ~¥0.50 | ~¥500 |

### 注意事项
- AI模式需要设备联网
- 需要开启无障碍服务（用于截图和手势执行）
- Android 11+ 支持原生截图，低版本需MediaProjection授权
- API Key 请妥善保管，建议使用环境变量或加密存储

---

## 兼容性
- 最低 Android 7.0 (API 24)
- 编译 SDK 35
- Kotlin 2.0.20
- Jetpack Compose 2024.09

AI Agent V2 completed: 2026-09-05
