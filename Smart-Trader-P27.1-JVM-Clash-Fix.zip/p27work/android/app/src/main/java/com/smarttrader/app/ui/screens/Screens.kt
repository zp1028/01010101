package com.smarttrader.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlin.math.max
import kotlin.math.min
import com.smarttrader.app.ui.components.*
import com.smarttrader.app.ui.theme.*
import com.smarttrader.app.viewmodel.AppState

@Composable
fun DiscoverScreen(state: AppState) {
    var query by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("") }
    val tabs = listOf("crypto" to "加密", "us" to "美股", "hk" to "港股", "commodities" to "大宗")
    val filtered = state.markets
        .filter { query.isBlank() || it.symbol.contains(query, true) || it.name.contains(query, true) }
        .filter { when (state.marketFilter) { "gainers" -> it.changePct > 0.0; "losers" -> it.changePct < 0.0; "active" -> it.attention >= 0.35; "favorites" -> it.symbol in state.favorites; else -> true } }
        .sortedWith(compareByDescending<com.smarttrader.app.data.MarketItem> {
            when (state.marketSort) { "attention" -> it.attention; "price" -> it.price.replace(",", "").toDoubleOrNull() ?: 0.0; else -> it.changePct }
        })
    Column(Modifier.fillMaxSize().background(Bg)) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("市场", style = MaterialTheme.typography.headlineLarge, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                    Text("全市场扫描 · 只读分析", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                }
                TagChip(if (state.live) "LIVE" else if (state.backendOnline) "ONLINE" else "OFFLINE", if (state.live) Bull else if (state.backendOnline) Accent else Warn)
            }
            state.analysisFeed?.let { feed ->
                Spacer(Modifier.height(4.dp))
                AppCard {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("当前高置信度分析", style = MaterialTheme.typography.titleMedium, color = Accent)
                            Text("基于当前行情 + 多指标结构 + 历史报告反馈持续跟踪", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        }
                        TagChip("${feed.items.size} 个", Accent)
                    }
                    Spacer(Modifier.height(8.dp))
                    feed.items.take(4).forEach { item ->
                        Row(Modifier.fillMaxWidth().clickable { state.openDetail(item.symbol, item.market) }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(item.symbol, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                                Text(item.summary, color = TextSecondary, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                                if (item.feedbackSummary.isNotBlank()) Text("反馈：${item.feedbackSummary}", color = TextMuted, style = MaterialTheme.typography.labelSmall, maxLines = 2)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                TagChip("${(item.confidence * 100).toInt()}%", if (item.confidence >= .75) Bull else Accent)
                                Spacer(Modifier.height(3.dp))
                                TagChip(if (item.direction == "long") "多头情景" else if (item.direction == "short") "空头情景" else "观察", if (item.direction == "long") Bull else if (item.direction == "short") Bear else Neutral)
                            }
                        }
                    }
                    Text("报告不会被后续行情改写；新行情只会形成新的反馈记录。", color = TextMuted, style = MaterialTheme.typography.labelSmall)
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                tabs.forEach { (key,label) -> FilterChip(selected = state.marketCategory == key, onClick = { state.loadUniverse(key, query.ifBlank { null }) }, label = { Text(label) }) }
            }
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = query, onValueChange = { query = it; state.loadUniverse(state.marketCategory, it.ifBlank { null }) },
                modifier = Modifier.fillMaxWidth(), singleLine = true,
                placeholder = { Text("搜索品种 / 公司名称") },
                label = { Text("市场搜索") },
            )
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("change" to "涨跌幅", "attention" to "关注度", "price" to "价格").forEach { (k,l) -> FilterChip(selected = state.marketSort == k, onClick = { state.marketSort = k }, label = { Text(l) }) }
                listOf("all" to "全部", "gainers" to "上涨", "losers" to "下跌", "active" to "活跃", "favorites" to "自选").forEach { (k,l) -> FilterChip(selected = state.marketFilter == k, onClick = { state.marketFilter = k }, label = { Text(l) }) }
                listOf("table" to "排行", "cards" to "卡片").forEach { (k,l) -> FilterChip(selected = state.marketView == k, onClick = { state.marketView = k }, label = { Text(l) }) }
            }
        }
        if (state.marketView == "table") {
            Row(Modifier.fillMaxWidth().background(SurfaceAlt).padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("品种 / 市场", color = TextMuted, style = MaterialTheme.typography.labelSmall)
                Text("最新 / 24H", color = TextMuted, style = MaterialTheme.typography.labelSmall)
            }
            LazyColumn(contentPadding = PaddingValues(bottom = 92.dp)) {
                items(filtered) { m ->
                    Row(Modifier.fillMaxWidth().clickable { state.openDetail(m.symbol, m.assetClass) }.padding(horizontal = 12.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { state.toggleFavorite(m.symbol) }) {
                            Icon(if (m.symbol in state.favorites) Icons.Outlined.Star else Icons.Outlined.StarBorder, contentDescription = "自选", tint = if (m.symbol in state.favorites) Accent else TextMuted)
                        }
                        Column(Modifier.weight(1f)) {
                            Text(m.symbol, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                            Text("${m.name} · ${m.venue.ifBlank { m.assetClass.uppercase() }}", color = TextMuted, style = MaterialTheme.typography.labelSmall)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(m.price, color = TextPrimary, fontWeight = FontWeight.Medium)
                            Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                                PctBadge(m.changePct)
                                if (m.currency.isNotBlank()) Text(m.currency, color = TextMuted, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                    HorizontalDivider(color = Border.copy(alpha = .55f))
                }
            }
        } else {
            LazyColumn(Modifier.padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 92.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filtered) { m ->
                    AppCard(Modifier.clickable { state.openDetail(m.symbol, m.assetClass) }) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                IconButton(onClick = { state.toggleFavorite(m.symbol) }) {
                                    Icon(if (m.symbol in state.favorites) Icons.Outlined.Star else Icons.Outlined.StarBorder, contentDescription = "自选", tint = if (m.symbol in state.favorites) Accent else TextMuted)
                                }
                                Column { Text(m.symbol, color = TextPrimary, fontWeight = FontWeight.SemiBold); Text(m.name, color = TextMuted, style = MaterialTheme.typography.bodySmall) }
                            }
                            Column(horizontalAlignment = Alignment.End) { Text(m.price, color = TextPrimary); PctBadge(m.changePct) }
                        }
                        Spacer(Modifier.height(8.dp)); MetricBar("关注度", m.attention.coerceIn(0.0,1.0), Accent)
                    }
                }
                if (state.hasMoreMarkets) {
                    item {
                        AppCard(Modifier.fillMaxWidth().clickable { state.loadMoreMarkets() }) {
                            Text(if (state.loadingMoreMarkets) "正在加载更多品种…" else "加载更多 · 当前 ${state.markets.size} 个", modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center, color = Accent)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MarketScreen(state: AppState) = DiscoverScreen(state)

private fun sma(values: List<Double>, period: Int): List<Double?> = values.indices.map { i ->
    if (i + 1 < period) null else values.subList(i + 1 - period, i + 1).average()
}

@Composable
private fun CandleChart(candles: List<com.smarttrader.app.network.CandleDto>) {
    if (candles.isEmpty()) { AppCard { EmptyHint("暂无K线数据；当前数据源未提供历史K线") }; return }
    val visible = candles.takeLast(160)
    val closes = visible.map { it.close }
    val ma20 = sma(closes, 20)
    val ma50 = sma(closes, 50)
    val minP = visible.minOf { it.low }; val maxP = visible.maxOf { it.high }
    val span = max(maxP - minP, maxP * 0.0001)
    val maxVol = visible.maxOf { it.volume }.coerceAtLeast(1.0)
    AppCard {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("K线 / Volume", color = TextPrimary, fontWeight = FontWeight.SemiBold)
                Text("实时K线视图 · 当前周期独立计算", color = TextMuted, style = MaterialTheme.typography.labelSmall)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                TagChip("MA20", Accent); TagChip("MA50", Neutral)
            }
        }
        Spacer(Modifier.height(8.dp))
        Canvas(Modifier.fillMaxWidth().height(310.dp)) {
            val dx = size.width / visible.size
            val priceHeight = size.height * 0.76f
            val volTop = size.height * 0.80f
            fun y(v: Double) = priceHeight - ((v-minP)/span * priceHeight).toFloat()
            visible.forEachIndexed { i, c ->
                val x = i * dx + dx/2f
                val up = c.close >= c.open
                drawLine(if (up) Bull else Bear, Offset(x,y(c.high)), Offset(x,y(c.low)), strokeWidth=1.5f)
                val top=y(max(c.open,c.close)); val bottom=y(min(c.open,c.close)); val w=max(2f, dx*0.58f)
                drawRect(if (up) Bull else Bear, Offset(x-w/2,top), androidx.compose.ui.geometry.Size(w,max(2f,bottom-top)))
                val vh = ((c.volume / maxVol) * (size.height - volTop)).toFloat()
                drawRect(if (up) Bull else Bear, Offset(x-w/2, size.height-vh), androidx.compose.ui.geometry.Size(w, vh))
            }
            fun drawMa(values: List<Double?>, tone: androidx.compose.ui.graphics.Color) {
                val path = Path(); var started = false
                values.forEachIndexed { i, v ->
                    if (v == null) return@forEachIndexed
                    val x = i * dx + dx/2f; val py = y(v)
                    if (!started) { path.moveTo(x, py); started = true } else path.lineTo(x, py)
                }
                drawPath(path, tone, style = Stroke(width = 2f))
            }
            drawMa(ma20, Accent); drawMa(ma50, TextMuted)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("低 ${"%.4f".format(minP)}", color = TextMuted, style = MaterialTheme.typography.labelSmall)
            Text("最新 ${"%.4f".format(closes.last())}", color = TextPrimary, style = MaterialTheme.typography.labelSmall)
            Text("高 ${"%.4f".format(maxP)}", color = TextMuted, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
fun DetailScreen(state: AppState) {
    val sym = state.selectedSymbol ?: return
    LazyColumn(
        Modifier.fillMaxSize().background(Bg).padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 88.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { state.closeDetail() }) {
                    Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "返回", tint = TextPrimary)
                }
                Column(Modifier.weight(1f)) {
                    Text(sym, style = MaterialTheme.typography.headlineMedium, color = TextPrimary)
                    Text(state.connectionStatus, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                }
                IconButton(onClick = { state.toggleFavorite(sym) }) {
                    Icon(if (sym in state.favorites) Icons.Outlined.Star else Icons.Outlined.StarBorder, contentDescription = "自选", tint = if (sym in state.favorites) Accent else TextMuted)
                }
            }
            Spacer(Modifier.height(8.dp))
            state.markets.firstOrNull { it.symbol == sym }?.let { m ->
                AppCard {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column { Text(m.price, color = TextPrimary, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold); Text("${m.name} · ${m.venue.ifBlank { m.assetClass }}", color = TextMuted, style = MaterialTheme.typography.labelSmall) }
                        Column(horizontalAlignment = Alignment.End) { PctBadge(m.changePct); Text("${m.currency.ifBlank { "市场价" }} · 只读", color = TextMuted, style = MaterialTheme.typography.labelSmall) }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("周期", style = MaterialTheme.typography.labelLarge, color = TextMuted)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AppState.timeframes.forEach { tf ->
                    val selected = state.timeframe == tf
                    FilterChip(
                        selected = selected,
                        onClick = { state.changeTimeframe(tf) },
                        label = { Text(tf) },
                    )
                }
            }
            if (state.detailLoading) {
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(Modifier.fillMaxWidth(), color = Accent)
            }
            state.errorMessage?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, color = Bear, style = MaterialTheme.typography.bodyMedium)
            }
        }

        item { CandleChart(state.candles) }

        state.instrumentAnalysisSnapshot?.let { data ->
            item {
                AppCard {
                    Text("数据能力 · ${data.market.uppercase()}", style = MaterialTheme.typography.titleSmall, color = Accent)
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TagChip(if (data.snapshotAvailable) "行情可用" else "行情不可用", if (data.snapshotAvailable) Bull else Bear)
                        TagChip(data.capabilityStatus, if (data.capabilityStatus == "available") Bull else Warn)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("Provider ${data.provider} · ${data.timeframe} · 只读分析", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Spacer(Modifier.height(4.dp))
                    Text("数据质量 ${data.quality} · ${if (data.realtime) "实时" else "非实时"}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    if (data.missing.isNotEmpty()) {
                        Text("缺失能力：${data.missing.joinToString("、")}", style = MaterialTheme.typography.labelSmall, color = Warn)
                    }
                }
            }
        }

        if (state.marketCategory == "crypto") {
            state.derivatives?.let { d ->
                item {
                    AppCard {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("合约市场结构", style = MaterialTheme.typography.titleMedium, color = Accent)
                            TagChip(if (d.available) "PUBLIC DATA" else "不可用", if (d.available) Bull else Warn)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("Funding ${d.fundingRate?.let { "%.4f%%".format(it*100) } ?: "—"}   OI ${d.openInterest?.let { "%.2f".format(it) } ?: "—"}", color = TextPrimary)
                        Spacer(Modifier.height(5.dp))
                        Text("Mark ${d.markPrice?.let { "%.4f".format(it) } ?: "—"} · Index ${d.indexPrice?.let { "%.4f".format(it) } ?: "—"}", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(5.dp))
                        Text("多空账户比 ${d.longShortRatio?.let { "%.3f".format(it) } ?: "—"} · Taker 买卖比 ${d.buySellRatio?.let { "%.3f".format(it) } ?: "—"}", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(5.dp))
                        Text("基差率 ${d.basisRate?.let { "%.4f%%".format(it*100) } ?: "—"} · 最近强平价 ${d.liquidationPrice?.let { "%.4f".format(it) } ?: "—"}", color = TextMuted, style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(6.dp))
                        Text("以上均为公开市场数据，只用于判断拥挤度、杠杆情绪与价格结构，不代表交易执行。", color = TextMuted, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            state.multiExchange?.let { ex ->
                item {
                    AppCard {
                        Text("多交易所一致性", style = MaterialTheme.typography.titleMedium, color = Accent)
                        Spacer(Modifier.height(6.dp))
                        Text("可用 ${ex.providerCount}/3 · 共识价格 ${ex.markPriceMean?.let { "%.4f".format(it) } ?: "—"}", color = TextPrimary)
                        Text("Funding均值 ${ex.fundingRateMean?.let { "%.5f".format(it) } ?: "—"} · OI均值 ${ex.openInterestMean?.let { "%.2f".format(it) } ?: "—"}", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                        Text("价格离散 ${ex.markSpreadPct?.let { "%.4f%%".format(it) } ?: "—"} · Funding离散 ${ex.fundingSpread?.let { "%.6f".format(it) } ?: "—"}", color = TextMuted, style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(8.dp))
                        ex.providers.forEach { row ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(row.provider.uppercase(), color = if (row.available) TextPrimary else TextMuted, fontWeight = FontWeight.Medium)
                                Text(if (row.available) "${row.markPrice?.let { "%.4f".format(it) } ?: "—"} · F ${row.fundingRate?.let { "%.5f".format(it) } ?: "—"}" else "不可用", color = if (row.available) TextSecondary else Warn, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }

        state.unifiedReport?.let { report ->
            item {
                AppCard {
                    Text("AI 行情结论 · ${report.timeframe}", style = MaterialTheme.typography.titleMedium, color = Accent)
                    Spacer(Modifier.height(6.dp))
                    Text(report.summary.ifBlank { "当前暂无一句话结论" }, style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
                    if (report.narrative.isNotBlank()) {
                        Spacer(Modifier.height(6.dp))
                        Text(report.narrative, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("多头情景", style = MaterialTheme.typography.labelLarge, color = Bull)
                    Text(report.longSummary, style = MaterialTheme.typography.bodySmall, color = TextPrimary)
                    Spacer(Modifier.height(5.dp))
                    Text("空头情景", style = MaterialTheme.typography.labelLarge, color = Bear)
                    Text(report.shortSummary, style = MaterialTheme.typography.bodySmall, color = TextPrimary)
                    Spacer(Modifier.height(5.dp))
                    Text("持仓观察", style = MaterialTheme.typography.labelLarge, color = Accent)
                    Text(report.holdingSummary, style = MaterialTheme.typography.bodySmall, color = TextPrimary)
                    if (report.riskNotes.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        report.riskNotes.take(4).forEach { Text("· $it", style = MaterialTheme.typography.bodySmall, color = TextMuted) }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("数据时间 ${report.generatedAt} · 数据质量 ${report.dataQuality}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                }
            }
        }

        state.analysisFeedback?.let { fb ->
            item {
                AppCard {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("历史分析反馈", style = MaterialTheme.typography.titleMedium, color = Accent)
                        TagChip(when (fb.currentState) { "validated" -> "阶段验证"; "invalidated" -> "已失效"; "tracking" -> "继续跟踪"; else -> "等待反馈" }, when (fb.currentState) { "validated" -> Bull; "invalidated" -> Bear; "tracking" -> Accent; else -> Neutral })
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(fb.currentSummary, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                    Spacer(Modifier.height(8.dp))
                    fb.history.take(5).forEach { h ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("${h.reportId} · ${h.direction} · ${(h.confidence * 100).toInt()}%", color = TextPrimary, style = MaterialTheme.typography.bodySmall)
                                Text(h.feedbackSummary, color = TextMuted, style = MaterialTheme.typography.labelSmall, maxLines = 2)
                            }
                            TagChip(when(h.feedbackState){"validated"->"验证";"invalidated"->"失效";"tracking"->"跟踪";else->"等待"}, when(h.feedbackState){"validated"->Bull;"invalidated"->Bear;"tracking"->Accent;else->Neutral})
                        }
                    }
                    Text("历史报告为冻结快照，当前周期切换后会重新生成独立分析与反馈链。", color = TextMuted, style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        state.indicator?.let { ind ->
            item {
                AppCard {
                    Text("指标 · ${ind.timeframe}", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Text(ind.summary, style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
                    Spacer(Modifier.height(8.dp))
                    Text(ind.narrative, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TagChip("趋势 ${ind.trendLabel}", if (ind.trendLabel == "上涨") Bull else if (ind.trendLabel == "下跌") Bear else Neutral)
                        TagChip("强度 ${ind.trendStrength}", Neutral)
                        TagChip("超买 ${ind.overboughtCount}", if (ind.overboughtCount > 0) Bear else Neutral)
                        TagChip("超卖 ${ind.oversoldCount}", if (ind.oversoldCount > 0) Bull else Neutral)
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("价格 ${ind.lastPrice ?: "—"}  RSI ${ind.rsi ?: "—"}  MACD柱 ${ind.macdHist ?: "—"}", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                    Spacer(Modifier.height(6.dp))
                    Text("趋势 ${ind.trendSma ?: "—"}  布林位置 ${ind.bbPct ?: "—"}", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                    Spacer(Modifier.height(8.dp))
                    Text("完整指标", style = MaterialTheme.typography.labelLarge, color = Accent)
                    ind.details.forEach { Text("· $it", style = MaterialTheme.typography.bodySmall, color = TextSecondary) }
                    if (ind.structureNote.isNotBlank()) {
                        Spacer(Modifier.height(6.dp))
                        Text("行情结构：${ind.structureNote}", style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                    }
                    if (ind.divergence.isNotBlank()) Text("背离：${ind.divergence}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    ind.oscillators.forEach {
                        Spacer(Modifier.height(4.dp))
                        Text("· $it", style = MaterialTheme.typography.bodyMedium, color = TextMuted)
                    }
                    if (ind.signals.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        Text("信号", style = MaterialTheme.typography.labelLarge, color = Accent)
                        ind.signals.forEach {
                            Text("· $it", style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                        }
                    }
                }
            }
        }

        state.advice?.let { a ->
            item {
                AppCard {
                    Text("入场 / 开仓双向建议", style = MaterialTheme.typography.titleMedium, color = Accent)
                    Spacer(Modifier.height(6.dp))
                    Text("同时展示多单与空单情景；系统不会执行交易。", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                    Spacer(Modifier.height(10.dp))
                    listOf("多单" to a.longPlan, "空单" to a.shortPlan).forEach { (label, plan) ->
                        val tone = if (label == "多单") Bull else Bear
                        TagChip("$label · 置信 ${(plan.conviction * 100).toInt()}%", tone)
                        Spacer(Modifier.height(6.dp))
                        Text("观察区间 ${plan.entryLow ?: "—"} ~ ${plan.entryHigh ?: "—"} · 参考 ${plan.entry ?: "—"}", style = MaterialTheme.typography.bodyLarge)
                        Text("止损参考 ${plan.stop ?: "—"} · 目标 ${plan.tp1 ?: "—"} / ${plan.tp2 ?: "—"}", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                        Text("风险回报 ${plan.rr ?: "—"} · 风险暴露参考 ${((plan.positionPct ?: 0.0) * 100).toInt()}%", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                        plan.rationale.take(4).forEach { reason ->
                            Spacer(Modifier.height(3.dp))
                            Text("· $reason", style = MaterialTheme.typography.bodySmall, color = TextPrimary)
                        }
                        Spacer(Modifier.height(10.dp))
                    }
                    TagChip("当前持仓观察：${a.positionAction}", Neutral)
                    Spacer(Modifier.height(6.dp))
                    Text(a.positionNote, style = MaterialTheme.typography.bodyMedium, color = TextMuted)
                    Text("综合偏向：${a.direction.uppercase()} · ${a.bias}", style = MaterialTheme.typography.bodySmall, color = Accent)
                    Spacer(Modifier.height(6.dp))
                    Text("分析每15秒刷新一次；多周期数据同步重新计算。", style = MaterialTheme.typography.labelMedium, color = TextMuted)
                    Text("分析模式：仅提供行情、技术指标、多空情景与开仓/持仓观察建议，不提供模拟或下单功能。", style = MaterialTheme.typography.labelMedium, color = TextMuted)
                }
            }
        }

        if (state.reportCatalog.isNotEmpty()) {
            item {
                Text("32 类报告中心", style = MaterialTheme.typography.titleMedium, color = Accent)
                Spacer(Modifier.height(4.dp))
                Text("以下状态属于当前品种 ${state.marketCategory} · ${state.timeframe} 的独立数据检查；打开报告后才加载该品种的完整正文。", style = MaterialTheme.typography.bodySmall, color = TextMuted)
            }
            items(state.reportCatalog) { r ->
                AppCard(Modifier.clickable { state.openReport(r.key) }) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${r.id}. ${r.name}", style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                            Text("${r.domain} · ${r.update}", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            TagChip(r.priority, if (r.priority == "P0") Bear else if (r.priority == "P1") Accent else Neutral)
                            Spacer(Modifier.height(4.dp))
                            TagChip(when (r.status) {
                                "available" -> "可生成"
                                "pending_provider" -> "等待数据源"
                                "unavailable" -> "不可用"
                                else -> "待检测"
                            }, when (r.status) {
                                "available" -> Bull
                                "pending_provider" -> Warn
                                "unavailable" -> Bear
                                else -> Neutral
                            })
                        }
                    }
                }
            }
        }

        state.selectedReport?.let { report ->
            item {
                AppCard {
                    Text("${report.name} · ${report.key}", style = MaterialTheme.typography.titleMedium, color = Accent)
                    Spacer(Modifier.height(6.dp))
                    TagChip(report.availability, if (report.availability == "available") Bull else Neutral)
                    Spacer(Modifier.height(6.dp))
                    Text(report.summary, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                    if (report.availabilityReason.isNotBlank()) Text(report.availabilityReason, style = MaterialTheme.typography.bodySmall, color = TextMuted)
                    report.content.take(12).forEach { Text("· $it", style = MaterialTheme.typography.bodySmall, color = TextSecondary) }
                    if (state.reportLoading) LinearProgressIndicator(Modifier.fillMaxWidth())
                    Spacer(Modifier.height(4.dp))
                    Text("生成时间 ${report.generatedAt} · 数据质量 ${report.dataQuality}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                }
            }
        }

        state.multiTimeframe?.let { mtf ->
            item {
                AppCard {
                    Text("多周期共振", style = MaterialTheme.typography.titleMedium, color = Accent)
                    Spacer(Modifier.height(6.dp))
                    TagChip(mtf.resonance, if (mtf.resonance.contains("多") && !mtf.resonance.contains("空") ) Bull else if (mtf.resonance.contains("空")) Bear else Neutral)
                    Spacer(Modifier.height(6.dp))
                    Text(mtf.resonanceNote, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                    Spacer(Modifier.height(8.dp))
                    mtf.timeframes.toSortedMap(compareBy { AppState.timeframes.indexOf(it).let { i -> if (i < 0) 99 else i } }).forEach { (tf, r) ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(tf, style = MaterialTheme.typography.bodyMedium, color = if (tf == mtf.currentTimeframe) Accent else TextSecondary)
                            Text("${r.trendLabel} · ${r.trendStrength} · 超买${r.overboughtCount}/超卖${r.oversoldCount}", style = MaterialTheme.typography.bodySmall, color = TextPrimary)
                        }
                        Spacer(Modifier.height(4.dp))
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(mtf.realtimeNote, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                }
            }
        }

        if (!state.detailLoading && state.indicator == null && state.advice == null) {
            item {
                AppCard {
                    Text("未加载到数据", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(6.dp))
                    Text("1. 本机启动后端 uvicorn\n2. ApiConfig.baseUrl 指向可达地址\n3. 再点周期或返回重进", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                }
            }
        }
    }
}

@Composable
fun AnalysisScreen(state: AppState) {
    // 引导去点市场；若已有上次建议也可展示
    LazyColumn(
        Modifier.fillMaxSize().background(Bg).padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 20.dp, bottom = 88.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Text("分析", style = MaterialTheme.typography.displaySmall, color = TextPrimary)
            Spacer(Modifier.height(4.dp))
            Text("在「市场/发现」点击品种进入详情，可切换周期并拉取超买超卖与入场建议。", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
            Spacer(Modifier.height(12.dp))
        }
        items(state.markets.take(6)) { m ->
            AppCard(Modifier.clickable { state.openDetail(m.symbol, m.assetClass) }) {
                Text(m.symbol, style = MaterialTheme.typography.titleMedium)
                Text("点击加载 ${state.timeframe} 指标与建议", style = MaterialTheme.typography.bodyMedium, color = TextMuted)
            }
        }
    }
}

@Composable
fun AccountScreen(state: AppState) {
    LazyColumn(
        Modifier.fillMaxSize().background(Bg).padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 20.dp, bottom = 88.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Text("观察", style = MaterialTheme.typography.displaySmall, color = TextPrimary)
            Spacer(Modifier.height(6.dp))
            Text("这是纯分析平台：不模拟、不下单、不连接交易账户。", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
        }
        item {
            AppCard {
                Text("分析范围", style = MaterialTheme.typography.titleMedium, color = Accent)
                Spacer(Modifier.height(8.dp))
                Text("加密货币 · 美股 · 港股 · 大宗商品", style = MaterialTheme.typography.bodyLarge)
                Spacer(Modifier.height(6.dp))
                Text("每个品种均进入独立详情页：实时/最新行情、多周期指标、市场结构、AI 多空情景、开仓观察区间、持仓观察建议与风险。", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
            }
        }
    }
}
