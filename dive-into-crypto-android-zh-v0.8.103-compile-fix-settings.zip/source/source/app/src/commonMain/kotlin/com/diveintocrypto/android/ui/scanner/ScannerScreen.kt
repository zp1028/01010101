package com.diveintocrypto.android.ui.scanner

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddAlert
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.diveintocrypto.android.AppContainer
import com.diveintocrypto.android.domain.alerts.AlertKind
import com.diveintocrypto.android.domain.model.Signal
import com.diveintocrypto.android.domain.scanner.ForwardEntryPlanEngine
import com.diveintocrypto.android.domain.scanner.ForwardPlanJournal
import com.diveintocrypto.android.domain.scanner.ForwardReplayProgress
import com.diveintocrypto.android.domain.scanner.ForwardReplayCandle
import com.diveintocrypto.android.domain.scanner.ForwardPlanReplayEvaluator
import com.diveintocrypto.android.domain.scanner.ForwardReplayBatchSelector
import com.diveintocrypto.android.platform.ShareVerdictPayload
import com.diveintocrypto.android.platform.format
import com.diveintocrypto.android.platform.formatTime
import com.diveintocrypto.android.platform.nowMillis
import com.diveintocrypto.android.platform.rememberShareVerdict
import com.diveintocrypto.android.platform.rememberShareText
import com.diveintocrypto.android.ui.alerts.AlertAddSheet
import com.diveintocrypto.android.ui.alerts.AlertLabels
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect
import kotlin.math.abs
import com.diveintocrypto.android.ui.theme.DiveColors
import com.diveintocrypto.android.ui.theme.DiveDims
import com.diveintocrypto.android.ui.theme.DiveFonts

/**
 * Scanner — mobile-first redesign.
 *
 * The previous incarnation forced a 16-column cross-ranking table into a
 * 360dp viewport, hidden behind a horizontalScroll that cut off everything
 * past column 5 (Direction/NetNSS/TF/1m). The user could NOT see all the
 * info on a phone like that.
 *
 * New layout, top to bottom:
 *   1. ScanHeroCard       — manual start/stop, scan stats, primary CTA
 *   2. (scanning)         — ProgressBlock with current symbol + bar
 *   3. (after scan)       — TfPillBar (active TF selector, horizontal pills)
 *   4. (after scan)       — CommonInfoChip (cross-TF agreement banner)
 *   5. (after scan)       — Vertical list of CoinResultCards.
 *
 *   Each CoinResultCard packs ALL info for one symbol into a single card,
 *   visible without horizontal scroll:
 *     - rank + symbol + signal pill + live price (row 1)
 *     - confidence bar (0..100%) + risk badge (row 2)
 *     - 4×3 mini-grid showing all 12 timeframes, color-tinted by signal,
 *       label = TF + confidence% (rows 3-5)
 *     - cross-TF agreement chip + "Select" CTA (row 6)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScannerScreen(container: AppContainer, onSelectSymbol: (String) -> Unit = {}, onOpenAnalysis: (String) -> Unit = {}, onAiAnalyze: (String) -> Unit = {}) {
    // App-scoped: uses the single instance from AppContainer instead of a screen-scoped
    // viewModel{} so the scan does not stop on navigation between screens or in the background.
    val vm: ScannerViewModel = container.scannerViewModel
    val state by vm.ui.collectAsStateWithLifecycle()
    val aiSession by container.aiSessionHub.session.collectAsStateWithLifecycle()

    // Result lens: "All" (consensus order, first TOP_N) vs "背离" (only rows flagged
    // with a whale-L/S bearish divergence, by divergence score). Presents divergence as a
    // discoverable lens without polluting the consensus order (reviewer P0).
    var resultFilter by rememberSaveable { mutableStateOf(ResultFilter.ALL) }
    // 共识 / 启动：两个独立分页。启动仅展示层重排，不改引擎。
    var rankBoard by rememberSaveable { mutableStateOf(RankBoard.AI_TOP) }
    // 多组合周期信号筛选（AND 组合）
    // Serialize the small UI filter model so it survives ScannerScreen leaving composition.
    val signalRulesSaver = remember {
        Saver<List<SignalFilterRule>, List<String>>(
            save = { rules -> rules.flatMap { listOf(it.tf, it.want.name) } },
            restore = { values ->
                values.chunked(2).mapNotNull { pair ->
                    if (pair.size != 2) null
                    else runCatching { SignalFilterRule(pair[0], SignalWant.valueOf(pair[1])) }.getOrNull()
                }
            },
        )
    }
    var signalRules by rememberSaveable(stateSaver = signalRulesSaver) {
        mutableStateOf<List<SignalFilterRule>>(emptyList())
    }

    // ── Watchlist live prices + favorites (Task 4 — client-side in the Screen).
    // ScannerViewModel exposes no favorites/live-ticker API, so the Screen consumes
    // AppContainer directly: the app-scoped all-market mini-ticker map for the live
    // price overlay, and SettingsStore favorites for the ★ İZLEME lens.
    val liveTickers by container.liveTickerEngine.tickers.collectAsStateWithLifecycle()
    val settings by container.settingsStore.settingsState.collectAsStateWithLifecycle()

    // After AI fusion completes, generate AI-primary forward plans (non-blocking).
    LaunchedEffect(state.aiFusionProgressText, state.survivors.size, settings.aiEnabled) {
        val msg = state.aiFusionProgressText
        if (settings.aiEnabled && (
            msg.contains("手动复核完成") || msg.contains("AI 统一复核完成")
        ) && state.survivors.isNotEmpty()
        ) {
            vm.runAiForwardPlans(force = false)
        }
    }
    val forwardPlanJournal = remember(container.settingsStore) { ForwardPlanJournal(container.settingsStore) }
    val forwardPlanJournalState by forwardPlanJournal.data.collectAsStateWithLifecycle()

    // Real replay integration: while the scanner is visible, backfill actual Binance USDT-M
    // futures candles for a bounded set of active plans and persist only terminal outcomes.
    // This is intentionally not a trading loop and never calls an order endpoint.
    LaunchedEffect(container, forwardPlanJournal) {
        // Per-plan exponential backoff prevents an unavailable symbol/endpoint from being
        // requested every minute forever. This is in-memory only; a process restart safely
        // retries again, while persisted replay checkpoints remain the source of truth.
        val retryAfterByPlan = mutableMapOf<String, Long>()
        val failureCountByPlan = mutableMapOf<String, Int>()
        while (true) {
            val now = nowMillis()
            val journalSnapshot = forwardPlanJournal.data.value
            val replayRecords = journalSnapshot.replayResults
            val latestCheckpointByPlan = replayRecords.groupBy { it.planId }
                .mapValues { (_, records) -> records.maxByOrNull { it.savedAtMs } }
            // Fair scheduling: process plans with no checkpoint / oldest checkpoint first,
            // rather than permanently favoring the newest 12 plans in a large watch history.
            val candidates = ForwardReplayBatchSelector.select(
                plans = journalSnapshot.plans.filter { (retryAfterByPlan[it.snapshot.id] ?: 0L) <= now },
                replayRecords = replayRecords,
                limit = 12,
            )
            for (tracked in candidates) {
                val plan = tracked.snapshot
                if (now < plan.generatedAtMs) continue
                try {
                    // This scanner generates USDT-M futures plans; use the plan's own timeframe
                    // and only real REST candles. The evaluator filters bars by decision time.
                    val intervalMs = when (plan.primaryTimeframe) {
                        "1m" -> 60_000L
                        "3m" -> 3 * 60_000L
                        "5m" -> 5 * 60_000L
                        "15m" -> 15 * 60_000L
                        "30m" -> 30 * 60_000L
                        "1h" -> 60 * 60_000L
                        "2h" -> 2 * 60 * 60_000L
                        "4h" -> 4 * 60 * 60_000L
                        "6h" -> 6 * 60 * 60_000L
                        "12h" -> 12 * 60 * 60_000L
                        "1d" -> 24 * 60 * 60_000L
                        else -> 60 * 60_000L
                    }
                    // Persisted OPEN checkpoints prevent repeatedly downloading/re-evaluating
                    // the same full history window every minute. Recheck only after a new bar
                    // could have closed; terminal outcomes are immutable below.
                    val checkpoint = latestCheckpointByPlan[plan.id]
                    if (checkpoint != null && checkpoint.outcome == ForwardPlanReplayEvaluator.Outcome.OPEN.name &&
                        now < checkpoint.evaluatedThroughMs + intervalMs) continue
                    // Persist the page cursor and accumulated bars so a transient failure or
                    // process restart resumes at the next page instead of redownloading history.
                    val replayEnd = minOf(now, plan.expiresAtMs + intervalMs)
                    val existingProgress = forwardPlanJournal.replayProgress(plan.id)
                    var progress = if (existingProgress != null &&
                        existingProgress.windowStartMs == plan.generatedAtMs &&
                        existingProgress.windowEndMs == plan.expiresAtMs + intervalMs) existingProgress
                    else ForwardReplayProgress(plan.id, plan.generatedAtMs, plan.expiresAtMs + intervalMs,
                        plan.generatedAtMs, updatedAtMs = now)
                    if (!progress.complete && progress.candles.size < ForwardPlanJournal.MAX_CANDLES_PER_PROGRESS) {
                        val page = container.repository.futuresHistoryPage(
                            symbol = plan.symbol,
                            interval = plan.primaryTimeframe,
                            startTimeMs = progress.nextCursorMs,
                            endTimeMs = replayEnd,
                            limit = 1000,
                        )
                        val merged = (progress.candles.map { it.toCandle() } + page)
                            .distinctBy { it.openTime }.sortedBy { it.openTime }
                        val last = page.lastOrNull()
                        val nextCursor = last?.let { it.openTime + intervalMs } ?: progress.nextCursorMs
                        val noProgress = if (page.isEmpty() || nextCursor <= progress.nextCursorMs) progress.noProgressPages + 1 else 0
                        // Empty pages and exhausted request budget are not proof of full coverage.
                        val complete = last != null && last.closeTime >= (progress.windowEndMs - intervalMs)
                        progress = progress.copy(
                            nextCursorMs = nextCursor,
                            candles = merged.takeLast(ForwardPlanJournal.MAX_CANDLES_PER_PROGRESS).map { ForwardReplayCandle.from(it) },
                            updatedAtMs = now,
                            complete = complete,
                            noProgressPages = noProgress,
                        )
                        forwardPlanJournal.saveReplayProgress(progress)
                    }
                    val candles = progress.candles.map { it.toCandle() }
                    // Do not label an old plan expired merely because history is absent or the
                    // paging endpoint temporarily returned an empty page.
                    if (candles.none { it.closeTime > plan.generatedAtMs && it.closeTime <= now }) continue
                    val replay = ForwardPlanReplayEvaluator.evaluate(
                        plan = plan,
                        candles = candles,
                        asOfMs = now,
                        expectedIntervalMs = intervalMs,
                    )
                    if (replay.outcome == ForwardPlanReplayEvaluator.Outcome.TARGET_HIT ||
                        replay.outcome == ForwardPlanReplayEvaluator.Outcome.STOP_HIT ||
                        replay.outcome == ForwardPlanReplayEvaluator.Outcome.EXPIRED ||
                        replay.outcome == ForwardPlanReplayEvaluator.Outcome.OPEN) {
                        // OPEN is a checkpoint only, never a settled performance result.
                        forwardPlanJournal.appendReplayResult(replay, savedAtMs = nowMillis())
                        if (replay.outcome == ForwardPlanReplayEvaluator.Outcome.TARGET_HIT ||
                            replay.outcome == ForwardPlanReplayEvaluator.Outcome.STOP_HIT ||
                            replay.outcome == ForwardPlanReplayEvaluator.Outcome.EXPIRED) {
                            forwardPlanJournal.clearReplayProgress(plan.id)
                        }
                    }
                    failureCountByPlan.remove(plan.id)
                    retryAfterByPlan.remove(plan.id)
                } catch (cancelled: kotlinx.coroutines.CancellationException) {
                    throw cancelled
                } catch (_: Throwable) {
                    // Exponential backoff (1, 2, 4, 8, 15 minutes) prevents retry storms.
                    val failures = ((failureCountByPlan[plan.id] ?: 0) + 1).coerceAtMost(5)
                    failureCountByPlan[plan.id] = failures
                    val delayMs = minOf(15L * 60_000L, 60_000L * (1L shl (failures - 1)))
                    retryAfterByPlan[plan.id] = nowMillis() + delayMs
                    // Public history can fail transiently; local ranking/UI remains available.
                }
            }
            delay(60_000L)
        }
    }
    val favoriteSet = remember(settings.favorites) { settings.favorites.map { it.uppercase() }.toSet() }
    var watchOnly by rememberSaveable { mutableStateOf(false) }
    var quickWatchScan by rememberSaveable { mutableStateOf(false) }
    // Quick-add alert sheet (🔔 on a result row): the symbol it opens for.
    var alertSheetSymbol by rememberSaveable { mutableStateOf<String?>(null) }
    // PAYLAŞ (v0.3.0): renders the row's verdict as a PNG share card and fires
    // the system share sheet (androidMain util; see platform/Share expect/actual).
    val shareVerdictCard = rememberShareVerdict()
    val shareText = rememberShareText()
    // ALL = survivors after elimination (as many as the table size); DIVERGENCE = eliminated.
    val eliminatedCount = state.eliminated.size
    // OPT-IN "Divergence Sort": when ON, the SAME survivor pool (state.survivors) is re-sorted
    // by |divergenceScore| desc — the cross-sectional top-K validated by backtest (rows with the
    // highest |divergence|) is surfaced into the visible window. Rows below the threshold
    // (DIVERGENCE_MIN_SHOWN) keep their default (netNss+0.35×div) order and sink to the bottom.
    // When OFF (default), the list stays bit-for-bit identical to today's. This is ONLY a
    // presentation re-sort: the pool/elimination/score are UNCHANGED (sortedByDescending is
    // stable → the relative order of sub-threshold rows is preserved).
    // remember() keyed on the pool + lens: the re-sort runs when its INPUTS change, not on
    // every recomposition (progress ticks used to re-sort the whole list each frame).
    val orderedSurvivors = remember(state.survivors, state.divergenceSort) {
        if (state.divergenceSort) {
            state.survivors.sortedByDescending { row ->
                if (abs(row.divergenceScore) >= ScannerViewModel.DIVERGENCE_MIN_SHOWN)
                    abs(row.divergenceScore) else Double.NEGATIVE_INFINITY
            }
        } else {
            state.survivors
        }
    }
    val lensRows = when (resultFilter) {
        ResultFilter.ALL -> orderedSurvivors.take(state.displaySize)
        ResultFilter.DIVERGENCE -> state.eliminated
    }
    // 启动排行：同一 survivors 池，仅展示层重排
    val earlyOrdered = remember(state.survivors, state.crossRanking) {
        val pool = if (state.survivors.isNotEmpty()) state.survivors else state.crossRanking
        pool.mapNotNull { row ->
            val score = earlyEntryScore(row) ?: return@mapNotNull null
            row to score
        }.sortedByDescending { it.second }.map { it.first }
    }
    // 前瞻计划由已完成扫描快照生成：只建立可证伪的预备条件，不把尚未发生的触发标记为已触发。
    // AI 融合只影响受约束的扫描排序；本地计划引擎与硬风险规则仍独立负责计划价位。
    val forwardPlanResult = remember(
        state.survivors, state.crossRanking, state.lastScanAtMs,
        settings.riskTargetR, settings.riskFeeSidePct, settings.riskSlippageSidePct,
    ) {
        val generatedAt = state.lastScanAtMs ?: nowMillis()
        val now = nowMillis()
        val pool = if (state.survivors.isNotEmpty()) state.survivors else state.crossRanking
        val rejected = linkedMapOf<String, Int>()
        val plans = pool.flatMap { row ->
            val direction = when {
                row.netNss > 0.0 -> 1
                row.netNss < 0.0 -> -1
                else -> 0
            }
            val evidence = row.perTf.map { (tf, slot) ->
                val tfDirection = when (slot.signal) {
                    Signal.BUY, Signal.STRONG_BUY -> 1
                    Signal.SELL, Signal.STRONG_SELL -> -1
                    Signal.NEUTRAL -> 0
                }
                ForwardEntryPlanEngine.TimeframeEvidence(tf, tfDirection, slot.confidence, slot.timeWeight)
            }
            val result = ForwardEntryPlanEngine.generate(
                ForwardEntryPlanEngine.Input(
                    symbol = row.symbol,
                    currentPrice = row.price,
                    atrPercent = row.atrPct,
                    support = row.supportPrice,
                    resistance = row.resistancePrice,
                    dominantDirection = direction,
                    mtfDirection = row.mtfDirection,
                    mtfGate = row.mtfGate,
                    regime = row.regime,
                    evidence = evidence,
                    divergenceDirection = row.divergenceDirection,
                    candleOpenTimeMs = row.marketDataOpenTimeMs,
                    candleTimeframeMs = row.marketDataTimeframeMs,
                    generatedAtMs = generatedAt,
                    nowMs = now,
                    targetR = settings.riskTargetR,
                    feeSidePct = settings.riskFeeSidePct,
                    slippageSidePct = settings.riskSlippageSidePct,
                ),
            )
            result.rejectionReasons.forEach { (reason, count) -> rejected[reason] = (rejected[reason] ?: 0) + count }
            result.plans
        }.distinctBy { it.id }.sortedWith(compareByDescending<ForwardEntryPlanEngine.Plan> { it.quality }.thenBy { it.expiresAtMs })
        ForwardEntryPlanEngine.Result(plans, rejected)
    }
    // Persist generated snapshots outside the composition. The journal keeps the original
    // immutable plan and records lifecycle changes across page switches/restarts.
    LaunchedEffect(forwardPlanResult.plans, state.crossRanking, state.lastScanAtMs) {
        val stamp = state.lastScanAtMs ?: nowMillis()
        if (forwardPlanResult.plans.isNotEmpty()) {
            forwardPlanJournal.mergeCandidates(forwardPlanResult.plans, stamp)
        }
        // AI proposals are appended as immutable revisions only when the local fusion guard
        // explicitly accepted their direction/entry/stop/target/RR. Original local snapshots
        // remain untouched and continue to be the risk-control baseline.
        val currentPlans = forwardPlanJournal.data.value.plans
        state.crossRanking.filter { row ->
            row.aiPlanAccepted && row.aiSuggestedEntry != null && row.aiSuggestedStop != null && row.aiSuggestedTarget != null
        }.forEach { row ->
            val tracked = currentPlans.firstOrNull {
                it.snapshot.symbol == row.symbol && it.status in ForwardPlanJournal.ACTIVE_STATUSES
            } ?: return@forEach
            forwardPlanJournal.appendAiRevision(
                planId = tracked.snapshot.id,
                entry = row.aiSuggestedEntry,
                stop = row.aiSuggestedStop,
                target = row.aiSuggestedTarget,
                createdAtMs = stamp,
                rationale = row.aiFusionThesis ?: row.aiFusionReason ?: "通过本地 AI 融合风控校验",
                maxEntryDriftPct = minOf(1.5, tracked.snapshot.maxAllowedPriceMovePct.coerceAtLeast(0.25)),
            )
        }
    }
    // Follow the ticker stream without restarting the collector on every price tick. A live
    // price can invalidate/expire a plan, but CONDITION_MET requires a later closed K-line.
    val forwardPlanIds = forwardPlanJournalState.plans.map { it.snapshot.id }
    LaunchedEffect(forwardPlanIds) {
        val lastProbeAt = mutableMapOf<String, Long>()
        container.liveTickerEngine.tickers.collect { tickerMap ->
            val now = nowMillis()
            var probesThisTick = 0
            val trackedPlans = forwardPlanJournal.data.value.plans.filter {
                it.status == ForwardEntryPlanEngine.Status.PREPARING ||
                    it.status == ForwardEntryPlanEngine.Status.WAITING_TRIGGER ||
                    it.status == ForwardEntryPlanEngine.Status.CONDITION_MET
            }
            for (tracked in trackedPlans) {
                val plan = tracked.snapshot
                val ticker = tickerMap[plan.symbol]
                if (ticker == null) {
                    forwardPlanJournal.observe(plan.id, plan.referencePrice, now)
                    continue
                }
                if (container.liveTickerEngine.isStale.value) {
                    // Permit time-based expiry while avoiding false price-drift invalidation from stale quotes.
                    forwardPlanJournal.observe(plan.id, plan.referencePrice, now)
                    continue
                }
                if (ticker.price <= 0.0) continue
                forwardPlanJournal.observe(plan.id, ticker.price, now)
                val crossed = if (plan.direction == ForwardEntryPlanEngine.Direction.LONG)
                    ticker.price >= plan.triggerPrice else ticker.price <= plan.triggerPrice
                val timeframeMs = when (plan.primaryTimeframe.lowercase()) {
                    "1m" -> 60_000L; "3m" -> 180_000L; "5m" -> 300_000L; "15m" -> 900_000L
                    "30m" -> 1_800_000L; "1h" -> 3_600_000L; "2h" -> 7_200_000L; "4h" -> 14_400_000L
                    "6h" -> 21_600_000L; "8h" -> 28_800_000L; "12h" -> 43_200_000L; "1d" -> 86_400_000L
                    else -> 3_600_000L
                }
                val lastClosed = tracked.lastClosedCandleTimeMs ?: 0L
                val probeAllowed = now - (lastProbeAt[plan.id] ?: 0L) >= 15_000L &&
                    (lastClosed == 0L || now - lastClosed >= timeframeMs)
                if (crossed && probeAllowed && probesThisTick < 3) {
                    probesThisTick++
                    lastProbeAt[plan.id] = now
                    try {
                        val candles = kotlinx.coroutines.withTimeout(5_000L) {
                            container.repository.futuresHistory(plan.symbol, plan.primaryTimeframe, limit = 3)
                                .filter { it.closeTime < now }
                        }
                        val lastClosedBar = candles.maxByOrNull { it.closeTime }
                        if (lastClosedBar != null) {
                            forwardPlanJournal.observe(
                                planId = plan.id, price = ticker.price, atMs = now,
                                closedCandleClose = lastClosedBar.close,
                                closedCandleTimeMs = lastClosedBar.closeTime,
                            )
                        }
                    } catch (cancelled: kotlinx.coroutines.CancellationException) {
                        throw cancelled
                    } catch (_: Throwable) {
                        // Keep waiting. A failed candle request must never synthesize confirmation.
                    }
                }
            }
        }
    }
    val journalActive = forwardPlanJournalState.plans.filter {
        it.status == ForwardEntryPlanEngine.Status.PREPARING ||
            it.status == ForwardEntryPlanEngine.Status.WAITING_TRIGGER ||
            it.status == ForwardEntryPlanEngine.Status.CONDITION_MET
    }
    val activeKeys = journalActive.map { Triple(it.snapshot.symbol, it.snapshot.type, it.snapshot.primaryTimeframe) }.toSet()
    // AI-primary plans first (when present); journal + local engine fill gaps only.
    val aiPrimary = state.aiForwardPlans
    val forwardPlans = (
        aiPrimary +
            journalActive.map { it.snapshot.copy(status = it.status) } +
            forwardPlanResult.plans.filter {
                Triple(it.symbol, it.type, it.primaryTimeframe) !in activeKeys
            }
        )
        .distinctBy { it.symbol to it.direction } // prefer first = AI when same symbol+direction
        .sortedWith(
            compareByDescending<ForwardEntryPlanEngine.Plan> {
                if (it.validationNotes.any { n -> n.contains("AI主导") }) 1 else 0
            }.thenByDescending { it.quality }.thenBy { it.expiresAtMs },
        )

    // 共识数据源：优先 survivors；若仍空则回退 crossRanking（与 VM 回退双保险）
    val consensusPool = when {
        orderedSurvivors.isNotEmpty() -> orderedSurvivors
        state.crossRanking.isNotEmpty() -> state.crossRanking
        else -> emptyList()
    }
    val boardRows = when {
        rankBoard == RankBoard.FORWARD -> emptyList()
        rankBoard == RankBoard.AI_TOP -> state.aiTopPicks
        resultFilter == ResultFilter.DIVERGENCE -> lensRows
        rankBoard == RankBoard.EARLY -> {
            val pool = if (earlyOrdered.isNotEmpty()) earlyOrdered
            else consensusPool // 启动分全空时仍展示共识池，避免白屏
            pool.take(state.displaySize)
        }
        else -> consensusPool.take(state.displaySize)
    }
    // 周期信号多条件 AND 过滤
    val signalFiltered = remember(boardRows, signalRules) {
        if (signalRules.isEmpty()) boardRows
        else boardRows.filter { matchesSignalRules(it, signalRules) }
    }
    val displayedRows = if (watchOnly) {
        signalFiltered.filter { it.symbol.uppercase() in favoriteSet }
    } else signalFiltered
    val resultSummary = when {
        rankBoard == RankBoard.FORWARD -> "前瞻计划榜 · ${forwardPlans.size} 条 · AI主导 ${aiPrimary.size} · 不自动下单"
        rankBoard == RankBoard.AI_TOP -> {
            val src = if (state.aiTopPicksFromFusion) {
                "AI 按行情研判排序"
            } else {
                "本地精选（开启 AI 融合后由 AI 自行判断）"
            }
            "决策面 · $src ${state.aiTopPicks.size}/10 · 仅供研究参考，不自动下单"
        }
        resultFilter == ResultFilter.DIVERGENCE ->
            "鲸鱼背离与指标矛盾：已剔除 $eliminatedCount 个币种"
        rankBoard == RankBoard.EARLY ->
            "启动排行 · 候选 ${earlyOrdered.size}" +
                (if (signalRules.isNotEmpty()) " · 信号筛选 ${displayedRows.size}" else "") +
                " · 与共识隔离"
        else ->
            "${state.universeSize} · ✓${state.survivors.size} · ✕$eliminatedCount" +
                (if (signalRules.isNotEmpty()) " · 信号筛选 ${displayedRows.size}" else "")
    }
    // Number of candidate symbols tried but with no whale data available (coverage==0) — added
    // to the empty message to honestly surface silent false-negatives. remember()'d: the
    // recount is O(rows) and only needs to run when the ranking itself changes.
    val uncheckableCount = remember(state.crossRanking) {
        state.crossRanking.count { it.divergenceCoverage == 0 }
    }
    // Dismissal state for the partial-coverage note. Keyed on the failed count so the
    // note re-arms whenever the value changes (new scan resets it 0 → n).
    var failedNoteDismissed by rememberSaveable(state.failedCount) { mutableStateOf(false) }

    PullToRefreshBox(
        isRefreshing = state.scanning,
        onRefresh = { if (quickWatchScan) vm.startWatchlistScan(settings.favorites) else vm.startScan() },
        modifier = Modifier.fillMaxSize()
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(DiveColors.RootBg),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(
                horizontal = 12.dp,
                vertical = 12.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
        // ── 1) Hero / Control card ────────────────────────────────────────
        item("hero") {
            ScanHeroCard(
                state = state,
                resultSummary = resultSummary,
                onStart = { if (quickWatchScan) vm.startWatchlistScan(settings.favorites) else vm.startScan() },
                onStop = vm::stopDemoScan,
            )
        }

        // ── 1b) Scan controls: table size button + continuous (back-to-back) mode ──
        item("controls") {
            ScanControlsRow(
                displaySize = state.displaySize,
                continuous = state.continuous,
                cycle = state.cycle,
                scanning = state.scanning,
                divergenceSort = state.divergenceSort,
                onSize = vm::setDisplaySize,
                onContinuous = vm::setContinuous,
                onDivergenceSort = vm::setDivergenceSort,
            )
        }

        // ── 1b-AI) Visible scan-page switch for AI-assisted ranking. ──
        item("ai-fusion-control") {
            val aiReady = settings.aiFusionEnabled && settings.aiEnabled && settings.aiApiKey.isNotBlank()
            val aiActive = state.aiFusionProgressText.isNotBlank() ||
                state.survivors.any { it.aiFusionStatus != "AI融合关闭" && it.aiFusionStatus.isNotBlank() }
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        if (aiReady) DiveColors.Accent.copy(alpha = 0.08f) else DiveColors.BgCard
                    )
                    .border(
                        1.5.dp,
                        when {
                            state.aiFusionProgressText.isNotBlank() -> DiveColors.Accent
                            aiReady -> DiveColors.Accent.copy(alpha = 0.7f)
                            else -> DiveColors.Border
                        },
                        RoundedCornerShape(14.dp),
                    )
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Visual status pill so user can instantly see whether AI is in use.
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(
                                when {
                                    state.aiFusionProgressText.isNotBlank() -> DiveColors.Accent
                                    aiReady -> DiveColors.Green
                                    settings.aiFusionEnabled -> DiveColors.Warn
                                    else -> DiveColors.Border
                                },
                            )
                            .padding(horizontal = 8.dp, vertical = 3.dp),
                    ) {
                        Text(
                            text = when {
                                state.aiFusionProgressText.isNotBlank() -> "AI 复核中"
                                aiReady -> "AI 已启用"
                                settings.aiFusionEnabled -> "AI 未就绪"
                                else -> "AI 关闭"
                            },
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                    Text("AI 融合排行", color = DiveColors.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    TextButton(
                        onClick = {
                            container.settingsStore.updateSettings(settings.copy(aiFusionEnabled = !settings.aiFusionEnabled))
                        },
                    ) {
                        Text(if (settings.aiFusionEnabled) "已开启 · 点击关闭" else "点击启用 AI 排行")
                    }
                }
                Text(
                    text = when {
                        !settings.aiFusionEnabled -> "当前仅本地量化排行。开启后，扫描结束时 AI 以「解释与风控复核」为主；仅在高置信且通过假突破/计划校验时才可能改方向，且绝不自动下单。"
                        !settings.aiEnabled -> "融合开关已开，但全局 AI 分析尚未启用；请到设置页启用 AI 并配置 API Key。"
                        settings.aiApiKey.isBlank() -> "融合开关已开，但 API Key 为空；请到设置页配置模型地址、模型名称和 API Key。"
                        else -> "AI 融合已启用：本地结果先可用，随后分批复核。默认输出研判与风险点；改方向需通过严格门禁，属高级行为。"
                    },
                    color = if (aiReady) DiveColors.TextMuted else DiveColors.Warn,
                    fontSize = 11.sp,
                    lineHeight = 15.sp,
                )
                state.aiFusionProgressText.takeIf { it.isNotBlank() }?.let { progress ->
                    Text(progress, color = DiveColors.Accent, fontSize = 12.sp, fontWeight = FontWeight.Medium, lineHeight = 15.sp)
                }
                // Manual re-fusion: one-shot AI review without a full rescan.
                val fusionBusy = state.aiFusionProgressText.contains("复核中")
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    TextButton(
                        onClick = { vm.rerunAiFusion() },
                        enabled = !state.scanning && !fusionBusy && settings.aiFusionEnabled &&
                            settings.aiEnabled && settings.aiApiKey.isNotBlank() &&
                            (state.survivors.isNotEmpty() || state.crossRanking.isNotEmpty()),
                    ) {
                        Text(
                            text = when {
                                fusionBusy -> "复核中…"
                                else -> "重新复核"
                            },
                            fontWeight = FontWeight.Bold,
                        )
                    }
                    val forwardBusy = state.aiForwardProgressText.contains("生成中")
                    TextButton(
                        onClick = { vm.runAiForwardPlans(force = true) },
                        enabled = !state.scanning && !forwardBusy &&
                            settings.aiEnabled && settings.aiApiKey.isNotBlank() &&
                            (state.survivors.isNotEmpty() || state.crossRanking.isNotEmpty()),
                    ) {
                        Text(
                            text = when {
                                forwardBusy -> "方案生成中…"
                                else -> "AI前瞻方案"
                            },
                            fontWeight = FontWeight.Bold,
                        )
                    }
                    Text(
                        text = "复核=排行 · 前瞻方案=AI主导价位（不下单）",
                        color = DiveColors.TextDim,
                        fontSize = 10.sp,
                        modifier = Modifier.weight(1f),
                    )
                }
                state.aiForwardProgressText.takeIf { it.isNotBlank() }?.let { prog ->
                    Text(prog, color = DiveColors.Accent, fontSize = 11.sp, lineHeight = 14.sp)
                }
                if (settings.aiFusionEnabled) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "允许 AI 改方向",
                                color = DiveColors.Text,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                            )
                            Text(
                                if (settings.aiFusionAllowDirectionChange) {
                                    "已开启：高置信且过门禁时可反转展示方向"
                                } else {
                                    "默认关闭：AI 只解释与微调排名，不改方向"
                                },
                                color = DiveColors.TextDim,
                                fontSize = 10.sp,
                                lineHeight = 13.sp,
                            )
                        }
                        TextButton(
                            onClick = {
                                container.settingsStore.updateSettings(
                                    settings.copy(aiFusionAllowDirectionChange = !settings.aiFusionAllowDirectionChange),
                                )
                            },
                        ) {
                            Text(if (settings.aiFusionAllowDirectionChange) "已开 · 点击关闭" else "已关 · 点击开启")
                        }
                    }
                }
                if (aiActive && state.aiFusionProgressText.isBlank() && state.survivors.isNotEmpty()) {
                    val changed = state.survivors.count { it.aiDirectionChanged }
                    val accepted = state.survivors.count { it.aiPlanAccepted }
                    val reviewed = state.survivors.count { it.aiFusionStatus != "AI融合关闭" && it.aiFusionStatus.isNotBlank() }
                    Text(
                        text = "本轮 AI：复核 $reviewed 只 · 方向反转 $changed · 参考计划 $accepted",
                        color = DiveColors.Accent,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                    )
                }
            }
        }

        // ── 1b-round) Global round summary after a completed scan ──
        if (!state.scanning && state.survivors.isNotEmpty() && state.lastScanAtMs != null) {
            item("round-summary") {
                val longs = state.survivors.count { it.dominantDir.score > 0 }
                val shorts = state.survivors.count { it.dominantDir.score < 0 }
                val neutrals = state.survivors.size - longs - shorts
                val aiChanged = state.survivors.count { it.aiDirectionChanged }
                val failed = state.failedCount
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(DiveColors.BgCard)
                        .border(1.dp, DiveColors.Border, RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Text("本轮扫描摘要", color = DiveColors.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        text = "展示 ${state.survivors.size.coerceAtMost(state.displaySize)} 只 · 多 $longs / 空 $shorts / 中性 $neutrals" +
                            (if (aiChanged > 0) " · AI 改方向 $aiChanged" else "") +
                            (if (failed > 0) " · 数据失败 $failed" else ""),
                        color = DiveColors.TextMuted,
                        fontSize = 12.sp,
                        lineHeight = 16.sp,
                    )
                    Text(
                        text = "风险区优先展示 AI 入场/止损/止盈（有有效方案时）；AI 回退时显示本地引擎。研究参考，不下单。",
                        color = DiveColors.TextDim,
                        fontSize = 11.sp,
                    )
                }
            }
        }

        // ── 1b-quick) Favorite-only fast scan + CSV export of the current visible result set. ──
        item("quick-export") {
            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                FilterPill(
                    label = if (quickWatchScan) "⚡ 快速扫描（自选）：开" else "⚡ 快速扫描（自选）：关",
                    selected = quickWatchScan,
                    accent = DiveColors.Cyan,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { quickWatchScan = !quickWatchScan },
                )
                Text(
                    text = if (quickWatchScan) {
                        "快速模式：只扫自选，先出列表。完整宇宙扫描请关闭此开关后使用上方范围（TOP20/50/…）。"
                    } else {
                        "开启后下次只扫自选（更快）。完整扫描仍按上方宇宙范围执行；结果导出仅含当前筛选列表。"
                    },
                    color = DiveColors.TextDim,
                    fontSize = 11.sp,
                )
                TextButton(
                    onClick = {
                        val csv = buildScannerCsv(displayedRows, state.timeframes, vm::confidenceFor)
                        if (displayedRows.isNotEmpty()) shareText("币安合约扫描结果.csv", csv)
                    },
                    enabled = displayedRows.isNotEmpty() && !state.scanning,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("导出当前结果 CSV（${displayedRows.size}）") }
            }
        }

        // ── 1c) Universe depth status (honest, read-only) + rolling ETA ──
        item("universe") {
            UniverseInfoRow(
                universeMode = state.universeMode,
                universeSize = state.universeSize,
                etaSeconds = state.etaSeconds.takeIf { state.scanning },
                onSelectMode = vm::setUniverseMode,
            )
        }
        item("data-health") {
            ScanDataHealthCard(
                universeSize = state.universeSize,
                failedCount = state.failedCount,
                failureReasons = state.failureReasonCounts,
                scanning = state.scanning,
                completedCount = state.completedCount,
                totalCount = state.totalCount,
                lastScanAtMs = state.lastScanAtMs,
            )
        }

        // ── 2) Live progress while scanning ───────────────────────────────
        if (state.scanning) {
            item("progress") { ScanProgressBlock(state = state) }
        }

        // ── 2b) HONESTY: partial-coverage note — N symbols could NOT be scanned.
        // Dismissible; re-arms whenever the failed count changes (new scan → 0 → n).
        if (state.failedCount > 0 && !failedNoteDismissed) {
            item("failed") {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    FailedScanNote(
                        count = state.failedCount,
                        onDismiss = { failedNoteDismissed = true },
                    )
                    val reasonLabels = state.failureReasonCounts.entries
                        .sortedByDescending { it.value }
                        .take(4)
                        .joinToString(" · ") { (reason, count) ->
                            val label = when (reason) {
                                "network_or_api" -> "网络/API失败"
                                "insufficient_history" -> "K线数量不足"
                                "stale_latest_candle" -> "行情过期"
                                "unordered_or_duplicate_timestamps" -> "时间戳重复/乱序"
                                "non_finite_ohlcv" -> "行情含非有限值"
                                "invalid_ohlcv_range" -> "OHLCV数值异常"
                                "inconsistent_ohlc" -> "高低价关系异常"
                                "invalid_timestamp" -> "时间戳无效"
                                else -> "其他数据校验失败"
                            }
                            "$label $count"
                        }
                    if (reasonLabels.isNotBlank()) {
                        Text(text = "失败原因（按周期请求计数）：$reasonLabels", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        // HONESTY: previous results intentionally remain visible during a refresh.
        // Explicitly label them as last-completed results so users do not mistake
        // them for the in-progress scan's final ranking.
        if (state.scanning && state.lastScanAtMs != null && state.survivors.isNotEmpty()) {
            val lastScanAt = state.lastScanAtMs
            item("previous-results") {
                Text(
                    text = "正在更新扫描结果；当前列表仍是上次完成扫描的数据（${lastScanAt?.let { formatTs(it) } ?: ""}）",
                    color = DiveColors.Orange,
                    fontSize = 12.sp,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                )
            }
        }

        // Results (survivors after elimination). Also visible during a scan in continuous mode.
        if (state.survivors.isNotEmpty()) {
            item("lifecycle-summary") {
                Text(
                    text = "机会生命周期：${state.lifecycleSummary}",
                    color = DiveColors.TextMuted,
                    fontSize = 11.sp,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                )
            }
            // ── Result lens toggle ─────────────────────────────────────────
            // ── 共识 / 启动：两个独立分页（启动失败不影响共识原序）────────
            item("rankboard") {
                RankBoardToggle(
                    selected = rankBoard,
                    aiTopCount = state.aiTopPicks.size,
                    consensusCount = state.survivors.size,
                    earlyCount = earlyOrdered.size,
                    forwardCount = forwardPlans.size,
                    onSelect = {
                        rankBoard = it
                        if (it == RankBoard.FORWARD) resultFilter = ResultFilter.ALL
                    },
                )
            }
            if (rankBoard == RankBoard.AI_TOP) {
                item("aitop-intro") {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(DiveColors.BgCard)
                            .border(1.dp, DiveColors.Accent.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        Text(
                            text = if (state.aiTopPicksFromFusion) {
                                "AI 十佳 · 按 AI 对多周期行情的研判自行排序（最多 10）"
                            } else {
                                "本地十佳 · 有方向机会（开启 AI 融合后改由 AI 根据行情判断）"
                            },
                            color = DiveColors.Text,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                        )
                        Text(
                            text = if (state.aiTopPicksFromFusion) {
                                "排序依据：AI 置信度、假突破风险、计划 R:R 与论点质量；本地分数仅作微弱并列打破。AI 判中性/低置信不进十佳；与本地冲突进观察。默认不改本地方向。非投资建议，不自动下单。"
                            } else {
                                "当前尚未完成 AI 复核，暂按本地排名展示。开启顶部「AI 融合」并等待复核后，十佳将改为 AI 行情判断。"
                            },
                            color = DiveColors.TextDim,
                            fontSize = 11.sp,
                            lineHeight = 14.sp,
                        )
                        if (state.aiWatchPicks.isNotEmpty() && state.aiTopPicksFromFusion) {
                            Text(
                                text = "观察名单 ${state.aiWatchPicks.size} 只（AI 中性/低置信/冲突等）见列表底部",
                                color = DiveColors.Warn,
                                fontSize = 11.sp,
                            )
                        }
                    }
                }
            }
            if (rankBoard == RankBoard.FORWARD) {
                item("forwardnote") {
                    ForwardPlansIntro(
                        count = forwardPlans.size,
                        rejectionCount = forwardPlanResult.rejectionReasons.values.sum(),
                        recentEvents = forwardPlanJournalState.events.takeLast(8).asReversed(),
                        trackedPlans = forwardPlanJournalState.plans,
                        revisionCount = forwardPlanJournalState.revisions.size,
                        replayResults = forwardPlanJournalState.replayResults,
                        onArchivePlan = { id -> forwardPlanJournal.archivePlan(id, nowMillis()) },
                        onDeleteArchived = { forwardPlanJournal.deleteArchived() },
                    )
                }
                if (forwardPlans.isEmpty()) {
                    item("forwardempty") { ForwardPlansEmpty(scanning = state.scanning, hasRows = state.survivors.isNotEmpty() || state.crossRanking.isNotEmpty()) }
                } else {
                    itemsIndexed(forwardPlans, key = { _, plan -> plan.id }) { idx, plan ->
                        ForwardPlanCard(
                            plan = plan,
                            rank = idx + 1,
                            livePrice = liveTickers[plan.symbol]?.price,
                            aiRevision = forwardPlanJournalState.revisions.filter { it.planId == plan.id }.maxByOrNull { it.version },
                            onOpen = {
                                container.activeTimeframe.value = plan.primaryTimeframe
                                onSelectSymbol(plan.symbol)
                            },
                            onAnalyze = { onOpenAnalysis(plan.symbol) },
                        )
                    }
                }
            } else {
            if (rankBoard == RankBoard.EARLY && resultFilter == ResultFilter.ALL) {
                item("earlynote") {
                    EarlyBoardNote()
                }
            }

            item("sigfilter") {
                SignalFilterPanel(
                    availableTfs = state.timeframes.ifEmpty {
                        listOf("1m", "5m", "15m", "1h", "4h", "1d")
                    },
                    rules = signalRules,
                    onRulesChange = { signalRules = it },
                    matchCount = if (signalRules.isEmpty()) null else displayedRows.size,
                )
            }

            item("filter") {
                ResultFilterToggle(
                    selected = resultFilter,
                    flaggedCount = eliminatedCount,
                    onSelect = { resultFilter = it },
                )
            }

            // ── ★ İZLEME lens: only SettingsStore favorites (client-side) ──
            // ── 收藏品种区域（始终可见，方便查看与跳转）────────────────
            item("favstrip") {
                FavoritesStrip(
                    favorites = settings.favorites,
                    survivorsBySymbol = remember(state.survivors) {
                        state.survivors.associateBy { it.symbol.uppercase() }
                    },
                    liveTickers = liveTickers,
                    onOpen = onSelectSymbol,
                    onToggleFavorite = { sym ->
                        val cur = container.settingsStore.getSettings()
                        val up = sym.uppercase()
                        val list = cur.favorites.toMutableList()
                        val existing = list.indexOfFirst { it.uppercase() == up }
                        if (existing >= 0) list.removeAt(existing) else list.add(sym)
                        container.settingsStore.updateSettings(cur.copy(favorites = list))
                    },
                )
            }

            item("watch") {
                FilterPill(
                    label = "★ 关注 (${favoriteSet.size})",
                    selected = watchOnly,
                    accent = DiveColors.Yellow,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { watchOnly = !watchOnly },
                )
            }
            if (watchOnly && displayedRows.isEmpty()) {
                item("nowatch") {
                    NoWatchlistCard(hasFavorites = favoriteSet.isNotEmpty())
                }
            }
            if (signalRules.isNotEmpty() && displayedRows.isEmpty() && state.survivors.isNotEmpty() && resultFilter == ResultFilter.ALL) {
                item("nosig") {
                    Text(
                        text = "当前信号组合无匹配结果。可点条件上的 × 删除，或点「清空」。",
                        color = DiveColors.TextMuted,
                        fontSize = 12.sp,
                        fontFamily = DiveFonts.body,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(DiveColors.BgCard)
                            .border(1.dp, DiveColors.Border, RoundedCornerShape(10.dp))
                            .padding(14.dp),
                    )
                }
            }
            if (resultFilter == ResultFilter.ALL && !watchOnly && displayedRows.isEmpty() && !state.scanning && state.lastScanAtMs != null) {
                item("noresults") {
                    val msg = when {
                        state.survivors.isEmpty() && state.crossRanking.isEmpty() && state.eliminated.isEmpty() ->
                            "扫描完成但没有排名数据。请检查：网络线路、缩小宇宙（TOP20）、或查看上方错误提示后重试。"
                        state.survivors.isEmpty() && state.eliminated.isNotEmpty() ->
                            "共识列表为空：结果可能都在「背离剔除」里。可点「背离剔除」查看，或重新扫描。"
                        rankBoard == RankBoard.EARLY ->
                            "启动排行暂无候选。可切回「共识排行」，或放宽信号筛选。"
                        signalRules.isNotEmpty() ->
                            "当前信号筛选无匹配。请清空筛选条件。"
                        else ->
                            "当前没有可显示的结果。可增大「表格行数」或切换排行分页。"
                    }
                    Text(
                        text = msg,
                        color = DiveColors.Warn,
                        fontSize = 12.sp,
                        fontFamily = DiveFonts.body,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(DiveColors.Warn.copy(alpha = 0.10f))
                            .border(1.dp, DiveColors.Warn.copy(alpha = 0.35f), RoundedCornerShape(10.dp))
                            .padding(14.dp),
                    )
                }
            }
            if (rankBoard == RankBoard.EARLY && resultFilter == ResultFilter.ALL && !watchOnly && displayedRows.isEmpty() && state.survivors.isNotEmpty()) {
                item("noearly") {
                    Text(
                        text = "启动排行暂无候选：短周期尚无明确买/卖，或与长周期冲突。可切回「共识排行」。",
                        color = DiveColors.TextMuted,
                        fontSize = 12.sp,
                        fontFamily = DiveFonts.body,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(DiveColors.BgCard)
                            .border(1.dp, DiveColors.Border, RoundedCornerShape(10.dp))
                            .padding(14.dp),
                    )
                }
            }

            // ── Divergence lens explanation (only when there are results; one message when empty) ──
            if (resultFilter == ResultFilter.DIVERGENCE && displayedRows.isNotEmpty()) {
                item("divinfo") { DivergenceLensInfo() }
            }

            if (resultFilter == ResultFilter.DIVERGENCE && displayedRows.isEmpty()) {
                item("nodiv") { NoDivergenceCard(uncheckable = uncheckableCount) }
            } else if (rankBoard == RankBoard.AI_TOP && displayedRows.isEmpty()) {
                item("aitop-empty") {
                    Text(
                        text = if (state.survivors.isEmpty()) {
                            "完成一次扫描后将在此生成最多 10 个有方向机会"
                        } else {
                            "当前没有通过门禁的有方向机会（中性/冲突/低置信已排除）。可切换到「共识排行」查看全部。"
                        },
                        color = DiveColors.TextMuted,
                        fontSize = 12.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(DiveColors.BgCard)
                            .border(1.dp, DiveColors.Border, RoundedCornerShape(10.dp))
                            .padding(14.dp),
                    )
                }
            } else {
                // ── Coin result cards (AI 十佳 uses compact decision cards) ─
                itemsIndexed(
                    items = displayedRows,
                    key = { _, row -> "${rankBoard.name}-${row.symbol}" },
                ) { idx, row ->
                    if (rankBoard == RankBoard.AI_TOP) {
                        AiTopPickCard(
                            row = row,
                            rank = idx + 1,
                            confidence = vm.confidenceFor(row),
                            fromFusion = state.aiTopPicksFromFusion,
                            onAnalyze = { onOpenAnalysis(row.symbol) },
                            onSelect = { onSelectSymbol(row.symbol) },
                        )
                    } else {
                        CoinResultCard(
                            row = row,
                            aiShort = aiSession.shortVerdict?.takeIf { aiSession.symbol.equals(row.symbol, true) },
                            aiRunning = aiSession.running && aiSession.symbol.equals(row.symbol, true),
                            adjustedConfidence = vm.confidenceFor(row),
                            rank = idx + 1,
                            allTfs = state.timeframes,
                            livePrice = liveTickers[row.symbol]?.price,
                            isFavorite = row.symbol.uppercase() in favoriteSet,
                            onToggleFavorite = {
                                val cur = container.settingsStore.getSettings()
                                val up = row.symbol.uppercase()
                                val list = cur.favorites.toMutableList()
                                val i = list.indexOfFirst { it.uppercase() == up }
                                if (i >= 0) list.removeAt(i) else list.add(row.symbol)
                                container.settingsStore.updateSettings(cur.copy(favorites = list))
                            },
                            onAlert = { alertSheetSymbol = row.symbol },
                            onShare = {
                                val payload = ShareVerdictPayload(
                                    symbol = row.symbol,
                                    verdict = row.dominantDir.name,
                                    confidence = vm.confidenceFor(row),
                                    perTf = state.timeframes.map { tf ->
                                        tf to (row.perTf[tf]?.signal?.name ?: "N/A")
                                    },
                                    timestampMs = nowMillis(),
                                )
                                shareVerdictCard(payload)
                            },
                            onSelect = { onSelectSymbol(row.symbol) },
                            onAnalyze = { onOpenAnalysis(row.symbol) },
                            onAiAnalyze = { onAiAnalyze(row.symbol) },
                            onTfClick = { tf ->
                                container.activeTimeframe.value = tf
                                onSelectSymbol(row.symbol)
                            },
                            container = container,
                        )
                    }
                }
                if (rankBoard == RankBoard.AI_TOP && state.aiWatchPicks.isNotEmpty() && state.aiTopPicksFromFusion) {
                    item("ai-watch-header") {
                        Text(
                            text = "观察（未进十佳）· ${state.aiWatchPicks.size}",
                            color = DiveColors.TextMuted,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(top = 8.dp),
                        )
                    }
                    itemsIndexed(
                        items = state.aiWatchPicks,
                        key = { _, row -> "watch-${row.symbol}" },
                    ) { idx, row ->
                        AiTopPickCard(
                            row = row,
                            rank = idx + 1,
                            confidence = vm.confidenceFor(row),
                            fromFusion = true,
                            watchMode = true,
                            onAnalyze = { onOpenAnalysis(row.symbol) },
                            onSelect = { onSelectSymbol(row.symbol) },
                        )
                    }
                }
            }

            }

            // ── Footer with scan time ──────────────────────────────────────
            state.lastScanAtMs?.let {
                item("ts") {
                    Box(modifier = Modifier.fillMaxWidth().padding(top = 6.dp)) {
                        Text(
                            text = "上次扫描：${formatTs(it)}",
                            color = DiveColors.TextDim,
                            fontSize = 11.sp,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
            }
        }

        // Initial empty state — before the user has ever pressed Start
        if (state.survivors.isEmpty() && state.crossRanking.isEmpty() && !state.scanning) {
            item("empty") { EmptyStateCard() }
        }

        state.error?.let { err ->
            item("err") {
                ScanErrorCard(message = err, onRetry = vm::startScan)
            }
        }

        // Bottom spacer so the last card isn't kissed by the bottom nav bar
        item("spacer") { Spacer(modifier = Modifier.height(16.dp)) }
    }
    }

    // ── Quick-add alert sheet (Task 2c) — the SAME authoring sheet the Alarmlar
    //    screen uses; the row's symbol is prefilled, kind defaults to VERDICT.
    alertSheetSymbol?.let { symbol ->
        AlertAddSheet(
            container = container,
            presetSymbol = symbol,
            presetKind = AlertKind.VERDICT,
            onDismiss = { alertSheetSymbol = null },
        )
    }
}

@Composable
private fun ScanDataHealthCard(
    universeSize: Int,
    failedCount: Int,
    failureReasons: Map<String, Int>,
    scanning: Boolean,
    completedCount: Int,
    totalCount: Int,
    lastScanAtMs: Long?,
) {
    val reasonText = failureReasons.entries.sortedByDescending { it.value }.take(3).joinToString(" · ") { (key, count) ->
        val label = when (key) {
            "network_or_api" -> "网络/API"
            "insufficient_history" -> "K线不足"
            "stale_latest_candle" -> "行情过期"
            "unordered_or_duplicate_timestamps" -> "时间戳重复/乱序"
            "non_finite_ohlcv" -> "非有限行情值"
            "invalid_ohlcv_range" -> "OHLCV异常"
            "inconsistent_ohlc" -> "高低价关系异常"
            "invalid_timestamp" -> "时间戳无效"
            else -> "其他校验失败"
        }
        "$label $count"
    }
    Column(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(DiveDims.Radius))
            .background(DiveColors.BgCard).border(1.dp, DiveColors.Border, RoundedCornerShape(DiveDims.Radius))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("数据健康", color = DiveColors.Text, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text(
                text = when {
                    scanning -> "扫描中"
                    lastScanAtMs == null -> "等待首次扫描"
                    failedCount == 0 -> "未发现失败品种"
                    else -> "有失败项需复查"
                },
                color = when { scanning -> DiveColors.Cyan; failedCount > 0 -> DiveColors.Warn; else -> DiveColors.Green },
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("扫描范围 ${universeSize}", color = DiveColors.TextMuted, fontSize = 11.sp)
            Text("失败品种 $failedCount", color = if (failedCount > 0) DiveColors.Warn else DiveColors.TextMuted, fontSize = 11.sp)
            Text("请求进度 ${completedCount.coerceAtMost(totalCount)}/${totalCount}", color = DiveColors.TextMuted, fontSize = 11.sp)
        }
        if (reasonText.isNotBlank()) Text("失败原因：$reasonText", color = DiveColors.TextDim, fontSize = 10.sp)
        if (lastScanAtMs != null) Text("最近完成时间：${formatTs(lastScanAtMs)}", color = DiveColors.TextDim, fontSize = 10.sp)
        Text("健康状态仅反映扫描请求与行情校验情况，不代表信号盈利概率。", color = DiveColors.TextDim, fontSize = 10.sp)
    }
}

private fun buildScannerCsv(
    rows: List<CrossRankingRow>,
    timeframes: List<String>,
    confidenceFor: (CrossRankingRow) -> Int,
): String {
    fun cell(value: String): String = "\"" + value.replace("\"", "\"\"") + "\""
    val headers = listOf("排名", "交易对", "方向", "置信度", "参考价格", "综合得分", "ATR百分比", "支撑位", "压力位", "背离得分", "多周期一致性", "市场状态", "AI融合状态", "AI分数调整", "AI理由") + timeframes
    val out = StringBuilder("\uFEFF")
    out.append(headers.joinToString(",") { cell(it) }).append("\r\n")
    rows.forEachIndexed { index, row ->
        val values = listOf(
            (index + 1).toString(), row.symbol, row.dominantDir.name, confidenceFor(row).toString(),
            row.price.toString(), row.netNss.toString(), row.atrPct?.toString().orEmpty(),
            row.supportPrice?.toString().orEmpty(), row.resistancePrice?.toString().orEmpty(),
            row.divergenceScore.toString(), row.mtfScore.toString(), row.regime,
            row.aiFusionStatus, row.aiRankDelta.toString(), row.aiFusionReason.orEmpty(),
        ) + timeframes.map { tf -> row.perTf[tf]?.signal?.name.orEmpty() }
        out.append(values.joinToString(",") { cell(it) }).append("\r\n")
    }
    return out.toString()
}

// ═════════════════════════════════════════════════════════════════════════
// 1) Scan hero card — primary control surface
// ═════════════════════════════════════════════════════════════════════════
@Composable
private fun ScanHeroCard(
    state: ScannerUiState,
    resultSummary: String,
    onStart: () -> Unit,
    onStop: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(
                brush = Brush.linearGradient(
                    // Theme-aware hero gradient: card base → hover elevation (was a pinned
                    // dark hex that looked wrong on the light Daylight/Paper presets).
                    colors = listOf(
                        DiveColors.BgCard,
                        DiveColors.BgCardHover,
                    ),
                ),
            )
            .border(1.dp, DiveColors.Border, RoundedCornerShape(14.dp))
            .padding(horizontal = 18.dp, vertical = 18.dp),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth(),
        ) {
            // 3px accent strip (cyan) — keeps the brand element
            Box(
                modifier = Modifier
                    .height(28.dp)
                    .width(3.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(DiveColors.Cyan),
            )
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "手动扫描",
                    color = DiveColors.TextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp,
                    fontFamily = DiveFonts.body,
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = heroSubtitle(state, resultSummary),
                    color = DiveColors.Text,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = "Binance USDT-M 合约 · ${state.timeframes.size} 时间框架",
                    color = DiveColors.TextDim,
                    fontSize = 11.sp,
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        // Primary CTA — full-width pill button
        PrimaryCtaButton(
            scanning = state.scanning,
            onStart = onStart,
            onStop = onStop,
        )
    }
}

@Composable
private fun PrimaryCtaButton(scanning: Boolean, onStart: () -> Unit, onStop: () -> Unit) {
    val bg = if (scanning) DiveColors.Red else DiveColors.Accent
    val label = if (scanning) "停止" else "开始扫描"
    val icon = if (scanning) Icons.Rounded.Stop else Icons.Rounded.PlayArrow
    // onPrimary follows the preset (dark presets → near-black text on the bright accent,
    // light presets → white on the deep accent) — was pinned Color.White.
    val onAccent = MaterialTheme.colorScheme.onPrimary
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(bg)
            .semantics {
                role = Role.Button
                contentDescription = label
            }
            .clickable { if (scanning) onStop() else onStart() }
            .padding(vertical = 13.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null, // container carries the label (a11y: no double-read)
            tint = onAccent,
            modifier = Modifier.size(20.dp),
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = label,
            color = onAccent,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp,
        )
    }
}

// ═════════════════════════════════════════════════════════════════════════
// 2) Progress block while scanning
// ═════════════════════════════════════════════════════════════════════════
@Composable
private fun ScanProgressBlock(state: ScannerUiState) {
    val pct = if (state.totalCount > 0) state.completedCount.toFloat() / state.totalCount else 0f
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(DiveDims.Radius))
            .background(DiveColors.BgCard)
            .border(1.dp, DiveColors.Border, RoundedCornerShape(DiveDims.Radius))
            .padding(14.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(DiveColors.Cyan),
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = phaseLabel(state.currentPhase),
                    color = DiveColors.Cyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp,
                    fontFamily = DiveFonts.body,
                )
            }
            Text(
                text = "${state.completedCount}/${state.totalCount}",
                color = DiveColors.Text,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = DiveFonts.body,
            )
        }
        Spacer(Modifier.height(10.dp))
        // Progress bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(DiveColors.BgCardHover),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(pct.coerceIn(0f, 1f))
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(
                        brush = Brush.horizontalGradient(
                            colors = listOf(DiveColors.Cyan, DiveColors.Green),
                        ),
                    ),
            )
        }
        if (state.currentSymbol != null) {
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "实时",
                    color = DiveColors.TextDim,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.sp,
                    fontFamily = DiveFonts.body,
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = state.currentSymbol,
                    color = DiveColors.Text,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = DiveFonts.body,
                )
            }
        }
    }
}

private fun phaseLabel(p: ScanPhase): String = when (p) {
    ScanPhase.UNIVERSE -> "获取市场"
    ScanPhase.PHASE1 -> "阶段1 · 高周期（榜单渐进）"
    ScanPhase.PHASE2 -> "阶段2 · 短周期（榜单渐进）"
    ScanPhase.FINALIZING -> "本地已出 · AI复核"
    // HONESTY: IDLE means no scan is running — saying "SCANNING" was a lie.
    ScanPhase.IDLE -> "就绪"
}

// Coin result card — detailed consensus row (AI 十佳卡见 ScannerAiTopUi.kt)
@Composable
private fun CoinResultCard(
    row: CrossRankingRow,
    adjustedConfidence: Int,
    rank: Int,
    allTfs: List<String>,
    livePrice: Double?,
    isFavorite: Boolean,
    onToggleFavorite: () -> Unit,
    onAlert: () -> Unit,
    onShare: () -> Unit,
    onSelect: () -> Unit,
    onAnalyze: () -> Unit = {},
    onAiAnalyze: () -> Unit = {},
    onTfClick: (String) -> Unit = {},
    container: AppContainer,
    aiShort: String? = null,
    aiRunning: Boolean = false,
) {
    var detailsExpanded by rememberSaveable(row.symbol) { mutableStateOf(false) }
    val isCommonAll = row.countHit == row.totalTfs
    val accentColor = when {
        row.dominantDir.score > 0 -> DiveColors.Green
        row.dominantDir.score < 0 -> DiveColors.Red
        else -> DiveColors.TextMuted
    }
    val cardBg = DiveColors.BgCard
    // Theme-derived celebration borders (were pinned green/yellow hexes that
    // ignored the active preset's up/warn colors).
    val borderColor = when {
        isCommonAll -> DiveColors.Green.copy(alpha = 0.4f)
        row.countHit >= row.totalTfs - 1 -> DiveColors.Yellow.copy(alpha = 0.4f)
        else -> DiveColors.Border
    }
    // Use the same coverage/conflict-adjusted confidence as feed, alerts and evidence.
    // Raw per-TF confidence remains available in the individual timeframe cells.
    // Canonical mapping lives in the ViewModel (public) — the screen's private
    // duplicate was deleted so there is exactly ONE threshold definition.
    val riskLevel = ScannerViewModel.riskFromAgreement(row.countHit, row.totalTfs)
    // Risk-advisor assumptions (target R / fees / slippage) live in SettingsStore.
    val settings by container.settingsStore.settingsState.collectAsStateWithLifecycle()
    val forwardPlanJournal = remember(container.settingsStore) { ForwardPlanJournal(container.settingsStore) }
    val forwardPlanJournalState by forwardPlanJournal.data.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(cardBg)
            .border(1.dp, borderColor, RoundedCornerShape(12.dp)),
    ) {
        // 3px top accent strip — color-coded by signal
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(3.dp)
                .background(accentColor),
        )

        Column(modifier = Modifier.padding(14.dp)) {
            // ── DEFAULT LAYER: rank / symbol / direction / price ──────────
            CoinCardHeader(
                row = row,
                rank = rank,
                isCommonAll = isCommonAll,
                accentColor = accentColor,
                livePrice = livePrice,
                isFavorite = isFavorite,
                onToggleFavorite = onToggleFavorite,
                onAlert = onAlert,
                onShare = onShare,
            )

            Spacer(Modifier.height(8.dp))

            // One-line ranking rationale + AI badge (always visible).
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Text(
                    text = "本地 · 一致 ${row.countHit}/${row.totalTfs} · 置信 $adjustedConfidence%",
                    color = DiveColors.TextMuted,
                    fontSize = 11.sp,
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                )
                if (row.aiFusionStatus != "AI融合关闭" && row.aiFusionStatus.isNotBlank()) {
                    val aiLabel = aiFusionStatusLabel(row)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(aiFusionStatusColor(row).copy(alpha = 0.9f))
                            .padding(horizontal = 6.dp, vertical = 2.dp),
                    ) {
                        Text(aiLabel, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            ConfidenceBlock(
                confidence = adjustedConfidence,
                accentColor = accentColor,
                risk = riskLevel,
            )

            // Local risk plan — always on the primary path (compact by default).
            row.atrPct?.let { atrPct ->
                if (atrPct.isFinite() && atrPct > 0.0 && row.price.isFinite() && row.price > 0.0) {
                    val hasAiPlan = row.aiSuggestedEntry != null && row.aiSuggestedStop != null && row.aiSuggestedTarget != null
                    Spacer(Modifier.height(8.dp))
                    PlanTypeChip(
                        label = if (hasAiPlan) "AI计划" else "本地计划",
                        hint = if (hasAiPlan) "AI分析 · 可进图 · 研究参考" else "引擎计算 · 可进图",
                    )
                    Spacer(Modifier.height(4.dp))
                    if (row.lifecycleStatus in setOf("DIRECTION_REVERSED", "DATA_INVALID", "PRICE_MOVED")) {
                        Text(
                            text = "${row.lifecycleLabel} · ${row.lifecycleNote}",
                            color = DiveColors.Warn,
                            fontSize = 10.sp,
                            lineHeight = 13.sp,
                        )
                        Spacer(Modifier.height(4.dp))
                    }
                    val riskEligibility = com.diveintocrypto.android.domain.scanner.RiskPlanEligibility.evaluate(
                        dominantSignal = row.dominantDir,
                        mtfDirection = row.mtfDirection,
                    )
                    RiskAdvisorBlock(
                        entryPrice = row.price,
                        atrPct = atrPct,
                        supportPrice = row.supportPrice,
                        resistancePrice = row.resistancePrice,
                        marketDataOpenTimeMs = row.marketDataOpenTimeMs,
                        marketDataTimeframeMs = row.marketDataTimeframeMs,
                        direction = riskEligibility.direction?.let {
                            when (it) {
                                com.diveintocrypto.android.domain.scanner.RiskPlanEligibility.Direction.LONG -> com.diveintocrypto.android.domain.scanner.RiskPlanCalculator.Direction.LONG
                                com.diveintocrypto.android.domain.scanner.RiskPlanEligibility.Direction.SHORT -> com.diveintocrypto.android.domain.scanner.RiskPlanCalculator.Direction.SHORT
                            }
                        },
                        blockedByMtfConflict = riskEligibility.status == com.diveintocrypto.android.domain.scanner.RiskPlanEligibility.Status.MTF_CONFLICT,
                        lifecycleStatus = row.lifecycleStatus,
                        eligibilityStatus = riskEligibility.status.name,
                        targetR = settings.riskTargetR,
                        feeSidePct = settings.riskFeeSidePct,
                        slippageSidePct = settings.riskSlippageSidePct,
                        onTargetRChange = { value ->
                            val current = container.settingsStore.getSettings()
                            container.settingsStore.updateSettings(current.copy(riskTargetR = value.coerceIn(0.5, 5.0)))
                        },
                        onFeeSidePctChange = { value ->
                            val current = container.settingsStore.getSettings()
                            container.settingsStore.updateSettings(current.copy(riskFeeSidePct = value.coerceIn(0.0, 1.0)))
                        },
                        onSlippageSidePctChange = { value ->
                            val current = container.settingsStore.getSettings()
                            container.settingsStore.updateSettings(current.copy(riskSlippageSidePct = value.coerceIn(0.0, 2.0)))
                        },
                        aiOverrideEntry = row.aiSuggestedEntry,
                        aiOverrideStop = row.aiSuggestedStop,
                        aiOverrideTarget = row.aiSuggestedTarget,
                        planSourceLabel = if (hasAiPlan) "AI计划" else "本地计划",
                    )
                }
            }

            if (aiRunning) {
                Spacer(Modifier.height(6.dp))
                Text("AI 分析中…", color = DiveColors.Accent, fontSize = 11.sp)
            } else if (!aiShort.isNullOrBlank()) {
                Spacer(Modifier.height(6.dp))
                Text("AI 研判：$aiShort", color = DiveColors.TextMuted, fontSize = 11.sp, maxLines = 2)
            }

            Spacer(Modifier.height(10.dp))
            CoinCardFooterCta(onSelect = onSelect, onAnalyze = onAnalyze, onAiAnalyze = onAiAnalyze)

            // ── EXPANDED LAYER: evidence / TF grid / AI audit ─────────────
            TextButton(
                onClick = { detailsExpanded = !detailsExpanded },
                contentPadding = PaddingValues(horizontal = 0.dp, vertical = 0.dp),
            ) {
                Text(
                    if (detailsExpanded) "收起证据与周期 ▴" else "展开证据 · 多周期 · AI 详情 ▾",
                    color = DiveColors.Accent,
                    fontSize = 12.sp,
                )
            }

            if (detailsExpanded) {
                Spacer(Modifier.height(6.dp))
                OverlayTagRow(row = row)
                Spacer(Modifier.height(6.dp))
                StageChip(stage = signalStageOf(row))
                Spacer(Modifier.height(10.dp))
                ScoreBlock(netNss = row.netNss, countHit = row.countHit, totalTfs = row.totalTfs)

                if (abs(row.divergenceScore) >= ScannerViewModel.DIVERGENCE_MIN_SHOWN) {
                    Spacer(Modifier.height(8.dp))
                    WhaleDivergenceBlock(
                        score = row.divergenceScore,
                        tf = row.divergenceTf,
                        risePct = row.divergenceRisePct,
                        whaleDrop = row.divergenceWhaleDrop,
                        patternDirection = row.divergencePatternDirection,
                    )
                }

                Spacer(Modifier.height(8.dp))
                AccumulationEvidenceBlock(
                    alignment = row.accumulationSummary.alignment.name,
                    usable = row.accumulationSummary.usableTimeframes,
                    accumulation = row.accumulationSummary.accumulationTimeframes,
                    distribution = row.accumulationSummary.distributionTimeframes,
                    mixed = row.accumulationSummary.mixedTimeframes,
                    score = row.accumulationSummary.averageEvidenceScore,
                    explanation = row.accumulationSummary.explanation,
                )

                if (row.aiFusionStatus != "AI融合关闭") {
                    Spacer(Modifier.height(8.dp))
                    PlanTypeChip(label = "AI 参考", hint = "不覆盖本地 · 不下单")
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "${aiFusionStatusLabel(row)} · 分数偏移 ${if (row.aiRankDelta >= 0) "+" else ""}${row.aiRankDelta}",
                        color = aiFusionStatusColor(row),
                        fontSize = 11.sp,
                        lineHeight = 14.sp,
                    )
                    if (row.aiDirectionChanged) {
                        Text(
                            text = "方向已由 ${row.localDirectionBeforeAi?.name ?: "本地信号"} 改为当前方向（高级融合）",
                            color = DiveColors.Accent,
                            fontSize = 10.sp,
                            lineHeight = 13.sp,
                        )
                    }
                    row.aiFusionReason?.takeIf { it.isNotBlank() }?.let {
                        Text(it, color = DiveColors.TextMuted, fontSize = 10.sp, lineHeight = 13.sp)
                    }
                    row.aiFusionThesis?.takeIf { it.isNotBlank() }?.let {
                        Text("AI 研判：$it", color = DiveColors.TextMuted, fontSize = 10.sp, lineHeight = 13.sp)
                    }
                    if (row.aiPlanAccepted && row.aiSuggestedEntry != null && row.aiSuggestedStop != null && row.aiSuggestedTarget != null) {
                        Text(
                            "AI 参考价：入场 ${row.aiSuggestedEntry} · 止损 ${row.aiSuggestedStop} · 止盈 ${row.aiSuggestedTarget}${row.aiSuggestedTimeframe?.let { " · $it" } ?: ""}",
                            color = DiveColors.TextMuted,
                            fontSize = 10.sp,
                            lineHeight = 13.sp,
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))
                Text("多周期信号", color = DiveColors.TextMuted, fontSize = 11.sp)
                Spacer(Modifier.height(6.dp))
                TfGrid(perTf = row.perTf, allTfs = allTfs, onTfClick = onTfClick)
            }
        }
    }
}


@Composable
private fun PlanTypeChip(label: String, hint: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(DiveColors.Accent.copy(alpha = 0.15f))
                .padding(horizontal = 6.dp, vertical = 2.dp),
        ) {
            Text(label, color = DiveColors.Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        Text(hint, color = DiveColors.TextDim, fontSize = 10.sp)
    }
}

/**
 * Tiny strategy-overlay tags for a CoinResultCard, straight from the CrossRankingRow
 * annotation fields (lane A). Regime label, MTF gate ✓/– and — only when actually
 * computed — the microstructure state. Nothing here is invented: no micro annotation
 * → no micro tag.
 */
@Composable
private fun OverlayTagRow(row: CrossRankingRow) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        TinyTag(
            text = row.regime,
            color = when (row.regime) {
                "TREND" -> DiveColors.Cyan
                "RANGE" -> DiveColors.Purple
                else -> DiveColors.TextMuted
            },
        )
        TinyTag(
            text = if (row.mtfGate) "MTF ✓" else "MTF –",
            color = if (row.mtfGate) DiveColors.Green else DiveColors.TextDim,
        )
        row.microLabel?.let { label ->
            val dir = row.microDirection
            val arrow = when {
                dir != null && dir > 0 -> "▲"
                dir != null && dir < 0 -> "▼"
                else -> "·"
            }
            val microText = if (row.microScore == null) {
                "MICRO ${microShortLabel(label)}"
            } else {
                val coverage = row.microCoveragePercent?.let { "$it% " } ?: ""
                "MICRO $coverage$arrow ${microShortLabel(label)}"
            }
            TinyTag(
                text = microText,
                color = when {
                    dir != null && dir > 0 -> DiveColors.Green
                    dir != null && dir < 0 -> DiveColors.Red
                    else -> DiveColors.TextMuted
                },
            )
        }
    }
}

/** Compact STRONG_BUY→S.BUY style shortening so the tag stays one-liner on 360dp. */
private fun microShortLabel(label: String?): String = when (label) {
    null -> "—"
    "STRONG_BUY" -> "强买"
    "STRONG_SELL" -> "强卖"
    "NEUTRAL" -> "中性"
    "INSUFFICIENT_DATA" -> "数据不足"
    "OFF" -> "未启用"
    else -> label
}

@Composable
private fun TinyTag(text: String, color: Color) {
    Text(
        text = text,
        color = color,
        fontSize = 10.sp,
        fontWeight = FontWeight.Bold,
        fontFamily = DiveFonts.body,
        letterSpacing = 0.3.sp,
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(color.copy(alpha = 0.12f))
            .border(1.dp, color.copy(alpha = 0.35f), RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp),
    )
}

/**
 * Whale L/S divergence alert block. This is a price-vs-top-trader-long/short-ratio
 * divergence proxy, not proof of real-world whale accumulation/distribution.
 * The signed score is a model ranking contribution, NOT probability or confidence.
 */
@Composable
private fun AccumulationEvidenceBlock(
    alignment: String,
    usable: Int,
    accumulation: Int,
    distribution: Int,
    mixed: Int,
    score: Int?,
    explanation: String,
) {
    val insufficient = alignment == "INSUFFICIENT_DATA"
    val bullish = alignment == "BULLISH_SIGNS_ALIGNED"
    val bearish = alignment == "BEARISH_SIGNS_ALIGNED"
    val color = when {
        insufficient -> DiveColors.TextMuted
        bullish -> DiveColors.Green
        bearish -> DiveColors.Red
        else -> DiveColors.Warn
    }
    val title = when {
        insufficient -> "吸筹/派发证据不足"
        bullish -> "多周期吸筹迹象一致"
        bearish -> "多周期派发迹象一致"
        else -> "吸筹/派发周期证据冲突"
    }
    Column(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.08f))
            .border(1.dp, color.copy(alpha = 0.30f), RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp),
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = DiveFonts.body)
            Text(score?.let { "证据分 $it/100" } ?: "待补数据", color = color, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
        }
        Text("有效周期 $usable · 吸筹 $accumulation · 派发 $distribution · 混合 $mixed", color = DiveColors.TextMuted, fontSize = 10.sp)
        Text(explanation, color = DiveColors.TextMuted, fontSize = 10.sp, lineHeight = 14.sp)
        Text("依据 OHLCV 代理指标，不代表真实主力行为或盈利概率；需结合价格结构确认。", color = DiveColors.TextMuted, fontSize = 9.sp, lineHeight = 12.sp)
    }
}

@Composable
private fun WhaleDivergenceBlock(
    score: Double,
    tf: String?,
    risePct: Double,
    whaleDrop: Double,
    patternDirection: Int,
) {
    val isNeutral = patternDirection == 0
    val isDistribution = patternDirection < 0
    val color = when {
        isNeutral -> DiveColors.TextMuted
        isDistribution -> DiveColors.Red
        else -> DiveColors.Green
    }
    val arrow = when {
        isNeutral -> "•"
        isDistribution -> "▼"
        else -> "▲"
    }
    val title = when {
        isNeutral -> "背离方向不明确"
        isDistribution -> "派发迹象"
        else -> "吸筹迹象"
    }
    val priceSign = if (isDistribution) "+" else "−"
    val whaleSign = if (isDistribution) "−" else "+"
    val scoreSign = if (score >= 0.0) "+" else "−"
    val interpretation = when {
        isNeutral -> "方向未确认：不要据此单独开仓"
        isDistribution -> "价格上涨而大户多空比下降；历史排名分偏反向，不等于必涨"
        else -> "价格下跌而大户多空比上升；历史排名分偏反向，不等于必跌"
    }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.10f))
            .border(1.dp, color.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                text = "$arrow  $title" + (tf?.let { " · $it" } ?: ""),
                color = color,
                fontSize = 11.sp,
                fontWeight = FontWeight.Black,
                fontFamily = DiveFonts.body,
            )
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "$scoreSign${abs(score).format(0)}",
                    color = color,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = DiveFonts.body,
                )
                Text("排名分 · 非概率", color = DiveColors.TextMuted, fontSize = 9.sp, fontFamily = DiveFonts.body)
            }
        }
        Text(
            text = "价格 $priceSign${(abs(risePct) * 100).format(1)}% · 大户多空比 $whaleSign${(abs(whaleDrop) * 100).format(1)}%",
            color = DiveColors.TextMuted,
            fontSize = 10.sp,
            fontFamily = DiveFonts.body,
        )
        Text(
            text = interpretation,
            color = DiveColors.TextMuted,
            fontSize = 10.sp,
            fontFamily = DiveFonts.body,
            lineHeight = 14.sp,
        )
        Text(
            text = "判定依据：价格与大户多空比方向相反；该指标是代理信号，不能证明真实资金正在吸筹/派发。",
            color = DiveColors.TextMuted,
            fontSize = 9.sp,
            fontFamily = DiveFonts.body,
            lineHeight = 13.sp,
        )
    }
}

/**
 * RISK ADVISOR — INFORMATIONAL only, NOT investment advice.
 *
 * Displays the shared domain risk-plan calculation as informational reference levels.
 * ATR is converted from percentage points to quote-price units; the shared calculator
 * derives direction-aware entry/stop/target prices. This is not a backtest guarantee and
 * estimates fees and slippage for net R:R display, but excludes funding, leverage and liquidation mechanics. It never places orders.
 */

@Composable
private fun CoinCardHeader(
    row: CrossRankingRow,
    rank: Int,
    isCommonAll: Boolean,
    accentColor: Color,
    livePrice: Double?,
    isFavorite: Boolean,
    onToggleFavorite: () -> Unit,
    onAlert: () -> Unit,
    onShare: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // Rank chip — always visible so the user can read "#1, #2, …" at a glance.
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(DiveColors.BgCardHover)
                .border(1.dp, DiveColors.Border, RoundedCornerShape(6.dp))
                .padding(horizontal = 6.dp, vertical = 3.dp),
        ) {
            Text(
                text = "#$rank",
                color = DiveColors.TextMuted,
                fontSize = 12.sp,
                fontWeight = FontWeight.Black,
                fontFamily = DiveFonts.body,
            )
        }
        Spacer(Modifier.width(8.dp))
        if (isCommonAll) {
            Text(
                "★",
                color = DiveColors.Green,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
            )
            Spacer(Modifier.width(4.dp))
        }
        Text(
            text = row.symbol,
            color = DiveColors.Text,
            fontSize = 17.sp,
            fontWeight = FontWeight.Black,
            fontFamily = DiveFonts.body,
            letterSpacing = 0.3.sp,
        )
        Spacer(Modifier.width(8.dp))
        // Signal pill
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(accentColor.copy(alpha = 0.15f))
                .border(1.dp, accentColor.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                .padding(horizontal = 8.dp, vertical = 3.dp),
        ) {
            Text(
                text = row.dominantDir.name,
                color = accentColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = DiveFonts.body,
                letterSpacing = 0.5.sp,
            )
        }
        Spacer(modifier = Modifier.weight(1f))
        // Quick-add alert affordance (Task 2c) — opens the shared KURAL EKLE sheet.
                // ★ 收藏切换
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(if (isFavorite) DiveColors.Yellow.copy(alpha = 0.18f) else DiveColors.BgCardHover)
                .border(1.dp, if (isFavorite) DiveColors.Yellow.copy(alpha = 0.5f) else DiveColors.Border, RoundedCornerShape(6.dp))
                .semantics {
                    role = Role.Button
                    contentDescription = if (isFavorite) "取消收藏 ${row.symbol}" else "收藏 ${row.symbol}"
                }
                .clickable(onClick = onToggleFavorite)
                .padding(horizontal = 6.dp, vertical = 4.dp),
        ) {
            Text(
                text = if (isFavorite) "★" else "☆",
                color = if (isFavorite) DiveColors.Yellow else DiveColors.TextMuted,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
            )
        }
        Spacer(Modifier.width(6.dp))
Box(
            modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(DiveColors.BgCardHover)
                .border(1.dp, DiveColors.Border, RoundedCornerShape(6.dp))
                .semantics {
                    role = Role.Button
                    contentDescription = "为 ${row.symbol} 添加警报"
                }
                .clickable(onClick = onAlert)
                .padding(horizontal = 6.dp, vertical = 4.dp),
        ) {
            Icon(
                imageVector = Icons.Rounded.AddAlert,
                contentDescription = null, // container carries the a11y label
                tint = DiveColors.Warn,
                modifier = Modifier.size(16.dp),
            )
        }
        Spacer(Modifier.width(6.dp))
        // PAYLAŞ — verdict share-card PNG via the system share sheet.
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(DiveColors.BgCardHover)
                .border(1.dp, DiveColors.Border, RoundedCornerShape(6.dp))
                .semantics {
                    role = Role.Button
                    contentDescription = "分享 ${row.symbol} 裁决卡片"
                }
                .clickable(onClick = onShare)
                .padding(horizontal = 6.dp, vertical = 4.dp),
        ) {
            Icon(
                imageVector = Icons.Rounded.Share,
                contentDescription = null, // container carries the a11y label
                tint = DiveColors.Accent,
                modifier = Modifier.size(16.dp),
            )
        }
        Spacer(Modifier.width(8.dp))
        LivePriceCell(symbol = row.symbol, rowPrice = row.price, livePrice = livePrice)
    }
}

/**
 * Live-price cell (Task 4) — overlays the watchlist engine's real-time price on
 * the scan-time price and flashes a brief tint on every change (300ms
 * animateColorAsState, subtle by design). No ticker yet → the scan price stays.
 */
@Composable
private fun LivePriceCell(symbol: String, rowPrice: Double, livePrice: Double?) {
    val price = livePrice ?: rowPrice
    var displayed by remember(symbol) { mutableStateOf(price) }
    var flash by remember(symbol) { mutableStateOf(0) } // +1 up · −1 down · 0 none
    LaunchedEffect(price) {
        if (price != displayed) {
            flash = if (price > displayed) 1 else -1
            displayed = price
        }
        if (flash != 0) {
            delay(300)
            flash = 0
        }
    }
    val flashColor by animateColorAsState(
        targetValue = when {
            flash > 0 -> DiveColors.GreenTint25
            flash < 0 -> DiveColors.RedTint25
            else -> Color.Transparent
        },
        animationSpec = tween(durationMillis = 300),
        label = "priceFlash",
    )
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(flashColor)
            .padding(horizontal = 4.dp, vertical = 1.dp),
    ) {
        Text(
            text = "${'$'}${displayed.format(2, grouped = true)}",
            color = DiveColors.Text,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = DiveFonts.body,
        )
    }
}

/**
 * TARAMA EVRENİ status row (Task 3 — HONEST READ-ONLY). ScannerViewModel exposes
 * NO public universe setter, so the UI renders the CURRENT mode (what the next
 * scan will use, read from the persisted SettingsStore) plus the rolling ETA —
 * never a fabricated countdown. Changing the mode requires a VM setter (noted in
 * the campaign report); this row is intentionally not clickable.
 */
@Composable
private fun UniverseInfoRow(
    universeMode: String,
    universeSize: Int,
    etaSeconds: Long?,
    onSelectMode: (String) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(DiveDims.Radius))
            .background(DiveColors.BgCard)
            .border(1.dp, DiveColors.Border, RoundedCornerShape(DiveDims.Radius))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "扫描范围",
                color = DiveColors.TextMuted,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp,
                fontFamily = DiveFonts.body,
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = AlertLabels.universeLabel(universeMode) +
                    if (universeSize > 0) " · $universeSize sembol" else "",
                color = DiveColors.Accent,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = DiveFonts.body,
            )
            Spacer(Modifier.weight(1f))
            Text(
                text = "ETA ${AlertLabels.etaLabel(etaSeconds)}",
                color = DiveColors.TextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = DiveFonts.body,
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("TOP20", "TOP50", "TOP100", "TOP250", "ALL").forEach { mode ->
                FilterPill(
                    label = AlertLabels.universeLabel(mode),
                    selected = universeMode == mode,
                    accent = DiveColors.Accent,
                    onClick = { if (universeMode != mode) onSelectMode(mode) },
                )
            }
        }
        if (AlertLabels.isFullUniverse(universeMode)) {
            Text(
                text = "⚠ 约500个交易对 · 需数分钟 · 下次扫描生效",
                color = DiveColors.Warn,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = DiveFonts.body,
            )
        }
    }
}


/**
 * 收藏品种条：始终展示收藏列表，可点开面板、可取消收藏。
 * 若刚扫过，会附带该币在本轮结果中的方向与置信度摘要。
 */
@Composable
private fun FavoritesStrip(
    favorites: List<String>,
    survivorsBySymbol: Map<String, CrossRankingRow>,
    liveTickers: Map<String, com.diveintocrypto.android.engine.LiveTickerEngine.LiveTicker>,
    onOpen: (String) -> Unit,
    onToggleFavorite: (String) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(DiveColors.BgCard)
            .border(1.dp, DiveColors.Border, RoundedCornerShape(12.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "收藏品种",
                color = DiveColors.Text,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = DiveFonts.body,
            )
            Spacer(Modifier.width(6.dp))
            Text(
                text = "${favorites.size}",
                color = DiveColors.Yellow,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
            )
            Spacer(Modifier.weight(1f))
            Text(
                text = "点卡片进面板 · 再点星取消",
                color = DiveColors.TextDim,
                fontSize = 10.sp,
            )
        }
        if (favorites.isEmpty()) {
            Text(
                text = "暂无收藏。在扫描结果卡片点 ☆ 即可加入，方便盯盘。",
                color = DiveColors.TextMuted,
                fontSize = 12.sp,
                fontFamily = DiveFonts.body,
            )
        } else {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                favorites.forEach { sym ->
                    val up = sym.uppercase()
                    val row = survivorsBySymbol[up]
                    val live = liveTickers[sym]?.price ?: liveTickers[up]?.price
                    val dir = row?.dominantDir?.name
                    val dirColor = when {
                        row == null -> DiveColors.TextMuted
                        row.dominantDir.score > 0 -> DiveColors.Green
                        row.dominantDir.score < 0 -> DiveColors.Red
                        else -> DiveColors.TextMuted
                    }
                    Column(
                        modifier = Modifier
                            .width(118.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(DiveColors.BgCardHover)
                            .border(1.dp, DiveColors.Border, RoundedCornerShape(10.dp))
                            .clickable { onOpen(sym) }
                            .padding(10.dp),
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = sym.removeSuffix("USDT").ifEmpty { sym },
                                color = DiveColors.Text,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = DiveFonts.body,
                                maxLines = 1,
                            )
                            Spacer(Modifier.weight(1f))
                            Text(
                                text = "★",
                                color = DiveColors.Yellow,
                                fontSize = 14.sp,
                                modifier = Modifier.clickable { onToggleFavorite(sym) },
                            )
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = live?.let { "$${it.format(2, grouped = true)}" }
                                ?: row?.price?.let { "$${it.format(2, grouped = true)}" }
                                ?: "—",
                            color = DiveColors.TextMuted,
                            fontSize = 11.sp,
                            fontFamily = DiveFonts.body,
                        )
                        if (dir != null) {
                            Spacer(Modifier.height(2.dp))
                            Text(
                                text = dir,
                                color = dirColor,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                            )
                        } else {
                            Spacer(Modifier.height(2.dp))
                            Text(
                                text = "未在本轮结果",
                                color = DiveColors.TextDim,
                                fontSize = 10.sp,
                            )
                        }
                    }
                }
            }
        }
    }
}

/** Honest empty state for the ★ İZLEME lens. */
@Composable
private fun NoWatchlistCard(hasFavorites: Boolean) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(DiveColors.BgCard)
            .border(1.dp, DiveColors.Border, RoundedCornerShape(12.dp))
            .padding(20.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = if (hasFavorites) "★ 关注列表在本次扫描中无结果。"
            else "★ 关注列表为空 — 在结果卡片点 ☆ 收藏，或在上方收藏区管理。",
            color = DiveColors.TextMuted,
            fontSize = 13.sp,
            fontFamily = DiveFonts.body,
        )
    }
}

@Composable
private fun ConfidenceBlock(confidence: Int, accentColor: Color, risk: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = "置信度",
            color = DiveColors.TextMuted,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            fontFamily = DiveFonts.body,
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = "$confidence%",
            color = DiveColors.Text,
            fontSize = 16.sp,
            fontWeight = FontWeight.Black,
            fontFamily = DiveFonts.body,
        )
        Spacer(Modifier.width(10.dp))
        // Progress fill
        Box(
            modifier = Modifier
                .weight(1f)
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(DiveColors.BgCardHover),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(confidence / 100f)
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(accentColor),
            )
        }
        Spacer(Modifier.width(10.dp))
        RiskChip(risk = risk)
    }
}

/**
 * SCORE block — surfaces the time-weighted net NSS that actually drives the
 * cross-rank sort. Previously hidden inside `row.netNss` and miscast as
 * "confidence" → the user could not see WHY one coin outranked another.
 *
 *   `net_nss = Σ final_score (dominant side) − Σ final_score (opposite side)`
 *   `final_score = confidence² × timeWeight / 100`
 *
 * The full integer score is shown alongside its "K-format" abbreviation; both
 * are nice on the eye but the integer is the canonical value.
 */
@Composable
private fun ScoreBlock(netNss: Double, countHit: Int, totalTfs: Int) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = "得分",
            color = DiveColors.TextMuted,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            fontFamily = DiveFonts.body,
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = formatScore(netNss),
            color = DiveColors.Yellow,
            fontSize = 16.sp,
            fontWeight = FontWeight.Black,
            fontFamily = DiveFonts.body,
        )
        Spacer(Modifier.width(6.dp))
        Text(
            text = "(${netNss.toInt()})",
            color = DiveColors.TextDim,
            fontSize = 11.sp,
            fontFamily = DiveFonts.body,
        )
        Spacer(modifier = Modifier.weight(1f))
        // Agreement chip — moved out of the footer so the user can see it
        // alongside the score that depends on it.
        // Theme-derived tints (were pinned green/yellow alpha hexes).
        val (chipBg, chipFg) = when {
            countHit >= 3 -> DiveColors.GreenTint15 to DiveColors.Green
            countHit == 2 -> DiveColors.YellowTint15 to DiveColors.Yellow
            else -> DiveColors.BgCardHover to DiveColors.TextMuted
        }
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .background(chipBg)
                .padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "$countHit/$totalTfs",
                color = chipFg,
                fontSize = 12.sp,
                fontWeight = FontWeight.Black,
                fontFamily = DiveFonts.body,
            )
            Spacer(Modifier.width(4.dp))
            Text(
                text = "TF一致",
                color = chipFg,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 0.5.sp,
                fontFamily = DiveFonts.body,
            )
        }
    }
}

@Composable
private fun RiskChip(risk: String) {
    val (bg, fg) = when (risk.uppercase()) {
        "LOW" -> DiveColors.GreenTint15 to DiveColors.Green
        "MEDIUM" -> DiveColors.YellowTint15 to DiveColors.Yellow
        "HIGH" -> DiveColors.RedTint15 to DiveColors.Red
        else -> DiveColors.NeutralTint15 to DiveColors.TextDim
    }
    Text(
        text = risk.uppercase(),
        color = fg,
        fontSize = 10.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 0.5.sp,
        fontFamily = DiveFonts.body,
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(bg)
            .padding(horizontal = 8.dp, vertical = 4.dp),
    )
}

// 4×3 grid of TF cells — ALL 12 timeframes visible, no horizontal scroll.
// Cell = TF label + confidence%, tinted by signal direction.
@Composable
private fun TfGrid(
    perTf: Map<String, TfSlotState>,
    allTfs: List<String>,
    onTfClick: (String) -> Unit = {},
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "全部 ${allTfs.size} 时间框架",
            color = DiveColors.TextMuted,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.2.sp,
            fontFamily = DiveFonts.body,
        )
        Spacer(Modifier.height(8.dp))
        // 3 rows × 4 columns = 12 cells
        val rows = allTfs.chunked(4)
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            rows.forEach { rowTfs ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    rowTfs.forEach { tf ->
                        TfCell(tf = tf, slot = perTf[tf], modifier = Modifier.weight(1f), onClick = { onTfClick(tf) })
                    }
                    // Fill remaining columns if last row is short
                    repeat(4 - rowTfs.size) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
private fun TfCell(
    tf: String,
    slot: TfSlotState?,
    modifier: Modifier = Modifier,
    onClick: () -> Unit = {},
) {
    val (bg, fg, borderColor) = when {
        slot == null -> Triple(DiveColors.BgCardHover, DiveColors.TextDim, DiveColors.Border)
        slot.signal.score > 0 -> Triple(DiveColors.GreenTint15, DiveColors.Green, DiveColors.GreenTint25)
        slot.signal.score < 0 -> Triple(DiveColors.RedTint15, DiveColors.Red, DiveColors.RedTint25)
        else -> Triple(DiveColors.NeutralTint15, DiveColors.TextMuted, DiveColors.Border)
    }
    val signalText = when {
        slot == null -> "—"
        slot.signal.score > 0 -> "买"
        slot.signal.score < 0 -> "卖"
        else -> "中"
    }
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bg)
            .border(1.dp, borderColor, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = tf,
            color = fg,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = DiveFonts.body,
        )
        Spacer(Modifier.height(2.dp))
        Text(
            text = signalText,
            color = fg,
            fontSize = 11.sp,
            fontWeight = FontWeight.Black,
            fontFamily = DiveFonts.body,
        )
        Text(
            text = if (slot != null) "${slot.confidence}%" else "",
            color = if (slot != null) fg.copy(alpha = 0.85f) else DiveColors.TextDim,
            fontSize = 9.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = DiveFonts.body,
        )
    }
}

/**
 * Footer with just the Select CTA — the agreement chip has migrated into the
 * `ScoreBlock` row so that SCORE and `N/12 TF AGREE` sit side-by-side (the user
 * needs both to judge the score's quality).
 */
@Composable
private fun CoinCardFooterCta(onSelect: () -> Unit, onAnalyze: () -> Unit = {}, onAiAnalyze: () -> Unit = {}) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Spacer(modifier = Modifier.weight(1f))
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .border(1.dp, DiveColors.Accent, RoundedCornerShape(8.dp))
                .clickable(onClick = onAiAnalyze)
                .semantics { role = Role.Button }
                .padding(horizontal = 12.dp, vertical = 9.dp),
        ) {
            Text(
                text = "AI",
                color = DiveColors.Accent,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.8.sp,
            )
        }
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .border(1.dp, DiveColors.Accent, RoundedCornerShape(8.dp))
                .clickable(onClick = onAnalyze)
                .semantics { role = Role.Button }
                .padding(horizontal = 14.dp, vertical = 9.dp),
        ) {
            Text(
                text = "分析",
                color = DiveColors.Accent,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.8.sp,
            )
        }
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(DiveColors.Accent)
                .clickable(onClick = onSelect)
                .semantics { role = Role.Button }
                .padding(horizontal = 18.dp, vertical = 9.dp),
        ) {
            Text(
                text = "选择 →",
                color = MaterialTheme.colorScheme.onPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.8.sp,
            )
        }
    }
}

// ═════════════════════════════════════════════════════════════════════════
// Empty state — invites the user to start
// ═════════════════════════════════════════════════════════════════════════
@Composable
private fun EmptyStateCard() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(DiveColors.BgCard)
            .border(1.dp, DiveColors.Border, RoundedCornerShape(12.dp))
            .padding(horizontal = 16.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("🔎", fontSize = 32.sp)
        Spacer(Modifier.height(10.dp))
        Text(
            text = "尚未扫描",
            color = DiveColors.Text,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = "点击上方「开始扫描」按钮",
            color = DiveColors.TextMuted,
            fontSize = 12.sp,
        )
    }
}

/**
 * Scan error card with an explicit "TEKRAR DENE" retry — wired to the SAME public
 * VM entry the pull-to-refresh gesture uses ([ScannerViewModel.startScan]).
 */
@Composable
private fun ScanErrorCard(message: String, onRetry: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(DiveDims.Radius))
            .background(DiveColors.RedTint15)
            .border(1.dp, DiveColors.RedTint25, RoundedCornerShape(DiveDims.Radius))
            .padding(12.dp),
    ) {
        Text("错误：$message", color = DiveColors.Red, fontSize = 13.sp)
        Spacer(Modifier.height(10.dp))
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(DiveDims.RadiusSm))
                .background(DiveColors.Red)
                .clickable(onClick = onRetry)
                .semantics { role = Role.Button }
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = com.diveintocrypto.android.ui.i18n.LocalDiveStrings.current.btnRetry,
                color = MaterialTheme.colorScheme.onPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.6.sp,
                fontFamily = DiveFonts.body,
            )
        }
    }
}

/** Amber partial-result note: "N 个交易对未扫描 — 部分结果" with a dismiss affordance. */
@Composable
private fun FailedScanNote(count: Int, onDismiss: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(DiveDims.Radius))
            .background(DiveColors.Warn.copy(alpha = 0.10f))
            .border(1.dp, DiveColors.Warn.copy(alpha = 0.35f), RoundedCornerShape(DiveDims.Radius))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = "⚠ $count 个交易对未扫描 — 部分结果",
            color = DiveColors.Warn,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = DiveFonts.body,
            modifier = Modifier.weight(1f),
        )
        Text(
            text = "×",
            color = DiveColors.Warn,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .clickable(onClick = onDismiss)
                .semantics {
                    role = Role.Button
                    contentDescription = "关闭部分结果提示"
                }
                .padding(horizontal = 8.dp, vertical = 2.dp),
        )
    }
}

// ─────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────
private fun formatTs(ms: Long): String {
    return formatTime(ms, "dd.MM.yyyy HH:mm:ss")
}

/**
 * Risk mapping note: the screen previously carried a PRIVATE duplicate of the
 * ViewModel's `riskFromAgreement` (and referenced the long-deleted `riskFromCount`).
 * The duplicate is gone — `ScannerViewModel.riskFromAgreement` is the single
 * canonical definition (≥ total-1 → LOW · ≥ total/2 → MEDIUM · > 0 → HIGH · else N/A).
 */

/**
 * Format the cross-rank net NSS for compact display. The raw integer is huge
 * (often 1k-30k after summing final_score across TFs), so we render a K-suffix
 * abbreviation in the SCORE headline and keep the raw int in parentheses so
 * detail-oriented users can still see the canonical value.
 */
private fun formatScore(s: Double): String = when {
    s >= 10000 -> "${(s / 1000).format(1)}K"
    s >= 1000 -> "${(s / 1000).format(2)}K"
    else -> s.toInt().toString()
}

private fun heroSubtitle(state: ScannerUiState, resultSummary: String): String = when (state.currentPhase) {
    ScanPhase.UNIVERSE -> "正在获取交易对列表…"
    ScanPhase.PHASE1 ->
        "阶段1 · 扫描 1d/12h/8h"
    ScanPhase.PHASE2 ->
        "阶段2 · 剩余 9 个时间框架"
    ScanPhase.FINALIZING -> {
        val n = state.survivors.size
        if (n > 0) "交叉排名中 · 已出 $n 条（可先浏览）" else "正在交叉排名…"
    }
    ScanPhase.IDLE -> when {
        state.universeLoading -> "正在获取交易对列表…"
        state.survivors.isNotEmpty() || state.crossRanking.isNotEmpty() || state.hotList.isNotEmpty() ->
            resultSummary // lens-aware (All/Divergence)
        else -> "全部 Binance USDT-M · 12 时间框架"
    }
}

/** Show only this many highest-confidence cards after a scan completes. */
/** Scanner result lens. */


/** 单条周期信号条件；多条之间为 AND。 */
private data class SignalFilterRule(
    val tf: String,
    val want: SignalWant,
)

private enum class SignalWant(val label: String) {
    BUY("买入"),
    SELL("卖出"),
    NEUTRAL("中性"),
    NON_NEUTRAL("非中性"),
}

private fun matchesSignalRules(row: CrossRankingRow, rules: List<SignalFilterRule>): Boolean {
    if (rules.isEmpty()) return true
    return rules.all { rule ->
        val slot = row.perTf[rule.tf] ?: return@all false
        val s = slot.signal.score
        when (rule.want) {
            SignalWant.BUY -> s > 0
            SignalWant.SELL -> s < 0
            SignalWant.NEUTRAL -> s == 0
            SignalWant.NON_NEUTRAL -> s != 0
        }
    }
}

/** 信号阶段（展示标签，不改得分）。 */
private enum class SignalStage(val label: String) {
    SPROUT("萌芽"),
    SPREAD("扩散"),
    RESONATE("共振"),
    CONFLICT("分歧"),
    UNKNOWN("—"),
}

private fun signalStageOf(row: CrossRankingRow): SignalStage {
    val shortTfs = listOf("5m", "15m", "30m", "1h")
    val longTfs = listOf("4h", "6h", "8h", "12h", "1d")
    fun d(s: com.diveintocrypto.android.domain.model.Signal) = when {
        s.score > 0 -> 1
        s.score < 0 -> -1
        else -> 0
    }
    val short = shortTfs.mapNotNull { row.perTf[it] }.map { d(it.signal) }
    val long = longTfs.mapNotNull { row.perTf[it] }.map { d(it.signal) }
    val shortDir = short.filter { it != 0 }
    if (shortDir.isEmpty() && long.none { it != 0 }) return SignalStage.UNKNOWN
    val primary = when {
        shortDir.count { it > 0 } > shortDir.count { it < 0 } -> 1
        shortDir.count { it < 0 } > shortDir.count { it > 0 } -> -1
        else -> {
            val ld = long.filter { it != 0 }
            when {
                ld.count { it > 0 } > ld.count { it < 0 } -> 1
                ld.count { it < 0 } > ld.count { it > 0 } -> -1
                else -> return SignalStage.UNKNOWN
            }
        }
    }
    val shortAlign = short.count { it == primary }
    val longAlign = long.count { it == primary }
    val longOpp = long.count { it == -primary }
    val longNeu = long.count { it == 0 }
    if (longOpp > longAlign && shortAlign > 0) return SignalStage.CONFLICT
    if (row.totalTfs > 0 && row.countHit >= (row.totalTfs * 2 / 3).coerceAtLeast(3)) return SignalStage.RESONATE
    if (shortAlign >= 1 && longAlign >= 1) return SignalStage.SPREAD
    if (shortAlign >= 1 && longNeu >= longAlign) return SignalStage.SPROUT
    if (shortAlign >= 1) return SignalStage.SPROUT
    return SignalStage.UNKNOWN
}

@Composable
private fun StageChip(stage: SignalStage) {
    if (stage == SignalStage.UNKNOWN) return
    val color = when (stage) {
        SignalStage.SPROUT -> DiveColors.Cyan
        SignalStage.SPREAD -> DiveColors.Accent
        SignalStage.RESONATE -> DiveColors.Green
        SignalStage.CONFLICT -> DiveColors.Warn
        else -> DiveColors.TextMuted
    }
    Text(
        text = "阶段 · ${stage.label}",
        color = color,
        fontSize = 10.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(color.copy(alpha = 0.12f))
            .border(1.dp, color.copy(alpha = 0.35f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp),
    )
}

@Composable
private fun SignalFilterPanel(
    availableTfs: List<String>,
    rules: List<SignalFilterRule>,
    onRulesChange: (List<SignalFilterRule>) -> Unit,
    matchCount: Int?,
) {
    var draftTf by remember(availableTfs) {
        mutableStateOf(availableTfs.firstOrNull { it == "15m" } ?: availableTfs.firstOrNull() ?: "15m")
    }
    var draftWant by remember { mutableStateOf(SignalWant.BUY) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(DiveColors.BgCard)
            .border(1.dp, DiveColors.Border, RoundedCornerShape(12.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "周期信号筛选",
                color = DiveColors.Text,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = DiveFonts.body,
            )
            Spacer(Modifier.weight(1f))
            if (matchCount != null) {
                Text(
                    text = "命中 $matchCount",
                    color = DiveColors.Accent,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                )
            }
            if (rules.isNotEmpty()) {
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "清空",
                    color = DiveColors.Warn,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { onRulesChange(emptyList()) },
                )
            }
        }
        Text(
            text = "多条件为「且」关系。例：15m 买入 + 1h 买入。",
            color = DiveColors.TextDim,
            fontSize = 10.sp,
        )
        // 预设
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            listOf(
                "短线启动" to listOf(
                    SignalFilterRule("15m", SignalWant.NON_NEUTRAL),
                    SignalFilterRule("1h", SignalWant.NEUTRAL),
                ),
                "短中同向买" to listOf(
                    SignalFilterRule("15m", SignalWant.BUY),
                    SignalFilterRule("1h", SignalWant.BUY),
                ),
                "短中同向卖" to listOf(
                    SignalFilterRule("15m", SignalWant.SELL),
                    SignalFilterRule("1h", SignalWant.SELL),
                ),
                "1h买入" to listOf(SignalFilterRule("1h", SignalWant.BUY)),
                "1h卖出" to listOf(SignalFilterRule("1h", SignalWant.SELL)),
            ).forEach { (label, preset) ->
                val active = rules == preset
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (active) DiveColors.Accent.copy(alpha = 0.2f) else DiveColors.BgCardHover)
                        .border(1.dp, if (active) DiveColors.Accent else DiveColors.Border, RoundedCornerShape(8.dp))
                        .clickable { onRulesChange(preset) }
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                ) {
                    Text(
                        text = label,
                        color = if (active) DiveColors.Accent else DiveColors.TextMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
        // 已选条件
        if (rules.isNotEmpty()) {
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                rules.forEachIndexed { index, rule ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(DiveColors.Accent.copy(alpha = 0.12f))
                            .border(1.dp, DiveColors.Accent.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                            .clickable {
                                onRulesChange(rules.toMutableList().also { it.removeAt(index) })
                            }
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                    ) {
                        Text(
                            text = "${rule.tf}·${rule.want.label} ×",
                            color = DiveColors.Accent,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }
            }
        }
        // 添加条件：TF
        Text("周期", color = DiveColors.TextDim, fontSize = 10.sp)
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            availableTfs.forEach { tf ->
                val active = draftTf == tf
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (active) DiveColors.Accent else DiveColors.BgCardHover)
                        .clickable { draftTf = tf }
                        .padding(horizontal = 8.dp, vertical = 5.dp),
                ) {
                    Text(
                        text = tf,
                        color = if (active) androidx.compose.ui.graphics.Color.White else DiveColors.TextMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
        Text("信号", color = DiveColors.TextDim, fontSize = 10.sp)
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            SignalWant.values().forEach { w ->
                val active = draftWant == w
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (active) DiveColors.Accent else DiveColors.BgCardHover)
                        .clickable { draftWant = w }
                        .padding(horizontal = 8.dp, vertical = 5.dp),
                ) {
                    Text(
                        text = w.label,
                        color = if (active) androidx.compose.ui.graphics.Color.White else DiveColors.TextMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(DiveColors.Accent)
                .clickable {
                    val next = rules + SignalFilterRule(draftTf, draftWant)
                    // 同一 TF 只保留最后一条
                    onRulesChange(next.groupBy { it.tf }.map { it.value.last() })
                }
                .padding(vertical = 10.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = "添加条件 · ${draftTf} ${draftWant.label}",
                color = androidx.compose.ui.graphics.Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}


/**
 * 启动分（展示层专用）：短周期已有买/卖，长周期未全面共振、且不强烈反向。
 * 返回 null = 不进入启动榜（不会从共识榜删除，只是不出现在启动分页）。
 */
private fun earlyEntryScore(row: CrossRankingRow): Double? {
    // 短周期优先；若扫描未写入 5m 等，回退到 2h / 任意已有周期上的方向信号
    val shortTfs = listOf("5m", "15m", "30m", "1h", "2h")
    val longTfs = listOf("4h", "6h", "8h", "12h", "1d")
    fun dirOf(s: com.diveintocrypto.android.domain.model.Signal): Int = when {
        s.score > 0 -> 1
        s.score < 0 -> -1
        else -> 0
    }
    var shortSlots = shortTfs.mapNotNull { row.perTf[it] }
    if (shortSlots.isEmpty()) {
        // 回退：任意非长周期、或全部 perTf 中带方向的格子
        shortSlots = row.perTf.filterKeys { it !in longTfs }.values.toList()
        if (shortSlots.isEmpty()) shortSlots = row.perTf.values.toList()
    }
    if (shortSlots.isEmpty()) {
        // 最后回退：用主导方向 + 低 countHit 作为弱启动分，避免启动榜全空
        if (row.dominantDir.score == 0) return null
        val late = if (row.totalTfs > 0) row.countHit.toDouble() / row.totalTfs else 1.0
        return 30.0 + kotlin.math.abs(row.dominantDir.score) * 10.0 - late * 25.0
    }
    val shortDirected = shortSlots.filter { dirOf(it.signal) != 0 }
    if (shortDirected.isEmpty()) {
        if (row.dominantDir.score == 0) return null
        val late = if (row.totalTfs > 0) row.countHit.toDouble() / row.totalTfs else 1.0
        return 25.0 + kotlin.math.abs(row.dominantDir.score) * 8.0 - late * 20.0
    }
    val buyN = shortDirected.count { dirOf(it.signal) > 0 }
    val sellN = shortDirected.count { dirOf(it.signal) < 0 }
    if (buyN == sellN) return null
    val primary = if (buyN > sellN) 1 else -1
    val longSlots = longTfs.mapNotNull { row.perTf[it] }
    val longOppose = longSlots.count { dirOf(it.signal) == -primary }
    val longAlign = longSlots.count { dirOf(it.signal) == primary }
    val longNeutral = longSlots.count { dirOf(it.signal) == 0 }
    // 长周期强烈反向仍排除
    if (longSlots.isNotEmpty() && longOppose > longAlign) return null
    val shortConf = shortDirected
        .filter { dirOf(it.signal) == primary }
        .sumOf { it.confidence }
        .toDouble()
    val latePenalty = when {
        row.totalTfs > 0 && row.countHit >= row.totalTfs - 1 -> 45.0
        row.totalTfs > 0 && row.countHit * 3 >= row.totalTfs * 2 -> 22.0
        else -> 0.0
    }
    val earlyBonus = longNeutral * 10.0 + (shortDirected.size * 3.0)
    val opposePenalty = longOppose * 28.0
    return shortConf + earlyBonus - latePenalty - opposePenalty
}


@Composable
private fun ForwardPlansIntro(
    count: Int,
    rejectionCount: Int,
    recentEvents: List<com.diveintocrypto.android.domain.scanner.ForwardPlanEvent>,
    trackedPlans: List<com.diveintocrypto.android.domain.scanner.TrackedForwardPlan>,
    revisionCount: Int,
    replayResults: List<com.diveintocrypto.android.domain.scanner.ForwardPlanReplayRecord>,
    onArchivePlan: (String) -> Unit,
    onDeleteArchived: () -> Int,
) {
    var showHistory by rememberSaveable { mutableStateOf(false) }
    var confirmDeleteArchived by rememberSaveable { mutableStateOf(false) }
    val archivedCount = trackedPlans.count { it.archived }
    val priceFmt: (Double) -> String = { value -> if (value >= 1000.0) value.format(2) else value.format(6).trimEnd('0').trimEnd('.') }
    if (confirmDeleteArchived) {
        AlertDialog(
            onDismissRequest = { confirmDeleteArchived = false },
            title = { Text("永久删除已归档计划？") },
            text = { Text("将删除 $archivedCount 个已归档计划及其关联事件和 AI 修订。此操作不可撤销。") },
            confirmButton = {
                TextButton(onClick = { onDeleteArchived(); confirmDeleteArchived = false }) { Text("永久删除") }
            },
            dismissButton = {
                TextButton(onClick = { confirmDeleteArchived = false }) { Text("取消") }
            },
        )
    }
    Column(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
            .background(DiveColors.BgCard).border(1.dp, DiveColors.Border, RoundedCornerShape(12.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        Text("前瞻计划榜", color = DiveColors.Text, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Text("只展示具备有效行情、方向与关键结构参考的预备计划。风险收益比按设置扣除估算双边手续费与滑点；计划不是已触发信号，也不会自动下单。", color = DiveColors.TextMuted, fontSize = 11.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("跟踪计划 $count", color = DiveColors.Accent, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            Text("本轮拒绝 $rejectionCount", color = DiveColors.TextDim, fontSize = 11.sp)
        }
        val statusCounts = trackedPlans.groupingBy { it.status }.eachCount()
        val waitingCount = statusCounts[com.diveintocrypto.android.domain.scanner.ForwardEntryPlanEngine.Status.WAITING_TRIGGER] ?: 0
        val metCount = statusCounts[com.diveintocrypto.android.domain.scanner.ForwardEntryPlanEngine.Status.CONDITION_MET] ?: 0
        val invalidExpiredCount = (statusCounts[com.diveintocrypto.android.domain.scanner.ForwardEntryPlanEngine.Status.INVALID] ?: 0) +
            (statusCounts[com.diveintocrypto.android.domain.scanner.ForwardEntryPlanEngine.Status.EXPIRED] ?: 0)
        Text(
            "历史快照 ${trackedPlans.size} · AI修订 $revisionCount · 回放记录 ${replayResults.size} · 等待触发 $waitingCount · 条件满足 $metCount · 失效/过期 $invalidExpiredCount",
            color = DiveColors.TextDim, fontSize = 10.sp, lineHeight = 13.sp,
        )
        val coverageGaps = replayResults.count { it.coverageStatus == "GAP" || it.coverageStatus == "PARTIAL" || it.coverageStatus == "NO_DATA" }
        val coverageComplete = replayResults.count { it.coverageStatus == "COMPLETE_THROUGH_EXPIRY" || it.coverageStatus == "SUFFICIENT_FOR_OUTCOME" }
        Text("回放覆盖：充分 $coverageComplete · 数据不足/缺口 $coverageGaps · 未决检查点 ${replayResults.count { it.outcome == "OPEN" }}", color = DiveColors.TextDim, fontSize = 10.sp, lineHeight = 13.sp)
        val performanceReport = com.diveintocrypto.android.domain.scanner.ForwardPlanPerformance.report(replayResults)
        val performance = performanceReport.summary
        Text(
            if (performanceReport.qualifiedCount == 0) "历史效果报告：暂无覆盖充分的止盈/止损样本；未决、过期、缺数据和有缺口的记录均排除。"
            else "历史效果报告 · 有效样本 ${performanceReport.qualifiedCount} / 排除 ${performanceReport.excludedCount} · 止盈 ${performance.wins} (${performance.targetHitRatePct?.format(1) ?: "—"}%) / 止损 ${performance.losses} (${performance.stopHitRatePct?.format(1) ?: "—"}%) · 胜率 ${performance.winRatePct?.format(1) ?: "—"}% · 平均净R ${performance.expectancyR?.format(2) ?: "—"} · 最大回撤 ${performance.maxDrawdownR?.format(2) ?: "—"}R",
            color = DiveColors.TextMuted, fontSize = 10.sp, lineHeight = 13.sp,
        )
        Text(performanceReport.splitDescription, color = DiveColors.TextDim, fontSize = 9.sp, lineHeight = 12.sp)
        val trainSummary = performanceReport.trainSummary
        val outSummary = performanceReport.outOfSampleSummary
        if (trainSummary != null || outSummary != null) {
            Text(
                "训练段 ${trainSummary?.sampleCount ?: 0} 条 / 期望R ${trainSummary?.expectancyR?.format(2) ?: "—"} · 样本外 ${outSummary?.sampleCount ?: 0} 条 / 期望R ${outSummary?.expectancyR?.format(2) ?: "—"}",
                color = DiveColors.TextMuted, fontSize = 9.sp, lineHeight = 12.sp,
            )
        }
        performanceReport.sampleWarning?.let { warning ->
            Text(warning, color = DiveColors.Red, fontSize = 9.sp, lineHeight = 12.sp)
        }
        if (performanceReport.equityCurve.isNotEmpty()) {
            val curveTail = performanceReport.equityCurve.takeLast(24)
            val minEquity = curveTail.minOf { it.cumulativeR }
            val maxEquity = curveTail.maxOf { it.cumulativeR }
            val sparkBars = "▁▂▃▄▅▆▇█"
            val sparkline = curveTail.joinToString("") { point ->
                val fraction = if (maxEquity - minEquity <= 1e-9) 0.5 else (point.cumulativeR - minEquity) / (maxEquity - minEquity)
                sparkBars[(fraction * (sparkBars.length - 1)).toInt().coerceIn(0, sparkBars.lastIndex)].toString()
            }
            Text(
                "累计净R曲线（最近${curveTail.size}个结算点）  $sparkline",
                color = if ((curveTail.lastOrNull()?.cumulativeR ?: 0.0) >= 0.0) DiveColors.Green else DiveColors.Red,
                fontSize = 10.sp, lineHeight = 14.sp,
            )
            Text(
                "累计 ${curveTail.last().cumulativeR.format(2)}R · 区间 ${minEquity.format(2)}R 至 ${maxEquity.format(2)}R",
                color = DiveColors.TextDim, fontSize = 9.sp, lineHeight = 12.sp,
            )
        }
        if (recentEvents.isNotEmpty()) {
            Text("最近状态历史", color = DiveColors.Text, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        }
        recentEvents.forEach { event ->
            Text(
                "${event.atMs} · ${event.planId.substringBefore('|')} · ${event.fromStatus} → ${event.toStatus} · ${event.reason}",
                color = DiveColors.TextMuted, fontSize = 10.sp, lineHeight = 13.sp,
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { showHistory = !showHistory }) {
                Text(if (showHistory) "收起计划历史" else "管理计划历史 (${trackedPlans.size})", fontSize = 11.sp)
            }
            if (archivedCount > 0) {
                TextButton(onClick = { confirmDeleteArchived = true }) {
                    Text("清理已归档 $archivedCount", fontSize = 11.sp, color = DiveColors.Red)
                }
            }
        }
        if (showHistory) {
            trackedPlans.sortedByDescending { it.snapshot.generatedAtMs }.forEach { tracked ->
                val plan = tracked.snapshot
                Column(
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp))
                        .background(DiveColors.Bg).padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp),
                ) {
                    Text(
                        "${plan.symbol} · ${plan.direction.name} · ${plan.type.name} · ${tracked.status.name}${if (tracked.archived) " · 已归档" else ""}",
                        color = DiveColors.Text, fontSize = 10.sp, fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                        "生成 ${plan.generatedAtMs} · 到期 ${plan.expiresAtMs} · 入场 ${priceFmt(plan.entryLow)}–${priceFmt(plan.entryHigh)} · 止损 ${priceFmt(plan.stopLoss)} · 止盈 ${priceFmt(plan.takeProfit)}",
                        color = DiveColors.TextMuted, fontSize = 10.sp, lineHeight = 13.sp,
                    )
                    Text(
                        "AI 修订记录共 ${revisionCount} 条 · 最近观察价 ${tracked.lastObservedPrice?.let { priceFmt(it) } ?: "—"} · 最近收盘K线 ${tracked.lastClosedCandleTimeMs ?: "—"}",
                        color = DiveColors.TextDim, fontSize = 9.sp,
                    )
                    if (!tracked.archived) {
                        TextButton(onClick = { onArchivePlan(plan.id) }) { Text("归档此计划", fontSize = 10.sp) }
                    }
                }
            }
        }
    }
}

@Composable
private fun ForwardPlansEmpty(scanning: Boolean, hasRows: Boolean) {
    Column(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
            .background(DiveColors.BgCard).border(1.dp, DiveColors.Border, RoundedCornerShape(12.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text(if (scanning) "正在更新前瞻候选…" else "当前没有合格的前瞻计划", color = DiveColors.Text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Text(
            if (!hasRows) "请先完成一次全市场扫描。" else "可点「AI前瞻方案」以 AI 分析为主生成预备计划；本地结构仅作锚点与校验。无合格结构时不会硬凑信号。",
            color = DiveColors.TextMuted, fontSize = 11.sp,
        )
    }
}

@Composable
private fun ForwardPlanCard(
    plan: ForwardEntryPlanEngine.Plan,
    rank: Int,
    livePrice: Double?,
    aiRevision: com.diveintocrypto.android.domain.scanner.ForwardPlanRevision? = null,
    onOpen: () -> Unit,
    onAnalyze: () -> Unit,
) {
    val aiPrimary = plan.validationNotes.any { it.contains("AI主导") }
    val typeLabel = when (plan.type) {
        ForwardEntryPlanEngine.Type.BREAKOUT_PREPARATION -> "突破预备"
        ForwardEntryPlanEngine.Type.RETEST_PREPARATION -> "回踩预备"
        ForwardEntryPlanEngine.Type.REVERSAL_PREPARATION -> "反转预备"
        ForwardEntryPlanEngine.Type.TREND_CONTINUATION -> "趋势延续"
    }
    val directionLabel = if (plan.direction == ForwardEntryPlanEngine.Direction.LONG) "做多候选" else "做空候选"
    val priceFmt: (Double) -> String = { value -> if (value >= 1000.0) value.format(2) else value.format(6).trimEnd('0').trimEnd('.') }
    Column(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .background(DiveColors.BgCard).border(1.dp, DiveColors.Border, RoundedCornerShape(14.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("#$rank  ${plan.symbol}", color = DiveColors.Text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text("质量 ${plan.quality}", color = if (plan.quality >= 75) DiveColors.Green else DiveColors.Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(typeLabel, color = DiveColors.Accent, fontSize = 10.sp, modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(DiveColors.Accent.copy(alpha = 0.12f)).padding(horizontal = 7.dp, vertical = 4.dp))
            Text(directionLabel, color = DiveColors.Text, fontSize = 10.sp, modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(DiveColors.BgCardHover).padding(horizontal = 7.dp, vertical = 4.dp))
            Text("${plan.primaryTimeframe} 主周期", color = DiveColors.TextMuted, fontSize = 10.sp, modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(DiveColors.BgCardHover).padding(horizontal = 7.dp, vertical = 4.dp))
            val statusLabel = when (plan.status) {
                ForwardEntryPlanEngine.Status.PREPARING -> "预备中"
                ForwardEntryPlanEngine.Status.WAITING_TRIGGER -> "等待触发"
                ForwardEntryPlanEngine.Status.CONDITION_MET -> "已收盘确认·待复核"
                ForwardEntryPlanEngine.Status.INVALID -> "已失效"
                ForwardEntryPlanEngine.Status.EXPIRED -> "已过期"
                ForwardEntryPlanEngine.Status.COMPLETED -> "已完成"
            }
            Text(statusLabel, color = if (plan.status == ForwardEntryPlanEngine.Status.CONDITION_MET) DiveColors.Green else DiveColors.Yellow, fontSize = 10.sp)
        }
        val validLivePrice = livePrice?.takeIf { it.isFinite() && it > 0.0 }
        val currentText = validLivePrice?.let { "实时参考 ${priceFmt(it)} · 生成时 ${priceFmt(plan.referencePrice)}" }
            ?: "生成时参考价 ${priceFmt(plan.referencePrice)}"
        val liveDriftPct = validLivePrice?.let { kotlin.math.abs(it - plan.referencePrice) / plan.referencePrice * 100.0 }
        val expired = nowMillis() >= plan.expiresAtMs
        val requiresRevalidation = expired || (liveDriftPct != null && liveDriftPct > plan.maxAllowedPriceMovePct)
        Text(currentText, color = DiveColors.TextDim, fontSize = 10.sp)
        Text(
            text = when {
                expired -> "计划已过有效期：请重新扫描，不可沿用旧价位"
                liveDriftPct != null && liveDriftPct > plan.maxAllowedPriceMovePct -> "价格偏离 ${liveDriftPct.format(2)}%，超过允许偏离 ${plan.maxAllowedPriceMovePct.format(2)}%；计划需重新校验"
                plan.status == ForwardEntryPlanEngine.Status.CONDITION_MET -> "已由后续收盘K线确认触发参考；仍需人工复核追价、手续费和净风险收益比"
                else -> "有效至 ${formatTs(plan.expiresAtMs)} · 当前状态：等待触发（未确认突破/回踩）"
            },
            color = if (requiresRevalidation) DiveColors.Warn else DiveColors.TextMuted,
            fontSize = 10.sp,
        )
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                ForwardPlanMetric("理想入场区", "${priceFmt(plan.entryLow)} – ${priceFmt(plan.entryHigh)}", Modifier.weight(1f))
                ForwardPlanMetric("触发参考", priceFmt(plan.triggerPrice), Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                ForwardPlanMetric("止损参考", priceFmt(plan.stopLoss), Modifier.weight(1f))
                ForwardPlanMetric("止盈参考", priceFmt(plan.takeProfit), Modifier.weight(1f))
                ForwardPlanMetric("风险收益比", "1 : ${plan.riskRewardRatio.format(2)}", Modifier.weight(1f))
            }
        }
        Text("触发条件：${plan.triggerRule}", color = DiveColors.TextMuted, fontSize = 11.sp, lineHeight = 15.sp)
        Text("失效条件：${plan.invalidationRule}", color = DiveColors.TextDim, fontSize = 10.sp, lineHeight = 14.sp)
        if (aiRevision != null) {
            Text(
                "AI建议版本 v${aiRevision.version}（独立参考，不覆盖本地计划）：入场 ${priceFmt(aiRevision.entry)} · 止损 ${priceFmt(aiRevision.stop)} · 止盈 ${priceFmt(aiRevision.target)} · R:R 1:${aiRevision.riskRewardRatio.format(2)}",
                color = DiveColors.Accent, fontSize = 10.sp, lineHeight = 14.sp,
            )
            Text("AI理由：${aiRevision.rationale}", color = DiveColors.TextDim, fontSize = 10.sp, lineHeight = 14.sp)
        }
        if (plan.validationNotes.isNotEmpty()) Text(plan.validationNotes.joinToString("；"), color = DiveColors.TextDim, fontSize = 10.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClick = onOpen) { Text("查看品种") }
            TextButton(onClick = onAnalyze) { Text("打开分析") }
        }
    }
}

@Composable
private fun ForwardPlanMetric(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(DiveColors.BgCardHover).padding(horizontal = 9.dp, vertical = 7.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp),
    ) {
        Text(label, color = DiveColors.TextDim, fontSize = 9.sp)
        Text(value, color = DiveColors.Text, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun EarlyBoardNote() {
    Text(
        text = "启动排行仅按短周期信号重排展示，不修改共识得分与淘汰逻辑；假突破可能更多，请谨慎。",
        color = DiveColors.Warn,
        fontSize = 11.sp,
        fontFamily = DiveFonts.body,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(DiveColors.Warn.copy(alpha = 0.10f))
            .border(1.dp, DiveColors.Warn.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
    )
}

private enum class ResultFilter { ALL, DIVERGENCE }

/** "All" / "⚠ Divergence (n)" two-pill lens selector. */
@Composable
private fun ResultFilterToggle(
    selected: ResultFilter,
    flaggedCount: Int,
    onSelect: (ResultFilter) -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        FilterPill(
            label = "全部",
            selected = selected == ResultFilter.ALL,
            accent = DiveColors.Accent,
            modifier = Modifier.weight(1f),
            onClick = { onSelect(ResultFilter.ALL) },
        )
        FilterPill(
            label = if (flaggedCount > 0) "✕ Eliminated ($flaggedCount)" else "✕ Eliminated",
            selected = selected == ResultFilter.DIVERGENCE,
            accent = DiveColors.Warn,
            modifier = Modifier.weight(1f),
            onClick = { onSelect(ResultFilter.DIVERGENCE) },
        )
    }
}

/** Scan controls: table size (5/10/15/20/All) + Divergence Sort lens + CONTINUOUS (back-to-back) mode button. */
@Composable
private fun ScanControlsRow(
    displaySize: Int,
    continuous: Boolean,
    cycle: Int,
    scanning: Boolean,
    divergenceSort: Boolean,
    onSize: (Int) -> Unit,
    onContinuous: (Boolean) -> Unit,
    onDivergenceSort: (Boolean) -> Unit,
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(
            text = "表格行数",
            color = DiveColors.TextMuted,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.2.sp,
            fontFamily = DiveFonts.body,
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            for (n in listOf(5, 10, 15, 20, Int.MAX_VALUE)) {
                FilterPill(
                    label = if (n >= Int.MAX_VALUE / 2) "全部" else "$n",
                    selected = displaySize == n,
                    accent = DiveColors.Accent,
                    modifier = Modifier.weight(1f),
                    onClick = { onSize(n) },
                )
            }
        }
        // ── OPT-IN "Divergence Sort" lens (default OFF) ─────────────
        // When ON, the SAME survivors are shown by |divergence score| desc (the cross-sectional
        // top-K validated by backtest). Only the display order changes; score/elimination are unchanged.
        FilterPill(
            label = if (divergenceSort) "◆ 背离排序 开" else "背离排序 关",
            selected = divergenceSort,
            accent = DiveColors.Warn,
            modifier = Modifier.fillMaxWidth(),
            onClick = { onDivergenceSort(!divergenceSort) },
        )
        if (divergenceSort) {
            Text(
                text = "按|背离得分|降序显示 — 回测：前3背离 ≈ 61–76%（24–48小时）。" +
                    "排名/得分/剔除逻辑不变；仅改变显示顺序。",
                color = DiveColors.TextDim,
                fontSize = 10.sp,
                lineHeight = 13.sp,
                fontFamily = DiveFonts.body,
            )
        }
        FilterPill(
            label = if (continuous) {
                if (scanning) "● 连续扫描 · 第${cycle}轮" else "● 连续扫描 开"
            } else "连续扫描 关",
            selected = continuous,
            accent = DiveColors.Cyan,
            modifier = Modifier.fillMaxWidth(),
            onClick = { onContinuous(!continuous) },
        )
    }
}

@Composable
private fun FilterPill(
    label: String,
    selected: Boolean,
    accent: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val bg = if (selected) accent.copy(alpha = 0.18f) else DiveColors.BgCard
    val border = if (selected) accent.copy(alpha = 0.6f) else DiveColors.Border
    val fg = if (selected) accent else DiveColors.TextMuted
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bg)
            .border(1.dp, border, RoundedCornerShape(8.dp))
            // A11y: exposed as a button whose selection state is announced.
            .semantics {
                role = Role.Button
                stateDescription = if (selected) "已选中" else "未选中"
            }
            .clickable { onClick() }
            .padding(vertical = 9.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = fg,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = DiveFonts.body,
        )
    }
}

/** Info card that explains the "背离" lens concept once (discoverability). */
@Composable
private fun DivergenceLensInfo() {
    // Theme warning token — was a pinned 0xFFF59E0B amber that clashed with light presets.
    val amber = DiveColors.Warn
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(amber.copy(alpha = 0.08f))
            .border(1.dp, amber.copy(alpha = 0.25f), RoundedCornerShape(10.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Text(
            text = "⚠ 鲸鱼多空背离",
            color = amber,
            fontSize = 11.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 0.4.sp,
            fontFamily = DiveFonts.body,
        )
        Text(
            text = "标签=鲸鱼原始动向；得分=经验反向排名。" +
                "▼ DISTRIBUTION (red): price ↑ + whale L/S ↓ (whales selling into a rally). " +
                "Top-trader L/S is contrarian → price has historically CONTINUED upward, " +
                "因此得分为正（+），币种排名上升。" +
                "▲ ACCUMULATION (green): price ↓ + whale L/S ↑ → contrarian expectation is a decline " +
                "→ SCORE NEGATIVE (−), ranks down. A higher timeframe (1d) scores stronger than a " +
                "较低的一个（5m）。",
            color = DiveColors.TextMuted,
            fontSize = 11.sp,
            fontFamily = DiveFonts.body,
            lineHeight = 15.sp,
        )
        // ── Honest historical backtest + suggested holding horizon (descriptive text only) ──
        // This block is PURELY explanatory; it does NOT affect signal/ranking/elimination logic.
        Text(
            text = "历史回测 / 建议持仓",
            color = amber,
            fontSize = 10.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 0.4.sp,
            fontFamily = DiveFonts.body,
        )
        Text(
            text = "建议持仓：24–48 小时。" +
                "最可靠：排名前 3 的背离信号。" +
                "Historical backtest: top 3 divergences ≈ 61–64% correct (24–48h, 2%+ move) — not guaranteed. " +
                "Contrarian: whale selling = DISTRIBUTION label, but historically price has " +
                "continued upward → rank ↑.",
            color = DiveColors.TextMuted,
            fontSize = 11.sp,
            fontFamily = DiveFonts.body,
            lineHeight = 15.sp,
        )
    }
}

/** Info shown when the "背离" lens is empty. If `uncheckable` > 0, honestly notes
 *  the number of symbols whose whale data could not be fetched (silent false-negative risk). */
@Composable
private fun NoDivergenceCard(uncheckable: Int) {
    val msg = buildString {
        append("本次扫描未发现鲸鱼多空背离。")
        if (uncheckable > 0) append("  ($uncheckable symbols had no whale data — partial check.)")
    }
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(DiveColors.BgCard)
            .border(1.dp, DiveColors.Border, RoundedCornerShape(12.dp))
            .padding(20.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = msg,
            color = DiveColors.TextMuted,
            fontSize = 13.sp,
            fontFamily = DiveFonts.body,
        )
    }
}
