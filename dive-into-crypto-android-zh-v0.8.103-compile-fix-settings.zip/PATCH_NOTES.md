Fix ScannerScreen: settings scope for LaunchedEffect; hasAiPlan in risk card
