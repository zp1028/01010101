# BTC Quant 10.0.0

BTC 多周期概率预测与交易研究终端。项目与旧彩票业务逻辑隔离，核心目标是把 **Market Data → Feature → Strategy → ML Probability → Bayesian → Polymarket Edge → Kelly → Risk → Execution → Reconciliation → PnL/Feedback** 串成闭环。

## 核心能力

- BTCUSDT 5m / 15m / 1h 多周期行情
- Binance Futures OrderBook：bid/ask、深度、imbalance、micro-price、spread
- Funding / Open Interest / 衍生品特征
- Strategy Pool + Walk-Forward + Dynamic Weight + Correlation Filter
- 本地 Logistic ML 概率模型：用历史 K 线拟合下一根方向
- Probability Calibration + Brier / LogLoss / ECE
- Bayesian Particle Filter / Particle Field
- Polymarket Gamma 市场发现 + CLOB YES/NO orderbook
- Executable Edge：Ask/Bid - Fee - Spread - Slippage - Liquidity Impact - Latency
- Half Kelly + 动态仓位倍率
- Paper / Testnet / Live 硬隔离
- 真实 Binance wallet / available / position 对账
- 持久化执行幂等、冷却时间、SL/TP 保护、Kill Switch
- Runtime Audit / PnL / Model Feedback
- HS Opportunity Score：将概率、Net Edge、流动性、Spread、模型表现、数据质量、回撤统一为可解释机会评分
- Data Quality Engine：BTC 多周期、Binance OrderBook、Polymarket CLOB、Chainlink 分级状态与决策安全门
- WHY / RISK 决策解释：每次机会输出同源的理由、风险、关键指标
- Logistic ML 严格时间切分：训练集与留出集分离，避免用测试样本评估训练模型

## 数据真实性原则

没有真实 CLOB orderbook 时，不把 0.50 或静态 outcome price 当成可成交报价；没有 Chainlink Oracle 配置时明确显示 Oracle unavailable；没有 Binance API 时明确显示 PAPER；Demo 只生成演示行情/衍生品/新闻，不伪造真实账户和盘口。

## Chainlink

在交易配置中填写 EVM JSON-RPC URL 与 Chainlink AggregatorV3 Feed Address。系统通过 `latestRoundData()` 获取 answer 与 updatedAt。未填写时不会把 Binance mark price 冒充 Chainlink。

## 构建

- JDK 17
- Android SDK 35
- AGP 8.5.2
- Gradle 8.9
- minSdk 24 / targetSdk 35

工程发布包不携带构建中间产物。若本地环境没有 Gradle Wrapper JAR，请使用已配置 Gradle 8.9 的 CI 环境执行 `assembleDebug`。

## 版本

10.0.0 — Polymarket 5m 实时终端面板、市场倒计时、Price-to-Beat/Current BTC/Delta、YES/NO 报价与真实 CLOB 深度绑定；市场匹配增强。

9.3.0 — HS 模型自评估增强：Model Lab、Model×Regime 归因、Shadow Trading、MFE/MAE、风险仓位引擎与实时决策展示。

## v9.2 质量层
- `HsDataQualityEngine` 对 5m/15m/1h、Binance OrderBook、Polymarket CLOB、Chainlink 做 LIVE/STALE/DEGRADED/OFFLINE 分级。
- `HsOpportunityEngine` 将 Net Edge、概率可信度、流动性、Spread、模型表现、数据质量、回撤组合成 Opportunity Score；它不是收益保证，只用于统一决策门槛。
- `HsDecisionExplanation` 使用决策同源数据生成 WHY / RISK，避免 UI 自己拼接与实际交易逻辑不一致。
- Logistic ML 使用严格时间顺序训练/留出评估，测试集不参与拟合；输出 Brier、LogLoss、Hit Rate 与模型版本。
- Kelly 同时按 YES/NO 两个方向计算，取当前可交易方向的较优值，避免把 YES 的赔率公式错误套到 NO。

## v9.3 模型反馈层
- `HsModelLab`：严格时间顺序 80/20 留出评估，提供 Trend/Momentum/Mean-Reversion/Breakout/Volatility 独立模型与 Regime 矩阵。
- `HsShadowTradingStore`：真实行情驱动、零真实下单的 Shadow Ledger；记录预测结算、MFE、MAE、收益和模型版本。
- `HsOpportunitySizing`：以 Half-Kelly 为上限，并同时考虑 Net Edge、流动性、波动率、回撤；不会因连续亏损自动加码。
- Decision Center 展示 Model Lab、Shadow MFE/MAE 和当前风险仓位。
- 诊断模块只参与研究与反馈，不绕过 Risk/Execution Gate。
