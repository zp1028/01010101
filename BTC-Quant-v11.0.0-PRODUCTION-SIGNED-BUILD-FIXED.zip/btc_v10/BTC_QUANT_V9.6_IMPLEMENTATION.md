# BTC Quant v9.7 — Snapshot / Persistence / Attribution Foundation

## Completed
- HS Model Lab is evaluated independently for 5m / 15m / 1h; each timeframe receives its own walk-forward/regime report and weights.
- `HsPredictionSnapshot` exposes `modelLabByTimeframe` while preserving the 15m report as the primary report.
- Shadow ledger now persists both OPEN and CLOSED records, so an app/process restart no longer silently loses unsettled shadow predictions.
- Execution audit supports bounded SharedPreferences persistence when a Context-backed instance is used.
- Prediction snapshot IDs are deterministic SHA-256 identifiers derived from the market/data/model state instead of a time-bucketed ID, improving replay and attribution linkage.
- Existing no-fake-data, execution gate, PAPER/TESTNET/LIVE separation, risk sizing and model lifecycle layers remain intact.

## Validation status
- Source archive integrity checked after packaging.
- Gradle wrapper JAR is still absent from the source archive, so a full Android APK build is not claimed as locally validated. CI remains the authoritative build path.
