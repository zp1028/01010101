# BTC Quant v10.0.0

- Dashboard / Polymarket 终端增加 DOWN YES/NO 四侧订单簿展示。
- Polymarket panel 暴露 CLOB LIVE/PARTIAL 状态，避免空盘口被误显示为完整实时盘口。
- ViewModel 增加 8 秒实时刷新循环；仍只使用真实接口数据，网络失败不生成盘口假数据。
- Polymarket LIVE 撤单明确返回 signer 未配置，而不是伪装为“已实现”。
- versionName 10.0.0 / versionCode 53。

- 自动轮询遇到瞬时网络失败时保留上一份 LIVE 快照，不用 Demo 覆盖真实数据。
- 移除 BTC 活跃代码中的 “stub / not implemented” 文案；LIVE 撤单能力明确标记为 signer/auth 未配置。
