# BTC Quant v9.4.0 — HS Feedback Loop

- Persistent HS probability feedback and shadow ledger using app-local SharedPreferences.
- Chronological shadow settlement preserves open records when settlement input is invalid.
- Model Lab ensemble is now fed into HS probability when sufficient holdout data exists.
- Model × Regime weights are computed from holdout/regime hit-rate and Brier score.
- Prediction snapshots expose current model weights for observability.
- BtcQuantViewModel supplies application context so feedback survives process restart.
- No synthetic market depth, oracle, account, or live execution data is introduced.
