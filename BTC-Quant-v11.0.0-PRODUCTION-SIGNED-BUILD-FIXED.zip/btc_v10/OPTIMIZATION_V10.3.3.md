# v10.3.3 执行门控 UI + 全通道 markPlaced

## 真实下单通道
- **POLYMARKET** 成交成功 → `executionCoordinator.markPlaced`
- **BINANCE** 成交成功 → `executionCoordinator.markPlaced`
- PAPER 此前已接入

## ExecutionCoordinator
- 暴露 `status()`：killSwitch / lastOrderAtMs / placedKeyCount / lastVerdictReason
- ViewModel：`executionStatus: StateFlow` + `setExecutionKillSwitch` / `refreshExecutionStatus`

## SettingsTab
- Kill Switch 开关（红色轨道）
- 最近裁决、幂等键数量、上次下单时间
- 数据质量门：score / LIVE 允许·禁止 / blockReasons / 各源状态

## DashboardTab
- 顶部状态条：`GATE OPEN` / `GATE BLOCKED` / `KILL SWITCH ON` + 最近原因

## 使用
设置页打开 Kill Switch → 自动交易与实盘通道全部拒绝新开仓。
