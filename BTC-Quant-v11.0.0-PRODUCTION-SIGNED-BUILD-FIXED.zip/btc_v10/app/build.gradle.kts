plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.ksp)
}

android {
    namespace = "com.caifenxi.app"
    compileSdk = 35

    // KSP 配置（Room schema 路径）
    ksp {
        arg("room.schemaLocation", "$projectDir/schemas")
        arg("room.incremental", "true")
    }

    defaultConfig {
        applicationId = "com.caifenxi.btcquant"
        // API 24 is the lowest supported baseline: AccessibilityService.dispatchGesture()
        // is available from Android 7.0, while all UI/service paths below use compatibility guards.
        minSdk = 24
        targetSdk = 35
        versionCode = 60
        versionName = "11.0.0"
        buildConfigField("boolean", "FEATURE_BTC_QUANT", "true")
        buildConfigField("boolean", "FEATURE_LEGACY_LOTTERY", "true")
    }

    flavorDimensions += "product"
    productFlavors {
        create("btc") {
            dimension = "product"
            applicationIdSuffix = ".btc"
            versionNameSuffix = "-btc"
            buildConfigField("boolean", "FEATURE_BTC_QUANT", "true")
            buildConfigField("boolean", "FEATURE_LEGACY_LOTTERY", "false")
        }
        create("legacy") {
            dimension = "product"
            applicationIdSuffix = ".legacy"
            versionNameSuffix = "-legacy"
            buildConfigField("boolean", "FEATURE_BTC_QUANT", "false")
            buildConfigField("boolean", "FEATURE_LEGACY_LOTTERY", "true")
        }
        create("full") {
            dimension = "product"
            // 默认全功能，兼容现有安装
            buildConfigField("boolean", "FEATURE_BTC_QUANT", "true")
            buildConfigField("boolean", "FEATURE_LEGACY_LOTTERY", "true")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs += listOf(
            "-opt-in=androidx.compose.material3.ExperimentalMaterial3Api",
            "-opt-in=androidx.compose.foundation.ExperimentalFoundationApi"
        )
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.work.runtime)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons)
    implementation(libs.androidx.navigation.compose)

    implementation(libs.okhttp)
    implementation(libs.okhttp.logging)
    implementation(libs.kotlinx.serialization.json)

    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)

    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.androidx.security.crypto)

    debugImplementation(libs.androidx.compose.ui.tooling)
}
