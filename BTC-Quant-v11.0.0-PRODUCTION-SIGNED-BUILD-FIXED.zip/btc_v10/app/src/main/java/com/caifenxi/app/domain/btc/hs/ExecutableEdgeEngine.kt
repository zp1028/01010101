package com.caifenxi.app.domain.btc.hs

/** Converts raw model-vs-market edge into an executable edge after realistic costs. */
object ExecutableEdgeEngine {
    data class Result(
        val rawEdge: Double,
        val netEdge: Double,
        val cost: HsCostEngine.Cost,
        val executable: Boolean,
        val reason: String
    )

    fun evaluate(
        probability: Double,
        ask: Double,
        bid: Double?,
        depthQuote: Double,
        requestedNotional: Double,
        config: HsRuntimeConfig = HsRuntimeConfig.Default
    ): Result {
        val p = probability.coerceIn(0.0, 1.0)
        val a = ask.coerceIn(0.0001, 0.9999)
        val raw = p - a
        val cost = HsCostEngine.estimate(
            ask = a,
            bid = bid,
            depthQuote = depthQuote,
            requestedNotional = requestedNotional,
            feeRate = config.feeRate,
            latencySec = config.latencySec
        )
        val net = raw - cost.total
        val executable = net >= config.minNetEdge && depthQuote >= requestedNotional * 0.5 && a < 0.995
        val reason = when {
            ask <= 0.0 -> "无有效 Ask"
            depthQuote < requestedNotional * 0.5 -> "盘口深度不足"
            net < config.minNetEdge -> "扣除费用/滑点后 Edge ${"%.2f%%".format(net * 100)} < ${"%.1f%%".format(config.minNetEdge * 100)}"
            else -> "可执行 Edge net=${"%.2f%%".format(net * 100)}"
        }
        return Result(raw, net, cost, executable, reason)
    }
}
