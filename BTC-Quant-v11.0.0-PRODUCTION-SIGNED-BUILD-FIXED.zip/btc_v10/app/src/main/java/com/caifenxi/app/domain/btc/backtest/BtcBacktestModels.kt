package com.caifenxi.app.domain.btc.backtest

import com.caifenxi.app.domain.btc.BtcDirection

data class BacktestConfig(
    val initialEquity: Double = 10_000.0,
    val riskPerTradePct: Double = 0.50,
    val feeRatePct: Double = 0.04,
    val slippagePct: Double = 0.02,
    /** Funding paid per 8h as % of notional (approx). Positive = longs pay. */
    val fundingPer8hPct: Double = 0.01,
    val barsPerFunding: Int = 32, // ~8h on 15m
    val maxHoldingBars: Int = 12,
    val walkForwardTrainBars: Int = 300,
    val walkForwardTestBars: Int = 100
)

data class BacktestTrade(
    val barId: Long,
    val direction: BtcDirection,
    val entry: Double,
    val exit: Double,
    val stopLoss: Double,
    val takeProfit: Double,
    val pnlPct: Double,
    val pnlCash: Double,
    val holdingBars: Int,
    val mfePct: Double,
    val maePct: Double,
    val reason: String,
    val feePct: Double = 0.0,
    val fundingPct: Double = 0.0,
    val slippagePct: Double = 0.0
)

data class BacktestResult(
    val planId: String,
    val trades: List<BacktestTrade>,
    val equityCurve: List<Double>,
    val totalReturnPct: Double,
    val winRatePct: Double,
    val profitFactor: Double,
    val maxDrawdownPct: Double,
    val averagePnlPct: Double,
    val averageHoldingBars: Double,
    val averageMfePct: Double,
    val averageMaePct: Double,
    val sampleSize: Int,
    val inSample: Boolean = false,
    val totalFundingPct: Double = 0.0,
    val totalFeePct: Double = 0.0,
    val sharpe: Double = 0.0,
    val sortino: Double = 0.0,
    val calmar: Double = 0.0,
    val expectancyCash: Double = 0.0,
    val payoffRatio: Double = 0.0
)

/** Per-plan attribution for dynamic weights / UI. */
data class PlanAttribution(
    val planId: String,
    val trades: Int,
    val netReturnPct: Double,
    val fundingDragPct: Double,
    val feeDragPct: Double,
    val profitFactor: Double,
    val maxDrawdownPct: Double
)
