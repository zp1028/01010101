package com.caifenxi.app.domain.btc.backtest

import com.caifenxi.app.domain.btc.BtcCandle
import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.BtcPlanEngine
import com.caifenxi.app.domain.btc.DerivativesFeatures
import com.caifenxi.app.domain.btc.FundingPoint
import com.caifenxi.app.domain.btc.OpenInterestPoint
import com.caifenxi.app.domain.btc.DerivativesFeatureEngine
import com.caifenxi.app.domain.btc.plan.DynamicWeightEngine
import kotlin.math.abs
import kotlin.math.max

class BtcBacktestEngine(
    private val signalEngine: BtcPlanEngine = BtcPlanEngine()
) {
    fun run(
        planId: String,
        candles: List<BtcCandle>,
        config: BacktestConfig = BacktestConfig(),
        startIndex: Int = 0,
        endIndex: Int = candles.lastIndex,
        fundingHistory: List<FundingPoint> = emptyList(),
        oiHistory: List<OpenInterestPoint> = emptyList(),
        perf: Map<String, DynamicWeightEngine.PlanPerf> = emptyMap()
    ): BacktestResult {
        val from = max(80, startIndex)
        val to = endIndex.coerceAtMost(candles.lastIndex - 1)
        if (from >= to) return emptyResult(planId, config.initialEquity)

        var equity = config.initialEquity
        var peak = equity
        var maxDd = 0.0
        val curve = mutableListOf(equity)
        val trades = mutableListOf<BacktestTrade>()
        var totalFunding = 0.0
        var totalFee = 0.0

        var i = from
        while (i < to) {
            val window = candles.subList(0, i + 1)
            val last = window.last()
            val prev = window.getOrNull(window.lastIndex - 1)
            val deriv = if (fundingHistory.isNotEmpty() || oiHistory.isNotEmpty()) {
                DerivativesFeatureEngine.build(
                    barTime = last.openTime,
                    close = last.close,
                    prevClose = prev?.close,
                    fundingHistory = fundingHistory,
                    oiHistory = oiHistory
                )
            } else null
            val (signals, _) = signalEngine.evaluate(window, deriv, perf)
            val signal = signals.firstOrNull { it.planId == planId }
            if (signal == null || signal.direction == BtcDirection.FLAT) {
                curve += equity
                i++
                continue
            }
            val direction = signal.direction
            val entryRaw = last.close
            val slip = config.slippagePct / 100.0
            val entry = if (direction == BtcDirection.UP) entryRaw * (1 + slip) else entryRaw * (1 - slip)
            val atrLike = (last.high - last.low).coerceAtLeast(entry * 0.001)
            val stopDistance = atrLike * 1.5
            val targetDistance = stopDistance * 2.0
            val sl = if (direction == BtcDirection.UP) entry - stopDistance else entry + stopDistance
            val tp = if (direction == BtcDirection.UP) entry + targetDistance else entry - targetDistance
            val riskCash = equity * (config.riskPerTradePct / 100.0)
            val riskPctPrice = (stopDistance / entry).coerceAtLeast(0.0001)
            val notional = riskCash / riskPctPrice

            var exit = entry
            var reason = "TIME"
            var holding = 0
            var mfe = 0.0
            var mae = 0.0
            var done = false
            while (holding < config.maxHoldingBars && i + holding + 1 <= to && !done) {
                val c = candles[i + holding + 1]
                val favorable = if (direction == BtcDirection.UP) (c.high - entry) / entry else (entry - c.low) / entry
                val adverse = if (direction == BtcDirection.UP) (entry - c.low) / entry else (c.high - entry) / entry
                mfe = max(mfe, favorable * 100.0)
                mae = max(mae, adverse * 100.0)
                holding++
                when {
                    direction == BtcDirection.UP && c.low <= sl -> {
                        exit = sl; reason = "SL"; done = true
                    }
                    direction == BtcDirection.DOWN && c.high >= sl -> {
                        exit = sl; reason = "SL"; done = true
                    }
                    direction == BtcDirection.UP && c.high >= tp -> {
                        exit = tp; reason = "TP"; done = true
                    }
                    direction == BtcDirection.DOWN && c.low <= tp -> {
                        exit = tp; reason = "TP"; done = true
                    }
                    holding >= config.maxHoldingBars || i + holding >= to -> {
                        exit = c.close; reason = "TIME"; done = true
                    }
                }
            }
            if (direction == BtcDirection.UP) exit *= (1 - slip) else exit *= (1 + slip)

            val grossPct = if (direction == BtcDirection.UP) {
                (exit - entry) / entry * 100.0
            } else {
                (entry - exit) / entry * 100.0
            }
            val feePct = config.feeRatePct * 2.0
            // Longs pay when funding > 0; shorts receive (approx)
            val fundingEvents = max(1, (holding + config.barsPerFunding - 1) / config.barsPerFunding)
            val liveFunding = fundingAt(fundingHistory, candles.getOrNull(i + holding)?.openTime ?: last.openTime)
            val fundingPct = if (fundingHistory.isEmpty()) {
                0.0
            } else if (direction == BtcDirection.UP) {
                liveFunding * 100.0 * fundingEvents
            } else {
                -liveFunding * 100.0 * fundingEvents
            }
            // Slippage is already applied to entry and exit prices above.
            // Do not subtract it a second time here.
            val pnlPct = grossPct - feePct - fundingPct
            val pnlCash = notional * pnlPct / 100.0
            equity += pnlCash
            peak = max(peak, equity)
            maxDd = max(maxDd, if (peak > 0) (peak - equity) / peak * 100.0 else 0.0)
            curve += equity
            totalFunding += fundingPct
            totalFee += feePct
            trades += BacktestTrade(
                barId = last.openTime,
                direction = direction,
                entry = entry,
                exit = exit,
                stopLoss = sl,
                takeProfit = tp,
                pnlPct = pnlPct,
                pnlCash = pnlCash,
                holdingBars = holding,
                mfePct = mfe,
                maePct = mae,
                reason = reason,
                feePct = feePct,
                fundingPct = fundingPct,
                slippagePct = config.slippagePct * 2.0
            )
            i += max(1, holding)
        }

        val grossProfit = trades.filter { it.pnlCash > 0 }.sumOf { it.pnlCash }
        val grossLoss = -trades.filter { it.pnlCash < 0 }.sumOf { it.pnlCash }
        val pf = when {
            grossLoss == 0.0 && grossProfit > 0 -> 99.0
            grossLoss == 0.0 -> 0.0
            else -> grossProfit / grossLoss
        }
        val tradeReturns = trades.map { it.pnlCash / config.initialEquity }
        val meanRet = tradeReturns.averageOrZero()
        val variance = if (tradeReturns.size > 1) tradeReturns.map { (it - meanRet) * (it - meanRet) }.sum() / (tradeReturns.size - 1) else 0.0
        val std = kotlin.math.sqrt(variance)
        val downside = tradeReturns.filter { it < 0.0 }
        val downsideDev = if (downside.isEmpty()) 0.0 else kotlin.math.sqrt(downside.map { it * it }.average())
        val sharpe = if (std > 1e-12) meanRet / std * kotlin.math.sqrt(trades.size.toDouble()) else 0.0
        val sortino = if (downsideDev > 1e-12) meanRet / downsideDev * kotlin.math.sqrt(trades.size.toDouble()) else 0.0
        val calmar = if (maxDd > 1e-12) ((equity / config.initialEquity - 1.0) * 100.0) / maxDd else 0.0
        val wins = trades.filter { it.pnlCash > 0.0 }
        val losses = trades.filter { it.pnlCash < 0.0 }
        val avgWin = wins.map { it.pnlCash }.averageOrZero()
        val avgLossAbs = -losses.map { it.pnlCash }.averageOrZero()
        val payoff = if (avgLossAbs > 1e-12) avgWin / avgLossAbs else 0.0
        val expectancy = trades.map { it.pnlCash }.averageOrZero()
        return BacktestResult(
            planId = planId,
            trades = trades,
            equityCurve = curve,
            totalReturnPct = (equity / config.initialEquity - 1.0) * 100.0,
            winRatePct = if (trades.isEmpty()) 0.0 else trades.count { it.pnlCash > 0 }.toDouble() / trades.size * 100.0,
            profitFactor = pf,
            maxDrawdownPct = maxDd,
            averagePnlPct = trades.map { it.pnlPct }.averageOrZero(),
            averageHoldingBars = trades.map { it.holdingBars.toDouble() }.averageOrZero(),
            averageMfePct = trades.map { it.mfePct }.averageOrZero(),
            averageMaePct = trades.map { it.maePct }.averageOrZero(),
            sampleSize = trades.size,
            totalFundingPct = totalFunding,
            totalFeePct = totalFee,
            sharpe = sharpe,
            sortino = sortino,
            calmar = calmar,
            expectancyCash = expectancy,
            payoffRatio = payoff
        )
    }

    fun walkForward(
        planId: String,
        candles: List<BtcCandle>,
        config: BacktestConfig = BacktestConfig(),
        fundingHistory: List<FundingPoint> = emptyList(),
        oiHistory: List<OpenInterestPoint> = emptyList()
    ): List<BacktestResult> {
        val results = mutableListOf<BacktestResult>()
        var trainEnd = max(80, config.walkForwardTrainBars)
        while (trainEnd + config.walkForwardTestBars < candles.size) {
            val testEnd = (trainEnd + config.walkForwardTestBars).coerceAtMost(candles.lastIndex)
            // train window performance → dynamic weights on test
            val trainRes = run(planId, candles, config, 0, trainEnd, fundingHistory, oiHistory)
            val perf = DynamicWeightEngine.fromBacktest(listOf(trainRes))
            results += run(
                planId, candles, config, trainEnd, testEnd,
                fundingHistory, oiHistory, perf
            ).copy(inSample = false)
            trainEnd += config.walkForwardTestBars
        }
        return results
    }

    fun attribution(results: List<BacktestResult>): List<PlanAttribution> =
        results.groupBy { it.planId }.map { (id, list) ->
            PlanAttribution(
                planId = id,
                trades = list.sumOf { it.sampleSize },
                netReturnPct = list.sumOf { it.totalReturnPct },
                fundingDragPct = list.sumOf { it.totalFundingPct },
                feeDragPct = list.sumOf { it.totalFeePct },
                profitFactor = list.map { it.profitFactor }.average(),
                maxDrawdownPct = list.maxOfOrNull { it.maxDrawdownPct } ?: 0.0
            )
        }

    private fun fundingAt(history: List<FundingPoint>, time: Long): Double {
        if (history.isEmpty()) return 0.0 // no funding data: do not invent a cost
        return history.lastOrNull { it.fundingTime <= time }?.fundingRate ?: history.last().fundingRate
    }

    private fun emptyResult(planId: String, equity: Double) =
        BacktestResult(planId, emptyList(), listOf(equity), 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0)

    private fun List<Double>.averageOrZero() = if (isEmpty()) 0.0 else average()
}
