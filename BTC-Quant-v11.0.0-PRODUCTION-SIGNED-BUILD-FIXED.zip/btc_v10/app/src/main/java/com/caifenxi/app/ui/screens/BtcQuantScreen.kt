package com.caifenxi.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.vector.ImageVector
import com.caifenxi.app.ui.BtcQuantViewModel

private enum class QuantTab(val label: String, val icon: ImageVector) {
    DASHBOARD("看板", Icons.Filled.Insights),
    DECISION("决策", Icons.Filled.AutoGraph),
    STRATEGY("策略", Icons.Filled.Analytics),
    TRADE("交易", Icons.Filled.AccountBalance),
    AUTO_TRADE("自注", Icons.Filled.AutoGraph),
    PAPER("模拟", Icons.Filled.MonetizationOn),
    BACKTEST("回测", Icons.Filled.History),
    FUTURES("合约", Icons.Filled.ShowChart),
    SETTINGS("设置", Icons.Filled.Settings),
    RESEARCH("研究", Icons.Filled.Search)
}

/**
 * BTC 量化交易主界面：多 Tab 架构（看板 / 策略 / 交易 / 自注 / 模拟 / 回测 / 设置）
 */
@Composable
fun BtcQuantScreen(viewModel: BtcQuantViewModel) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val dashboardState by viewModel.state.collectAsState()

    val terminalBg = Color(0xFF08090C)
    val panelBg = Color(0xFF101217)
    val cyan = Color(0xFF00E5FF)
    val muted = Color(0xFF737B88)

    Column(
        Modifier
            .fillMaxSize()
            .background(terminalBg)
    ) {
        // High-density terminal header: mirrors the reference image while remaining usable on phones.
        Row(
            Modifier
                .fillMaxWidth()
                .background(Color(0xFF050609))
                .padding(horizontal = 12.dp, vertical = 7.dp),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            Text("H", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text("BTC QUANT", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                Text("HS PREDICTION ENGINE // BTC 5m / 15m / 1h", color = muted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
            }
            val mode = dashboardState.hsSnapshot?.dataMode?.uppercase() ?: "OFFLINE"
            val statusLabel = when {
                mode == "DEMO" -> "DEMO"
                mode == "PAPER" -> "PAPER"
                mode == "LIVE_ACCOUNT" -> "ACCOUNT"
                mode == "LIVE" -> "LIVE"
                else -> mode
            }
            Text(statusLabel, color = if (statusLabel == "LIVE") cyan else muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }

        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            edgePadding = 4.dp,
            containerColor = panelBg,
            contentColor = Color.White
        ) {
            QuantTab.entries.forEach { tab ->
                Tab(
                    selected = selectedTab == tab.ordinal,
                    onClick = { selectedTab = tab.ordinal },
                    text = { Text(tab.label, fontSize = 11.sp, fontFamily = FontFamily.Monospace) },
                    icon = { Icon(tab.icon, contentDescription = tab.label, modifier = Modifier.padding(bottom = 1.dp)) }
                )
            }
        }

        when (selectedTab) {
            QuantTab.DASHBOARD.ordinal -> DashboardTab(viewModel)
            QuantTab.DECISION.ordinal -> DecisionCenterScreen(viewModel)
            QuantTab.STRATEGY.ordinal -> StrategyTab(viewModel)
            QuantTab.TRADE.ordinal -> TradeTab(viewModel)
            QuantTab.AUTO_TRADE.ordinal -> AutoTradeTab(viewModel)
            QuantTab.PAPER.ordinal -> PaperTradingTab(viewModel)
            QuantTab.BACKTEST.ordinal -> BacktestTab(viewModel)
            QuantTab.FUTURES.ordinal -> FuturesQuantTab(viewModel)
            QuantTab.SETTINGS.ordinal -> SettingsTab(viewModel)
            QuantTab.RESEARCH.ordinal -> ResearchCenterScreen(viewModel)
        }
    }
}
