package com.caifenxi.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.btc.hs.HsRuntimeConfig
import com.caifenxi.app.ui.BtcQuantViewModel
import com.caifenxi.app.ui.components.SectionTitle

@Composable
fun SettingsTab(viewModel: BtcQuantViewModel) {
    val state by viewModel.state.collectAsState()
    val exec by viewModel.executionStatus.collectAsState()
    val hsCfg by viewModel.hsRuntimeConfig.collectAsState()
    val readiness by viewModel.readiness.collectAsState()
    val hs = state.hsSnapshot
    val dq = hs?.dataQuality
    val cyan = Color(0xFF00E5FF)
    val red = Color(0xFFFF5252)
    val green = Color(0xFF69F0AE)
    val amber = Color(0xFFFFD54F)

    var minEdgePct by remember(hsCfg) { mutableStateOf((hsCfg.minNetEdge * 100).toFloat()) }
    var maxRiskPct by remember(hsCfg) { mutableStateOf((hsCfg.maxRiskFraction * 100).toFloat()) }
    var minOppPct by remember(hsCfg) { mutableStateOf((hsCfg.minOpportunityScore * 100).toFloat()) }
    var minDqPct by remember(hsCfg) { mutableStateOf((hsCfg.minDataQualityForLive * 100).toFloat()) }
    var feePct by remember(hsCfg) { mutableStateOf((hsCfg.feeRate * 100).toFloat()) }
    var maxNotional by remember(hsCfg) { mutableStateOf(hsCfg.maxNotionalUsdt.toFloat()) }

    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState())
    ) {
        SectionTitle("上线自检")
        Card(
            Modifier.padding(horizontal = 16.dp, vertical = 8.dp).fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                val report = readiness
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(
                        if (report?.readyForLive == true) "LIVE 就绪"
                        else if (report?.readyForPaper == true) "PAPER 可用"
                        else "未就绪",
                        fontWeight = FontWeight.Bold,
                        color = when {
                            report?.readyForLive == true -> green
                            report?.readyForPaper == true -> amber
                            else -> red
                        }
                    )
                    Text(
                        "得分 ${"%.0f".format((report?.score ?: 0.0) * 100)}%",
                        fontSize = 12.sp,
                        color = cyan
                    )
                }
                report?.items?.forEach { item ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(
                            "${if (item.ok) "✓" else "✗"} ${item.title}",
                            fontSize = 11.sp,
                            color = if (item.ok) green else red
                        )
                        Text(item.detail.take(36), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Button(
                    onClick = { viewModel.evaluateReadiness() },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("重新检测") }
            }
        }

        SectionTitle("执行风控")
        Card(
            Modifier.padding(horizontal = 16.dp, vertical = 8.dp).fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Kill Switch", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            if (exec.killSwitch) "已开启 — 禁止新开仓" else "关闭",
                            fontSize = 11.sp,
                            color = if (exec.killSwitch) red else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = exec.killSwitch,
                        onCheckedChange = { viewModel.setExecutionKillSwitch(it) },
                        colors = SwitchDefaults.colors(checkedTrackColor = red)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { viewModel.killRuntime() }, modifier = Modifier.weight(1f)) {
                        Text("全链路 KILL", color = red, fontSize = 12.sp)
                    }
                    OutlinedButton(onClick = { viewModel.resumeRuntime() }, modifier = Modifier.weight(1f)) {
                        Text("恢复运行", fontSize = 12.sp)
                    }
                }
                Text("最近裁决: ${exec.lastVerdictReason ?: "—"}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        SectionTitle("风控参数（即时生效）")
        Card(
            Modifier.padding(horizontal = 16.dp, vertical = 8.dp).fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ParamSlider("最小净 Edge %", minEdgePct, 1f..10f) { minEdgePct = it }
                ParamSlider("单笔最大风险 %", maxRiskPct, 0.5f..5f) { maxRiskPct = it }
                ParamSlider("最小机会分 %", minOppPct, 30f..90f) { minOppPct = it }
                ParamSlider("LIVE 质量分门槛 %", minDqPct, 50f..95f) { minDqPct = it }
                ParamSlider("费率 %", feePct, 0f..3f) { feePct = it }
                ParamSlider("单笔金额上限 U", maxNotional, 5f..500f) { maxNotional = it }
                Button(
                    onClick = {
                        viewModel.saveHsRuntimeConfig(
                            HsRuntimeConfig(
                                feeRate = feePct / 100.0,
                                minNetEdge = minEdgePct / 100.0,
                                maxRiskFraction = maxRiskPct / 100.0,
                                minOpportunityScore = minOppPct / 100.0,
                                minDataQualityForLive = minDqPct / 100.0,
                                maxNotionalUsdt = maxNotional.toDouble(),
                                kellyFraction = hsCfg.kellyFraction,
                                latencySec = hsCfg.latencySec,
                                minNotionalUsdt = hsCfg.minNotionalUsdt,
                                minModelHitRate = hsCfg.minModelHitRate,
                                maxBrierScore = hsCfg.maxBrierScore,
                                mlCacheTtlMs = hsCfg.mlCacheTtlMs,
                                dailyLossKillPct = hsCfg.dailyLossKillPct
                            )
                        )
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("保存参数") }
            }
        }

        SectionTitle("数据质量门")
        Card(
            Modifier.padding(horizontal = 16.dp, vertical = 8.dp).fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("质量分 ${"%.0f".format((dq?.score ?: hs?.dataQualityScore ?: 0.0) * 100)}%", fontWeight = FontWeight.Bold, color = cyan)
                    val liveOk = dq?.liveTradeAllowed == true
                    Text(if (liveOk) "LIVE 允许" else "LIVE 禁止", color = if (liveOk) green else red, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                }
                val blocks = dq?.blockReasons.orEmpty()
                if (blocks.isEmpty()) Text("无阻断原因", fontSize = 11.sp, color = green)
                else blocks.forEach { Text("· $it", fontSize = 11.sp, color = red) }
                dq?.sources?.forEach { src ->
                    val c = when (src.status.name) {
                        "LIVE" -> green; "DEGRADED", "STALE" -> amber; else -> red
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(src.name, fontSize = 11.sp)
                        Text("${src.status}", fontSize = 10.sp, color = c)
                    }
                }
            }
        }

        SectionTitle("落地步骤")
        Card(
            Modifier.padding(horizontal = 16.dp, vertical = 8.dp).fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Text(
                """
                1. PAPER 模式跑通：看板有 p_hat、门控为 GATE OPEN
                2. 自注 Tab 启动运行时，观察日志无「执行门控」狂刷
                3. 配置 API（设置/密钥），连通性测试通过
                4. 上线自检全部打勾后，再输入确认语授权 LIVE
                5. 随时可用 Kill Switch / 全链路 KILL 停机
                """.trimIndent(),
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(16.dp)
            )
        }

        SectionTitle("关于")
        Card(Modifier.padding(horizontal = 16.dp, vertical = 8.dp).fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("BTC Quant v11.0.0", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("可落地：自检 · 门控 · 半凯利 · 前台服务", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.height(40.dp))
    }
}

@Composable
private fun ParamSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, fontSize = 11.sp)
            Text("%.2f".format(value), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}
