package com.caifenxi.app.domain.btc.hs

/**
 * HS 运行时统一配置 —— 费用 / 延迟 / 仓位 / 质量门 / 机会分阈值
 * 全部用 0–1 比率（概率、edge、kelly、fee），UI 层再乘 100 显示。
 */
data class HsRuntimeConfig(
    /** Polymarket/交易费率（占成交价比例） */
    val feeRate: Double = 0.01,
    /** 预期端到端延迟（秒），用于成本估计 */
    val latencySec: Double = 2.0,
    /** 可执行净 Edge 下限 */
    val minNetEdge: Double = 0.03,
    /** 半凯利系数 */
    val kellyFraction: Double = 0.5,
    /** 单笔最大占净值比例（硬上限 2%） */
    val maxRiskFraction: Double = 0.02,
    /** 单笔绝对金额上限 */
    val maxNotionalUsdt: Double = 200.0,
    /** 单笔最小金额 */
    val minNotionalUsdt: Double = 1.0,
    /** 数据质量分低于此值禁止 LIVE 下单 */
    val minDataQualityForLive: Double = 0.75,
    /** 机会分低于此值 multiplier=0 */
    val minOpportunityScore: Double = 0.60,
    /** 模型 hitRate 低于此值降权 */
    val minModelHitRate: Double = 0.52,
    /** Brier 高于此值降权 */
    val maxBrierScore: Double = 0.25,
    /** ML 缓存有效期：同一根 bar 内不重训（ms） */
    val mlCacheTtlMs: Long = 55_000L,
    /** 日损失熔断（占日初净值） */
    val dailyLossKillPct: Double = 0.05
) {
    companion object {
        val Default = HsRuntimeConfig()
    }
}

/** 进程内共享当前配置，设置页保存后即时生效 */
object HsRuntimeConfigHolder {
    @Volatile
    var current: HsRuntimeConfig = HsRuntimeConfig.Default
        private set

    fun update(c: HsRuntimeConfig) {
        current = c.copy(
            maxRiskFraction = c.maxRiskFraction.coerceIn(0.005, 0.05),
            minNetEdge = c.minNetEdge.coerceIn(0.005, 0.15),
            minDataQualityForLive = c.minDataQualityForLive.coerceIn(0.4, 0.95),
            minOpportunityScore = c.minOpportunityScore.coerceIn(0.3, 0.9)
        )
    }
}
