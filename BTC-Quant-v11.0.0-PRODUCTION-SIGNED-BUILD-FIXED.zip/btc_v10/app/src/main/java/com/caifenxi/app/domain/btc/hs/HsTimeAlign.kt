package com.caifenxi.app.domain.btc.hs

import com.caifenxi.app.domain.btc.BtcCandle

/**
 * 多周期 K 线时间对齐工具。
 * 决策时钟默认对齐到 5m 边界，计算各周期最后一根 bar 与时钟的偏差。
 */
object HsTimeAlign {
    /** 5 分钟毫秒 */
    const val FIVE_MIN_MS = 5L * 60_000L

    fun floorTo5m(ts: Long): Long = ts - (ts % FIVE_MIN_MS)

    /**
     * @return 最大对齐误差（ms）；无数据返回 Long.MAX_VALUE
     */
    fun maxAlignErrorMs(
        c5: List<BtcCandle>,
        c15: List<BtcCandle>,
        c1h: List<BtcCandle>
    ): Long {
        val t5 = c5.lastOrNull()?.openTime ?: return Long.MAX_VALUE
        val clock = floorTo5m(t5)
        val times = listOfNotNull(
            c5.lastOrNull()?.openTime,
            c15.lastOrNull()?.openTime,
            c1h.lastOrNull()?.openTime
        )
        if (times.isEmpty()) return Long.MAX_VALUE
        return times.maxOf { kotlin.math.abs(it - clock) }
    }

    /** 截断到 clock 及之前的已收盘 bar（openTime <= clock） */
    fun closedBarsUntil(candles: List<BtcCandle>, clock: Long): List<BtcCandle> =
        candles.filter { it.openTime <= clock }
}
