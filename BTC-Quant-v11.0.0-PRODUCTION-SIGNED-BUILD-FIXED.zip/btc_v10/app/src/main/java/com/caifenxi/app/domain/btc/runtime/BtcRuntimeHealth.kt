package com.caifenxi.app.domain.btc.runtime

/** Runtime health snapshot used by the dashboard and watchdog. */
data class BtcRuntimeHealth(
    val heartbeatOk: Boolean,
    val dataOk: Boolean,
    val brokerOk: Boolean,
    val riskOk: Boolean,
    val staleSeconds: Long,
    val consecutiveErrors: Int,
    val status: BtcRuntimeStatus
) {
    val healthy: Boolean get() = heartbeatOk && dataOk && brokerOk && riskOk && status != BtcRuntimeStatus.KILLED
}

object BtcRuntimeHealthEvaluator {
    fun evaluate(
        state: BtcRuntimeState,
        now: Long = System.currentTimeMillis(),
        heartbeatTimeoutMs: Long = 90_000L,
        dataOk: Boolean = state.lastBarId > 0L,
        brokerOk: Boolean = true,
        riskOk: Boolean = state.status != BtcRuntimeStatus.PAUSED || state.lastError?.contains("熔断") != true
    ): BtcRuntimeHealth {
        val stale = if (state.lastHeartbeatAt <= 0L) Long.MAX_VALUE else ((now - state.lastHeartbeatAt) / 1000L).coerceAtLeast(0L)
        return BtcRuntimeHealth(
            heartbeatOk = now - state.lastHeartbeatAt <= heartbeatTimeoutMs,
            dataOk = dataOk,
            brokerOk = brokerOk,
            riskOk = riskOk,
            staleSeconds = stale,
            consecutiveErrors = state.consecutiveErrors,
            status = state.status
        )
    }
}
