package com.caifenxi.app.domain.btc

import com.caifenxi.app.domain.btc.hs.HsPredictionSnapshot
import kotlin.math.abs

enum class BtcDirection { UP, DOWN, FLAT }
enum class MarketRegime { TREND_UP, TREND_DOWN, RANGE, BREAKOUT, HIGH_VOLATILITY }
enum class BtcPlanFamily { TREND, MOMENTUM, STRUCTURE, VOLUME, VOLATILITY, DERIVATIVES, AI }

data class BtcCandle(
    val openTime: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double
)

data class BtcPlanSignal(
    val planId: String,
    val name: String,
    val family: BtcPlanFamily,
    val direction: BtcDirection,
    val rawScore: Double,
    val confidence: Double,
    val weight: Double,
    val hitRate: Double,
    val samples: Int,
    val regimeFit: Double,
    val contribution: Double
)

data class BtcConsensus(
    val direction: BtcDirection,
    val probability: Double,
    val consensusStrength: Double,
    val upScore: Double,
    val downScore: Double,
    val flatScore: Double,
    val regime: MarketRegime,
    val trendScore: Double,
    val volatility: Double,
    val expectedMovePct: Double,
    val riskScore: Double
)

data class BtcDashboardState(
    val symbol: String = "BTCUSDT",
    val timeframe: String = "15m",
    val candles: List<BtcCandle> = emptyList(),
    val plans: List<BtcPlanSignal> = emptyList(),
    val consensus: BtcConsensus? = null,
    val loading: Boolean = false,
    val error: String? = null,
    val updatedAt: Long = 0L,
    val newsNetSentiment: Double? = null,
    val newsBlackSwan: Boolean = false,
    val newsHeadlines: List<String> = emptyList(),
    val aiDirection: BtcDirection? = null,
    val aiConfidence: Double? = null,
    val aiJson: String? = null,
    val aiLiveAllowed: Boolean = false,
    val fundingRate: Double? = null,
    val fundingZScore: Double? = null,
    val fundingExtreme: Boolean = false,
    val oiChangePct: Double? = null,
    val derivativesScore: Double? = null,
    val markPrice: Double? = null,
    val connectorNote: String? = null,
    val isDemoMode: Boolean = false,
    /** HS Prediction Engine 实时快照（驱动新看板） */
    val hsSnapshot: HsPredictionSnapshot? = null
)

internal fun clamp01(v: Double) = v.coerceIn(0.0, 1.0)
internal fun signedDirection(score: Double, threshold: Double = 0.08): BtcDirection = when {
    score > threshold -> BtcDirection.UP
    score < -threshold -> BtcDirection.DOWN
    else -> BtcDirection.FLAT
}
internal fun directionAgreement(score: Double, direction: BtcDirection): Double = when (direction) {
    BtcDirection.UP -> clamp01((score + 1.0) / 2.0)
    BtcDirection.DOWN -> clamp01((1.0 - score) / 2.0)
    BtcDirection.FLAT -> clamp01(1.0 - abs(score))
}
