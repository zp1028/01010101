package com.caifenxi.app.domain.btc.portfolio

import com.caifenxi.app.domain.btc.BtcDirection
import kotlin.math.abs

/** Portfolio-level allocator: combines independent engines without letting one view dominate. */
class PortfolioDecisionEngine(
    private val maxGrossExposureUsdt: Double = 500.0,
    private val maxDirectionalExposureUsdt: Double = 400.0
) {
    data class EngineView(val engine: String, val direction: BtcDirection, val confidence: Double, val exposureUsdt: Double)
    data class Decision(val direction: BtcDirection, val confidence: Double, val allowedExposureUsdt: Double, val reason: String)

    fun combine(views: List<EngineView>, currentNetExposureUsdt: Double = 0.0): Decision {
        val usable = views.filter { it.confidence.isFinite() && it.exposureUsdt > 0.0 && it.direction != BtcDirection.FLAT }
        if (usable.isEmpty()) return Decision(BtcDirection.FLAT, 0.0, 0.0, "无有效引擎观点")
        val up = usable.filter { it.direction == BtcDirection.UP }.sumOf { it.confidence.coerceIn(0.0, 1.0) * it.exposureUsdt }
        val down = usable.filter { it.direction == BtcDirection.DOWN }.sumOf { it.confidence.coerceIn(0.0, 1.0) * it.exposureUsdt }
        val total = up + down
        if (total <= 0.0) return Decision(BtcDirection.FLAT, 0.0, 0.0, "组合信号无效")
        val direction = if (up >= down) BtcDirection.UP else BtcDirection.DOWN
        val dominance = (maxOf(up, down) / total).coerceIn(0.0, 1.0)
        val grossRoom = (maxGrossExposureUsdt - usable.sumOf { it.exposureUsdt }).coerceAtLeast(0.0)
        val directionalRoom = (maxDirectionalExposureUsdt - abs(currentNetExposureUsdt)).coerceAtLeast(0.0)
        val allowed = minOf(grossRoom, directionalRoom)
        return Decision(direction, dominance, allowed, "${usable.size}个引擎；主方向占比${"%.1f".format(dominance * 100)}%")
    }
}
