package com.caifenxi.app.domain.btc.runtime

import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/** Durable-in-process execution identity. The same decision cannot produce two tickets. */
data class BtcExecutionTicket(
    val executionId: String,
    val decisionId: String,
    val symbol: String,
    val timeframe: String,
    val barId: Long,
    val action: String,
    val clientOrderId: String,
    val createdAt: Long = System.currentTimeMillis()
)

class BtcExecutionTicketStore {
    private val byDecision = ConcurrentHashMap<String, BtcExecutionTicket>()

    fun claim(decisionId: String, symbol: String, timeframe: String, barId: Long, action: String): BtcExecutionTicket? {
        val existing = byDecision[decisionId]
        if (existing != null) return null
        val ticket = BtcExecutionTicket(
            executionId = "EX-${stableId(decisionId)}",
            decisionId = decisionId,
            symbol = symbol,
            timeframe = timeframe,
            barId = barId,
            action = action,
            clientOrderId = "CO-${stableId(decisionId)}".take(36)
        )
        return if (byDecision.putIfAbsent(decisionId, ticket) == null) ticket else null
    }

    private fun stableId(value: String): String =
        MessageDigest.getInstance("SHA-256").digest(value.toByteArray()).joinToString("") { "%02x".format(it) }.take(24)

    fun contains(decisionId: String): Boolean = byDecision.containsKey(decisionId)
    fun clear(decisionId: String) { byDecision.remove(decisionId) }
}
