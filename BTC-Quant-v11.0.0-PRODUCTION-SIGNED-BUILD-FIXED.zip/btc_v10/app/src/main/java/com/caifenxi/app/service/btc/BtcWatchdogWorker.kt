package com.caifenxi.app.service.btc

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.caifenxi.app.domain.btc.runtime.BtcRuntimeStatus
import com.caifenxi.app.domain.btc.runtime.BtcRuntimeStore
import com.caifenxi.app.domain.btc.runtime.BtcRuntimeHealthEvaluator

/** Periodic watchdog. Android WorkManager is a watchdog, not the trading clock. */
class BtcWatchdogWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val store = BtcRuntimeStore(applicationContext)
        val state = store.state()
        if (state.status == BtcRuntimeStatus.RUNNING && state.lastHeartbeatAt > 0L) {
            val health = BtcRuntimeHealthEvaluator.evaluate(state, heartbeatTimeoutMs = 5 * 60_000L)
            if (!health.heartbeatOk) store.update { it.copy(status = BtcRuntimeStatus.ERROR, lastError = "运行心跳超时（${health.staleSeconds}s）") }
        }
        return Result.success()
    }
}
