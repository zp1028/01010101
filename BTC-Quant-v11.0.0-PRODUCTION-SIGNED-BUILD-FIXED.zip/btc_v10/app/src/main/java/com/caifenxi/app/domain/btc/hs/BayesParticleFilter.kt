package com.caifenxi.app.domain.btc.hs

import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * 贝叶斯粒子滤波器 —— 驱动截图中的 BAYES PARTICLE FIELD
 *
 * 状态空间：隐含上涨概率 s ∈ (0,1)
 * 过程模型：s_t = s_{t-1} + v·Δt + σ·ε   (带漂移的随机游走，logit 空间)
 * 观测模型：技术/衍生品/盘口 观测似然 → 重加权
 * 重采样：系统重采样，保持有效样本量
 */
class BayesParticleFilter(
    private val nParticles: Int = 64,
    private val processNoise: Double = 0.04,
    private val observationNoise: Double = 0.08,
    private val rng: Random = Random.Default
) {
    private var particles: MutableList<BayesParticle> = MutableList(nParticles) {
        BayesParticle(weight = 1.0 / nParticles, state = 0.5, velocity = 0.0)
    }

    fun fieldState(): BayesParticleFieldState {
        val mean = weightedMean()
        val std = weightedStd(mean)
        val ess = effectiveSampleSize()
        val trigger = (mean - 0.5).let { d ->
            // 触发强度：偏离 0.5 越大 + ESS 越高 → 越强
            (kotlin.math.abs(d) * 80.0 + (ess / nParticles) * 20.0).coerceIn(0.0, 99.0)
        }
        return BayesParticleFieldState(
            particles = particles.toList(),
            mean = mean,
            std = std,
            trigger = trigger,
            effectiveSampleSize = ess
        )
    }

    /**
     * 一步更新：预测 → 用观测似然重加权 → 必要时重采样
     * @param observation 观测到的“上涨倾向” [0,1]（来自技术+衍生品+盘口综合）
     * @param confidence  观测置信度 [0,1]
     */
    fun update(observation: Double, confidence: Double = 0.6): BayesParticleFieldState {
        val obs = observation.coerceIn(0.02, 0.98)
        val conf = confidence.coerceIn(0.05, 1.0)

        // 1) 预测（logit 空间随机游走）
        particles = particles.map { p ->
            val logit = logit(p.state)
            val newLogit = logit + p.velocity + rng.nextGaussian() * processNoise
            val newState = sigmoid(newLogit).coerceIn(0.02, 0.98)
            val newVel = p.velocity * 0.85 + rng.nextGaussian() * processNoise * 0.3
            p.copy(state = newState, velocity = newVel)
        }.toMutableList()

        // 2) 似然重加权（高斯似然在概率空间）
        val sigma = observationNoise / conf.coerceAtLeast(0.2)
        var sumW = 0.0
        particles = particles.map { p ->
            val diff = p.state - obs
            val lik = exp(-0.5 * (diff * diff) / (sigma * sigma))
            val w = (p.weight * lik).coerceAtLeast(1e-12)
            sumW += w
            p.copy(weight = w)
        }.toMutableList()
        particles = particles.map { it.copy(weight = it.weight / sumW) }.toMutableList()

        // 3) 有效样本量过低则系统重采样
        if (effectiveSampleSize() < nParticles * 0.45) {
            resampleSystematic()
        }
        return fieldState()
    }

    fun reset(priorMean: Double = 0.5) {
        particles = MutableList(nParticles) {
            val s = (priorMean + rng.nextGaussian() * 0.08).coerceIn(0.05, 0.95)
            BayesParticle(1.0 / nParticles, s, 0.0)
        }
    }

    private fun weightedMean(): Double = particles.sumOf { it.weight * it.state }

    private fun weightedStd(mean: Double): Double {
        val v = particles.sumOf { it.weight * (it.state - mean) * (it.state - mean) }
        return sqrt(v.coerceAtLeast(0.0))
    }

    private fun effectiveSampleSize(): Double {
        val sumSq = particles.sumOf { it.weight * it.weight }
        return if (sumSq <= 0) 0.0 else 1.0 / sumSq
    }

    private fun resampleSystematic() {
        val n = nParticles
        val cdf = DoubleArray(n)
        cdf[0] = particles[0].weight
        for (i in 1 until n) cdf[i] = cdf[i - 1] + particles[i].weight
        val step = 1.0 / n
        var u = rng.nextDouble() * step
        val newList = ArrayList<BayesParticle>(n)
        var i = 0
        repeat(n) {
            while (u > cdf[i] && i < n - 1) i++
            newList += particles[i].copy(weight = 1.0 / n)
            u += step
        }
        particles = newList
    }

    private fun logit(p: Double): Double {
        val x = p.coerceIn(1e-6, 1 - 1e-6)
        return ln(x / (1 - x))
    }

    private fun sigmoid(z: Double): Double = 1.0 / (1.0 + exp(-z.coerceIn(-20.0, 20.0)))

    private fun Random.nextGaussian(): Double {
        // Box-Muller
        val u = nextDouble().coerceAtLeast(1e-12)
        val v = nextDouble()
        return sqrt(-2.0 * ln(u)) * kotlin.math.cos(2.0 * Math.PI * v)
    }
}
