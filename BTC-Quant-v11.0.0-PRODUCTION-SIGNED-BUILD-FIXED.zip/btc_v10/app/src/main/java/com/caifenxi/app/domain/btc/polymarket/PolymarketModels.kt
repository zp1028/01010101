package com.caifenxi.app.domain.btc.polymarket

data class PolyMarket(
    val conditionId: String,
    val question: String,
    val slug: String,
    val description: String = "",
    val priceToBeat: Double? = null,
    val startDateMs: Long? = null,
    val yesTokenId: String,
    val noTokenId: String,
    val yesPrice: Double,
    val noPrice: Double,
    val endDateMs: Long?,
    val closed: Boolean,
    val enableOrderBook: Boolean,
    val negRisk: Boolean = false,
    val tickSize: Double = 0.01,
    val minOrderSize: Double = 1.0
)

data class PolyBookLevel(val price: Double, val size: Double)

data class PolyOrderBook(
    val tokenId: String,
    val bids: List<PolyBookLevel>,
    val asks: List<PolyBookLevel>,
    val tickSize: Double,
    val minOrderSize: Double,
    val negRisk: Boolean
) {
    val bestBid: Double? get() = bids.maxByOrNull { it.price }?.price
    val bestAsk: Double? get() = asks.minByOrNull { it.price }?.price
    val mid: Double?
        get() {
            val b = bestBid; val a = bestAsk
            return if (b != null && a != null) (b + a) / 2.0 else a ?: b
        }
    val spread: Double
        get() {
            val b = bestBid; val a = bestAsk
            return if (b != null && a != null) (a - b).coerceAtLeast(0.0) else 1.0
        }
}

data class PolyEdgeOpportunity(
    val market: PolyMarket,
    val outcome: String, // YES / NO
    val tokenId: String,
    val marketP: Double,
    val modelP: Double,
    val tradePrice: Double,
    val edge: Double,
    val ev: Double,
    val spread: Double,
    val liquidityScore: Double,
    val timeToResolutionSec: Long,
    val action: String, // BUY / NO_TRADE
    val reason: String
)
