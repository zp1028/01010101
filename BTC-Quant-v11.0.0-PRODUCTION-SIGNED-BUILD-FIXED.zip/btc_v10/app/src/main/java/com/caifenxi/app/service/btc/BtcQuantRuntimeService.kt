package com.caifenxi.app.service.btc

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.caifenxi.app.R
import com.caifenxi.app.domain.btc.broker.BrokerCredentialStore
import com.caifenxi.app.domain.btc.broker.BrokerFactory
import com.caifenxi.app.domain.btc.broker.DailyPnlStore
import com.caifenxi.app.domain.btc.broker.BinanceFuturesEndpoint
import com.caifenxi.app.domain.btc.broker.PaperPerpBroker
import com.caifenxi.app.domain.btc.runtime.BtcRunMode
import com.caifenxi.app.domain.btc.runtime.BtcRuntimeController
import com.caifenxi.app.domain.btc.runtime.BtcRuntimeStore
import com.caifenxi.app.domain.btc.runtime.LiveUnattendedGuard
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * 前台服务驱动量化循环。
 * LIVE 模式必须：已授权 + API Key + Guard 通过；连续失败会自动 KILL。
 */
class BtcQuantRuntimeService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var loopJob: Job? = null
    private lateinit var store: BtcRuntimeStore
    private lateinit var dailyPnl: DailyPnlStore
    private lateinit var credStore: BrokerCredentialStore

    override fun onCreate() {
        super.onCreate()
        store = BtcRuntimeStore(this)
        dailyPnl = DailyPnlStore(this)
        credStore = BrokerCredentialStore(this)
        createChannel()
        startForeground(NOTIFICATION_ID, notification("BTC Quant · 初始化"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopRuntime()
            ACTION_KILL -> {
                store.setKillSwitch(true)
                stopRuntime()
            }
            ACTION_RESUME -> {
                store.setKillSwitch(false)
                startRuntime()
            }
            else -> startRuntime()
        }
        return START_STICKY
    }

    private fun startRuntime() {
        val cfg = store.config()
        if (!cfg.enabled || store.state().killSwitch) {
            stopRuntime()
            return
        }
        val creds = credStore.load()
        val startGate = LiveUnattendedGuard.authorizeStart(cfg, creds, store.state())
        if (!startGate.allowed) {
            store.update {
                it.copy(
                    status = com.caifenxi.app.domain.btc.runtime.BtcRuntimeStatus.ERROR,
                    lastError = startGate.reason
                )
            }
            updateNotification("拒绝启动: ${startGate.reason}")
            // PAPER 外失败直接停，避免空转
            if (cfg.runMode != BtcRunMode.PAPER) {
                stopRuntime()
                return
            }
        }
        if (loopJob?.isActive == true) return
        store.update {
            it.copy(
                status = com.caifenxi.app.domain.btc.runtime.BtcRuntimeStatus.RUNNING,
                lastError = null,
                consecutiveErrors = 0
            )
        }
        val broker = when (cfg.runMode) {
            BtcRunMode.PAPER -> PaperPerpBroker()
            BtcRunMode.TESTNET -> {
                if (creds.binanceEndpoint != BinanceFuturesEndpoint.TESTNET) {
                    store.update { it.copy(status = com.caifenxi.app.domain.btc.runtime.BtcRuntimeStatus.ERROR, lastError = "TESTNET 模式要求 Binance TESTNET endpoint") }
                    stopRuntime(); return
                }
                runCatching { BrokerFactory.perp(creds) }.getOrElse { error ->
                    store.update { it.copy(status = com.caifenxi.app.domain.btc.runtime.BtcRuntimeStatus.ERROR, lastError = error.message ?: "TESTNET Broker 初始化失败") }
                    stopRuntime(); return
                }
            }
            BtcRunMode.LIVE -> {
                if (creds.binanceEndpoint != BinanceFuturesEndpoint.MAINNET) {
                    store.update { it.copy(status = com.caifenxi.app.domain.btc.runtime.BtcRuntimeStatus.ERROR, lastError = "LIVE 模式要求 Binance MAINNET endpoint") }
                    stopRuntime(); return
                }
                runCatching { BrokerFactory.perp(creds) }.getOrElse { error ->
                    store.update { it.copy(status = com.caifenxi.app.domain.btc.runtime.BtcRuntimeStatus.ERROR, lastError = error.message ?: "LIVE Broker 初始化失败") }
                    stopRuntime(); return
                }
            }
        }
        loopJob = scope.launch {
            val controller = BtcRuntimeController(
                store = store,
                broker = broker,
                dayRealizedPnlProvider = { dailyPnl.realizedPnlToday() }
            )
            while (!store.state().killSwitch && store.config().enabled && this.isActive) {
                val c = store.config()
                runCatching { controller.runOnce() }.onFailure { e ->
                    store.update {
                        it.copy(
                            lastError = e.message ?: "loop error",
                            consecutiveErrors = it.consecutiveErrors + 1
                        )
                    }
                }
                val st = store.state()
                if (st.killSwitch || st.consecutiveErrors >= c.maxConsecutiveErrors && c.runMode != BtcRunMode.PAPER) {
                    store.setKillSwitch(true)
                    updateNotification("已熔断停止: ${st.lastError ?: "consecutive errors"}")
                    break
                }
                val delayMs = c.pollSeconds.coerceIn(10L, 120L) * 1000L
                kotlinx.coroutines.delay(delayMs)
            }
            stopRuntime()
        }
        val modeLabel = when (cfg.runMode) {
            BtcRunMode.PAPER -> "PAPER"
            BtcRunMode.TESTNET -> "TESTNET"
            BtcRunMode.LIVE -> "LIVE⚠"
        }
        updateNotification("BTC Quant · $modeLabel · ${cfg.symbol} ${cfg.timeframe} · 轮询${cfg.pollSeconds}s")
    }

    private fun stopRuntime() {
        loopJob?.cancel()
        loopJob = null
        val killed = store.state().killSwitch
        store.update {
            it.copy(
                status = if (killed)
                    com.caifenxi.app.domain.btc.runtime.BtcRuntimeStatus.KILLED
                else
                    com.caifenxi.app.domain.btc.runtime.BtcRuntimeStatus.STOPPED
            )
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        loopJob?.cancel()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "BTC Quant Runtime", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun notification(text: String): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("BTC Quant")
            .setContentText(text)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(text))
    }

    companion object {
        const val ACTION_STOP = "com.caifenxi.btcquant.STOP"
        const val ACTION_KILL = "com.caifenxi.btcquant.KILL"
        const val ACTION_RESUME = "com.caifenxi.btcquant.RESUME"
        private const val CHANNEL_ID = "btc_quant_runtime"
        private const val NOTIFICATION_ID = 4201
    }
}
