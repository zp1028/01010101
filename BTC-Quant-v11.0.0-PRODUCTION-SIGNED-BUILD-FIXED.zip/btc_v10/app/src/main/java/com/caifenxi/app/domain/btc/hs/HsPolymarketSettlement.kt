package com.caifenxi.app.domain.btc.hs

import com.caifenxi.app.domain.btc.polymarket.PolyMarket

/** Resolution helper: only accepts an explicitly closed market with a binary outcome price. */
object HsPolymarketSettlement {
    enum class Outcome { YES, NO, UNKNOWN }
    data class Resolution(val marketId: String, val outcome: Outcome, val resolvedAt: Long, val source: String)

    fun resolve(market: PolyMarket, now: Long = System.currentTimeMillis()): Resolution? {
        if (!market.closed) return null
        val y = market.yesPrice; val n = market.noPrice
        val outcome = when {
            y >= 0.999 && n <= 0.001 -> Outcome.YES
            n >= 0.999 && y <= 0.001 -> Outcome.NO
            else -> Outcome.UNKNOWN
        }
        if (outcome == Outcome.UNKNOWN) return null
        return Resolution(market.conditionId, outcome, now, "Polymarket closed outcomePrices")
    }
}
