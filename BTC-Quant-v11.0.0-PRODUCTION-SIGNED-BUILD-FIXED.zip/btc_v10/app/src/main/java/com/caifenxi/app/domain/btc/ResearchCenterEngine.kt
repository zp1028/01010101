package com.caifenxi.app.domain.btc

import com.caifenxi.app.domain.btc.hs.ExecutableEdgeEngine
import com.caifenxi.app.domain.btc.hs.HsPredictionSnapshot
import com.caifenxi.app.domain.btc.portfolio.PortfolioExposureEngine
import kotlin.math.abs

object ResearchCenterEngine {
    data class Report(
        val dataQualityPct: Double,
        val rawEdgePct: Double,
        val netEdgePct: Double,
        val executable: Boolean,
        val regime: String,
        val pHatPct: Double,
        val direction: String,
        val exposure: PortfolioExposureEngine.Snapshot,
        val signalTtlMinutes: Int,
        val risks: List<String>
    )

    fun build(snapshot: HsPredictionSnapshot, requestedNotional: Double = 25.0): Report {
        val tf = snapshot.phatFor("5m")
        val ask = tf.bestAsk ?: tf.marketYes.coerceIn(0.01, 0.99)
        val bid = tf.bestBid ?: tf.marketYes.coerceIn(0.01, 0.99)
        val edge = ExecutableEdgeEngine.evaluate(
            probability = tf.pHat,
            ask = ask,
            bid = bid,
            depthQuote = minOf(tf.depthAsk, tf.depthBid).coerceAtLeast(0.0),
            requestedNotional = requestedNotional
        )
        val legs = buildList {
            add(PortfolioExposureEngine.Leg("5m", if (snapshot.primaryDirection == BtcDirection.DOWN) -tf.bucket else tf.bucket))
            add(PortfolioExposureEngine.Leg("15m", if (snapshot.tf15m.pHat >= 0.5) snapshot.tf15m.bucket else -snapshot.tf15m.bucket))
            add(PortfolioExposureEngine.Leg("1h", if (snapshot.tf1h.pHat >= 0.5) snapshot.tf1h.bucket else -snapshot.tf1h.bucket))
        }
        val exposure = PortfolioExposureEngine.evaluate(legs, 400.0)
        val risks = buildList {
            snapshot.dataQuality?.sources?.filter { it.status != com.caifenxi.app.domain.btc.hs.HsDataQualityEngine.Status.LIVE }?.forEach { add("${it.name}: ${it.status}") }
            if (edge.cost.total > 0.05) add("交易成本偏高")
            if (exposure.concentration > 0.8) add("方向暴露集中")
            if (snapshot.maxDrawdownPct > 8.0) add("历史回撤偏高")
        }
        return Report(snapshot.dataQualityScore * 100, edge.rawEdge * 100, edge.netEdge * 100, edge.executable,
            tf.regime.name, tf.pHat * 100, snapshot.primaryDirection.name, exposure,
            if (snapshot.tf5m.action == "NO_TRADE") 0 else 5, risks.take(6))
    }
}
