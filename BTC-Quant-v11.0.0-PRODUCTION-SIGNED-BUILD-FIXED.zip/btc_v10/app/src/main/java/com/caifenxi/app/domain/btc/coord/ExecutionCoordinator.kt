package com.caifenxi.app.domain.btc.coord

import com.caifenxi.app.domain.btc.hs.HsRuntimeConfig
import com.caifenxi.app.domain.btc.hs.HsRuntimeConfigHolder
import com.caifenxi.app.domain.btc.hs.HsPredictionSnapshot

/**
 * 执行协调器 —— 幂等键、冷却、Kill Switch、数据门检查
 */
class ExecutionCoordinator(
    private val config: () -> HsRuntimeConfig = { HsRuntimeConfigHolder.current }
) {
    data class Verdict(
        val allowed: Boolean,
        val reason: String,
        val idempotencyKey: String?
    )

    data class Status(
        val killSwitch: Boolean,
        val lastOrderAtMs: Long,
        val placedKeyCount: Int,
        val lastVerdictReason: String?
    )

    private var lastOrderAtMs: Long = 0L
    private val placedKeys = LinkedHashSet<String>()
    @Volatile private var killSwitch: Boolean = false
    @Volatile private var lastVerdictReason: String? = null

    fun setKillSwitch(on: Boolean) { killSwitch = on }
    fun isKillSwitchOn(): Boolean = killSwitch

    fun status(): Status = Status(killSwitch, lastOrderAtMs, placedKeys.size, lastVerdictReason)

    fun canExecute(
        snapshot: HsPredictionSnapshot,
        marketId: String,
        direction: String,
        windowId: String,
        nowMs: Long = System.currentTimeMillis(),
        cooldownMs: Long = 15_000L
    ): Verdict {
        if (killSwitch) {
            return record(Verdict(false, "Kill Switch 已开启", null))
        }
        val dq = snapshot.dataQuality
        if (dq != null && !dq.liveTradeAllowed) {
            val reasons = dq.blockReasons.ifEmpty { listOf("数据质量不足") }
            return record(Verdict(false, "数据质量门禁止: ${reasons.joinToString()}", null))
        }
        if (snapshot.opportunityScore < config().minOpportunityScore) {
            return record(Verdict(false, "机会分不足 (${"%.0f".format(snapshot.opportunityScore * 100)}% < ${"%.0f".format(config().minOpportunityScore * 100)}%)", null))
        }
        if (nowMs - lastOrderAtMs < cooldownMs) {
            return record(Verdict(false, "冷却中 (${(cooldownMs - (nowMs - lastOrderAtMs)) / 1000}s)", null))
        }
        val key = "$marketId|$direction|$windowId"
        if (key in placedKeys) return record(Verdict(false, "幂等：同窗口已下单", key))
        return record(Verdict(true, "OK", key))
    }

    fun markPlaced(key: String, nowMs: Long = System.currentTimeMillis()) {
        placedKeys.add(key)
        while (placedKeys.size > 500) placedKeys.remove(placedKeys.first())
        lastOrderAtMs = nowMs
    }

    private fun record(v: Verdict): Verdict {
        lastVerdictReason = v.reason
        return v
    }
}
