package com.caifenxi.app.domain.btc.hs

import kotlin.math.abs

/** Converts executable market conditions into a net edge cost breakdown. */
object HsCostEngine {
    data class Cost(
        val fee: Double,
        val spread: Double,
        val slippage: Double,
        val liquidityImpact: Double,
        val latency: Double
    ) {
        val total: Double get() = fee + spread + slippage + liquidityImpact + latency
    }

    fun estimate(
        ask: Double,
        bid: Double?,
        depthQuote: Double,
        requestedNotional: Double = 25.0,
        feeRate: Double = 0.01,
        latencySec: Double = 2.0
    ): Cost {
        val spread = if (bid != null) abs(ask - bid).coerceAtLeast(0.0) else 0.0
        val spreadHalf = spread * 0.5
        val depth = depthQuote.coerceAtLeast(1.0)
        // 吃单冲击：随 notional/depth 非线性上升，上限 8%
        val impactRatio = (requestedNotional / depth).coerceIn(0.0, 2.0)
        val impact = (impactRatio * 0.25 + impactRatio * impactRatio * 0.10).coerceIn(0.0, 0.08)
        val slippage = (spreadHalf * 0.75 + impact * 0.5).coerceIn(0.0, 0.10)
        val latency = (latencySec.coerceIn(0.0, 10.0) * 0.0005).coerceIn(0.0, 0.005)
        return Cost(feeRate.coerceAtLeast(0.0), spreadHalf, slippage, impact, latency)
    }
}
