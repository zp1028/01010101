package com.caifenxi.app.domain.btc.runtime

import com.caifenxi.app.domain.btc.BinanceDerivativesRepository
import com.caifenxi.app.domain.btc.BinanceMarketRepository
import com.caifenxi.app.domain.btc.BtcPlanEngine
import com.caifenxi.app.domain.btc.BtcSignalFactory
import com.caifenxi.app.domain.btc.BtcDecisionPipeline
import com.caifenxi.app.domain.btc.DerivativesFeatureEngine
import com.caifenxi.app.domain.btc.news.CryptoNewsRepository
import com.caifenxi.app.domain.btc.ai.AiBrain
import com.caifenxi.app.domain.btc.ai.AiPolicy
import com.caifenxi.app.domain.btc.ai.AiPolicyConfig
import com.caifenxi.app.domain.btc.broker.PerpBroker
import com.caifenxi.app.domain.btc.risk.BtcRiskEngine
import com.caifenxi.app.domain.btc.plan.BtcLivePlanPerformance
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope

/** P2 runtime loop + P3 derivatives features. Default PAPER; TESTNET needs injected broker. */
class BtcRuntimeController(
    private val market: BinanceMarketRepository = BinanceMarketRepository(),
    private val derivatives: BinanceDerivativesRepository = BinanceDerivativesRepository(),
    private val newsRepo: CryptoNewsRepository = CryptoNewsRepository(),
    private val aiBrain: AiBrain = AiBrain(),
    private val aiPolicy: AiPolicyConfig = AiPolicyConfig(allowLiveAiOrders = false),
    private val engine: BtcPlanEngine = BtcPlanEngine(),
    private val signalFactory: BtcSignalFactory = BtcSignalFactory(),
    private val risk: BtcRiskEngine = BtcRiskEngine(),
    private val store: BtcRuntimeStore,
    private val broker: PerpBroker? = null,
    private val gate: BtcExecutionGate = BtcExecutionGate(),
    private val decisionPipeline: BtcDecisionPipeline = BtcDecisionPipeline(),
    private val ticketStore: BtcExecutionTicketStore = BtcExecutionTicketStore(),
    private val persistentExecutionStore: BtcPersistentExecutionStore = BtcPersistentExecutionStore(store.appContext),
    private val audit: BtcExecutionAudit = BtcExecutionAudit(store.appContext),
    private val livePerformance: BtcLivePlanPerformance = BtcLivePlanPerformance(),
    /** 云控制面：默认 Noop（不联网、零副作用）；接入真实实现后可远程停市/恢复。 */
    private val controlPlane: BtcControlPlane = NoopBtcControlPlane,
    /** 今日已实现盈亏（USDT），用于日损熔断 */
    private val dayRealizedPnlProvider: () -> Double = { 0.0 }
) {
    /** 本节点标识（云端控制面按节点分发命令；Noop 实现忽略该值）。 */
    companion object {
        private const val NODE_ID = "btc-quant-default"
    }

    suspend fun runOnce() {
        val cfg = store.config()
        if (!cfg.enabled || store.state().killSwitch) return
        // 云控制面：拉取远程命令并执行（KILL/RESUME/STOP 等安全控制）。
        // Noop 返回空列表，任何远程异常都不影响本地执行主循环。
        runCatching {
            val commands = controlPlane.pullCommands(NODE_ID)
            if (commands.isNotEmpty()) {
                val processor = BtcRemoteCommandProcessor(store)
                commands.forEach { cmd ->
                    val ok = processor.apply(cmd)
                    controlPlane.ack(cmd.commandId, ok)
                }
            }
        }
        if (!store.config().enabled || store.state().killSwitch) return
        coroutineScope {
            val candlesDef = async { runCatching { market.loadKlines(cfg.symbol, cfg.timeframe, 300) }.getOrDefault(emptyList()) }
            val fundingDef = async {
                runCatching { derivatives.fundingHistory(cfg.symbol, 100) }.getOrDefault(emptyList())
            }
            val oiDef = async {
                runCatching { derivatives.openInterestHistory(cfg.symbol, cfg.timeframe.ifBlank { "15m" }, 100) }
                    .getOrDefault(emptyList())
            }
            val snapDef = async {
                runCatching { derivatives.snapshot(cfg.symbol) }.getOrNull()
            }
            val candles = candlesDef.await()
            if (candles.isEmpty()) return@coroutineScope
            // Only make a decision from a completed candle. Binance may return the
            // currently-forming candle as the last item; using it would make the
            // signal change intrabar and can create inconsistent execution.
            val decisionIndex = candles.indexOfLast { it.openTime + timeframeMillis(cfg.timeframe) <= System.currentTimeMillis() }
            if (decisionIndex < 0) return@coroutineScope
            val decisionCandles = candles.subList(0, decisionIndex + 1)
            val last = decisionCandles.last()
            val current = store.state()
            // Paper account is stateful and survives process death. Mark the open
            // position before deciding whether this bar is already processed.
            if (cfg.runMode == BtcRunMode.PAPER) {
                val paper = store.paperLedger()
                paper.mark(last.close)
                if (paper.shouldCloseAt(last.close)) {
                    paper.close(last.close)
                    store.update { it.copy(lastError = null, lastHeartbeatAt = System.currentTimeMillis()) }
                }
            }
            if (current.lastBarId == last.openTime) {
                store.update {
                    it.copy(status = BtcRuntimeStatus.RUNNING, lastHeartbeatAt = System.currentTimeMillis())
                }
                return@coroutineScope
            }
            val funding = fundingDef.await()
            val oi = oiDef.await()
            val snap = snapDef.await()
            val prev = decisionCandles.getOrNull(decisionCandles.lastIndex - 1)
            val deriv = DerivativesFeatureEngine.build(
                barTime = last.openTime,
                close = last.close,
                prevClose = prev?.close,
                fundingHistory = funding,
                oiHistory = oi,
                snapshot = snap
            )
            val news = runCatching { newsRepo.snapshot() }.getOrNull()
            // Refresh plan performance once per completed bar. This makes the
            // registry/lifecycle/dynamic-weight stack actually influence live decisions.
            val perf = livePerformance.get(decisionCandles, deriv)
            val (basePlans, baseConsensus) = engine.evaluate(decisionCandles, deriv, perf = perf)
            val aiCand = aiBrain.generateCandidate(decisionCandles, basePlans, baseConsensus, news, deriv)
            if (news?.blackSwan == true && aiPolicy.haltOnBlackSwan) {
                store.update { it.copy(
                    status = BtcRuntimeStatus.PAUSED,
                    lastError = "新闻黑天鹅熔断",
                    lastHeartbeatAt = System.currentTimeMillis(),
                    lastBarId = last.openTime
                ) }
                return@coroutineScope
            }
            val aiPlan = AiPolicy.toPlanSignal(aiCand, aiPolicy)
            val (plans, consensus) = if (aiPlan != null) {
                engine.evaluate(decisionCandles, deriv, perf = perf, extraSignals = listOf(aiPlan))
            } else basePlans to baseConsensus
            val tradingDecision = if (consensus != null) {
                decisionPipeline.build(cfg.symbol, cfg.timeframe, decisionCandles, plans, consensus, minProbabilityOverride = cfg.minProbability)
            } else null
            val signal = if (consensus != null && tradingDecision != null &&
                tradingDecision.action != com.caifenxi.app.domain.btc.DecisionAction.WAIT &&
                tradingDecision.action != com.caifenxi.app.domain.btc.DecisionAction.BLOCK) {
                signalFactory.buildPerpSignal(cfg.symbol, decisionCandles, plans, consensus, cfg.maxPositionQty)
            } else null
            // Publish the latest signal/market diagnostics first, but DO NOT
            // advance lastBarId yet. A failed broker call must remain retryable.
            store.update {
                it.copy(
                    status = BtcRuntimeStatus.RUNNING,
                    lastHeartbeatAt = System.currentTimeMillis(),
                    lastSignal = consensus?.direction,
                    lastError = null,
                    lastFundingRate = deriv.fundingRate,
                    lastOiChangePct = deriv.oiChangePct,
                    lastDerivScore = deriv.derivativesScore
                )
            }
            if (signal == null || consensus == null) {
                store.update {
                    it.copy(
                        lastBarId = last.openTime,
                        processedBars = it.processedBars + 1
                    )
                }
                return@coroutineScope
            }
            val dayPnl = dayRealizedPnlProvider()
            // v9: 风控基准使用真实/纸面账户权益，不再固定 1000U。
            val equity = when (cfg.runMode) {
                BtcRunMode.PAPER -> store.paperLedger().snapshot().equity
                BtcRunMode.TESTNET, BtcRunMode.LIVE -> {
                    val b = broker
                    if (b == null) {
                        store.update { it.copy(status = BtcRuntimeStatus.ERROR, lastError = "Broker 未注入，无法读取账户权益") }
                        return@coroutineScope
                    }
                    runCatching { b.accountSnapshot().totalWalletBalance }
                        .getOrElse { error ->
                            audit.add(BtcExecutionAudit.Entry(decisionId = tradingDecision?.decisionId.orEmpty(), executionId = null, stage = "RECONCILE", outcome = "FAILED", detail = error.message.orEmpty()))
                            store.update { it.copy(status = BtcRuntimeStatus.ERROR, lastError = "账户对账失败：${error.message ?: "unknown"}") }
                            return@coroutineScope
                        }
                }
            }
            val previousPeak = store.state().peakEquityUsdt
            val peak = maxOf(previousPeak, equity)
            val drawdownPct = if (peak > 0.0) ((peak - equity) / peak * 100.0).coerceAtLeast(0.0) else 0.0
            store.update { it.copy(lastEquityUsdt = equity, peakEquityUsdt = peak, currentDrawdownPct = drawdownPct) }
            val decision = risk.authorizeByEquity(
                consensus = consensus,
                dailyPnlUsdt = dayPnl,
                equityUsdt = equity,
                currentDrawdownPct = drawdownPct,
                requestedNotionalUsdt = signal.positionSize * signal.entry
            )
            audit.add(BtcExecutionAudit.Entry(decisionId = tradingDecision?.decisionId.orEmpty(), executionId = null, stage = "RISK", outcome = if (decision.allowed) "ALLOW" else "BLOCK", detail = decision.reason))
            if (!decision.allowed) {
                store.update { it.copy(status = BtcRuntimeStatus.PAUSED, lastError = decision.reason) }
                return@coroutineScope
            }
            // LIVE/TESTNET 额外硬闸门
            val sized = signal.copy(
                positionSize = signal.positionSize.coerceAtMost(cfg.maxPositionQty),
                leverageCap = signal.leverageCap.coerceAtMost(cfg.maxLeverage)
            )
            val notional = sized.positionSize * sized.entry
            if (notional > cfg.maxNotionalUsdt) {
                store.update { it.copy(status = BtcRuntimeStatus.PAUSED, lastError = "单笔名义超限: ${"%.2f".format(notional)} > ${"%.2f".format(cfg.maxNotionalUsdt)}") }
                return@coroutineScope
            }
            val liveGate = LiveUnattendedGuard.authorizeOrder(
                cfg = cfg,
                state = store.state(),
                consensus = consensus,
                signal = sized,
                dayRealizedPnl = dayPnl
            )
            if (!liveGate.allowed) {
                store.update {
                    it.copy(
                        status = BtcRuntimeStatus.PAUSED,
                        lastError = "Guard: ${liveGate.reason}",
                        lastHeartbeatAt = System.currentTimeMillis()
                    )
                }
                return@coroutineScope
            }
            val td = tradingDecision ?: return@coroutineScope
            audit.add(BtcExecutionAudit.Entry(decisionId = td.decisionId, executionId = null, stage = "DECISION", outcome = td.action.name, detail = td.context.reason))
            val lastOrderAt = store.state().lastOrderAt
            if (lastOrderAt > 0L && System.currentTimeMillis() - lastOrderAt < cfg.minOrderIntervalSec * 1000L) {
                audit.add(BtcExecutionAudit.Entry(decisionId = td.decisionId, executionId = null, stage = "COOLDOWN", outcome = "BLOCK", detail = "minOrderIntervalSec=${cfg.minOrderIntervalSec}"))
                store.update { it.copy(status = BtcRuntimeStatus.PAUSED, lastBarId = last.openTime, processedBars = it.processedBars + 1, lastError = "执行冷却中：距离上一笔订单不足 ${cfg.minOrderIntervalSec}s") }
                return@coroutineScope
            }
            if (!gate.claimBar(sized.symbol, cfg.timeframe, sized.barId)) return@coroutineScope
            val executionKey = gate.key(sized.symbol, cfg.timeframe, sized.barId)
            if (!persistentExecutionStore.claim(td.decisionId)) {
                // A prior process already claimed this exact decision. Treat it as
                // an idempotency suppression rather than generating another order.
                gate.release(executionKey)
                store.update { it.copy(
                    status = BtcRuntimeStatus.RUNNING,
                    lastBarId = last.openTime,
                    processedBars = it.processedBars + 1,
                    lastError = "幂等保护：该决策已执行/已提交，跳过重复订单",
                    lastHeartbeatAt = System.currentTimeMillis()
                ) }
                return@coroutineScope
            }
            val ticket = ticketStore.claim(td.decisionId, sized.symbol, cfg.timeframe, sized.barId, td.action.name)
            if (ticket == null) {
                persistentExecutionStore.clear(td.decisionId)
                gate.release(executionKey)
                return@coroutineScope
            }
            try {
                audit.add(BtcExecutionAudit.Entry(decisionId = td.decisionId, executionId = ticket.executionId, stage = "EXECUTION", outcome = "START", detail = ticket.clientOrderId))
                val result = when (cfg.runMode) {
                    BtcRunMode.PAPER -> {
                        val paper = store.paperLedger()
                        val opened = paper.open(
                            symbol = sized.symbol,
                            direction = sized.direction,
                            entry = sized.entry,
                            quantity = sized.positionSize,
                            leverage = sized.leverageCap,
                            stopLoss = sized.stopLoss,
                            takeProfit = sized.takeProfit
                        )
                        com.caifenxi.app.domain.btc.broker.BrokerOrderResult(
                            success = opened,
                            orderId = null,
                            clientOrderId = ticket.clientOrderId,
                            status = if (opened) "PAPER_FILLED" else "PAPER_REJECTED",
                            message = if (opened) "paper position opened" else "paper position already active"
                        )
                    }
                    BtcRunMode.TESTNET, BtcRunMode.LIVE -> {
                        val b = broker ?: run {
                            store.update {
                                it.copy(
                                    status = BtcRuntimeStatus.ERROR,
                                    lastError = "Broker 未注入，未标记本 bar 已处理"
                                )
                            }
                            gate.release(executionKey)
                            ticketStore.clear(td.decisionId)
                            persistentExecutionStore.clear(td.decisionId)
                            return@coroutineScope
                        }
                        // Broker 侧再次确认当前持仓，避免应用重启/网络重试造成重复加仓。
                        val existingResult = runCatching { b.fetchPositionRisk(sized.symbol) }
                        val existing = existingResult.getOrElse {
                            audit.add(BtcExecutionAudit.Entry(decisionId = td.decisionId, executionId = ticket.executionId, stage = "RECONCILE", outcome = "FAILED", detail = it.message.orEmpty()))
                            throw IllegalStateException("持仓对账失败，拒绝继续下单: ${it.message ?: "unknown"}")
                        }
                        audit.add(BtcExecutionAudit.Entry(decisionId = td.decisionId, executionId = ticket.executionId, stage = "RECONCILE", outcome = "OK", detail = "position=${existing?.positionAmt ?: 0.0}"))
                        if (existing != null && kotlin.math.abs(existing.positionAmt) > 1e-9) {
                            val existingDirection = if (existing.positionAmt > 0) com.caifenxi.app.domain.btc.BtcDirection.UP else com.caifenxi.app.domain.btc.BtcDirection.DOWN
                            if (existingDirection == sized.direction) {
                                gate.release(executionKey)
                                ticketStore.clear(td.decisionId)
                                persistentExecutionStore.clear(td.decisionId)
                                store.update { it.copy(
                                    status = BtcRuntimeStatus.RUNNING,
                                    lastBarId = last.openTime,
                                    processedBars = it.processedBars + 1,
                                    lastError = "已有同向持仓，跳过重复开仓"
                                ) }
                                return@coroutineScope
                            }
                        }
                        // 设杠杆后市价开仓
                        val lev = runCatching { b.setLeverage(sized.symbol, sized.leverageCap) }.getOrNull()
                        if (lev != null && !lev.success) {
                            gate.release(executionKey)
                            ticketStore.clear(td.decisionId)
                            persistentExecutionStore.clear(td.decisionId)
                            store.update { it.copy(status = BtcRuntimeStatus.ERROR, lastError = "杠杆设置失败: ${lev.message}") }
                            return@coroutineScope
                        }
                        val clientId = ticket.clientOrderId
                        val entryRes = b.place(sized, clientId)
                        if (entryRes.success && cfg.requireBracketOrders) {
                            val closeSide = if (sized.direction == com.caifenxi.app.domain.btc.BtcDirection.UP) "SELL" else "BUY"
                            val sl = b.placeConditionalOrder(
                                symbol = sized.symbol,
                                side = closeSide,
                                type = com.caifenxi.app.domain.btc.futures.FuturesOrderType.STOP_MARKET,
                                quantity = sized.positionSize,
                                stopPrice = sized.stopLoss,
                                reduceOnly = true,
                                clientOrderId = ("sl-" + clientId).take(36)
                            )
                            val tp = b.placeConditionalOrder(
                                symbol = sized.symbol,
                                side = closeSide,
                                type = com.caifenxi.app.domain.btc.futures.FuturesOrderType.TAKE_PROFIT_MARKET,
                                quantity = sized.positionSize,
                                stopPrice = sized.takeProfit,
                                reduceOnly = true,
                                clientOrderId = ("tp-" + clientId).take(36)
                            )
                            if (!sl.success || !tp.success) {
                                audit.add(BtcExecutionAudit.Entry(decisionId = td.decisionId, executionId = ticket.executionId, stage = "BRACKET", outcome = "FAILED", detail = "SL=${sl.success},TP=${tp.success}"))
                                // Do not leave an unprotected live position. Close and verify the result.
                                val closeRes = runCatching { b.closePosition(com.caifenxi.app.domain.btc.futures.ClosePositionRequest(sized.symbol, reason = "bracket_failed")) }.getOrNull()
                                val remaining = runCatching { b.fetchPositionRisk(sized.symbol) }.getOrNull()
                                val protectedClosed = closeRes?.success == true && (remaining == null || kotlin.math.abs(remaining.positionAmt) <= 1e-9)
                                audit.add(BtcExecutionAudit.Entry(decisionId = td.decisionId, executionId = ticket.executionId, stage = "BRACKET", outcome = if (protectedClosed) "CLOSED" else "KILL", detail = "close=${closeRes?.success};remaining=${remaining?.positionAmt}"))
                                if (!protectedClosed) {
                                    store.setKillSwitch(true)
                                    throw IllegalStateException("BRACKET_FAILED_FATAL: 无法确认未保护仓位已关闭")
                                }
                                throw IllegalStateException("BRACKET_FAILED: SL/TP 挂单失败，仓位已关闭")
                            }
                            audit.add(BtcExecutionAudit.Entry(decisionId = td.decisionId, executionId = ticket.executionId, stage = "BRACKET", outcome = "SUCCESS", detail = "SL/TP placed"))
                        }
                        entryRes
                    }
                }

                if (result.success) {
                    audit.add(BtcExecutionAudit.Entry(decisionId = td.decisionId, executionId = ticket.executionId, stage = "EXECUTION", outcome = "SUCCESS", detail = result.message))
                    store.update {
                        it.copy(
                            status = BtcRuntimeStatus.RUNNING,
                            lastBarId = last.openTime,
                            processedBars = it.processedBars + 1,
                            lastOrderClientId = result.clientOrderId,
                            lastError = null,
                            consecutiveErrors = 0,
                            lastOrderAt = System.currentTimeMillis(),
                            lastHeartbeatAt = System.currentTimeMillis()
                        )
                    }
                } else {
                    gate.release(executionKey)
                    ticketStore.clear(td.decisionId)
                    persistentExecutionStore.clear(td.decisionId)
                    audit.add(BtcExecutionAudit.Entry(decisionId = td.decisionId, executionId = ticket.executionId, stage = "EXECUTION", outcome = "FAILED", detail = result.message))
                    val errs = store.state().consecutiveErrors + 1
                    val kill = errs >= cfg.maxConsecutiveErrors && cfg.runMode != BtcRunMode.PAPER
                    store.update {
                        it.copy(
                            status = if (kill) BtcRuntimeStatus.KILLED else BtcRuntimeStatus.ERROR,
                            lastError = "订单失败: ${result.status} ${result.message}".trim(),
                            consecutiveErrors = errs,
                            killSwitch = if (kill) true else it.killSwitch
                        )
                    }
                }
            } catch (e: Exception) {
                gate.release(executionKey)
                ticketStore.clear(td.decisionId)
                persistentExecutionStore.clear(td.decisionId)
                audit.add(BtcExecutionAudit.Entry(decisionId = td.decisionId, executionId = ticket.executionId, stage = "EXECUTION", outcome = "EXCEPTION", detail = e.message.orEmpty()))
                val errs = store.state().consecutiveErrors + 1
                val kill = errs >= cfg.maxConsecutiveErrors && cfg.runMode != BtcRunMode.PAPER
                store.update {
                    it.copy(
                        status = if (kill) BtcRuntimeStatus.KILLED else BtcRuntimeStatus.ERROR,
                        lastError = e.message ?: "runtime execution failed",
                        consecutiveErrors = errs,
                        killSwitch = if (kill) true else it.killSwitch
                    )
                }
            }
        }
        // 云控制面：每次执行结束上报心跳（Noop 忽略，不影响本地主循环）。
        runCatching {
            val s = store.state()
            controlPlane.heartbeat(
                BtcHeartbeat(
                    nodeId = NODE_ID,
                    status = s.status.name,
                    symbol = cfg.symbol,
                    timeframe = cfg.timeframe,
                    lastBarId = s.lastBarId,
                    lastHeartbeatAt = System.currentTimeMillis(),
                    killSwitch = s.killSwitch
                )
            )
        }
    }

    private fun timeframeMillis(timeframe: String): Long {
        val m = Regex("(\\d+)([mhdwM])").matchEntire(timeframe)
            ?: return 5L * 60_000L
        val n = m.groupValues[1].toLongOrNull()?.coerceAtLeast(1L) ?: 5L
        return when (m.groupValues[2]) {
            "m" -> n * 60_000L
            "h" -> n * 3_600_000L
            "d" -> n * 86_400_000L
            "w" -> n * 7L * 86_400_000L
            "M" -> n * 30L * 86_400_000L
            else -> 5L * 60_000L
        }
    }
}
