package com.caifenxi.app.domain.btc.hs

import com.caifenxi.app.domain.btc.broker.BrokerCredentials
import com.caifenxi.app.domain.btc.runtime.BtcRunMode
import com.caifenxi.app.domain.btc.runtime.BtcRuntimeConfig
import com.caifenxi.app.domain.btc.runtime.BtcRuntimeState

/**
 * 上线前自检清单 —— UI 与启动门共用。
 */
object ProductionReadiness {
    data class Item(val id: String, val title: String, val ok: Boolean, val detail: String, val required: Boolean = true)
    data class Report(val items: List<Item>) {
        val requiredOk: Boolean get() = items.filter { it.required }.all { it.ok }
        val score: Double get() {
            if (items.isEmpty()) return 0.0
            return items.count { it.ok }.toDouble() / items.size
        }
        val readyForPaper: Boolean get() = items.filter { it.id in paperIds }.all { it.ok }
        val readyForLive: Boolean get() = requiredOk && items.filter { it.id in liveIds }.all { it.ok }

        companion object {
            private val paperIds = setOf("refresh", "dq", "paper_engine", "kill_off")
            private val liveIds = setOf("creds", "live_auth", "dq_live", "gate", "kill_off")
        }
    }

    fun evaluate(
        snapshot: HsPredictionSnapshot?,
        creds: BrokerCredentials,
        runtimeCfg: BtcRuntimeConfig,
        runtimeState: BtcRuntimeState,
        execKill: Boolean,
        hsCfg: HsRuntimeConfig
    ): Report {
        val dq = snapshot?.dataQuality
        val items = listOf(
            Item(
                "refresh", "行情链路",
                snapshot != null && (snapshot.dataMode == "LIVE" || snapshot.dataMode == "LIVE_ACCOUNT" || snapshot.dataMode == "PAPER" || snapshot.tf15m.pHat > 0),
                snapshot?.dataMode ?: "无快照"
            ),
            Item(
                "dq", "数据质量分",
                (dq?.score ?: snapshot?.dataQualityScore ?: 0.0) >= 0.5,
                "score=${"%.0f".format((dq?.score ?: snapshot?.dataQualityScore ?: 0.0) * 100)}%"
            ),
            Item(
                "dq_live", "LIVE 数据门",
                dq?.liveTradeAllowed == true,
                if (dq?.liveTradeAllowed == true) "允许" else (dq?.blockReasons?.joinToString() ?: "未通过"),
                required = true
            ),
            Item(
                "gate", "执行门控",
                !execKill && (dq?.liveTradeAllowed != false),
                if (execKill) "Kill Switch ON" else "OK"
            ),
            Item(
                "kill_off", "Kill Switch 关闭",
                !execKill && !runtimeState.killSwitch,
                if (execKill || runtimeState.killSwitch) "仍处于停机" else "关闭"
            ),
            Item(
                "paper_engine", "纸交易引擎",
                snapshot != null,
                "balance=${"%.2f".format(snapshot?.balance ?: 0.0)}"
            ),
            Item(
                "creds", "API 凭据",
                when (runtimeCfg.runMode) {
                    BtcRunMode.PAPER -> true
                    BtcRunMode.TESTNET -> creds.polymarketApiKey.isNotBlank() || creds.binanceApiKey.isNotBlank()
                    BtcRunMode.LIVE -> creds.binanceApiKey.isNotBlank() && creds.binanceSecret.isNotBlank()
                },
                "mode=${runtimeCfg.runMode.name} binanceKey=${creds.binanceApiKey.isNotBlank()} polyKey=${creds.polymarketApiKey.isNotBlank()}"
            ),
            Item(
                "live_auth", "LIVE 无人值守授权",
                runtimeCfg.runMode != BtcRunMode.LIVE || runtimeCfg.liveAutoAuthorized,
                if (runtimeCfg.liveAutoAuthorized) "已授权" else "未授权（设置页确认语）"
            ),
            Item(
                "risk", "仓位硬上限",
                hsCfg.maxRiskFraction in 0.005..0.05 && hsCfg.minNetEdge > 0,
                "maxRisk=${"%.1f".format(hsCfg.maxRiskFraction * 100)}% minEdge=${"%.1f".format(hsCfg.minNetEdge * 100)}%"
            ),
            Item(
                "demo", "非 Demo 污染",
                snapshot?.dataMode != "DEMO",
                snapshot?.dataMode ?: "—"
            )
        )
        return Report(items)
    }
}
