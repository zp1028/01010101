package com.caifenxi.app.domain.btc.broker

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Runtime credentials. Stored with AndroidX encrypted preferences; never hard-code keys. */
data class BrokerCredentials(
    val binanceApiKey: String = "",
    val binanceSecret: String = "",
    val binanceEndpoint: BinanceFuturesEndpoint = BinanceFuturesEndpoint.DEMO,
    val polymarketApiKey: String = "",
    val polymarketApiSecret: String = "",
    val polymarketPassphrase: String = "",
    /** Polygon signer/funder address used by authenticated CLOB L2 requests. */
    val polymarketAddress: String = "",
    val polymarketDryRun: Boolean = true,
    val chainlinkRpcUrl: String = "",
    val chainlinkFeedAddress: String = ""
)

class BrokerCredentialStore(context: Context) {
    private val sp: SharedPreferences = runCatching {
        val app = context.applicationContext
        val master = MasterKey.Builder(app)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            app,
            "btc_broker_creds_secure",
            master,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }.getOrElse {
        // Private fallback keeps old installs readable if the secure store cannot initialize.
        context.applicationContext.getSharedPreferences("btc_broker_creds", Context.MODE_PRIVATE)
    }

    init {
        // One-time migration from the previous private-prefs store to encrypted storage.
        if (!sp.contains("b_key")) {
            val legacy = context.applicationContext.getSharedPreferences("btc_broker_creds", Context.MODE_PRIVATE)
            if (legacy.contains("b_key")) {
                sp.edit()
                    .putString("b_key", legacy.getString("b_key", ""))
                    .putString("b_sec", legacy.getString("b_sec", ""))
                    .putString("b_ep", legacy.getString("b_ep", "DEMO"))
                    .putString("p_key", legacy.getString("p_key", ""))
                    .putString("p_sec", legacy.getString("p_sec", ""))
                    .putString("p_pass", legacy.getString("p_pass", ""))
                    .putString("p_addr", legacy.getString("p_addr", ""))
                    .putBoolean("p_dry", legacy.getBoolean("p_dry", true))
                    .putString("cl_rpc", legacy.getString("cl_rpc", ""))
                    .putString("cl_feed", legacy.getString("cl_feed", ""))
                    .apply()
            }
        }
    }

    fun load(): BrokerCredentials = BrokerCredentials(
        binanceApiKey = sp.getString("b_key", "").orEmpty(),
        binanceSecret = sp.getString("b_sec", "").orEmpty(),
        binanceEndpoint = runCatching {
            BinanceFuturesEndpoint.valueOf(sp.getString("b_ep", "DEMO")!!)
        }.getOrDefault(BinanceFuturesEndpoint.DEMO),
        polymarketApiKey = sp.getString("p_key", "").orEmpty(),
        polymarketApiSecret = sp.getString("p_sec", "").orEmpty(),
        polymarketPassphrase = sp.getString("p_pass", "").orEmpty(),
        polymarketAddress = sp.getString("p_addr", "").orEmpty(),
        polymarketDryRun = sp.getBoolean("p_dry", true),
        chainlinkRpcUrl = sp.getString("cl_rpc", "").orEmpty(),
        chainlinkFeedAddress = sp.getString("cl_feed", "").orEmpty()
    )

    fun save(c: BrokerCredentials) {
        sp.edit()
            .putString("b_key", c.binanceApiKey.trim())
            .putString("b_sec", c.binanceSecret.trim())
            .putString("b_ep", c.binanceEndpoint.name)
            .putString("p_key", c.polymarketApiKey.trim())
            .putString("p_sec", c.polymarketApiSecret.trim())
            .putString("p_pass", c.polymarketPassphrase.trim())
            .putString("p_addr", c.polymarketAddress.trim())
            .putBoolean("p_dry", c.polymarketDryRun)
            .putString("cl_rpc", c.chainlinkRpcUrl.trim())
            .putString("cl_feed", c.chainlinkFeedAddress.trim())
            .apply()
    }

    fun clear() {
        sp.edit().clear().apply()
    }
}

object BrokerFactory {
    fun perp(creds: BrokerCredentials, forcePaper: Boolean = false): PerpBroker {
        if (forcePaper) return PaperPerpBroker()
        require(creds.binanceApiKey.isNotBlank() && creds.binanceSecret.isNotBlank()) {
            "Binance API Key/Secret 未配置：不会自动回退到 PAPER"
        }
        return BinanceFuturesBroker(creds.binanceApiKey, creds.binanceSecret, creds.binanceEndpoint)
    }

    fun polymarket(creds: BrokerCredentials): EventMarketBroker =
        PolymarketClobBroker(
            dryRun = creds.polymarketDryRun || creds.polymarketApiKey.isBlank(),
            apiKey = creds.polymarketApiKey,
            apiSecret = creds.polymarketApiSecret,
            passphrase = creds.polymarketPassphrase,
            address = creds.polymarketAddress
        )

    /**
     * Event Contract 合约市场 Broker 选择：
     * - 未配 polymarket 实盘密钥或 dryRun=true → Paper（不会真金白银下单）；
     * - 已配密钥（polymarketDryRun=false）→ Binance 实盘合约 Broker。
     */
    fun eventContract(creds: BrokerCredentials = BrokerCredentials()): EventContractBroker =
        if (creds.polymarketDryRun || creds.polymarketApiKey.isBlank()) {
            PaperEventContractBroker()
        } else {
            BinanceEventContractBroker(
                apiKey = creds.polymarketApiKey,
                secretKey = creds.polymarketApiSecret
            )
        }
}
