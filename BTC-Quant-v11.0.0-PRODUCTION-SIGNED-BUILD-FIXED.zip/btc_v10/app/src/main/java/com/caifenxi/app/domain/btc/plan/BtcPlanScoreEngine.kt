package com.caifenxi.app.domain.btc.plan

import com.caifenxi.app.domain.btc.MarketRegime
import kotlin.math.max

/** Unified 0..1 strategy score used by UI and runtime explanations. */
object BtcPlanScoreEngine {
    data class Score(
        val planId: String,
        val score: Double,
        val components: Map<String, Double>
    )

    fun score(perf: DynamicWeightEngine.PlanPerf?, regimeFit: Double, correlationPenalty: Double = 0.0): Double {
        if (perf == null) return (0.45 + regimeFit * 0.35 - correlationPenalty).coerceIn(0.0, 1.0)
        val pf = ((perf.profitFactor - 0.8) / 1.2).coerceIn(0.0, 1.0)
        val wr = (perf.winRatePct / 100.0).coerceIn(0.0, 1.0)
        val dd = 1.0 - (perf.maxDrawdownPct / 30.0).coerceIn(0.0, 1.0)
        val samples = (perf.samples / 100.0).coerceIn(0.0, 1.0)
        return (pf * .30 + wr * .20 + dd * .20 + regimeFit.coerceIn(0.0,1.0) * .20 + samples * .10 - correlationPenalty).coerceIn(0.0, 1.0)
    }
}
