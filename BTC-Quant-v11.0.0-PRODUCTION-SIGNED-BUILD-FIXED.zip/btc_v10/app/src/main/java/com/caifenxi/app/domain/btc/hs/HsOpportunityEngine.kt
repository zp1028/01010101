package com.caifenxi.app.domain.btc.hs

import kotlin.math.abs

/**
 * 机会评分（v2）
 * - 统一 0–1 输入
 * - 硬门槛：低 edge / 低质量 → NO_TRADE
 * - 连续弱信号冷却由外部传入 consecutiveNoTrade（可选）
 */
object HsOpportunityEngine {
    data class Result(
        val score: Double,
        val confidence: Double,
        val finalMultiplier: Double,
        val label: String,
        val reasons: List<String>,
        val risks: List<String>
    )

    fun evaluate(
        pHat: Double,
        netEdge: Double,
        liquidity: Double,
        spread: Double,
        modelHitRate: Double,
        brier: Double,
        dataQuality: Double,
        regime: String,
        drawdownPct: Double,
        config: HsRuntimeConfig = HsRuntimeConfig.Default,
        liveTradeAllowed: Boolean = true,
        consecutiveNoTrade: Int = 0
    ): Result {
        val confidence = (
            abs(pHat - 0.5) * 2.0 * 0.55 +
                modelHitRate.coerceIn(0.0, 1.0) * 0.30 +
                (1.0 - brier.coerceIn(0.0, 1.0)) * 0.15
            ).coerceIn(0.0, 1.0)
        val edgeScore = (netEdge / 0.08).coerceIn(0.0, 1.0)
        val spreadScore = (1.0 - spread / 0.05).coerceIn(0.0, 1.0)
        val score = (
            edgeScore * 0.34 +
                confidence * 0.25 +
                liquidity.coerceIn(0.0, 1.0) * 0.18 +
                spreadScore * 0.08 +
                dataQuality.coerceIn(0.0, 1.0) * 0.15
            ).coerceIn(0.0, 1.0)

        val riskPenalty = (1.0 - (drawdownPct.coerceAtLeast(0.0) / 15.0).coerceIn(0.0, 0.55))
        val regimeMul = when (regime) {
            "HIGH_VOLATILITY" -> 0.65
            "BREAKOUT" -> 1.05
            else -> 1.0
        }
        // 连续 NO_TRADE 后短暂降温，避免震荡反复试探
        val coolMul = when {
            consecutiveNoTrade >= 5 -> 0.7
            consecutiveNoTrade >= 3 -> 0.85
            else -> 1.0
        }

        var multiplier = if (score < config.minOpportunityScore || netEdge <= 0.0) {
            0.0
        } else {
            (score * confidence * liquidity.coerceIn(0.15, 1.0) * riskPenalty * regimeMul * coolMul)
                .coerceIn(0.0, 1.5)
        }
        if (!liveTradeAllowed) multiplier = 0.0

        val label = when {
            !liveTradeAllowed -> "BLOCKED_DATA"
            score >= 0.82 && netEdge >= config.minNetEdge -> "STRONG"
            score >= 0.70 && netEdge > 0.0 -> "OPPORTUNITY"
            score >= config.minOpportunityScore -> "WATCH"
            else -> "NO_TRADE"
        }

        val reasons = buildList {
            if (netEdge >= config.minNetEdge) add("Net Edge ≥ ${"%.0f".format(config.minNetEdge * 100)}%")
            if (confidence >= 0.65) add("模型可信度充足")
            if (liquidity >= 0.60) add("盘口流动性充足")
            if (dataQuality >= 0.80) add("实时数据质量良好")
            if (regime == "BREAKOUT") add("当前处于突破状态")
        }
        val risks = buildList {
            if (!liveTradeAllowed) add("数据质量门禁止实盘")
            if (netEdge < config.minNetEdge) add("Net Edge 不足")
            if (liquidity < 0.40) add("流动性偏低")
            if (spread > 0.03) add("Spread 偏宽")
            if (dataQuality < config.minDataQualityForLive) add("数据质量不足")
            if (drawdownPct > 8.0) add("当前回撤较高")
            if (modelHitRate < config.minModelHitRate) add("模型命中率偏低")
            if (brier > config.maxBrierScore) add("Brier 偏高")
        }
        return Result(score, confidence, multiplier, label, reasons, risks)
    }
}
