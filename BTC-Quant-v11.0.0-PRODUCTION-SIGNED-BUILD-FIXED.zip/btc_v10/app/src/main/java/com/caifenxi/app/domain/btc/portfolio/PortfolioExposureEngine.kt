package com.caifenxi.app.domain.btc.portfolio

import kotlin.math.abs

/** Aggregates cross-engine BTC directional exposure and concentration. */
object PortfolioExposureEngine {
    data class Leg(val name: String, val signedNotionalUsdt: Double)
    data class Snapshot(val netExposure: Double, val grossExposure: Double, val concentration: Double, val legs: List<Leg>)

    fun evaluate(legs: List<Leg>, maxExposure: Double): Snapshot {
        val net = legs.sumOf { it.signedNotionalUsdt }
        val gross = legs.sumOf { abs(it.signedNotionalUsdt) }
        val concentration = if (gross <= 0.0) 0.0 else (abs(net) / gross).coerceIn(0.0, 1.0)
        return Snapshot(net, gross, if (maxExposure <= 0.0) 0.0 else (abs(net) / maxExposure).coerceIn(0.0, 1.0), legs)
    }
}
