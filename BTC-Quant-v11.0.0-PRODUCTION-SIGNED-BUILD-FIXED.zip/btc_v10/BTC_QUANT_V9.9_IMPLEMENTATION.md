# BTC Quant v9.9.0

## 本轮目标
将参考图右侧的 Polymarket BTC Up/Down 5m 终端能力原生接入 Android UI，并确保展示数据来自真实 Polymarket/Gamma/CLOB 数据链路，不用固定截图数字。

## 完成
- PolyMarket 增加 description / priceToBeat / startDateMs。
- Gamma market parser 支持 clobTokenIds 为 JSONArray 或 JSON 字符串。
- 市场匹配同时使用 question/slug、BTC 关键词、5m/15m/1h 时长与结束时间。
- HsPredictionSnapshot 增加 polymarketPanels。
- 5m panel 包含倒计时、Price to Beat（若市场元数据提供）、当前 BTC、Delta、YES/NO、best bid/ask、CLOB depth。
- UI 无市场时明确显示 NO ACTIVE MARKET，不生成假盘口。
- Snapshot/Decision 数据仍沿用 v9.8 持久化链路。
- versionName 9.9.0 / versionCode 52。

## 数据边界
Public market/orderbook 数据无需交易凭证；真实下单仍走独立 CLOB signer/auth/execution 链路。
