# v10.3.1 续完：拆分 / Room / Flavor

## 1. Product Flavors（彩票 / BTC 隔离）
`app/build.gradle.kts`：
- **btc**：`FEATURE_BTC_QUANT=true`, `FEATURE_LEGACY_LOTTERY=false`，applicationId `.btc`
- **legacy**：仅彩票
- **full**：双开（默认兼容）

运行时用 `FeatureFlags.btcQuantEnabled` / `legacyLotteryEnabled` 做导航与入口门控。

构建示例：
```bash
./gradlew assembleBtcDebug
./gradlew assembleLegacyDebug
./gradlew assembleFullRelease
```

## 2. ViewModel 职责拆分（协调器）
`domain/btc/coord/`：
| 类 | 职责 |
|----|------|
| `MarketDataCoordinator` | 并行拉 K线/衍生品/盘口/Oracle/Polymarket |
| `PaperAccountCoordinator` | 纸交易余额/名义/PnL/回撤 |
| `HsEngineCoordinator` | 组装参数调用 HsPredictionEngine |
| `ExecutionCoordinator` | Kill Switch、冷却、幂等键、数据门裁决 |

`BtcQuantViewModel` 保留为门面，已注入上述协调器，后续可逐步把 `refresh` / 下单逻辑迁入。

## 3. Feedback / Shadow → Room
- 表：`hs_feedback` / `hs_shadow_open` / `hs_shadow_closed`
- DB version **16** + `MIGRATION_15_16`
- `HsFeedbackStore` / `HsShadowTradingStore`：优先 Room，启动时从 SharedPreferences **一次性迁移**，无 Context 时回退内存+prefs

## 建议后续
- UI 导航按 `FeatureFlags` 隐藏彩票 Tab
- `refresh()` 整段改为调用 `marketDataCoordinator.loadParallel(...)`
- 执行路径统一走 `executionCoordinator.canExecute(...)`
