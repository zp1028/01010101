# BTC Quant v9.1 — HS 对齐增强

本版本把 HS 视频中可确认的产品逻辑落到真实数据链：多周期概率、BTC 订单簿、Polymarket CLOB、Edge/成本、Kelly、Bayesian Particle、ML 拟合、模型反馈和真实账户源。

## 数据真实性
- Binance Kline 5m/15m/1h 为行情输入。
- Binance Futures depth 为 BTC 深度、spread、imbalance、micro-price 输入。
- Polymarket CLOB YES/NO orderbook 用于可执行 ask/bid；缺盘口时 edge、Kelly、交易动作不伪造。
- Chainlink 通过用户配置的 EVM RPC + AggregatorV3 feed 地址读取；未配置时 Oracle 明确 unavailable。
- Dashboard 不再使用截图中的固定余额、固定 p_hat、固定交易量或固定 API 18/18。

## 概率层
- Plan Pool consensus
- 本地 Logistic ML：使用历史 candle 特征预测下一根方向，训练与推理分离，避免标签泄漏。
- Probability calibration
- Bayesian particle filter
- 5m/15m/1h 权重根据模型质量与当前净 Edge 动态变化。
- 运行期间记录上一周期预测与实际结果，形成 bounded feedback metrics。

## 市场价值层
`model probability → executable ask/bid → fee + spread + slippage + liquidity impact + latency → net edge → Kelly → dynamic multiplier → risk gate`

没有真实 CLOB ask 时不允许把 0.50 或 outcomePrices 当作“可成交价格”。

## 账户层
- 无 API：明确 PAPER。
- 有 Binance API：读取真实 wallet/available/position。
- 账户读取失败：ACCOUNT_OFFLINE，不回退显示纸账户数字。

## 执行层
- Paper/Testnet/Live 隔离。
- 同决策持久化幂等。
- Broker 持仓对账失败停止继续开仓。
- 最小订单间隔强制执行。
- SL/TP 保护失败后关闭仓位并复核，无法确认关闭则 Kill Switch。
- Runtime health 同时要求 heartbeat/data/broker/risk。
