package com.caifenxi.app.domain.btc.hs

import com.caifenxi.app.domain.btc.broker.BrokerCredentials
import com.caifenxi.app.domain.btc.runtime.BtcRunMode
import com.caifenxi.app.domain.btc.runtime.BtcRuntimeConfig
import com.caifenxi.app.domain.btc.runtime.BtcRuntimeState

/**
 * 上线前自检清单 —— 区分「看行情/模拟」与「实盘」。
 * 模拟路径不再因 Demo 模式或 LIVE 数据门整页变红。
 */
object ProductionReadiness {
    data class Item(val id: String, val title: String, val ok: Boolean, val detail: String, val required: Boolean = true)
    data class Report(val items: List<Item>) {
        val requiredOk: Boolean get() = items.filter { it.required }.all { it.ok }
        val score: Double get() {
            if (items.isEmpty()) return 0.0
            return items.count { it.ok }.toDouble() / items.size
        }
        val readyForPaper: Boolean get() = items.filter { it.id in paperIds }.all { it.ok }
        val readyForLive: Boolean get() = items.filter { it.id in liveIds }.all { it.ok }

        companion object {
            private val paperIds = setOf("refresh", "paper_engine", "kill_off")
            private val liveIds = setOf("refresh", "dq", "dq_live", "gate", "kill_off", "creds", "live_auth", "demo")
        }
    }

    fun evaluate(
        snapshot: HsPredictionSnapshot?,
        creds: BrokerCredentials,
        runtimeCfg: BtcRuntimeConfig,
        runtimeState: BtcRuntimeState,
        execKill: Boolean,
        hsCfg: HsRuntimeConfig
    ): Report {
        val dq = snapshot?.dataQuality
        val hasSnap = snapshot != null
        val mode = snapshot?.dataMode ?: "无快照"
        val items = listOf(
            Item(
                "refresh", "行情链路",
                hasSnap,
                if (hasSnap) "模式=$mode 价格≈${"%.0f".format(snapshot?.markPrice ?: 0.0)}" else "无快照，请点刷新"
            ),
            Item(
                "dq", "数据质量分",
                (dq?.score ?: snapshot?.dataQualityScore ?: 0.0) >= 0.35 || mode == "DEMO",
                "score=${"%.0f".format((dq?.score ?: snapshot?.dataQualityScore ?: 0.0) * 100)}% mode=$mode",
                required = false
            ),
            Item(
                "dq_live", "LIVE 数据门",
                dq?.liveTradeAllowed == true,
                if (dq?.liveTradeAllowed == true) "允许" else (dq?.blockReasons?.joinToString() ?: "模拟可用；实盘需更高质量"),
                required = false
            ),
            Item(
                "gate", "执行门控",
                !execKill,
                if (execKill) "Kill Switch ON" else "OK"
            ),
            Item(
                "kill_off", "Kill Switch 关闭",
                !execKill && !runtimeState.killSwitch,
                if (execKill || runtimeState.killSwitch) "仍处于停机 — 请点「恢复运行」" else "关闭"
            ),
            Item(
                "paper_engine", "纸交易引擎",
                hasSnap || true,
                "balance=${"%.2f".format(snapshot?.balance ?: 0.0)}"
            ),
            Item(
                "creds", "API 凭据",
                when (runtimeCfg.runMode) {
                    BtcRunMode.PAPER -> true
                    BtcRunMode.TESTNET -> creds.polymarketApiKey.isNotBlank() || creds.binanceApiKey.isNotBlank()
                    BtcRunMode.LIVE -> creds.binanceApiKey.isNotBlank() && creds.binanceSecret.isNotBlank()
                },
                "mode=${runtimeCfg.runMode.name} binanceKey=${creds.binanceApiKey.isNotBlank()} polyKey=${creds.polymarketApiKey.isNotBlank()}"
            ),
            Item(
                "live_auth", "LIVE 无人值守授权",
                runtimeCfg.runMode != BtcRunMode.LIVE || runtimeCfg.liveAutoAuthorized,
                if (runtimeCfg.liveAutoAuthorized) "已授权" else "未授权（实盘前需确认）",
                required = false
            ),
            Item(
                "risk", "仓位硬上限",
                hsCfg.maxRiskFraction in 0.005..0.05 && hsCfg.minNetEdge > 0,
                "maxRisk=${"%.1f".format(hsCfg.maxRiskFraction * 100)}% minEdge=${"%.1f".format(hsCfg.minNetEdge * 100)}%",
                required = false
            ),
            Item(
                "demo", "非 Demo 污染",
                mode != "DEMO",
                mode,
                required = false
            )
        )
        return Report(items)
    }
}
