package com.caifenxi.app.domain.btc

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.util.concurrent.TimeUnit

class BinanceOrderBookRepository(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()
) {
    data class Level(val price: Double, val quantity: Double)

    data class Snapshot(
        val symbol: String,
        val bids: List<Level>,
        val asks: List<Level>,
        val lastUpdateId: Long = 0L,
        val fetchedAt: Long = System.currentTimeMillis()
    ) {
        val bestBid: Double? get() = bids.maxByOrNull { it.price }?.price
        val bestAsk: Double? get() = asks.minByOrNull { it.price }?.price
        val mid: Double? get() = bestBid?.let { b -> bestAsk?.let { a -> (a + b) / 2.0 } }
        val spread: Double get() = bestBid?.let { b -> bestAsk?.let { a -> (a - b).coerceAtLeast(0.0) } } ?: 0.0
        val bidDepth: Double get() = bids.take(20).sumOf { it.price * it.quantity }
        val askDepth: Double get() = asks.take(20).sumOf { it.price * it.quantity }
        val imbalance: Double
            get() = if (bidDepth + askDepth <= 0.0) 0.0 else (bidDepth - askDepth) / (bidDepth + askDepth)
        val microPrice: Double?
            get() {
                val bid = bids.maxByOrNull { it.price } ?: return bestAsk
                val ask = asks.minByOrNull { it.price } ?: return bestBid
                val total = bid.quantity + ask.quantity
                return if (total > 0.0) (ask.price * bid.quantity + bid.price * ask.quantity) / total else (bid.price + ask.price) / 2.0
            }
    }

    private val urlBuilders: List<(String, Int) -> String> = listOf(
        { s, n -> "https://data-api.binance.vision/api/v3/depth?symbol=${s.uppercase()}&limit=$n" },
        { s, n -> "https://api.binance.us/api/v3/depth?symbol=${s.uppercase()}&limit=$n" },
        { s, n -> "https://api.binance.com/api/v3/depth?symbol=${s.uppercase()}&limit=$n" },
        { s, n -> "https://fapi.binance.com/fapi/v1/depth?symbol=${s.uppercase()}&limit=$n" }
    )

    suspend fun snapshot(symbol: String = "BTCUSDT", limit: Int = 100): Snapshot? = withContext(Dispatchers.IO) {
        val safe = limit.coerceIn(5, 1000)
        for (builder in urlBuilders) {
            try {
                val req = Request.Builder()
                    .url(builder(symbol, safe))
                    .header("User-Agent", "BTCQuant/11.0 (Android)")
                    .get()
                    .build()
                client.newCall(req).execute().use { response ->
                    if (!response.isSuccessful) return@use
                    val body = response.body?.string().orEmpty()
                    val obj = org.json.JSONObject(body)
                    fun parse(key: String): List<Level> {
                        val arr = obj.optJSONArray(key) ?: JSONArray()
                        return buildList {
                            for (i in 0 until arr.length()) {
                                val row = arr.optJSONArray(i) ?: continue
                                val p = row.optString(0).toDoubleOrNull() ?: continue
                                val q = row.optString(1).toDoubleOrNull() ?: continue
                                if (p > 0.0 && q > 0.0 && p.isFinite() && q.isFinite()) add(Level(p, q))
                            }
                        }
                    }
                    val bids = parse("bids")
                    val asks = parse("asks")
                    if (bids.isEmpty() && asks.isEmpty()) return@use
                    return@withContext Snapshot(symbol.uppercase(), bids, asks, obj.optLong("lastUpdateId"), System.currentTimeMillis())
                }
            } catch (_: Exception) {
            }
        }
        null
    }
}
