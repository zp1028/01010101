package com.caifenxi.app.domain.btc.paper

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * 将模拟二元账户核心字段持久化到本机，进程重启后恢复余额与统计。
 */
class BinaryOptionStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("btc_binary_option", Context.MODE_PRIVATE)

    data class Snapshot(
        val initialBalance: Double,
        val balance: Double,
        val totalWagered: Double,
        val totalPayout: Double,
        val winCount: Int,
        val lossCount: Int,
        val maxBalance: Double,
        val maxDrawdownPct: Double
    )

    fun load(): Snapshot? {
        if (!prefs.contains("balance")) return null
        return Snapshot(
            initialBalance = prefs.getFloat("initialBalance", 10_000f).toDouble(),
            balance = prefs.getFloat("balance", 10_000f).toDouble(),
            totalWagered = prefs.getFloat("totalWagered", 0f).toDouble(),
            totalPayout = prefs.getFloat("totalPayout", 0f).toDouble(),
            winCount = prefs.getInt("winCount", 0),
            lossCount = prefs.getInt("lossCount", 0),
            maxBalance = prefs.getFloat("maxBalance", 10_000f).toDouble(),
            maxDrawdownPct = prefs.getFloat("maxDrawdownPct", 0f).toDouble()
        )
    }

    fun save(account: BinaryOptionAccount) {
        prefs.edit()
            .putFloat("initialBalance", account.initialBalance.toFloat())
            .putFloat("balance", account.balance.toFloat())
            .putFloat("totalWagered", account.totalWagered.toFloat())
            .putFloat("totalPayout", account.totalPayout.toFloat())
            .putInt("winCount", account.winCount)
            .putInt("lossCount", account.lossCount)
            .putFloat("maxBalance", account.maxBalance.toFloat())
            .putFloat("maxDrawdownPct", account.maxDrawdownPct.toFloat())
            .apply()
    }

    fun clear() {
        prefs.edit().clear().apply()
    }
}
