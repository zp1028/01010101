package com.caifenxi.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.caifenxi.app.data.db.dao.HsFeedbackDao
import com.caifenxi.app.data.db.dao.HsShadowDao
import com.caifenxi.app.data.db.entity.HsFeedbackEntity
import com.caifenxi.app.data.db.entity.HsShadowClosedEntity
import com.caifenxi.app.data.db.entity.HsShadowOpenEntity

/**
 * BTC Quant local store.
 * Only HS feedback / shadow-trading tables remain after legacy lottery cleanup.
 * DB name kept as caifenxi.db so existing installs can migrate via destructive fallback.
 */
@Database(
    entities = [
        HsFeedbackEntity::class,
        HsShadowOpenEntity::class,
        HsShadowClosedEntity::class
    ],
    version = 17,
    exportSchema = false
)
abstract class CaiDatabase : RoomDatabase() {
    abstract fun hsFeedbackDao(): HsFeedbackDao
    abstract fun hsShadowDao(): HsShadowDao

    companion object {
        @Volatile
        private var instance: CaiDatabase? = null

        fun getInstance(context: Context): CaiDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    CaiDatabase::class.java,
                    "caifenxi.db"
                )
                    // Schema slimmed from lottery+HS → HS-only; destructive is intentional.
                    .fallbackToDestructiveMigration()
                    .build().also { instance = it }
            }
        }
    }
}
