package com.caifenxi.app

import android.content.Context

/** One-shot cleanup of retired lottery/automation data after pure-BTC migration. */
object LegacyDataCleaner {
    private const val VERSION = 2
    private val legacyPrefs = listOf(
        "caifenxi_prefs",
        "caifenxi_legacy_backup",
        "auto_bet_runtime",
        "floating_overlay",
        "ai_agent_background",
        "ai_agent_metrics"
    )
    private val legacyFiles = listOf("caifenxi.db")

    fun runOnce(context: Context) {
        val sp = context.getSharedPreferences("btc_quant_migration", Context.MODE_PRIVATE)
        if (sp.getInt("legacy_cleanup_version", 0) >= VERSION) return
        legacyPrefs.forEach {
            context.getSharedPreferences(it, Context.MODE_PRIVATE).edit().clear().apply()
        }
        legacyFiles.forEach { context.deleteDatabase(it) }
        sp.edit().putInt("legacy_cleanup_version", VERSION).apply()
    }
}
