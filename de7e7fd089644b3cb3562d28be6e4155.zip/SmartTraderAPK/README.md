# SmartTraderAPK — 完整自包含 APK

这是一个**完整自包含的 Android APK 项目**：
- Python FastAPI 后端（Chaquopy 打包进 APK）
- 前端静态资源打包进 assets
- APP 启动时本地起 uvicorn（127.0.0.1:8000）
- WebView 加载本地页面，不需要远程服务器

## 使用步骤

### 1. 推到 GitHub
- 新建仓库（如 `smart-trader-apk`）
- 把本文件夹所有内容传上去
- Commit

### 2. Actions 自动构建
- 仓库顶部点 **Actions** 标签
- 看到 "Build Full APK" 在跑（黄圆点）
- 等 5–10 分钟（Chaquopy 要编译 Python 依赖，比纯壳慢）
- 变绿勾即成功

### 3. 下载 APK
- 点进完成的 Build 记录
- 拉到底部 **Artifacts**
- 点 `smart-trader-full-apk` 下载（zip，解压后里面是 `app-debug.apk`）
- 传到手机安装，允许"未知来源"

## 说明

- 这是 **debug 签名** APK，自用没问题
- APP 第一次打开会等 2–3 秒（启动后端），然后自动加载
- 不需要 Render、不需要 URL、不需要外网（除了拉行情数据）
- 行情从币安（data-api.binance.vision）+ Gate.io 实时拉取
- 数据存在手机本地 SQLite
- 按返回键先回退网页，再退出

## 技术栈

- Chaquopy 15.0.1（Python 运行时打包进 APK）
- FastAPI + uvicorn（后端）
- WebView（前端加载）
- minSdk 24（Android 7.0+），targetSdk 34
