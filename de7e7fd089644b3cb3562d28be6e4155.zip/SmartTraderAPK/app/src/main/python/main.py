"""APK entry: start uvicorn server in background thread."""
import sys
import os

def run_server():
    # Ensure app package is importable
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import uvicorn
    from app.main import app
    uvicorn.run(app, host="127.0.0.1", port=8000, log_level="warning")

if __name__ == "__main__":
    run_server()
