package com.caifenxi.app.data.repository

import com.caifenxi.app.data.db.CaiDatabase
import com.caifenxi.app.data.db.entity.ExecutionTaskEntity
import com.caifenxi.app.domain.execution.BetAction
import com.caifenxi.app.domain.execution.BetCommand
import com.caifenxi.app.domain.execution.ExecutionRepository
import com.caifenxi.app.domain.execution.ExecutionResult
import com.caifenxi.app.domain.execution.ExecutionTask
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

/**
 * 执行任务仓库：基于 Room 持久化，支持崩溃恢复。
 * App 重启后可从 execution_tasks 表恢复未终态任务和 UNKNOWN 状态任务。
 */
class ExecutionRepositoryImpl(
    private val db: CaiDatabase
) : ExecutionRepository {

    private val dao get() = db.executionTaskDao()

    // ---- ExecutionTask <-> ExecutionTaskEntity 映射 ----

    private fun taskToEntity(task: ExecutionTask): ExecutionTaskEntity {
        val commandJson = task.command?.let { serializeCommand(it) } ?: "{}"
        val resultJson = task.result?.let { serializeResult(it) }
        return ExecutionTaskEntity(
            cmdId = task.cmdId,
            lotteryKey = task.lotteryKey,
            issue = task.issue,
            stage = task.stage,
            leg = task.leg,
            state = task.state.name,
            commandJson = commandJson,
            resultJson = resultJson,
            retryOf = task.retryOf,
            createdAt = task.createdAt,
            lockedAt = if (task.state == ExecutionTask.State.LOCKED) task.updatedAt else null,
            executedAt = if (task.state == ExecutionTask.State.EXECUTING) task.updatedAt else null,
            verifiedAt = if (task.state == ExecutionTask.State.VERIFYING) task.updatedAt else null,
            completedAt = if (task.state in ExecutionTask.TERMINAL_STATES) task.updatedAt else null
        )
    }

    private fun entityToTask(entity: ExecutionTaskEntity): ExecutionTask {
        val command = deserializeCommand(entity.commandJson)
        val result = entity.resultJson?.let { deserializeResult(it) }
        return ExecutionTask(
            cmdId = entity.cmdId,
            lotteryKey = entity.lotteryKey,
            issue = entity.issue,
            stage = entity.stage,
            leg = entity.leg,
            source = command?.source ?: "",
            command = command,
            state = runCatching { ExecutionTask.State.valueOf(entity.state) }
                .getOrDefault(ExecutionTask.State.CREATED),
            status = stateToStatus(
                runCatching { ExecutionTask.State.valueOf(entity.state) }
                    .getOrDefault(ExecutionTask.State.CREATED)
            ),
            retryOf = entity.retryOf,
            createdAt = entity.createdAt,
            updatedAt = entity.completedAt ?: entity.verifiedAt
                ?: entity.executedAt ?: entity.lockedAt ?: entity.createdAt,
            result = result,
            lastError = result?.takeIf { !it.success }?.message
        )
    }

    // ---- JSON 序列化（不依赖 @Serializable 注解，使用 org.json） ----

    private fun serializeCommand(cmd: BetCommand): String {
        val json = JSONObject()
        json.put("cmdId", cmd.cmdId)
        json.put("lotteryKey", cmd.lotteryKey)
        json.put("issue", cmd.issue)
        json.put("stage", cmd.stage)
        json.put("leg", cmd.leg)
        json.put("amountText", cmd.amountText ?: JSONObject.NULL)
        json.put("source", cmd.source)
        json.put("createdAt", cmd.createdAt)
        json.put("expireAt", cmd.expireAt)
        val betsArr = JSONArray()
        cmd.bets.forEach { bet ->
            val b = JSONObject()
            b.put("category", bet.category)
            b.put("value", bet.value)
            betsArr.put(b)
        }
        json.put("bets", betsArr)
        val opts = JSONObject()
        cmd.options.forEach { (k, v) -> opts.put(k, v) }
        json.put("options", opts)
        return json.toString()
    }

    private fun deserializeCommand(jsonStr: String): BetCommand? = try {
        val json = JSONObject(jsonStr)
        val bets = mutableListOf<BetAction>()
        val betsArr = json.optJSONArray("bets")
        if (betsArr != null) {
            for (i in 0 until betsArr.length()) {
                val b = betsArr.getJSONObject(i)
                bets += BetAction(
                    category = b.optString("category"),
                    value = b.optString("value")
                )
            }
        }
        val options = mutableMapOf<String, String>()
        val opts = json.optJSONObject("options")
        if (opts != null) {
            val keys = opts.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                options[k] = opts.optString(k)
            }
        }
        BetCommand(
            cmdId = json.optString("cmdId"),
            lotteryKey = json.optString("lotteryKey"),
            issue = json.optString("issue"),
            stage = json.optInt("stage", 1),
            leg = json.optInt("leg", 0),
            bets = bets,
            amountText = json.optString("amountText").takeIf { it.isNotBlank() && it != "null" },
            source = json.optString("source"),
            createdAt = json.optLong("createdAt", System.currentTimeMillis()),
            expireAt = json.optLong("expireAt", 0L),
            options = options
        )
    } catch (e: Exception) {
        null
    }

    private fun serializeResult(result: ExecutionResult): String {
        val json = JSONObject()
        json.put("cmdId", result.cmdId)
        json.put("success", result.success)
        json.put("message", result.message)
        json.put("errorType", result.errorType ?: JSONObject.NULL)
        json.put("durationMs", result.durationMs)
        val arr = JSONArray()
        result.actionResults.forEach { ar ->
            val o = JSONObject()
            o.put("category", ar.category)
            o.put("value", ar.value)
            o.put("success", ar.success)
            o.put("message", ar.message)
            o.put("durationMs", ar.durationMs)
            arr.put(o)
        }
        json.put("actionResults", arr)
        return json.toString()
    }

    private fun deserializeResult(jsonStr: String): ExecutionResult? = try {
        val json = JSONObject(jsonStr)
        val actionResults = mutableListOf<ExecutionResult.ActionResult>()
        val arr = json.optJSONArray("actionResults")
        if (arr != null) {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                actionResults += ExecutionResult.ActionResult(
                    category = o.optString("category"),
                    value = o.optString("value"),
                    success = o.optBoolean("success", false),
                    message = o.optString("message"),
                    durationMs = o.optLong("durationMs", 0L)
                )
            }
        }
        ExecutionResult(
            cmdId = json.optString("cmdId"),
            success = json.optBoolean("success", false),
            message = json.optString("message"),
            errorType = json.optString("errorType").takeIf { it.isNotBlank() && it != "null" },
            durationMs = json.optLong("durationMs", 0L),
            actionResults = actionResults
        )
    } catch (e: Exception) {
        null
    }

    private fun stateToStatus(state: ExecutionTask.State): ExecutionTask.TaskStatus = when (state) {
        ExecutionTask.State.CREATED -> ExecutionTask.TaskStatus.CREATED
        ExecutionTask.State.LOCKED -> ExecutionTask.TaskStatus.READY
        ExecutionTask.State.EXECUTING -> ExecutionTask.TaskStatus.EXECUTING
        ExecutionTask.State.VERIFYING -> ExecutionTask.TaskStatus.VERIFYING
        ExecutionTask.State.SUCCESS -> ExecutionTask.TaskStatus.SUCCESS
        ExecutionTask.State.FAILED -> ExecutionTask.TaskStatus.FAILED
        ExecutionTask.State.UNKNOWN -> ExecutionTask.TaskStatus.UNKNOWN
        ExecutionTask.State.EXPIRED -> ExecutionTask.TaskStatus.EXPIRED
        ExecutionTask.State.CANCELLED -> ExecutionTask.TaskStatus.CANCELLED
    }

    // ---- ExecutionRepository 接口实现 ----

    override suspend fun create(command: BetCommand): ExecutionTask {
        val task = ExecutionTask.fromCommand(command, source = command.source).copy(
            state = ExecutionTask.State.CREATED,
            status = ExecutionTask.TaskStatus.CREATED
        )
        dao.insert(taskToEntity(task))
        return task
    }

    override suspend fun transition(
        cmdId: String,
        from: ExecutionTask.State,
        to: ExecutionTask.State
    ): Boolean {
        val affected = dao.casUpdateState(cmdId, from.name, to.name)
        return affected > 0
    }

    override suspend fun findById(cmdId: String): ExecutionTask? =
        dao.getById(cmdId)?.let { entityToTask(it) }

    override suspend fun findPendingByLottery(lotteryKey: String): List<ExecutionTask> {
        val nonTerminalStates = listOf(
            ExecutionTask.State.CREATED.name,
            ExecutionTask.State.LOCKED.name,
            ExecutionTask.State.EXECUTING.name,
            ExecutionTask.State.VERIFYING.name
        )
        return dao.getByLotteryAndStates(lotteryKey, nonTerminalStates).map { entityToTask(it) }
    }

    override suspend fun findUnknowns(): List<ExecutionTask> =
        dao.getUnknowns().map { entityToTask(it) }

    override suspend fun findLastSuccess(lotteryKey: String): ExecutionTask? =
        dao.getLastSuccess(lotteryKey)?.let { entityToTask(it) }

    override suspend fun isLotteryBlocked(lotteryKey: String): Boolean =
        dao.hasUnknownForLottery(lotteryKey)

    override suspend fun complete(cmdId: String, result: ExecutionResult): Boolean {
        val state = when (result.code) {
            ExecutionResult.ResultCode.SUCCESS -> ExecutionTask.State.SUCCESS
            ExecutionResult.ResultCode.COMMITTED_SUCCESS -> ExecutionTask.State.SUCCESS
            ExecutionResult.ResultCode.FAILED -> ExecutionTask.State.FAILED
            ExecutionResult.ResultCode.UNKNOWN -> ExecutionTask.State.UNKNOWN
            ExecutionResult.ResultCode.EXPIRED -> ExecutionTask.State.EXPIRED
            ExecutionResult.ResultCode.CANCELLED -> ExecutionTask.State.CANCELLED
            ExecutionResult.ResultCode.TIMEOUT -> ExecutionTask.State.FAILED
            ExecutionResult.ResultCode.DUPLICATE -> ExecutionTask.State.FAILED
            ExecutionResult.ResultCode.WEBVIEW_DISCONNECTED -> ExecutionTask.State.FAILED
            ExecutionResult.ResultCode.COMMITTED_UNKNOWN -> ExecutionTask.State.UNKNOWN
        }
        val resultJson = serializeResult(result)
        val affected = dao.complete(cmdId, state.name, resultJson, System.currentTimeMillis())
        return affected > 0
    }

    override suspend fun expire(cmdId: String): Boolean {
        val affected = dao.casUpdateState(
            cmdId,
            ExecutionTask.State.CREATED.name,
            ExecutionTask.State.EXPIRED.name
        )
        // 如果任务不在 CREATED 状态，尝试从 LOCKED 状态过期
        if (affected == 0) {
            return dao.casUpdateState(
                cmdId,
                ExecutionTask.State.LOCKED.name,
                ExecutionTask.State.EXPIRED.name
            ) > 0
        }
        return true
    }

    override suspend fun acknowledgeUnknown(cmdId: String): Boolean {
        // 原子 CAS：UNKNOWN → CANCELLED，不经过 DAO 的 ACKNOWLEDGED 中间态
        return dao.casUpdateState(
            cmdId,
            ExecutionTask.State.UNKNOWN.name,
            ExecutionTask.State.CANCELLED.name
        ) > 0
    }

    override fun observeLotteryTasks(lotteryKey: String): Flow<List<ExecutionTask>> =
        dao.observeByLottery(lotteryKey).map { entities ->
            entities.map { entityToTask(it) }
        }

    override fun observeUnknowns(): Flow<List<ExecutionTask>> =
        dao.observeUnknowns().map { entities ->
            entities.map { entityToTask(it) }
        }
}
