package com.caifenxi.app.domain.strategy

import com.caifenxi.app.domain.model.BetOdds
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.LotteryConfig
import com.caifenxi.app.domain.model.LotteryType
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * 策略池回测引擎 V2（独立于原有 NovaPlanAnalytics，完全隔离）。
 *
 * 特性：
 * - Walk-forward：每期只用之前的数据预测
 * - 一期/二期/三期滚动窗口倍投
 * - 数据去重+排序
 * - 独立的曲线点和收益计算
 * - 不修改原有 NovaPlanAnalytics
 */
object StrategyAnalytics {

    /**
     * 图表回测：输出每个回测单元的累计收益、峰谷、回撤与趋势数据。
     *
     * @param plan 策略定义
     * @param history 开奖历史
     * @param periods 回测期数
     * @param stake 单注金额
     * @param stage 回测阶段 1=一期 2=二期 3=三期
     * @param invert 是否反投
     */
    fun chartBacktest(
        plan: StrategyDefinition,
        history: List<DrawRecord>,
        periods: Int,
        stake: Double,
        stage: Int = 1,
        invert: Boolean = false,
        /** 预测算法窗口：覆盖 plan.window，0=用 plan.window */
        algoWindow: Int = 0,
        /** 窗口胜率统计窗口大小（按轮级别），默认20 */
        winRateWindow: Int = 20
    ): StrategyBacktestReport {
        // 去重+排序
        val ordered = history
            .sortedWith(compareBy<DrawRecord> { it.issue.toLongOrNull() ?: Long.MIN_VALUE }.thenBy { it.issue })
            .distinctBy { it.issue }

        val selectedStage = stage.coerceIn(1, 3)
        val maxPoints = periods.coerceAtLeast(1)
        val amount = stake.coerceAtLeast(0.0)
        val lotKey = ordered.firstOrNull()?.lotteryKey.orEmpty()
        val lotType = LotteryConfig.findByKey(lotKey)?.type

        // 如果传了 algoWindow > 0，用覆盖后的 plan 做预测
        val effectivePlan = if (algoWindow > 0) plan.copy(window = algoWindow) else plan

        val points = mutableListOf<StrategyChartPoint>()
        var cumulative = 0.0
        var peak = 0.0
        var trough = 0.0
        var hits = 0
        var misses = 0
        var hitStreak = 0
        var missStreak = 0
        var maxHit = 0
        var maxMiss = 0
        var periodHitStreak = 0
        var periodMissStreak = 0
        var maxPeriodHit = 0
        var maxPeriodMiss = 0
        var totalStake = 0.0
        val seenIssues = mutableSetOf<String>()

        fun legsCount(raw: String): Int {
            val parts = raw.removePrefix("反:").split("/", "、", ",").map { it.trim() }.filter { it.isNotEmpty() }
            return when (plan.playType) {
                "组合" -> parts.count { it in listOf("大单", "大双", "小单", "小双") }.coerceAtLeast(1)
                else -> 1
            }
        }

        fun calcProfit(out: String, hit: Boolean, unitStake: Double): Double {
            val n = legsCount(out)
            val cost = unitStake * n
            totalStake += cost
            return if (plan.playType == "组合") {
                if (hit) unitStake * BetOdds.COMBO_RETURN - cost else -cost
            } else {
                val odds = BetOdds.forPlay(
                    plan.playType,
                    out, lotKey
                )
                if (hit) unitStake * (odds - 1.0) else -unitStake
            }
        }

        if (selectedStage <= 1) {
            // 一期回测：每期独立预测、独立结算
            val firstTarget = (ordered.size - maxPoints).coerceAtLeast(5)
            for (i in firstTarget until ordered.size) {
                if (points.size >= maxPoints) break
                val issue = ordered[i].issue
                if (issue in seenIssues) continue
                val prediction = PredictEngineV2.predict(effectivePlan, ordered.subList(0, i)) ?: continue
                val out = if (invert) invertOutput(effectivePlan.playType, prediction.output) else prediction.output
                val hit = PredictEngineV2.evaluate(effectivePlan, out, ordered[i])
                seenIssues += issue

                val profit = calcProfit(out, hit, amount)
                cumulative += profit
                peak = max(peak, cumulative)
                trough = min(trough, cumulative)

                if (hit) { hits++; hitStreak++; missStreak = 0; periodHitStreak++; periodMissStreak = 0; maxHit = max(maxHit, hitStreak); maxPeriodHit = max(maxPeriodHit, periodHitStreak) }
                else { misses++; missStreak++; hitStreak = 0; periodMissStreak++; periodHitStreak = 0; maxMiss = max(maxMiss, missStreak); maxPeriodMiss = max(maxPeriodMiss, periodMissStreak) }

                val total = hits + misses
                points += StrategyChartPoint(
                    issue = issue,
                    prediction = if (invert) "反:$out" else out,
                    hit = hit,
                    stake = amount * legsCount(out),
                    periodProfit = profit,
                    cumulativeProfit = cumulative,
                    peakProfit = peak,
                    troughProfit = trough,
                    drawdown = peak - cumulative,
                    hitRate = if (total == 0) 0.0 else hits.toDouble() / total
                )
            }
        } else {
            // 二期/三期滚动窗口：一次预测锁定，最多追 selectedStage 期
            val firstTarget = (ordered.size - maxPoints).coerceAtLeast(5)
            var i = firstTarget
            while (i < ordered.size && (hits + misses) < maxPoints) {
                if (i + selectedStage > ordered.size) break
                val prediction = PredictEngineV2.predict(effectivePlan, ordered.subList(0, i))
                if (prediction == null) { i += 1; continue }
                val out = if (invert) invertOutput(effectivePlan.playType, prediction.output) else prediction.output
                var unitStake = amount
                var roundHit = false
                var lastTargetIndex = i

                for (k in 0 until selectedStage) {
                    val targetIndex = i + k
                    lastTargetIndex = targetIndex
                    val issue = ordered[targetIndex].issue
                    if (issue in seenIssues) continue
                    val hit = PredictEngineV2.evaluate(effectivePlan, out, ordered[targetIndex])
                    seenIssues += issue

                    val profit = calcProfit(out, hit, unitStake)
                    cumulative += profit
                    peak = max(peak, cumulative)
                    trough = min(trough, cumulative)

                    if (hit) { periodHitStreak++; periodMissStreak = 0; maxPeriodHit = max(maxPeriodHit, periodHitStreak) }
                    else { periodMissStreak++; periodHitStreak = 0; maxPeriodMiss = max(maxPeriodMiss, periodMissStreak) }

                    val total = hits + misses
                    points += StrategyChartPoint(
                        issue = issue,
                        prediction = if (invert) "反:$out" else out,
                        hit = hit,
                        stake = unitStake * legsCount(out),
                        periodProfit = profit,
                        cumulativeProfit = cumulative,
                        peakProfit = peak,
                        troughProfit = trough,
                        drawdown = peak - cumulative,
                        hitRate = if (total == 0) 0.0 else hits.toDouble() / total
                    )
                    if (hit) { roundHit = true; break }
                    unitStake *= plan.stageMult
                }
                if (roundHit) { hits++; hitStreak++; missStreak = 0; maxHit = max(maxHit, hitStreak) }
                else { misses++; missStreak++; hitStreak = 0; maxMiss = max(maxMiss, missStreak) }
                // 对齐 NovaPlanAnalytics：轮结束后更新最后一个点的 hitRate 为轮级胜率
                if (points.isNotEmpty()) {
                    val totalR = hits + misses
                    val last = points.last()
                    points[points.lastIndex] = last.copy(
                        hitRate = if (totalR == 0) 0.0 else hits.toDouble() / totalR
                    )
                }
                // 修复重叠：下一轮从命中期的下一期开始
                i = if (roundHit) lastTargetIndex + 1 else i + selectedStage
            }
        }

        // 计算窗口胜率（按轮级别：一期=每点一轮，二/三期=每个完整轮一轮）
        // 用可配置窗口大小，默认20轮
        val roundHits = mutableListOf<Boolean>()
        if (selectedStage <= 1) {
            // 一期：每个point就是一轮
            roundHits.addAll(points.map { it.hit })
        } else {
            // 二/三期：从points中重建轮结果
            var idx = 0
            while (idx < points.size) {
                val remaining = points.size - idx
                val roundLen = minOf(selectedStage, remaining)
                val round = points.subList(idx, idx + roundLen)
                roundHits.add(round.any { it.hit })  // 任一期命中=轮命中
                idx += roundLen
            }
        }
        val winSize = winRateWindow.coerceIn(2, 500)
        val (winHit, winTotal) = calcRoundWindowRate(roundHits, winSize)
        val winRate = if (winTotal == 0) 0.0 else winHit.toDouble() / winTotal

        val total = hits + misses
        val rate = if (total == 0) 0.0 else hits.toDouble() / total
        val baseline = plan.baselineValue
        val variance = if (points.size < 2) 0.0 else points.map { (if (it.hit) 1.0 else 0.0) }.let { r ->
            val m = r.average()
            r.map { (it - m) * (it - m) }.average()
        }
        val stability = (1.0 - sqrt(variance) * 2.0).coerceIn(0.0, 1.0)
        val maxDrawdown = points.maxOfOrNull { it.drawdown } ?: 0.0
        val netProfit = cumulative

        return StrategyBacktestReport(
            planId = plan.planId,
            planName = plan.planName,
            track = plan.track,
            playType = plan.playType,
            stage = selectedStage,
            total = total,
            hits = hits,
            misses = misses,
            hitRate = rate,
            baseline = baseline,
            edge = rate - baseline,
            maxHitStreak = maxHit,
            maxMissStreak = maxMiss,
            currentHitStreak = hitStreak,
            currentMissStreak = missStreak,
            stability = stability,
            windowRate = winRate,
            windowRateSize = winSize,
            totalStake = totalStake,
            totalReturn = totalStake + netProfit,
            netProfit = netProfit,
            maxDrawdown = maxDrawdown,
            peakProfit = peak,
            troughProfit = trough,
            points = points
        )
    }

    /**
     * 按轮级别的命中/未命中序列计算滚动窗口胜率。
     * 窗口内至少1轮命中 = 窗口命中。
     * 样本不足时使用全部样本计算，不返回0。
     */
    private fun calcRoundWindowRate(roundHits: List<Boolean>, windowSize: Int): Pair<Int, Int> {
        if (roundHits.isEmpty()) return 0 to 0
        val effectiveWindow = minOf(windowSize, roundHits.size)
        var hitWindows = 0
        var totalWindows = 0
        var i = 0
        while (i + effectiveWindow <= roundHits.size) {
            totalWindows++
            if (roundHits.subList(i, i + effectiveWindow).any { it }) hitWindows++
            i += effectiveWindow
        }
        return hitWindows to totalWindows
    }

    /** 反投：方向取反 */
    private fun invertOutput(playType: String, output: String): String {
        if (output.isBlank()) return output
        return output.split("/", "、", ",").map { it.trim() }.filter { it.isNotEmpty() }.joinToString("/") { token ->
            token.map { c ->
                when (c) {
                    '大' -> '小'
                    '小' -> '大'
                    '单' -> '双'
                    '双' -> '单'
                    else -> c
                }
            }.joinToString("")
        }
    }

    /** 转换为 BetCommand（挂机互通用） */
    fun toBetCommand(
        plan: StrategyDefinition,
        prediction: StrategyPrediction,
        lotteryKey: String,
        issue: String,
        amount: Double,
        stage: Int = 1,
        leg: Int = 0
    ): com.caifenxi.app.domain.execution.BetCommand {
        val bets = prediction.output.split("/", "、", ",").map { it.trim() }.filter { it.isNotEmpty() }.map { value ->
            val cat = when {
                plan.playType == "组合" -> com.caifenxi.app.domain.execution.BetAction.CAT_COMBO
                plan.playType.contains("大小") -> com.caifenxi.app.domain.execution.BetAction.CAT_DX
                plan.playType.contains("单双") -> com.caifenxi.app.domain.execution.BetAction.CAT_DS
                else -> com.caifenxi.app.domain.execution.BetAction.CAT_TEXT
            }
            com.caifenxi.app.domain.execution.BetAction(category = cat, value = value)
        }
        return com.caifenxi.app.domain.execution.BetCommand(
            cmdId = com.caifenxi.app.domain.execution.BetCommand.generateCmdId(lotteryKey, issue),
            lotteryKey = lotteryKey,
            issue = issue,
            stage = stage,
            leg = leg,
            bets = bets,
            amountText = amount.toInt().toString(),
            source = "STRATEGY_POOL",
            createdAt = System.currentTimeMillis()
        )
    }
}
