package com.caifenxi.app.domain.strategy

import com.caifenxi.app.domain.execution.BetAction
import com.caifenxi.app.domain.execution.BetCommand
import com.caifenxi.app.domain.model.BetOdds
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.LotteryConfig

/**
 * 过关斩将下注模型（独立于原有倍投，新增多期连续/阶梯式下注模式）。
 *
 * 过关斩将：锁定一个预测方向，连续多期递增下注，
 * 每期命中即"过关"进入下一关，累计收益按阶梯倍率计算；
 * 任一期未中即"斩将"终止本轮，按已过关的期数结算累计盈亏。
 */
data class GuoGuanConfig(
    /** 是否启用过关斩将 */
    val enabled: Boolean = false,
    /** 总关卡数（连续几期） */
    val totalGates: Int = 3,
    /** 基础单注金额 */
    val baseStake: Double = 10.0,
    /** 每关递增倍率：第N关金额 = baseStake * gateMult^(N-1) */
    val gateMult: Double = 2.0,
    /** 玩法分类："大小" / "单双" / "组合" */
    val category: String = "大小",
    /** 预测来源："algo"=驾驶舱 / "plan"=指定计划 / "strategy"=策略池 / "consensus"=共识 */
    val source: String = "algo",
    /** 来源ID */
    val sourceId: String = "",
    /** 中途可提取：到某关后自动提取收益重置（0=不提取，一直累积到最后） */
    val autoWithdrawAt: Int = 0
) {
    /** 计算第N关（1-based）的下注金额 */
    fun stakeAtGate(gate: Int): Double {
        val g = gate.coerceIn(1, totalGates)
        val mult = when {
            gateMult <= 1.0 -> 1.0
            else -> Math.pow(gateMult, (g - 1).toDouble())
        }
        return baseStake * mult
    }

    /** 计算到第N关为止的累计投入 */
    fun cumulativeStake(gate: Int): Double {
        val g = gate.coerceIn(1, totalGates)
        var sum = 0.0
        for (i in 1..g) sum += stakeAtGate(i)
        return sum
    }

    /** 计算到第N关命中时的累计返还（大小单双按1.98赔率） */
    fun cumulativeReturn(gate: Int, odds: Double = 1.98): Double {
        val g = gate.coerceIn(1, totalGates)
        return stakeAtGate(g) * odds
    }

    /** 计算到第N关命中时的净收益 = 累计返还 - 累计投入 */
    fun netProfitAtGate(gate: Int, odds: Double = 1.98): Double {
        val g = gate.coerceIn(1, totalGates)
        val ret = stakeAtGate(g) * odds
        val cost = cumulativeStake(g)
        return ret - cost
    }
}

/**
 * 过关斩将运行时状态
 */
data class GuoGuanRuntime(
    /** 当前轮次ID（每轮从1开始递增） */
    val roundId: Int = 1,
    /** 当前已过关数（1-based：1=第一关已过，0=未开始/刚斩将） */
    val currentGate: Int = 0,
    /** 当前轮次的开始期号 */
    val startIssue: String = "",
    /** 当前轮次已下注的期号列表 */
    val betIssues: List<String> = emptyList(),
    /** 当前轮次每关结果（true=过关 false=斩将） */
    val gateResults: List<Boolean> = emptyList(),
    /** 累计净收益 */
    val totalProfit: Double = 0.0,
    /** 历史轮次记录 */
    val history: List<GuoGuanRound> = emptyList(),
    /** 是否正在运行 */
    val running: Boolean = false
)

/**
 * 单轮过关斩将记录
 */
data class GuoGuanRound(
    val roundId: Int,
    val startIssue: String,
    val endIssue: String,
    val gatesPassed: Int,
    val totalGates: Int,
    val stake: Double,
    val profit: Double,
    val completed: Boolean,
    val gateResults: List<Boolean>
) {
    val isWin: Boolean get() = gatesPassed >= totalGates
    val label: String get() = if (isWin) "通关" else "第${gatesPassed + 1}关斩将"
}

/**
 * 过关斩将引擎（独立于 BetEngine，不修改原有下注逻辑）。
 *
 * 职责：
 * - 管理过关斩将轮次状态
 * - 生成每关的 BetCommand
 * - 开奖后结算每关结果
 * - 维护历史和累计收益
 */
class GuoGuanEngine {

    private val _runtime = kotlinx.coroutines.flow.MutableStateFlow(GuoGuanRuntime())
    val runtime: kotlinx.coroutines.flow.StateFlow<GuoGuanRuntime> = _runtime

    private val _config = kotlinx.coroutines.flow.MutableStateFlow(GuoGuanConfig())
    val config: kotlinx.coroutines.flow.StateFlow<GuoGuanConfig> = _config

    fun updateConfig(config: GuoGuanConfig) {
        _config.value = config
    }

    /**
     * 开始新一轮过关斩将
     */
    fun startRound(startIssue: String) {
        val cfg = _config.value
        _runtime.value = _runtime.value.copy(
            roundId = _runtime.value.roundId + 1,
            currentGate = 0,
            startIssue = startIssue,
            betIssues = emptyList(),
            gateResults = emptyList(),
            running = cfg.enabled
        )
    }

    /**
     * 生成当前关的 BetCommand
     */
    fun generateBetCommand(
        lotteryKey: String,
        issue: String,
        prediction: String
    ): BetCommand? {
        val cfg = _config.value
        val rt = _runtime.value
        if (!cfg.enabled || !rt.running) return null

        val gate = rt.currentGate + 1
        if (gate > cfg.totalGates) return null

        val stake = cfg.stakeAtGate(gate)
        val action = BetAction(
            category = cfg.category,
            value = prediction,
            extra = mapOf(
                "guoguan" to "true",
                "gate" to gate.toString(),
                "totalGates" to cfg.totalGates.toString(),
                "roundId" to rt.roundId.toString()
            )
        )

        return BetCommand(
            cmdId = BetCommand.generateCmdId(lotteryKey, issue),
            lotteryKey = lotteryKey,
            issue = issue,
            stage = 1,
            leg = gate - 1,
            bets = listOf(action),
            amountText = stake.toInt().toString(),
            source = "guoguan_round${rt.roundId}_gate$gate",
            createdAt = System.currentTimeMillis(),
            expireAt = 0L,
            options = mapOf(
                "mode" to "guoguan",
                "gate" to gate.toString(),
                "totalGates" to cfg.totalGates.toString()
            )
        )
    }

    /**
     * 开奖后结算当前关
     */
    fun settleGate(actual: DrawRecord, predictionHit: Boolean): GuoGuanRound? {
        val cfg = _config.value
        val rt = _runtime.value
        if (!rt.running || rt.currentGate >= cfg.totalGates) return null

        val gate = rt.currentGate + 1
        val stake = cfg.stakeAtGate(gate)
        val odds = BetOdds.forPlay(cfg.category, "", actual.lotteryKey)

        val newResults = rt.gateResults + predictionHit
        val newIssues = rt.betIssues + actual.issue

        if (predictionHit) {
            // 过关
            val profit = stake * (odds - 1.0)
            val newGate = gate
            val isLastGate = newGate >= cfg.totalGates

            if (isLastGate) {
                // 通关：结算累计收益
                val totalProfit = rt.totalProfit + profit
                val round = GuoGuanRound(
                    roundId = rt.roundId,
                    startIssue = rt.startIssue,
                    endIssue = actual.issue,
                    gatesPassed = cfg.totalGates,
                    totalGates = cfg.totalGates,
                    stake = cfg.cumulativeStake(cfg.totalGates),
                    profit = totalProfit,
                    completed = true,
                    gateResults = newResults
                )
                _runtime.value = _runtime.value.copy(
                    currentGate = 0,
                    gateResults = emptyList(),
                    betIssues = emptyList(),
                    totalProfit = totalProfit,
                    history = rt.history + round,
                    running = false
                )
                return round
            } else {
                // 过关但未通关：进入下一关
                _runtime.value = _runtime.value.copy(
                    currentGate = newGate,
                    gateResults = newResults,
                    betIssues = newIssues,
                    totalProfit = rt.totalProfit + profit
                )
                return null
            }
        } else {
            // 斩将：本轮终止
            val cumulativeCost = cfg.cumulativeStake(gate)
            val round = GuoGuanRound(
                roundId = rt.roundId,
                startIssue = rt.startIssue,
                endIssue = actual.issue,
                gatesPassed = gate - 1,
                totalGates = cfg.totalGates,
                stake = cumulativeCost,
                profit = -cumulativeCost,
                completed = true,
                gateResults = newResults
            )
            _runtime.value = _runtime.value.copy(
                currentGate = 0,
                gateResults = emptyList(),
                betIssues = emptyList(),
                totalProfit = rt.totalProfit - cumulativeCost,
                history = rt.history + round,
                running = false
            )
            return round
        }
    }

    /**
     * 停止当前轮次
     */
    fun stopRound() {
        _runtime.value = _runtime.value.copy(running = false)
    }

    /**
     * 重置全部
     */
    fun reset() {
        _runtime.value = GuoGuanRuntime()
    }
}
