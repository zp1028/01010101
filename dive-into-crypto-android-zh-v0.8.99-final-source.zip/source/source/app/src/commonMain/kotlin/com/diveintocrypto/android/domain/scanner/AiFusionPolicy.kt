package com.diveintocrypto.android.domain.scanner

import kotlin.math.abs

/** Minimal, dependency-free advice DTO passed into the local AI-fusion guardrail. */
data class AiFusionAdvice(
    val direction: String,
    val confidence: Int,
    val fakeBreakoutRisk: Int,
    val entry: Double?,
    val stop: Double?,
    val target: Double?,
    val riskRewardRatio: Double?,
)

/**
 * Guardrail for AI-assisted scanner ranking. AI is advisory only: it may nudge
 * ordering inside a small bounded range, but never changes the local direction,
 * local hard filters, or risk decisions.
 */
object AiFusionPolicy {
    data class Decision(
        val delta: Double,
        val status: String,
        val reason: String,
        val acceptedPlan: Boolean,
    )

    fun evaluate(
        localDirection: Int,
        localPrice: Double,
        atrPct: Double?,
        advice: AiFusionAdvice?,
    ): Decision {
        if (advice == null) return Decision(0.0, "NO_ADVICE", "AI未返回可解析的结构化结果，保留本地排行", false)
        if (localDirection == 0) return Decision(0.0, "LOCAL_NEUTRAL", "本地方向不明确，AI不替代本地定向", false)
        if (advice.confidence < 60) return Decision(0.0, "LOW_CONFIDENCE", "AI置信度低于60%，不参与排序", false)

        val aiDirection = when (advice.direction.uppercase()) { "LONG" -> 1; "SHORT" -> -1; else -> 0 }
        var delta = when {
            aiDirection == 0 -> -0.005
            aiDirection == localDirection -> 0.025 * (advice.confidence / 100.0)
            else -> -0.075 * (advice.confidence / 100.0)
        }
        if (advice.fakeBreakoutRisk >= 75) delta -= 0.02
        delta = delta.coerceIn(-0.10, 0.035)

        val entry = advice.entry
        val stop = advice.stop
        val target = advice.target
        val risk = if (entry != null && stop != null) abs(entry - stop) else 0.0
        val reward = if (entry != null && target != null) abs(target - entry) else 0.0
        val computedRr = if (risk > 0.0) reward / risk else 0.0
        val planValid = aiDirection == localDirection && entry != null && stop != null && target != null &&
            entry > 0 && stop > 0 && target > 0 &&
            (if (localDirection > 0) stop < entry && target > entry else stop > entry && target < entry) &&
            computedRr >= 1.2 && (advice.riskRewardRatio == null || advice.riskRewardRatio >= 1.0) && localPrice > 0 &&
            abs(entry - localPrice) / localPrice * 100.0 <= (atrPct?.takeIf { it > 0 }?.times(1.5) ?: 0.75).coerceIn(0.25, 2.0)
        val directionLabel = if (aiDirection == localDirection) "AI与本地方向一致" else if (aiDirection == 0) "AI中性" else "AI与本地方向冲突，已惩罚排名"
        val planLabel = if (planValid) "AI计划通过基础价格/方向/RR校验" else "AI计划未通过校验，不采用其入场止损止盈"
        return Decision(delta, if (aiDirection == localDirection) "ALIGNED" else "CONFLICT", "$directionLabel；$planLabel；假突破风险${advice.fakeBreakoutRisk}%", planValid)
    }
}
