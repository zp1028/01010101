package com.caifenxi.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.data.config.LlmConfigStore
import com.caifenxi.app.domain.execution.ExecutorManager
import com.caifenxi.app.domain.execution.LlmClient
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import kotlinx.coroutines.launch
import com.caifenxi.app.domain.execution.LlmResponse
import com.caifenxi.app.domain.execution.ModelListResult
import com.caifenxi.app.ui.components.SectionTitle

/**
 * AI 大模型设置页面
 * 配置 LLM API 参数、选择模型、测试连接
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiSettingsScreen(
    onBack: () -> Unit = {}
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var config by remember { mutableStateOf(LlmConfigStore.load(context)) }

    var providerExpanded by remember { mutableStateOf(false) }
    var modelExpanded by remember { mutableStateOf(false) }
    var testStatus by remember { mutableStateOf("") }
    var isTesting by remember { mutableStateOf(false) }
    var isLoadingModels by remember { mutableStateOf(false) }
    var modelStatus by remember { mutableStateOf("尚未获取模型") }
    var discoveredModels by remember { mutableStateOf(emptyList<com.caifenxi.app.domain.execution.ModelInfo>()) }
    var lastLatency by remember { mutableStateOf<Long?>(null) }
    var lastError by remember { mutableStateOf<String?>(null) }

    val providers = LlmClient.LlmProvider.entries.toList()
    val models = discoveredModels.ifEmpty { listOf(com.caifenxi.app.domain.execution.ModelInfo(config.model, "当前配置", true, true)) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // 顶栏
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("← 返回") }
            Text(
                "🧠 AI 大模型设置",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(Modifier.height(16.dp))

        // AI 状态总览
        GlobalCard {
            SectionTitle("AI 状态总览")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatusTile("状态", if (lastError == null && config.apiKey.isNotBlank()) "● 就绪" else "○ 待配置", Modifier.weight(1f))
                StatusTile("模型", config.model.ifBlank { "未选择" }, Modifier.weight(1f))
                StatusTile("延迟", lastLatency?.let { "${it}ms" } ?: "—", Modifier.weight(1f))
            }
        }

        // 执行模式选择
        GlobalCard {
            SectionTitle("执行模式")
            val modes = listOf(
                "auto" to "自动（AI优先）",
                "ai_vision" to "仅AI视觉",
                "webview" to "仅内置网页",
                "accessibility" to "仅无障碍"
            )
            var selectedMode by remember { mutableStateOf(ExecutorManager.getMode()) }
            modes.forEach { (value, label) ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = selectedMode == value,
                        onClick = {
                            selectedMode = value
                            ExecutorManager.setMode(value)
                        }
                    )
                    Text(label, modifier = Modifier.padding(start = 8.dp))
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // LLM 提供商
        GlobalCard {
            SectionTitle("LLM 提供商")
            ExposedDropdownMenuBox(
                expanded = providerExpanded,
                onExpandedChange = { providerExpanded = it }
            ) {
                OutlinedTextField(
                    value = config.provider.name,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("提供商") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor()
                )
                ExposedDropdownMenu(
                    expanded = providerExpanded,
                    onDismissRequest = { providerExpanded = false }
                ) {
                    providers.forEach { provider ->
                        DropdownMenuItem(
                            text = { Text(provider.name) },
                            onClick = {
                                config = config.copy(provider = provider)
                                discoveredModels = emptyList()
                                modelStatus = "已切换提供商，请重新获取模型"
                                lastError = null
                                lastLatency = null
                                providerExpanded = false
                            }
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // API 配置
        GlobalCard {
            SectionTitle("API 配置")

            OutlinedTextField(
                value = config.baseUrl,
                onValueChange = { config = config.copy(baseUrl = it) },
                label = { Text("API Base URL") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(8.dp))

            OutlinedTextField(
                value = config.apiKey,
                onValueChange = { config = config.copy(apiKey = it) },
                label = { Text("API Key") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(8.dp))

            // 动态模型发现
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("模型", modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                PrimaryButton(
                    text = if (isLoadingModels) "获取中..." else "🔄 获取模型",
                    onClick = {
                        isLoadingModels = true
                        modelStatus = "正在连接模型服务..."
                        lastError = null
                        coroutineScope.launch {
                            val result = LlmClient(config).listModels()
                            when (result) {
                                is ModelListResult.Success -> {
                                    discoveredModels = result.models
                                    modelStatus = "已获取 ${result.models.size} 个可用模型 · ${result.durationMs}ms"
                                    lastLatency = result.durationMs
                                }
                                is ModelListResult.Error -> {
                                    modelStatus = "获取失败"
                                    lastError = result.message
                                    lastLatency = result.durationMs
                                }
                            }
                            isLoadingModels = false
                        }
                    },
                    enabled = !isLoadingModels && config.apiKey.isNotBlank()
                )
            }

            Spacer(Modifier.height(8.dp))
            ExposedDropdownMenuBox(
                expanded = modelExpanded,
                onExpandedChange = { modelExpanded = it }
            ) {
                OutlinedTextField(
                    value = config.model,
                    onValueChange = { config = config.copy(model = it) },
                    label = { Text("当前模型") },
                    modifier = Modifier.fillMaxWidth().menuAnchor()
                )
                ExposedDropdownMenu(
                    expanded = modelExpanded,
                    onDismissRequest = { modelExpanded = false }
                ) {
                    models.forEach { model ->
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(model.id)
                                    Text(
                                        if (model.supportsVision) "👁 支持视觉 · ${model.providerLabel}" else model.providerLabel,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            },
                            onClick = {
                                config = config.copy(model = model.id)
                                modelExpanded = false
                            }
                        )
                    }
                }
            }
            Text(
                modelStatus,
                fontSize = 12.sp,
                color = if (lastError == null) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(top = 6.dp)
            )
            if (lastError != null) {
                Text(
                    lastError!!,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        // 高级参数
        GlobalCard {
            SectionTitle("高级参数")

            var temperature by remember { mutableStateOf(config.temperature.toFloat()) }
            Text("Temperature: ${String.format("%.1f", temperature)}")
            Slider(
                value = temperature,
                onValueChange = {
                    temperature = it
                    config = config.copy(temperature = it.toDouble())
                },
                valueRange = 0f..1f,
                steps = 9
            )

            Spacer(Modifier.height(8.dp))

            var maxTokens by remember { mutableStateOf(config.maxTokens) }
            Text("Max Tokens: $maxTokens")
            Slider(
                value = maxTokens.toFloat(),
                onValueChange = {
                    maxTokens = it.toInt()
                    config = config.copy(maxTokens = maxTokens)
                },
                valueRange = 128f..2048f,
                steps = 14
            )

            Spacer(Modifier.height(8.dp))

            // 图像质量
            var imageDetail by remember { mutableStateOf(config.imageDetail) }
            Row {
                listOf("low", "medium", "high").forEach { detail ->
                    FilterChip(
                        selected = imageDetail == detail,
                        onClick = {
                            imageDetail = detail
                            config = config.copy(imageDetail = detail)
                        },
                        label = { Text(detail.uppercase()) },
                        modifier = Modifier.padding(end = 8.dp)
                    )
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // 测试连接
        GlobalCard {
            SectionTitle("连接测试")
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                PrimaryButton(
                    text = if (isTesting) "测试中..." else "🧪 测试连接",
                    onClick = {
                        isTesting = true
                        testStatus = ""
                        // 简单的连通性测试
                        coroutineScope.launch {
                            val client = LlmClient(config)
                            val result = client.testConnection()
                            when (result) {
                                is LlmResponse.Success -> {
                                    lastLatency = result.durationMs
                                    lastError = null
                                    testStatus = "✅ 连接成功 · ${result.durationMs}ms"
                                }
                                is LlmResponse.Error -> {
                                    lastLatency = result.durationMs
                                    lastError = result.message
                                    testStatus = "❌ 连接失败 · ${result.durationMs}ms"
                                }
                            }
                            isTesting = false
                        }
                    },
                    enabled = !isTesting && config.apiKey.isNotBlank()
                )
                if (testStatus.isNotBlank()) {
                    Text(
                        testStatus,
                        modifier = Modifier.padding(start = 12.dp),
                        fontSize = 14.sp
                    )
                }
            }
        }

        Spacer(Modifier.height(24.dp))

        // 保存按钮
        PrimaryButton(
            text = "💾 保存配置",
            onClick = {
                LlmConfigStore.save(context, config)
                // 重新注册 AI 执行器以应用新配置
                val app = context.applicationContext as? com.caifenxi.app.CaiFenXiApplication
                app?.registerAiVisionExecutor()
                testStatus = "✅ 配置已保存"
            },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(8.dp))

        Text(
            "提示：AI视觉模式需要无障碍服务已连接，且设备需联网。",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun StatusTile(title: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = MaterialTheme.shapes.medium,
        tonalElevation = 2.dp
    ) {
        Column(Modifier.padding(10.dp)) {
            Text(title, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(3.dp))
            Text(value, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}
