package com.klinealert.nativeapp

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.viewmodel.compose.viewModel
import com.klinealert.nativeapp.domain.Analysis
import com.klinealert.nativeapp.domain.AnalysisEngine
import com.klinealert.nativeapp.domain.Candle
import com.klinealert.nativeapp.domain.ConfirmationGate
import com.klinealert.nativeapp.domain.EvidenceEngine
import com.klinealert.nativeapp.domain.PendingSetup
import com.klinealert.nativeapp.domain.PhaseGate
import com.klinealert.nativeapp.domain.PositionEngine
import com.klinealert.nativeapp.domain.PrecisionCheck
import com.klinealert.nativeapp.domain.PrecisionRank
import com.klinealert.nativeapp.domain.ReviewRecord
import com.klinealert.nativeapp.domain.SymbolOpportunity
import com.klinealert.nativeapp.service.BackgroundMonitorService
import com.klinealert.nativeapp.ui.MarketViewModel
import java.util.Locale
import kotlin.math.abs

/* ---------------- 网页版同款配色 ---------------- */
private val Bg = Color(0xFF0B0E14)
private val Panel = Color(0xFF131722)
private val Panel2 = Color(0xFF1A2030)
private val BorderC = Color(0xFF232A3B)
private val BorderActive = Color(0xFF33405C)
private val TextC = Color(0xFFE8EBF2)
private val MutedC = Color(0xFF8B93A7)
private val Green = Color(0xFF0ECB81)
private val Red = Color(0xFFF6465D)
private val Yellow = Color(0xFFF0B90B)
private val Blue = Color(0xFF4A7DFF)

private fun fmt(v: Double): String {
    val a = kotlin.math.abs(v)
    return when {
        a >= 1000 -> String.format(Locale.US, "%,.2f", v)
        a >= 1 -> String.format(Locale.US, "%.4f", v)
        a >= 0.01 -> String.format(Locale.US, "%.6f", v)
        else -> String.format(Locale.US, "%.4e", v)
    }
}

private fun scoreColor(s: Int): Color = when {
    s >= 80 -> Green
    s >= 65 -> Yellow
    else -> Blue
}

private fun baseName(symbol: String) = symbol.removeSuffix("USDT")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(11, 14, 20)
        window.navigationBarColor = android.graphics.Color.rgb(11, 14, 20)
        setContent {
            androidx.compose.material3.MaterialTheme(colorScheme = darkColorScheme(primary = Yellow, background = Bg, surface = Panel, onBackground = TextC, onSurface = TextC)) {
                Surface(Modifier.fillMaxSize(), color = Bg) {
                    Dashboard(deepLinkTab = intent?.getStringExtra("deep_link_tab"), deepLinkSymbol = intent?.getStringExtra("deep_link_symbol"))
                }
            }
        }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
    }
}

@Composable
private fun Dashboard(vm: MarketViewModel = viewModel(), deepLinkTab: String? = null, deepLinkSymbol: String? = null) {
    val state by vm.state.collectAsState()
    val monitorRunning by BackgroundMonitorService.running.collectAsState()
    // v4.4 通知深链：进入后用一次即可（避免重组重复触发）
    androidx.compose.runtime.LaunchedEffect(deepLinkTab, deepLinkSymbol) {
        if (!deepLinkTab.isNullOrBlank() || !deepLinkSymbol.isNullOrBlank()) vm.handleDeepLink(deepLinkTab, deepLinkSymbol)
    }
    // v4.4 高亮自动清除（3 秒后恢复常态）
    androidx.compose.runtime.LaunchedEffect(state.highlightSymbol) {
        if (state.highlightSymbol != null) { kotlinx.coroutines.delay(3000); vm.clearHighlight() }
    }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, vm) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> vm.startLive()
                Lifecycle.Event.ON_STOP -> vm.stopLive()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        if (lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) vm.startLive()
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer); vm.stopLive() }
    }

    val expanded = remember { mutableStateMapOf<String, Boolean>() }
    var dirFilter by remember { mutableStateOf("ALL") }
    var editingPos by remember { mutableStateOf<com.klinealert.nativeapp.data.LocalStore.LocalPosition?>(null) }
    var showWatching by remember { mutableStateOf(false) }   // 观察区（未触发机会）展开开关
    var watchInput by remember { mutableStateOf("") }        // 关注页手动添加输入
    // 币安跟单页本地 UI 状态（必须在 LazyColumn 外 remember，否则编译失败）
    var tradeApiKey by remember { mutableStateOf("") }
    var tradeApiSecret by remember { mutableStateOf("") }
    var tradeShowLogs by remember { mutableStateOf(false) }
    var tradeSub by remember { mutableStateOf("open") } // open | hist

    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { _ -> vm.setBackgroundMonitor(true) }
    val context = LocalContext.current

    /* 整页单一 LazyColumn：header / tabs / stats / toolbar / 列表全部在其中，任何状态下都能滚动 */
    LazyColumn(Modifier.fillMaxSize().background(Bg), contentPadding = androidx.compose.foundation.layout.PaddingValues(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // ---------- header ----------
        item {
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).border(1.dp, BorderC, RoundedCornerShape(12.dp)).padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.size(10.dp).background(Yellow, CircleShape))
                    Text("K线预警 · 机会看板", color = TextC, fontSize = 14.5.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    Badge(if (state.scanning) "● 扫描中" else "● LIVE", if (state.scanning) Yellow else Green)
                }
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.weight(1f)) { Badge(state.status, MutedC) }
                    Button(onClick = { vm.scanAll() }, enabled = !state.scanning, shape = RoundedCornerShape(8.dp), colors = ButtonDefaults.buttonColors(containerColor = Yellow, contentColor = Color(0xFF111111))) {
                        Text("立即扫描", fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                    }
                }
                if (state.scanning && state.total > 0) {
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(progress = { state.progress.toFloat() / state.total.coerceAtLeast(1) }, modifier = Modifier.fillMaxWidth().height(3.dp), color = Yellow, trackColor = Panel2)
                }
                if (state.symbol.isNotBlank()) {
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("关注 ${state.symbol}", color = MutedC, fontSize = 11.sp)
                        Text(state.livePrice?.let { fmt(it) } ?: "连接中…", color = Yellow, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                        state.changePct?.let { Text("${if (it >= 0) "+" else ""}${String.format(Locale.US, "%.2f", it)}%", color = if (it >= 0) Green else Red, fontSize = 11.sp) }
                        Spacer(Modifier.weight(1f))
                        Text("取消关注", color = MutedC, fontSize = 10.sp, modifier = Modifier.clickable { vm.setSymbol("") })
                    }
                }
                state.error?.let { Spacer(Modifier.height(6.dp)); Text(it, color = Red, fontSize = 11.sp) }
            }
        }

        // ---------- tabs ----------
        item {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                val tabs: List<Pair<String, String>> = listOf(
                    "home" to "工作台",
                    "us" to "美股",
                    "prec" to "精准榜",
                    "latest" to "最新机会 ${state.setups.count { it.value.active }}",
                    "opps" to "机会榜",
                    "watch" to "★关注 ${state.watchlist.size}",
                    "rank" to "胜率榜",
                    "conf" to "确认榜",
                    "pos" to "持仓监控 ${state.positions.size}",
                    "trade" to "币安跟单${if (state.tradeConfig.enabled) "·开" else ""}",
                    "history" to "历史提醒",
                    "diag" to "诊断"
                )
                tabs.forEach { tab ->
                    SegButton(tab.second, state.tab == tab.first) { vm.setTab(tab.first) }
                }
            }
        }

        when (state.tab) {
            "home" -> {
                // ---------- ① 仓位容量条 ----------
                item {
                    val used = state.positions.size
                    val full = used >= state.maxPositions
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(horizontal = 4.dp)) {
                        Text("仓位容量", color = MutedC, fontSize = 11.sp)
                        Text("$used/${state.maxPositions}", color = if (full) Red else Green, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        listOf(1, 2, 3, 5, 8, 10).forEach { n ->
                            SegChip("$n", state.maxPositions == n, Yellow) { vm.setMaxPositions(n) }
                        }
                    }
                    // v4.5 自动作战循环：全自动入仓/平仓 + 固定/移动止盈切换
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)) {
                        Text("自动作战", color = MutedC, fontSize = 11.sp)
                        SegChip(if (state.autoBattle) "全自动开" else "关闭", state.autoBattle, Yellow) { vm.setAutoBattle(!state.autoBattle) }
                        Spacer(Modifier.weight(1f))
                        Text("止盈", color = MutedC, fontSize = 11.sp)
                        SegChip(if (state.trailingEnabled) "移动" else "固定", state.trailingEnabled, Yellow) { vm.setTrailingEnabled(!state.trailingEnabled) }
                    }
                    if (state.autoBattle) {
                        // 收益统计：已平/浮盈均为 USDT（本金×杠杆×方向变动%/100）；size=本金
                        val floatPnl = state.positions.sumOf { p ->
                            val lp = state.positionPrices[p.symbol]
                            if (lp != null && lp > 0) {
                                val move = PositionEngine.directionalMovePct(p.entry, lp, p.direction)
                                PositionEngine.pnlUsdt(p.size, p.leverage, move)
                            } else 0.0
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { vm.toggleBattleHistory() }
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(if (state.showBattleHistory) "▾ 循环统计" else "▸ 循环统计", color = Yellow, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("入 ${state.battleEntered} · 平 ${state.battleClosed}（胜 ${state.battleWins}/负 ${state.battleLosses}）", color = if (state.battleWins >= state.battleLosses) Green else MutedC, fontSize = 10.sp)
                            Text("已平盈亏 ${String.format(Locale.US, "%+.2f", state.battlePnlSum)}U", color = if (state.battlePnlSum >= 0) Green else Red, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("浮盈 ${String.format(Locale.US, "%+.2f", floatPnl)}U", color = if (floatPnl >= 0) Green else Red, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                        if (state.showBattleHistory) {
                            if (state.battleHistory.isEmpty()) {
                                Text("暂无自动平仓记录（平仓后会在此列出每笔明细）", color = MutedC, fontSize = 10.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                            } else {
                                val eng = com.klinealert.nativeapp.domain.BattleLoopEngine
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Panel2, RoundedCornerShape(8.dp))
                                        .padding(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text("已平仓明细（最近 ${state.battleHistory.size.coerceAtMost(50)} 笔 · 点统计行可收起）", color = MutedC, fontSize = 9.5.sp)
                                    state.battleHistory.take(50).forEach { r ->
                                        val closePx = if (r.hitPrice > 0) r.hitPrice else r.entry
                                        val move = PositionEngine.directionalMovePct(r.entry, closePx, r.direction)
                                        val usdt = PositionEngine.pnlUsdt(eng.DEFAULT_MARGIN_USDT, eng.DEFAULT_LEVERAGE, move)
                                        val yld = PositionEngine.yieldPct(eng.DEFAULT_LEVERAGE, move)
                                        val win = r.verdict == "hit"
                                        val ts = if (r.verdictAt > 0) r.verdictAt else r.alertedAt
                                        val timeStr = java.text.SimpleDateFormat("MM-dd HH:mm", Locale.US).format(java.util.Date(ts))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Text(if (win) "✅" else "⛔", fontSize = 11.sp)
                                            Text(baseName(r.symbol), color = TextC, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            Text(if (r.direction == "LONG") "多" else "空", color = if (r.direction == "LONG") Green else Red, fontSize = 10.sp)
                                            Text("${fmt(r.entry)}→${fmt(closePx)}", color = MutedC, fontSize = 9.5.sp)
                                            Spacer(Modifier.weight(1f))
                                            Text("${String.format(Locale.US, "%+.2f", usdt)}U", color = if (usdt >= 0) Green else Red, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            Text("${String.format(Locale.US, "%+.0f", yld)}%", color = if (yld >= 0) Green else Red, fontSize = 9.5.sp)
                                            Text(timeStr, color = MutedC, fontSize = 9.sp)
                                        }
                                    }
                                }
                            }
                        }
                        if (!full && state.battleQueue.isNotEmpty()) {
                            Text("候补队列（坑位空出自动顶上·仅新鲜信号）· ${state.battleQueue.joinToString("  |  ")}", color = MutedC, fontSize = 9.5.sp,
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp))
                        }
                    }
                    if (full) {
                        Text("🛑 满仓监控模式：作战台暂停推荐新信号，只跟踪持仓生命线；平仓后只补新鲜确认信号", color = Red.copy(alpha = 0.9f), fontSize = 10.sp,
                            modifier = Modifier.fillMaxWidth().background(Red.copy(alpha = 0.08f), RoundedCornerShape(8.dp)).padding(horizontal = 10.dp, vertical = 6.dp))
                    }
                    Spacer(Modifier.height(8.dp))
                }
                // ---------- ② 作战台：新鲜度滚动榜单（优中选优 Top8，过期自动下榜不堵死） ----------
                item {
                    val full = state.positions.size >= state.maxPositions
                    val held = state.positions.map { it.symbol }.toSet()
                    val nowMs = System.currentTimeMillis()
                    val engine = com.klinealert.nativeapp.domain.BattleLoopEngine
                    val scored = state.symbolOps.filter { !held.contains(it.symbol) }.mapNotNull { sop ->
                        val c = state.oppConfirm["${sop.market}|${sop.symbol}|${sop.direction}"] ?: return@mapNotNull null
                        if (!engine.isFresh(sop.rep.candleTime, nowMs, sop.rep.timeframe)) return@mapNotNull null   // 过期信号直接不上榜
                        val wr = state.winRank.firstOrNull { it.symbol == sop.symbol }?.rate ?: 40.0
                        val bs = engine.battleScore(sop.score, wr, c.progressAtr, sop.rep.volExpansion, sop.rep.candleTime, nowMs, sop.rep.timeframe)
                        Triple(sop, bs, c)
                    }
                    val confirmed = scored.filter { it.third.status == "已确认" || it.third.status == "回踩确认" }.sortedByDescending { it.second }
                    val pending = scored.filter { it.third.status != "已确认" && it.third.status != "回踩确认" }.sortedByDescending { it.second }
                    val showWatch = remember { mutableStateOf(false) }
                    Text("⚔ 作战台推荐 · 新鲜度滚动榜（过期自动下榜，只进最新信号）", color = Yellow, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp))
                    Spacer(Modifier.height(6.dp))
                    if (full) {
                        Text("🛑 持仓已满（${state.positions.size}/${state.maxPositions}）— 作战台暂停推荐，只跟踪持仓生命线；平仓后只自动补入新鲜确认信号",
                            color = Red.copy(alpha = 0.9f), fontSize = 10.5.sp,
                            modifier = Modifier.fillMaxWidth().background(Red.copy(alpha = 0.06f), RoundedCornerShape(8.dp)).padding(horizontal = 10.dp, vertical = 6.dp))
                    } else {
                        if (confirmed.isEmpty() && pending.isEmpty()) {
                            Text("当前无新鲜合格机会（等新扫描/新确认；旧信号已下榜）", color = MutedC, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 4.dp))
                        } else {
                            val rankLabels = listOf("🥇 首选", "🥈 次选", "🥉 三选")
                            confirmed.take(8).forEachIndexed { i, t ->
                                val role = (rankLabels.getOrNull(i) ?: "第${i + 1}名") + freshBadge(t.first.rep.candleTime, nowMs)
                                BattleCard(role, t.first, t.second, t.third, onExecute = { vm.addPosition(t.first.rep) })
                                Spacer(Modifier.height(6.dp))
                            }
                            if (pending.isNotEmpty()) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth().clickable { showWatch.value = !showWatch.value }.padding(horizontal = 4.dp, vertical = 4.dp)) {
                                    Text(if (showWatch.value) "▾" else "▸", color = Yellow, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Text("🕐 观察中 ${pending.size} 个新鲜信号（未确认，等待确认走出，点击展开）", color = MutedC, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                                }
                                if (showWatch.value) {
                                    pending.take(5).forEach { t ->
                                        BattleCard("👁 观察${freshBadge(t.first.rep.candleTime, nowMs)}", t.first, t.second, t.third, onExecute = null)
                                        Spacer(Modifier.height(6.dp))
                                    }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
                // ---------- ③ 全局仪表 ----------
                item {
                    val longStrong = state.symbolOps.count { it.direction == "LONG" && (state.oppPrices[it.symbol]?.second ?: 0.0) >= 2.0 }
                    val shortStrong = state.symbolOps.count { it.direction == "SHORT" && (state.oppPrices[it.symbol]?.second ?: 0.0) <= -2.0 }
                    val btc = state.symbolOps.firstOrNull { it.symbol == "BTCUSDT" }
                    val sessionLine = state.winStats.firstOrNull { it.contains("时段") }
                    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).border(1.dp, BorderC, RoundedCornerShape(12.dp)).padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("市场仪表", color = Yellow, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        DiagLine("大盘 BTC", if (btc != null) "${btc.direction} · ${btc.rep.regime} · 分 ${btc.score}" else "未扫描")
                        DiagLine("板块共振", if (longStrong >= 5) "🌊 多头潮 $longStrong 个" else if (shortStrong >= 5) "🌊 空头潮 $shortStrong 个" else "无")
                        sessionLine?.let { DiagLine("时段提醒", it) }
                        DiagLine("美股", usMarketCountdown())
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("后台实时监控", color = MutedC, fontSize = 10.sp)
                            Text(if (monitorRunning) "运行中（前台服务 · K线流预警）" else "关闭", color = if (monitorRunning) Green else MutedC, fontSize = 10.sp)
                            Spacer(Modifier.weight(1f))
                            SegChip(if (monitorRunning) "已开启" else "开启", monitorRunning, Yellow) { vm.setBackgroundMonitor(!monitorRunning) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }
            "us" -> {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(horizontal = 4.dp)) {
                        Text("美股行情 · Stooq 免费源（延迟行情）", color = MutedC, fontSize = 10.sp)
                        Spacer(Modifier.weight(1f))
                        Text("刷新", color = Yellow, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { vm.loadUsQuotes() }.padding(4.dp))
                    }
                    Spacer(Modifier.height(6.dp))
                    DiagLine("时段", usMarketCountdown())
                    Spacer(Modifier.height(6.dp))
                }
                if (state.usQuotes.isEmpty()) {
                    item { EmptyBox("下拉刷新或点「刷新」加载指数与自选股\n自选股点击下方列表中的 × 删除") }
                } else {
                    items(state.usQuotes, key = { it.symbol }) { q ->
                        val up = q.chgPct >= 0
                        val idx = q.symbol.startsWith("^")
                        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).border(1.dp, BorderC, RoundedCornerShape(12.dp)).padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(if (idx) "📊 ${q.symbol}" else baseName(q.symbol), color = TextC, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                if (idx) Text("指数", color = MutedC, fontSize = 9.sp)
                                Spacer(Modifier.weight(1f))
                                Text(String.format(Locale.US, "%.2f", q.price), color = TextC, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Text("${if (up) "+" else ""}${String.format(Locale.US, "%.2f", q.chgPct)}%",
                                    color = if (up) Green else Red, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                if (!idx) Text("×", color = MutedC, fontSize = 13.sp, modifier = Modifier.clickable { vm.toggleUsWatch(q.symbol) }.padding(4.dp))
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                }
                item {
                    Spacer(Modifier.height(4.dp))
                    Text("添加自选（点选）", color = MutedC, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 4.dp))
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("AAPL", "NVDA", "TSLA", "MSFT", "COIN", "MSTR", "AMD", "META").forEach { sym ->
                            SegChip(sym, state.usWatch.contains(sym), Yellow) { vm.toggleUsWatch(sym) }
                        }
                    }
                    Text("备注：美股开盘时段常与加密波动放大联动（波动自适应失效已自动放宽）", color = MutedC, fontSize = 9.5.sp, modifier = Modifier.padding(horizontal = 4.dp))
                }
            }
            "prec" -> {
                item {
                    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).border(1.dp, Yellow.copy(alpha = 0.35f), RoundedCornerShape(12.dp)).padding(10.dp)) {
                        Text("★ 精准入场榜 · 14 项加权门槛 · 宁缺毋滥", color = Yellow, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("核心×1.5：多周期共振 / 无反向 / 金叉状态延续 / 位置贴近周期极值 / 量能确认。标准×1.0：距关键位≤0.6% / 盈亏比≥1.5 / ATR 0.3~5% / RSI不极端 / 可信度≥60 / 阶段匹配 / 15m不逆向加速。软性×0.5：历史胜率背书 / 波动健康度。A 级=核心全过且加权≥90。", color = MutedC, fontSize = 10.sp, lineHeight = 13.sp)
                    }
                }
                val ranked = state.symbolOps
                    .map { sop -> sop to PrecisionRank.evaluate(sop, state.oppPrices[sop.symbol]?.first, state.tfWinRates) }
                    .map { (sop, checks) -> Triple(sop, checks, PrecisionRank.rankScore(checks)) }
                    .sortedWith(compareByDescending<Triple<SymbolOpportunity, List<PrecisionCheck>, Int>> { it.third }.thenByDescending { it.first.score })
                if (ranked.isEmpty()) {
                    item { EmptyBox("暂无机会数据\n请先到「机会榜」扫描") }
                } else {
                    items(ranked, key = { it.first.market + "-" + it.first.symbol }) { (sop, checks, rank) ->
                        val key = sop.market + sop.symbol
                        val live = state.oppPrices[sop.symbol]
                        Column {
                            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("精准度 $rank", color = if (rank >= 88) Yellow else MutedC, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                checks.filter { !it.pass }.take(3).forEach { c -> Text("✗ ${c.label}", color = Red.copy(alpha = 0.85f), fontSize = 9.5.sp) }
                                if (rank == 100) ResChip("全条件达成", Yellow)
                            }
                            SymbolOppRow(sop, live?.first, live?.second, expanded[key] == true, showWatch = true, inWatchlist = state.watchlist.contains(sop.symbol), onClick = { expanded[key] = !(expanded[key] == true) }, onAddPosition = { vm.addPosition(sop.rep) }, onOpen = { vm.setSymbol(sop.symbol) }, onToggleWatch = { vm.toggleWatch(sop.symbol) }, tfWinRates = state.tfWinRates, onSetRR = { vm.setRiskReward(sop.symbol, sop.market, it) }, onBinance = { openBinanceFutures(context, sop.symbol) }, miniCandles = vm.miniSeries(sop.symbol, sop.market), health = state.oppHealth[sop.symbol], confirm = state.oppConfirm["${sop.market}|${sop.symbol}|${sop.direction}"], position = state.positions.firstOrNull { it.symbol == sop.symbol && it.market == sop.market },
                            aiConfigured = state.aiConfigured, aiInsight = state.aiInsights["${sop.market}|${sop.symbol}"],
                            aiBusyNow = state.aiBusy == "${sop.market}|${sop.symbol}", onAi = { vm.aiExplain(sop) })
                        }
                    }
                }
            }
            "watch" -> {
                item {
                    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("★ 关注品种不受评分阈值限制，始终在实时行情流中。机会卡右上角点 ★ 或在下方直接输入添加。", color = MutedC, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(value = watchInput, onValueChange = { watchInput = it.uppercase() }, modifier = Modifier.weight(1f), singleLine = true,
                                placeholder = { Text("输入币种如 SOL", color = MutedC, fontSize = 11.5.sp) }, shape = RoundedCornerShape(8.dp),
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextC, unfocusedTextColor = TextC, focusedContainerColor = Panel2, unfocusedContainerColor = Panel2, focusedBorderColor = BorderActive, unfocusedBorderColor = BorderC, cursorColor = Yellow))
                            Button(onClick = {
                                val sym = watchInput.trim().uppercase()
                                if (sym.isNotEmpty() && !state.watchlist.contains(sym)) {
                                    vm.toggleWatch(sym); watchInput = ""
                                }
                            }, colors = ButtonDefaults.buttonColors(containerColor = Yellow)) {
                                Text("添加", color = Color(0xFF0B0E14), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                if (state.watchlist.isEmpty()) {
                    item { EmptyBox("还没有关注品种\n在「机会榜」卡片右上角点击 ☆ 加入") }
                } else {
                    items(state.watchlist.sorted(), key = { it }) { sym ->
                        val sop = state.symbolOps.firstOrNull { it.symbol == sym }
                        val live = state.oppPrices[sym]
                        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(12.dp)) {
                            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(baseName(sym), color = TextC, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text("USDT", color = MutedC, fontSize = 8.5.sp)
                                sop?.let { DirChip(it.direction) }
                                Spacer(Modifier.weight(1f))
                                Text(live?.first?.let { fmt(it) } ?: sop?.price?.let(::fmt) ?: "—", color = Yellow, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                                live?.second?.let {
                                    Text("${if (it >= 0) "+" else ""}${String.format(Locale.US, "%.2f", it)}%", color = if (it >= 0) Green else Red, fontSize = 10.sp)
                                }
                                Text("移除", color = Red, fontSize = 11.sp, modifier = Modifier.clickable { vm.toggleWatch(sym) }.padding(4.dp))
                            }
                        }
                    }
                }
            }
            "trade" -> {
                // 底栏汇总（apiKey 等状态已在 LazyColumn 外 hoist）
                item {
                    val st = state.tradeStats
                    val acc = state.tradeAccount
                    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).border(1.dp, if (state.tradeConfig.enabled) Yellow else BorderC, RoundedCornerShape(12.dp)).padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("币安 U 本位跟单", color = Yellow, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text(if (state.tradeConnected) "已连接" else "未连接", color = if (state.tradeConnected) Green else MutedC, fontSize = 11.sp)
                            if (state.tradeConfig.testnet) Text("测试网", color = Yellow, fontSize = 10.sp)
                            Spacer(Modifier.weight(1f))
                            if (state.tradeConnected) {
                                Text("可用 ${String.format(Locale.US, "%.2f", acc.availableBalance)}U", color = TextC, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        state.tradeMessage?.let { Text(it, color = MutedC, fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp)) }
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("浮盈 ${String.format(Locale.US, "%+.2f", st.floatingPnl)}U", color = if (st.floatingPnl >= 0) Green else Red, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("已实现 ${String.format(Locale.US, "%+.2f", st.realizedPnl)}U", color = if (st.realizedPnl >= 0) Green else Red, fontSize = 11.sp)
                            Text("胜 ${st.wins}/负 ${st.losses}", color = MutedC, fontSize = 11.sp)
                            Text("持仓 ${st.openCount}/${state.tradeConfig.maxFollowSlots}", color = TextC, fontSize = 11.sp)
                        }
                    }
                }
                // 连接 / 确认
                item {
                    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("① 连接账户", color = Yellow, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        if (state.tradePendingConfirm) {
                            Text("请确认以下账户（登入返回确认）", color = TextC, fontSize = 11.sp)
                            Text("标识 ${state.tradeAccount.accountIdMask} · ${state.tradeAccount.positionMode}", color = MutedC, fontSize = 10.sp)
                            Text("可用 ${String.format(Locale.US, "%.2f", state.tradeAccount.availableBalance)} USDT · 权益 ${String.format(Locale.US, "%.2f", state.tradeAccount.walletBalance)}", color = Green, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { vm.tradeConfirmEnable() }, colors = ButtonDefaults.buttonColors(containerColor = Yellow)) {
                                    Text("确认启用", color = Color(0xFF0B0E14), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                OutlinedButton(onClick = { vm.tradeCancelConfirm() }) { Text("返回修改", color = MutedC, fontSize = 12.sp) }
                            }
                        } else if (!state.tradeConnected) {
                            Text("密钥仅存本机。请关闭提现权限，建议先测试网。", color = MutedC, fontSize = 10.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                SegChip("测试网", state.tradeConfig.testnet, Yellow) {
                                    vm.updateTradeConfig(state.tradeConfig.copy(testnet = true))
                                }
                                SegChip("主网", !state.tradeConfig.testnet, Red) {
                                    vm.updateTradeConfig(state.tradeConfig.copy(testnet = false))
                                }
                            }
                            OutlinedTextField(value = tradeApiKey, onValueChange = { tradeApiKey = it }, modifier = Modifier.fillMaxWidth(), singleLine = true,
                                placeholder = { Text("API Key", color = MutedC) },
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextC, unfocusedTextColor = TextC, focusedContainerColor = Panel2, unfocusedContainerColor = Panel2, focusedBorderColor = BorderActive, unfocusedBorderColor = BorderC, cursorColor = Yellow))
                            OutlinedTextField(value = tradeApiSecret, onValueChange = { tradeApiSecret = it }, modifier = Modifier.fillMaxWidth(), singleLine = true,
                                placeholder = { Text("Secret Key", color = MutedC) },
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextC, unfocusedTextColor = TextC, focusedContainerColor = Panel2, unfocusedContainerColor = Panel2, focusedBorderColor = BorderActive, unfocusedBorderColor = BorderC, cursorColor = Yellow))
                            Button(
                                onClick = { vm.tradeVerify(tradeApiKey, tradeApiSecret, state.tradeConfig.testnet) },
                                enabled = !state.tradeBusy,
                                colors = ButtonDefaults.buttonColors(containerColor = Yellow)
                            ) { Text(if (state.tradeBusy) "验证中…" else "连接并验证", color = Color(0xFF0B0E14), fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                        } else {
                            Text("${state.tradeAccount.accountIdMask} · ${state.tradeAccount.positionMode}", color = MutedC, fontSize = 10.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { vm.refreshTradeAccount() }) { Text("刷新余额", color = Yellow, fontSize = 11.sp) }
                                OutlinedButton(onClick = { vm.tradeDisconnect() }) { Text("断开清除", color = Red, fontSize = 11.sp) }
                            }
                        }
                    }
                }
                // 配置
                if (state.tradeConnected) {
                    item {
                        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("② 跟单配置", color = Yellow, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("全自动跟单", color = TextC, fontSize = 12.sp)
                                SegChip(if (state.tradeConfig.enabled) "已开启" else "关闭", state.tradeConfig.enabled, if (state.tradeConfig.enabled) Green else MutedC) {
                                    vm.setTradeFollowEnabled(!state.tradeConfig.enabled)
                                }
                            }
                            Text("每笔保证金（本金 USDT）", color = MutedC, fontSize = 10.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf(5.0, 10.0, 20.0, 50.0).forEach { m ->
                                    SegChip("${m.toInt()}U", state.tradeConfig.marginUsdt == m, Yellow) {
                                        vm.updateTradeConfig(state.tradeConfig.copy(marginUsdt = m))
                                    }
                                }
                            }
                            Text("最大同时跟随仓数", color = MutedC, fontSize = 10.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf(1, 2, 3, 5, 8).forEach { n ->
                                    SegChip("$n", state.tradeConfig.maxFollowSlots == n, Yellow) {
                                        vm.updateTradeConfig(state.tradeConfig.copy(maxFollowSlots = n))
                                    }
                                }
                            }
                            Text("杠杆：默认品种最大 · 封顶 ${state.tradeConfig.maxLeverageCap}x", color = MutedC, fontSize = 10.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf(5, 10, 20, 50).forEach { n ->
                                    SegChip("≤${n}x", state.tradeConfig.maxLeverageCap == n, Yellow) {
                                        vm.updateTradeConfig(state.tradeConfig.copy(maxLeverageCap = n))
                                    }
                                }
                            }
                            Text("止盈止损严格跟随监控页（同盈亏比价位挂条件单）；市价开仓；仅跟建仓5分钟内仓位；开平去重。", color = MutedC, fontSize = 9.5.sp)
                        }
                    }
                }
                // 子 Tab
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SegChip("持仓中 ${state.tradeOpenLinks.size}", tradeSub == "open", Yellow) { tradeSub = "open" }
                        SegChip("历史战绩 ${state.tradeHistory.size}", tradeSub == "hist", Yellow) {
                            tradeSub = "hist"; vm.refreshTradeLinks()
                        }
                        SegChip(if (tradeShowLogs) "日志▾" else "日志▸", tradeShowLogs, MutedC) { tradeShowLogs = !tradeShowLogs }
                    }
                }
                if (tradeSub == "open") {
                    if (state.tradeOpenLinks.isEmpty()) {
                        item { EmptyBox("暂无实盘跟单持仓\n开启跟单后，持仓监控开仓将自动市价跟单") }
                    } else {
                        items(state.tradeOpenLinks, key = { it.localPositionId }) { link ->
                            TradeLinkCard(link, live = true)
                        }
                    }
                } else {
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("today" to "今日", "7d" to "7日", "30d" to "30日", "all" to "全部").forEach { (k, lab) ->
                                SegChip(lab, state.tradeHistoryRange == k, Yellow) { vm.setTradeHistoryRange(k) }
                            }
                        }
                        val st = state.tradeStats
                        Text(
                            "已实现 ${String.format(Locale.US, "%+.2f", st.realizedPnl)}U · 胜${st.wins}/负${st.losses}/平${st.flats} · 胜率 ${String.format(Locale.US, "%.0f", st.winRate)}% · 手续费 ${String.format(Locale.US, "%.2f", st.fees)}U",
                            color = MutedC, fontSize = 10.sp, modifier = Modifier.padding(vertical = 4.dp)
                        )
                    }
                    if (state.tradeHistory.isEmpty()) {
                        item { EmptyBox("暂无已平跟单记录") }
                    } else {
                        items(state.tradeHistory, key = { it.localPositionId + it.closedAt }) { link ->
                            TradeLinkCard(link, live = false)
                        }
                    }
                }
                if (tradeShowLogs) {
                    items(state.tradeLogs, key = { it.at.toString() + it.action + it.detail }) { log ->
                        Text(
                            "${java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(java.util.Date(log.at))} ${log.symbol} ${log.action} ${if (log.ok) "✓" else "✗"} ${log.detail}",
                            color = if (log.ok) MutedC else Red, fontSize = 9.5.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }
            }
            "diag" -> {
                item {
                    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).border(1.dp, BorderC, RoundedCornerShape(12.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("=== 运行环境 ===", color = Yellow, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        DiagLine("市场", "${state.market} · 周期 ${state.scanTimeframes.sorted().joinToString("/")}")
                        DiagLine("前台实时", if (state.livePrice != null) "已连接" else if (state.symbol.isBlank()) "未关注品种" else "连接中")
                        DiagLine("全市场实时流", if (state.status.contains("全市场")) "运行中" else state.status)
                        DiagLine("后台预警", if (BackgroundMonitorService.running.collectAsState().value) "运行中" else "关闭")
                        Text("=== 扫描覆盖 ===", color = Yellow, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
                        DiagLine("扫描品种", "${state.instruments}")
                        DiagLine("聚合机会", "${state.symbolOps.size} 个品种")
                        DiagLine("关注品种", "${state.watchlist.size}")
                        DiagLine("扫描进度", if (state.scanning) "${state.progress}/${state.total}" else "空闲")
                        Text("=== 健康 ===", color = Yellow, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
                        DiagLine("最近错误", state.error ?: "无")
                        DiagLine("实时价格样本", state.oppPrices.size.toString() + " 个品种有实时价")
                        Text("=== 运行日志 ===", color = Yellow, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("共 ${state.runtimeLogs.size} 条（新在上，内存保留约 200）", color = MutedC, fontSize = 10.sp)
                            Spacer(Modifier.weight(1f))
                            Text("清空", color = Yellow, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.clickable { vm.clearRuntimeLogs() }.padding(4.dp))
                        }
                        if (state.runtimeLogs.isEmpty()) {
                            Text("暂无日志。全市场连接、重连、扫描、跟单事件会写在这里。", color = MutedC, fontSize = 10.sp, modifier = Modifier.padding(vertical = 4.dp))
                        } else {
                            Column(
                                Modifier.fillMaxWidth().background(Panel2, RoundedCornerShape(8.dp)).padding(8.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                state.runtimeLogs.take(80).forEach { log ->
                                    val col = when (log.level) {
                                        "ERROR" -> Red
                                        "WARN" -> Yellow
                                        else -> MutedC
                                    }
                                    val time = java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(java.util.Date(log.at))
                                    Text("$time [${log.level}] ${log.tag} · ${log.message}", color = col, fontSize = 9.5.sp, lineHeight = 12.sp)
                                }
                            }
                        }
                        run {
                            val since = if (state.lastTickAt > 0) (System.currentTimeMillis() - state.lastTickAt) / 1000 else -1
                            DiagLine("机会实时流", if (state.oppStreamSockets > 0 && since in 0..30)
                                "${state.oppStreamSockets} 个连接 · 最后行情 ${since} 秒前"
                            else if (state.oppStreamSockets > 0) "${state.oppStreamSockets} 个连接 · ⚠ 行情中断 ${if (since > 0) since else "?"} 秒，自动重连中"
                            else "未连接（扫描后自动开启）")
                        }
                        DiagLine("关注流覆盖", state.watchlist.count { state.oppPrices.containsKey(it) }.toString() + "/" + state.watchlist.size)
                        DiagLine("交叉校验源", when {
                            state.crossCheckOk -> "Gate.io 参考价 ${state.crossCheckCount} 条 · 已启用（防插针）"
                            state.crossCheckError.isNotBlank() -> "不可用（${state.crossCheckError}）· 已降级，不拦截"
                            else -> "加载中…（不可用时不影响正常功能）"
                        })
                        Text("=== 信号胜率（本地 24h 回访） ===", color = Yellow, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
                        state.winStats.forEach { DiagLine("·", it) }
                        if (state.learnedWeights.isNotEmpty()) {
                            Text("=== 学习权重（胜率→周期×方向权重） ===", color = Yellow, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
                            state.learnedWeights.toSortedMap().forEach { (key, w) ->
                                val (n, rate) = state.tfWinRates[key] ?: (0 to 0.0)
                                val tag = if (n < 20) " · ⚠样本不足" else ""
                                DiagLine(key.replace("|", " "), String.format(Locale.US, "胜率 %.0f%%（样本 %d）→ 权重 %.2f%s", rate * 100, n, w, tag))
                            }
                        }
                        Button(onClick = { vm.exportCsv() }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp), colors = ButtonDefaults.buttonColors(containerColor = Panel2)) {
                            Text("导出记账 CSV（训练数据）", color = Yellow, fontSize = 11.sp)
                        }
                        Text("=== 模式校准（ML-1 预置） ===", color = Yellow, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
                        if (state.patternStats.isEmpty()) {
                            DiagLine("状态", "样本积累中：每模式需 ≥20 个已结算样本，到量后自动加减分")
                        } else {
                            state.patternStats.take(8).forEach { ps ->
                                val label = ps.key.replace("|", " ")
                                DiagLine(label, String.format(Locale.US, "胜率 %.0f%%（样本 %d）→ 校准 %+d 分", ps.rate * 100, ps.samples, ps.bonus))
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 4.dp)) {
                            Text("省电模式（实时流 40 品种）", color = MutedC, fontSize = 11.sp)
                            SegChip(if (state.powerSave) "已开启" else "关闭", state.powerSave, Yellow) { vm.togglePowerSave() }
                        }
                        // ---------- v4.4 回测校准报告 ----------
                        Text("=== 回测校准（真实样本） ===", color = Yellow, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                        run {
                            val bt = state.backtest
                            if (bt == null) {
                                DiagLine("状态", "点击下方按钮生成报告（需已积累结算样本）")
                            } else {
                                DiagLine("样本", bt.note)
                                bt.scoreBands?.let { sb ->
                                    Text("· 证据分段胜率", color = TextC, fontSize = 10.5.sp, modifier = Modifier.padding(top = 2.dp))
                                    sb.bands.forEach { b ->
                                        val tag = if (b.reliable) "" else "（样本不足）"
                                        DiagLine("  ${b.label}", String.format(Locale.US, "胜率 %.0f%%（%d 个）%s", b.rate * 100, b.samples, tag))
                                    }
                                    DiagLine("  建议阈值", "≥${sb.suggestedThreshold}（当前 85，仅供参考勿强改）")
                                }
                                bt.pullback?.let { pb ->
                                    Text("· 回踩确认 vs 直接触发", color = TextC, fontSize = 10.5.sp, modifier = Modifier.padding(top = 2.dp))
                                    DiagLine("  回踩确认", String.format(Locale.US, "胜率 %.0f%%（%d 个）%s", pb.pullback.rate * 100, pb.pullback.samples, if (pb.pullback.reliable) "" else "（样本不足）"))
                                    DiagLine("  直接触发", String.format(Locale.US, "胜率 %.0f%%（%d 个）%s", pb.direct.rate * 100, pb.direct.samples, if (pb.direct.reliable) "" else "（样本不足）"))
                                    if (pb.pullback.reliable && pb.direct.reliable)
                                        DiagLine("  结论", if (pb.pullbackBetter) "回踩确认更优 ✓（v4.1 假设得到支持）" else "暂无显著优势（继续积累）")
                                }
                                bt.walkForward?.let { wf ->
                                    Text("· 样本外验证（训练 70% / 验证 30%）", color = TextC, fontSize = 10.5.sp, modifier = Modifier.padding(top = 2.dp))
                                    DiagLine("  训练段", String.format(Locale.US, "胜率 %.0f%%（%d 个）", wf.trainRate * 100, wf.trainSamples))
                                    DiagLine("  验证段", String.format(Locale.US, "胜率 %.0f%%（%d 个）", wf.testRate * 100, wf.testSamples))
                                    DiagLine("  结论", if (wf.overfit) String.format(Locale.US, "⚠ 验证段落后 %.0f 个百分点，疑似过拟合/市场漂移", wf.degradation * 100) else "训练验证一致，未见明显过拟合 ✓")
                                }
                            }
                        }
                        Button(onClick = { vm.loadBacktest() }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp), colors = ButtonDefaults.buttonColors(containerColor = Panel2)) {
                            Text("生成/刷新回测校准报告", color = Yellow, fontSize = 11.sp)
                        }
                        // ---------- AI 大模型配置（OpenAI 兼容，完全可选） ----------
                        val diagFieldColors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextC, unfocusedTextColor = TextC, focusedContainerColor = Panel2, unfocusedContainerColor = Panel2, focusedBorderColor = BorderActive, unfocusedBorderColor = BorderC, cursorColor = Yellow)
                        var aiUrl by remember(state.aiBaseUrl) { mutableStateOf(state.aiBaseUrl) }
                        var aiKey by remember(state.aiKey) { mutableStateOf(state.aiKey) }
                        var aiModel by remember(state.aiModel) { mutableStateOf(state.aiModel) }
                        Text("=== AI 大模型（可选，未配置不影响使用） ===", color = Yellow, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                        DiagLine("说明", "兼容 DeepSeek/通义/Kimi/OpenAI/Ollama 等任意 OpenAI 兼容端点；密钥只存本机")
                        OutlinedTextField(value = aiUrl, onValueChange = { aiUrl = it }, modifier = Modifier.fillMaxWidth(), singleLine = true,
                            label = { Text("大模型链接（含 /v1）", color = MutedC, fontSize = 10.sp) },
                            placeholder = { Text("https://api.deepseek.com/v1", color = MutedC, fontSize = 10.sp) },
                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp, color = TextC),
                            shape = RoundedCornerShape(8.dp), colors = diagFieldColors)
                        OutlinedTextField(value = aiKey, onValueChange = { aiKey = it }, modifier = Modifier.fillMaxWidth(), singleLine = true,
                            label = { Text("API 密钥（Key）", color = MutedC, fontSize = 10.sp) },
                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp, color = TextC),
                            shape = RoundedCornerShape(8.dp), colors = diagFieldColors)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(value = aiModel, onValueChange = { aiModel = it }, modifier = Modifier.weight(1f), singleLine = true,
                                label = { Text("模型名（可手填或点下方获取）", color = MutedC, fontSize = 10.sp) },
                                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp, color = TextC),
                                shape = RoundedCornerShape(8.dp), colors = diagFieldColors)
                            Text("保存", color = Yellow, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.clickable { vm.saveAiConfig(aiUrl, aiKey, aiModel) }.padding(8.dp))
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { vm.saveAiConfig(aiUrl, aiKey, aiModel); vm.fetchAiModels() }, enabled = state.aiBusy != "config",
                                modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Panel2)) {
                                Text(if (state.aiBusy == "config" && state.aiModels.isEmpty()) "获取中…" else "获取模型", color = Yellow, fontSize = 11.sp)
                            }
                            Button(onClick = { vm.saveAiConfig(aiUrl, aiKey, aiModel); vm.testAiConnection() }, enabled = state.aiBusy != "config",
                                modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Panel2)) {
                                Text("确定链接（测试）", color = Yellow, fontSize = 11.sp)
                            }
                        }
                        state.aiTestMsg?.let { Text(it, color = if (it.startsWith("✅") || it.startsWith("已保存")) Green else MutedC, fontSize = 10.sp) }
                        if (state.aiModels.isNotEmpty()) {
                            Text("可用模型（点击选择）：", color = MutedC, fontSize = 10.sp, modifier = Modifier.padding(top = 2.dp))
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                state.aiModels.take(12).forEach { m ->
                                    Text(if (m == state.aiModel) "✓ $m" else "　$m",
                                        color = if (m == state.aiModel) Yellow else TextC, fontSize = 10.5.sp,
                                        modifier = Modifier.fillMaxWidth().clickable { aiModel = m; vm.selectAiModel(m) }.padding(vertical = 2.dp))
                                }
                            }
                        }
                    }
                }
            }
            "latest" -> {
                // ---------- 最新机会（待命单）：按生成时间倒序，越靠前越新 ----------
                item {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("⚡ 最新机会 · 按生成时间倒序（越靠前越新）", color = Yellow, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Button(onClick = { vm.scanAll() }, enabled = !state.scanning, shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Yellow, contentColor = Color(0xFF111111))) {
                            Text(if (state.scanning) "刷新中…" else "刷新", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    Text("待命单 = 价格到触发价才可入场；未到位的机会提前展示，给你准备时间", color = MutedC, fontSize = 10.sp)
                    Spacer(Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("触发推送", color = MutedC, fontSize = 10.sp)
                        SegChip("证据≥85 响亮 / ≥70 普通", true, Yellow) { }
                        Text("夜间静音(23-08)", color = MutedC, fontSize = 10.sp)
                        SegChip(if (vm.quietEnabled()) "已开启" else "已关闭", vm.quietEnabled(), Yellow) { vm.setQuietEnabled(!vm.quietEnabled()) }
                    }
                }
                val nowMs = System.currentTimeMillis()
                val activeSetups = state.setups.values.filter { it.active }.sortedByDescending { it.createdAt }
                val triggeredFirst = activeSetups.sortedWith(
                    compareByDescending<PendingSetup> { it.status == PendingSetup.TRIGGERED }
                        .thenByDescending { it.status == PendingSetup.ARMED }
                        .thenByDescending { it.createdAt })
                if (triggeredFirst.isEmpty()) {
                    item { EmptyBox("暂无待命单\n扫描后，价格到关键位的品种会生成「待命单」在此排队") }
                } else {
                    items(triggeredFirst, key = { "st_" + it.key }) { st ->
                        val live = state.oppPrices[st.symbol]?.first
                        val dist = st.distPct(live)
                        val isTrig = st.status == PendingSetup.TRIGGERED
                        val isArmed = st.status == PendingSetup.ARMED
                        val dirC = if (st.direction == "LONG") Green else Red
                        val highlighted = state.highlightSymbol == st.symbol
                        Column(Modifier.fillMaxWidth().background(if (highlighted) Yellow.copy(alpha = 0.07f) else Panel, RoundedCornerShape(12.dp)).border(if (highlighted) 2.dp else 1.dp, if (highlighted) Yellow else if (isTrig) dirC.copy(alpha = 0.6f) else if (isArmed) Yellow.copy(alpha = 0.6f) else BorderC, RoundedCornerShape(12.dp)).padding(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(baseName(st.symbol), color = TextC, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                DirChip(st.direction)
                                Text(st.timeframe, color = MutedC, fontSize = 9.sp)
                                when {
                                    isTrig -> ResChip("⚡ 可入场", dirC)
                                    isArmed -> ResChip("⏳ 等回踩确认", Yellow)
                                    else -> ResChip("🕐 待命", MutedC)
                                }
                                Spacer(Modifier.weight(1f))
                                ResChip("证据${st.evidenceScore}", if (st.evidenceScore >= 85) Yellow else if (st.evidenceScore >= 70) Color(0xFF4A7DFF) else MutedC)
                                // v4.4 手动忽略：不等自动过期，用户可主动清掉不想看的单
                                Text("✕", color = MutedC, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                                    modifier = Modifier.clickable { vm.dismissSetup(st.key) }.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                            Spacer(Modifier.height(6.dp))
                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                PlanCell(if (st.direction == "LONG") "回踩触发" else "反抽触发", fmt(st.triggerPrice), dirC)
                                PlanCell("失效价", fmt(st.invalidPrice), Red)
                                PlanCell("止损", fmt(st.stop), Red)
                                PlanCell("止盈3R", fmt(st.target3R), Green)
                            }
                            Spacer(Modifier.height(6.dp))
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (isTrig) {
                                    Text("⚡ 回踩确认 ${fmt(st.triggeredPrice)} · 现价 ${live?.let { fmt(it) } ?: "—"}", color = dirC, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                } else if (isArmed) {
                                    Text("⏳ 已到触发价，等回踩至 ${fmt(st.triggerPrice)} ±0.5ATR 确认", color = Yellow, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                } else {
                                    Text("距触发 ${dist?.let { String.format(Locale.US, "%+.2f", it) } ?: "—"}%", color = if (dist != null && abs(dist) <= 1.0) Yellow else MutedC, fontSize = 10.sp)
                                    Text("· 3门 ${if (st.gatePosition) "✓" else "✗"}位 ${if (st.gateSignal) "✓" else "✗"}号 ${if (st.gateTime) "✓" else "✗"}时", color = MutedC, fontSize = 9.5.sp)
                                    if (st.missingGate.isNotBlank()) Text("· ${st.missingGate}", color = MutedC, fontSize = 9.5.sp)
                                }
                                Spacer(Modifier.weight(1f))
                                Text("⏰ 剩 ${remainText(st.remainMs(nowMs))}", color = MutedC, fontSize = 9.5.sp)
                            }
                            // v4.0 AI 复核（仅证据≥85 触发时自动生成；未配置 AI 不显示）
                            val review = state.setupReviews[st.key]
                            if (state.aiReviewing == st.key) {
                                Spacer(Modifier.height(4.dp))
                                Text("🤖 AI 复核中…", color = Yellow, fontSize = 9.5.sp)
                            } else if (review != null) {
                                Spacer(Modifier.height(4.dp))
                                Column(Modifier.fillMaxWidth().background(Yellow.copy(alpha = 0.05f), RoundedCornerShape(8.dp)).border(1.dp, BorderC, RoundedCornerShape(8.dp)).padding(8.dp)) {
                                    Text("🤖 AI 复核（辅助参考）", color = Yellow, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                                    Text(review, color = TextC, fontSize = 9.5.sp, lineHeight = 13.sp)
                                }
                            }
                            Spacer(Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("生成于 ${timeAgoText(nowMs - st.createdAt)}", color = MutedC, fontSize = 9.sp)
                                if (st.note.isNotBlank()) Text("· ${st.note}", color = MutedC, fontSize = 9.sp)
                                Spacer(Modifier.weight(1f))
                                val sopFor = state.symbolOps.firstOrNull { it.symbol == st.symbol && it.direction == st.direction }
                                val samePos = state.positions.firstOrNull { it.symbol == st.symbol && it.market == st.market }
                                if (sopFor != null) {
                                    Text("★ ${if (st.symbol in state.watchlist) "已关注" else "关注"}", color = if (st.symbol in state.watchlist) Yellow else MutedC, fontSize = 10.sp,
                                        modifier = Modifier.clickable { vm.toggleWatch(st.symbol) }.padding(2.dp))
                                    when {
                                        samePos == null -> Text("+仓位", color = dirC, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                                            modifier = Modifier.clickable { vm.addPosition(sopFor.rep) }.padding(2.dp))
                                        samePos.direction == st.direction -> Text("+加仓(金字塔)", color = dirC, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                                            modifier = Modifier.clickable { vm.addPosition(sopFor.rep) }.padding(2.dp))
                                        else -> Text("⚠ 与持仓方向冲突", color = Yellow, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                    }
                    item {
                        Text("提示：价格到触发价后先进「等回踩确认」（避免接到插针最差价），回踩到触发价 ±0.5ATR 内且未破失效价才确认可入场；确认前若顺势走远 >1.2ATR 或超时则作废；触发后 2 根K线内出现反向形态自动取消（反悔）；同品种同方向 4 小时内只生成 1 次；确认过一次后保留一次回踩二次入场机会",
                            color = MutedC, fontSize = 9.5.sp, lineHeight = 13.sp, modifier = Modifier.padding(horizontal = 4.dp))
                    }
                }
            }
            "opps" -> {
                // ---------- 统计卡 ----------
                item {
                    // 同向潮（板块共振近似）：≥5 个做多机会同步走强 ≥2% 时提示
                    val longStrong = state.symbolOps.count { it.direction == "LONG" && (state.oppPrices[it.symbol]?.second ?: 0.0) >= 2.0 }
                    val shortStrong = state.symbolOps.count { it.direction == "SHORT" && (state.oppPrices[it.symbol]?.second ?: 0.0) <= -2.0 }
                    if (longStrong >= 5 || shortStrong >= 5) {
                        Text(
                            if (longStrong >= 5) "🌊 多头潮：$longStrong 个品种同步走强 ≥2%，板块级共振（此类信号历史胜率天然更高，但注意板块回撤风险同源）"
                            else "🌊 空头潮：$shortStrong 个品种同步走弱 ≥2%，板块级共振（同源风险，注意踩踏）",
                            color = if (longStrong >= 5) Green else Red, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.fillMaxWidth().background((if (longStrong >= 5) Green else Red).copy(alpha = 0.08f), RoundedCornerShape(8.dp)).padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                        Spacer(Modifier.height(6.dp))
                    }
                    // AI 全局研判（可选：配置 AI 后出现，辅助生成机会视角）
                    if (state.aiConfigured) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 6.dp)) {
                            Button(onClick = { vm.aiScanBrief() }, enabled = state.aiBusy == null,
                                colors = ButtonDefaults.buttonColors(containerColor = Panel2), modifier = Modifier.weight(1f)) {
                                Text(if (state.aiBusy == "brief") "AI 研判中…" else "🤖 AI 扫描研判（Top12 综合排序）", color = Yellow, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        state.aiBrief?.let { brief ->
                            Column(Modifier.fillMaxWidth().background(Yellow.copy(alpha = 0.06f), RoundedCornerShape(8.dp)).border(1.dp, BorderC, RoundedCornerShape(8.dp)).padding(horizontal = 10.dp, vertical = 6.dp)) {
                                Text("AI 全局研判（辅助参考，不替代算法）", color = Yellow, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Text(brief, color = TextC, fontSize = 10.5.sp, lineHeight = 14.sp)
                            }
                            Spacer(Modifier.height(6.dp))
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatCard("扫描品种", "${state.instruments}", Modifier.weight(1f), TextC)
                        StatCard("机会品种", "${state.symbolOps.size}", Modifier.weight(1f), Yellow)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 4.dp)) {
                        Text("同质化信号", color = MutedC, fontSize = 10.sp)
                        SegChip("宽松显示", !state.strictMerge, Yellow) { vm.setStrictMerge(false) }
                        SegChip("严格合并", state.strictMerge, Yellow) { vm.setStrictMerge(true) }
                        if (dedupeDroppedCount(state, dirFilter) > 0) {
                            Text("◈ 已合并 ${dedupeDroppedCount(state, dirFilter)} 个联动信号", color = MutedC, fontSize = 9.5.sp)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatCard("做多机会", "${state.symbolOps.count { it.direction == "LONG" }}", Modifier.weight(1f), Green)
                        StatCard("承压/做空", "${state.symbolOps.count { it.direction == "SHORT" }}", Modifier.weight(1f), Red)
                    }
                }
                // ---------- 工具栏：方向 + 周期 ----------
                item {
                    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).border(1.dp, BorderC, RoundedCornerShape(12.dp)).padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            SegChip("全部", dirFilter == "ALL") { dirFilter = "ALL" }
                            SegChip("做多", dirFilter == "LONG", Green) { dirFilter = "LONG" }
                            SegChip("做空/承压", dirFilter == "SHORT", Red) { dirFilter = "SHORT" }
                        }
                        Text("扫描周期（可多选，列表展示所有已扫描周期）", color = MutedC, fontSize = 10.sp)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            AnalysisEngine.supportedTimeframes.forEach { tf -> SegChip(tf, tf in state.scanTimeframes, Yellow) { vm.toggleScanTimeframe(tf) } }
                        }
                        OutlinedTextField(value = state.searchQuery, onValueChange = vm::setSearchQuery, modifier = Modifier.fillMaxWidth(), singleLine = true,
                            placeholder = { Text("搜索币种…", color = MutedC, fontSize = 11.5.sp) }, shape = RoundedCornerShape(8.dp),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextC, unfocusedTextColor = TextC, focusedContainerColor = Panel2, unfocusedContainerColor = Panel2, focusedBorderColor = BorderActive, unfocusedBorderColor = BorderC, cursorColor = Yellow))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("最低评分 ${state.minConfidence}", color = MutedC, fontSize = 11.sp)
                            Slider(value = state.minConfidence.toFloat(), onValueChange = { vm.setMinConfidence(it.toInt()) }, valueRange = 0f..100f, colors = SliderDefaults.colors(thumbColor = Yellow, activeTrackColor = Yellow), modifier = Modifier.weight(1f))
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = {
                                if (monitorRunning) vm.setBackgroundMonitor(false)
                                else if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                                else vm.setBackgroundMonitor(true)
                            }, shape = RoundedCornerShape(8.dp)) {
                                Text(if (monitorRunning) "后台预警：运行中 · 停止" else "后台预警：开启", fontSize = 11.sp, color = if (monitorRunning) Green else MutedC, fontWeight = FontWeight.SemiBold)
                            }
                            Text("显示 ${visibleOps(state, dirFilter).size} / ${state.symbolOps.size}", color = MutedC, fontSize = 10.sp, modifier = Modifier.weight(1f))
                        }
                    }
                }
                val ops = visibleOps(state, dirFilter)
                // 机会三态：触发（价格到入场区 或 确认走出）进主列表；观察（等回踩/反抽）折叠在观察区
                val triggered = ops.filter { sop ->
                    PhaseGate.evaluate(sop, state.oppPrices[sop.symbol]?.first, state.oppConfirm["${sop.market}|${sop.symbol}|${sop.direction}"]).phase == PhaseGate.TRIGGERED
                }
                val watching = ops.filterNot { triggered.contains(it) }
                if (ops.isEmpty()) {
                    item { EmptyBox(if (state.symbolOps.isEmpty()) "等待扫描结果\n点击「立即扫描」开始全市场扫描" else "当前筛选条件下没有机会") }
                } else {
                    if (triggered.isEmpty()) {
                        item {
                            Text("⚡ 暂无已触发机会——主列表只显示「价格已到入场区」或「确认已走出」的机会；下方 ${watching.size} 个观察中机会等价格到位后自动升级",
                                color = Yellow, fontSize = 10.5.sp, modifier = Modifier.fillMaxWidth().background(Yellow.copy(alpha = 0.06f), RoundedCornerShape(8.dp)).padding(horizontal = 10.dp, vertical = 6.dp))
                        }
                    }
                    items(triggered, key = { it.market + "-" + it.symbol }) { sop ->
                        val key = sop.market + sop.symbol
                        val live = state.oppPrices[sop.symbol]
                        SymbolOppRow(sop, live?.first, live?.second, expanded[key] == true,
                            showWatch = true, inWatchlist = sop.symbol in state.watchlist,
                            onClick = { expanded[key] = !(expanded[key] == true) },
                            onAddPosition = { vm.addPosition(sop.rep) },
                            onOpen = { vm.setSymbol(sop.symbol) },
                            onToggleWatch = { vm.toggleWatch(sop.symbol) },
                            tfWinRates = state.tfWinRates,
                            onSetRR = { vm.setRiskReward(sop.symbol, sop.market, it) },
                            onBinance = { openBinanceFutures(context, sop.symbol) }, miniCandles = vm.miniSeries(sop.symbol, sop.market), health = state.oppHealth[sop.symbol], confirm = state.oppConfirm["${sop.market}|${sop.symbol}|${sop.direction}"], position = state.positions.firstOrNull { it.symbol == sop.symbol && it.market == sop.market },
                            aiConfigured = state.aiConfigured, aiInsight = state.aiInsights["${sop.market}|${sop.symbol}"],
                            aiBusyNow = state.aiBusy == "${sop.market}|${sop.symbol}", onAi = { vm.aiExplain(sop) },
                            evidence = state.evidence["${sop.market}|${sop.symbol}"])
                    }
                    // ---------- 观察区：评分达标但价格未到入场区（中性等待态） ----------
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth().clickable { showWatching = !showWatching }.padding(horizontal = 4.dp, vertical = 4.dp)) {
                            Text(if (showWatching) "▾" else "▸", color = Yellow, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("🕐 观察中 ${watching.size} 个 · 等待价格触发（点击展开）", color = MutedC, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    if (showWatching) {
                        items(watching, key = { "w_" + it.market + "-" + it.symbol }) { sop ->
                            val ph = PhaseGate.evaluate(sop, state.oppPrices[sop.symbol]?.first, state.oppConfirm["${sop.market}|${sop.symbol}|${sop.direction}"])
                            Row(Modifier.fillMaxWidth().background(Panel2, RoundedCornerShape(10.dp)).border(1.dp, BorderC, RoundedCornerShape(10.dp)).padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(baseName(sop.symbol), color = MutedC, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                DirChip(sop.direction)
                                Text("🕐 观察中", color = MutedC, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.weight(1f))
                                Text("距触发 ${String.format(Locale.US, "%.2f", ph.distPct)}%", color = if (kotlin.math.abs(ph.distPct) <= 1.0) Yellow else MutedC, fontSize = 10.sp)
                                Text("★", color = if (sop.symbol in state.watchlist) Yellow else MutedC, fontSize = 15.sp, modifier = Modifier.clickable { vm.toggleWatch(sop.symbol) }.padding(horizontal = 2.dp))
                            }
                        }
                    }
                }
            }
            "rank" -> {
                state.winDetail?.let { (sym, rows) ->
                    item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("◀ 返回榜单", color = Yellow, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { vm.closeWinDetail() }.padding(4.dp))
                            Text("${baseName(sym)} 过往机会明细", color = TextC, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(4.dp))
                        val hits = rows.count { it.verdict == "hit" }
                        val sd = rows.filter { it.verdict == "hit" || it.verdict == "miss" }
                        Text("已结算 ${sd.size} · 命中 $hits · 落空 ${sd.size - hits} · 跟踪中 ${rows.count { it.verdict == "open" }}",
                            color = MutedC, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 4.dp))
                        Spacer(Modifier.height(4.dp))
                    }
                    if (rows.isEmpty()) item { EmptyBox("该品种暂无历史机会记录") }
                    else items(rows, key = { "wd_" + it.id }) { r -> HistoryRow(r) }
                }
                if (state.winDetail == null) {
                    item {
                        Text("品种机会胜率排行 · 来自训练闭环自动结算（≥2 个已结算样本入榜），点击卡片查看该品种每笔机会的命中/失败明细", color = MutedC, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 4.dp))
                    }
                    if (state.winRank.isEmpty()) {
                        item { EmptyBox("样本积累中\nA/B 级机会自动记账，结算后此处出榜") }
                    } else {
                        val shown = state.winRank.take(state.winRankPage * 20)
                        items(shown, key = { it.symbol }) { st ->
                            val rc = when {
                                st.rate >= 60 -> Green
                                st.rate >= 45 -> Yellow
                                else -> Red
                            }
                            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).border(1.dp, BorderC, RoundedCornerShape(12.dp)).clickable { vm.openWinDetail(st.symbol) }.padding(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(baseName(st.symbol), color = TextC, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    Text("USDT", color = MutedC, fontSize = 8.5.sp)
                                    DirChip(st.bestDir)
                                    Text("最优方向 ${String.format(Locale.US, "%.0f%%", st.bestDirRate)}", color = rc, fontSize = 10.sp)
                                    Spacer(Modifier.weight(1f))
                                    Text(String.format(Locale.US, "%.0f%%", st.rate), color = rc, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(Modifier.height(6.dp))
                                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    PlanCell("已结算", "${st.total}")
                                    PlanCell("命中", "${st.hits}", Green)
                                    PlanCell("落空", "${st.misses}", Red)
                                    PlanCell("跟踪中", "${st.openCount}")
                                    PlanCell("点击查看", "过往明细 →", Yellow)
                                }
                                Spacer(Modifier.height(6.dp))
                                Box(Modifier.fillMaxWidth().height(4.dp).background(BorderC, RoundedCornerShape(2.dp))) {
                                    Box(Modifier.fillMaxWidth(st.rate.toFloat() / 100f).height(4.dp).background(rc, RoundedCornerShape(2.dp)))
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                        if (state.winRank.size > shown.size) {
                            item {
                                Button(onClick = { vm.loadMoreWinRank() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Panel2)) {
                                    Text("加载更多（共 ${state.winRank.size} 个品种）", color = Yellow, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
            "conf" -> {
                // ---- 确认观察中（实时进度）：还没判定的机会显示确认进度条 ----
                item {
                    val pending = state.oppConfirm.values.filter { !it.resolved }.sortedByDescending { it.progressAtr }
                    if (pending.isNotEmpty()) {
                        Text("确认观察中 ${pending.size} 个（实时进度）", color = Yellow, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp))
                        Spacer(Modifier.height(4.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            pending.take(10).forEach { c ->
                                val need = c.thresholdAtr.coerceAtLeast(0.1)
                                val prog = (c.progressAtr / need).toFloat().coerceIn(0f, 1f)
                                Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(10.dp)).border(1.dp, BorderC, RoundedCornerShape(10.dp)).padding(10.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text(baseName(c.symbol), color = TextC, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        DirChip(c.direction)
                                        Text(ConfirmationGate.badge(c), color = Yellow, fontSize = 9.5.sp)
                                        Spacer(Modifier.weight(1f))
                                        Text("${c.repTimeframe}", color = MutedC, fontSize = 9.5.sp)
                                    }
                                    Spacer(Modifier.height(5.dp))
                                    Box(Modifier.fillMaxWidth().height(4.dp).background(BorderC, RoundedCornerShape(2.dp))) {
                                        Box(Modifier.fillMaxWidth(prog).height(4.dp).background(Yellow, RoundedCornerShape(2.dp)))
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                    }
                }
                // ---- 当前已确认机会排行（实时） ----
                item {
                    Text("当前已确认机会排行（实时）", color = Yellow, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp))
                    Spacer(Modifier.height(4.dp))
                }
                item {
                    val held = state.positions.map { it.symbol }.toSet()
                    val cur = state.symbolOps.filter { !held.contains(it.symbol) }.mapNotNull { sop ->
                        val c = state.oppConfirm["${sop.market}|${sop.symbol}|${sop.direction}"] ?: return@mapNotNull null
                        if (c.status != "已确认" && c.status != "回踩确认") return@mapNotNull null
                        Triple(sop, c, c.progressAtr * 100 + sop.score)
                    }.sortedByDescending { it.third }
                    if (cur.isEmpty()) {
                        Text("暂无已确认机会——A/B 级机会进入观察窗口后（如 15m 需 4 根K线内顺势走出 0.5×ATR），确认完成即出现在此处。上方「确认观察中」可看到实时进度", color = MutedC, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp))
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            cur.forEach { (sop, c, _) ->
                                Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(10.dp)).border(1.dp, BorderC, RoundedCornerShape(10.dp)).padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(baseName(sop.symbol), color = TextC, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    DirChip(sop.direction)
                                    Text(if (c.status == "回踩确认") "🔁回踩确认" else "✅已确认", color = Green, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    Text("+${String.format(Locale.US, "%.1f", c.progressAtr)}×ATR", color = Green, fontSize = 10.sp)
                                    Spacer(Modifier.weight(1f))
                                    Text("分 ${sop.score} · ${sop.grade}级", color = Yellow, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("—— 品种历史确认率 ——", color = Yellow, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp))
                    Spacer(Modifier.height(4.dp))
                    Text("各品种的信号「确认成功率」（数据来自自动记账的确认状态）", color = MutedC, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 4.dp))
                    Spacer(Modifier.height(4.dp))
                }
                if (state.confirmRank.isEmpty()) {
                    item { EmptyBox("样本积累中\nA/B 级机会自动进入确认观察，判定后此处出榜") }
                } else {
                    items(state.confirmRank.take(30), key = { "cf_" + it.symbol }) { st ->
                        val rc = when {
                            st.rate >= 60 -> Green
                            st.rate >= 40 -> Yellow
                            else -> Red
                        }
                        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).border(1.dp, BorderC, RoundedCornerShape(12.dp)).padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(baseName(st.symbol), color = TextC, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text("USDT", color = MutedC, fontSize = 8.5.sp)
                                Spacer(Modifier.weight(1f))
                                Text("确认率 ${String.format(Locale.US, "%.0f%%", st.rate)}", color = rc, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.height(6.dp))
                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                PlanCell("已确认", "${st.confirmed}", Green)
                                PlanCell("回踩确认", "${st.retest}", Green)
                                PlanCell("未确认", "${st.unconfirmed}", Red)
                                PlanCell("记录总数", "${st.total}")
                            }
                            Spacer(Modifier.height(6.dp))
                            Box(Modifier.fillMaxWidth().height(4.dp).background(BorderC, RoundedCornerShape(2.dp))) {
                                Box(Modifier.fillMaxWidth(st.rate.toFloat() / 100f).height(4.dp).background(rc, RoundedCornerShape(2.dp)))
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                    item {
                        Text("解读：确认率高 = 该品种信号发出后行情真实走出的比例高，其新信号更值得关注；确认率低的品种信号多为假启动，谨慎对待",
                            color = MutedC, fontSize = 9.5.sp, modifier = Modifier.padding(horizontal = 4.dp))
                    }
                }
            }
            "pos" -> {
                item {
                    Text("本地持仓跟踪 · 记录只保存在本机，可从机会卡片加入", color = MutedC, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 4.dp))
                    if (state.autoBattle) {
                        Text("🤖 自动作战 ${if (state.trailingEnabled) "· 移动止盈（回撤 ${com.klinealert.nativeapp.domain.BattleLoopEngine.DEFAULT_TRAIL_ATR}×ATR 锁盈）" else "· 固定止盈（止损${com.klinealert.nativeapp.domain.BattleLoopEngine.DEFAULT_STOP_MULT.toInt()}×ATR / 止盈${com.klinealert.nativeapp.domain.BattleLoopEngine.DEFAULT_TARGET_MULT.toInt()}×ATR）"} · 入 ${state.battleEntered} 平 ${state.battleClosed} 盈亏 ${String.format(Locale.US, "%+.2f", state.battlePnlSum)}U（本金${com.klinealert.nativeapp.domain.BattleLoopEngine.DEFAULT_MARGIN_USDT.toInt()}×${com.klinealert.nativeapp.domain.BattleLoopEngine.DEFAULT_LEVERAGE.toInt()}x）", color = Yellow, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                    }
                }
                if (state.positions.isEmpty()) {
                    item { EmptyBox("还没有持仓记录\n在「机会榜」卡片底部点击「加入持仓跟踪」") }
                } else {
                    val live = state.positionPrices
                    val sorted = state.positions.sortedBy { p ->
                        val lp = live[p.symbol]
                        val rep = state.symbolOps.firstOrNull { it.symbol == p.symbol && it.market == p.market }?.rep
                        if (lp != null && rep != null) com.klinealert.nativeapp.domain.LifecycleEngine.urgency(
                            com.klinealert.nativeapp.domain.LifecycleEngine.evaluate(p.direction, p.entry, p.stop, p.target, lp, rep, isPosition = true)
                        ) else 4
                    }
                    items(sorted, key = { it.id }) { p ->
                        val rep = state.symbolOps.firstOrNull { it.symbol == p.symbol && it.market == p.market }?.rep
                        PosCard(p, state.positionPrices[p.symbol], rep, onDelete = { vm.removePosition(p.id) }, onEdit = { editingPos = p })
                    }
                }
            }
            else -> {
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatCard("跟踪中", "${state.history.count { it.verdict == "open" }}", Modifier.weight(1f), TextC)
                        StatCard("命中", "${state.history.count { it.verdict == "hit" }}", Modifier.weight(1f), Green)
                        StatCard("落空", "${state.history.count { it.verdict == "miss" }}", Modifier.weight(1f), Red)
                        StatCard("平局", "${state.history.count { it.verdict == "neutral" }}", Modifier.weight(1f), Yellow)
                    }
                }
                if (state.history.isEmpty()) {
                    item { EmptyBox("暂无历史提醒\n信号方向变化时会自动记录并回看命中/落空") }
                } else {
                    items(state.history, key = { it.id }) { r -> HistoryRow(r) }
                }
            }
        }
        item {
            Text("公开行情 · 仅供信息参考，不构成投资建议", color = MutedC, fontSize = 9.5.sp, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        }
    }
    editingPos?.let { ep ->
        EditPositionDialog(ep, onSave = { vm.updatePosition(it); editingPos = null }, onDismiss = { editingPos = null })
    }
}

@Composable
private fun EditPositionDialog(p: com.klinealert.nativeapp.data.LocalStore.LocalPosition, onSave: (com.klinealert.nativeapp.data.LocalStore.LocalPosition) -> Unit, onDismiss: () -> Unit) {
    var stop by remember { mutableStateOf(p.stop.toString()) }
    var target by remember { mutableStateOf(p.target.toString()) }
    var size by remember { mutableStateOf(p.size.toString()) }
    var leverage by remember { mutableStateOf(p.leverage.toString()) }
    var note by remember { mutableStateOf(p.note) }
    val fieldColors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextC, unfocusedTextColor = TextC, focusedContainerColor = Panel2, unfocusedContainerColor = Panel2, focusedBorderColor = BorderActive, unfocusedBorderColor = BorderC, cursorColor = Yellow)
    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).border(1.dp, BorderC, RoundedCornerShape(14.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("编辑持仓 · ${baseName(p.symbol)} ${if (p.direction == "LONG") "多单" else "空单"}", color = Yellow, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = stop, onValueChange = { stop = it }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("止损", color = MutedC, fontSize = 10.sp) }, shape = RoundedCornerShape(8.dp), colors = fieldColors)
                OutlinedTextField(value = target, onValueChange = { target = it }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("止盈", color = MutedC, fontSize = 10.sp) }, shape = RoundedCornerShape(8.dp), colors = fieldColors)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = size, onValueChange = { size = it }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("数量", color = MutedC, fontSize = 10.sp) }, shape = RoundedCornerShape(8.dp), colors = fieldColors)
                OutlinedTextField(value = leverage, onValueChange = { leverage = it.filter { ch -> ch.isDigit() } }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("仓位倍数(1-200)", color = MutedC, fontSize = 10.sp) }, shape = RoundedCornerShape(8.dp), colors = fieldColors)
            }
            OutlinedTextField(value = note, onValueChange = { note = it }, modifier = Modifier.fillMaxWidth(), label = { Text("备注", color = MutedC, fontSize = 10.sp) }, shape = RoundedCornerShape(8.dp), colors = fieldColors)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                Text("取消", color = MutedC, fontSize = 12.sp, modifier = Modifier.clickable(onClick = onDismiss).padding(8.dp))
                Button(onClick = {
                    onSave(p.copy(
                        stop = stop.toDoubleOrNull() ?: p.stop,
                        target = target.toDoubleOrNull() ?: p.target,
                        size = size.toDoubleOrNull() ?: p.size,
                        leverage = (leverage.toIntOrNull() ?: p.leverage.toInt()).coerceIn(1, 200).toDouble(),
                        note = note
                    ))
                }, colors = ButtonDefaults.buttonColors(containerColor = Yellow)) {
                    Text("保存", color = Color(0xFF0B0E14), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

private fun visibleOps(state: com.klinealert.nativeapp.ui.MarketUiState, dirFilter: String): List<SymbolOpportunity> {
    val filtered = state.symbolOps.filter { sop ->
        (dirFilter == "ALL" || sop.direction == dirFilter) &&
            sop.score >= state.minConfidence &&
            (state.searchQuery.isBlank() || sop.symbol.contains(state.searchQuery.trim(), ignoreCase = true)) &&
            // v3.7 证据门槛：四维证据分 <50 的机会剔除（证据明细见卡片）
            (state.evidence["${sop.market}|${sop.symbol}"]?.score ?: 100) >= 50
    }
    // 同质化信号：默认宽松显示全部；开启「严格合并」后同方向+同阶段只保留最强（BTC/ETH 始终保留）
    if (!state.strictMerge) return filtered
    val majors = setOf("BTCUSDT", "ETHUSDT")
    val kept = mutableListOf<SymbolOpportunity>()
    for (sop in filtered.sortedByDescending { it.score }) {
        if (sop.symbol in majors || kept.none { it.direction == sop.direction && it.rep.regime == sop.rep.regime }) kept += sop
    }
    return kept
}

private fun dedupeDroppedCount(state: com.klinealert.nativeapp.ui.MarketUiState, dirFilter: String): Int {
    if (!state.strictMerge) return 0
    val filtered = state.symbolOps.filter { sop ->
        (dirFilter == "ALL" || sop.direction == dirFilter) &&
            sop.score >= state.minConfidence &&
            (state.searchQuery.isBlank() || sop.symbol.contains(state.searchQuery.trim(), ignoreCase = true))
    }
    val majors = setOf("BTCUSDT", "ETHUSDT")
    val kept = mutableListOf<SymbolOpportunity>()
    var dropped = 0
    for (sop in filtered.sortedByDescending { it.score }) {
        if (sop.symbol in majors || kept.none { it.direction == sop.direction && it.rep.regime == sop.rep.regime }) kept += sop else dropped++
    }
    return dropped
}

/* ---------------- 时间辅助 ---------------- */
private fun timeAgoText(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return when {
        s < 60 -> "${s} 秒前"
        s < 3600 -> "${s / 60} 分钟前"
        s < 86400 -> "${s / 3600} 小时前"
        else -> "${s / 86400} 天前"
    }
}

private fun remainText(ms: Long): String {
    val m = ms / 60000
    return when {
        m <= 0 -> "已到期"
        m < 60 -> "${m}m"
        else -> "${m / 60}h${m % 60}m"
    }
}

/* ---------------- 网页版同款组件 ---------------- */

@Composable
private fun Badge(text: String, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier
            .background(Panel2, RoundedCornerShape(20.dp))
            .border(1.dp, color.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
            .padding(horizontal = 9.dp, vertical = 3.dp)
    ) { Text(text, color = color, fontSize = 10.sp, maxLines = 1) }
}

@Composable
private fun SegButton(label: String, active: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.background(if (active) Panel2 else Panel, RoundedCornerShape(9.dp))
            .border(1.dp, if (active) BorderActive else BorderC, RoundedCornerShape(9.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) { Text(label, color = if (active) TextC else MutedC, fontSize = 11.5.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal) }
}

@Composable
private fun SegChip(label: String, active: Boolean, activeColor: Color = TextC, onClick: () -> Unit) {
    Box(
        Modifier.background(if (active) Panel2 else Color.Transparent, RoundedCornerShape(7.dp))
            .border(1.dp, if (active) BorderActive else BorderC, RoundedCornerShape(7.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 11.dp, vertical = 5.dp)
    ) { Text(label, color = if (active) activeColor else MutedC, fontSize = 11.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal) }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier, valueColor: Color) {
    Column(modifier.background(Panel, RoundedCornerShape(12.dp)).border(1.dp, BorderC, RoundedCornerShape(12.dp)).padding(10.dp)) {
        Text(label, color = MutedC, fontSize = 10.sp)
        Text(value, color = valueColor, fontSize = 19.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun TradeLinkCard(link: com.klinealert.nativeapp.domain.TradeModels.TradeLink, live: Boolean) {
    val dirColor = if (link.direction == "LONG") Green else Red
    val yld = com.klinealert.nativeapp.domain.TradeModels.yieldPct(
        if (live) link.unrealizedPnl else link.realizedPnlNet, link.marginUsdt
    )
    val pnl = if (live) link.unrealizedPnl else link.realizedPnlNet
    Column(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).border(1.dp, BorderC, RoundedCornerShape(12.dp)).padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(baseName(link.symbol), color = TextC, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(if (link.direction == "LONG") "多" else "空", color = dirColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(link.status, color = MutedC, fontSize = 10.sp)
            Spacer(Modifier.weight(1f))
            Text("${String.format(Locale.US, "%+.2f", pnl)}U", color = if (pnl >= 0) Green else Red, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(4.dp))
        Text(
            "本金 ${link.marginUsdt}U · ${link.leverage.toInt()}x · 数量 ${String.format(Locale.US, "%.4f", link.qty)}",
            color = MutedC, fontSize = 10.sp
        )
        Text(
            "开仓均价 ${fmt(link.avgEntry)}" + if (!live && link.avgExit > 0) " → 平仓 ${fmt(link.avgExit)}" else if (link.markPrice > 0) " · 标记 ${fmt(link.markPrice)}" else "",
            color = MutedC, fontSize = 10.sp
        )
        Text(
            "收益率 ${String.format(Locale.US, "%+.1f", yld)}% · 开仓费 ${String.format(Locale.US, "%.4f", link.commissionOpen)}" +
                if (!live) " · 平仓费 ${String.format(Locale.US, "%.4f", link.commissionClose)}" else "",
            color = MutedC, fontSize = 10.sp
        )
        Text(
            "止损 ${fmt(link.stopPrice)} · 止盈 ${fmt(link.targetPrice)}" +
                if (link.stopOrderId > 0 || link.tpOrderId > 0) " · 条件单已挂" else "",
            color = TextC, fontSize = 10.sp
        )
        if (link.lastError.isNotBlank()) Text(link.lastError, color = Red, fontSize = 9.5.sp)
        if (!live && link.closeReason.isNotBlank()) {
            Text("原因 ${link.closeReason} · ${java.text.SimpleDateFormat("MM-dd HH:mm", Locale.US).format(java.util.Date(link.closedAt))}", color = MutedC, fontSize = 9.5.sp)
        }
    }
    Spacer(Modifier.height(6.dp))
}

@Composable
private fun EmptyBox(text: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        text.split("\n").forEach {
            Text(it, color = MutedC, fontSize = 11.5.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        }
    }
}

@Composable
private fun SymbolOppRow(sop: SymbolOpportunity, livePrice: Double?, liveChangePct: Double?, expanded: Boolean, showWatch: Boolean = true, inWatchlist: Boolean = false, onClick: () -> Unit, onAddPosition: () -> Unit, onOpen: () -> Unit, onToggleWatch: () -> Unit, tfWinRates: Map<String, Pair<Int, Double>> = emptyMap(), onSetRR: (Double) -> Unit = {}, onBinance: () -> Unit = {}, miniCandles: List<Candle> = emptyList(), health: com.klinealert.nativeapp.domain.SignalHealth? = null, confirm: com.klinealert.nativeapp.domain.Confirmation? = null, position: com.klinealert.nativeapp.data.LocalStore.LocalPosition? = null, aiConfigured: Boolean = false, aiInsight: String? = null, aiBusyNow: Boolean = false, onAi: () -> Unit = {}, evidence: EvidenceEngine.Evidence? = null) {
    val dirColor = if (sop.direction == "LONG") Green else Red
    val clipboard = LocalClipboardManager.current
    val a = sop.rep
    val shownPrice = livePrice ?: sop.price
    val keyLevel = if (sop.direction == "LONG") a.resistance else a.support
    val keyLabel = if (sop.direction == "LONG") (a.resistanceLabel.ifBlank { "承压" }) else (a.supportLabel.ifBlank { "支撑" })
    val liveDist = if (livePrice != null && keyLevel != null && livePrice > 0) (keyLevel - livePrice) / livePrice * 100 else null
    Column(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).border(1.dp, BorderC, RoundedCornerShape(12.dp)).clickable(onClick = onClick)
    ) {
        Row(Modifier.fillMaxWidth().height(44.dp)) {
            Box(Modifier.width(3.dp).fillMaxSize().background(dirColor))
            Column(Modifier.weight(1f).padding(horizontal = 10.dp, vertical = 8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(baseName(sop.symbol), color = TextC, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("USDT", color = MutedC, fontSize = 8.5.sp)
                    DirChip(sop.direction)
                    if (sop.grade.isNotEmpty()) ResChip("${sop.grade} 级", if (sop.grade == "A") Yellow else if (sop.grade == "B") Color(0xFF4A7DFF) else MutedC)
                    if (sop.resonanceCount >= 1) ResChip("共振${sop.resonanceCount + 1}周期", Yellow)
                    if (sop.oppositeCount >= 1) ResChip("反向${sop.oppositeCount}周期", Red)
                    evidence?.let { ev ->
                        ResChip("证据${ev.score}", if (ev.score >= 70) Yellow else if (ev.score >= 50) Color(0xFF4A7DFF) else Red)
                        if (ev.veto) ResChip("量价否决", Red)
                    }
                    Spacer(Modifier.weight(1f))
                    if (showWatch) {
                        Text(if (inWatchlist) "★" else "☆", color = if (inWatchlist) Yellow else MutedC, fontSize = 16.sp,
                            modifier = Modifier.clickable(onClick = onToggleWatch).padding(horizontal = 4.dp))
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 2.dp)) {
                    sop.perTimeframe.values.sortedBy { AnalysisEngine.supportedTimeframes.indexOf(it.timeframe) }.forEach { tf ->
                        val c = if (tf.direction == "LONG") Green else Red
                        val wr = tfWinRates["${tf.timeframe}|${tf.direction}"]
                        val wrLabel = wr?.takeIf { it.first >= 8 }?.let { " · 胜${String.format(Locale.US, "%.0f", it.second * 100)}%" } ?: ""
                        Box(Modifier.background(Panel2, RoundedCornerShape(5.dp)).border(1.dp, c.copy(alpha = 0.35f), RoundedCornerShape(5.dp)).padding(horizontal = 5.dp, vertical = 1.dp)) {
                            Text("${tf.timeframe} ${tf.score}$wrLabel", color = c, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    Text("${sop.score}", color = scoreColor(sop.score), fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
                    Box(Modifier.width(56.dp).height(5.dp).background(Panel2, RoundedCornerShape(4.dp))) {
                        Box(Modifier.fillMaxWidth(sop.score.coerceIn(0, 100) / 100f).height(5.dp).background(scoreColor(sop.score), RoundedCornerShape(4.dp)))
                    }
                }
            }
        }
        // 实时价格 + 实时关键位距离
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(start = 12.dp, end = 10.dp)) {
            Text("现价 ", color = MutedC, fontSize = 10.sp)
            Text(fmt(shownPrice), color = Yellow, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            liveChangePct?.let {
                Text("${if (it >= 0) "+" else ""}${String.format(Locale.US, "%.2f", it)}%", color = if (it >= 0) Green else Red, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            liveDist?.let {
                val near = abs(it) <= 0.5
                Text("距$keyLabel ${if (it >= 0) "+" else ""}${String.format(Locale.US, "%.2f", it)}%",
                    color = if (near) Yellow else MutedC, fontSize = 10.sp, fontWeight = if (near) FontWeight.Bold else FontWeight.Normal)
            }
            PhaseChip(a.regime, a.regimeConfidence)
        }
        // 机会确认状态：确认观察 → 已确认/回踩确认/延候/未确认
        confirm?.let { c ->
            val cc = when {
                c.status == "已确认" || c.status == "回踩确认" -> Green
                c.status == "未确认" -> Red
                else -> Yellow
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(start = 12.dp, end = 10.dp, top = 2.dp)) {
                Text(com.klinealert.nativeapp.domain.ConfirmationGate.badge(c), color = cc, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                if (c.status == "待确认" || c.status == "延候确认") {
                    Text("· 反向最大 ${String.format(java.util.Locale.US, "%.1f", c.reverseMaxAtr)}×ATR", color = MutedC, fontSize = 9.sp, maxLines = 1)
                }
            }
        }
        // 实时信号健康度：tick 级迟滞状态机（MFE/MAE + 3tick 去抖），不翻转信号
        run {
            val health = health ?: run {
                val stale = System.currentTimeMillis() - sop.rep.candleTime
                com.klinealert.nativeapp.domain.SignalHealthMonitor.evaluate(sop, livePrice, if (stale > 0) stale else -1L)
            }
            val hc = when (health.color) {
                "GOOD" -> Green; "WARN" -> Yellow; else -> MutedC
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(start = 12.dp, end = 10.dp, top = 2.dp)) {
                Text("◉", color = hc, fontSize = 10.sp)
                Text("实时健康：${health.status}", color = hc, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(health.detail, color = MutedC, fontSize = 9.5.sp, maxLines = 1)
            }
        }
        Text(
            a.reason, color = if (sop.direction == "LONG") Color(0xFFC9F7E4) else Color(0xFFFFD7DC),
            fontSize = 11.sp, fontWeight = FontWeight.SemiBold, lineHeight = 15.sp,
            modifier = Modifier.padding(start = 12.dp, end = 10.dp, top = 6.dp, bottom = 8.dp)
        )
        // v3.7 四维证据明细：告诉用户这个机会缺什么/强在哪
        evidence?.let { ev ->
            Column(Modifier.fillMaxWidth().padding(start = 12.dp, end = 10.dp, bottom = 4.dp)) {
                ev.detail.forEach { line ->
                    Text("◇ $line", color = MutedC, fontSize = 9.5.sp, lineHeight = 13.sp)
                }
            }
        }
        if (expanded) {
            Column(Modifier.fillMaxWidth().padding(start = 12.dp, end = 10.dp, bottom = 10.dp)) {
                Box(Modifier.fillMaxWidth().height(1.dp).background(BorderC)); Spacer(Modifier.height(8.dp))
                Text("代表信号：${a.timeframe} 周期", color = MutedC, fontSize = 10.sp)
                Spacer(Modifier.height(4.dp))
                // AI 解读（可选）：把算法数据包交给大模型做因果解读
                if (aiConfigured) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(if (aiBusyNow) "AI 解读中…" else "🤖 AI 解读此机会", color = Yellow, fontSize = 10.5.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable(enabled = !aiBusyNow, onClick = onAi).padding(vertical = 4.dp))
                    }
                    aiInsight?.let { ins ->
                        Text(ins, color = TextC, fontSize = 10.sp, lineHeight = 13.sp,
                            modifier = Modifier.fillMaxWidth().background(Panel2, RoundedCornerShape(8.dp)).padding(8.dp))
                        Spacer(Modifier.height(4.dp))
                    }
                }
                if (sop.plan.isNotEmpty()) {
                    Column(Modifier.fillMaxWidth().background(Panel2, RoundedCornerShape(8.dp)).padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("标准交易计划（${sop.grade} 级）", color = Yellow, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        sop.plan.forEach { line ->
                            Text(line, color = TextC, fontSize = 10.sp, lineHeight = 13.sp,
                                fontWeight = if (line.startsWith("失效条件")) FontWeight.SemiBold else FontWeight.Normal)
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                }
                if (a.states.isNotEmpty()) {
                    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("指标状态（延续范围）", color = MutedC, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        a.states.forEach { st ->
                            val stColor = when {
                                st.state.contains("多头") || st.state.contains("上方") || st.state.contains("强趋势") || st.state.contains("延续") -> Green
                                st.state.contains("空头") || st.state.contains("下方") || st.state.contains("背离") || st.state.contains("超买") -> Red
                                else -> MutedC
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("•", color = stColor, fontSize = 10.sp)
                                Text("${st.name}：${st.detail}", color = if (stColor == MutedC) MutedC else stColor, fontSize = 10.sp, lineHeight = 13.sp)
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                }
                Spacer(Modifier.height(8.dp))
                // 生命线：确认后机会/持仓的五段式阶段 + 回踩反转判别 + 关键位推演
                val lcEntry = position?.entry ?: sop.price
                val lc = if ((confirm != null && confirm.resolved) || position != null) {
                    com.klinealert.nativeapp.domain.LifecycleEngine.evaluate(
                        sop.direction, lcEntry, position?.stop ?: sop.rep.stop, position?.target ?: sop.rep.target,
                        shownPrice, a, confirm, isPosition = position != null)
                } else null
                lc?.let { lc2 ->
                    Column(Modifier.fillMaxWidth().background(Panel2, RoundedCornerShape(8.dp)).padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        val lcColor = when (lc2.phaseColor) { "GOOD" -> Green; "WARN" -> Yellow; else -> Red }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("生命线：${lc2.phase}", color = lcColor, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            lc2.verdict?.let { v -> Text("${v.dot} ${v.status} ${v.confidence}%", color = lcColor, fontSize = 9.5.sp, fontWeight = FontWeight.SemiBold) }
                        }
                        lc2.lines.forEach { Text(it, color = MutedC, fontSize = 9.5.sp, lineHeight = 12.sp) }
                        lc2.verdict?.evidence?.take(3)?.forEach { Text("· $it", color = MutedC, fontSize = 9.sp, maxLines = 1) }
                    }
                    Spacer(Modifier.height(6.dp))
                }
                // 迷你K线：最近 60 根收盘价 + 止损/止盈虚线参考
                if (miniCandles.size >= 10) {
                    Text("迷你K线（60根）", color = MutedC, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Canvas(Modifier.fillMaxWidth().height(80.dp).background(Panel2, RoundedCornerShape(8.dp))) {
                        val closes = miniCandles.map { it.close }
                        val levels = listOfNotNull(a.stop.takeIf { it > 0.0 }, a.target.takeIf { it > 0.0 })
                        val lo = (closes + levels).min()
                        val hi = (closes + levels).max()
                        val span = (hi - lo).takeIf { it > 0.0 } ?: 1.0
                        fun y(v: Double) = (size.height * (1f - ((v - lo) / span).toFloat())).coerceIn(0f, size.height)
                        fun x(i: Int) = size.width * i / (closes.size - 1).coerceAtLeast(1)
                        val line = Path()
                        closes.forEachIndexed { i, c -> if (i == 0) line.moveTo(x(0), y(c)) else line.lineTo(x(i), y(c)) }
                        drawPath(line, color = dirColor, style = Stroke(width = 4f))
                        fun hline(v: Double, color: Color) {
                            if (v <= 0.0) return
                            drawLine(color, Offset(0f, y(v)), Offset(size.width, y(v)),
                                strokeWidth = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f)))
                        }
                        hline(a.stop, Red)
                        hline(a.target, Green)
                    }
                    Spacer(Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("— 价格", color = dirColor, fontSize = 9.5.sp)
                        Text("- - 止损", color = Red, fontSize = 9.5.sp)
                        Text("- - 止盈", color = Green, fontSize = 9.5.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                }
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    PlanCell("参考进场", fmt(a.price))
                    PlanCell("止损", fmt(a.stop), Red)
                    PlanCell("止盈", fmt(a.target), Green)
                    PlanCell("盈亏比", String.format(Locale.US, "%.2f", a.riskReward))
                    PlanCell("ATR波动", String.format(Locale.US, "%.2f", a.atrPct) + "%")
                    a.rsi14?.let { PlanCell("RSI", String.format(Locale.US, "%.1f", it)) }
                }
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("盈亏比", color = MutedC, fontSize = 10.sp)
                    listOf(1.0, 1.5, 2.0, 2.5, 3.0).forEach { rr ->
                        val selected = abs(a.riskReward - rr) < 0.01
                        Box(Modifier.background(if (selected) Yellow.copy(alpha = 0.15f) else Panel2, RoundedCornerShape(6.dp)).border(1.dp, if (selected) Yellow else BorderC, RoundedCornerShape(6.dp)).clickable { onSetRR(rr) }.padding(horizontal = 8.dp, vertical = 3.dp)) {
                            Text(String.format(Locale.US, "%.1f", rr), color = if (selected) Yellow else MutedC, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    a.swingHigh?.let { LevelChip("周期高点", it, Red) }
                    a.swingLow?.let { LevelChip("周期低点", it, Green) }
                    a.support?.let { LevelChip("最近支撑" + (if (a.supportLabel.isBlank()) "" else "·${a.supportLabel}"), it, Green) }
                    a.resistance?.let { LevelChip("最近承压" + (if (a.resistanceLabel.isBlank()) "" else "·${a.resistanceLabel}"), it, Red) }
                }
                Spacer(Modifier.height(8.dp))
                Text("各周期信号明细", color = MutedC, fontSize = 10.sp)
                Spacer(Modifier.height(4.dp))
                sop.perTimeframe.values.sortedBy { AnalysisEngine.supportedTimeframes.indexOf(it.timeframe) }.forEach { tf ->
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(vertical = 2.dp)) {
                        TfChip(tf.timeframe)
                        DirChip(tf.direction)
                        Text("评分 ${tf.score}", color = scoreColor(tf.score), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        PhaseChip(tf.regime, tf.regimeConfidence)
                        Text("RSI ${tf.rsi14?.let { String.format(Locale.US, "%.1f", it) } ?: "—"}", color = MutedC, fontSize = 10.sp)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onAddPosition, shape = RoundedCornerShape(8.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 2.dp)) {
                        Text("加入持仓跟踪", fontSize = 11.sp, color = Yellow)
                    }
                    OutlinedButton(onClick = onOpen, shape = RoundedCornerShape(8.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 2.dp)) {
                        Text("查看实时", fontSize = 11.sp, color = MutedC)
                    }
                    OutlinedButton(onClick = onBinance, shape = RoundedCornerShape(8.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 2.dp)) {
                        Text("币安合约", fontSize = 11.sp, color = Color(0xFFF0B90B))
                    }
                    OutlinedButton(onClick = {
                        clipboard.setText(AnnotatedString("${baseName(sop.symbol)} ${sop.grade}级 ${if (sop.direction == "LONG") "做多" else "做空"}\n" + sop.plan.joinToString("\n")))
                    }, shape = RoundedCornerShape(8.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 2.dp)) {
                        Text("复制计划", fontSize = 11.sp, color = MutedC)
                    }
                }
            }
        }
    }
}

/** 币安合约直跳：优先拉起币安 App（App Links），未安装则浏览器打开。 */
private fun openBinanceFutures(context: android.content.Context, symbol: String) {
    val url = "https://www.binance.com/zh-CN/futures/${symbol.uppercase()}"
    val appIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.binance.dev")
    val launched = runCatching { context.startActivity(appIntent) }.isSuccess
    if (!launched) runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
}

@Composable
private fun ResChip(text: String, color: Color) {
    Box(Modifier.background(color.copy(alpha = 0.12f), RoundedCornerShape(6.dp)).border(1.dp, color.copy(alpha = 0.4f), RoundedCornerShape(6.dp)).padding(horizontal = 6.dp, vertical = 1.dp)) {
        Text(text, color = color, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun DiagLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp)) {
        Text(label + " ：", color = MutedC, fontSize = 11.sp)
        Text(value, color = TextC, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}
@Composable
private fun TfChip(tf: String) {
    Box(Modifier.background(Panel2, RoundedCornerShape(5.dp)).border(1.dp, BorderC, RoundedCornerShape(5.dp)).padding(horizontal = 6.dp, vertical = 1.dp)) {
        Text(tf, color = Blue, fontSize = 9.5.sp)
    }
}

@Composable
private fun DirChip(direction: String) {
    val c = if (direction == "LONG") Green else Red
    Box(Modifier.background(c.copy(alpha = 0.14f), RoundedCornerShape(6.dp)).padding(horizontal = 8.dp, vertical = 2.dp)) {
        Text(if (direction == "LONG") "▲ 做多" else "▼ 承压/做空", color = c, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun PhaseChip(regime: String, confidence: Double) {
    val bull = regime.contains("牛") || regime.contains("上涨") || regime.contains("多")
    val bear = regime.contains("熊") || regime.contains("下跌") || regime.contains("空")
    val c = when { bull -> Green; bear -> Red; else -> Blue }
    Box(Modifier.background(c.copy(alpha = 0.1f), RoundedCornerShape(6.dp)).border(1.dp, c.copy(alpha = 0.35f), RoundedCornerShape(6.dp)).padding(horizontal = 7.dp, vertical = 2.dp)) {
        Text("$regime ${String.format(Locale.US, "%.0f", confidence)}", color = c, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun PlanCell(label: String, value: String, valueColor: Color = TextC) {
    Column(Modifier.background(Panel2, RoundedCornerShape(8.dp)).padding(horizontal = 10.dp, vertical = 7.dp)) {
        Text(label, color = MutedC, fontSize = 9.5.sp)
        Text(value, color = valueColor, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun LevelChip(label: String, price: Double, color: Color) {
    Box(Modifier.background(Panel2, RoundedCornerShape(6.dp)).border(1.dp, color.copy(alpha = 0.3f), RoundedCornerShape(6.dp)).padding(horizontal = 8.dp, vertical = 3.dp)) {
        Text("$label ${fmt(price)}", color = MutedC, fontSize = 10.sp)
    }
}

@Composable
private fun PosCard(p: com.klinealert.nativeapp.data.LocalStore.LocalPosition, livePrice: Double?, rep: Analysis? = null, onDelete: () -> Unit, onEdit: () -> Unit) {
    val dirColor = if (p.direction == "LONG") Green else Red
    val move = livePrice?.let { PositionEngine.directionalMovePct(p.entry, it, p.direction) }
    // 生命线：五段式阶段 + 回踩/反转四证据判别 + 关键位推演
    val lifecycle = if (livePrice != null && rep != null && livePrice > 0)
        com.klinealert.nativeapp.domain.LifecycleEngine.evaluate(p.direction, p.entry, p.stop, p.target, livePrice, rep, isPosition = true) else null
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).border(1.dp, BorderC, RoundedCornerShape(12.dp)).padding(12.dp)) {
        Row(Modifier.width(3.dp)) {}
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(baseName(p.symbol), color = TextC, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text("USDT", color = MutedC, fontSize = 8.5.sp)
            DirChip(p.direction)
            Text("本地跟踪", color = MutedC, fontSize = 9.5.sp)
            // v4.5 自动作战标识：自动入仓 + 移动止盈
            if (p.note.contains("自动作战")) ResChip("🤖自动", Yellow)
            if (p.trailing) ResChip("移动止盈", Yellow)
            Spacer(Modifier.weight(1f))
            Text("编辑", color = Color(0xFF4A7DFF), fontSize = 11.sp, modifier = Modifier.clickable(onClick = onEdit).padding(4.dp))
            Text("删除", color = Red, fontSize = 11.sp, modifier = Modifier.clickable(onClick = onDelete).padding(4.dp))
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            PlanCell("参考入场", fmt(p.entry))
            PlanCell("止损${p.stopMult.toInt()}×ATR", fmt(p.stop), Red)
            PlanCell("止盈${p.targetMult.toInt()}×ATR", fmt(p.target), Green)
            PlanCell("实时价格", livePrice?.let(::fmt) ?: "连接中…")
            PlanCell("方向变动", move?.let { (if (it >= 0) "+" else "") + String.format(Locale.US, "%.2f", it) + "%" } ?: "—", (move ?: 0.0).let { m -> if (m >= 0) Green else Red })
            // size=本金 USDT；盈亏=本金×杠杆×变动%/100；收益率=杠杆×变动%
            val usdt = move?.let { PositionEngine.pnlUsdt(p.size, p.leverage, it) }
            val yld = move?.let { PositionEngine.yieldPct(p.leverage, it) }
            PlanCell("盈亏USDT", usdt?.let { (if (it >= 0) "+" else "") + String.format(Locale.US, "%.2f", it) } ?: "—", (usdt ?: 0.0).let { m -> if (m >= 0) Green else Red })
            PlanCell("收益率", yld?.let { (if (it >= 0) "+" else "") + String.format(Locale.US, "%.1f", it) + "%" } ?: "—", (yld ?: 0.0).let { m -> if (m >= 0) Green else Red })
        }
        // v4.5 自动作战进度：距止损/止盈 + 移动止盈锚点
        livePrice?.let { lp ->
            Spacer(Modifier.height(4.dp))
            val stopDist = (p.stop - lp) / lp * 100.0
            val tgtDist = (p.target - lp) / lp * 100.0
            val anchorTxt = if (p.trailing && p.bestPrice > 0) " · 锚点 ${fmt(p.bestPrice)}（回撤 ${com.klinealert.nativeapp.domain.BattleLoopEngine.DEFAULT_TRAIL_ATR}×ATR）" else ""
            Text("距止损 ${String.format(Locale.US, "%+.2f", stopDist)}% · 距止盈 ${String.format(Locale.US, "%+.2f", tgtDist)}%$anchorTxt",
                color = MutedC, fontSize = 9.5.sp)
        }
        Spacer(Modifier.height(6.dp))
        Text(p.note, color = MutedC, fontSize = 10.sp)
        lifecycle?.let { lc ->
            Spacer(Modifier.height(8.dp))
            Box(Modifier.fillMaxWidth().height(1.dp).background(BorderC))
            Spacer(Modifier.height(6.dp))
            val lcColor = when (lc.phaseColor) { "GOOD" -> Green; "WARN" -> Yellow; else -> Red }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("生命线：${lc.phase}", color = lcColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                lc.verdict?.let { v ->
                    Text("${v.dot} ${v.status}（${v.confidence}%）", color = lcColor, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            lc.lines.forEach { Text(it, color = MutedC, fontSize = 9.5.sp, lineHeight = 12.sp) }
            lc.verdict?.evidence?.take(3)?.forEach { Text("· $it", color = MutedC, fontSize = 9.sp, maxLines = 1) }
        }
    }
}

@Composable
private fun HistoryRow(r: ReviewRecord) {
    val dirColor = if (r.direction == "LONG") Green else Red
    val verdict = when (r.verdict) {
        "hit" -> if (r.barsUsed > 0) "命中 ${r.barsUsed}根内" else "命中"
        "miss" -> "落空"
        "neutral" -> "平局"
        else -> "跟踪中"
    }
    val verdictColor = when (r.verdict) {
        "hit" -> Green
        "miss" -> Red
        "neutral" -> Yellow
        else -> MutedC
    }
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).border(1.dp, BorderC, RoundedCornerShape(12.dp)).clickable { }.padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.width(3.dp).height(16.dp).background(dirColor))
            Text(baseName(r.symbol), color = TextC, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text("USDT", color = MutedC, fontSize = 8.5.sp)
            TfChip(r.timeframe)
            Text(if (r.direction == "LONG") "多" else "空", color = dirColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Box(Modifier.background(verdictColor.copy(alpha = 0.1f), RoundedCornerShape(10.dp)).border(1.dp, verdictColor.copy(alpha = 0.35f), RoundedCornerShape(10.dp)).padding(horizontal = 7.dp, vertical = 1.dp)) {
                Text(verdict, color = verdictColor, fontSize = 9.5.sp)
            }
            Spacer(Modifier.weight(1f))
            Text("评分 ${r.score}", color = scoreColor(r.score), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(4.dp))
        Text(java.text.SimpleDateFormat("MM-dd HH:mm", Locale.US).format(java.util.Date(r.alertedAt)), color = MutedC, fontSize = 9.5.sp)
    }
}

/** 新鲜标记：确认于 X 分钟前（≤1 分钟"刚刚确认"，越新越醒目）。 */
@Composable
private fun freshBadge(candleTime: Long, now: Long): String {
    if (candleTime <= 0) return ""
    val min = (now - candleTime) / 60_000L
    return when {
        min < 1 -> " · ⚡刚刚确认"
        min < 10 -> " · ⚡${min}分钟前"
        else -> " · ${min}分钟前"
    }
}

@Composable
private fun BattleCard(role: String, sop: SymbolOpportunity, composite: Double, c: com.klinealert.nativeapp.domain.Confirmation?, onExecute: (() -> Unit)?) {
    val dirColor = if (sop.direction == "LONG") Green else Red
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).border(1.dp, if (role.contains("主攻")) Yellow else BorderC, RoundedCornerShape(12.dp)).padding(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(role, color = Yellow, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(baseName(sop.symbol), color = TextC, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            DirChip(sop.direction)
            c?.let { Text(it.status, color = MutedC, fontSize = 10.sp) }
            Spacer(Modifier.weight(1f))
            Text("综合 ${composite.toInt()}", color = Yellow, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(4.dp))
        val a = sop.rep
        Text("入场 ${fmt(a.entry)} · 止损 ${fmt(a.stop)} · T3 ${fmt(a.target)}（盈亏比 ${String.format(Locale.US, "%.2f", a.riskReward)}）", color = MutedC, fontSize = 10.sp)
        Text("入选依据：信号分×0.3 + 方向胜率×0.2 + 确认强度×0.15 + 波动健康×0.15 + 新鲜度×0.2", color = MutedC, fontSize = 9.5.sp)
        onExecute?.let {
            Spacer(Modifier.height(6.dp))
            Button(onClick = it, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Yellow)) {
                Text("按此执行（SmartLevels 自动填价位）", color = Color(0xFF0B0E14), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

private fun usMarketCountdown(): String {
    val tz = java.util.TimeZone.getTimeZone("America/New_York")
    val cal = java.util.Calendar.getInstance(tz)
    val dow = cal.get(java.util.Calendar.DAY_OF_WEEK)
    val min = cal.get(java.util.Calendar.HOUR_OF_DAY) * 60 + cal.get(java.util.Calendar.MINUTE)
    val dst = tz.inDaylightTime(cal.time)
    val open = 9 * 60 + 30; val close = 16 * 60
    fun h(m: Int) = "${m / 60}小时${m % 60}分"
    val weekend = dow == java.util.Calendar.SATURDAY || dow == java.util.Calendar.SUNDAY
    return when {
        !weekend && min < open -> "盘前 · 距开盘 ${h(open - min)}（${if (dst) "夏令时" else "冬令时"}）"
        !weekend && min < close -> "盘中 · 距收盘 ${h(close - min)}（${if (dst) "夏令时" else "冬令时"}）"
        else -> "休市（${if (dst) "夏令时" else "冬令时"}）· 开盘常引发加密波动放大"
    }
}
