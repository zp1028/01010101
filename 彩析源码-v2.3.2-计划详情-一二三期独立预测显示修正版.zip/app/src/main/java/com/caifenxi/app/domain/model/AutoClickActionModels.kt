package com.caifenxi.app.domain.model

import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * 无障碍可编排点击动作（全部可增删排序，无固定前两步）。
 * type：挂机预测点击 / 文案点击 / 金额数字等。
 */
@Serializable
data class AutoClickPostAction(
    val id: String,
    val type: String = TYPE_TEXT,
    val enabled: Boolean = true,
    /** TEXT / 玩法标签时要点击的文案 */
    val text: String = "",
    val regionEnabled: Boolean = false,
    val regionLeft: Float = 0f,
    val regionTop: Float = 0f,
    val regionRight: Float = 1f,
    val regionBottom: Float = 1f
) {
    companion object {
        /** 挂机预测：大小/单双 */
        const val TYPE_PRED_DX_DS = "pred_dx_ds"
        /** 倍投/复原金额数字键盘 */
        const val TYPE_BET_AMOUNT = "bet_amount"
        const val TYPE_COMBO = "combo"
        const val TYPE_PRED_NUMBERS = "pred_numbers"
        const val TYPE_TEXT = "text"
        /** 当前彩种扩展玩法：用 text 作为要点击文案 */
        const val TYPE_PLAY = "play"

        fun defaultList(): List<AutoClickPostAction> = defaultsForLottery(LotteryType.PKS)

        fun defaultsForLottery(type: LotteryType): List<AutoClickPostAction> {
            val core = listOf(
                AutoClickPostAction(id = "pred_dx_ds", type = TYPE_PRED_DX_DS, enabled = true, text = "大小单双"),
                AutoClickPostAction(id = "bet_amount", type = TYPE_BET_AMOUNT, enabled = true, text = "倍投金额"),
                AutoClickPostAction(id = "combo", type = TYPE_COMBO, enabled = true, text = "组合"),
                AutoClickPostAction(id = "pred_numbers", type = TYPE_PRED_NUMBERS, enabled = true, text = "位置数字")
            )
            val extra = when (type) {
                LotteryType.PKS -> listOf(
                    AutoClickPostAction(id = "pks_confirm", type = TYPE_TEXT, enabled = false, text = "确认"),
                    AutoClickPostAction(id = "pks_bet", type = TYPE_TEXT, enabled = false, text = "投注")
                )
                LotteryType.LUCK20 -> listOf(
                    AutoClickPostAction(id = "l20_confirm", type = TYPE_TEXT, enabled = false, text = "确认")
                )
                LotteryType.YDH -> listOf(
                    AutoClickPostAction(id = "ydh_long", type = TYPE_PLAY, enabled = false, text = "龙"),
                    AutoClickPostAction(id = "ydh_hu", type = TYPE_PLAY, enabled = false, text = "虎"),
                    AutoClickPostAction(id = "ydh_da", type = TYPE_PLAY, enabled = false, text = "大"),
                    AutoClickPostAction(id = "ydh_xiao", type = TYPE_PLAY, enabled = false, text = "小"),
                    AutoClickPostAction(id = "ydh_dan", type = TYPE_PLAY, enabled = false, text = "单"),
                    AutoClickPostAction(id = "ydh_shuang", type = TYPE_PLAY, enabled = false, text = "双")
                )
                LotteryType.K3 -> listOf(
                    AutoClickPostAction(id = "k3_da", type = TYPE_PLAY, enabled = false, text = "大"),
                    AutoClickPostAction(id = "k3_xiao", type = TYPE_PLAY, enabled = false, text = "小"),
                    AutoClickPostAction(id = "k3_sanjun", type = TYPE_PLAY, enabled = false, text = "三军"),
                    AutoClickPostAction(id = "k3_yxx", type = TYPE_PLAY, enabled = false, text = "鱼虾蟹")
                )
                LotteryType.PC28 -> listOf(
                    AutoClickPostAction(id = "pc28_da", type = TYPE_PLAY, enabled = false, text = "大"),
                    AutoClickPostAction(id = "pc28_xiao", type = TYPE_PLAY, enabled = false, text = "小")
                )
                else -> emptyList()
            }
            return core + extra
        }

        fun typeLabel(type: String): String = when (type) {
            TYPE_PRED_DX_DS -> "挂机预测·大小单双"
            TYPE_BET_AMOUNT -> "倍投/金额数字"
            TYPE_COMBO -> "挂机预测·组合"
            TYPE_PRED_NUMBERS -> "挂机预测·位置数字"
            TYPE_PLAY -> "玩法文案"
            TYPE_TEXT -> "点击文字"
            else -> type
        }
    }
}

object AutoClickPostActionsCodec {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    fun encode(list: List<AutoClickPostAction>): String =
        try {
            json.encodeToString(list)
        } catch (_: Exception) {
            "[]"
        }

    fun decode(raw: String?): List<AutoClickPostAction> {
        if (raw.isNullOrBlank() || raw == "[]") return AutoClickPostAction.defaultList()
        return try {
            val list = json.decodeFromString<List<AutoClickPostAction>>(raw)
            if (list.isEmpty()) return AutoClickPostAction.defaultList()
            // 旧配置无「大小单双/金额」动作时，自动补到队首，保持可编排
            val hasDx = list.any { it.type == AutoClickPostAction.TYPE_PRED_DX_DS }
            val hasAmt = list.any { it.type == AutoClickPostAction.TYPE_BET_AMOUNT }
            val prefix = buildList {
                if (!hasDx) add(
                    AutoClickPostAction(id = "pred_dx_ds", type = AutoClickPostAction.TYPE_PRED_DX_DS, enabled = true, text = "大小单双")
                )
                if (!hasAmt) add(
                    AutoClickPostAction(id = "bet_amount", type = AutoClickPostAction.TYPE_BET_AMOUNT, enabled = true, text = "倍投金额")
                )
            }
            prefix + list
        } catch (_: Exception) {
            AutoClickPostAction.defaultList()
        }
    }
}
