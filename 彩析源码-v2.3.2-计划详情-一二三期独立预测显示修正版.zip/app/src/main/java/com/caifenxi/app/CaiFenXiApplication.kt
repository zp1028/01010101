package com.caifenxi.app

import android.app.Application
import com.caifenxi.app.data.api.LotteryApiClient
import com.caifenxi.app.data.config.ConfigStore
import com.caifenxi.app.data.config.ConsensusStore
import com.caifenxi.app.data.config.LegacyJsonBackup
import com.caifenxi.app.data.config.LegacyJsonImporter
import com.caifenxi.app.data.config.ManualStore
import com.caifenxi.app.data.config.StatStore
import com.caifenxi.app.data.db.CaiDatabase
import com.caifenxi.app.data.db.dao.CustomPlanDao
import com.caifenxi.app.data.repository.DrawRepository
import com.caifenxi.app.domain.engine.BetEngine
import com.caifenxi.app.domain.plan.PlanEngine
import com.caifenxi.app.service.SyncScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class CaiFenXiApplication : Application() {
    lateinit var database: CaiDatabase private set
    lateinit var configStore: ConfigStore private set
    lateinit var statStore: StatStore private set
    lateinit var manualStore: ManualStore private set
    lateinit var consensusStore: ConsensusStore private set
    lateinit var apiClient: LotteryApiClient private set
    lateinit var drawRepository: DrawRepository private set
    lateinit var betEngine: BetEngine private set
    /** 全局共享计划引擎:前台 MainViewModel/PlanViewModel 与后台 Worker 共用同一份战绩状态 */
    lateinit var planEngine: PlanEngine private set
    val customPlanDao: CustomPlanDao get() = database.customPlanDao()

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        instance = this
        LegacyJsonBackup.backupOnce(this)
        database = CaiDatabase.getInstance(this)
        configStore = ConfigStore(this)
        statStore = StatStore(database.statDao())
        manualStore = ManualStore(database.manualMarkDao())
        consensusStore = ConsensusStore(database.consensusDao())
        apiClient = LotteryApiClient()
        drawRepository = DrawRepository(apiClient, database.drawDao(), configStore)
        betEngine = BetEngine(database.betDao())
        planEngine = PlanEngine()
        SyncScheduler.schedule(this)

        // 异步执行旧数据导入
        appScope.launch {
            try {
                LegacyJsonImporter.importOnce(this@CaiFenXiApplication, database)
            } catch (e: Exception) {
                android.util.Log.e("CaiFenXiApplication", "legacy import failed", e)
            }
        }
    }

    companion object {
        lateinit var instance: CaiFenXiApplication private set
    }
}
