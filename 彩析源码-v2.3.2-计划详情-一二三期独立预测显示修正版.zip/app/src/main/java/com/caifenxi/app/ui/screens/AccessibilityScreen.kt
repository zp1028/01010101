package com.caifenxi.app.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.model.AutoClickPostAction
import com.caifenxi.app.domain.model.LotteryPlayCatalog
import com.caifenxi.app.domain.model.AutoClickPostActionsCodec
import com.caifenxi.app.service.AutoBetAccessibilityService
import com.caifenxi.app.service.AutoBetController
import com.caifenxi.app.service.DataSyncService
import com.caifenxi.app.ui.ClickRegionPickActivity
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.components.SectionTitle
import com.caifenxi.app.util.AndroidCompat
import com.caifenxi.app.ui.theme.CaiTokens
import java.util.UUID

@Composable
private fun A11ySwitch(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(title, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

/**
 * 无障碍跟投独立页：权限、可编排点击流水线、区域框选、试点击。
 */
@Composable
fun AccessibilityScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val p = vm.prefs.value
    var a11yOn by remember { mutableStateOf(AutoBetController.isAccessibilityEnabled(context)) }
    var serviceRunning by remember { mutableStateOf(AutoBetAccessibilityService.isRunning()) }
    var postActions by remember(p.autoClickPostActionsJson) {
        mutableStateOf(AutoClickPostActionsCodec.decode(p.autoClickPostActionsJson))
    }
    var newText by remember { mutableStateOf("") }

    fun refreshFlags() {
        a11yOn = AutoBetController.isAccessibilityEnabled(context)
        serviceRunning = AutoBetAccessibilityService.isRunning()
    }

    fun savePostActions(list: List<AutoClickPostAction>) {
        postActions = list
        vm.updatePrefs { it.copy(autoClickPostActionsJson = AutoClickPostActionsCodec.encode(list)) }
    }

    LaunchedEffect(Unit) { refreshFlags() }

    LazyColumn(
        Modifier
            .fillMaxSize()
            .padding(horizontal = CaiTokens.ScreenHPadding),
        verticalArrangement = Arrangement.spacedBy(CaiTokens.S8),
        contentPadding = PaddingValues(top = CaiTokens.S16, bottom = CaiTokens.ScreenBottom)
    ) {
        item {
            Text("无障碍跟投", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            CaptionMuted("全部动作可增删排序：挂机预测（大小单双/组合/位置数字）、倍投金额、点击文字；每步可框选区域")
        }

        item {
            SectionTitle("权限与总控")
            GlobalCard {
                Text(
                    when {
                        !a11yOn -> "系统无障碍：未开启"
                        !serviceRunning -> "无障碍：已开但未连接，请重开一次服务"
                        else -> "无障碍：已就绪"
                    },
                    fontWeight = FontWeight.SemiBold
                )
                PrimaryButton("打开系统无障碍设置", {
                    AutoBetController.openAccessibilitySettings(context)
                    refreshFlags()
                }, Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                A11ySwitch("启用真实自动点击", p.autoClickEnabled) { enabled ->
                    if (enabled && !AutoBetController.isAccessibilityEnabled(context)) {
                        AutoBetController.openAccessibilitySettings(context)
                    }
                    vm.updatePrefs { it.copy(autoClickEnabled = enabled) }
                    refreshFlags()
                }
                A11ySwitch("仅模拟（不真实点击）", p.autoClickSimulateOnly) {
                    vm.updatePrefs { pref -> pref.copy(autoClickSimulateOnly = it) }
                }
                A11ySwitch("跟随挂机预测来源", p.autoClickFollowBetSource) {
                    vm.updatePrefs { pref -> pref.copy(autoClickFollowBetSource = it) }
                }
                val lotteryKey = vm.currentLottery.value.key
                val srcDesc = remember(p.autoClickFollowBetSource, lotteryKey, p.floatingSource) {
                    AutoBetController.describeClickSource(context, p, lotteryKey)
                }
                CaptionMuted(srcDesc + "（关则仍用设置页悬浮窗来源）")
                A11ySwitch("无障碍控制悬浮窗", p.autoClickPanelEnabled) { enabled ->
                    if (enabled && !Settings.canDrawOverlays(context)) {
                        try {
                            context.startActivity(
                                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        } catch (_: Exception) {
                        }
                    }
                    vm.updatePrefs { it.copy(autoClickPanelEnabled = enabled) }
                    AndroidCompat.startDataSyncService(
                        context,
                        Intent(context, DataSyncService::class.java).setAction(DataSyncService.ACTION_REFRESH_OVERLAY)
                    )
                }
                A11ySwitch("显示点击红点", p.autoClickShowFeedback) {
                    vm.updatePrefs { pref -> pref.copy(autoClickShowFeedback = it) }
                }
                A11ySwitch("允许点击大小单双（总开关）", p.autoExecClickDxDs) {
                    vm.updatePrefs { pref -> pref.copy(autoExecClickDxDs = it) }
                }
            }
        }

        item {
            SectionTitle("倍投 / 复原数字")
            GlobalCard {
                CaptionMuted("流水线中的「倍投/金额数字」动作会使用以下参数；需在动作列表中开启该步骤才会执行。")
                A11ySwitch("启用金额数字输入", p.autoInputEnabled) {
                    vm.updatePrefs { pref -> pref.copy(autoInputEnabled = it) }
                }
                A11ySwitch("查找并点击输入框", p.autoExecFindInput) {
                    vm.updatePrefs { pref -> pref.copy(autoExecFindInput = it) }
                }
                A11ySwitch("逐位点击金额数字", p.autoExecTypeAmount) {
                    vm.updatePrefs { pref -> pref.copy(autoExecTypeAmount = it) }
                }
                A11ySwitch("输数字前先清空", p.autoClickClearBeforeDigits) {
                    vm.updatePrefs { pref -> pref.copy(autoClickClearBeforeDigits = it) }
                }
                Text("基础金额（复原）：${"%.1f".format(p.autoInputBaseAmount)}")
                Slider(
                    value = p.autoInputBaseAmount.toFloat().coerceIn(1f, 500f),
                    onValueChange = { v ->
                        vm.updatePrefs { pref -> pref.copy(autoInputBaseAmount = v.toDouble().coerceIn(1.0, 9999.0)) }
                    },
                    valueRange = 1f..200f
                )
                Text("倍投金额：${"%.1f".format(p.autoInputMultAmount)}")
                Slider(
                    value = p.autoInputMultAmount.toFloat().coerceIn(1f, 500f),
                    onValueChange = { v ->
                        vm.updatePrefs { pref -> pref.copy(autoInputMultAmount = v.toDouble().coerceIn(1.0, 9999.0)) }
                    },
                    valueRange = 1f..500f
                )
                Text("追号期数上限：${p.autoInputChaseMax}（1=仅当期金额）")
                Slider(
                    value = p.autoInputChaseMax.toFloat().coerceIn(1f, 10f),
                    onValueChange = { v ->
                        vm.updatePrefs { pref -> pref.copy(autoInputChaseMax = v.toInt().coerceIn(1, 20)) }
                    },
                    valueRange = 1f..10f,
                    steps = 8
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = p.autoInputRegionEnabled,
                        onClick = {
                            context.startActivity(
                                Intent(context, ClickRegionPickActivity::class.java)
                                    .putExtra(ClickRegionPickActivity.EXTRA_MODE, ClickRegionPickActivity.MODE_INPUT)
                            )
                        },
                        label = { Text(if (p.autoInputRegionEnabled) "已框数字键盘区" else "框选数字键盘区域") }
                    )
                    if (p.autoInputRegionEnabled) {
                        FilterChip(
                            selected = false,
                            onClick = {
                                vm.updatePrefs { pref ->
                                    pref.copy(
                                        autoInputRegionEnabled = false,
                                        autoInputRegionLeft = 0f,
                                        autoInputRegionTop = 0f,
                                        autoInputRegionRight = 1f,
                                        autoInputRegionBottom = 1f
                                    )
                                }
                            },
                            label = { Text("清除键盘区域") }
                        )
                    }
                }
                CaptionMuted("基础金额用于复原；倍投金额用于连错后加码。与挂机倍投策略配合使用。")
            }
        }

        item {
            SectionTitle("点击动作流水线（可排序 / 增删）")
            CaptionMuted("全部动作可自由排序：挂机预测大小单双、倍投金额、组合、位置数字、点击文字、彩种玩法。按当前彩种可一键重置默认。")
            val lot = vm.currentLottery.value
            CaptionMuted("当前彩种玩法：" + LotteryPlayCatalog.summaryText(lot.type))
            PrimaryButton(
                "按当前彩种重置动作",
                {
                    val list = AutoClickPostAction.defaultsForLottery(lot.type)
                    postActions = list
                    savePostActions(list)
                },
                Modifier.fillMaxWidth(),
                ghost = true
            )
        }

        itemsIndexed(postActions, key = { _, a -> a.id }) { index, action ->
            GlobalCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        AutoClickPostAction.typeLabel(action.type) +
                            if (action.text.isNotBlank() && action.type in listOf(
                                    AutoClickPostAction.TYPE_TEXT,
                                    AutoClickPostAction.TYPE_PLAY
                                )
                            ) " · ${action.text}" else "",
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f)
                    )
                    Switch(
                        checked = action.enabled,
                        onCheckedChange = { on ->
                            savePostActions(postActions.mapIndexed { i, a -> if (i == index) a.copy(enabled = on) else a })
                        }
                    )
                }
                if (action.type == AutoClickPostAction.TYPE_TEXT || action.type == AutoClickPostAction.TYPE_PLAY) {
                    OutlinedTextField(
                        value = action.text,
                        onValueChange = { t ->
                            savePostActions(postActions.mapIndexed { i, a -> if (i == index) a.copy(text = t.take(12)) else a })
                        },
                        label = { Text("点击文案") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = false,
                        onClick = {
                            if (index > 0) {
                                val list = postActions.toMutableList()
                                val tmp = list[index - 1]
                                list[index - 1] = list[index]
                                list[index] = tmp
                                savePostActions(list)
                            }
                        },
                        label = { Text("上移") },
                        enabled = index > 0
                    )
                    FilterChip(
                        selected = false,
                        onClick = {
                            if (index < postActions.lastIndex) {
                                val list = postActions.toMutableList()
                                val tmp = list[index + 1]
                                list[index + 1] = list[index]
                                list[index] = tmp
                                savePostActions(list)
                            }
                        },
                        label = { Text("下移") },
                        enabled = index < postActions.lastIndex
                    )
                    FilterChip(
                        selected = action.regionEnabled,
                        onClick = {
                            context.startActivity(
                                Intent(context, ClickRegionPickActivity::class.java)
                                    .putExtra(ClickRegionPickActivity.EXTRA_MODE, ClickRegionPickActivity.MODE_ACTION)
                                    .putExtra(ClickRegionPickActivity.EXTRA_ACTION_ID, action.id)
                            )
                        },
                        label = { Text("框选区域") }
                    )
                    FilterChip(
                        selected = false,
                        onClick = {
                            savePostActions(postActions.filterIndexed { i, _ -> i != index })
                        },
                        label = { Text("删除") }
                    )
                }
            }
        }

        item {
            GlobalCard {
                Text("添加动作", fontWeight = FontWeight.SemiBold)
                CaptionMuted("挂机预测类读取挂机下单结果；文字类点击界面固定文案。")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(
                        AutoClickPostAction.TYPE_PRED_DX_DS to "大小单双",
                        AutoClickPostAction.TYPE_BET_AMOUNT to "金额数字",
                        AutoClickPostAction.TYPE_COMBO to "组合",
                        AutoClickPostAction.TYPE_PRED_NUMBERS to "位置数字"
                    ).forEach { (ty, label) ->
                        FilterChip(
                            selected = false,
                            onClick = {
                                if (postActions.none { it.type == ty }) {
                                    savePostActions(
                                        postActions + AutoClickPostAction(
                                            id = ty + "_" + UUID.randomUUID().toString().take(4),
                                            type = ty,
                                            enabled = true,
                                            text = label
                                        )
                                    )
                                }
                            },
                            label = { Text("+ $label") }
                        )
                    }
                }
                OutlinedTextField(
                    value = newText,
                    onValueChange = { newText = it.take(12) },
                    label = { Text("自定义点击文字，如：确认") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                PrimaryButton("添加点击文字", {
                    val t = newText.trim()
                    if (t.isNotEmpty()) {
                        savePostActions(
                            postActions + AutoClickPostAction(
                                id = UUID.randomUUID().toString().take(8),
                                type = AutoClickPostAction.TYPE_TEXT,
                                enabled = true,
                                text = t
                            )
                        )
                        newText = ""
                    }
                }, Modifier.fillMaxWidth())
                // 当前彩种扩展玩法
                val plays = LotteryPlayCatalog.plays(vm.currentLottery.value.type)
                if (plays.isNotEmpty()) {
                    CaptionMuted("当前彩种玩法标签（可添加为点击）")
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        plays.take(8).forEach { play ->
                            FilterChip(
                                selected = false,
                                onClick = {
                                    savePostActions(
                                        postActions + AutoClickPostAction(
                                            id = "play_" + play.id + UUID.randomUUID().toString().take(3),
                                            type = AutoClickPostAction.TYPE_PLAY,
                                            enabled = true,
                                            text = play.label.take(6)
                                        )
                                    )
                                },
                                label = { Text("+ ${play.label}") }
                            )
                        }
                    }
                }
            }
        }

        item {
            SectionTitle("参数")
            GlobalCard {
                Text("点击间隔：${p.autoClickDelayMs}ms")
                Slider(
                    value = p.autoClickDelayMs.toFloat(),
                    onValueChange = { v -> vm.updatePrefs { it.copy(autoClickDelayMs = v.toLong().coerceIn(100L, 2000L)) } },
                    valueRange = 100f..2000f
                )
                Text("连续失败停点：${p.autoClickFailStopCount} 次（0=不限制）")
                Slider(
                    value = p.autoClickFailStopCount.toFloat(),
                    onValueChange = { v -> vm.updatePrefs { it.copy(autoClickFailStopCount = v.toInt().coerceIn(0, 10)) } },
                    valueRange = 0f..10f,
                    steps = 9
                )
            }
        }

        item {
            SectionTitle("试点击")
            GlobalCard {
                CaptionMuted("不记挂机订单；请先切到投注页再点。会走完整流水线（含已开启的后续动作）。")
                PrimaryButton("立即试跑一轮", {
                    refreshFlags()
                    AutoBetController.tryNow(context)
                }, Modifier.fillMaxWidth())
            }
        }
    }
}
