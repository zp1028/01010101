package com.caifenxi.app.ui

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Build
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.caifenxi.app.CaiFenXiApplication
import com.caifenxi.app.util.RuntimeLog
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * 真正全屏自由框选区域（沉浸式，坐标按真实屏幕像素归一化 0～1）。
 *
 * EXTRA_MODE:
 * - [MODE_CLICK] 大小单双点击区域 → autoClickRegion*
 * - [MODE_INPUT] 数字键盘区域 → autoInputRegion*
 * - [MODE_ACTION] 后续文案/组合/号码动作区域 → 写入对应 postAction.id
 *
 * 手指在全屏任意位置拖出矩形；「全屏」一键选整屏；确认后按 displayMetrics 比例落盘。
 */
class ClickRegionPickActivity : ComponentActivity() {

    companion object {
        const val EXTRA_MODE = "region_mode"
        const val EXTRA_ACTION_ID = "action_id"
        const val MODE_CLICK = "click"
        const val MODE_INPUT = "input"
        const val MODE_ACTION = "action"
    }

    private lateinit var pickView: RegionPickView
    private var mode: String = MODE_CLICK
    private var actionId: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mode = intent.getStringExtra(EXTRA_MODE) ?: MODE_CLICK
        actionId = intent.getStringExtra(EXTRA_ACTION_ID).orEmpty()
        enterImmersive()

        val root = FrameLayout(this)
        pickView = RegionPickView(this).apply {
            titleText = when (mode) {
                MODE_INPUT -> "框选数字键盘区域"
                MODE_ACTION -> "框选动作点击区域"
                else -> "框选大小单双点击区域"
            }
            hintText = when (mode) {
                MODE_INPUT -> "全屏任意位置拖动框选数字键(0-9)，确认后仅在该区域点数字"
                MODE_ACTION -> "全屏拖动框选本条动作的识别范围（组合/文案/预测数字）"
                else -> "全屏任意位置拖动框选「大/小/单/双」，确认后仅在该区域点击"
            }
            accentColor = when (mode) {
                MODE_INPUT -> Color.rgb(33, 150, 243)
                MODE_ACTION -> Color.rgb(255, 152, 0)
                else -> Color.rgb(76, 175, 80)
            }
            screenW = resources.displayMetrics.widthPixels.toFloat().coerceAtLeast(1f)
            screenH = resources.displayMetrics.heightPixels.toFloat().coerceAtLeast(1f)
        }
        try {
            val p = CaiFenXiApplication.instance.configStore.loadPrefs()
            when (mode) {
                MODE_INPUT -> pickView.setNormalized(
                    p.autoInputRegionLeft, p.autoInputRegionTop, p.autoInputRegionRight, p.autoInputRegionBottom
                )
                MODE_ACTION -> {
                    val act = com.caifenxi.app.domain.model.AutoClickPostActionsCodec.decode(p.autoClickPostActionsJson)
                        .firstOrNull { it.id == actionId }
                    if (act != null && act.regionEnabled) {
                        pickView.setNormalized(act.regionLeft, act.regionTop, act.regionRight, act.regionBottom)
                    }
                }
                else -> pickView.setNormalized(
                    p.autoClickRegionLeft, p.autoClickRegionTop, p.autoClickRegionRight, p.autoClickRegionBottom
                )
            }
        } catch (_: Exception) {
        }
        root.addView(
            pickView,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )
        setContentView(root)

        pickView.onConfirm = { l, t, r, b ->
            try {
                val store = CaiFenXiApplication.instance.configStore
                val prefs = store.loadPrefs()
                val dm = resources.displayMetrics
                val sw = dm.widthPixels
                val sh = dm.heightPixels
                val updated = when (mode) {
                    MODE_INPUT -> prefs.copy(
                        autoInputRegionEnabled = true,
                        autoInputRegionLeft = l,
                        autoInputRegionTop = t,
                        autoInputRegionRight = r,
                        autoInputRegionBottom = b,
                        autoInputRegionScreenW = sw,
                        autoInputRegionScreenH = sh
                    )
                    MODE_ACTION -> {
                        val list = com.caifenxi.app.domain.model.AutoClickPostActionsCodec
                            .decode(prefs.autoClickPostActionsJson)
                            .map { a ->
                                if (a.id == actionId) a.copy(
                                    regionEnabled = true,
                                    regionLeft = l,
                                    regionTop = t,
                                    regionRight = r,
                                    regionBottom = b
                                ) else a
                            }
                        prefs.copy(
                            autoClickPostActionsJson = com.caifenxi.app.domain.model.AutoClickPostActionsCodec.encode(list)
                        )
                    }
                    else -> prefs.copy(
                        autoClickRegionEnabled = true,
                        autoClickRegionLeft = l,
                        autoClickRegionTop = t,
                        autoClickRegionRight = r,
                        autoClickRegionBottom = b,
                        autoClickRegionScreenW = sw,
                        autoClickRegionScreenH = sh
                    )
                }
                store.savePrefs(updated)
                val tag = when (mode) {
                    MODE_INPUT -> "数字键盘区域"
                    MODE_ACTION -> "动作区域($actionId)"
                    else -> "大小单双点击区域"
                }
                RuntimeLog.info(
                    "AutoBet",
                    "$tag 已保存 L=${pct(l)} T=${pct(t)} R=${pct(r)} B=${pct(b)} screen=${sw}x$sh"
                )
            } catch (e: Exception) {
                RuntimeLog.warn("AutoBet", "保存框选区域失败: ${e.message}")
            }
            setResult(RESULT_OK)
            finish()
        }
        pickView.onCancel = {
            setResult(RESULT_CANCELED)
            finish()
        }
    }

    private fun enterImmersive() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterImmersive()
    }

    private fun pct(v: Float) = "${(v * 100).toInt()}%"

    private class RegionPickView(context: android.content.Context) : View(context) {
        var onConfirm: ((Float, Float, Float, Float) -> Unit)? = null
        var onCancel: (() -> Unit)? = null
        var titleText: String = "框选区域"
        var hintText: String = "手指拖动选择任意矩形区域"
        var accentColor: Int = Color.rgb(76, 175, 80)
        var screenW: Float = 1f
        var screenH: Float = 1f

        private val dimPaint = Paint().apply {
            color = Color.argb(150, 0, 0, 0)
            style = Paint.Style.FILL
        }
        private val boxPaint = Paint().apply { style = Paint.Style.FILL }
        private val borderPaint = Paint().apply {
            style = Paint.Style.STROKE
            strokeWidth = 5f
            isAntiAlias = true
        }
        private val textPaint = Paint().apply {
            color = Color.WHITE
            textSize = 42f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        private val hintPaint = Paint().apply {
            color = Color.argb(230, 255, 255, 255)
            textSize = 28f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        private val metaPaint = Paint().apply {
            color = Color.argb(200, 200, 230, 255)
            textSize = 26f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        private val btnPaint = Paint().apply {
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        private val btnTextPaint = Paint().apply {
            color = Color.WHITE
            textSize = 36f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }

        // 使用屏幕绝对坐标（raw），避免状态栏导致归一化偏移
        private var startRawX = 0f
        private var startRawY = 0f
        private var curRawX = 0f
        private var curRawY = 0f
        private var dragging = false
        private var hasBox = false

        /** 屏幕绝对像素矩形 */
        private val boxScreen = RectF()
        private val confirmBtn = RectF()
        private val cancelBtn = RectF()
        private val fullBtn = RectF()
        private val clearBtn = RectF()

        private val loc = IntArray(2)

        fun setNormalized(l: Float, t: Float, r: Float, b: Float) {
            post {
                if (r - l < 0.01f || b - t < 0.01f) {
                    hasBox = false
                    invalidate()
                    return@post
                }
                boxScreen.set(l * screenW, t * screenH, r * screenW, b * screenH)
                hasBox = boxScreen.width() > 8 && boxScreen.height() > 8
                invalidate()
            }
        }

        private fun viewToScreen(x: Float, y: Float): Pair<Float, Float> {
            getLocationOnScreen(loc)
            return (x + loc[0]) to (y + loc[1])
        }

        private fun screenToView(sx: Float, sy: Float): Pair<Float, Float> {
            getLocationOnScreen(loc)
            return (sx - loc[0]) to (sy - loc[1])
        }

        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            boxPaint.color = Color.argb(90, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor))
            borderPaint.color = accentColor
            btnPaint.color = accentColor

            canvas.drawRect(0f, 0f, w, h, dimPaint)

            if (hasBox || dragging) {
                val sx1: Float
                val sy1: Float
                val sx2: Float
                val sy2: Float
                if (dragging) {
                    sx1 = min(startRawX, curRawX)
                    sy1 = min(startRawY, curRawY)
                    sx2 = max(startRawX, curRawX)
                    sy2 = max(startRawY, curRawY)
                } else {
                    sx1 = boxScreen.left
                    sy1 = boxScreen.top
                    sx2 = boxScreen.right
                    sy2 = boxScreen.bottom
                }
                val (vx1, vy1) = screenToView(sx1, sy1)
                val (vx2, vy2) = screenToView(sx2, sy2)
                val rect = RectF(vx1, vy1, vx2, vy2)
                canvas.drawRect(rect, boxPaint)
                canvas.drawRect(rect, borderPaint)

                val pctL = ((sx1 / screenW) * 100).toInt()
                val pctT = ((sy1 / screenH) * 100).toInt()
                val pctR = ((sx2 / screenW) * 100).toInt()
                val pctB = ((sy2 / screenH) * 100).toInt()
                canvas.drawText(
                    "区域 ${pctL}% , ${pctT}% → ${pctR}% , ${pctB}%",
                    w / 2f,
                    180f,
                    metaPaint
                )
            }

            canvas.drawText(titleText, w / 2f, 72f, textPaint)
            canvas.drawText(hintText, w / 2f, 120f, hintPaint)
            canvas.drawText("可拖到屏幕任意位置，不限预设", w / 2f, 220f, metaPaint)

            val btnH = 96f
            val margin = 20f
            val gap = 12f
            val btnW = (w - margin * 2 - gap * 3) / 4f
            val by = h - btnH - margin - 16f
            cancelBtn.set(margin, by, margin + btnW, by + btnH)
            clearBtn.set(margin + btnW + gap, by, margin + btnW * 2 + gap, by + btnH)
            fullBtn.set(margin + btnW * 2 + gap * 2, by, margin + btnW * 3 + gap * 2, by + btnH)
            confirmBtn.set(margin + btnW * 3 + gap * 3, by, w - margin, by + btnH)

            drawBtn(canvas, cancelBtn, "取消")
            drawBtn(canvas, clearBtn, "清除")
            drawBtn(canvas, fullBtn, "全屏")
            drawBtn(canvas, confirmBtn, "确认")
        }

        private fun drawBtn(canvas: Canvas, r: RectF, label: String) {
            canvas.drawRoundRect(r, 16f, 16f, btnPaint)
            val ty = r.centerY() - (btnTextPaint.descent() + btnTextPaint.ascent()) / 2
            canvas.drawText(label, r.centerX(), ty, btnTextPaint)
        }

        private fun hitButton(x: Float, y: Float): String? = when {
            cancelBtn.contains(x, y) -> "cancel"
            clearBtn.contains(x, y) -> "clear"
            fullBtn.contains(x, y) -> "full"
            confirmBtn.contains(x, y) -> "confirm"
            else -> null
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    val x = event.x
                    val y = event.y
                    if (hitButton(x, y) != null) return true
                    val (sx, sy) = viewToScreen(x, y)
                    startRawX = sx
                    startRawY = sy
                    curRawX = sx
                    curRawY = sy
                    dragging = true
                    hasBox = false
                    invalidate()
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (dragging) {
                        val (sx, sy) = viewToScreen(event.x, event.y)
                        curRawX = sx.coerceIn(0f, screenW)
                        curRawY = sy.coerceIn(0f, screenH)
                        invalidate()
                    }
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val x = event.x
                    val y = event.y
                    if (!dragging) {
                        when (hitButton(x, y)) {
                            "cancel" -> onCancel?.invoke()
                            "clear" -> {
                                hasBox = false
                                boxScreen.setEmpty()
                                invalidate()
                            }
                            "full" -> {
                                boxScreen.set(0f, 0f, screenW, screenH)
                                hasBox = true
                                invalidate()
                            }
                            "confirm" -> confirmNormalized()
                        }
                        return true
                    }
                    dragging = false
                    val l = min(startRawX, curRawX).coerceIn(0f, screenW)
                    val t = min(startRawY, curRawY).coerceIn(0f, screenH)
                    val r = max(startRawX, curRawX).coerceIn(0f, screenW)
                    val b = max(startRawY, curRawY).coerceIn(0f, screenH)
                    if (abs(r - l) > 12 && abs(b - t) > 12) {
                        boxScreen.set(l, t, r, b)
                        hasBox = true
                    }
                    when (hitButton(x, y)) {
                        "cancel" -> onCancel?.invoke()
                        "clear" -> {
                            hasBox = false
                            boxScreen.setEmpty()
                        }
                        "full" -> {
                            boxScreen.set(0f, 0f, screenW, screenH)
                            hasBox = true
                        }
                        "confirm" -> confirmNormalized()
                    }
                    invalidate()
                    return true
                }
            }
            return super.onTouchEvent(event)
        }

        private fun confirmNormalized() {
            if (!hasBox) return
            val l = (boxScreen.left / screenW).coerceIn(0f, 1f)
            val t = (boxScreen.top / screenH).coerceIn(0f, 1f)
            val r = (boxScreen.right / screenW).coerceIn(0f, 1f)
            val b = (boxScreen.bottom / screenH).coerceIn(0f, 1f)
            // 允许很小的区域（数字键可能很紧凑），最低约 1%
            if (r - l < 0.01f || b - t < 0.01f) return
            onConfirm?.invoke(l, t, r, b)
        }
    }
}
