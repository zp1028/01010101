package com.caifenxi.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.TextButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.fastAny
import androidx.compose.ui.util.fastForEach
import kotlin.math.abs
import com.caifenxi.app.domain.model.AlgoMode
import com.caifenxi.app.domain.model.BetCategory
import com.caifenxi.app.domain.model.LotteryBetRules
import com.caifenxi.app.domain.model.BetSourceType
import com.caifenxi.app.domain.model.BotConfig
import com.caifenxi.app.domain.model.CatBetStats
import com.caifenxi.app.domain.model.LotteryType
import com.caifenxi.app.domain.model.LotteryPlayCatalog
import com.caifenxi.app.domain.plan.NovaPlanPool
import com.caifenxi.app.domain.plan.NovaYdhPlanPool
import com.caifenxi.app.domain.plan.NovaK3PlanPool
import com.caifenxi.app.domain.plan.LotteryPlanPools
import com.caifenxi.app.domain.plan.PlanPool
import com.caifenxi.app.domain.model.PksPositions
import com.caifenxi.app.domain.model.ProfitPoint
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.StrategySummaryCard
import com.caifenxi.app.ui.components.UiFormat
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.components.SectionTitle
import com.caifenxi.app.ui.theme.CaiTokens
import kotlin.math.roundToInt

@Composable
fun BetScreen(vm: MainViewModel) {
    val cfg = vm.botConfig.value
    val stats = vm.betStats.value
    val bets = vm.betHistory.value
    val isPks = vm.currentLottery.value.type == LotteryType.PKS
    val isConsensus = cfg.sourceType == "consensus"
    val curveReset = vm.betCurveReset.value
    val curveRevision = vm.betCurveRevision.value

    var amountText by remember(cfg.amount) { mutableStateOf(cfg.amount.toInt().toString()) }
    var initText by remember(stats.initialBalance) { mutableStateOf(stats.initialBalance.toInt().toString()) }
    var winMultText by remember(cfg.winMult) { mutableStateOf(cfg.winMult.toString()) }
    var lossMultText by remember(cfg.lossMult) { mutableStateOf(cfg.lossMult.toString()) }
    var winPeriodsText by remember(cfg.winMultPeriods) { mutableStateOf(cfg.winMultPeriods.toString()) }
    var lossPeriodsText by remember(cfg.lossMultPeriods) { mutableStateOf(cfg.lossMultPeriods.toString()) }
    var maxMultText by remember(cfg.maxMult) { mutableStateOf(cfg.maxMult.toString()) }
    var curveExpanded by remember { mutableStateOf(true) }
    var showResetDialog by remember { mutableStateOf(false) }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("重置挂机总览?") },
            text = { Text("将清空下注记录、累计收益、总投注、胜率和全部对错统计,恢复当前初始资金。挂机策略和倍投配置会保留。") },
            confirmButton = {
                TextButton(onClick = {
                    showResetDialog = false
                    vm.resetBetOverview()
                }) { Text("确认重置") }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) { Text("取消") }
            }
        )
    }

    LazyColumn(
        Modifier
            .fillMaxSize()
            .padding(horizontal = CaiTokens.ScreenHPadding)
            .padding(top = CaiTokens.S16),
        verticalArrangement = Arrangement.spacedBy(CaiTokens.S12)
    ) {
        item {
            Text("模拟下注", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            CaptionMuted("虚拟资金 · 每期开奖自动结算 · 仅本地模拟")
        }

        // ---- 收藏计划同步区（仅监控/模拟，不驱动真实自动点击） ----
        item {
            val favoriteIds = vm.favoritePlanIds(vm.currentLottery.value.key)
            val favoritePlans = (vm.planRows.value.map { it.first } +
                vm.planVM.generatedNovaPlans.value +
                LotteryPlanPools.novaPlansFor(vm.currentLottery.value.type) +
                LotteryPlanPools.legacyPlansFor(vm.currentLottery.value.type))
                .distinctBy { it.planId }
                .filter { it.planId in favoriteIds }
            GlobalCard {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("★ 收藏计划", fontWeight = FontWeight.Bold)
                        CaptionMuted("已同步 ${favoritePlans.size} 个 · 当前彩种独立保存")
                    }
                    Text("${favoriteIds.size}", fontWeight = FontWeight.Bold, fontSize = 22.sp)
                }
                if (favoritePlans.isEmpty()) {
                    CaptionMuted("还没有收藏计划。到「计划工作台」点击 ☆ 即可收藏。")
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = CaiTokens.S8)) {
                        favoritePlans.take(8).forEach { plan ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Star, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(6.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(plan.planName, fontWeight = FontWeight.SemiBold)
                                    CaptionMuted("${plan.playType} · ${plan.algorithm} · ${plan.window}期${if (plan.positionIndex >= 0) " · 位置${plan.positionIndex + 1}" else ""}")
                                }
                            }
                        }
                    }
                    if (favoritePlans.size > 8) CaptionMuted("还有 ${favoritePlans.size - 8} 个收藏计划，可到计划工作台查看全部。")
                }
                CaptionMuted("上方可预览收藏计划。真实挂机请在「预测来源」中选择「收藏计划」并点选具体计划。")
            }
        }

        // ---- 资金与收益区 ----
        item {
            GlobalCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("当前余额", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                        Text(
                            "%.0f".format(stats.balance),
                            fontWeight = FontWeight.Bold,
                            fontSize = 30.sp,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            if (stats.totalProfit >= 0) "+%.0f".format(stats.totalProfit)
                            else "%.0f".format(stats.totalProfit),
                            fontWeight = FontWeight.Bold,
                            color = if (stats.totalProfit >= 0) Color(0xFF2E7D32) else Color(0xFFC62828)
                        )
                        CaptionMuted("累计盈亏")
                    }
                }
                Spacer(Modifier.height(CaiTokens.S12))

                // 收益/胜率指标行
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    StatMini("总投注", "%.0f".format(stats.totalBet))
                    StatMini("中奖", "${stats.winCount}")
                    StatMini("未中", "${stats.loseCount}")
                    StatMini("胜率", if (stats.totalSettled > 0) "${(stats.winRate * 100).roundToInt()}%" else "-")
                }
                Spacer(Modifier.height(CaiTokens.S8))

                // 收益率进度条
                val rateColor = if (stats.profitRate >= 0) Color(0xFF2E7D32) else Color(0xFFC62828)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("收益率", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Text(
                        "${(stats.profitRate * 100).roundToInt()}%",
                        fontWeight = FontWeight.Bold,
                        color = rateColor,
                        fontSize = 13.sp
                    )
                }
                LinearProgressIndicator(
                    progress = { (stats.profitRate.coerceIn(-1.0, 1.0) + 1.0).toFloat() / 2.0f },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                    color = rateColor
                )
                Spacer(Modifier.height(CaiTokens.S8))

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    StatMini("本期投入", "%.0f".format(stats.currentBetAmount))
                    StatMini("本期盈亏",
                        if (stats.currentProfit >= 0) "+${stats.currentProfit.roundToInt()}"
                        else "${stats.currentProfit.roundToInt()}")
                    StatMini("初始", "%.0f".format(stats.initialBalance))
                }
                Spacer(Modifier.height(CaiTokens.S12))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = initText,
                        onValueChange = { initText = it.filter { c -> c.isDigit() } },
                        label = { Text("初始资金") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    Spacer(Modifier.width(CaiTokens.S8))
                    PrimaryButton("设置", onClick = {
                        val v = initText.toDoubleOrNull() ?: 0.0
                        if (v > 0) vm.setInitialBalance(v)
                    }, ghost = true)
                }
                Spacer(Modifier.height(CaiTokens.S8))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    PrimaryButton("刷新总览", onClick = { vm.refreshBetOverview() }, ghost = true)
                    Spacer(Modifier.width(CaiTokens.S8))
                    PrimaryButton("重置总览", onClick = { showResetDialog = true }, ghost = true)
                }
            }
        }

        // ---- 收益曲线区(可折叠) ----
        item {
            GlobalCard {
                Row(
                    Modifier.fillMaxWidth().clickable { curveExpanded = !curveExpanded },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("收益曲线", fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(CaiTokens.S8))
                            if (stats.totalProfit >= 0) {
                                Text(
                                    "+${stats.totalProfit.roundToInt()}",
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF2E7D32),
                                    fontSize = 14.sp
                                )
                            } else {
                                Text(
                                    "${stats.totalProfit.roundToInt()}",
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFC62828),
                                    fontSize = 14.sp
                                )
                            }
                        }
                        CaptionMuted(
                            "最大回撤 ${stats.maxDrawdown.roundToInt()} " +
                                "(${(stats.maxDrawdownPct * 100).roundToInt()}%) · " +
                                "最长连对 ${stats.maxHitStreak} · 最长连错 ${stats.maxMissStreak}"
                        )
                    }
                    Icon(
                        if (curveExpanded) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                        contentDescription = if (curveExpanded) "收起" else "展开",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                AnimatedVisibility(visible = curveExpanded) {
                    key(curveRevision) {
                        Column(Modifier.padding(top = CaiTokens.S12)) {
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                PrimaryButton("刷新曲线", onClick = { vm.refreshBetCurve() }, ghost = true)
                                Spacer(Modifier.width(CaiTokens.S8))
                                PrimaryButton("重置曲线", onClick = { vm.resetBetCurve() }, ghost = true)
                            }
                            Spacer(Modifier.height(CaiTokens.S8))
                            if (curveReset || stats.profitCurve.isEmpty()) {
                                Text("曲线已重置,点击“刷新曲线”重新生成。",
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            } else {
                                ProfitCurveChart(
                                    points = stats.profitCurve,
                                    maxDrawdown = stats.maxDrawdown
                                )
                                Spacer(Modifier.height(CaiTokens.S8))
                                CaptionMuted("绿涨红跌 · 虚线最大回撤 · 色带连对/连错 · 可双指缩放与拖动")
                            }
                        }
                    }
                }
            }
        }

        // ---- 挂机设置区 ----
        item {
            SectionTitle("挂机策略")
            GlobalCard {
                // 来源选择
                val bot = vm.betVM.botConfig.value
                    StrategySummaryCard(
                        title = "挂机策略摘要",
                        rows = listOf(
                            "彩种" to vm.currentLottery.value.name,
                            "玩法" to LotteryPlayCatalog.summaryText(vm.currentLottery.value.type),
                            "状态" to (if (bot.enabled) "已开启" else "未开启"),
                            "来源" to "${bot.sourceType.ifBlank { "-" }} / ${bot.sourceId.ifBlank { "默认" }}",
                            "目标期" to vm.nextIssueText.value
                        )
                    )
                    CaptionMuted("当前彩种玩法：" + LotteryPlayCatalog.summaryText(vm.currentLottery.value.type))
                    Text("预测来源", fontWeight = FontWeight.SemiBold)
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(vertical = CaiTokens.S8),
                    horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)
                ) {
                    BetSourceType.entries.forEach { s ->
                        FilterChip(
                            selected = cfg.sourceType == s.id,
                            onClick = {
                                val defaultId = when (s) {
                                    BetSourceType.COCKPIT -> "cockpit"
                                    BetSourceType.ALGO -> "experience"
                                    BetSourceType.PLAN -> vm.planRows.value.firstOrNull()?.first?.planId
                                        ?: "S-FREQ-010"
                                    BetSourceType.NOVA -> LotteryPlanPools.defaultNovaId(vm.currentLottery.value.type)
                                    BetSourceType.AUTO_BEST -> "auto_best"
                                    BetSourceType.CONSENSUS -> "consensus"
                                    BetSourceType.NOVA_CONSENSUS -> "nova_consensus"
                                    BetSourceType.FAVORITE -> vm.favoritePlanIds(vm.currentLottery.value.key).firstOrNull()
                                        ?: "favorite"
                                }
                                vm.saveBotConfig(cfg.copy(sourceType = s.id, sourceId = defaultId))
                            },
                            label = { Text(s.label) }
                        )
                    }
                }

                // 具体来源项
                when (cfg.sourceType) {
                    "cockpit" -> {
                        Text("驾驶舱当前模型", fontWeight = FontWeight.SemiBold)
                        CaptionMuted("挂机直接使用驾驶舱当前预测；切换驾驶舱算法后，下一次预测自动跟随。")
                    }
                    "algo" -> {
                        Text("算法", fontWeight = FontWeight.SemiBold)
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()).padding(vertical = CaiTokens.S8),
                            horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)
                        ) {
                            AlgoMode.entries.forEach { a ->
                                FilterChip(
                                    selected = cfg.sourceId == a.id,
                                    onClick = { vm.saveBotConfig(cfg.copy(sourceId = a.id)) },
                                    label = { Text(a.label) }
                                )
                            }
                        }
                    }
                    "plan" -> {
                        Text("原计划模型（完整计划池）", fontWeight = FontWeight.SemiBold)
                        CaptionMuted("可分别指定大小/单双/组合计划；列表来自完整计划池，不依赖回测是否跑过。")
                        val allPlans = remember {
                            PlanPool.ALL.filter { !it.planId.startsWith("NOVA-") }
                        }
                        val dxPlans = remember(allPlans) { allPlans.filter { it.category == "大小" || it.playType == "大小" } }
                        val dsPlans = remember(allPlans) { allPlans.filter { it.category == "单双" || it.playType == "单双" } }
                        val comboPlans = remember(allPlans) { allPlans.filter { it.category == "组合" || it.playType == "组合" } }
                        fun planLabel(id: String) =
                            allPlans.firstOrNull { it.planId == id }?.let { "${it.planName}·${it.category}" } ?: id.ifBlank { "未选" }
                        Text("默认计划（回退）", fontWeight = FontWeight.SemiBold)
                        CaptionMuted("当前默认: ${planLabel(cfg.sourceId)}")
                        androidx.compose.foundation.lazy.LazyRow(
                            Modifier.padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(allPlans.size, key = { allPlans[it].planId }) { idx ->
                                val def = allPlans[idx]
                                FilterChip(
                                    selected = cfg.sourceId == def.planId,
                                    onClick = {
                                        vm.saveBotConfig(
                                            cfg.copy(
                                                sourceId = def.planId,
                                                sourceIdDx = if (cfg.sourceIdDx.isBlank()) def.planId else cfg.sourceIdDx,
                                                sourceIdDs = if (cfg.sourceIdDs.isBlank()) def.planId else cfg.sourceIdDs,
                                                sourceIdCombo = if (cfg.sourceIdCombo.isBlank()) def.planId else cfg.sourceIdCombo
                                            )
                                        )
                                    },
                                    label = { Text("${def.planName} · ${def.category}") }
                                )
                            }
                        }
                        Text("大小计划: ${planLabel(cfg.sourceIdDx.ifBlank { cfg.sourceId })}", fontWeight = FontWeight.SemiBold)
                        androidx.compose.foundation.lazy.LazyRow(
                            Modifier.padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(dxPlans.size, key = { "dx-" + dxPlans[it].planId }) { idx ->
                                val def = dxPlans[idx]
                                FilterChip(
                                    selected = (cfg.sourceIdDx.ifBlank { cfg.sourceId }) == def.planId,
                                    onClick = { vm.saveBotConfig(cfg.copy(sourceIdDx = def.planId)) },
                                    label = { Text(def.planName) }
                                )
                            }
                        }
                        Text("单双计划: ${planLabel(cfg.sourceIdDs.ifBlank { cfg.sourceId })}", fontWeight = FontWeight.SemiBold)
                        androidx.compose.foundation.lazy.LazyRow(
                            Modifier.padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(dsPlans.size, key = { "ds-" + dsPlans[it].planId }) { idx ->
                                val def = dsPlans[idx]
                                FilterChip(
                                    selected = (cfg.sourceIdDs.ifBlank { cfg.sourceId }) == def.planId,
                                    onClick = { vm.saveBotConfig(cfg.copy(sourceIdDs = def.planId)) },
                                    label = { Text(def.planName) }
                                )
                            }
                        }
                        Text("组合计划: ${planLabel(cfg.sourceIdCombo.ifBlank { cfg.sourceId })}", fontWeight = FontWeight.SemiBold)
                        androidx.compose.foundation.lazy.LazyRow(
                            Modifier.padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            val list = if (comboPlans.isNotEmpty()) comboPlans else allPlans
                            items(list.size, key = { "cb-" + list[it].planId }) { idx ->
                                val def = list[idx]
                                FilterChip(
                                    selected = (cfg.sourceIdCombo.ifBlank { cfg.sourceId }) == def.planId,
                                    onClick = { vm.saveBotConfig(cfg.copy(sourceIdCombo = def.planId)) },
                                    label = { Text(def.planName) }
                                )
                            }
                        }
                    }
                    "nova" -> {
                        Text("NovaPlan 新计划（按彩种隔离）", fontWeight = FontWeight.SemiBold)
                        CaptionMuted("当前彩种独立计划池；大小/单双/组合（或运动会球位/龙虎）可分别指定。")
                        val lot = vm.currentLottery.value.type
                        val allNova = LotteryPlanPools.novaPlansFor(lot)
                        val dxPlans = allNova.filter {
                            it.playType in listOf("大小", "球大小", "和值大小")
                        }
                        val dsPlans = allNova.filter {
                            it.playType in listOf("单双", "球单双", "三军", "鱼虾蟹")
                        }
                        val comboPlans = allNova.filter {
                            it.playType in listOf("组合", "龙虎", "长牌", "定位")
                        }
                        fun nLabel(id: String) =
                            LotteryPlanPools.find(id, lot)
                                ?.let { "${it.planName}·${it.playType}" } ?: id.ifBlank { "未选" }
                        Text("默认: ${nLabel(cfg.sourceId)}", fontWeight = FontWeight.SemiBold)
                        androidx.compose.foundation.lazy.LazyRow(
                            Modifier.padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(allNova.size, key = { allNova[it].planId }) { idx ->
                                val def = allNova[idx]
                                FilterChip(
                                    selected = cfg.sourceId == def.planId,
                                    onClick = {
                                        vm.saveBotConfig(
                                            cfg.copy(
                                                sourceId = def.planId,
                                                sourceIdDx = if (cfg.sourceIdDx.isBlank()) def.planId else cfg.sourceIdDx,
                                                sourceIdDs = if (cfg.sourceIdDs.isBlank()) def.planId else cfg.sourceIdDs,
                                                sourceIdCombo = if (cfg.sourceIdCombo.isBlank()) def.planId else cfg.sourceIdCombo
                                            )
                                        )
                                    },
                                    label = { Text("${def.planName} · ${def.playType}") }
                                )
                            }
                        }
                        Text("大小: ${nLabel(cfg.sourceIdDx.ifBlank { cfg.sourceId })}", fontWeight = FontWeight.SemiBold)
                        androidx.compose.foundation.lazy.LazyRow(
                            Modifier.padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(dxPlans.size, key = { "ndx-" + dxPlans[it].planId }) { idx ->
                                val def = dxPlans[idx]
                                FilterChip(
                                    selected = (cfg.sourceIdDx.ifBlank { cfg.sourceId }) == def.planId,
                                    onClick = { vm.saveBotConfig(cfg.copy(sourceIdDx = def.planId)) },
                                    label = { Text(def.planName) }
                                )
                            }
                        }
                        Text("单双: ${nLabel(cfg.sourceIdDs.ifBlank { cfg.sourceId })}", fontWeight = FontWeight.SemiBold)
                        androidx.compose.foundation.lazy.LazyRow(
                            Modifier.padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(dsPlans.size, key = { "nds-" + dsPlans[it].planId }) { idx ->
                                val def = dsPlans[idx]
                                FilterChip(
                                    selected = (cfg.sourceIdDs.ifBlank { cfg.sourceId }) == def.planId,
                                    onClick = { vm.saveBotConfig(cfg.copy(sourceIdDs = def.planId)) },
                                    label = { Text(def.planName) }
                                )
                            }
                        }
                        Text("组合: ${nLabel(cfg.sourceIdCombo.ifBlank { cfg.sourceId })}", fontWeight = FontWeight.SemiBold)
                        androidx.compose.foundation.lazy.LazyRow(
                            Modifier.padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(comboPlans.size, key = { "ncb-" + comboPlans[it].planId }) { idx ->
                                val def = comboPlans[idx]
                                FilterChip(
                                    selected = (cfg.sourceIdCombo.ifBlank { cfg.sourceId }) == def.planId,
                                    onClick = { vm.saveBotConfig(cfg.copy(sourceIdCombo = def.planId)) },
                                    label = { Text(def.planName) }
                                )
                            }
                        }
                    }
                    "favorite" -> {
                        Text("收藏计划挂机", fontWeight = FontWeight.SemiBold)
                        CaptionMuted("可分别指定大小/单双/组合收藏计划；默认滚动现算。")
                        val favIds = vm.favoritePlanIds(vm.currentLottery.value.key)
                        val lot = vm.currentLottery.value.type
                        val favPlans = favIds.mapNotNull { id ->
                            LotteryPlanPools.find(id, lot)
                                ?: vm.customPlans.value.firstOrNull { it.planId == id }?.toDefinition()
                                ?: vm.planRows.value.firstOrNull { it.first.planId == id }?.first
                                ?: vm.planVM.novaPlanRows.value.firstOrNull { it.first.planId == id }?.first
                        }
                        fun fLabel(id: String) = favPlans.firstOrNull { it.planId == id }?.let { "${it.planName}·${it.playType}" } ?: id.ifBlank { "未选" }
                        if (favPlans.isEmpty()) {
                            CaptionMuted("暂无收藏计划。请到「计划工作台」点 ☆ 收藏后再来选择。")
                        } else {
                            val dxFav = favPlans.filter { it.playType.contains("大小") || it.playType == "大小" }
                            val dsFav = favPlans.filter { it.playType.contains("单双") || it.playType == "单双" }
                            val comboFav = favPlans.filter { it.playType.contains("组合") || it.playType == "组合" || it.playType == "龙虎" }
                            Text("默认: ${fLabel(cfg.sourceId)}", fontWeight = FontWeight.SemiBold)
                            androidx.compose.foundation.lazy.LazyRow(
                                Modifier.padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                items(favPlans.size, key = { "fav-" + favPlans[it].planId }) { idx ->
                                    val def = favPlans[idx]
                                    FilterChip(
                                        selected = cfg.sourceId == def.planId,
                                        onClick = {
                                            vm.saveBotConfig(
                                                cfg.copy(
                                                    sourceId = def.planId,
                                                    rollingPredict = true
                                                )
                                            )
                                        },
                                        label = { Text("${def.planName} · ${def.playType}") }
                                    )
                                }
                            }
                            Text("大小: ${fLabel(cfg.sourceIdDx.ifBlank { cfg.sourceId })}", fontWeight = FontWeight.SemiBold)
                            androidx.compose.foundation.lazy.LazyRow(
                                Modifier.padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                val list = dxFav.ifEmpty { favPlans }
                                items(list.size, key = { "fdx-" + list[it].planId }) { idx ->
                                    val def = list[idx]
                                    FilterChip(
                                        selected = (cfg.sourceIdDx.ifBlank { cfg.sourceId }) == def.planId,
                                        onClick = { vm.saveBotConfig(cfg.copy(sourceIdDx = def.planId, rollingPredict = true)) },
                                        label = { Text(def.planName) }
                                    )
                                }
                            }
                            Text("单双: ${fLabel(cfg.sourceIdDs.ifBlank { cfg.sourceId })}", fontWeight = FontWeight.SemiBold)
                            androidx.compose.foundation.lazy.LazyRow(
                                Modifier.padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                val list = dsFav.ifEmpty { favPlans }
                                items(list.size, key = { "fds-" + list[it].planId }) { idx ->
                                    val def = list[idx]
                                    FilterChip(
                                        selected = (cfg.sourceIdDs.ifBlank { cfg.sourceId }) == def.planId,
                                        onClick = { vm.saveBotConfig(cfg.copy(sourceIdDs = def.planId, rollingPredict = true)) },
                                        label = { Text(def.planName) }
                                    )
                                }
                            }
                            Text("组合: ${fLabel(cfg.sourceIdCombo.ifBlank { cfg.sourceId })}", fontWeight = FontWeight.SemiBold)
                            androidx.compose.foundation.lazy.LazyRow(
                                Modifier.padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                val list = comboFav.ifEmpty { favPlans }
                                items(list.size, key = { "fco-" + list[it].planId }) { idx ->
                                    val def = list[idx]
                                    FilterChip(
                                        selected = (cfg.sourceIdCombo.ifBlank { cfg.sourceId }) == def.planId,
                                        onClick = { vm.saveBotConfig(cfg.copy(sourceIdCombo = def.planId, rollingPredict = true)) },
                                        label = { Text(def.planName) }
                                    )
                                }
                            }
                        }
                    }
                    "auto_best" -> {
                        Text("模型竞技场", fontWeight = FontWeight.SemiBold)
                        CaptionMuted("每次预测优先使用当前计划池中评分最高的未结算计划。")
                    }
                    "consensus" -> {
                        Text("共识预测（计划引擎）", fontWeight = FontWeight.SemiBold)
                        CaptionMuted(
                            "认计划页「共识预测」目标第 ${
                                vm.planVM.planTargetIssue.value.takeIf { it != "-" }
                                    ?: vm.nextIssueText.value
                            } 期 · ${LotteryBetRules.profileForKey(vm.currentLottery.value.key).ruleLabel}大小/单双/组合"
                        )
                    }
                    "nova_consensus" -> {
                        Text("新计划共识", fontWeight = FontWeight.SemiBold)
                        CaptionMuted(
                            "认新计划页独立共识 · 目标第 ${
                                vm.planVM.planTargetIssue.value.takeIf { it != "-" }
                                    ?: vm.nextIssueText.value
                            } 期 · 与计划引擎共识数据分离，互不覆盖"
                        )
                        val novaCons = vm.planVM.novaConsensus.value.filter {
                            it.targetIssue == (vm.planVM.planTargetIssue.value.takeIf { t -> t != "-" }
                                ?: vm.nextIssueText.value)
                        }
                        if (novaCons.isEmpty()) {
                            CaptionMuted("暂无新计划共识，请到「新计划」页打开共识预测并刷新")
                        } else {
                            novaCons.take(6).forEach { c ->
                                Text(
                                    "${c.category} → ${c.leadingDirection}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }

                Spacer(Modifier.height(CaiTokens.S12))

                // 分类多选(共识时数字分类对应「位置共识」下注,可选)
                Text("下注分类", fontWeight = FontWeight.SemiBold)
                val betProfile = LotteryBetRules.profileForKey(vm.currentLottery.value.key)
                CaptionMuted("${betProfile.ruleLabel}口径 · ${betProfile.dxThresholdText}")
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(vertical = CaiTokens.S8),
                    horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)
                ) {
                    BetCategory.entries.forEach { c ->
                        val label = when (c) {
                            BetCategory.DX -> betProfile.dxLabel
                            BetCategory.DS -> betProfile.dsLabel
                            BetCategory.COMBO -> betProfile.comboLabel
                            BetCategory.NUMBER -> c.label
                        }
                        FilterChip(
                            selected = cfg.categories.contains(c.id),
                            onClick = {
                                val next = if (cfg.categories.contains(c.id)) cfg.categories - c.id
                                else cfg.categories + c.id
                                vm.saveBotConfig(cfg.copy(categories = next))
                            },
                            label = { Text(label) }
                        )
                    }
                }
                if (isConsensus) {
                    CaptionMuted("共识包含 位置-冠军/亚军/第3 预测,勾选「数字」后会自动下对应位置号码")
                }

                // 数字位置选择(PKS + 数字分类 + 非共识 时才显示)
                if (cfg.categories.contains(BetCategory.NUMBER.id) && isPks && !isConsensus) {
                    Spacer(Modifier.height(CaiTokens.S12))
                    Text("数字位置", fontWeight = FontWeight.SemiBold)
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()).padding(vertical = CaiTokens.S8),
                        horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)
                    ) {
                        (0 until 10).forEach { i ->
                            FilterChip(
                                selected = cfg.numberPosition == i,
                                onClick = { vm.saveBotConfig(cfg.copy(numberPosition = i)) },
                                label = { Text(PksPositions.nameAt(i)) }
                            )
                        }
                    }
                }

                Spacer(Modifier.height(CaiTokens.S12))

                // 单注金额
                Text("单注金额", fontWeight = FontWeight.SemiBold)
                Row(
                    Modifier.padding(vertical = CaiTokens.S8),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = amountText,
                        onValueChange = { amountText = it.filter { c -> c.isDigit() } },
                        label = { Text("每注金额") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    Spacer(Modifier.width(CaiTokens.S8))
                    PrimaryButton("保存", onClick = {
                        val v = amountText.toDoubleOrNull() ?: 0.0
                        if (v > 0) vm.saveBotConfig(cfg.copy(amount = v))
                    }, ghost = true)
                }

                Spacer(Modifier.height(CaiTokens.S8))

                Text("投注方向", fontWeight = FontWeight.SemiBold)
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(vertical = CaiTokens.S4),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = cfg.betMode != "reverse",
                        onClick = { vm.saveBotConfig(cfg.copy(betMode = "forward")) },
                        label = { Text("正投") }
                    )
                    FilterChip(
                        selected = cfg.betMode == "reverse",
                        onClick = { vm.saveBotConfig(cfg.copy(betMode = "reverse")) },
                        label = { Text("反投") }
                    )
                }
                CaptionMuted(
                    if (cfg.betMode == "reverse")
                        "反投：大小/单双/组合取反下单（大↔小、单↔双、大单↔小双）；数字不取反"
                    else
                        "正投：按预测原文下单"
                )

                Spacer(Modifier.height(CaiTokens.S8))

                // 滚动预测（指定计划 / 新计划）：与图表回测同款现算
                if (cfg.sourceType == "plan" || cfg.sourceType == "nova" || cfg.sourceType == "favorite") {
                    Text("滚动预测（图表同款）", fontWeight = FontWeight.SemiBold)
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = CaiTokens.S4),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            if (cfg.rollingPredict) "已开启 · 现算下注" else "关闭 · 用原计划预测",
                            modifier = Modifier.weight(1f)
                        )
                        Switch(
                            checked = cfg.rollingPredict,
                            onCheckedChange = { on ->
                                vm.saveBotConfig(cfg.copy(rollingPredict = on))
                            }
                        )
                    }
                    if (cfg.rollingPredict) {
                        CaptionMuted("开启后不用引擎缓存结果，按图表同一套逻辑在最新历史上现算（可配合正/反投）。")
                        Text("滚动口径", fontWeight = FontWeight.SemiBold)
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()).padding(vertical = CaiTokens.S4),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(1 to "一期", 2 to "二期", 3 to "三期").forEach { (st, lab) ->
                                FilterChip(
                                    selected = cfg.rollingStage == st,
                                    onClick = { vm.saveBotConfig(cfg.copy(rollingStage = st)) },
                                    label = { Text(lab) }
                                )
                            }
                        }
                        CaptionMuted(
                            when (cfg.rollingStage) {
                                2 -> "二期：与图表一致，轮内未中默认按 2 倍递进（挂机金额仍受倍投设置约束）"
                                3 -> "三期：与图表一致，轮内未中默认按 2 倍递进（-1→-2→-4）"
                                else -> "一期：每期一注，与图表一期滚动一致"
                            }
                        )
                    } else {
                        CaptionMuted("关闭时仍使用该计划在引擎中的原预测结果下注。")
                    }
                    Spacer(Modifier.height(CaiTokens.S8))
                }

                // 启停开关
                Row(
                    Modifier.fillMaxWidth().padding(vertical = CaiTokens.S4),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        if (cfg.enabled) "挂机运行中" else "挂机已暂停",
                        fontWeight = FontWeight.Bold,
                        color = if (cfg.enabled) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f)
                    )
                    Switch(
                        checked = cfg.enabled,
                        onCheckedChange = { vm.saveBotConfig(cfg.copy(enabled = it)) }
                    )
                }
                CaptionMuted("开启后每期开奖自动结算并按下期预测自动下注")
                Spacer(Modifier.height(CaiTokens.S8))
                PrimaryButton(
                    "立即尝试挂机下单",
                    onClick = { vm.tryPlaceBotNow() },
                    modifier = Modifier.fillMaxWidth()
                )
                CaptionMuted("不换期也能试下单;失败原因见状态栏与设置-运行日志问题编号")
            }
        }

        // ---- 倍投设置区 ----
        item {
            SectionTitle("倍投设置")
            GlobalCard {
                Row(
                    Modifier.fillMaxWidth().padding(vertical = CaiTokens.S4),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("对了倍投", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Switch(
                        checked = cfg.winMult > 1.0,
                        onCheckedChange = { on ->
                            val mult = if (on) (winMultText.toDoubleOrNull() ?: 1.5).coerceIn(1.1, 10.0) else 1.0
                            vm.saveBotConfig(cfg.copy(winMult = mult))
                        }
                    )
                    if (cfg.winMult > 1.0) {
                        Spacer(Modifier.width(CaiTokens.S8))
                        OutlinedTextField(
                            value = winMultText,
                            onValueChange = { winMultText = it.filter { c -> c.isDigit() || c == '.' } },
                            label = { Text("系数") },
                            modifier = Modifier.width(72.dp),
                            singleLine = true
                        )
                        Spacer(Modifier.width(CaiTokens.S4))
                        CaptionMuted("倍")
                        Spacer(Modifier.width(CaiTokens.S4))
                        // 输入框无保存入口,离开页面后本地状态丢失会回退 DB 旧值,
                        // 与期数/上限一致提供「应用」按钮持久化系数
                        PrimaryButton("应用", onClick = {
                            val v = winMultText.toDoubleOrNull() ?: 1.0
                            vm.saveBotConfig(cfg.copy(winMult = v.coerceIn(1.0, 10.0)))
                        }, ghost = true)
                    }
                }
                Row(
                    Modifier.fillMaxWidth().padding(vertical = CaiTokens.S4),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("对了倍投期数", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    OutlinedTextField(
                        value = winPeriodsText,
                        onValueChange = { winPeriodsText = it.filter(Char::isDigit) },
                        label = { Text("期数") },
                        modifier = Modifier.width(72.dp),
                        singleLine = true
                    )
                    Spacer(Modifier.width(CaiTokens.S4))
                    PrimaryButton("应用", onClick = {
                        val v = winPeriodsText.toIntOrNull() ?: 1
                        vm.saveBotConfig(cfg.copy(winMultPeriods = v.coerceIn(1, 20)))
                    }, ghost = true)
                }

                Row(
                    Modifier.fillMaxWidth().padding(vertical = CaiTokens.S4),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("错了倍投", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Switch(
                        checked = cfg.lossMult > 1.0,
                        onCheckedChange = { on ->
                            val mult = if (on) (lossMultText.toDoubleOrNull() ?: 1.5).coerceIn(1.1, 10.0) else 1.0
                            vm.saveBotConfig(cfg.copy(lossMult = mult))
                        }
                    )
                    if (cfg.lossMult > 1.0) {
                        Spacer(Modifier.width(CaiTokens.S8))
                        OutlinedTextField(
                            value = lossMultText,
                            onValueChange = { lossMultText = it.filter { c -> c.isDigit() || c == '.' } },
                            label = { Text("系数") },
                            modifier = Modifier.width(72.dp),
                            singleLine = true
                        )
                        Spacer(Modifier.width(CaiTokens.S4))
                        CaptionMuted("倍")
                        Spacer(Modifier.width(CaiTokens.S4))
                        PrimaryButton("应用", onClick = {
                            val v = lossMultText.toDoubleOrNull() ?: 1.0
                            vm.saveBotConfig(cfg.copy(lossMult = v.coerceIn(1.0, 10.0)))
                        }, ghost = true)
                    }
                }
                Row(
                    Modifier.fillMaxWidth().padding(vertical = CaiTokens.S4),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("错了倍投期数", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    OutlinedTextField(
                        value = lossPeriodsText,
                        onValueChange = { lossPeriodsText = it.filter(Char::isDigit) },
                        label = { Text("期数") },
                        modifier = Modifier.width(72.dp),
                        singleLine = true
                    )
                    Spacer(Modifier.width(CaiTokens.S4))
                    PrimaryButton("应用", onClick = {
                        val v = lossPeriodsText.toIntOrNull() ?: 1
                        vm.saveBotConfig(cfg.copy(lossMultPeriods = v.coerceIn(1, 20)))
                    }, ghost = true)
                }

                Row(
                    Modifier.fillMaxWidth().padding(vertical = CaiTokens.S4),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("最大倍数上限", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    OutlinedTextField(
                        value = maxMultText,
                        onValueChange = { maxMultText = it.filter { c -> c.isDigit() } },
                        label = { Text("上限") },
                        modifier = Modifier.width(72.dp),
                        singleLine = true
                    )
                    Spacer(Modifier.width(CaiTokens.S4))
                    PrimaryButton("应用", onClick = {
                        val v = maxMultText.toIntOrNull() ?: 1
                        vm.saveBotConfig(cfg.copy(maxMult = v.coerceIn(1, 20)))
                    }, ghost = true)
                }
                CaptionMuted("对/错倍投分别设置系数和持续期数;超过设定期数后恢复基础注额。")
            }
        }

        // ---- 对错统计区 ----
        item {
            SectionTitle("挂机对错统计")
            GlobalCard {
                val catStats = stats.byCategory
                if (catStats.isEmpty() || catStats.values.all { it.settled == 0 }) {
                    Text("暂无已结算数据", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    catStats.values.filter { it.settled > 0 }.forEach { cs ->
                        CatStatsRow(cs)
                        Spacer(Modifier.height(CaiTokens.S8))
                    }
                }
            }
        }

        // ---- 记录区 ----
        item {
            SectionTitle("下注记录")
            GlobalCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    CaptionMuted("共 ${bets.size} 注")
                    PrimaryButton("清空记录", onClick = { vm.clearBetHistory() }, ghost = true)
                }
            }
        }

        if (bets.isEmpty()) {
            item { GlobalCard { Text("暂无下注记录,开启挂机后自动生成。") } }
        } else {
            items(bets.take(80), key = { it.id }) { b ->
                BetRow(b)
            }
        }

        item { Spacer(Modifier.height(CaiTokens.S24)) }
    }
}

@Composable
private fun StatMini(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        CaptionMuted(label)
    }
}

@Composable
private fun CatStatsRow(cs: CatBetStats) {
    val rateColor = when {
        cs.recentStreak > 0 -> Color(0xFF2E7D32)
        cs.recentStreak < 0 -> Color(0xFFC62828)
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(cs.catName, fontWeight = FontWeight.Bold)
            Text(
                if (cs.recentStreak >= 0) "连对 ${cs.recentStreak}" else "连错 ${-cs.recentStreak}",
                fontWeight = FontWeight.Bold,
                color = rateColor
            )
        }
        Spacer(Modifier.height(CaiTokens.S4))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("中 ${cs.hit} / 未中 ${cs.miss}", fontSize = 13.sp)
            Text("对错率 ${cs.hitRateStr}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
        }
        Spacer(Modifier.height(CaiTokens.S4))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("累计盈亏", fontSize = 13.sp)
            Text(
                if (cs.profit >= 0) "+${cs.profit.roundToInt()}" else "${cs.profit.roundToInt()}",
                fontWeight = FontWeight.Bold,
                color = if (cs.profit >= 0) Color(0xFF2E7D32) else Color(0xFFC62828)
            )
        }
        LinearProgressIndicator(
            progress = { cs.winRate.toFloat().coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
            color = MaterialTheme.colorScheme.secondary
        )
        CaptionMuted("最长连对 ${cs.maxHitStreak} · 最长连错 ${cs.maxMissStreak}")
        CatWindowRate("两期", cs.twoWindows, cs.twoHitRate, cs.twoMissRate)
        CatWindowRate("三期", cs.threeWindows, cs.threeHitRate, cs.threeMissRate)
    }
}

/** 分类窗口对错率展示(与共识口径一致:窗口内至少 1 次中 = 对窗口) */
@Composable
private fun CatWindowRate(title: String, windows: Int, hitRate: Double, missRate: Double) {
    Column(Modifier.padding(top = CaiTokens.S4)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text(
                if (windows > 0) "对 ${(hitRate * 100).roundToInt()}% · 错 ${(missRate * 100).roundToInt()}%(${windows} 窗口)"
                else "-",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (windows > 0) {
            Spacer(Modifier.height(2.dp))
            LinearProgressIndicator(
                progress = { hitRate.toFloat().coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                color = Color(0xFF2E7D32)
            )
        }
    }
}

@Composable
private fun BetRow(b: com.caifenxi.app.domain.model.BetView) {
    val statusColor = when (b.status) {
        "中" -> Color(0xFF2E7D32)
        "未中" -> Color(0xFFC62828)
        else -> Color(0xFFF9A825)
    }
    GlobalCard {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text("第 ${b.issue} 期 · ${b.category}", fontWeight = FontWeight.Bold)
                Text("押「${b.betValue}」 · ${b.sourceLabel}", fontSize = 13.sp)
                CaptionMuted(
                    "本金 ${b.amount.toInt()} · 赔率 ${b.odds}" +
                        if (b.status == "待开") " · 待开" else ""
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(b.status, fontWeight = FontWeight.Bold, color = statusColor)
                Text(
                    when {
                        b.status == "待开" -> "-"
                        b.profit >= 0 -> "+${b.profit.roundToInt()}"
                        else -> "${b.profit.roundToInt()}"
                    },
                    fontWeight = FontWeight.Bold,
                    color = if (b.profit >= 0) Color(0xFF2E7D32) else Color(0xFFC62828)
                )
            }
        }
    }
}

/**
 * 收益曲线图(Compose Canvas 自绘)。
 * 性能要点：
 * - Canvas 只按 1x 绘制一次路径，缩放/平移走 graphicsLayer（GPU，不每帧重建 Path）
 * - 点数过多时降采样，避免主线程绘制过重
 * - 单指在 1x 时不抢列表滚动；双指缩放，放大后可单指拖动
 */
@Composable
private fun ProfitCurveChart(
    points: List<ProfitPoint>,
    maxDrawdown: Double
) {
    val green = Color(0xFF2E7D32)
    val red = Color(0xFFC62828)
    val amber = Color(0xFFF9A825)
    val chartHeight = 180.dp
    val secondaryColor = MaterialTheme.colorScheme.secondary

    // 降采样：最多约 180 点，保留首尾
    val drawPoints = remember(points) { downsampleProfitPoints(points, maxPoints = 180) }
    val (hitStart, hitEnd) = remember(drawPoints) { findLongestStreak(drawPoints, hit = true) }
    val (missStart, missEnd) = remember(drawPoints) { findLongestStreak(drawPoints, hit = false) }
    val (ddPeakIdx, ddTroughIdx) = remember(drawPoints) { findMaxDrawdownIdx(drawPoints) }

    var scale by remember(drawPoints.size) { mutableFloatStateOf(1f) }
    var offsetX by remember(drawPoints.size) { mutableFloatStateOf(0f) }
    var offsetY by remember(drawPoints.size) { mutableFloatStateOf(0f) }

    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            CaptionMuted(
                if (scale <= 1.01f) "双指缩放查看细节 · 当前 1x"
                else "拖动平移 · 当前 ${"%.1f".format(scale)}x"
            )
            if (scale > 1.01f || abs(offsetX) > 1f || abs(offsetY) > 1f) {
                TextButton(onClick = {
                    scale = 1f
                    offsetX = 0f
                    offsetY = 0f
                }) { Text("复位") }
            }
        }
        Box(
            Modifier
                .fillMaxWidth()
                .height(chartHeight)
                .clip(RoundedCornerShape(8.dp))
                .pointerInput(drawPoints.size) {
                    awaitEachGesture {
                        // 不主动 awaitFirstDown consume，避免 1x 单指抢 LazyColumn 滚动
                        try {
                            do {
                                val event = awaitPointerEvent()
                                val pressed = event.changes.fastAny { it.pressed }
                                if (!pressed) break
                                if (size.width <= 0 || size.height <= 0) continue
                                val zoom = event.calculateZoom()
                                val pan = event.calculatePan()
                                val multi = event.changes.count { it.pressed } >= 2
                                val zooming = abs(zoom - 1f) > 0.01f
                                val shouldHandle = multi || zooming || scale > 1.01f
                                if (shouldHandle) {
                                    val newScale = (scale * zoom).coerceIn(1f, 6f)
                                    val scaleRatio = if (scale > 0f) newScale / scale else 1f
                                    scale = newScale
                                    if (newScale <= 1.01f) {
                                        scale = 1f
                                        offsetX = 0f
                                        offsetY = 0f
                                    } else {
                                        val maxPanX = size.width * (newScale - 1f)
                                        val maxPanY = size.height * (newScale - 1f) * 0.4f
                                        offsetX = (offsetX * scaleRatio + pan.x).coerceIn(-maxPanX, maxPanX)
                                        offsetY = (offsetY * scaleRatio + pan.y).coerceIn(-maxPanY, maxPanY)
                                    }
                                    event.changes.fastForEach {
                                        if (it.positionChanged()) it.consume()
                                    }
                                }
                            } while (true)
                        } catch (_: Exception) {
                            // 手势取消/布局变化时忽略，避免滑动闪退
                        }
                    }
                }
        ) {
            // 缩放/平移只改 layer，不触发 Canvas 重绘路径
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        translationX = offsetX
                        translationY = offsetY
                    }
            ) {
                if (drawPoints.isEmpty()) return@Canvas
                val w = size.width
                val h = size.height
                val padL = 8f
                val padR = 8f
                val padT = 10f
                val padB = 14f
                val chartW = w - padL - padR
                val chartH = h - padT - padB

                val profits = drawPoints.map { it.cumulativeProfit }
                val minP = profits.minOrNull() ?: 0.0
                val maxP = profits.maxOrNull() ?: 0.0
                val lo = minOf(0.0, minP)
                val hi = maxOf(0.0, maxP)
                val span = (hi - lo).coerceAtLeast(1.0)
                val yRange = span * 1.15
                val yBase = (padT + chartH * (hi / yRange)).toFloat()

                fun xOf(i: Int): Float {
                    val n = drawPoints.size
                    return if (n <= 1) padL + chartW / 2f else padL + chartW * i / (n - 1)
                }

                fun yOf(v: Double): Float {
                    val t = ((hi - v) / yRange).toFloat().coerceIn(0f, 1f)
                    return padT + chartH * t
                }

                if (hitStart in 0..hitEnd && hitEnd in drawPoints.indices) {
                    val x1 = xOf(hitStart)
                    val x2 = if (hitEnd + 1 < drawPoints.size) xOf(hitEnd + 1) else xOf(drawPoints.lastIndex) + 1
                    drawRect(
                        color = green.copy(alpha = 0.10f),
                        topLeft = Offset(x1, yBase),
                        size = androidx.compose.ui.geometry.Size(
                            (x2 - x1).coerceAtLeast(1f),
                            (h - yBase).coerceAtLeast(0f)
                        )
                    )
                }
                if (missStart in 0..missEnd && missEnd in drawPoints.indices) {
                    val x1 = xOf(missStart)
                    val x2 = if (missEnd + 1 < drawPoints.size) xOf(missEnd + 1) else xOf(drawPoints.lastIndex) + 1
                    drawRect(
                        color = red.copy(alpha = 0.10f),
                        topLeft = Offset(x1, yBase),
                        size = androidx.compose.ui.geometry.Size(
                            (x2 - x1).coerceAtLeast(1f),
                            (h - yBase).coerceAtLeast(0f)
                        )
                    )
                }

                drawLine(
                    color = Color(0xFF999999),
                    start = Offset(padL, yBase),
                    end = Offset(w - padR, yBase),
                    strokeWidth = 1.5f,
                    pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(8f, 6f))
                )

                val linePath = Path()
                drawPoints.forEachIndexed { i, p ->
                    val x = xOf(i)
                    val y = yOf(p.cumulativeProfit)
                    if (i == 0) linePath.moveTo(x, y) else linePath.lineTo(x, y)
                }
                drawPath(linePath, color = secondaryColor, style = Stroke(width = 3.5f, cap = StrokeCap.Round))

                if (drawPoints.size > 1) {
                    val fillPath = Path()
                    fillPath.moveTo(xOf(0), yBase)
                    drawPoints.forEachIndexed { i, p ->
                        fillPath.lineTo(xOf(i), yOf(p.cumulativeProfit))
                    }
                    fillPath.lineTo(xOf(drawPoints.lastIndex), yBase)
                    fillPath.close()
                    val fillColor =
                        if (drawPoints.last().cumulativeProfit >= 0) green.copy(alpha = 0.08f)
                        else red.copy(alpha = 0.08f)
                    drawPath(fillPath, color = fillColor)
                }

                // 点过多时不画圆点，只保留关键峰谷
                val drawDots = drawPoints.size <= 80
                if (drawDots) {
                    drawPoints.forEachIndexed { i, p ->
                        val c = if (p.hit) green else red
                        drawCircle(color = c, radius = 2.5f, center = Offset(xOf(i), yOf(p.cumulativeProfit)))
                    }
                }

                if (ddPeakIdx >= 0 && ddTroughIdx >= 0 && ddPeakIdx != ddTroughIdx && maxDrawdown > 0 &&
                    ddPeakIdx in drawPoints.indices && ddTroughIdx in drawPoints.indices
                ) {
                    val px = xOf(ddPeakIdx)
                    val py = yOf(drawPoints[ddPeakIdx].cumulativeProfit)
                    val tx = xOf(ddTroughIdx)
                    val ty = yOf(drawPoints[ddTroughIdx].cumulativeProfit)
                    drawLine(
                        color = amber,
                        start = Offset(px, py),
                        end = Offset(tx, ty),
                        strokeWidth = 2f,
                        pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
                    )
                    drawCircle(color = amber, radius = 4f, center = Offset(px, py), style = Stroke(width = 2f))
                    drawCircle(color = amber, radius = 4f, center = Offset(tx, ty))
                }
            }
        }
    }
}

/** 均匀降采样，始终保留首尾点 */
private fun downsampleProfitPoints(points: List<ProfitPoint>, maxPoints: Int): List<ProfitPoint> {
    if (points.size <= maxPoints) return points
    if (maxPoints < 3) return listOf(points.first(), points.last())
    val out = ArrayList<ProfitPoint>(maxPoints)
    val last = points.size - 1
    val step = last.toFloat() / (maxPoints - 1)
    var prev = -1
    for (i in 0 until maxPoints) {
        val idx = (i * step).toInt().coerceIn(0, last)
        if (idx != prev) {
            out.add(points[idx])
            prev = idx
        }
    }
    if (out.lastOrNull() != points.last()) out.add(points.last())
    return out
}

/** 找到最长连对/连错的起止索引区间 */
private fun findLongestStreak(points: List<ProfitPoint>, hit: Boolean): Pair<Int, Int> {
    var bestStart = -1
    var bestEnd = -1
    var bestLen = 0
    var curStart = -1
    var curLen = 0
    points.forEachIndexed { i, p ->
        if (p.hit == hit) {
            if (curStart < 0) curStart = i
            curLen++
            if (curLen > bestLen) {
                bestLen = curLen
                bestStart = curStart
                bestEnd = i
            }
        } else {
            curStart = -1
            curLen = 0
        }
    }
    return bestStart to bestEnd
}

/** 找到最大回撤对应的峰值索引与谷底索引(峰值在前,谷底在后) */
private fun findMaxDrawdownIdx(points: List<ProfitPoint>): Pair<Int, Int> {
    var peakIdx = 0
    var peakVal = points.firstOrNull()?.cumulativeProfit ?: 0.0
    var bestPeak = -1
    var bestTrough = -1
    var bestDD = 0.0
    points.forEachIndexed { i, p ->
        if (p.cumulativeProfit > peakVal) {
            peakVal = p.cumulativeProfit
            peakIdx = i
        }
        val dd = peakVal - p.cumulativeProfit
        if (dd > bestDD) {
            bestDD = dd
            bestPeak = peakIdx
            bestTrough = i
        }
    }
    return bestPeak to bestTrough
}
