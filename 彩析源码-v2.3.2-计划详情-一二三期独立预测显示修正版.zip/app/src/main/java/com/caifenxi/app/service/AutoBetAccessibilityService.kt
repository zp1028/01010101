package com.caifenxi.app.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import com.caifenxi.app.CaiFenXiApplication
import com.caifenxi.app.domain.model.AutoClickPostAction
import com.caifenxi.app.domain.model.AutoClickPostActionsCodec
import com.caifenxi.app.util.AndroidCompat
import com.caifenxi.app.util.RuntimeLog
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * 无障碍自动点击服务：根据彩分析内部预测，在第三方页面点击「大/小/单/双」。
 *
 * 关键能力：
 * 1. canPerformGestures：支持 WebView / 不响应 ACTION_CLICK 的控件
 * 2. 多窗口扫描：不只看 rootInActiveWindow
 * 3. 跳过本应用窗口，避免点到彩析自己的界面
 * 4. 精确文字 / contentDescription / 递归子节点匹配
 * 5. 若当前仍在本应用，挂起任务，等切到第三方页面再执行
 */
class AutoBetAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AutoBetAccessibilityService? = null

        fun isRunning(): Boolean = instance != null
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    /** 含 Thread.sleep 的点击流水线必须在后台线程，否则主线程会卡顿/ANR */
    private val worker = Executors.newSingleThreadExecutor()
    private val pipelineRunning = AtomicBoolean(false)

    @Volatile private var lastActionFingerprint: String = ""
    @Volatile private var lastActionAt: Long = 0L
    private val actionCooldownMs = 2_000L

    /** 等待用户切到第三方页面时的挂起任务。
     * 注意：这些字段被 worker 线程(performBet/executePendingIfPossible)写入，
     * 又被无障碍回调主线程(onAccessibilityEvent)读取，必须保证跨线程可见性，
     * 否则主线程可能读到陈旧 null 而提前 return，导致挂起任务丢失或重复执行。 */
    @Volatile private var pendingDx: String? = null
    @Volatile private var pendingDs: String? = null
    @Volatile private var pendingAmount: String? = null
    @Volatile private var pendingCombo: String? = null
    @Volatile private var pendingPredNumbers: List<String> = emptyList()
    @Volatile private var pendingDelayMs: Long = 350L
    @Volatile private var pendingUntil: Long = 0L
    @Volatile private var pendingIssue: String? = null
    @Volatile private var pendingLotteryKey: String? = null
    private val pendingMaxWaitMs = 45_000L

    private val supportsGestureTap: Boolean
        get() = AndroidCompat.supportsAccessibilityGesture()

    /**
     * 临时区域覆盖：点数字键盘时优先用「输入区域」，避免受大小单双点击区域限制。
     * null 表示回落到 [activeClickRegionPx]。
     */
    @Volatile
    private var regionOverridePx: Rect? = null

    /** 当前点击区域（屏幕像素），null 表示不限制 */
    private fun activeClickRegionPx(): Rect? {
        regionOverridePx?.let { return it }
        return try {
            val prefs = CaiFenXiApplication.instance.configStore.loadPrefs()
            if (!prefs.autoClickRegionEnabled) return null
            normalizedToPx(
                prefs.autoClickRegionLeft,
                prefs.autoClickRegionTop,
                prefs.autoClickRegionRight,
                prefs.autoClickRegionBottom
            )
        } catch (_: Exception) {
            null
        }
    }

    /** 数字键盘/输入区域（屏幕像素），null 表示未框选 */
    private fun activeInputRegionPx(): Rect? {
        return try {
            val prefs = CaiFenXiApplication.instance.configStore.loadPrefs()
            if (!prefs.autoInputRegionEnabled) return null
            normalizedToPx(
                prefs.autoInputRegionLeft,
                prefs.autoInputRegionTop,
                prefs.autoInputRegionRight,
                prefs.autoInputRegionBottom
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun normalizedToPx(lN: Float, tN: Float, rN: Float, bN: Float): Rect? {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val l = (lN.coerceIn(0f, 1f) * w).toInt()
        val top = (tN.coerceIn(0f, 1f) * h).toInt()
        val r = (rN.coerceIn(0f, 1f) * w).toInt()
        val b = (bN.coerceIn(0f, 1f) * h).toInt()
        // 允许较小框选（数字键区域可能很紧凑），最低约 8px
        if (r - l < 8 || b - top < 8) return null
        return Rect(l, top, r, b)
    }

    private fun centerInsideRegion(rect: Rect, region: Rect?): Boolean {
        if (region == null) return true
        val cx = rect.centerX()
        val cy = rect.centerY()
        return region.contains(cx, cy)
    }

    private fun showClickFeedback(x: Float, y: Float, label: String) {
        try {
            val prefs = CaiFenXiApplication.instance.configStore.loadPrefs()
            if (!prefs.autoClickShowFeedback) return
            ClickFeedbackOverlay.show(this, x, y, label, fromA11y = true)
        } catch (_: Exception) {
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        // 运行时再补一次能力（兼容部分 ROM 对 XML 解析不完整）
        serviceInfo = serviceInfo?.apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                // FLAG 已在 xml 中声明；这里确保 eventTypes 覆盖窗口切换
                eventTypes = eventTypes or
                    AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                    AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                    AccessibilityEvent.TYPE_WINDOWS_CHANGED
            }
        }
        RuntimeLog.info("AutoBet", "无障碍服务已连接 package=$packageName")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (pendingDx == null && pendingDs == null) return
        if (System.currentTimeMillis() > pendingUntil) {
            clearPending("等待超时，取消挂起点击", reportFailure = true)
            return
        }
        val type = event.eventType
        if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            type == AccessibilityEvent.TYPE_WINDOWS_CHANGED ||
            type == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        ) {
            val pkg = event.packageName?.toString().orEmpty()
            if (pkg.isNotBlank() && pkg != packageName) {
                RuntimeLog.info("AutoBet", "检测到第三方窗口 pkg=$pkg，尝试执行挂起点击")
                mainHandler.post { executePendingIfPossible() }
            }
        }
    }

    override fun onInterrupt() {
        RuntimeLog.warn("AutoBet", "无障碍服务被中断")
    }

    override fun onDestroy() {
        instance = null
        clearPending("无障碍服务销毁", reportFailure = true)
        try { worker.shutdownNow() } catch (e: Exception) {
            RuntimeLog.warn("AutoBet", "worker shutdown: ${e.message}")
        }
        RuntimeLog.info("AutoBet", "无障碍服务已销毁")
        super.onDestroy()
    }

    /**
     * 根据预测执行点击。
     * 若当前前台是本应用，则挂起最多 [pendingMaxWaitMs]，等用户切到第三方页面再点。
     * 仅在流水线成功后回调 [AutoBetController.notifyBetSucceeded] 写入期号去重。
     *
     * @param amountText 若非空且开启自动点击数字，则在点击大小单双后，于数字键盘区域内逐位点击金额
     * @param targetIssue 目标期号；成功后写入去重
     * @param lotteryKey 彩种；与期号一起用于成功/失败回调
     */
    fun performBet(
        dx: String?,
        ds: String?,
        clickDelayMs: Long = 350L,
        amountText: String? = null,
        targetIssue: String? = null,
        lotteryKey: String? = null,
        combo: String? = null,
        predNumbers: List<String> = emptyList()
    ) {
        val fingerprint =
            "${dx.orEmpty()}|${ds.orEmpty()}|${amountText.orEmpty()}|${combo.orEmpty()}|${predNumbers.joinToString(",")}|${targetIssue.orEmpty()}"
        val now = System.currentTimeMillis()
        if (fingerprint.isBlank() || fingerprint == "|||||" ||
            (fingerprint == lastActionFingerprint && now - lastActionAt < actionCooldownMs)
        ) {
            RuntimeLog.info("AutoBet", "重复触发保护：跳过 $fingerprint")
            return
        }

        worker.execute {
            if (!pipelineRunning.compareAndSet(false, true)) {
                RuntimeLog.info("AutoBet", "流水线忙碌，改为挂起")
                stashPending(dx, ds, amountText, combo, predNumbers, clickDelayMs, targetIssue, lotteryKey)
                return@execute
            }
            try {
                val activePkg = activeWindowPackage()
                RuntimeLog.info(
                    "AutoBet",
                    "performBet 当前前台=$activePkg dx=$dx ds=$ds amount=${amountText ?: "-"} combo=${combo ?: "-"} nums=$predNumbers issue=${targetIssue ?: "-"}"
                )
                if (activePkg.isNullOrBlank() || activePkg == packageName) {
                    stashPending(dx, ds, amountText, combo, predNumbers, clickDelayMs, targetIssue, lotteryKey)
                    RuntimeLog.warn(
                        "AutoBet",
                        "当前仍在本应用($activePkg)，已挂起，请在 ${pendingMaxWaitMs / 1000}s 内切换到第三方投注页"
                    )
                    return@execute
                }
                val ok = doExecutePipeline(dx, ds, clickDelayMs, amountText, combo, predNumbers)
                if (ok) {
                    lastActionFingerprint = fingerprint
                    lastActionAt = System.currentTimeMillis()
                    reportSuccessToController(targetIssue, lotteryKey)
                    clearPending(null, reportFailure = false)
                } else {
                    stashPending(dx, ds, amountText, combo, predNumbers, clickDelayMs, targetIssue, lotteryKey)
                    RuntimeLog.warn("AutoBet", "本次执行未完成，已挂起等待页面内容出现")
                }
            } catch (e: Exception) {
                RuntimeLog.warn("AutoBet", "performBet 异常: ${e.message}")
                stashPending(dx, ds, amountText, combo, predNumbers, clickDelayMs, targetIssue, lotteryKey)
            } finally {
                pipelineRunning.set(false)
            }
        }
    }

    private fun stashPending(
        dx: String?,
        ds: String?,
        amount: String?,
        combo: String?,
        nums: List<String>,
        delay: Long,
        issue: String?,
        lottery: String?
    ) {
        pendingDx = dx
        pendingDs = ds
        pendingAmount = amount
        pendingCombo = combo
        pendingPredNumbers = nums
        pendingDelayMs = delay
        pendingIssue = issue
        pendingLotteryKey = lottery
        pendingUntil = System.currentTimeMillis() + pendingMaxWaitMs
    }

    private fun executePendingIfPossible() {
        // 从主线程事件回调进来时，立刻切到 worker，避免 sleep 卡 UI
        if (Looper.myLooper() == Looper.getMainLooper()) {
            worker.execute { executePendingIfPossible() }
            return
        }
        if (!pipelineRunning.compareAndSet(false, true)) return
        try {
            val dx = pendingDx
            val ds = pendingDs
            val combo = pendingCombo
            val nums = pendingPredNumbers
            val issue = pendingIssue
            val lottery = pendingLotteryKey
            val refreshed = try {
                AutoBetController.refreshPendingAmountBeforeExecute(this)
            } catch (e: Exception) {
                RuntimeLog.warn("AutoBet", "刷新挂起金额失败: ${e.message}")
                null
            }
            val amount = refreshed ?: pendingAmount
            if (refreshed != null) pendingAmount = refreshed
            if (dx == null && ds == null && amount.isNullOrBlank() && combo.isNullOrBlank() && nums.isEmpty()) return
            if (System.currentTimeMillis() > pendingUntil) {
                clearPending("挂起任务超时", reportFailure = true)
                return
            }
            val activePkg = activeWindowPackage()
            if (activePkg.isNullOrBlank() || activePkg == packageName) return

            val ok = doExecutePipeline(dx, ds, pendingDelayMs, amount, combo, nums)
            if (ok) {
                lastActionFingerprint =
                    "${dx.orEmpty()}|${ds.orEmpty()}|${amount.orEmpty()}|${combo.orEmpty()}|${nums.joinToString(",")}|${issue.orEmpty()}"
                lastActionAt = System.currentTimeMillis()
                reportSuccessToController(issue, lottery)
                clearPending("挂起执行成功", reportFailure = false)
            }
        } catch (e: Exception) {
            RuntimeLog.warn("AutoBet", "executePending 异常: ${e.message}")
        } finally {
            pipelineRunning.set(false)
        }
    }

    private fun reportSuccessToController(issue: String?, lotteryKey: String?) {
        if (issue.isNullOrBlank()) return
        try {
            AutoBetController.notifyBetSucceeded(this, issue, lotteryKey.orEmpty())
        } catch (e: Exception) {
            RuntimeLog.warn("AutoBet", "notifyBetSucceeded 失败: ${e.message}")
        }
    }

    private fun reportFailureToController(issue: String?, lotteryKey: String?, reason: String?) {
        try {
            AutoBetController.notifyBetFailedOrTimedOut(this, issue, lotteryKey, reason)
        } catch (e: Exception) {
            RuntimeLog.warn("AutoBet", "notifyBetFailedOrTimedOut 失败: ${e.message}")
        }
    }

    /**
     * @param reportFailure 为 true 时（超时等）通知 Controller 清除 inflight，允许同一期重试
     */
    private fun clearPending(reason: String?, reportFailure: Boolean = false) {
        val issue = pendingIssue
        val lottery = pendingLotteryKey
        pendingDx = null
        pendingDs = null
        pendingAmount = null
        pendingCombo = null
        pendingPredNumbers = emptyList()
        pendingUntil = 0L
        pendingIssue = null
        pendingLotteryKey = null
        if (!reason.isNullOrBlank()) {
            RuntimeLog.info("AutoBet", reason)
        }
        if (reportFailure) {
            reportFailureToController(issue, lottery, reason)
        }
    }

    /** 在非本应用窗口上真正执行点击 */
    /**
     * 固定顺序：
     * ① 大小单双（固定最先）
     * ② 倍投/复原金额数字（固定第二）
     * ③ 之后按 [autoClickPostActionsJson] 顺序：组合 / 预测数字 / 自定义文案
     */
    private fun doExecutePipeline(
        dx: String?,
        ds: String?,
        clickDelayMs: Long,
        amountText: String?,
        combo: String? = null,
        predNumbers: List<String> = emptyList()
    ): Boolean {
        val prefs = try {
            CaiFenXiApplication.instance.configStore.loadPrefs()
        } catch (_: Exception) {
            return doClickOnThirdParty(dx, ds, clickDelayMs)
        }

        var anyOk = false
        val needDxDs = prefs.autoExecClickDxDs && (!dx.isNullOrBlank() || !ds.isNullOrBlank())
        val needDigits = !amountText.isNullOrBlank() && prefs.autoInputEnabled &&
            (prefs.autoExecFindInput || prefs.autoExecTypeAmount)

        // 全部动作可编排排序：大小单双 / 金额 / 组合 / 数字 / 文案 / 玩法
        val postActions = AutoClickPostActionsCodec.decode(prefs.autoClickPostActionsJson)
        for (action in postActions) {
            if (!action.enabled) continue
            val ok = when (action.type) {
                AutoClickPostAction.TYPE_PRED_DX_DS -> {
                    if (!needDxDs) {
                        RuntimeLog.info("AutoBet", "动作·大小单双 跳过（无预测或开关关）")
                        true
                    } else {
                        RuntimeLog.info("AutoBet", "动作·大小单双 dx=$dx ds=$ds")
                        regionOverridePx = null
                        doClickOnThirdParty(dx, ds, clickDelayMs)
                    }
                }
                AutoClickPostAction.TYPE_BET_AMOUNT -> {
                    if (!needDigits) {
                        RuntimeLog.info("AutoBet", "动作·金额数字 跳过")
                        true
                    } else {
                        RuntimeLog.info("AutoBet", "动作·金额数字 amount=$amountText")
                        clickAmountDigitsOnScreen(amountText!!, clickDelayMs)
                    }
                }
                AutoClickPostAction.TYPE_COMBO -> {
                    val label = combo?.takeIf { it.isNotBlank() }
                    if (label == null) {
                        RuntimeLog.info("AutoBet", "动作·组合 无预测，跳过")
                        true
                    } else {
                        RuntimeLog.info("AutoBet", "动作·组合 点击「$label」")
                        clickTextWithOptionalRegion(label, action, clickDelayMs)
                    }
                }
                AutoClickPostAction.TYPE_PRED_NUMBERS -> {
                    if (predNumbers.isEmpty()) {
                        RuntimeLog.info("AutoBet", "动作·位置数字 无号码，跳过")
                        true
                    } else {
                        RuntimeLog.info("AutoBet", "动作·位置数字 ${predNumbers.joinToString()}")
                        var all = true
                        for (n in predNumbers) {
                            if (!clickTextWithOptionalRegion(n, action, clickDelayMs)) all = false
                            sleepGap(clickDelayMs, 0.6)
                        }
                        all
                    }
                }
                AutoClickPostAction.TYPE_PLAY, AutoClickPostAction.TYPE_TEXT -> {
                    val label = action.text.trim()
                    if (label.isEmpty()) {
                        RuntimeLog.info("AutoBet", "动作·文案 空，跳过")
                        true
                    } else {
                        RuntimeLog.info("AutoBet", "动作·文案 点击「$label」")
                        clickTextWithOptionalRegion(label, action, clickDelayMs)
                    }
                }
                else -> {
                    val label = action.text.trim()
                    if (label.isEmpty()) true
                    else clickTextWithOptionalRegion(label, action, clickDelayMs)
                }
            }
            if (!ok) {
                // 大小单双失败则中止；其余失败可记录但继续（金额失败也中止后续意义不大，保持中止）
                RuntimeLog.warn("AutoBet", "动作失败 type=${action.type} text=${action.text}")
                if (action.type == AutoClickPostAction.TYPE_PRED_DX_DS) return false
                return anyOk
            }
            anyOk = true
            sleepGap(clickDelayMs, if (action.type == AutoClickPostAction.TYPE_PRED_DX_DS) 1.5 else 1.0)
        }

        return anyOk || postActions.none { it.enabled }
    }


    private fun sleepGap(baseMs: Long, factor: Double) {
        try {
            Thread.sleep((baseMs * factor).toLong().coerceIn(120L, 2500L))
        } catch (_: InterruptedException) {
        }
    }

    /** 文案点击：若动作带区域则覆盖，否则用大小单双区域 / 全屏 */
    private fun clickTextWithOptionalRegion(
        text: String,
        action: AutoClickPostAction,
        clickDelayMs: Long
    ): Boolean {
        val override = if (action.regionEnabled) {
            normalizedToPx(action.regionLeft, action.regionTop, action.regionRight, action.regionBottom)
        } else null
        regionOverridePx = override
        return try {
            var ok = doClickLabelOnThirdParty(text)
            if (!ok) {
                sleepGap(clickDelayMs, 0.5)
                ok = doClickLabelOnThirdParty(text)
            }
            ok
        } finally {
            regionOverridePx = null
        }
    }

    /**
     * 将金额拆成「0-9 / .」序列，用数字键专用匹配与点击逻辑逐位输入。
     * 区域：优先数字键盘区域 → 点击区域 → 全屏。
     * 体验：逐位重扫树、失败重试一次、键间间隔略长，避免点到赔率/期号等杂数字。
     */
    /**
     * 将金额拆成「0-9 / .」序列，用数字键专用匹配与点击逻辑逐位输入。
     * 区域：优先数字键盘区域 → 点击区域 → 全屏。
     * 体验：逐位重扫树、失败重试一次、键间间隔略长，避免点到赔率/期号等杂数字。
     */
    private fun clickAmountDigitsOnScreen(amountText: String, clickDelayMs: Long): Boolean {
        val digits = amountText.trim().map { ch ->
            when {
                ch in '０'..'９' -> ('0'.code + (ch - '０')).toChar()
                ch == '．' || ch == '。' -> '.'
                else -> ch
            }
        }.filter { it.isDigit() || it == '.' }
        if (digits.isEmpty()) {
            RuntimeLog.warn("AutoBet", "金额无可点击字符 amount=$amountText")
            return false
        }

        val digitRegion = activeInputRegionPx() ?: activeClickRegionPxRaw()
        // 数字键响应常慢于大小单双，下限略提高
        val gapMs = clickDelayMs.coerceIn(160L, 900L)
        regionOverridePx = digitRegion
        try {
            RuntimeLog.info(
                "AutoBet",
                "开始逐位点击数字 sequence=$digits region=${digitRegion ?: "全屏"} gap=${gapMs}ms"
            )
            for ((idx, ch) in digits.withIndex()) {
                val label = ch.toString()
                var ok = doClickDigitOnThirdParty(label)
                if (!ok) {
                    // 界面可能刚刷新：稍等再扫一次
                    try {
                        Thread.sleep((gapMs / 2).coerceIn(80L, 350L))
                    } catch (_: InterruptedException) {
                    }
                    ok = doClickDigitOnThirdParty(label)
                }
                if (!ok) {
                    RuntimeLog.warn("AutoBet", "第${idx + 1}位数字「$label」未找到或点击失败")
                    return false
                }
                RuntimeLog.info("AutoBet", "已点击数字「$label」(${idx + 1}/${digits.size})")
                if (idx < digits.lastIndex) {
                    try {
                        Thread.sleep(gapMs)
                    } catch (_: InterruptedException) {
                    }
                }
            }
            return true
        } finally {
            regionOverridePx = null
        }
    }

    /**
     * 数字键专用：每键重新收集窗口，走 findAndClickDigit（更严精确匹配 + 小键优先）。
     */
    private fun doClickDigitOnThirdParty(digit: String): Boolean {
        val roots = collectCandidateRoots()
        if (roots.isEmpty()) {
            RuntimeLog.warn("AutoBet", "点数字「$digit」：无可用窗口根节点")
            return false
        }
        try {
            for (root in roots) {
                val pkg = root.packageName?.toString().orEmpty()
                if (pkg == packageName) continue
                if (findAndClickDigit(root, digit)) {
                    RuntimeLog.info("AutoBet", "窗口=$pkg 数字键[$digit] => true")
                    return true
                }
            }
        } finally {
            roots.forEach { try { it.recycle() } catch (_: Exception) {} }
        }
        RuntimeLog.warn("AutoBet", "未找到可点击的数字「$digit」")
        return false
    }

    /**
     * 与 [doClickOnThirdParty] 单目标路径一致：遍历第三方窗口，findAndClick(text)。
     * 供大小单双等非数字目标使用。
     */
    private fun doClickLabelOnThirdParty(text: String): Boolean {
        val roots = collectCandidateRoots()
        if (roots.isEmpty()) {
            RuntimeLog.warn("AutoBet", "点「$text」：无可用窗口根节点")
            return false
        }
        try {
            for (root in roots) {
                val pkg = root.packageName?.toString().orEmpty()
                if (pkg == packageName) continue
                if (findAndClick(root, text)) {
                    RuntimeLog.info("AutoBet", "窗口=$pkg 点击[$text] => true")
                    return true
                }
            }
        } finally {
            roots.forEach { try { it.recycle() } catch (_: Exception) {} }
        }
        RuntimeLog.warn("AutoBet", "未找到可点击的「$text」")
        return false
    }

    /** 读取点击区域原始配置（不经过 regionOverride），供数字回落使用 */
    private fun activeClickRegionPxRaw(): Rect? {
        return try {
            val prefs = CaiFenXiApplication.instance.configStore.loadPrefs()
            if (!prefs.autoClickRegionEnabled) return null
            normalizedToPx(
                prefs.autoClickRegionLeft,
                prefs.autoClickRegionTop,
                prefs.autoClickRegionRight,
                prefs.autoClickRegionBottom
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun doClickOnThirdParty(dx: String?, ds: String?, clickDelayMs: Long): Boolean {
        val roots = collectCandidateRoots()
        if (roots.isEmpty()) {
            RuntimeLog.warn("AutoBet", "无可用窗口根节点")
            return false
        }

        var clickedDx = false
        var clickedDs = false

        try {
            if (!dx.isNullOrBlank() && (dx == "大" || dx == "小")) {
                for (root in roots) {
                    val pkg = root.packageName?.toString().orEmpty()
                    if (pkg == packageName) continue
                    if (findAndClick(root, dx)) {
                        RuntimeLog.info("AutoBet", "窗口=$pkg 点击[$dx] => true")
                        clickedDx = true
                        break
                    }
                }
                if (!clickedDx) {
                    RuntimeLog.warn("AutoBet", "未找到可点击的「$dx」")
                }
            } else {
                clickedDx = true // 未要求点大小，视为通过
            }

            if (!ds.isNullOrBlank() && (ds == "单" || ds == "双")) {
                val runDs = {
                    val roots2 = collectCandidateRoots()
                    var ok = false
                    for (root in roots2) {
                        val pkg = root.packageName?.toString().orEmpty()
                        if (pkg == packageName) continue
                        if (findAndClick(root, ds)) {
                            RuntimeLog.info("AutoBet", "窗口=$pkg 点击[$ds] => true")
                            ok = true
                            break
                        }
                    }
                    if (!ok) RuntimeLog.warn("AutoBet", "未找到可点击的「$ds」")
                    roots2.forEach { try { it.recycle() } catch (_: Exception) {} }
                    clickedDs = ok
                }
                if (clickedDx && clickDelayMs > 0 && !dx.isNullOrBlank()) {
                    // 同步等待一小段，保证顺序（挂起路径里已在主线程）
                    try {
                        Thread.sleep(clickDelayMs.coerceIn(100L, 1500L))
                    } catch (_: InterruptedException) {
                    }
                }
                runDs()
            } else {
                clickedDs = true
            }
        } finally {
            roots.forEach { try { it.recycle() } catch (_: Exception) {} }
        }

        return (dx.isNullOrBlank() || clickedDx) && (ds.isNullOrBlank() || clickedDs) &&
            (!dx.isNullOrBlank() || !ds.isNullOrBlank()) && (clickedDx || clickedDs)
    }

    private fun activeWindowPackage(): String? {
        val root = rootInActiveWindow ?: return null
        return try {
            root.packageName?.toString()
        } finally {
            try { root.recycle() } catch (_: Exception) {}
        }
    }

    /** 收集所有可交互窗口的根节点（排除本应用） */
    private fun collectCandidateRoots(): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        val seen = HashSet<Int>()

        fun addRoot(node: AccessibilityNodeInfo?) {
            if (node == null) return
            val key = System.identityHashCode(node)
            if (!seen.add(key)) {
                try { node.recycle() } catch (_: Exception) {}
                return
            }
            val pkg = node.packageName?.toString().orEmpty()
            if (pkg == packageName) {
                try { node.recycle() } catch (_: Exception) {}
                return
            }
            out.add(node)
        }

        // 1) 活动窗口
        addRoot(rootInActiveWindow)

        // 2) 多窗口（浏览器分屏、悬浮层等）
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            val wins = windows
            if (wins != null) {
                for (w in wins) {
                    try {
                        if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION &&
                            w.type != AccessibilityWindowInfo.TYPE_SPLIT_SCREEN_DIVIDER
                        ) {
                            // 仍尝试取 root，部分投注页在 TYPE_APPLICATION
                        }
                        addRoot(w.root)
                    } catch (_: Exception) {
                    }
                }
            }
        }
        return out
    }

    /**
     * 严格查找并点击目标文字（大小单双主路径）。
     * 优先点「自身可点 + 面积小」的按钮，禁止点超大父容器。
     */
    private fun findAndClick(root: AccessibilityNodeInfo, text: String): Boolean {
        val candidates = ArrayList<ScoredNode>()
        collectStrictMatches(root, text, candidates)
        try {
            val byText = root.findAccessibilityNodeInfosByText(text)
            if (byText != null) {
                for (n in byText) {
                    try {
                        scoreAndMaybeAdd(n, text, candidates)
                    } finally {
                        try { n.recycle() } catch (_: Exception) {}
                    }
                }
            }
        } catch (_: Exception) {
        }
        if (candidates.isEmpty()) {
            RuntimeLog.warn("AutoBet", "严格匹配无结果: $text")
            return false
        }
        candidates.sortWith(
            compareByDescending<ScoredNode> { it.score }
                .thenBy { it.area }
        )
        RuntimeLog.info(
            "AutoBet",
            "候选「$text」${candidates.size}个 最佳score=${candidates.first().score} area=${candidates.first().area}"
        )

        try {
            for (c in candidates) {
                if (c.score < 40) continue
                if (tryClickNodeStrict(c.node, c.area, text)) {
                    RuntimeLog.info("AutoBet", "命中点击「$text」score=${c.score} bounds=${boundsStr(c.node)}")
                    return true
                }
            }
        } finally {
            candidates.forEach { try { it.node.recycle() } catch (_: Exception) {} }
        }
        return false
    }

    /**
     * 数字键专用匹配：只认「整段就是该数字」的节点，优先小面积、接近方形的键盘键，
     * 避免点到「大1.98」「第123期」等含数字的杂节点。
     */
    private fun findAndClickDigit(root: AccessibilityNodeInfo, digit: String): Boolean {
        val candidates = ArrayList<ScoredNode>()
        collectDigitMatches(root, digit, candidates)
        try {
            val byText = root.findAccessibilityNodeInfosByText(digit)
            if (byText != null) {
                for (n in byText) {
                    try {
                        scoreDigitCandidate(n, digit, candidates)
                    } finally {
                        try { n.recycle() } catch (_: Exception) {}
                    }
                }
            }
        } catch (_: Exception) {
        }
        if (candidates.isEmpty()) {
            RuntimeLog.warn("AutoBet", "数字键匹配无结果: $digit")
            return false
        }
        // 分数优先，同等分选更小面积（更像按键）
        candidates.sortWith(
            compareByDescending<ScoredNode> { it.score }
                .thenBy { it.area }
        )
        RuntimeLog.info(
            "AutoBet",
            "数字候选「$digit」${candidates.size}个 最佳score=${candidates.first().score} area=${candidates.first().area}"
        )
        try {
            for (c in candidates) {
                if (c.score < 50) continue
                if (tryClickNodeStrict(c.node, c.area, digit)) {
                    RuntimeLog.info("AutoBet", "命中数字「$digit」score=${c.score} bounds=${boundsStr(c.node)}")
                    return true
                }
            }
        } finally {
            candidates.forEach { try { it.node.recycle() } catch (_: Exception) {} }
        }
        return false
    }

    private fun collectDigitMatches(
        node: AccessibilityNodeInfo,
        digit: String,
        out: MutableList<ScoredNode>
    ) {
        scoreDigitCandidate(node, digit, out)
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            try {
                collectDigitMatches(child, digit, out)
            } finally {
                try { child.recycle() } catch (_: Exception) {}
            }
        }
    }

    private fun scoreDigitCandidate(
        node: AccessibilityNodeInfo,
        digit: String,
        out: MutableList<ScoredNode>
    ) {
        val nodeText = normalizeLabel(node.text?.toString())
        val desc = normalizeLabel(node.contentDescription?.toString())
        val cls = node.className?.toString().orEmpty()

        // 必须「整段等于该数字」，拒绝含其它字符的长文案
        var score = when {
            nodeText == digit -> 100
            desc == digit -> 95
            // 极少数键盘用「数字 1」「键1」
            nodeText in listOf("数字$digit", "键$digit", "按键$digit") -> 88
            desc in listOf("数字$digit", "键$digit", "按键$digit") -> 85
            else -> 0
        }
        if (score <= 0) return

        val rect = Rect()
        node.getBoundsInScreen(rect)
        val w = rect.width().coerceAtLeast(0)
        val h = rect.height().coerceAtLeast(0)
        val area = w * h
        val dm = resources.displayMetrics
        val screenArea = (dm.widthPixels * dm.heightPixels).coerceAtLeast(1)

        val tooBig = area > screenArea * 0.08 || w > dm.widthPixels * 0.40 || h > dm.heightPixels * 0.25
        val tooSmall = w < 10 || h < 10
        val notOnScreen = rect.isEmpty || rect.right <= 0 || rect.bottom <= 0 ||
            rect.left >= dm.widthPixels || rect.top >= dm.heightPixels
        val notVisible = !node.isVisibleToUser
        val outsideRegion = !centerInsideRegion(rect, activeClickRegionPx())
        if (tooBig || tooSmall || notOnScreen || notVisible || outsideRegion) return

        // 接近方形的小键更像数字键盘
        val ratio = if (h > 0) w.toFloat() / h else 99f
        if (ratio in 0.55f..1.8f) score += 12
        if (area < 25_000) score += 12
        if (area < 12_000) score += 8
        if (area < 6_000) score += 6
        if (node.isClickable && node.isEnabled) score += 20
        else if (node.isEnabled) score += 5
        if (cls.contains("Button", ignoreCase = true)) score += 10
        else if (cls.contains("TextView", ignoreCase = true) ||
            cls.contains("View", ignoreCase = true)
        ) score += 4
        // 键盘多在屏幕中下部
        val cy = rect.exactCenterY()
        if (cy > dm.heightPixels * 0.40f) score += 8
        if (cy > dm.heightPixels * 0.55f) score += 4

        out.add(ScoredNode(AccessibilityNodeInfo.obtain(node), score, area))
    }

    private data class ScoredNode(
        val node: AccessibilityNodeInfo,
        val score: Int,
        val area: Int
    )

    private fun collectStrictMatches(
        node: AccessibilityNodeInfo,
        text: String,
        out: MutableList<ScoredNode>
    ) {
        scoreAndMaybeAdd(node, text, out)
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            try {
                collectStrictMatches(child, text, out)
            } finally {
                try { child.recycle() } catch (_: Exception) {}
            }
        }
    }

    /** 对单个节点打分，合格则加入候选（递归与 findByText 共用） */
    private fun scoreAndMaybeAdd(
        node: AccessibilityNodeInfo,
        text: String,
        out: MutableList<ScoredNode>
    ) {
        val nodeText = normalizeLabel(node.text?.toString())
        val desc = normalizeLabel(node.contentDescription?.toString())
        val cls = node.className?.toString().orEmpty()
        val isDigitKey = text.length == 1 && (text[0].isDigit() || text == ".")

        var score = 0
        // 大小单双与数字共用：优先整段相等；数字额外允许极短标签（防点到「大1.98」）
        when {
            nodeText == text -> score += 100
            desc == text -> score += 90
            isDigitKey && nodeText.length in 1..2 && nodeText.contains(text) &&
                nodeText.all { it.isDigit() || it == '.' } -> score += 85
            isDigitKey && desc.length in 1..2 && desc.contains(text) &&
                desc.all { it.isDigit() || it == '.' } -> score += 80
            !isDigitKey && isSingleTargetToken(nodeText, text) -> score += 80
            !isDigitKey && isSingleTargetToken(desc, text) -> score += 70
            !isDigitKey && nodeText.contains(text) && nodeText.length <= 4 && !containsRival(nodeText, text) -> score += 55
            !isDigitKey && desc.contains(text) && desc.length <= 4 && !containsRival(desc, text) -> score += 50
        }
        if (score <= 0) return

        val rect = Rect()
        node.getBoundsInScreen(rect)
        val area = (rect.width().coerceAtLeast(0) * rect.height().coerceAtLeast(0))
        val dm = resources.displayMetrics
        val screenArea = (dm.widthPixels * dm.heightPixels).coerceAtLeast(1)

        // 数字键通常更小：放宽最小尺寸；大小单双保持原阈值
        val minSide = if (isDigitKey) 12 else 24
        val tooBig = area > screenArea * 0.12 || rect.width() > dm.widthPixels * 0.55
        val tooSmall = rect.width() < minSide || rect.height() < minSide
        val notOnScreen = rect.isEmpty || rect.right <= 0 || rect.bottom <= 0 ||
            rect.left >= dm.widthPixels || rect.top >= dm.heightPixels
        val notVisible = !node.isVisibleToUser
        val outsideRegion = !centerInsideRegion(rect, activeClickRegionPx())

        if (tooBig || tooSmall || notOnScreen || notVisible || outsideRegion) return

        if (node.isClickable && node.isEnabled) score += 25
        if (node.isEnabled) score += 5
        if (cls.contains("Button", ignoreCase = true) ||
            cls.contains("TextView", ignoreCase = true) ||
            cls.contains("ViewGroup", ignoreCase = true) ||
            cls.contains("Image", ignoreCase = true)
        ) score += 5
        val cy = rect.exactCenterY()
        if (cy > dm.heightPixels * 0.35f) score += 8
        if (area < 80_000) score += 10
        if (area < 30_000) score += 8

        out.add(ScoredNode(AccessibilityNodeInfo.obtain(node), score, area))
    }

    /** 去掉空白，全角数字/小数点转半角，便于精确比对 */
    private fun normalizeLabel(raw: String?): String {
        if (raw.isNullOrBlank()) return ""
        val sb = StringBuilder()
        for (c in raw.trim()) {
            when {
                c in '０'..'９' -> sb.append(('0'.code + (c - '０')).toChar())
                c == '．' || c == '。' -> sb.append('.')
                c == ' ' || c == '\n' || c == '\t' || c == '　' -> Unit
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    /** 如「大1.98」「大@2」视为单目标；「大小」这类对立词组合不算 */
    private fun isSingleTargetToken(label: String, text: String): Boolean {
        if (label.isEmpty() || !label.contains(text)) return false
        if (containsRival(label, text)) return false
        // 去掉目标字后只剩数字/符号
        val rest = label.replace(text, "")
        return rest.isEmpty() || rest.all { it.isDigit() || it in ".@xX倍赔:-_/" }
    }

    private fun containsRival(label: String, text: String): Boolean {
        val rivals = when (text) {
            "大" -> listOf("小")
            "小" -> listOf("大")
            "单" -> listOf("双")
            "双" -> listOf("单")
            else -> emptyList()
        }
        return rivals.any { it in label }
    }

    private fun boundsStr(node: AccessibilityNodeInfo): String {
        val r = Rect()
        node.getBoundsInScreen(r)
        return "[${r.left},${r.top}-${r.right},${r.bottom}]"
    }

    /**
     * 严格点击：优先 ACTION_CLICK → 可点父节点 → 手势点中心。
     * 数字键与大小单双共用；数字键放宽父层深度与手势面积下限。
     */
    private fun tryClickNodeStrict(node: AccessibilityNodeInfo, area: Int, label: String = ""): Boolean {
        if (!node.isEnabled || !node.isVisibleToUser) return false

        val rect = Rect()
        node.getBoundsInScreen(rect)
        val dm = resources.displayMetrics
        if (rect.isEmpty) return false
        if (rect.width() > dm.widthPixels * 0.55) return false
        if (area > dm.widthPixels * dm.heightPixels * 0.12) return false
        if (!centerInsideRegion(rect, activeClickRegionPx())) return false

        val isDigitKey = label.length == 1 && (label[0].isDigit() || label == ".")

        fun feedback(x: Float = rect.exactCenterX(), y: Float = rect.exactCenterY()) {
            showClickFeedback(x, y, label)
        }

        // 1) 节点自身可点
        if (node.isClickable) {
            if (node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                feedback()
                return true
            }
        }

        // 2) 向上找可点父节点（数字键多包一层，允许 3 层）
        val maxDepth = if (isDigitKey) 3 else 2
        var parent = node.parent
        var depth = 0
        while (parent != null && depth < maxDepth) {
            try {
                if (parent.isClickable && parent.isEnabled) {
                    val pr = Rect()
                    parent.getBoundsInScreen(pr)
                    val pArea = pr.width().coerceAtLeast(0) * pr.height().coerceAtLeast(0)
                    val parentOk = pArea > 0 &&
                        pArea <= dm.widthPixels * dm.heightPixels * 0.12 &&
                        pr.width() <= dm.widthPixels * 0.55 &&
                        centerInsideRegion(pr, activeClickRegionPx())
                    if (parentOk && parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        showClickFeedback(pr.exactCenterX(), pr.exactCenterY(), label)
                        return true
                    }
                    // 父节点可点但 ACTION_CLICK 失败时，手势点父中心
                    if (parentOk && supportsGestureTap &&
                        dispatchTap(pr.exactCenterX(), pr.exactCenterY())
                    ) {
                        showClickFeedback(pr.exactCenterX(), pr.exactCenterY(), label)
                        return true
                    }
                }
            } finally {
                val next = parent.parent
                try { parent.recycle() } catch (_: Exception) {}
                parent = next
                depth++
            }
        }

        // 3) 手势点节点中心（数字 TextView 常不可点，用手势更稳）
        if (supportsGestureTap) {
            val cx = rect.exactCenterX()
            val cy = rect.exactCenterY()
            val minArea = if (isDigitKey) 80 else 800
            val maxArea = if (isDigitKey) 80_000 else 120_000
            val durationMs = if (isDigitKey) 55L else 40L
            if (cx > 0 && cy > 0 && area in minArea..maxArea && dispatchTap(cx, cy, durationMs)) {
                feedback(cx, cy)
                return true
            }
        }
        return false
    }

    private fun dispatchTap(x: Float, y: Float, durationMs: Long = 40L): Boolean {
        if (!supportsGestureTap) return false
        return try {
            val path = Path().apply { moveTo(x, y) }
            val stroke = GestureDescription.StrokeDescription(path, 0, durationMs.coerceIn(30L, 120L))
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            dispatchGesture(gesture, null, null)
        } catch (e: Exception) {
            RuntimeLog.warn("AutoBet", "手势点击失败: ${e.message}")
            false
        }
    }
}
