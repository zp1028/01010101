# Smart Trader P61 — Market Empty / Provider Failover Audit

## User-visible symptom
The Market page showed `0` loaded instruments and the message:
`Binance HTTP info=451 ticker=451`.

## Root cause
The crypto market path had a hard dependency on Binance USD-M public REST:

1. `MarketUniverseService.crypto()` discovered the universe only from `https://fapi.binance.com/fapi/v1/exchangeInfo`.
2. `BinanceUsdMMarketData.quotes()` required Binance exchangeInfo + ticker + mark/book endpoints.
3. Android's direct fallback also called Binance `exchangeInfo` + `ticker/24hr`.
4. When Binance returned HTTP 451, the discovered universe became empty and Android had no rows to render.
5. The existing OKX/Bybit multi-exchange service was only used for per-symbol derivatives analysis; it was not connected to market discovery.
6. Even after a fallback list was shown, crypto candle/terminal paths were still Binance-only, so detail analysis could fail for the fallback symbols.

## P61 changes
- Added `CryptoMarketFallbackService` for public OKX SWAP and Bybit linear discovery + live 24h quotes.
- Binance remains the preferred crypto provider; OKX/Bybit are truthful public-data fallbacks.
- Prevented an empty Binance result from being cached as a healthy one-hour universe.
- Backend `/api/v1/markets?market=crypto` now falls back to OKX/Bybit when Binance is unavailable.
- Android direct crypto discovery now falls back to OKX/Bybit when Binance returns an error such as 451.
- Crypto OHLCV analysis now attempts Binance → OKX → Bybit, so indicator/MTF/chart analysis is not tied to one exchange.
- Crypto instrument snapshot now uses the unified public kline path and multi-exchange derivatives fallback.
- Binance derivatives analysis now falls back to OKX/Bybit for mark/funding/OI when Binance is unavailable; unsupported fields remain unavailable rather than being fabricated.
- Terminal snapshot now falls back to OKX public ticker/mark/order-book/trades/candles.
- Market capability wording now reflects the preferred provider plus public fallbacks.
- Android connection text no longer falsely claims Binance is the active source when a fallback provider is used.

## Truth rules
- No hard-coded symbol list was added.
- No simulated prices or zero-filled unavailable market facts were added.
- Provider/source remains attached to market rows.
- Missing derivative fields remain `null`/unavailable.
- This remains analysis-only: no account, order, paper-trading, or execution API was introduced.

## Validation
- Python syntax compilation: PASS.
- Backend test suite: **107 passed**.
- Android Gradle compile: not claimed locally; the environment does not have a completed Gradle 8.9 distribution cache. GitHub Actions remains the authoritative Android compile check.

## Next CI check
Run `assembleDebug` from this P61 source. Expected first success criterion is that the Market page receives live rows even when Binance returns HTTP 451, provided at least one public fallback provider is reachable from the device/backend network.
