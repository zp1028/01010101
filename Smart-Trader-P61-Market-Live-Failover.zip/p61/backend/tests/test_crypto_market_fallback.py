from app.services.crypto_market_fallback import CryptoMarketFallbackService


def test_normalize_and_okx_symbol():
    assert CryptoMarketFallbackService._norm("BTC/USDT") == "BTCUSDT"
    assert CryptoMarketFallbackService._okx_inst("BTCUSDT") == "BTC-USDT-SWAP"


def test_pct():
    assert CryptoMarketFallbackService._pct("110", "100") == 10.0
    assert CryptoMarketFallbackService._pct("100", "0") == 0.0
