package com.smarttrader.app.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.math.abs


private suspend fun fetchText(url: String): String = withContext(Dispatchers.IO) {
    clientForRest.newCall(Request.Builder().url(url).get().build()).execute().use { resp ->
        if (!resp.isSuccessful) throw IllegalStateException("HTTP ${resp.code}")
        resp.body?.string().orEmpty()
    }
}

private val clientForRest = OkHttpClient.Builder()
    .connectTimeout(15, TimeUnit.SECONDS)
    .readTimeout(20, TimeUnit.SECONDS)
    .build()


data class CandleDto(
    val openTime: Long,
    val closeTime: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double,
)

data class IndicatorDto(
    val symbol: String,
    val timeframe: String,
    val lastPrice: Double?,
    val rsi: Double?,
    val macdHist: Double?,
    val bbPct: Double?,
    val trendSma: String?,
    val summary: String,
    val oscillators: List<String>,
    val signals: List<String>,
    val trendLabel: String = "未知",
    val trendStrength: String = "未知",
    val overboughtCount: Int = 0,
    val oversoldCount: Int = 0,
    val narrative: String = "",
    val realtimeNote: String = "",
    val details: List<String> = emptyList(),
    val structureNote: String = "",
    val divergence: String = "",
)

data class StructurePivotDto(val index: Int, val price: Double, val timestamp: Long?, val kind: String, val label: String)
data class MarketStructureDto(
    val symbol: String, val market: String, val timeframe: String, val available: Boolean,
    val lastPrice: Double?, val support: Double?, val resistance: Double?, val trend: String,
    val breakout: String, val pivots: List<StructurePivotDto>, val note: String, val closedCandleRule: String
)

data class ScenarioDto(
    val name: String, val label: String, val status: String, val trigger: String,
    val observationZone: String, val invalidation: String, val targets: String,
    val reasons: List<String>, val probability: Double?
)
data class HoldingObservationDto(
    val side: String?, val entryPrice: Double?, val unrealizedChangePct: Double?,
    val riskLevel: String, val supportDistancePct: Double?, val resistanceDistancePct: Double?,
    val invalidation: String, val watchpoints: List<String>, val contextSource: String,
    val closedCandleRule: String
)
data class RiskMapLevelDto(val timeframe:String,val available:Boolean,val lastPrice:Double?,val support:Double?,val resistance:Double?,val trend:String,val breakout:String)
data class RiskMapDto(
    val symbol:String,val market:String,val currentTimeframe:String,val lastPrice:Double?,
    val nearestSupport:Double?,val nearestResistance:Double?,val supportDistancePct:Double?,val resistanceDistancePct:Double?,
    val levels:Map<String,RiskMapLevelDto>,val rule:String
)

data class ScenarioAnalysisDto(
    val symbol: String, val market: String, val timeframe: String, val available: Boolean,
    val lastPrice: Double?, val trend: String, val mtfResonance: String,
    val scenarios: List<ScenarioDto>, val probabilityRule: String, val closedCandleRule: String,
    val holdingObservation: HoldingObservationDto?
)

data class MultiTimeframeDto(
    val symbol: String,
    val currentTimeframe: String,
    val current: IndicatorDto,
    val timeframes: Map<String, IndicatorDto>,
    val resonance: String,
    val resonanceNote: String,
    val realtimeNote: String,
)

data class EntryPlanDto(
    val direction: String,
    val conviction: Double,
    val entryLow: Double?,
    val entryHigh: Double?,
    val entry: Double?,
    val stop: Double?,
    val tp1: Double?,
    val tp2: Double?,
    val positionPct: Double?,
    val rr: Double?,
    val rationale: List<String>,
    val scoreType: String = "rule_evidence_score",
)

data class AnalysisFeedItemDto(val symbol:String,val market:String,val timeframe:String,val confidence:Double,val state:String,val direction:String,val summary:String,val reportId:String,val generatedAt:Long,val feedbackState:String,val feedbackSummary:String)
data class AnalysisFeedDto(val items:List<AnalysisFeedItemDto>,val generatedAt:Long,val dataQuality:String)
data class FeedbackHistoryDto(val reportId:String,val generatedAt:Long,val direction:String,val confidence:Double,val state:String,val feedbackState:String,val feedbackSummary:String,val priceAtReport:Double?,val currentPrice:Double?)
data class AnalysisFeedbackDto(val xSymbol:String,val market:String,val timeframe:String,val currentState:String,val currentSummary:String,val history:List<FeedbackHistoryDto>)

data class AdviceDto(
    val symbol: String,
    val bias: String,
    val longPlan: EntryPlanDto,
    val shortPlan: EntryPlanDto,
    val direction: String,
    val conviction: Double,
    val entryLow: Double?,
    val entryHigh: Double?,
    val entry: Double?,
    val stop: Double?,
    val tp1: Double?,
    val tp2: Double?,
    val positionPct: Double?,
    val rr: Double?,
    val positionAction: String,
    val positionNote: String,
    val rationale: List<String>,
    val lastPrice: Double?,
)


data class ReportCatalogItemDto(
    val id: Int, val key: String, val name: String, val domain: String, val priority: String, val update: String, val markets: List<String>,
    val status: String = "unknown", val statusReason: String = ""
)

data class ReportResultDto(
    val key: String, val name: String, val domain: String, val priority: String,
    val summary: String, val availability: String, val availabilityReason: String,
    val dataQuality: String, val generatedAt: String, val dataTimestamp: String = "", val content: List<String>
)

data class InstrumentAnalysisSnapshotDto(
    val symbol: String,
    val market: String,
    val timeframe: String,
    val snapshotAvailable: Boolean,
    val capabilityStatus: String,
    val provider: String,
    val quality: String = "unknown",
    val realtime: Boolean = false,
    val missing: List<String> = emptyList(),
)

data class DerivativesDto(
    val symbol: String, val provider: String, val available: Boolean, val readOnly: Boolean,
    val fundingRate: Double?, val openInterest: Double?, val markPrice: Double?, val indexPrice: Double?,
    val longShortRatio: Double?, val buySellRatio: Double?, val basisRate: Double?, val liquidationPrice: Double?,
)

data class ExchangeMarketDto(
    val provider: String, val available: Boolean, val markPrice: Double?, val indexPrice: Double?,
    val fundingRate: Double?, val openInterest: Double?,
)

data class TerminalLevelDto(val price: Double, val qty: Double)
data class TerminalTradeDto(val id: Long?, val price: Double?, val qty: Double?, val buyerMaker: Boolean?, val time: Long?)
data class TerminalCandleDto(val openTime: Long?, val open: Double?, val high: Double?, val low: Double?, val close: Double?, val volume: Double?, val closeTime: Long?)
data class TerminalQuoteDto(val lastPrice: Double?, val priceChange: Double?, val changePct: Double?, val high24h: Double?, val low24h: Double?, val volume: Double?, val quoteVolume: Double?, val trades: Int?, val dataTime: Long?)
data class TerminalMarkDto(val markPrice: Double?, val indexPrice: Double?, val fundingRate: Double?, val nextFundingTime: Long?, val dataTime: Long?)
data class TerminalBookDto(val bid: Double?, val bidSize: Double?, val ask: Double?, val askSize: Double?, val dataTime: Long?)
data class TerminalFreshnessDto(val quoteMs: Long?, val markMs: Long?, val bookMs: Long?, val status: String)
data class TerminalSnapshotDto(val symbol: String, val provider: String, val marketDataType: String, val serverTime: Long, val quote: TerminalQuoteDto, val mark: TerminalMarkDto, val book: TerminalBookDto, val depthBids: List<TerminalLevelDto>, val depthAsks: List<TerminalLevelDto>, val trades: List<TerminalTradeDto>, val candles: List<TerminalCandleDto>, val freshness: TerminalFreshnessDto)

data class MultiExchangeDto(
    val symbol: String, val providers: List<ExchangeMarketDto>, val providerCount: Int,
    val markPriceMean: Double?, val fundingRateMean: Double?, val openInterestMean: Double?,
    val fundingSpread: Double?, val markSpreadPct: Double?,
)



data class ProviderHealthDto(
    val name: String, val available: Boolean, val status: String, val message: String
)

data class MarketCoverageDto(
    val total: Int, val markets: Map<String, Int>, val providerStatus: Map<String, String>
)

data class MarketDataStatusDto(
    val market: String, val status: String, val provider: String, val realtime: Boolean, val message: String
)

data class MarketCapabilityDto(
    val market: String, val available: Boolean, val realtime: Boolean, val capabilities: List<String>, val missing: List<String>, val provider: String
)

data class UnifiedReportDto(
    val symbol: String, val timeframe: String, val summary: String, val narrative: String,
    val dataQuality: String, val generatedAt: String, val dataTimestamp: String = "", val realtimeNote: String,
    val longSummary: String, val shortSummary: String, val holdingSummary: String, val riskNotes: List<String>
)

object RestClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val json = "application/json; charset=utf-8".toMediaType()

    suspend fun fetchReportCatalog(): Result<List<ReportCatalogItemDto>> = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder().url("${ApiConfig.baseUrl.trimEnd('/')}/api/v1/reports/catalog").get().build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                val root = JSONObject(resp.body?.string().orEmpty())
                val arr = root.optJSONArray("reports") ?: return@withContext Result.success(emptyList())
                val out = mutableListOf<ReportCatalogItemDto>()
                for (i in 0 until arr.length()) {
                    val x = arr.getJSONObject(i)
                    val markets = mutableListOf<String>()
                    x.optJSONArray("markets")?.let { a -> for (j in 0 until a.length()) markets += a.optString(j) }
                    out += ReportCatalogItemDto(x.optInt("id"), x.optString("key"), x.optString("name"), x.optString("domain"), x.optString("priority"), x.optString("update"), markets)
                }
                Result.success(out)
            }
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun fetchInstrumentReportManifest(symbol: String, timeframe: String, market: String): Result<List<ReportCatalogItemDto>> = withContext(Dispatchers.IO) {
        try {
            val raw = symbol.replace("/", "")
            val url = "${ApiConfig.baseUrl.trimEnd('/')}/api/v1/reports/instrument/$raw?timeframe=$timeframe&market=$market"
            val req = Request.Builder().url(url).get().build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                val root = JSONObject(resp.body?.string().orEmpty())
                val arr = root.optJSONArray("reports") ?: return@withContext Result.success(emptyList())
                val out = mutableListOf<ReportCatalogItemDto>()
                for (i in 0 until arr.length()) {
                    val x = arr.getJSONObject(i)
                    val reqs = mutableListOf<String>()
                    x.optJSONArray("source_requirements")?.let { a -> for (j in 0 until a.length()) reqs += a.optString(j) }
                    out += ReportCatalogItemDto(
                        x.optInt("id"), x.optString("key"), x.optString("name"),
                        x.optString("domain"), x.optString("priority"), x.optString("update"),
                        reqs, x.optString("status", "unknown"), x.optString("reason", "")
                    )
                }
                Result.success(out)
            }
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun fetchReport(reportKey: String, symbol: String, timeframe: String, market: String): Result<ReportResultDto> = withContext(Dispatchers.IO) {
        try {
            val raw = symbol.replace("/", "")
            val url = "${ApiConfig.baseUrl.trimEnd('/')}/api/v1/reports/$reportKey/$raw?timeframe=$timeframe&market=$market"
            val req = Request.Builder().url(url).get().build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                val o = JSONObject(resp.body?.string().orEmpty())
                val r = o.optJSONObject("report") ?: JSONObject()
                val a = o.optJSONObject("availability") ?: JSONObject()
                val content = mutableListOf<String>()
                fun flatten(value: Any?, prefix: String = "") {
                    when (value) {
                        is JSONObject -> value.keys().forEach { k -> flatten(value.opt(k), if (prefix.isBlank()) k else "$prefix.$k") }
                        is org.json.JSONArray -> for (i in 0 until value.length()) flatten(value.opt(i), "$prefix[$i]")
                        else -> if (value != null && value.toString().isNotBlank() && value.toString() != "null") content += "$prefix: $value"
                    }
                }
                flatten(o.opt("content"))
                Result.success(ReportResultDto(r.optString("key"), r.optString("name"), r.optString("domain"), r.optString("priority"), o.optString("summary"), a.optString("status"), a.optString("reason"), o.optJSONObject("data_quality")?.toString() ?: "—", o.optString("generated_at"), o.optString("data_timestamp"), content.take(24)))
            }
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun fetchDerivatives(symbol: String, period: String = "1h"): Result<DerivativesDto> = withContext(Dispatchers.IO) {
        try {
            val raw = symbol.replace("/", "")
            val url = "${ApiConfig.baseUrl.trimEnd('/')}/api/v1/derivatives/crypto/$raw?period=$period"
            client.newCall(Request.Builder().url(url).get().build()).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                val o = JSONObject(resp.body?.string().orEmpty())
                val f=o.optJSONObject("funding")?.optJSONObject("latest")
                val oi=o.optJSONObject("open_interest")?.optJSONObject("latest")
                val mi=o.optJSONObject("mark_index")
                val ls=o.optJSONObject("long_short")?.optJSONObject("latest")
                val tk=o.optJSONObject("taker_flow")?.optJSONObject("latest")
                val ba=o.optJSONObject("basis")?.optJSONObject("latest")
                val li=o.optJSONObject("liquidations")?.optJSONObject("latest")
                Result.success(DerivativesDto(
                    o.optString("symbol",symbol), o.optString("provider"), o.optBoolean("available"), o.optBoolean("read_only",true),
                    f?.optDouble("fundingRate")?.takeUnless { it.isNaN() } ?: mi?.optDouble("last_funding_rate")?.takeUnless { it.isNaN() },
                    oi?.optDouble("open_interest")?.takeUnless { it.isNaN() }, mi?.optDouble("mark_price")?.takeUnless { it.isNaN() },
                    mi?.optDouble("index_price")?.takeUnless { it.isNaN() }, ls?.optDouble("longShortRatio")?.takeUnless { it.isNaN() },
                    tk?.optDouble("buySellRatio")?.takeUnless { it.isNaN() }, ba?.optDouble("basisRate")?.takeUnless { it.isNaN() },
                    li?.optDouble("price")?.takeUnless { it.isNaN() }
                ))
            }
        } catch(e:Exception){ Result.failure(e) }
    }

    suspend fun fetchMultiExchange(symbol: String): Result<MultiExchangeDto> = withContext(Dispatchers.IO) {
        try {
            val raw=symbol.replace("/","")
            val url="${ApiConfig.baseUrl.trimEnd('/')}/api/v1/crypto/$raw/multi-exchange"
            client.newCall(Request.Builder().url(url).get().build()).execute().use { resp ->
                if(!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                val o=JSONObject(resp.body?.string().orEmpty()); val arr=o.optJSONArray("providers") ?: org.json.JSONArray()
                val rows=mutableListOf<ExchangeMarketDto>()
                for(i in 0 until arr.length()){ val x=arr.getJSONObject(i); rows+=ExchangeMarketDto(x.optString("provider"),x.optBoolean("available"),x.optDouble("mark_price").takeUnless{it.isNaN()},x.optDouble("index_price").takeUnless{it.isNaN()},x.optDouble("funding_rate").takeUnless{it.isNaN()},x.optDouble("open_interest").takeUnless{it.isNaN()}) }
                val c=o.optJSONObject("consensus") ?: JSONObject(); val d=o.optJSONObject("divergence") ?: JSONObject()
                Result.success(MultiExchangeDto(o.optString("symbol",symbol),rows,o.optInt("available_provider_count"),c.optDouble("mark_price_mean").takeUnless{it.isNaN()},c.optDouble("funding_rate_mean").takeUnless{it.isNaN()},c.optDouble("open_interest_mean").takeUnless{it.isNaN()},d.optDouble("funding_rate_spread").takeUnless{it.isNaN()},d.optDouble("mark_price_spread_pct").takeUnless{it.isNaN()}))
            }
        } catch(e:Exception){ Result.failure(e) }
    }

    suspend fun fetchTerminalSnapshot(symbol: String, timeframe: String): Result<TerminalSnapshotDto> = withContext(Dispatchers.IO) {
        try {
            val raw = symbol.replace("/", "")
            val url = "${ApiConfig.baseUrl.trimEnd('/')}/api/v1/terminal/crypto/$raw?interval=$timeframe&depth_limit=20&trade_limit=20"
            client.newCall(Request.Builder().url(url).get().build()).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                val o = JSONObject(resp.body?.string().orEmpty())
                fun num(obj: JSONObject, key: String): Double? = if (obj.has(key) && !obj.isNull(key)) obj.optDouble(key).takeUnless { it.isNaN() } else null
                val q = o.optJSONObject("quote") ?: JSONObject()
                val m = o.optJSONObject("mark") ?: JSONObject()
                val b = o.optJSONObject("book") ?: JSONObject()
                val f = o.optJSONObject("freshness") ?: JSONObject()
                fun levels(key: String): List<TerminalLevelDto> {
                    val a=o.optJSONObject("depth")?.optJSONArray(key) ?: return emptyList(); val out=mutableListOf<TerminalLevelDto>()
                    for(i in 0 until a.length()){ val x=a.optJSONObject(i) ?: continue; val px=num(x,"price") ?: continue; val qty=num(x,"qty") ?: continue; out+=TerminalLevelDto(px,qty) }; return out
                }
                fun trades(): List<TerminalTradeDto> {
                    val a=o.optJSONArray("trades") ?: return emptyList(); val out=mutableListOf<TerminalTradeDto>()
                    for(i in 0 until a.length()){ val x=a.optJSONObject(i) ?: continue; out+=TerminalTradeDto(x.optLong("id").takeIf{ x.has("id") }, num(x,"price"), num(x,"qty"), if(x.has("buyer_maker")&&!x.isNull("buyer_maker")) x.optBoolean("buyer_maker") else null, x.optLong("time").takeIf{x.has("time")}) }; return out
                }
                val candles=o.optJSONArray("candles")?.let { a -> List(a.length()){ i -> val x=a.optJSONObject(i) ?: JSONObject(); TerminalCandleDto(x.optLong("open_time").takeIf{x.has("open_time")},num(x,"open"),num(x,"high"),num(x,"low"),num(x,"close"),num(x,"volume"),x.optLong("close_time").takeIf{x.has("close_time")}) } } ?: emptyList()
                Result.success(TerminalSnapshotDto(o.optString("symbol",raw),o.optString("provider"),o.optString("market_data_type"),o.optLong("server_time"),
                    TerminalQuoteDto(num(q,"last_price"),num(q,"price_change"),num(q,"change_pct"),num(q,"high_24h"),num(q,"low_24h"),num(q,"volume"),num(q,"quote_volume"),q.optInt("trades").takeIf{q.has("trades")},q.optLong("data_time").takeIf{q.has("data_time")}),
                    TerminalMarkDto(num(m,"mark_price"),num(m,"index_price"),num(m,"funding_rate"),m.optLong("next_funding_time").takeIf{m.has("next_funding_time")},m.optLong("data_time").takeIf{m.has("data_time")}),
                    TerminalBookDto(num(b,"bid"),num(b,"bid_size"),num(b,"ask"),num(b,"ask_size"),b.optLong("data_time").takeIf{b.has("data_time")}),levels("bids"),levels("asks"),trades(),candles,
                    TerminalFreshnessDto(f.optLong("quote_ms").takeIf{f.has("quote_ms")},f.optLong("mark_ms").takeIf{f.has("mark_ms")},f.optLong("book_ms").takeIf{f.has("book_ms")},f.optString("status","unknown"))))
            }
        } catch(e: Exception) { Result.failure(e) }
    }

    suspend fun fetchUnifiedReport(symbol: String, timeframe: String, market: String): Result<UnifiedReportDto> = withContext(Dispatchers.IO) {
        try {
            val raw = symbol.replace("/", "")
            val url = "${ApiConfig.baseUrl.trimEnd('/')}/api/v1/unified-report/$raw?timeframe=$timeframe&market=$market"
            val req = Request.Builder().url(url).get().build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                val o = JSONObject(resp.body?.string().orEmpty())
                val sc = o.optJSONObject("scenario_analysis") ?: JSONObject()
                val risk = mutableListOf<String>()
                sc.optJSONArray("risk_notes")?.let { a -> for (i in 0 until a.length()) risk += a.optString(i) }
                val longObj = sc.optJSONObject("long") ?: JSONObject()
                val shortObj = sc.optJSONObject("short") ?: JSONObject()
                val holdObj = sc.optJSONObject("holding") ?: JSONObject()
                fun one(x: JSONObject): String = x.optString("summary").ifBlank { x.optString("rationale").ifBlank { x.toString() } }
                Result.success(UnifiedReportDto(o.optString("symbol", symbol), o.optString("timeframe", timeframe), o.optString("summary"), o.optString("narrative"), o.optJSONObject("data_quality")?.toString() ?: "—", o.optString("generated_at"), o.optString("data_timestamp"), o.optString("realtime_note"), one(longObj), one(shortObj), one(holdObj), risk))
            }
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun fetchInstrumentAnalysisSnapshot(symbol: String, timeframe: String, market: String): Result<InstrumentAnalysisSnapshotDto> = withContext(Dispatchers.IO) {
        try {
            val raw = symbol.replace("/", "")
            val url = "${ApiConfig.baseUrl.trimEnd('/')}/api/v1/instrument/$market/$raw/analysis?timeframe=$timeframe&limit=250"
            val req = Request.Builder().url(url).get().build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                val o = JSONObject(resp.body?.string().orEmpty())
                val inst = o.optJSONObject("instrument") ?: JSONObject()
                val snap = o.optJSONObject("snapshot") ?: JSONObject()
                val caps = o.optJSONObject("capabilities") ?: JSONObject()
                val missing = mutableListOf<String>()
                caps.optJSONArray("missing")?.let { a -> for (i in 0 until a.length()) missing += a.optString(i) }
                Result.success(InstrumentAnalysisSnapshotDto(
                    inst.optString("symbol", symbol),
                    inst.optString("market", market),
                    inst.optString("timeframe", timeframe),
                    snap.optBoolean("available", false),
                    caps.optString("status", "unknown"),
                    caps.optString("provider", "unknown"),
                    caps.optString("quality", "unknown"),
                    caps.optBoolean("realtime", false),
                    missing,
                ))
            }
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun fetchCandles(symbol: String, timeframe: String, market: String, limit: Int = 180): Result<List<CandleDto>> = withContext(Dispatchers.IO) {
        val raw = symbol.replace("/", "")
        try {
            val url = "${ApiConfig.baseUrl.trimEnd('/')}/api/v1/candles/$raw?timeframe=$timeframe&market=$market&limit=$limit"
            val req = Request.Builder().url(url).get().build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) throw Exception("HTTP ${resp.code}")
                val arr = JSONObject(resp.body?.string().orEmpty()).optJSONArray("candles") ?: return@withContext Result.success(emptyList())
                Result.success(parseCandles(arr))
            }
        } catch (backendError: Exception) {
            if (market.lowercase() != "crypto") return@withContext Result.failure(backendError)
            try {
                val interval = mapOf("5m" to "5m", "15m" to "15m", "30m" to "30m", "1h" to "1h", "4h" to "4h", "1d" to "1d", "1w" to "1w")[timeframe] ?: "15m"
                val url = "https://fapi.binance.com/fapi/v1/klines?symbol=$raw&interval=$interval&limit=${limit.coerceIn(1, 1000)}"
                client.newCall(Request.Builder().url(url).get().build()).execute().use { resp ->
                    if (!resp.isSuccessful) return@withContext Result.failure(Exception("Backend ${backendError.message}; Binance HTTP ${resp.code}"))
                    val arr = org.json.JSONArray(resp.body?.string().orEmpty())
                    val out = mutableListOf<CandleDto>()
                    for (i in 0 until arr.length()) {
                        val x = arr.getJSONArray(i)
                        out += CandleDto(x.optLong(0), x.optLong(6), x.optDouble(1), x.optDouble(2), x.optDouble(3), x.optDouble(4), x.optDouble(5))
                    }
                    Result.success(out)
                }
            } catch (directError: Exception) {
                Result.failure(Exception("K线不可用：Backend=${backendError.message}; Binance=${directError.message}"))
            }
        }
    }

    private fun parseCandles(arr: org.json.JSONArray): List<CandleDto> = buildList {
        for (i in 0 until arr.length()) {
            val x = arr.getJSONObject(i)
            add(CandleDto(x.optLong("open_time"), x.optLong("close_time"), x.optDouble("open"), x.optDouble("high"), x.optDouble("low"), x.optDouble("close"), x.optDouble("volume")))
        }
    }

    suspend fun health(): Boolean = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder().url(ApiConfig.healthUrl).get().build()
            client.newCall(req).execute().use { it.isSuccessful }
        } catch (_: Exception) {
            false
        }
    }

    suspend fun fetchIndicators(symbol: String, timeframe: String, market: String = "crypto"): Result<IndicatorDto> =
        withContext(Dispatchers.IO) {
            try {
                val raw = symbol.replace("/", "")
                val url = "${ApiConfig.baseUrl.trimEnd('/')}/api/v1/indicators/$raw?timeframe=$timeframe&market=$market"
                val req = Request.Builder().url(url).get().build()
                client.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                    val body = resp.body?.string().orEmpty()
                    val o = JSONObject(body)
                    val osc = o.optJSONArray("oscillators")
                    val oscList = mutableListOf<String>()
                    if (osc != null) {
                        for (i in 0 until osc.length()) {
                            val x = osc.getJSONObject(i)
                            oscList.add("${x.optString("name")}: ${x.optString("state")} (${x.optString("note")})")
                        }
                    }
                    val sig = o.optJSONArray("active_signals")
                    val sigList = mutableListOf<String>()
                    if (sig != null) {
                        for (i in 0 until sig.length()) {
                            val x = sig.getJSONObject(i)
                            sigList.add("${x.optString("name")} → ${x.optString("direction")}")
                        }
                    }
                    Result.success(
                        IndicatorDto(
                            symbol = o.optString("symbol", symbol),
                            timeframe = o.optString("timeframe", timeframe),
                            lastPrice = o.optDoubleOrNull("last_price"),
                            rsi = o.optDoubleOrNull("rsi_14"),
                            macdHist = o.optDoubleOrNull("macd_hist"),
                            bbPct = o.optDoubleOrNull("bb_pct"),
                            trendSma = o.optString("trend_sma", null),
                            summary = o.optString("summary"),
                            oscillators = oscList,
                            signals = sigList,
                            trendLabel = o.optString("trend_label", "未知"),
                            trendStrength = o.optString("trend_strength", "未知"),
                            overboughtCount = o.optInt("overbought_count", 0),
                            oversoldCount = o.optInt("oversold_count", 0),
                            narrative = o.optString("narrative", ""),
                            realtimeNote = o.optString("realtime_note", ""),
                            details = listOf(
                                "MA20 ${o.optDoubleOrNull("sma_20") ?: "—"} · MA50 ${o.optDoubleOrNull("sma_50") ?: "—"} · MA200 ${o.optDoubleOrNull("sma_200") ?: "—"}",
                                "EMA12 ${o.optDoubleOrNull("ema_12") ?: "—"} · EMA26 ${o.optDoubleOrNull("ema_26") ?: "—"}",
                                "Stoch K ${o.optDoubleOrNull("stoch_k") ?: "—"} / D ${o.optDoubleOrNull("stoch_d") ?: "—"} · StochRSI ${o.optDoubleOrNull("stoch_rsi") ?: "—"}",
                                "CCI ${o.optDoubleOrNull("cci_20") ?: "—"} · Williams %R ${o.optDoubleOrNull("williams_r") ?: "—"} · UO ${o.optDoubleOrNull("ultimate_osc") ?: "—"}",
                                "ATR ${o.optDoubleOrNull("atr_14") ?: "—"} · ADX ${o.optDoubleOrNull("adx_14") ?: "—"} · DMI+ ${o.optDoubleOrNull("dmi_plus") ?: "—"} / DMI- ${o.optDoubleOrNull("dmi_minus") ?: "—"}",
                                "BOLL ${o.optDoubleOrNull("bb_lower") ?: "—"} / ${o.optDoubleOrNull("bb_mid") ?: "—"} / ${o.optDoubleOrNull("bb_upper") ?: "—"} · % ${o.optDoubleOrNull("bb_pct") ?: "—"}",
                                "VWAP ${o.optDoubleOrNull("vwap") ?: "—"} · MFI ${o.optDoubleOrNull("mfi_14") ?: "—"} · CMF ${o.optDoubleOrNull("cmf_20") ?: "—"}",
                                "OBV ${o.optDoubleOrNull("obv") ?: "—"} · ROC ${o.optDoubleOrNull("roc_12") ?: "—"} · Volume比 ${o.optDoubleOrNull("volume_ratio") ?: "—"}",
                                "Keltner ${o.optDoubleOrNull("keltner_lower") ?: "—"} / ${o.optDoubleOrNull("keltner_mid") ?: "—"} / ${o.optDoubleOrNull("keltner_upper") ?: "—"}",
                                "Donchian ${o.optDoubleOrNull("donchian_low") ?: "—"} / ${o.optDoubleOrNull("donchian_mid") ?: "—"} / ${o.optDoubleOrNull("donchian_high") ?: "—"} · PSAR ${o.optDoubleOrNull("psar") ?: "—"}",
                            ),
                            structureNote = o.optJSONObject("structure")?.optString("note", "") ?: "",
                            divergence = o.optString("divergence", "无明显背离"),
                        )
                    )
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }


    private fun buildLocalIndicator(symbol: String, timeframe: String, candles: List<CandleDto>): IndicatorDto? {
        if (candles.size < 30) return null
        val closes = candles.map { it.close }
        fun sma(n: Int): Double? = if (closes.size < n) null else closes.takeLast(n).average()
        fun ema(values: List<Double>, n: Int): List<Double> {
            if (values.isEmpty()) return emptyList()
            val alpha = 2.0 / (n + 1)
            var prev = values.first()
            val out = ArrayList<Double>(values.size)
            out += prev
            for (v in values.drop(1)) { prev = alpha * v + (1 - alpha) * prev; out += prev }
            return out
        }
        val gains = mutableListOf<Double>(); val losses = mutableListOf<Double>()
        for (i in 1 until closes.size) { val d = closes[i] - closes[i-1]; gains += maxOf(d, 0.0); losses += maxOf(-d, 0.0) }
        val period = 14
        val avgGain = gains.takeLast(period).average(); val avgLoss = losses.takeLast(period).average()
        val rsi = if (avgLoss == 0.0) 100.0 else 100.0 - 100.0 / (1.0 + avgGain / avgLoss)
        val e12 = ema(closes, 12); val e26 = ema(closes, 26)
        val macdSeries = e12.indices.map { e12[it] - e26[it] }
        val signal = ema(macdSeries, 9).lastOrNull() ?: 0.0
        val macdHist = (macdSeries.lastOrNull() ?: 0.0) - signal
        val sma20 = sma(20); val sma50 = sma(50); val mean20 = sma20 ?: closes.takeLast(20).average()
        val sd20 = closes.takeLast(20).let { vals -> val m=vals.average(); kotlin.math.sqrt(vals.sumOf { (it-m)*(it-m) } / vals.size) }
        val bbPct = if (sd20 > 0) (closes.last() - (mean20 - 2*sd20)) / (4*sd20) else 0.5
        val trend = when { sma20 != null && sma50 != null && closes.last() > sma20 && sma20 > sma50 -> "上涨"; sma20 != null && sma50 != null && closes.last() < sma20 && sma20 < sma50 -> "下降"; else -> "震荡" }
        val over = listOf(rsi > 70, bbPct > 0.95).count { it }; val under = listOf(rsi < 30, bbPct < 0.05).count { it }
        val narrative = "实时直连技术分析：RSI ${String.format("%.1f", rsi)}，MACD柱 ${String.format("%.4f", macdHist)}，当前${trend}结构。数据来自实际K线，未使用模拟价格。"
        return IndicatorDto(symbol, timeframe, closes.last(), rsi, macdHist, bbPct, sma20?.let { if (closes.last() >= it) "above" else "below" }, narrative, listOf("RSI ${String.format("%.1f", rsi)}", "BOLL位置 ${String.format("%.2f", bbPct)}"), listOf("MACD ${if (macdHist >= 0) "动能偏多" else "动能偏空"}"), trend, if (abs(macdHist) > closes.last()*0.001) "中等" else "弱", over, under, narrative, "本地实时K线计算", listOf("MA20 ${sma20 ?: "—"}", "MA50 ${sma50 ?: "—"}"), "基于K线结构计算", "未使用模拟数据")
    }


    suspend fun fetchMultiTimeframe(symbol: String, current: String, market: String = "crypto"): Result<MultiTimeframeDto> =
        withContext(Dispatchers.IO) {
            try {
                val raw = symbol.replace("/", "")
                val url = "${ApiConfig.baseUrl.trimEnd('/')}/api/v1/indicators/$raw/multi?current=$current&market=$market"
                val req = Request.Builder().url(url).get().build()
                client.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                    val root = JSONObject(resp.body?.string().orEmpty())
                    fun parse(o: JSONObject): IndicatorDto {
                        val osc = mutableListOf<String>()
                        o.optJSONArray("oscillators")?.let { arr -> for (i in 0 until arr.length()) { val x = arr.getJSONObject(i); osc += "${x.optString("name")}: ${x.optString("state")} (${x.optString("note")})" } }
                        val sig = mutableListOf<String>()
                        o.optJSONArray("active_signals")?.let { arr -> for (i in 0 until arr.length()) { val x = arr.getJSONObject(i); sig += "${x.optString("name")} → ${x.optString("direction")}" } }
                        return IndicatorDto(
                            symbol=o.optString("symbol", symbol), timeframe=o.optString("timeframe"),
                            lastPrice=o.optDoubleOrNull("last_price"), rsi=o.optDoubleOrNull("rsi_14"),
                            macdHist=o.optDoubleOrNull("macd_hist"), bbPct=o.optDoubleOrNull("bb_pct"),
                            trendSma=o.optString("trend_sma", null), summary=o.optString("summary"),
                            oscillators=osc, signals=sig, trendLabel=o.optString("trend_label", "未知"),
                            trendStrength=o.optString("trend_strength", "未知"), overboughtCount=o.optInt("overbought_count", 0),
                            oversoldCount=o.optInt("oversold_count", 0), narrative=o.optString("narrative", ""),
                            realtimeNote=o.optString("realtime_note", ""),
                            details = listOf(
                                "RSI ${o.optDoubleOrNull("rsi_14") ?: "—"} · MACD柱 ${o.optDoubleOrNull("macd_hist") ?: "—"} · ADX ${o.optDoubleOrNull("adx_14") ?: "—"}",
                                "MA20 ${o.optDoubleOrNull("sma_20") ?: "—"} · MA50 ${o.optDoubleOrNull("sma_50") ?: "—"} · ATR ${o.optDoubleOrNull("atr_14") ?: "—"}",
                                "Stoch ${o.optDoubleOrNull("stoch_k") ?: "—"} · CCI ${o.optDoubleOrNull("cci_20") ?: "—"} · MFI ${o.optDoubleOrNull("mfi_14") ?: "—"}",
                            ),
                            structureNote=o.optJSONObject("structure")?.optString("note", "") ?: "",
                            divergence=o.optString("divergence", "无明显背离")
                        )
                    }
                    val map = mutableMapOf<String, IndicatorDto>()
                    root.optJSONObject("timeframes")?.let { obj -> obj.keys().forEach { k -> obj.optJSONObject(k)?.let { map[k] = parse(it) } } }
                    val currentDto = root.optJSONObject("current")?.let { parse(it) } ?: return@withContext Result.failure(Exception("current timeframe missing"))
                    Result.success(MultiTimeframeDto(root.optString("symbol", symbol), root.optString("current_timeframe", current), currentDto, map, root.optString("resonance", ""), root.optString("resonance_note", ""), root.optString("realtime_note", "")))
                }
            } catch (e: Exception) { Result.failure(e) }
        }

    suspend fun fetchRiskMap(symbol:String,timeframe:String,market:String="crypto"): Result<RiskMapDto> = runCatching {
        val raw=symbol.replace("/","").replace("-","")
        val url="${ApiConfig.baseUrl.trimEnd('/')}/api/v1/analysis/$raw/risk-map?timeframe=$timeframe&market=$market&limit=160"
        val o=JSONObject(fetchText(url))
        val levels=mutableMapOf<String,RiskMapLevelDto>()
        o.optJSONObject("timeframes")?.let { obj -> obj.keys().forEach { k -> obj.optJSONObject(k)?.let { x -> levels[k]=RiskMapLevelDto(k,x.optBoolean("available",false),x.optDoubleOrNull("last_price"),x.optDoubleOrNull("support"),x.optDoubleOrNull("resistance"),x.optString("trend","未知"),x.optString("breakout","none")) } } }
        RiskMapDto(o.optString("symbol",symbol),o.optString("market",market),o.optString("current_timeframe",timeframe),o.optDoubleOrNull("last_price"),o.optDoubleOrNull("nearest_support"),o.optDoubleOrNull("nearest_resistance"),o.optDoubleOrNull("support_distance_pct"),o.optDoubleOrNull("resistance_distance_pct"),levels,o.optString("rule",""))
    }

    suspend fun fetchScenarioAnalysis(symbol: String, timeframe: String, market: String = "crypto"): Result<ScenarioAnalysisDto> = runCatching {
        val raw = symbol.replace("/", "").replace("-", "")
        val url = "${ApiConfig.baseUrl.trimEnd('/')}/api/v1/analysis/$raw/scenarios?timeframe=$timeframe&market=$market&limit=200"
        val o = JSONObject(fetchText(url))
        val arr = o.optJSONArray("scenarios") ?: JSONArray()
        val scenarios = (0 until arr.length()).map { i ->
            val x = arr.getJSONObject(i)
            ScenarioDto(x.optString("name"), x.optString("label"), x.optString("status"), x.optString("trigger"), x.optString("observation_zone"), x.optString("invalidation"), x.optString("targets"), (0 until x.optJSONArray("reasons").length()).map { j -> x.optJSONArray("reasons").getString(j) }, if (x.isNull("probability")) null else x.optDouble("probability"))
        }
        val ho = o.optJSONObject("holding_observation")?.let { h ->
            HoldingObservationDto(
                if (h.isNull("side")) null else h.optString("side"),
                h.optDoubleOrNull("entry_price"), h.optDoubleOrNull("unrealized_change_pct"),
                h.optString("risk_level", "正常观察"), h.optDoubleOrNull("support_distance_pct"),
                h.optDoubleOrNull("resistance_distance_pct"), h.optString("invalidation", ""),
                (0 until (h.optJSONArray("watchpoints")?.length() ?: 0)).map { j -> h.optJSONArray("watchpoints")!!.getString(j) },
                h.optString("context_source", "market_only"), h.optString("closed_candle_rule", "")
            )
        }
        ScenarioAnalysisDto(o.optString("symbol",symbol),o.optString("market",market),o.optString("timeframe",timeframe),o.optBoolean("available",false),o.optDoubleOrNull("last_price"),o.optString("trend","unknown"),o.optString("mtf_resonance","多周期中性"),scenarios,o.optString("probability_rule",""),o.optString("closed_candle_rule",""),ho)
    }

    suspend fun fetchMarketStructure(symbol: String, timeframe: String, market: String = "crypto"): Result<MarketStructureDto> =
        withContext(Dispatchers.IO) {
            try {
                val raw = symbol.replace("/", "")
                val url = "${ApiConfig.baseUrl.trimEnd('/')}/api/v1/analysis/$raw/structure?timeframe=$timeframe&market=$market&limit=200"
                val req = Request.Builder().url(url).get().build()
                client.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                    val o = JSONObject(resp.body?.string().orEmpty())
                    val pivots = mutableListOf<StructurePivotDto>()
                    o.optJSONArray("pivots")?.let { a -> for (i in 0 until a.length()) { val x=a.getJSONObject(i); pivots += StructurePivotDto(x.optInt("index"), x.optDouble("price"), if (x.has("timestamp") && !x.isNull("timestamp")) x.optLong("timestamp") else null, x.optString("kind"), x.optString("label")) } }
                    Result.success(MarketStructureDto(o.optString("symbol",symbol),o.optString("market",market),o.optString("timeframe",timeframe),o.optBoolean("available",false),o.optDoubleOrNull("last_price"),o.optDoubleOrNull("support"),o.optDoubleOrNull("resistance"),o.optString("trend","未知"),o.optString("breakout","none"),pivots,o.optString("note",""),o.optString("closed_candle_rule","")))
                }
            } catch (e: Exception) { Result.failure(e) }
        }

    suspend fun fetchAdvice(symbol: String, timeframe: String = "15m", market: String = "crypto"): Result<AdviceDto> =
        withContext(Dispatchers.IO) {
            try {
                val raw = symbol.replace("/", "")
                val url =
                    "${ApiConfig.baseUrl.trimEnd('/')}/api/v1/advice/$raw?timeframe=$timeframe&run_analysis=true&market=$market"
                val req = Request.Builder().url(url).get().build()
                client.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                    val o = JSONObject(resp.body?.string().orEmpty())
                    val entry = o.optJSONObject("entry")
                    val long = o.optJSONObject("long_entry")
                    val short = o.optJSONObject("short_entry")
                    val pos = o.optJSONObject("position")
                    fun plan(x: JSONObject?): EntryPlanDto {
                        val ra = mutableListOf<String>()
                        x?.optJSONArray("rationale")?.let { arr ->
                            for (i in 0 until arr.length()) ra.add(arr.getString(i))
                        }
                        return EntryPlanDto(
                            direction = x?.optString("direction") ?: "wait",
                            conviction = x?.optDouble("conviction") ?: 0.0,
                            entryLow = x?.optDoubleOrNull("entry_zone_low"),
                            entryHigh = x?.optDoubleOrNull("entry_zone_high"),
                            entry = x?.optDoubleOrNull("suggested_entry"),
                            stop = x?.optDoubleOrNull("stop_loss"),
                            tp1 = x?.optDoubleOrNull("take_profit_1"),
                            tp2 = x?.optDoubleOrNull("take_profit_2"),
                            positionPct = x?.optDoubleOrNull("position_pct"),
                            rr = x?.optDoubleOrNull("risk_reward"),
                            rationale = ra,
                            scoreType = x?.optString("score_type", "rule_evidence_score") ?: "rule_evidence_score",
                        )
                    }
                    val lp = plan(long)
                    val sp = plan(short)
                    val selectedRationale = mutableListOf<String>()
                    entry?.optJSONArray("rationale")?.let { arr ->
                        for (i in 0 until arr.length()) selectedRationale.add(arr.getString(i))
                    }
                    Result.success(
                        AdviceDto(
                            symbol = o.optString("symbol", symbol),
                            bias = o.optString("market_bias"),
                            longPlan = lp,
                            shortPlan = sp,
                            direction = entry?.optString("direction") ?: "wait",
                            conviction = entry?.optDouble("conviction") ?: 0.0,
                            entryLow = entry?.optDoubleOrNull("entry_zone_low"),
                            entryHigh = entry?.optDoubleOrNull("entry_zone_high"),
                            entry = entry?.optDoubleOrNull("suggested_entry"),
                            stop = entry?.optDoubleOrNull("stop_loss"),
                            tp1 = entry?.optDoubleOrNull("take_profit_1"),
                            tp2 = entry?.optDoubleOrNull("take_profit_2"),
                            positionPct = entry?.optDoubleOrNull("position_pct"),
                            rr = entry?.optDoubleOrNull("risk_reward"),
                            positionAction = pos?.optString("action") ?: "wait",
                            positionNote = pos?.optString("note") ?: "",
                            rationale = selectedRationale,
                            lastPrice = o.optDoubleOrNull("last_price"),
                        )
                    )
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }


private fun JSONObject.optDoubleOrNull(key: String): Double? {
    if (!has(key) || isNull(key)) return null
    val v = optDouble(key, Double.NaN)
    return if (v.isNaN()) null else v
}

    data class MarketPage(val items: List<com.smarttrader.app.data.MarketItem>, val hasMore: Boolean, val total: Int, val offset: Int)

    suspend fun fetchMarketsPage(market: String? = null, query: String? = null, limit: Int = 250, offset: Int = 0): Result<MarketPage> = withContext(Dispatchers.IO) {
        // An APK built without SMART_TRADER_BACKEND_URL can use the same
        // Binance USD-M Futures public market feed directly. The Android
        // fallback must never switch to Spot or a different crypto provider.
        if (ApiConfig.baseUrl.isBlank()) {
            return@withContext if (market.isNullOrBlank() || market.equals("crypto", true)) {
                fetchCryptoMarketsDirect(query, limit, offset)
            } else {
                Result.failure(Exception("backend URL not configured for $market market"))
            }
        }
        try {
            val parts = mutableListOf("limit=$limit", "offset=$offset")
            if (!market.isNullOrBlank()) parts += "market=${java.net.URLEncoder.encode(market, "UTF-8")}"
            if (!query.isNullOrBlank()) parts += "q=${java.net.URLEncoder.encode(query, "UTF-8")}"
            val url = "${ApiConfig.baseUrl.trimEnd('/')}/api/v1/markets?${parts.joinToString("&")}"
            client.newCall(Request.Builder().url(url).get().build()).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                val root = JSONObject(resp.body?.string().orEmpty())
                val arr = root.optJSONArray("markets") ?: org.json.JSONArray()
                val out = mutableListOf<com.smarttrader.app.data.MarketItem>()
                for (i in 0 until arr.length()) {
                    val x = arr.getJSONObject(i)
                    out += com.smarttrader.app.data.MarketItem(
                        symbol=x.optString("symbol"), name=x.optString("name", x.optString("symbol")),
                        price=x.optDoubleOrNull("price")?.let { java.text.DecimalFormat("#,##0.####").format(it) } ?: "--",
                        changePct=x.optDoubleOrNull("change_pct") ?: 0.0, attention=0.0, regime="—",
                        assetClass=x.optString("market", "crypto"), venue=x.optString("venue"), currency=x.optString("currency"),
                        quoteStatus=x.optString("quote_status", "unknown"),
                        contractType=x.optString("metadata_contract_type", x.optString("contract_type", "")),
                        marketDataType=x.optString("market_data_type", x.optString("market_type", ""))
                    )
                }
                // A reachable backend can still have an empty crypto provider.
                // Use the same Binance USD-M feed directly rather than changing
                // market semantics or inventing rows.
                if (out.isEmpty() && market.equals("crypto", true)) {
                    return@withContext fetchCryptoMarketsDirect(query, limit, offset)
                }
                Result.success(MarketPage(out, root.optBoolean("has_more", false), root.optInt("total", out.size), root.optInt("offset", offset)))
            }
        } catch (e: Exception) {
            if (market.isNullOrBlank() || market.equals("crypto", true)) {
                fetchCryptoMarketsDirect(query, limit, offset)
            } else {
                Result.failure(e)
            }
        }
    }

    suspend fun fetchCryptoMarketsDirect(query: String? = null, limit: Int = 1000, offset: Int = 0): Result<MarketPage> = withContext(Dispatchers.IO) {
        val errors = mutableListOf<String>()

        // Binance USD-M Futures is the only direct crypto fallback.
        // The universe and quote values therefore have the same semantics as
        // the backend market layer.
        try {
            val infoUrl = "https://fapi.binance.com/fapi/v1/exchangeInfo"
            val tickerUrl = "https://fapi.binance.com/fapi/v1/ticker/24hr"
            val requestInfo = Request.Builder().url(infoUrl).get().build()
            val requestTicker = Request.Builder().url(tickerUrl).get().build()
            val infoResponse = client.newCall(requestInfo).execute()
            val tickerResponse = client.newCall(requestTicker).execute()
            infoResponse.use { infoResp ->
                tickerResponse.use { tickerResp ->
                    if (!infoResp.isSuccessful || !tickerResp.isSuccessful) {
                        errors += "Binance HTTP info=${infoResp.code} ticker=${tickerResp.code}"
                    } else {
                        val info = JSONObject(infoResp.body?.string().orEmpty())
                        val symbols = info.optJSONArray("symbols") ?: org.json.JSONArray()
                        val contractMeta = mutableMapOf<String, Pair<String, String>>()
                        for (i in 0 until symbols.length()) {
                            val x = symbols.optJSONObject(i) ?: continue
                            val symbol = x.optString("symbol").uppercase()
                            val quote = x.optString("quoteAsset").uppercase()
                            val type = x.optString("contractType").uppercase()
                            val status = x.optString("status", x.optString("contractStatus")).uppercase()
                            if (symbol.isNotBlank() && quote in setOf("USDT", "USDC") && type in setOf("PERPETUAL", "CURRENT_QUARTER", "NEXT_QUARTER") && (status.isBlank() || status == "TRADING")) {
                                contractMeta[symbol] = quote to type
                            }
                        }
                        val arr = org.json.JSONArray(tickerResp.body?.string().orEmpty())
                        val rows = parseBinanceCryptoRows(arr, query, contractMeta)
                        if (rows.isNotEmpty()) return@withContext paginateMarketRows(rows, limit, offset)
                        errors += "Binance returned no matching USD-M symbols"
                    }
                }
            }
        } catch (e: Exception) {
            errors += "Binance ${e.message ?: e.javaClass.simpleName}"
        }

        // Binance can legitimately return HTTP 451 for a region. Fall back to
        // public OKX/Bybit derivatives data instead of leaving the market page empty.
        fetchCryptoMarketsFromFallbackProviders(query, limit, offset).fold(
            onSuccess = { return@withContext Result.success(it) },
            onFailure = { errors += it.message ?: "fallback providers unavailable" }
        )
        Result.failure(Exception(errors.joinToString("; ").ifBlank { "no public crypto provider available" }))
    }

    private suspend fun fetchCryptoMarketsFromFallbackProviders(query: String?, limit: Int, offset: Int): Result<MarketPage> = withContext(Dispatchers.IO) {
        val providers = listOf("okx", "bybit")
        val all = mutableListOf<com.smarttrader.app.data.MarketItem>()
        val seen = mutableSetOf<String>()
        for (provider in providers) {
            try {
                val rows = if (provider == "okx") {
                    val instReq = Request.Builder().url("https://www.okx.com/api/v5/public/instruments?instType=SWAP").get().build()
                    val tickReq = Request.Builder().url("https://www.okx.com/api/v5/market/tickers?instType=SWAP").get().build()
                    val instResp = client.newCall(instReq).execute()
                    val tickResp = client.newCall(tickReq).execute()
                    instResp.use { ir -> tickResp.use { tr ->
                        if (!ir.isSuccessful || !tr.isSuccessful) throw Exception("OKX HTTP inst=${ir.code} ticker=${tr.code}")
                        val ia = JSONObject(ir.body?.string().orEmpty()).optJSONArray("data") ?: org.json.JSONArray()
                        val ta = JSONObject(tr.body?.string().orEmpty()).optJSONArray("data") ?: org.json.JSONArray()
                        val ticks = mutableMapOf<String, JSONObject>()
                        for (i in 0 until ta.length()) ta.optJSONObject(i)?.let { ticks[it.optString("instId").uppercase()] = it }
                        buildList {
                            for (i in 0 until ia.length()) {
                                val x = ia.optJSONObject(i) ?: continue
                                if (!x.optString("state").equals("live", true)) continue
                                val inst = x.optString("instId").uppercase()
                                if (!inst.endsWith("-USDT-SWAP")) continue
                                val symbol = inst.replace("-", "")
                                val t = ticks[inst] ?: continue
                                val last = t.optDoubleOrNull("last") ?: continue
                                val prev = t.optDoubleOrNull("open24h") ?: last
                                if (!query.isNullOrBlank() && !symbol.contains(query.trim().uppercase())) continue
                                add(com.smarttrader.app.data.MarketItem(symbol, inst, java.text.DecimalFormat("#,##0.####").format(last), if (prev != 0.0) (last-prev)/prev*100.0 else 0.0, 0.0, "—", "crypto", "okx", "USDT", "live", "PERPETUAL", "SWAP"))
                            }
                        }
                    }}
                } else {
                    val instUrl = "https://api.bybit.com/v5/market/instruments-info?category=linear&limit=1000"
                    val tickUrl = "https://api.bybit.com/v5/market/tickers?category=linear"
                    val ir = client.newCall(Request.Builder().url(instUrl).get().build()).execute()
                    val tr = client.newCall(Request.Builder().url(tickUrl).get().build()).execute()
                    ir.use { iresp -> tr.use { tresp ->
                        if (!iresp.isSuccessful || !tresp.isSuccessful) throw Exception("Bybit HTTP inst=${iresp.code} ticker=${tresp.code}")
                        val ia = JSONObject(iresp.body?.string().orEmpty()).optJSONObject("result")?.optJSONArray("list") ?: org.json.JSONArray()
                        val ta = JSONObject(tresp.body?.string().orEmpty()).optJSONObject("result")?.optJSONArray("list") ?: org.json.JSONArray()
                        val ticks = mutableMapOf<String, JSONObject>()
                        for (i in 0 until ta.length()) ta.optJSONObject(i)?.let { ticks[it.optString("symbol").uppercase()] = it }
                        buildList {
                            for (i in 0 until ia.length()) {
                                val x = ia.optJSONObject(i) ?: continue
                                if (!x.optString("status").equals("Trading", true)) continue
                                val symbol = x.optString("symbol").uppercase()
                                if (!symbol.endsWith("USDT")) continue
                                val t = ticks[symbol] ?: continue
                                val last = t.optDoubleOrNull("lastPrice") ?: continue
                                val prev = t.optDoubleOrNull("prevPrice24h") ?: last
                                if (!query.isNullOrBlank() && !symbol.contains(query.trim().uppercase())) continue
                                add(com.smarttrader.app.data.MarketItem(symbol, symbol, java.text.DecimalFormat("#,##0.####").format(last), if (prev != 0.0) (last-prev)/prev*100.0 else 0.0, 0.0, "—", "crypto", "bybit", "USDT", "live", "PERPETUAL", "linear"))
                            }
                        }
                    }}
                }
                for (r in rows) if (seen.add(r.symbol)) all += r
            } catch (_: Exception) { }
        }
        if (all.isEmpty()) return@withContext Result.failure(Exception("OKX/Bybit public market data unavailable"))
        Result.success(paginateMarketRows(all.sortedBy { it.symbol }, limit, offset))
    }

    private fun parseBinanceCryptoRows(
        arr: org.json.JSONArray,
        query: String?,
        contractMeta: Map<String, Pair<String, String>> = emptyMap(),
    ): List<com.smarttrader.app.data.MarketItem> {
        val rows = mutableListOf<com.smarttrader.app.data.MarketItem>()
        val needle = query?.trim()?.uppercase().orEmpty()
        for (i in 0 until arr.length()) {
            val x = arr.optJSONObject(i) ?: continue
            val raw = x.optString("symbol").uppercase()
            val meta = contractMeta[raw] ?: continue
            val quote = meta.first
            val contractType = meta.second
            val base = raw.removeSuffix(quote)
            if (base.isBlank()) continue
            val display = "$base/$quote"
            if (needle.isNotBlank() && !raw.contains(needle) && !base.contains(needle)) continue
            val price = x.optDoubleOrNull("lastPrice") ?: continue
            val change = x.optDoubleOrNull("priceChangePercent") ?: 0.0
            val volume = x.optDoubleOrNull("quoteVolume") ?: 0.0
            val attention = (kotlin.math.abs(change) / 8.0 + kotlin.math.min(0.5, kotlin.math.log10(volume + 1.0) / 20.0)).coerceIn(0.0, 1.0)
            rows += com.smarttrader.app.data.MarketItem(
                symbol = display, name = base, price = java.text.DecimalFormat("#,##0.####").format(price),
                changePct = change, attention = attention, regime = "live",
                assetClass = "crypto", venue = "binance-usdm", currency = quote, quoteStatus = "live",
                contractType = contractType, marketDataType = "USD-M"
            )
        }
        return rows.sortedBy { it.symbol }
    }

    private fun paginateMarketRows(rows: List<com.smarttrader.app.data.MarketItem>, limit: Int, offset: Int): Result<MarketPage> {
        val total = rows.size
        val page = rows.drop(offset).take(limit)
        return Result.success(MarketPage(page, offset + page.size < total, total, offset))
    }

    suspend fun fetchMarkets(market: String? = null, query: String? = null, limit: Int = 1000): Result<List<com.smarttrader.app.data.MarketItem>> =
        fetchMarketsPage(market, query, limit, 0).map { it.items }

    suspend fun fetchAnalysisFeed(market: String = "crypto", timeframe: String = "15m", limit: Int = 8): Result<AnalysisFeedDto> = withContext(Dispatchers.IO) {
        try {
            val url = "${ApiConfig.baseUrl.trimEnd('/')}/api/v1/analysis-feed?market=${java.net.URLEncoder.encode(market, "UTF-8")}&timeframe=${java.net.URLEncoder.encode(timeframe, "UTF-8")}&limit=$limit"
            client.newCall(Request.Builder().url(url).get().build()).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                val root=JSONObject(resp.body?.string().orEmpty())
                val arr=root.optJSONArray("items") ?: org.json.JSONArray()
                val items=mutableListOf<AnalysisFeedItemDto>()
                for(i in 0 until arr.length()){ val x=arr.getJSONObject(i); items += AnalysisFeedItemDto(x.optString("symbol"),x.optString("market"),x.optString("timeframe"),x.optDouble("confidence"),x.optString("state"),x.optString("direction"),x.optString("summary"),x.optString("report_id"),x.optLong("generated_at"),x.optString("feedback_state"),x.optString("feedback_summary")) }
                Result.success(AnalysisFeedDto(items, root.optLong("generated_at"), root.optString("data_quality")))
            }
        } catch(e:Exception){ Result.failure(e) }
    }

    suspend fun fetchProviderHealth(): Result<List<ProviderHealthDto>> = withContext(Dispatchers.IO) {
        try {
            val url = "${ApiConfig.baseUrl.trimEnd('/')}/api/v1/providers/health"
            client.newCall(Request.Builder().url(url).get().build()).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                val arr = org.json.JSONArray(resp.body?.string().orEmpty())
                val out = mutableListOf<ProviderHealthDto>()
                for (i in 0 until arr.length()) {
                    val x = arr.optJSONObject(i) ?: continue
                    out += ProviderHealthDto(x.optString("name", "provider"), x.optBoolean("available", false), x.optString("status", "unknown"), x.optString("message", ""))
                }
                Result.success(out)
            }
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun fetchMarketCoverage(): Result<MarketCoverageDto> = withContext(Dispatchers.IO) {
        try {
            val url = "${ApiConfig.baseUrl.trimEnd('/')}/api/v1/markets/coverage"
            client.newCall(Request.Builder().url(url).get().build()).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                val root = JSONObject(resp.body?.string().orEmpty())
                val counts = mutableMapOf<String, Int>()
                val statuses = mutableMapOf<String, String>()
                root.optJSONObject("markets")?.let { o ->
                    o.keys().forEach { k ->
                        val item = o.optJSONObject(k) ?: JSONObject()
                        counts[k] = item.optInt("count", 0)
                        statuses[k] = if (item.optBoolean("realtime", false)) "realtime" else item.optString("quote_note", item.optString("universe", "configured"))
                    }
                }
                Result.success(MarketCoverageDto(counts.values.sum(), counts, statuses))
            }
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun fetchMarketDataStatus(): Result<List<MarketDataStatusDto>> = withContext(Dispatchers.IO) {
        try {
            val url = "${ApiConfig.baseUrl.trimEnd('/')}/api/v1/markets/data-status"
            client.newCall(Request.Builder().url(url).get().build()).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                val root = JSONObject(resp.body?.string().orEmpty())
                val obj = root.optJSONObject("providers") ?: JSONObject()
                val out = mutableListOf<MarketDataStatusDto>()
                obj.keys().forEach { market ->
                    val x = obj.optJSONObject(market) ?: JSONObject()
                    out += MarketDataStatusDto(
                        market,
                        if (x.optBoolean("configured", false)) "configured" else "provider_required",
                        x.optString("quotes", x.optString("universe", "unknown")),
                        x.optBoolean("realtime", false),
                        x.optString("missing", "")
                    )
                }
                Result.success(out)
            }
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun fetchMarketCapabilities(): Result<List<MarketCapabilityDto>> = withContext(Dispatchers.IO) {
        try {
            val url = "${ApiConfig.baseUrl.trimEnd('/')}/api/v1/market-capabilities"
            client.newCall(Request.Builder().url(url).get().build()).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                val root = JSONObject(resp.body?.string().orEmpty())
                val obj = root.optJSONObject("markets") ?: JSONObject()
                val out = mutableListOf<MarketCapabilityDto>()
                obj.keys().forEach { market ->
                    val x = obj.optJSONObject(market) ?: JSONObject()
                    val capabilities = buildList {
                        x.keys().forEach { key -> if (key !in setOf("market", "status", "quality", "missing", "provider", "universe")) { if (x.optBoolean(key, false)) add(key) } }
                    }
                    val missing = mutableListOf<String>()
                    x.optJSONArray("missing")?.let { a -> for (j in 0 until a.length()) missing += a.optString(j) }
                    out += MarketCapabilityDto(
                        market,
                        x.optString("status") == "available",
                        x.optBoolean("realtime", false),
                        capabilities, missing, x.optString("provider")
                    )
                }
                Result.success(out)
            }
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun fetchAnalysisFeedback(symbol: String, market: String, timeframe: String): Result<AnalysisFeedbackDto> = withContext(Dispatchers.IO) {
        try {
            val url="${ApiConfig.baseUrl.trimEnd('/')}/api/v1/analysis-feedback/${java.net.URLEncoder.encode(symbol, "UTF-8")}?market=${java.net.URLEncoder.encode(market, "UTF-8")}&timeframe=${java.net.URLEncoder.encode(timeframe, "UTF-8")}"
            client.newCall(Request.Builder().url(url).get().build()).execute().use { resp ->
                if(!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                val root=JSONObject(resp.body?.string().orEmpty()); val arr=root.optJSONArray("history") ?: org.json.JSONArray(); val h=mutableListOf<FeedbackHistoryDto>()
                for(i in 0 until arr.length()){ val x=arr.getJSONObject(i); h += FeedbackHistoryDto(x.optString("report_id"),x.optLong("generated_at"),x.optString("direction"),x.optDouble("confidence"),x.optString("state"),x.optString("feedback_state"),x.optString("feedback_summary"),x.optDoubleOrNull("price_at_report"),x.optDoubleOrNull("current_price")) }
                Result.success(AnalysisFeedbackDto(xSymbol=root.optString("symbol",symbol), market=root.optString("market",market), timeframe=root.optString("timeframe",timeframe), currentState=root.optString("current_state"), currentSummary=root.optString("current_summary"), history=h))
            }
        } catch(e:Exception){ Result.failure(e) }
    }

}
