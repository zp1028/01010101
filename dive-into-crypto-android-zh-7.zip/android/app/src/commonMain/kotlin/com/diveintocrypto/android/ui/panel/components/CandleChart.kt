package com.diveintocrypto.android.ui.panel.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.heightIn
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.input.pointer.pointerInput
import com.diveintocrypto.android.domain.math.Series
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.diveintocrypto.android.domain.cvd.CvdBucket
import com.diveintocrypto.android.domain.model.Candle
import com.diveintocrypto.android.engine.analytics.VolCone
import com.diveintocrypto.android.platform.format
import com.diveintocrypto.android.ui.panel.ALL_TIMEFRAMES
import com.diveintocrypto.android.ui.panel.PanelUiState
import com.diveintocrypto.android.ui.theme.DiveColors
import com.diveintocrypto.android.ui.theme.DiveFonts
import com.diveintocrypto.android.ui.common.UiLabels
import kotlin.math.abs

/**
 * Panel candlestick chart — Depth Terminal aesthetic on a Compose Canvas:
 *   - green/red candles with wicks ([DiveColors.Green] / [DiveColors.Red])
 *   - EMA20 + EMA50 polylines ([DiveColors.Accent] / [DiveColors.Accent2];
 *     null warm-up values split each polyline into honest segments)
 *   - Bollinger band as a translucent fill between [PanelUiState.bbUpper]/[bbLower]
 *   - hairline grid + corner brackets, right-edge price axis (last · max · min,
 *     monospace = tabular numerics)
 *   - volume bars along the bottom at low opacity, direction-tinted
 *   - last-price dashed line + accent pill
 *   - CVD per-minute delta mini-histogram strip below (buy green / sell red)
 *
 * HONESTY: no candles → an explicit "无数据 — 刷新" state; a failed CVD
 * fetch says so instead of drawing fabricated zeros. All scale math lives in
 * the pure, unit-tested [ChartMath]. Landscape simply stretches (fit width).
 */

/** Upper bound on rendered candles — the viewport stays readable when the engine hands over more. */
private const val MAX_BARS = 150

@Composable
fun CandleChartCard(
    state: PanelUiState,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier,
    cone: VolCone.ConeEnv? = null,
    onTimeframeSelected: ((String) -> Unit)? = null,
) {
    DiveCard(
        title = "${state.activeSymbol} · ${state.timeframe.uppercase()} · 价格",
        modifier = modifier,
    ) {
        // 时间周期切换（写入 container.activeTimeframe → PanelViewModel 自动重拉数据）
        if (onTimeframeSelected != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                ALL_TIMEFRAMES.forEach { tf ->
                    val active = tf.equals(state.timeframe, ignoreCase = true)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (active) DiveColors.Accent else DiveColors.BgCardHover)
                            .border(
                                1.dp,
                                if (active) DiveColors.Accent else DiveColors.Border,
                                RoundedCornerShape(6.dp),
                            )
                            .clickable { onTimeframeSelected(tf) }
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                    ) {
                        Text(
                            text = tf.uppercase(),
                            color = if (active) Color.White else DiveColors.TextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = DiveFonts.body,
                        )
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
        if (state.chartCandles.isEmpty()) {
            // Honest empty state — no fabricated placeholder candles.
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(DiveColors.BgCardHover)
                    .clickable { onRefresh() },
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = "无数据 — 刷新",
                    color = DiveColors.Warn,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = DiveFonts.body,
                )
            }
            return@DiveCard
        }

        // 指标显隐（点击切换）
        var showEma20 by remember { mutableStateOf(true) }
        var showEma50 by remember { mutableStateOf(true) }
        var showBb by remember { mutableStateOf(true) }
        var showSma200 by remember { mutableStateOf(true) }
        var showMacd by remember { mutableStateOf(false) }
        var showVol by remember { mutableStateOf(true) }
        var showCone by remember { mutableStateOf(cone != null) }
        var showCvd by remember { mutableStateOf(true) }
        var showStructure by remember { mutableStateOf(true) }

        // 缩放 / 平移：scale≥1 放大（可见 K 线更少），panBars 从右端向左偏移
        var scale by remember { mutableFloatStateOf(1f) }
        var panBars by remember { mutableFloatStateOf(0f) }

        IndicatorToggleRow(
            items = buildList {
                add(IndicatorToggle("均线20", showEma20) { showEma20 = !showEma20 })
                add(IndicatorToggle("均线50", showEma50) { showEma50 = !showEma50 })
                add(IndicatorToggle("布林带", showBb) { showBb = !showBb })
                add(IndicatorToggle("均线200", showSma200) { showSma200 = !showSma200 })
                add(IndicatorToggle("MACD", showMacd) { showMacd = !showMacd })
                add(IndicatorToggle("量能", showVol) { showVol = !showVol })
                add(IndicatorToggle("结构", showStructure) { showStructure = !showStructure })
                add(IndicatorToggle("资金流", showCvd) { showCvd = !showCvd })
                if (cone != null) add(IndicatorToggle("波动锥", showCone) { showCone = !showCone })
            },
        )
        Text(
            text = "双指缩放 · 拖动平移 · 点「复位」恢复 · 点标签显隐 · 结构含突破/转换",
            color = DiveColors.TextDim,
            fontSize = 9.sp,
            fontFamily = DiveFonts.body,
        )

        Spacer(Modifier.height(6.dp))

        // Tail window: candles AND overlays are sliced to the same LAST n bars
        val n = minOf(state.chartCandles.size, MAX_BARS)
        val candlesFull = state.chartCandles.takeLast(n)
        val ema20Full = state.ema20.takeLast(n).let { if (it.size < n) List(n - it.size) { null } + it else it }
        val ema50Full = state.ema50.takeLast(n).let { if (it.size < n) List(n - it.size) { null } + it else it }
        val bbUpperFull = state.bbUpper.takeLast(n).let { if (it.size < n) List(n - it.size) { null } + it else it }
        val bbLowerFull = state.bbLower.takeLast(n).let { if (it.size < n) List(n - it.size) { null } + it else it }
        val closes = candlesFull.map { it.close }
        val sma200Full = remember(candlesFull) { Series.rollingMean(closes, 200.coerceAtMost(closes.size.coerceAtLeast(1))) }
        val macdPack = remember(candlesFull) { computeMacd(closes) }
        val swings = remember(candlesFull) { computeSwingPoints(candlesFull, leftRight = 3) }
        val structureEvents = remember(candlesFull) { computeStructureEvents(candlesFull, leftRight = 3) }

        val visibleCount = (n / scale).toInt().coerceIn(20, n.coerceAtLeast(20))
        val maxPan = (n - visibleCount).coerceAtLeast(0).toFloat()
        val panClamped = panBars.coerceIn(0f, maxPan)
        val end = n - panClamped.toInt()
        val start = (end - visibleCount).coerceAtLeast(0)
        val endExcl = end.coerceIn(start + 1, n)

        fun <T> slice(list: List<T>): List<T> =
            if (list.isEmpty()) list else list.subList(start.coerceAtMost(list.size), endExcl.coerceAtMost(list.size))

        val candles = slice(candlesFull)
        val ema20 = slice(ema20Full)
        val ema50 = slice(ema50Full)
        val bbUpper = slice(bbUpperFull)
        val bbLower = slice(bbLowerFull)
        val sma200 = slice(sma200Full)
        val macdHist = slice(macdPack.hist)
        val macdLine = slice(macdPack.macd)
        val macdSignal = slice(macdPack.signal)
        val deltaSeries = state.deltaSeries
        val cvdUnavailable = state.cvdUnavailable

        val textMeasurer = rememberTextMeasurer()

        // ── Price chart: zoom + pan ──
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp)
                .pointerInput(n) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(1f, 8f)
                        val barW = size.width / visibleCount.coerceAtLeast(1).toFloat()
                        if (barW > 0f) {
                            panBars = (panBars - pan.x / barW).coerceIn(0f, maxPan)
                        }
                    }
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawPriceChart(
                    candles = candles,
                    ema20 = if (showEma20) ema20 else emptyList(),
                    ema50 = if (showEma50) ema50 else emptyList(),
                    bbUpper = if (showBb) bbUpper else emptyList(),
                    bbLower = if (showBb) bbLower else emptyList(),
                    sma200 = if (showSma200) sma200 else emptyList(),
                    swings = if (showStructure) swings.filter { it.index in start until endExcl }.map {
                        it.copy(index = it.index - start)
                    } else emptyList(),
                    structureEvents = if (showStructure) structureEvents.filter { it.index in start until endExcl }.map {
                        it.copy(index = it.index - start)
                    } else emptyList(),
                    cone = if (showCone) cone else null,
                    showVolume = showVol,
                    textMeasurer = textMeasurer,
                )
            }
            // 复位按钮
            Text(
                text = "复位",
                color = DiveColors.Accent,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(6.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(DiveColors.BgCard.copy(alpha = 0.85f))
                    .clickable {
                        scale = 1f
                        panBars = 0f
                    }
                    .padding(horizontal = 8.dp, vertical = 4.dp),
            )
        }

        if (showMacd) {
            Spacer(Modifier.height(6.dp))
            Text(text = "MACD 指标 (12/26/9)", color = DiveColors.TextDim, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = DiveFonts.body)
            Spacer(Modifier.height(2.dp))
            Canvas(modifier = Modifier.fillMaxWidth().height(72.dp)) {
                drawMacdPanel(macdHist, macdLine, macdSignal)
            }
        }

        // ── CONE honest caption (only when the envelope is actually drawn) ──
        if (cone != null) {
            Spacer(Modifier.height(4.dp))
            Text(
                text = UiLabels.CONE_CAPTION,
                color = DiveColors.TextDim,
                fontSize = 9.sp,
                lineHeight = 12.sp,
                fontFamily = DiveFonts.body,
            )
        }

        if (showCvd) {
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "资金流增量",
                color = DiveColors.TextDim,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.8.sp,
                fontFamily = DiveFonts.body,
            )
            Spacer(Modifier.width(8.dp))
            if (cvdUnavailable) {
                Text(
                    text = "无数据（流错误）",
                    color = DiveColors.Warn,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = DiveFonts.body,
                )
            }
        }
        Spacer(Modifier.height(4.dp))

        // ── CVD delta strip (~48dp) ──
        Box(modifier = Modifier.fillMaxWidth().height(48.dp)) {
            if (deltaSeries.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(4.dp))
                        .background(DiveColors.BgCardHover),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = if (cvdUnavailable) "无法获取资金流" else "无资金流数据",
                        color = DiveColors.TextDim,
                        fontSize = 10.sp,
                        fontFamily = DiveFonts.body,
                    )
                }
            } else {
                Canvas(modifier = Modifier.fillMaxSize()) { drawCvdStrip(deltaSeries) }
            }
        }
        } // showCvd
    }
}

@Composable
private fun LegendRow(hasCone: Boolean = false) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        LegendSwatch(color = DiveColors.Accent, label = "均线20")
        LegendSwatch(color = DiveColors.Accent2, label = "均线50")
        LegendSwatch(color = DiveColors.Purple.copy(alpha = 0.30f), label = "布林带", filled = true)
        if (hasCone) {
            LegendSwatch(color = DiveColors.Cyan.copy(alpha = 0.20f), label = "波动锥", filled = true)
        }
    }
}

@Composable
private fun LegendSwatch(color: Color, label: String, filled: Boolean = false) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(width = 12.dp, height = if (filled) 8.dp else 3.dp)
                .clip(RoundedCornerShape(1.dp))
                .background(color),
        )
        Spacer(Modifier.width(4.dp))
        Text(
            text = label,
            color = DiveColors.TextMuted,
            fontSize = 9.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 0.4.sp,
            fontFamily = DiveFonts.body,
        )
    }
}

// ═══════════════════════════════════════════════════════════════════════
// Canvas drawing (pure DrawScope functions — all math via ChartMath)
// ═══════════════════════════════════════════════════════════════════════

private fun DrawScope.drawPriceChart(
    candles: List<Candle>,
    ema20: List<Double?>,
    ema50: List<Double?>,
    bbUpper: List<Double?>,
    bbLower: List<Double?>,
    sma200: List<Double?> = emptyList(),
    swings: List<SwingPoint> = emptyList(),
    structureEvents: List<StructureEvent> = emptyList(),
    cone: VolCone.ConeEnv?,
    showVolume: Boolean = true,
    textMeasurer: TextMeasurer,
) {
    if (candles.isEmpty()) return
    val n = candles.size

    val labelW = 52.dp.toPx()
    val topPad = 6.dp.toPx()
    val plotRight = size.width - labelW
    val priceTop = topPad
    val priceBottom = size.height * 0.80f
    val volTop = size.height * 0.84f
    val volBottom = size.height - 2.dp.toPx()

    val range = ChartMath.chartPriceRange(candles, bbUpper, bbLower)
    fun yOf(v: Double): Float = ChartMath.scaleY(v, range, priceTop, priceBottom)
    fun xCenter(i: Int): Float = plotRight * (i + 0.5f) / n

    // ── HAIRLINE grid: min / mid / max ────────────────────────────
    listOf(range.min, (range.min + range.max) / 2.0, range.max).forEach { v ->
        val y = yOf(v)
        drawLine(DiveColors.Border, Offset(0f, y), Offset(plotRight, y), strokeWidth = 1f)
    }

    // ── CONE ±envelope bands (anchored on the LAST close) ─────────
    // Inner band = ±envLowPct, outer = ±envHighPct — the 24h log-normal
    // expected-move envelope P0·exp(±σ√24) as % of the last close.
    // Percentile-free by construction: these are historical-σ projections,
    // NOT probability bands — the caption below the chart says exactly that.
    if (cone != null) {
        val last = candles.last().close
        if (last > 0.0) {
            fun band(lowPct: Double?, highPct: Double?, alpha: Float) {
                val loPct = lowPct ?: return
                val hiPct = highPct ?: return
                val upper = last * (1.0 + hiPct / 100.0)
                val lower = last * (1.0 - loPct / 100.0)
                val yU = yOf(upper).coerceIn(priceTop, priceBottom)
                val yL = yOf(lower).coerceIn(priceTop, priceBottom)
                if (yL - yU >= 1f) {
                    drawRect(
                        DiveColors.Cyan.copy(alpha = alpha),
                        topLeft = Offset(0f, yU),
                        size = Size(plotRight, yL - yU),
                    )
                    drawLine(
                        DiveColors.Cyan.copy(alpha = (alpha + 0.35f).coerceAtMost(1f)),
                        Offset(0f, yU), Offset(plotRight, yU), strokeWidth = 1f,
                    )
                    drawLine(
                        DiveColors.Cyan.copy(alpha = (alpha + 0.35f).coerceAtMost(1f)),
                        Offset(0f, yL), Offset(plotRight, yL), strokeWidth = 1f,
                    )
                }
            }
            // Outer envelope first (behind), inner on top.
            band(cone.envLowPct, cone.envHighPct, alpha = 0.07f)
            band(cone.envLowPct, cone.envLowPct, alpha = 0.10f)

            // σ label — top-left, honest (√t projection from trailing σ1h).
            val sigmaText = "σ1h ${cone.sigma1hPct.format(2)}% · 24h ±${cone.vol24hPct.format(2)}%"
            val layout = textMeasurer.measure(
                sigmaText,
                TextStyle(color = DiveColors.Cyan, fontSize = 9.sp, fontFamily = DiveFonts.Mono),
            )
            drawText(textLayoutResult = layout, topLeft = Offset(6.dp.toPx(), priceTop + 2.dp.toPx()))
        }
    }

    // ── Bollinger band translucent fill (null warm-up → skip runs) ────
    fun bbValueAt(i: Int): Pair<Double, Double>? {
        val u = bbUpper.getOrNull(i) ?: return null
        val l = bbLower.getOrNull(i) ?: return null
        return u to l
    }
    var bbStart = -1
    fun flushBbRun(endExclusive: Int) {
        if (bbStart < 0 || endExclusive - bbStart < 2) { bbStart = -1; return }
        val path = Path()
        for (i in bbStart until endExclusive) {
            val (u, _) = bbValueAt(i) ?: break
            val x = xCenter(i); val y = yOf(u)
            if (i == bbStart) path.moveTo(x, y) else path.lineTo(x, y)
        }
        for (i in (endExclusive - 1) downTo bbStart) {
            val (_, l) = bbValueAt(i) ?: break
            path.lineTo(xCenter(i), yOf(l))
        }
        path.close()
        drawPath(path, DiveColors.Purple.copy(alpha = 0.10f))
        bbStart = -1
    }
    for (i in 0 until n) {
        if (bbValueAt(i) != null) { if (bbStart < 0) bbStart = i } else flushBbRun(i)
    }
    flushBbRun(n)

    // ── Volume bars (bottom strip, low opacity, direction-tinted) ─────
    val maxVol = ChartMath.maxVolume(candles)
    if (showVolume && maxVol > 0.0) {
        val volBarW = ((plotRight / n) * 0.6f).coerceAtLeast(1f)
        candles.forEachIndexed { i, c ->
            if (!c.volume.isFinite() || c.volume <= 0.0) return@forEachIndexed
            val h = (c.volume / maxVol * (volBottom - volTop)).toFloat().coerceAtLeast(1f)
            val up = c.close >= c.open
            val color = (if (up) DiveColors.Green else DiveColors.Red).copy(alpha = 0.30f)
            drawRect(color, Offset(xCenter(i) - volBarW / 2f, volBottom - h), Size(volBarW, h))
        }
    }

    // ── Candles: wick + body ──────────────────────────────────────────
    val bodyW = ((plotRight / n) * 0.6f).coerceIn(1f, 12.dp.toPx())
    candles.forEachIndexed { i, c ->
        val x = xCenter(i)
        val up = c.close >= c.open
        val color = if (up) DiveColors.Green else DiveColors.Red
        drawLine(color, Offset(x, yOf(c.high)), Offset(x, yOf(c.low)), strokeWidth = 1f)
        val bodyTop = yOf(maxOf(c.open, c.close))
        val bodyBottom = yOf(minOf(c.open, c.close))
        val bodyH = (bodyBottom - bodyTop).coerceAtLeast(1f)
        drawRect(color, Offset(x - bodyW / 2f, bodyTop), Size(bodyW, bodyH))
    }

    // ── EMA polylines (contiguous non-null runs — null warm-up skips) ─
    fun drawSeries(values: List<Double?>, color: Color, strokeWidth: Float) {
        var start = -1
        fun flush(endExclusive: Int) {
            if (start < 0 || endExclusive - start < 2) { start = -1; return }
            val path = Path()
            for (i in start until endExclusive) {
                val v = values.getOrNull(i) ?: break
                val x = xCenter(i); val y = yOf(v)
                if (i == start) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, color, style = Stroke(width = strokeWidth))
            start = -1
        }
        for (i in 0 until n) {
            if (values.getOrNull(i) != null) { if (start < 0) start = i } else flush(i)
        }
        flush(n)
    }
    drawSeries(ema20, DiveColors.Accent, 1.5.dp.toPx())
    drawSeries(ema50, DiveColors.Accent2, 1.5.dp.toPx())
    drawSeries(sma200, DiveColors.Yellow, 2.dp.toPx())
    // 简化结构：摆动高低点水平线（SMC 全量移植过重，仅参考高低结构）
    swings.forEach { sw ->
        if (sw.index !in 0 until n) return@forEach
        val y = yOf(sw.price)
        val color = if (sw.isHigh) DiveColors.Red.copy(alpha = 0.55f) else DiveColors.Green.copy(alpha = 0.55f)
        drawLine(color, Offset(0f, y), Offset(plotRight, y), strokeWidth = 1f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 6f)))
    }
    // 简化 BOS / CHoCH 中文标签
    structureEvents.forEach { ev ->
        if (ev.index !in 0 until n) return@forEach
        val x = xCenter(ev.index)
        val y = yOf(ev.price).coerceIn(priceTop + 4.dp.toPx(), priceBottom - 4.dp.toPx())
        val bull = ev.kind == StructureKind.BOS_UP || ev.kind == StructureKind.CHOCH_UP
        val color = if (bull) DiveColors.Green else DiveColors.Red
        val label = when (ev.kind) {
            StructureKind.BOS_UP -> "结构突破·多"
            StructureKind.BOS_DOWN -> "结构突破·空"
            StructureKind.CHOCH_UP -> "结构转换·多"
            StructureKind.CHOCH_DOWN -> "结构转换·空"
        }
        val layout = textMeasurer.measure(
            text = label,
            style = TextStyle(
                color = color,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
            ),
        )
        val lx = (x - layout.size.width / 2f).coerceIn(0f, plotRight - layout.size.width)
        val ly = if (bull) (y - layout.size.height - 4.dp.toPx()).coerceAtLeast(priceTop) else (y + 4.dp.toPx()).coerceAtMost(priceBottom - layout.size.height)
        drawRect(
            color = DiveColors.BgCard.copy(alpha = 0.85f),
            topLeft = Offset(lx - 2.dp.toPx(), ly - 1.dp.toPx()),
            size = Size(layout.size.width + 4.dp.toPx(), layout.size.height + 2.dp.toPx()),
        )
        drawText(textLayoutResult = layout, topLeft = Offset(lx, ly))
        // 突破位置短竖线
        drawLine(color, Offset(x, y - 6.dp.toPx()), Offset(x, y + 6.dp.toPx()), strokeWidth = 2f)
    }

    // ── Last-price dashed line ────────────────────────────────────────
    val last = candles.last().close
    val lastY = yOf(last).coerceIn(priceTop, priceBottom)
    drawLine(
        color = DiveColors.Accent.copy(alpha = 0.75f),
        start = Offset(0f, lastY),
        end = Offset(plotRight, lastY),
        strokeWidth = 1f,
        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f)),
    )

    // ── Right-edge price axis: last (pill) · max · min (tabular numerics) ─
    val decimals = ChartMath.axisDecimals(range)
    val axisStyle = TextStyle(
        color = DiveColors.TextMuted,
        fontSize = 9.sp,
        fontFamily = DiveFonts.Mono, // monospace = tabular numerics
    )
    fun drawAxisLabel(text: String, y: Float, accent: Boolean) {
        val layout = textMeasurer.measure(text, axisStyle)
        val ly = (y - layout.size.height / 2f).coerceIn(0f, size.height - layout.size.height)
        if (accent) {
            drawRoundRect(
                color = DiveColors.Accent,
                topLeft = Offset(plotRight + 2.dp.toPx(), ly - 2.dp.toPx()),
                size = Size(labelW - 4.dp.toPx(), layout.size.height + 4.dp.toPx()),
                cornerRadius = CornerRadius(3.dp.toPx()),
            )
        }
        drawText(textLayoutResult = layout, topLeft = Offset(plotRight + 4.dp.toPx(), ly))
    }
    drawAxisLabel(ChartMath.formatAxisPrice(range.max, decimals), priceTop, accent = false)
    drawAxisLabel(ChartMath.formatAxisPrice(range.min, decimals), priceBottom, accent = false)
    drawAxisLabel(ChartMath.formatAxisPrice(last, decimals), lastY, accent = true)

    // ── Depth Terminal corner brackets ────────────────────────────────
    val arm = 10.dp.toPx()
    val inset = 1f
    fun bracket(cx: Float, cy: Float, dx: Float, dy: Float) {
        drawLine(DiveColors.BorderStrong, Offset(cx, cy), Offset(cx + dx * arm, cy), strokeWidth = 1f)
        drawLine(DiveColors.BorderStrong, Offset(cx, cy), Offset(cx, cy + dy * arm), strokeWidth = 1f)
    }
    bracket(inset, inset, 1f, 1f)
    bracket(plotRight - inset, inset, -1f, 1f)
    bracket(inset, size.height - inset, 1f, -1f)
    bracket(plotRight - inset, size.height - inset, -1f, -1f)
}

private fun DrawScope.drawCvdStrip(buckets: List<CvdBucket>) {
    if (buckets.isEmpty()) return
    val maxAbs = ChartMath.maxAbsDelta(buckets)
    if (maxAbs <= 0.0) return
    val midY = size.height / 2f
    drawLine(DiveColors.Border, Offset(0f, midY), Offset(size.width, midY), strokeWidth = 1f)
    val slot = size.width / buckets.size
    val barW = (slot * 0.7f).coerceAtLeast(1f)
    val halfArea = size.height / 2f - 2.dp.toPx()
    buckets.forEachIndexed { i, b ->
        if (!b.delta.isFinite() || b.delta == 0.0) return@forEachIndexed
        val h = (abs(b.delta) / maxAbs * halfArea).toFloat().coerceAtLeast(1f)
        val x = i * slot + (slot - barW) / 2f
        val color = if (b.delta > 0) DiveColors.Green.copy(alpha = 0.8f) else DiveColors.Red.copy(alpha = 0.8f)
        drawRect(color, Offset(x, if (b.delta > 0) midY - h else midY), Size(barW, h))
    }
}



private data class IndicatorToggle(
    val label: String,
    val on: Boolean,
    val onClick: () -> Unit,
)

@Composable
private fun IndicatorToggleRow(items: List<IndicatorToggle>) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        items.forEach { item ->
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (item.on) DiveColors.Accent.copy(alpha = 0.2f) else DiveColors.BgCardHover)
                    .border(1.dp, if (item.on) DiveColors.Accent else DiveColors.Border, RoundedCornerShape(6.dp))
                    .clickable(onClick = item.onClick)
                    .padding(horizontal = 8.dp, vertical = 5.dp),
            ) {
                Text(
                    text = item.label,
                    color = if (item.on) DiveColors.Accent else DiveColors.TextMuted,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = DiveFonts.body,
                )
            }
        }
    }
}

private data class MacdPack(
    val macd: List<Double?>,
    val signal: List<Double?>,
    val hist: List<Double?>,
)

/** ChartArt 风格：SMA(12)-SMA(26) 为 MACD，再 SMA(9) 为信号线。 */
private fun computeMacd(closes: List<Double>): MacdPack {
    if (closes.isEmpty()) return MacdPack(emptyList(), emptyList(), emptyList())
    val fast = Series.rollingMean(closes, 12)
    val slow = Series.rollingMean(closes, 26)
    val macd = closes.indices.map { i ->
        val f = fast.getOrNull(i)
        val s = slow.getOrNull(i)
        if (f != null && s != null) f - s else null
    }
    val macdFilled = macd.map { it ?: 0.0 }
    // signal only meaningful where macd non-null; still use rolling on filled for length match
    val signalRaw = Series.rollingMean(macdFilled, 9)
    val signal = macd.indices.map { i ->
        if (macd[i] == null || i < 26 + 8) null else signalRaw[i]
    }
    val hist = macd.indices.map { i ->
        val m = macd[i]
        val s = signal[i]
        if (m != null && s != null) m - s else null
    }
    return MacdPack(macd, signal, hist)
}

private data class SwingPoint(val index: Int, val price: Double, val isHigh: Boolean)

/** 简化摆动点（非完整 LuxAlgo SMC）：左右各 lookback 根更高/更低。 */


private enum class StructureKind { BOS_UP, BOS_DOWN, CHOCH_UP, CHOCH_DOWN }

private data class StructureEvent(val index: Int, val price: Double, val kind: StructureKind)

/**
 * 简化 BOS/CHoCH：
 * 1) 用摆动高低点推断结构偏向（高点抬高+低点抬高→多；相反→空）
 * 2) 收盘价顺势突破最近摆动高/低 → 结构突破（BOS）
 * 3) 收盘价逆势跌破/升破关键摆动低/高 → 结构转换（CHoCH），并翻转偏向
 * 仅图表展示，不进入扫描/共识得分。
 */
private fun computeStructureEvents(candles: List<Candle>, leftRight: Int = 3): List<StructureEvent> {
    if (candles.size < leftRight * 2 + 5) return emptyList()
    val swings = computeSwingPoints(candles, leftRight)
    if (swings.size < 2) return emptyList()

    val events = mutableListOf<StructureEvent>()
    var bias = 0 // +1 多 / -1 空
    var lastHigh: SwingPoint? = null
    var lastLow: SwingPoint? = null
    var highBroken = false
    var lowBroken = false

    val confirmedAt = HashMap<Int, MutableList<SwingPoint>>()
    for (sw in swings) {
        val conf = (sw.index + leftRight).coerceAtMost(candles.lastIndex)
        confirmedAt.getOrPut(conf) { mutableListOf() }.add(sw)
    }

    fun recomputeBias() {
        val h = lastHigh ?: return
        val l = lastLow ?: return
        // 用「当前高低」与更早的同侧摆动比较
        val earlierHighs = swings.filter { it.isHigh && it.index < h.index }
        val earlierLows = swings.filter { !it.isHigh && it.index < l.index }
        val prevH = earlierHighs.lastOrNull()
        val prevL = earlierLows.lastOrNull()
        bias = when {
            prevH != null && prevL != null && h.price > prevH.price && l.price > prevL.price -> 1
            prevH != null && prevL != null && h.price < prevH.price && l.price < prevL.price -> -1
            prevH != null && h.price > prevH.price -> 1
            prevH != null && h.price < prevH.price -> -1
            prevL != null && l.price > prevL.price -> 1
            prevL != null && l.price < prevL.price -> -1
            else -> bias
        }
    }

    for (i in candles.indices) {
        confirmedAt[i]?.forEach { sw ->
            if (sw.isHigh) {
                lastHigh = sw
                highBroken = false
            } else {
                lastLow = sw
                lowBroken = false
            }
            recomputeBias()
        }
        if (bias == 0) continue
        val close = candles[i].close
        val lh = lastHigh
        val ll = lastLow
        if (bias > 0) {
            if (lh != null && !highBroken && i > lh.index + leftRight && close > lh.price) {
                events.add(StructureEvent(i, lh.price, StructureKind.BOS_UP))
                highBroken = true
            }
            if (ll != null && !lowBroken && i > ll.index + leftRight && close < ll.price) {
                events.add(StructureEvent(i, ll.price, StructureKind.CHOCH_DOWN))
                lowBroken = true
                bias = -1
            }
        } else if (bias < 0) {
            if (ll != null && !lowBroken && i > ll.index + leftRight && close < ll.price) {
                events.add(StructureEvent(i, ll.price, StructureKind.BOS_DOWN))
                lowBroken = true
            }
            if (lh != null && !highBroken && i > lh.index + leftRight && close > lh.price) {
                events.add(StructureEvent(i, lh.price, StructureKind.CHOCH_UP))
                highBroken = true
                bias = 1
            }
        }
    }
    return events.takeLast(10)
}

private fun computeSwingPoints(candles: List<Candle>, leftRight: Int = 3): List<SwingPoint> {
    if (candles.size < leftRight * 2 + 1) return emptyList()
    val out = mutableListOf<SwingPoint>()
    for (i in leftRight until candles.size - leftRight) {
        val h = candles[i].high
        val l = candles[i].low
        var isHigh = true
        var isLow = true
        for (j in 1..leftRight) {
            if (candles[i - j].high >= h || candles[i + j].high >= h) isHigh = false
            if (candles[i - j].low <= l || candles[i + j].low <= l) isLow = false
        }
        if (isHigh) out.add(SwingPoint(i, h, true))
        if (isLow) out.add(SwingPoint(i, l, false))
    }
    // 只保留最近若干个，避免过密
    return out.takeLast(12)
}

private fun DrawScope.drawMacdPanel(
    hist: List<Double?>,
    macd: List<Double?>,
    signal: List<Double?>,
) {
    val n = maxOf(hist.size, 1)
    val vals = hist.mapNotNull { it } + macd.mapNotNull { it } + signal.mapNotNull { it }
    if (vals.isEmpty()) return
    val maxAbs = vals.maxOf { kotlin.math.abs(it) }.coerceAtLeast(1e-9)
    val mid = size.height / 2f
    drawLine(DiveColors.Border, Offset(0f, mid), Offset(size.width, mid), strokeWidth = 1f)
    val slot = size.width / n
    val barW = (slot * 0.65f).coerceAtLeast(1f)
    hist.forEachIndexed { i, h ->
        if (h == null) return@forEachIndexed
        val hh = (kotlin.math.abs(h) / maxAbs * (mid - 2.dp.toPx())).toFloat().coerceAtLeast(1f)
        val color = if (h >= 0) DiveColors.Green.copy(alpha = 0.7f) else DiveColors.Red.copy(alpha = 0.7f)
        val x = i * slot + (slot - barW) / 2f
        drawRect(color, Offset(x, if (h >= 0) mid - hh else mid), Size(barW, hh))
    }
    fun drawLineSeries(series: List<Double?>, color: Color) {
        var started = false
        val path = Path()
        series.forEachIndexed { i, v ->
            if (v == null) {
                started = false
                return@forEachIndexed
            }
            val x = i * slot + slot / 2f
            val y = mid - (v / maxAbs * (mid - 2.dp.toPx())).toFloat()
            if (!started) {
                path.moveTo(x, y)
                started = true
            } else path.lineTo(x, y)
        }
        drawPath(path, color, style = Stroke(width = 1.5.dp.toPx()))
    }
    drawLineSeries(macd, DiveColors.Accent)
    drawLineSeries(signal, DiveColors.Accent2)
}

