# ======================== 彩析自动点击 ProGuard 规则 ========================

# ---- 通用 ----
-keepattributes *Annotation*, InnerClasses, Signature, Exceptions, EnclosingMethod
-dontnote kotlinx.serialization.AnnotationsKt

# ---- Kotlinx Serialization ----
-keepattributes RuntimeVisibleAnnotations,AnnotationDefault
-keep,includedescriptorclasses class com.caifenxi.app.**$$serializer { *; }
-keepclassmembers class com.caifenxi.app.** {
    *** Companion;
}
-keepclasseswithmembers class com.caifenxi.app.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# ---- Room ----
-keep class com.caifenxi.app.data.db.entity.** { *; }
-keep class com.caifenxi.app.data.db.dao.** { *; }
-keep class * extends androidx.room.RoomDatabase { *; }
-keep @androidx.room.Entity class * { *; }
-dontwarn androidx.room.paging.**

# ---- Compose ----
-dontwarn androidx.compose.**
-keep class androidx.compose.** { *; }

# ---- OkHttp ----
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn org.conscrypt.**
-keep class okhttp3.** { *; }
-keep interface okhttp3.** { *; }

# ---- App 核心类 ----
-keep class com.caifenxi.app.CaiFenXiApplication { *; }
-keep class com.caifenxi.app.MainActivity { *; }
-keep class com.caifenxi.app.service.** { *; }
-keep class com.caifenxi.app.data.api.** { *; }
-keep class com.caifenxi.app.domain.** { *; }

# ---- WebView JS 注入接口 ----
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# ---- Accessibility Service ----
-keep class * extends android.accessibilityservice.AccessibilityService { *; }

# ---- Kotlin Metadata ----
-keep class kotlin.Metadata { *; }
