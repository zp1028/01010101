package com.caifenxi.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.LotteryConfig
import com.caifenxi.app.domain.model.positionDisplayName
import com.caifenxi.app.domain.model.positionIndexOf
import com.caifenxi.app.domain.model.LotteryType
import com.caifenxi.app.domain.strategy.PredictEngineV2
import com.caifenxi.app.domain.strategy.StrategyAnalytics
import com.caifenxi.app.domain.strategy.StrategyBacktestReport
import com.caifenxi.app.domain.strategy.StrategyChartPoint
import com.caifenxi.app.domain.strategy.StrategyDefinition
import com.caifenxi.app.domain.strategy.StrategyEngine
import com.caifenxi.app.domain.strategy.StrategyPool
import com.caifenxi.app.domain.strategy.StrategyTrack
import androidx.navigation.NavHostController
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PageHeader
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.components.SectionTitle
import com.caifenxi.app.ui.components.StaggeredEntrance
import com.caifenxi.app.ui.components.UiFormat
import com.caifenxi.app.ui.theme.CaiTokens
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

@Composable
fun StrategyPoolScreen(vm: MainViewModel, navController: NavHostController? = null) {
    val history = vm.history.value
    val lottery = vm.currentLottery.value
    val lotType = lottery.type
    val lotKey = lottery.key
    val scope = rememberCoroutineScope()

    val engine = vm.strategyEngine
    val availablePlans = remember(lotType) { StrategyPool.forLotteryType(lotType) }
    val subscribedPlans = engine.subscribedPlans.collectAsState()
    val backtestReports = engine.backtestReports.collectAsState()
    val currentPredictions = engine.currentPredictions.collectAsState()
    val runtimeMap = engine.runtimeMap.collectAsState()

    var selectedTrack by remember { mutableStateOf(StrategyTrack.TRACK_A) }
    var selectedStage by remember { mutableStateOf(1) }
    var backtestPeriods by remember { mutableStateOf(200) }
    var backtestStake by remember { mutableStateOf("10") }
    var chartMode by remember { mutableStateOf("累计收益") }
    var running by remember { mutableStateOf(false) }
    var selectedPlanId by remember { mutableStateOf<String?>(null) }
    var chartDetail by remember { mutableStateOf<StrategyChartPoint?>(null) }
    var algoWindow by remember { mutableStateOf(0) }        // 0=用plan默认
    var winRateWindow by remember { mutableStateOf(20) }    // 窗口胜率统计窗口

    val trackPlans = remember(selectedTrack, lotType) {
        availablePlans.filter { it.track == selectedTrack }
    }

    LaunchedEffect(selectedTrack) {
        selectedPlanId = trackPlans.firstOrNull()?.planId
    }

    fun runBacktest() {
        val planId = selectedPlanId ?: return
        val plan = StrategyPool.byId(planId) ?: return
        val stake = backtestStake.toDoubleOrNull() ?: 10.0
        if (history.size < 6) return
        running = true
        scope.launch {
            withContext(Dispatchers.Default) {
                engine.runBacktest(plan, history, backtestPeriods, stake, selectedStage, false, algoWindow, winRateWindow)
                engine.predict(plan, history)
            }
            running = false
        }
    }

    if (chartDetail != null) {
        val pt = chartDetail!!
        AlertDialog(
            onDismissRequest = { chartDetail = null },
            confirmButton = { TextButton(onClick = { chartDetail = null }) { Text("关闭") } },
            title = { Text("回测节点详情") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("期号: ${pt.issue}")
                    Text("预测: ${pt.prediction}")
                    Text("结果: ${if (pt.hit) "对" else "错"}")
                    Text("单期盈亏: ${fmtMoney(pt.periodProfit)}")
                    Text("累计盈亏: ${fmtMoney(pt.cumulativeProfit)}")
                    Text("当时胜率: ${"%.2f".format(pt.hitRate * 100)}%")
                    Text("回撤: ${fmtMoney(pt.drawdown)}")
                }
            }
        )
    }

    LazyColumn(
        Modifier
            .fillMaxSize()
            .padding(horizontal = CaiTokens.ScreenHPadding, vertical = CaiTokens.S12),
        verticalArrangement = Arrangement.spacedBy(CaiTokens.S12),
        contentPadding = PaddingValues(bottom = CaiTokens.ScreenBottom)
    ) {
        item {
            PageHeader(
                title = "策略池",
                lotteryName = lottery.name,
                subtitle = "三轨架构 · 独立引擎 · 数据隔离"
            )
            CaptionMuted(
                "A轨(大小单双贝叶斯融合) · B轨(组合2口互补对冲) · C轨(组合3口排除最弱) " +
                    "· 完全独立于原计划引擎，不修改原有代码"
            )
        }

        // ---- 轨道选择 ----
        item {
            GlobalCard {
                Text("选择轨道", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StrategyTrack.entries.forEach { track ->
                        FilterChip(
                            selected = selectedTrack == track,
                            onClick = { selectedTrack = track },
                            label = { Text(track.label) }
                        )
                    }
                }
                CaptionMuted(selectedTrack.desc)
            }
        }

        // ---- 计划列表 ----
        item {
            SectionTitle("${selectedTrack.label} · 可选计划")
            trackPlans.forEachIndexed { idx, plan ->
                StaggeredEntrance(index = idx) {
                    GlobalCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = CaiTokens.S8)
                            .clickable {
                                selectedPlanId = plan.planId
                                navController?.navigate("strategy_detail/${plan.planId}")
                            }
                    ) {
                        val isSelected = selectedPlanId == plan.planId
                        val isSubscribed = plan.planId in subscribedPlans.value
                        Row(
                            Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    plan.planName,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold
                                )
                                CaptionMuted(
                                    "${plan.playType} · ${plan.algorithm} · ${plan.window}期" +
                                        if (plan.positionIndex >= 0) " · ${positionDisplayName(lottery.type, plan.positionIndex)}" else ""
                                )
                                // 预测输出
                                val pred = currentPredictions.value[plan.planId]
                                if (pred != null) {
                                    Text(
                                        "预测: ${pred.output} (置信度${"%.0f".format(pred.confidence * 100)}%)",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                    CaptionMuted(pred.detail)
                                }
                            }
                            IconButton(onClick = {
                                if (isSubscribed) engine.unsubscribeFromBet(plan.planId)
                                else engine.subscribeToBet(plan.planId)
                            }) {
                                Icon(
                                    if (isSubscribed) Icons.Filled.Star else Icons.Filled.StarBorder,
                                    contentDescription = "挂机订阅",
                                    tint = if (isSubscribed) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // ---- 回测设置 ----
        item {
            GlobalCard {
                Text("回测设置", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))

                ChartFilterLine("回测阶段", listOf("一期", "二期", "三期"), when (selectedStage) { 2 -> "二期"; 3 -> "三期"; else -> "一期" }) { v ->
                    selectedStage = when (v) { "二期" -> 2; "三期" -> 3; else -> 1 }
                }
                ChartFilterLine("回测期数", listOf("100期", "200期", "500期", "1000期", "2000期", "5000期"), "${backtestPeriods}期") { v ->
                    backtestPeriods = v.removeSuffix("期").toInt()
                }
                ChartFilterLine("图表模式", listOf("累计收益", "单期盈亏", "胜率", "回撤"), chartMode) { chartMode = it }
                ChartFilterLine("预测算法窗口", listOf("默认", "100期", "200期", "500期"), if (algoWindow == 0) "默认" else "${algoWindow}期") { v ->
                    algoWindow = if (v == "默认") 0 else v.removeSuffix("期").toInt()
                }
                CaptionMuted("预测算法窗口：贝叶斯融合用最近N期做特征提取（越大越平滑，越小越敏感）")

                TextField(
                    value = backtestStake,
                    onValueChange = { backtestStake = it.filter { c -> c.isDigit() || c == '.' }.take(10) },
                    label = { Text("回测单注金额") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                )

                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PrimaryButton(
                        if (running) "回测中..." else "开始回测",
                        { runBacktest() },
                        Modifier.weight(1f),
                        enabled = !running && selectedPlanId != null && history.size >= 6
                    )
                    OutlinedButton(
                        onClick = { selectedPlanId = null },
                        modifier = Modifier.weight(0.5f)
                    ) { Text("取消选择") }
                }
                if (history.size < 6) {
                    CaptionMuted("历史不足6期，无法回测")
                }
            }
        }

        // ---- 回测报告 + 胜率面板 ----
        val reportKey = "${selectedPlanId}_s${selectedStage}_w${algoWindow}_wr${winRateWindow}"
        val report = backtestReports.value[reportKey]

        if (report != null) {
            // 胜率面板（对齐工作台单一胜率口径）
            item {
                GlobalCard {
                    Text("胜率面板 · ${report.planName} · ${selectedStage}期", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        RateColumn("胜率", report.hitRate)
                        RateColumn("基准", report.baseline)
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        InfoColumn("样本", "${report.total}")
                        InfoColumn("中/错", "${report.hits}/${report.misses}")
                        InfoColumn("Edge", "${"%.1f".format(report.edge * 100)}%")
                        InfoColumn("稳定性", "${"%.0f".format(report.stability * 100)}%")
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        InfoColumn("连中", "${report.currentHitStreak}")
                        InfoColumn("连挂", "${report.currentMissStreak}")
                        InfoColumn("最大连中", "${report.maxHitStreak}")
                        InfoColumn("最大连挂", "${report.maxMissStreak}")
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        InfoColumn("净收益", fmtMoney(report.netProfit))
                        InfoColumn("最大回撤", fmtMoney(report.maxDrawdown))
                        InfoColumn("峰值", fmtMoney(report.peakProfit))
                        InfoColumn("谷值", fmtMoney(report.troughProfit))
                    }
                }
            }

            // 回测曲线图
            item {
                GlobalCard {
                    Text("回测曲线 · $chartMode", fontWeight = FontWeight.Bold)
                    CaptionMuted("绿涨红跌 · 双指缩放 · 轻点查看节点")
                    StrategyChart(report.points, chartMode) { chartDetail = it }
                }
            }
        } else if (!running) {
            item {
                GlobalCard {
                    Text("暂无回测数据", fontWeight = FontWeight.Bold)
                    CaptionMuted("选择计划后点击「开始回测」")
                }
            }
        }

        if (running) {
            item {
                GlobalCard {
                    Row(
                        Modifier.fillMaxWidth().padding(16.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(Modifier.padding(end = 10.dp), strokeWidth = 2.dp)
                        Text("回测计算中...", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        // ---- 挂机互通区 ----
        item {
            GlobalCard {
                Text("挂机互通 · 已订阅计划", fontWeight = FontWeight.Bold)
                CaptionMuted("已订阅的计划会在挂机页面自动生成BetCommand下注")
                val subs = subscribedPlans.value
                if (subs.isEmpty()) {
                    CaptionMuted("点击计划列表中的星标按钮添加到挂机")
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = CaiTokens.S8)) {
                        subs.forEach { planId ->
                            val plan = StrategyPool.byId(planId)
                            if (plan != null) {
                                Row(
                                    Modifier.fillMaxWidth().clickable { selectedPlanId = planId },
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Filled.CheckCircle,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(Modifier.width(6.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(plan.planName, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                        CaptionMuted("${plan.playType} · ${plan.track.label}")
                                    }
                                    TextButton(onClick = { engine.unsubscribeFromBet(planId) }) { Text("取消") }
                                }
                            }
                        }
                    }
                }

                // 预览BetCommand
                if (subs.isNotEmpty() && history.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    val cmds = engine.getBetCommands(history, lotKey, history.lastOrNull()?.nextIssue ?: "", backtestStake.toDoubleOrNull() ?: 10.0, selectedStage)
                    if (cmds.isNotEmpty()) {
                        CaptionMuted("已生成 ${cmds.size} 条下注指令:")
                        cmds.forEach { (plan, cmd) ->
                            Row(Modifier.fillMaxWidth().padding(top = 4.dp)) {
                                Text(
                                    "${plan.planName}: ${cmd.bets.joinToString("、") { it.value }} × ${cmd.amountText}元",
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // ---- 运行时统计 ----
        if (runtimeMap.value.isNotEmpty()) {
            item {
                GlobalCard {
                    Text("运行时统计", fontWeight = FontWeight.Bold)
                    runtimeMap.value.entries.sortedBy { it.key }.forEach { (planId, rt) ->
                        val plan = StrategyPool.byId(planId)
                        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(
                                "${plan?.planName ?: planId} · ${rt.sampleCount}次",
                                fontSize = 12.sp
                            )
                            Text(
                                "命中率 ${rt.hitRatePercent} · 连中${rt.consecutiveHit}/连挂${rt.consecutiveMiss}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }
                }
            }
        }
    }
}

// ==================== Helpers ====================

@Composable
private fun RateColumn(label: String, rate: Double) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            UiFormat.pct(rate),
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            color = when {
                rate >= 0.55 -> Color(0xFF2E7D32)
                rate <= 0.45 -> Color(0xFFC62828)
                else -> MaterialTheme.colorScheme.onSurface
            }
        )
    }
}

@Composable
private fun InfoColumn(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
    }
}

private fun fmtMoney(v: Double): String = if (v >= 0) "+${"%.2f".format(v)}" else "${"%.2f".format(v)}"

// ==================== Strategy Chart (self-contained Canvas) ====================

@Composable
private fun StrategyChart(
    points: List<StrategyChartPoint>,
    mode: String,
    onPointClick: (StrategyChartPoint) -> Unit
) {
    if (points.isEmpty()) {
        Box(Modifier.fillMaxWidth().height(200.dp), contentAlignment = Alignment.Center) {
            Text("无数据", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        return
    }

    val chartHeight = 240.dp
    var scale by remember(points.size, mode) { mutableFloatStateOf(1f) }
    var offsetX by remember(points.size, mode) { mutableFloatStateOf(0f) }
    var offsetY by remember(points.size, mode) { mutableFloatStateOf(0f) }

    val green = Color(0xFF2E7D32)
    val red = Color(0xFFC62828)
    val amber = Color(0xFFF9A825)
    val secondaryColor = MaterialTheme.colorScheme.secondary

    val isHitRateMode = mode == "胜率"
    val baselineValue = if (isHitRateMode) 50.0 else 0.0
    val hitRateCap = 70.0

    val values = remember(points, mode) {
        points.map { p -> chartValueAt(mode, p) }
    }
    val idxs = remember(values) {
        downsampleKeepExtremes(values, 400)
    }

    Column(Modifier.fillMaxWidth()) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(chartHeight)
                .clip(RoundedCornerShape(8.dp))
                .pointerInput(points.size, mode) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        val zooming = abs(zoom - 1f) > 0.01f
                        val panning = pan.getDistance() > 2f
                        if (zooming || panning) {
                            val newScale = (scale * zoom).coerceIn(1f, 3f)
                            val ratio = if (scale > 0f) newScale / scale else 1f
                            scale = newScale
                            if (newScale <= 1.01f) {
                                scale = 1f; offsetX = 0f; offsetY = 0f
                            } else {
                                val maxX = size.width * (newScale - 1f)
                                val maxY = size.height * (newScale - 1f) * 0.35f
                                offsetX = (offsetX * ratio + pan.x).coerceIn(-maxX, maxX)
                                offsetY = (offsetY * ratio + pan.y).coerceIn(-maxY, maxY)
                            }
                        }
                    }
                }
                .pointerInput(points.size, mode) {
                    detectTapGestures { pos ->
                        try {
                            if (idxs.isEmpty() || points.isEmpty()) return@detectTapGestures
                            val w = size.width.coerceAtLeast(1)
                            val idx = ((pos.x / w) * idxs.size).toInt().coerceIn(0, idxs.lastIndex)
                            val pointIdx = idxs[idx].coerceIn(0, points.lastIndex)
                            onPointClick(points[pointIdx])
                        } catch (_: Exception) {}
                    }
                }
        ) {
            Canvas(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        scaleX = scale; scaleY = scale
                        translationX = offsetX; translationY = offsetY
                        transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0.5f, 0.5f)
                    }
            ) {
                if (idxs.isEmpty()) return@Canvas
                val padL = 36f; val padR = 10f; val padT = 14f; val padB = 14f
                val cw = (size.width - padL - padR).coerceAtLeast(1f)
                val ch = (size.height - padT - padB).coerceAtLeast(1f)
                val maxCount = idxs.size.coerceAtLeast(1)

                fun x(i: Int): Float = if (maxCount <= 1) padL + cw / 2f else padL + cw * i / (maxCount - 1)

                val allValues = idxs.map { chartValueAt(mode, points[it]) }
                val modeMin = allValues.minOrNull() ?: baselineValue
                val modeMax = allValues.maxOrNull() ?: baselineValue
                val viewHi: Double
                val viewLo: Double
                if (isHitRateMode) {
                    viewHi = hitRateCap
                    viewLo = minOf(modeMin, 30.0, baselineValue).coerceAtMost(baselineValue - 5.0)
                } else {
                    val modeLo = minOf(baselineValue, modeMin)
                    val modeHi = maxOf(baselineValue, modeMax)
                    val rawRange = (modeHi - modeLo).coerceAtLeast(1e-6)
                    val padValue = rawRange * 0.10
                    viewHi = modeHi + padValue
                    viewLo = modeLo - padValue
                }
                val viewRange = (viewHi - viewLo).coerceAtLeast(1e-6)

                fun y(v: Double): Float {
                    val vv = if (isHitRateMode) v.coerceAtMost(hitRateCap) else v
                    return padT + ch * (((viewHi - vv) / viewRange).toFloat().coerceIn(0f, 1f))
                }

                val zeroY = y(baselineValue)
                val gridColor = Color(0xFFB0B0B0)
                val zeroColor = Color(0xFF666666)

                // grid lines + labels
                val levels = if (isHitRateMode) {
                    listOf(viewLo, 40.0, 50.0, 60.0, 70.0).filter { it in viewLo..viewHi || abs(it - 50.0) < 0.01 }.distinctBy { "%.1f".format(it) }
                } else {
                    listOf(baselineValue, viewLo + viewRange * 0.25, viewLo + viewRange * 0.50, viewLo + viewRange * 0.75, viewHi).distinctBy { "%.4f".format(it) }
                }
                val textPaint = android.graphics.Paint().apply { isAntiAlias = true; textSize = 22f; color = android.graphics.Color.parseColor("#888888") }
                levels.forEach { level ->
                    val yy = y(level)
                    val isBase = abs(level - baselineValue) < 1e-6
                    drawLine(
                        color = if (isBase) zeroColor else gridColor,
                        start = Offset(padL, yy), end = Offset(size.width - padR, yy),
                        strokeWidth = if (isBase) 1.8f else 1.0f,
                        pathEffect = PathEffect.dashPathEffect(if (isBase) floatArrayOf(8f, 6f) else floatArrayOf(4f, 6f))
                    )
                    val label = if (isHitRateMode) "${"%.0f".format(level)}%" else if (abs(level) >= 100) "%.0f".format(level) else "%.1f".format(level)
                    drawContext.canvas.nativeCanvas.drawText(label, 4f, yy + 6f, textPaint)
                }

                // draw line
                if (mode == "累计收益" && idxs.size > 1) {
                    val fillPath = Path()
                    fillPath.moveTo(x(0), zeroY)
                    idxs.forEachIndexed { i, idx -> fillPath.lineTo(x(i), y(chartValueAt(mode, points[idx]))) }
                    fillPath.lineTo(x(idxs.lastIndex), zeroY)
                    fillPath.close()
                    val last = chartValueAt(mode, points[idxs.last()])
                    drawPath(fillPath, color = (if (last >= baselineValue) green else red).copy(alpha = 0.08f))
                }

                for (i in 1 until idxs.size) {
                    val prevV = chartValueAt(mode, points[idxs[i - 1]])
                    val curV = chartValueAt(mode, points[idxs[i]])
                    val c = when {
                        mode == "回撤" -> if (curV >= prevV) red else green
                        isHitRateMode -> if (curV >= prevV) green else red
                        abs(curV - prevV) < 1e-12 -> secondaryColor
                        curV > prevV -> green
                        else -> red
                    }
                    drawLine(c, Offset(x(i - 1), y(prevV)), Offset(x(i), y(curV)), 3.4f, cap = StrokeCap.Round)
                }

                // hi/lo markers
                val hiLocal = idxs.indices.maxByOrNull { chartValueAt(mode, points[idxs[it]]) } ?: -1
                val loLocal = idxs.indices.minByOrNull { chartValueAt(mode, points[idxs[it]]) } ?: -1
                if (hiLocal >= 0) drawCircle(green, 4f, Offset(x(hiLocal), y(chartValueAt(mode, points[idxs[hiLocal]]))))
                if (loLocal >= 0) drawCircle(red, 4f, Offset(x(loLocal), y(chartValueAt(mode, points[idxs[loLocal]]))))

                // max drawdown
                if ((mode == "累计收益" || mode == "回撤")) {
                    val series = idxs.map { chartValueAt(mode, points[it]) }
                    val (peakI, troughI) = findMaxDrawdownPair(series)
                    if (peakI >= 0 && troughI > peakI) {
                        drawLine(amber, Offset(x(peakI), y(series[peakI])), Offset(x(troughI), y(series[troughI])), 2.2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f)))
                        drawCircle(amber, 4f, Offset(x(peakI), y(series[peakI])), style = Stroke(width = 2f))
                        drawCircle(amber, 4f, Offset(x(troughI), y(series[troughI])))
                    }
                }

                // hit/miss dots for small series
                if (idxs.size <= 90) {
                    idxs.forEachIndexed { i, idx ->
                        val hit = points[idx].hit
                        drawCircle(if (hit) green else red, 2.2f, Offset(x(i), y(chartValueAt(mode, points[idx]))))
                    }
                }
            }
        }
        // Summary line
        CaptionMuted(
            if (isHitRateMode) {
                val hi = values.maxOrNull() ?: 0.0
                val lo = values.minOrNull() ?: 0.0
                "胜率 ${"%.0f".format(values.last())}% · 最高 ${"%.0f".format(hi)}% · 最低 ${"%.0f".format(lo)}%"
            } else {
                "最高 ${fmtMoney(points.maxOfOrNull { it.cumulativeProfit } ?: 0.0)} · 最低 ${fmtMoney(points.minOfOrNull { it.cumulativeProfit } ?: 0.0)} · 当前 ${fmtMoney(points.lastOrNull()?.cumulativeProfit ?: 0.0)} · 回撤 ${fmtMoney(points.maxOfOrNull { it.drawdown } ?: 0.0)}"
            }
        )
    }
}

private fun chartValueAt(mode: String, p: StrategyChartPoint): Double = when (mode) {
    "单期盈亏" -> p.periodProfit
    "胜率" -> p.hitRate * 100.0
    "回撤" -> p.drawdown
    else -> p.cumulativeProfit
}

private fun downsampleKeepExtremes(values: List<Double>, maxPoints: Int): List<Int> {
    val n = values.size
    if (n <= maxPoints) return values.indices.toList()
    if (maxPoints < 3) return listOf(0, n - 1)
    val bucket = ((n - 1).toFloat() / (maxPoints - 1)).coerceAtLeast(1f)
    val out = ArrayList<Int>(maxPoints + 8)
    out.add(0)
    var b = 0
    while (true) {
        val start = (b * bucket).toInt().coerceIn(0, n - 1)
        val end = (((b + 1) * bucket).toInt() - 1).coerceIn(start, n - 1)
        if (start >= n - 1) break
        var minI = start; var maxI = start
        for (i in start..end) {
            if (values[i] < values[minI]) minI = i
            if (values[i] > values[maxI]) maxI = i
        }
        if (minI < maxI) {
            if (out.last() != minI) out.add(minI)
            if (out.last() != maxI) out.add(maxI)
        } else {
            if (out.last() != maxI) out.add(maxI)
            if (out.last() != minI) out.add(minI)
        }
        if (end >= n - 1) break
        b++
        if (out.size >= maxPoints * 2) break
    }
    if (out.last() != n - 1) out.add(n - 1)
    if (out.size <= maxPoints) return out
    val step = (out.size - 1).toFloat() / (maxPoints - 1)
    val slim = ArrayList<Int>(maxPoints)
    var prev = -1
    for (i in 0 until maxPoints) {
        val idx = out[(i * step).toInt().coerceIn(0, out.lastIndex)]
        if (idx != prev) { slim.add(idx); prev = idx }
    }
    if (slim.last() != n - 1) slim.add(n - 1)
    return slim
}

private fun findMaxDrawdownPair(series: List<Double>): Pair<Int, Int> {
    if (series.size < 2) return -1 to -1
    var bestPeak = 0; var bestTrough = 0; var bestDd = 0.0
    var runningPeakIdx = 0
    for (i in series.indices) {
        if (series[i] > series[runningPeakIdx]) runningPeakIdx = i
        val dd = series[runningPeakIdx] - series[i]
        if (dd > bestDd) { bestDd = dd; bestPeak = runningPeakIdx; bestTrough = i }
    }
    return if (bestDd > 0.0 && bestTrough > bestPeak) bestPeak to bestTrough else -1 to -1
}
