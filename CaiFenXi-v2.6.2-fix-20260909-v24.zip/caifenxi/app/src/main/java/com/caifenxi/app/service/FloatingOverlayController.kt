package com.caifenxi.app.service

import android.content.Context
import android.graphics.Color as AndroidColor
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.caifenxi.app.CaiFenXiApplication

/**
 * 悬浮窗只读显示器（v2.5.4 性能优化 + 高级感重设计）。
 *
 * 性能优化：
 * 1. 拖拽只读一次 prefs（ACTION_DOWN 缓存），MOVE/UP 直接用缓存值，消除 60-120 次/秒 I/O。
 * 2. ticker 快照 diff：数据未变时跳过整条 render + updateViewLayout 链路。
 * 3. mini 模式复用 TextView，不再每次 removeAllViews + new。
 *
 * 视觉升级：
 * - 圆角渐变背景 + elevation 阴影
 * - 方向文字着色（大=绿/小=红/单=蓝/双=橙）
 * - 精细排版与间距
 * - mini 模式渐变圆形 + 描边
 */
class FloatingOverlayController(private val context: Context) {
    private val appContext = context.applicationContext
    private val wm = appContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private var textViews: MutableList<TextView> = mutableListOf()
    private val handler = Handler(Looper.getMainLooper())
    private var collapseTask: Runnable? = null
    private var lastMode: String = ""
    private var tickerTask: Runnable? = null

    // P0: 快照 diff — 缓存上次渲染的关键字段，数据未变时跳过整条 render 链路
    private var lastRenderKey: String = ""

    // P0: mini 模式 TextView 复用，避免每次 refresh 都 removeAllViews + new
    private var miniTextView: TextView? = null

    // 视觉：方向色板
    private fun colorForDir(d: String?) = when (d) {
        "大" -> AndroidColor.rgb(0x66, 0xBB, 0x6A)
        "小" -> AndroidColor.rgb(0xEF, 0x53, 0x50)
        "单" -> AndroidColor.rgb(0x42, 0xA5, 0xF5)
        "双" -> AndroidColor.rgb(0xFF, 0xA7, 0x26)
        else -> AndroidColor.rgb(0xB0, 0xBE, 0xC5)
    }
    private val cAccent = AndroidColor.rgb(0x00, 0xBC, 0xD4)
    private val cTitle = AndroidColor.rgb(0xFF, 0xFF, 0xFF)
    private val cLabel = AndroidColor.rgb(0xB0, 0xBE, 0xC5)
    private val cDetail = AndroidColor.rgb(0x78, 0x90, 0x9C)
    private val cOk = AndroidColor.rgb(0x66, 0xBB, 0x6A)
    private val cSync = AndroidColor.rgb(0xFF, 0xA7, 0x26)

    private val bgFull = intArrayOf(
        AndroidColor.rgb(0x1A, 0x1A, 0x2E),
        AndroidColor.rgb(0x0D, 0x1B, 0x2A)
    )
    private val bgMini = intArrayOf(
        AndroidColor.rgb(0x1A, 0x1A, 0x2E),
        AndroidColor.rgb(0x0F, 0x34, 0x60)
    )

    private enum class LineStyle { TITLE, DIRECTION, LABEL, DETAIL, EXECUTION, STATUS }
    private data class LineData(
        val text: String, val bold: Boolean, val small: Boolean,
        val style: LineStyle = LineStyle.LABEL, val dirValue: String? = null
    )

    @Synchronized
    fun refresh(prefs: com.caifenxi.app.domain.model.UserPrefs) {
        if (!prefs.floatingEnabled || !Settings.canDrawOverlays(appContext)) {
            hide()
            return
        }
        val current = FloatingOverlayStore.load(appContext)
        if (current == null) return
        val display = if (current.status == "CALCULATING") {
            FloatingOverlayStore.loadLastReady(appContext) ?: current
        } else current
        ensureView(prefs)
        val modeChanged = lastMode != prefs.floatingMode
        render(prefs, display, current)
        if (modeChanged) scheduleAutoCollapse(prefs)
        lastMode = prefs.floatingMode
    }

    @Synchronized
    fun hide() {
        collapseTask?.let { handler.removeCallbacks(it) }
        collapseTask = null
        val v = root
        root = null
        params = null
        textViews.clear()
        miniTextView = null
        lastMode = ""
        lastRenderKey = ""
        tickerTask?.let { handler.removeCallbacks(it) }
        tickerTask = null
        if (v == null) return
        try {
            wm.removeViewImmediate(v)
        } catch (_: Exception) {
            try {
                if (v.isAttachedToWindow) wm.removeView(v)
            } catch (_: Exception) {
            }
        }
    }

    fun keepOnServiceDestroy() {
        val v = root
        val p = params
        if (v != null) {
            HeldOverlay.view = v
            HeldOverlay.params = p
        }
        root = null
        params = null
        textViews.clear()
        miniTextView = null
        lastMode = ""
    }

    @Suppress("DEPRECATION")
    private fun ensureView(prefs: com.caifenxi.app.domain.model.UserPrefs) {
        if (root == null && HeldOverlay.view != null) {
            root = HeldOverlay.view as? LinearLayout
            params = HeldOverlay.params
            HeldOverlay.view = null
            HeldOverlay.params = null
            textViews.clear()
            miniTextView = null
            root?.let { box ->
                textViews.addAll((0 until box.childCount).mapNotNull { box.getChildAt(it) as? TextView })
            }
        }
        val existing = root
        if (existing != null && existing.isAttachedToWindow) return
        if (existing != null) {
            try { wm.removeViewImmediate(existing) } catch (_: Exception) {}
        }
        root = null
        params = null
        textViews.clear()
        miniTextView = null
        lastRenderKey = ""

        val lp = WindowManager.LayoutParams(
            dp(245), WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.floatingX
            y = prefs.floatingY
        }
        val box = LinearLayout(appContext).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(16).toFloat()
                colors = bgFull
                orientation = GradientDrawable.Orientation.TOP_BOTTOM
            }
            elevation = dp(10).toFloat()
        }
        box.setOnTouchListener(DragTouchListener(lp))
        try {
            wm.addView(box, lp)
            root = box
            params = lp
            startTicker()
        } catch (_: Exception) {
            root = null
            params = null
        }
    }

    private fun render(
        prefs: com.caifenxi.app.domain.model.UserPrefs,
        snap: FloatingSnapshot,
        current: FloatingSnapshot
    ) {
        val box = root ?: return
        if (!box.isAttachedToWindow) return

        if (prefs.floatingMode == "mini") {
            renderMini(prefs, snap, current)
            return
        }
        if (prefs.floatingMode == "hidden") {
            box.visibility = View.GONE
            return
        }

        // mini -> full 切换：清除 mini TextView
        if (miniTextView != null) {
            box.removeAllViews()
            miniTextView = null
            textViews.clear()
        }

        box.visibility = View.VISIBLE
        box.alpha = prefs.floatingOpacity
        box.setPadding(dp(16), dp(14), dp(16), dp(14))
        box.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(16).toFloat()
            colors = bgFull
            orientation = GradientDrawable.Orientation.TOP_BOTTOM
        }
        box.elevation = dp(10).toFloat()
        params?.let { lp ->
            lp.width = dp(245)
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT
            try { wm.updateViewLayout(box, lp) } catch (_: Exception) {}
        }

        val selectedDxId = prefs.floatingDxPlanId.ifBlank { prefs.floatingPlanId }
        val selectedDsId = prefs.floatingDsPlanId.ifBlank { prefs.floatingPlanId }
        val dxPlan = snap.plans.firstOrNull { it.planId == selectedDxId && !it.dx.isNullOrBlank() }
        val dsPlan = snap.plans.firstOrNull { it.planId == selectedDsId && !it.ds.isNullOrBlank() }

        val consensusDx = snap.consensusDx?.takeIf { it == "大" || it == "小" }
        val consensusDs = snap.consensusDs?.takeIf { it == "单" || it == "双" }
        val algoDx = snap.algoDx?.takeIf { it == "大" || it == "小" }
        val algoDs = snap.algoDs?.takeIf { it == "单" || it == "双" }

        var dx: String? = null
        var ds: String? = null
        var sourceName = "共识"
        var detail: String? = null

        // 跟随挂机时与无障碍同一套解析，避免悬浮窗显示与真实点击不一致
        if (prefs.autoClickFollowBetSource) {
            try {
                val resolved = AutoBetController.resolveClickTargets(prefs, snap)
                dx = resolved.first
                ds = resolved.second
                sourceName = AutoBetController.describeClickSource(appContext, prefs, snap.lotteryKey)
                detail = "组合：${AutoBetController.resolveCombo(snap, prefs) ?: "-"}"
            } catch (_: Exception) {
                dx = consensusDx ?: algoDx
                ds = consensusDs ?: algoDs
                sourceName = "跟随挂机"
            }
        } else when (prefs.floatingSource) {
            "plan" -> {
                dx = dxPlan?.dx?.split("/", "、", ",")?.firstOrNull { it == "大" || it == "小" }
                ds = dsPlan?.ds?.split("/", "、", ",")?.firstOrNull { it == "单" || it == "双" }
                if (dx == null) dx = consensusDx ?: algoDx
                if (ds == null) ds = consensusDs ?: algoDs
                sourceName = "指定计划"
                val dxName = dxPlan?.planName ?: "共识兜底"
                val dsName = dsPlan?.planName ?: "共识兜底"
                detail = "大小：$dxName / 单双：$dsName"
            }
            "algo" -> {
                dx = algoDx ?: consensusDx
                ds = algoDs ?: consensusDs
                sourceName = "当前算法"
            }
            else -> {
                dx = consensusDx ?: algoDx
                ds = consensusDs ?: algoDs
                sourceName = if (consensusDx != null && consensusDs != null) "共识" else "共识兜底"
            }
        }

        val target = snap.targetIssue
        val issueReady = target != "-" && snap.latestIssue != "-" &&
            (isNextIssue(snap.latestIssue, target) || snap.latestIssue.toLongOrNull() == null)
        val predictionReady = issueReady && !dx.isNullOrBlank() && !ds.isNullOrBlank() && current.status != "CALCULATING"

        val status = when {
            current.status == "CALCULATING" -> "同步中 · 预测计算"
            !issueReady -> "同步中 · 期号校验"
            predictionReady -> "待开 · 同步正常"
            else -> "同步中 · 等待预测"
        }

        val ticket = com.caifenxi.app.domain.execution.ExecutionTicketStore.ticket.value
        val ticketMatches = ticket.lotteryKey.isBlank() || ticket.lotteryKey == snap.lotteryKey
        val executionLine = if (ticketMatches && ticket.cmdId.isNotBlank()) {
            val stage = com.caifenxi.app.domain.execution.ExecutionTicketStore.stageLabel(ticket.stage, ticket.leg)
            val dir = listOfNotNull(ticket.dx, ticket.ds).joinToString("/").ifBlank { "-" }
            val amount = ticket.amountText?.takeIf { it.isNotBlank() }?.let { " \u00a5$it" } ?: ""
            LineData("执行：$stage \u00b7 $dir$amount \u00b7 ${ticket.status}", false, false, LineStyle.EXECUTION)
        } else null
        val executionDetail = if (ticketMatches && ticket.message.isNotBlank() && ticket.status !in setOf("IDLE", "SUCCESS")) {
            LineData(ticket.message.take(42), false, true, LineStyle.DETAIL)
        } else null

        val statusDot = if (predictionReady) "\u25cf" else "\u25cb"
        val lines = listOf(
            LineData("\u2588${snap.lotteryName}", true, false, LineStyle.TITLE),
            LineData(
                if (predictionReady) "\u7b2c${target}\u671f \u00b7 ${dx}" else "\u7b2c${target}\u671f \u00b7 \u9884\u6d4b\u66f4\u65b0\u4e2d\u2026",
                true, false, LineStyle.DIRECTION, if (predictionReady) dx else null
            ),
            LineData(
                if (predictionReady) "\u7b2c${target}\u671f \u00b7 ${ds}" else "\u7b2c${target}\u671f \u00b7 \u9884\u6d4b\u66f4\u65b0\u4e2d\u2026",
                true, false, LineStyle.DIRECTION, if (predictionReady) ds else null
            ),
            LineData("\u6765\u6e90\uff1a$sourceName", false, false, LineStyle.LABEL),
            detail?.let { LineData(it, false, true, LineStyle.DETAIL) },
            executionLine,
            executionDetail,
            LineData("$statusDot \u72b6\u6001\uff1a$status", false, false, LineStyle.STATUS)
        ).filterNotNull()

        // 固定复用 View，只更新文本/样式，避免 removeAllViews 导致悬浮窗闪烁或卡顿。
        while (textViews.size < lines.size) {
            val tv = TextView(appContext).apply { setTextColor(AndroidColor.WHITE) }
            box.addView(tv)
            textViews.add(tv)
        }
        while (textViews.size > lines.size) {
            box.removeViewAt(box.childCount - 1)
            textViews.removeAt(textViews.lastIndex)
        }
        lines.forEachIndexed { i, line ->
            textViews[i].apply {
                text = buildText(line)
                textSize = sizeFor(line, prefs.floatingTextSize)
                setTypeface(typeface, if (line.bold) Typeface.BOLD else Typeface.NORMAL)
                setPadding(0, dp(padFor(line)), 0, dp(1))
                setTextColor(colorFor(line))
            }
        }
    }

    private fun buildText(line: LineData): CharSequence {
        if (line.style == LineStyle.TITLE) {
            val s = SpannableStringBuilder(line.text)
            s.setSpan(ForegroundColorSpan(cAccent), 0, 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            return s
        }
        if (line.style == LineStyle.DIRECTION && line.dirValue != null) {
            val s = SpannableStringBuilder(line.text)
            val idx = line.text.indexOf(line.dirValue)
            if (idx >= 0) {
                s.setSpan(ForegroundColorSpan(colorForDir(line.dirValue)),
                    idx, idx + line.dirValue.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                s.setSpan(StyleSpan(Typeface.BOLD),
                    idx, idx + line.dirValue.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            return s
        }
        if (line.style == LineStyle.STATUS) {
            val s = SpannableStringBuilder(line.text)
            val dotColor = if (line.text.startsWith("\u25cf")) cOk else cSync
            s.setSpan(ForegroundColorSpan(dotColor), 0, 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            return s
        }
        return line.text
    }

    private fun sizeFor(line: LineData, base: Float): Float = when (line.style) {
        LineStyle.TITLE -> base
        LineStyle.DIRECTION -> (base + 3f)
        LineStyle.LABEL -> (base - 2f).coerceAtLeast(10f)
        LineStyle.DETAIL -> (base - 3f).coerceAtLeast(9f)
        LineStyle.EXECUTION -> (base - 1f).coerceAtLeast(10f)
        LineStyle.STATUS -> (base - 2f).coerceAtLeast(10f)
    }

    private fun padFor(line: LineData): Int = when (line.style) {
        LineStyle.TITLE -> 0
        LineStyle.DIRECTION -> 4
        LineStyle.LABEL -> 6
        LineStyle.DETAIL -> 1
        LineStyle.EXECUTION -> 6
        LineStyle.STATUS -> 4
    }

    private fun colorFor(line: LineData): Int = when (line.style) {
        LineStyle.TITLE -> cTitle
        LineStyle.DIRECTION -> cTitle
        LineStyle.LABEL -> cLabel
        LineStyle.DETAIL -> cDetail
        LineStyle.EXECUTION -> cAccent
        LineStyle.STATUS -> cLabel
    }

    private fun renderMini(prefs: com.caifenxi.app.domain.model.UserPrefs, snap: FloatingSnapshot, current: FloatingSnapshot) {
        val box = root ?: return
        box.visibility = View.VISIBLE
        box.alpha = prefs.floatingMiniOpacity

        val lp = params ?: return
        val size = dp(prefs.floatingMiniSize.coerceIn(32, 72))

        // full -> mini 切换：首次创建 miniTextView，后续复用
        if (miniTextView == null) {
            box.removeAllViews()
            textViews.clear()
            box.orientation = LinearLayout.VERTICAL
            box.gravity = Gravity.CENTER
            miniTextView = TextView(appContext).apply {
                gravity = Gravity.CENTER
            }
            box.addView(miniTextView, LinearLayout.LayoutParams(size, size))
        }

        box.setPadding(0, 0, 0, 0)
        box.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            colors = bgMini
            orientation = GradientDrawable.Orientation.TL_BR
            setStroke(dp(1), AndroidColor.argb(0x4D, 0xFF, 0xFF, 0xFF))
        }
        box.elevation = dp(8).toFloat()
        lp.width = size
        lp.height = size
        try { wm.updateViewLayout(box, lp) } catch (_: Exception) {}

        val target = snap.targetIssue.takeIf { it != "-" } ?: "?"
        val ticket = com.caifenxi.app.domain.execution.ExecutionTicketStore.ticket.value
        val selected = ticket.takeIf { it.lotteryKey.isBlank() || it.lotteryKey == snap.lotteryKey }
            ?.dx?.takeIf { it == "\u5927" || it == "\u5c0f" }
            ?: snap.consensusDx?.takeIf { it == "\u5927" || it == "\u5c0f" }
            ?: snap.algoDx?.takeIf { it == "\u5927" || it == "\u5c0f" } ?: "\u00b7"

        miniTextView?.apply {
            text = if (selected == "\u00b7") "\u25c9" else selected
            setTextColor(colorForDir(if (selected == "\u00b7") null else selected))
            textSize = (prefs.floatingMiniSize * 0.36f).coerceIn(13f, 24f)
            setTypeface(typeface, Typeface.BOLD)
            contentDescription = "\u60ac\u6d6e\u7a97\uff1a\u7b2c${target}\u671f $selected\uff0c\u62d6\u62fd\u79fb\u52a8\uff0c\u8f7b\u89e6\u5c55\u5f00"
        }

        // 重新挂载 listener（轻量操作，确保拿到最新 lp 和 prefs）
        miniTextView?.setOnTouchListener(createMiniDragListener(box, lp, prefs))
    }

    private fun createMiniDragListener(
        box: LinearLayout,
        lp: WindowManager.LayoutParams,
        prefs: com.caifenxi.app.domain.model.UserPrefs
    ): View.OnTouchListener {
        val draggable = prefs.floatingDraggable
        val edgeSnap = prefs.floatingEdgeSnap
        val clickThreshold = dp(8)
        return object : View.OnTouchListener {
            private var downX = 0f
            private var downY = 0f
            private var startX = 0
            private var startY = 0
            private var moved = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.rawX; downY = event.rawY
                        startX = lp.x; startY = lp.y
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (!draggable) return true
                        val dx = (event.rawX - downX).toInt()
                        val dy = (event.rawY - downY).toInt()
                        if (kotlin.math.abs(dx) > clickThreshold || kotlin.math.abs(dy) > clickThreshold) moved = true
                        lp.x = startX + dx
                        lp.y = startY + dy
                        try { wm.updateViewLayout(box, lp) } catch (_: Exception) {}
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved && kotlin.math.abs((event.rawX - downX).toInt()) <= clickThreshold && kotlin.math.abs((event.rawY - downY).toInt()) <= clickThreshold) {
                            val now = CaiFenXiApplication.instance.configStore.loadPrefs()
                            CaiFenXiApplication.instance.configStore.savePrefs(now.copy(floatingMode = "full"))
                            refresh(now.copy(floatingMode = "full"))
                        } else if (draggable) {
                            if (edgeSnap) {
                                val metrics = appContext.resources.displayMetrics
                                val screenW = metrics.widthPixels
                                val viewW = box.width.coerceAtLeast(dp(1))
                                lp.x = if (lp.x + viewW / 2 < screenW / 2) 0 else (screenW - viewW).coerceAtLeast(0)
                                try { wm.updateViewLayout(box, lp) } catch (_: Exception) {}
                            }
                            CaiFenXiApplication.instance.configStore.savePrefs(
                                prefs.copy(floatingX = lp.x, floatingY = lp.y)
                            )
                        }
                        return true
                    }
                }
                return false
            }
        }
    }

    /** 每秒刷新一次执行台状态，使后台 WebView/挂机执行进度实时反映到系统悬浮窗。 */
    private fun startTicker() {
        if (tickerTask != null) return
        val task = object : Runnable {
            override fun run() {
                if (root == null) { tickerTask = null; return }
                val prefs = CaiFenXiApplication.instance.configStore.loadPrefs()
                if (!prefs.floatingEnabled || !Settings.canDrawOverlays(appContext)) {
                    tickerTask = null
                    return
                }
                // P0: 快照 diff — 数据未变时跳过整条 render 链路
                val snap = FloatingOverlayStore.load(appContext)
                val ticket = com.caifenxi.app.domain.execution.ExecutionTicketStore.ticket.value
                val key = if (snap != null) {
                    "${snap.targetIssue}|${snap.consensusDx}|${snap.consensusDs}|${snap.algoDx}|${snap.algoDs}|${snap.status}|${snap.lotteryKey}|${snap.lotteryName}|${ticket.cmdId}|${ticket.status}|${ticket.dx}|${ticket.ds}|${ticket.stage}|${ticket.leg}|${ticket.amountText}|${ticket.message}|${prefs.floatingMode}"
                } else ""
                if (key == lastRenderKey && prefs.floatingMode == lastMode) {
                    handler.postDelayed(this, 1000L)
                    return
                }
                lastRenderKey = key
                refresh(prefs)
                handler.postDelayed(this, 1000L)
            }
        }
        tickerTask = task
        handler.postDelayed(task, 1000L)
    }

    private fun scheduleAutoCollapse(prefs: com.caifenxi.app.domain.model.UserPrefs) {
        collapseTask?.let { handler.removeCallbacks(it) }
        collapseTask = null
        if (prefs.floatingMode != "full" || prefs.floatingAutoCollapseSeconds <= 0) return
        val task = Runnable {
            val now = CaiFenXiApplication.instance.configStore.loadPrefs()
            if (now.floatingEnabled && now.floatingMode == "full") {
                CaiFenXiApplication.instance.configStore.savePrefs(now.copy(floatingMode = "mini"))
                refresh(now.copy(floatingMode = "mini"))
            }
        }
        collapseTask = task
        handler.postDelayed(task, prefs.floatingAutoCollapseSeconds * 1000L)
    }

    private fun isNextIssue(latest: String, target: String): Boolean {
        val a = latest.toLongOrNull()
        val b = target.toLongOrNull()
        return if (a != null && b != null) b == a + 1L else true
    }

    private fun dp(v: Int) = (v * appContext.resources.displayMetrics.density).toInt()

    private inner class DragTouchListener(private val lp: WindowManager.LayoutParams) : View.OnTouchListener {
        private var downX = 0f
        private var downY = 0f
        private var startX = 0
        private var startY = 0
        private var lastUpAt = 0L
        // P0: 缓存 prefs，避免 MOVE 期间每帧读 SharedPreferences（60-120 次/秒）
        private var cachedDraggable = false
        private var cachedEdgeSnap = false
        private var cachedPrefs: com.caifenxi.app.domain.model.UserPrefs? = null

        override fun onTouch(v: View, event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    // 只在 DOWN 时读一次 prefs
                    cachedPrefs = CaiFenXiApplication.instance.configStore.loadPrefs()
                    cachedDraggable = cachedPrefs!!.floatingDraggable
                    cachedEdgeSnap = cachedPrefs!!.floatingEdgeSnap
                    downX = event.rawX; downY = event.rawY
                    startX = lp.x; startY = lp.y
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    // 直接用缓存值，不再读 SharedPreferences
                    if (!cachedDraggable) return true
                    lp.x = startX + (event.rawX - downX).toInt()
                    lp.y = startY + (event.rawY - downY).toInt()
                    try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    val now = System.currentTimeMillis()
                    if (now - lastUpAt < 320L) {
                        try { wm.removeViewImmediate(v) } catch (_: Exception) {}
                        root = null
                        params = null
                        textViews.clear()
                        miniTextView = null
                        lastUpAt = 0L
                        return true
                    }
                    lastUpAt = now
                    if (cachedDraggable) {
                        if (cachedEdgeSnap) {
                            val metrics = appContext.resources.displayMetrics
                            val screenW = metrics.widthPixels
                            val viewW = v.width.coerceAtLeast(dp(1))
                            lp.x = if (lp.x + viewW / 2 < screenW / 2) 0 else (screenW - viewW).coerceAtLeast(0)
                            try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
                        }
                        // 一次写回，用缓存的 prefs copy 新坐标
                        cachedPrefs?.let { p ->
                            CaiFenXiApplication.instance.configStore.savePrefs(
                                p.copy(floatingX = lp.x, floatingY = lp.y)
                            )
                        }
                    }
                    cachedPrefs = null
                    return true
                }
            }
            return false
        }
    }
}

/** 服务短暂销毁时暂存预测悬浮窗 View，避免叠窗与误消失 */
private object HeldOverlay {
    @Volatile var view: android.view.View? = null
    @Volatile var params: WindowManager.LayoutParams? = null
}
