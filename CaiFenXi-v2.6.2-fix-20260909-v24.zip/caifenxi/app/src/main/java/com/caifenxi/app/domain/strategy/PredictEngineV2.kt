package com.caifenxi.app.domain.strategy

import com.caifenxi.app.domain.model.BetOdds
import com.caifenxi.app.domain.model.Direction
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.LotteryConfig
import com.caifenxi.app.domain.model.LotteryType
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.sqrt

/**
 * 策略池预测引擎 V2（独立于原有 PredictEngine，完全隔离）。
 *
 * 三轨算法：
 * - A轨 BAYES_FUSION：三阶特征 + 加权贝叶斯融合器，输出大小/单双方向
 * - B轨 HEDGE_2：互补对冲选择器，输出2个组合（覆盖不同维度）
 * - C轨 EXCLUDE_1：排除概率最低的组合，输出3个组合
 */
object PredictEngineV2 {

    // ==================== 公共入口 ====================

    fun predict(plan: StrategyDefinition, history: List<DrawRecord>): StrategyPrediction? {
        val data = history.takeLast(plan.window.coerceAtLeast(20))
        if (data.size < 5) return null
        val lotKey = data.lastOrNull()?.lotteryKey.orEmpty()
        return when (plan.algorithm) {
            "BAYES_FUSION" -> predictBayesFusion(plan, data, lotKey)
            "HEDGE_2" -> predictHedge2(plan, data, lotKey)
            "EXCLUDE_1" -> predictExclude1(plan, data, lotKey)
            else -> null
        }
    }

    // ==================== A轨：贝叶斯融合器 ====================

    /**
     * 三阶特征 + 加权贝叶斯融合：
     * 1) 收集5个弱预测器各自输出 P(方向A) 和 P(方向B)
     * 2) 用各预测器在最近50期的实际命中率作为先验权重
     * 3) 加权融合后取概率大的一方
     */
    private fun predictBayesFusion(
        plan: StrategyDefinition,
        data: List<DrawRecord>,
        lotKey: String
    ): StrategyPrediction? {
        val isDx = plan.playType.contains("大小")
        val labels = if (isDx) listOf("大", "小") else listOf("单", "双")
        val seq = extractDirectionSeq(plan, data, isDx)
        if (seq.size < 5) return null

        // 5个弱预测器
        val predictors = listOf(
            "频率" to freqPredictor(seq, labels),
            "EWMA" to ewmaPredictor(seq, labels),
            "马尔可夫" to markovPredictor(seq, labels),
            "遗漏" to omitPredictor(seq, labels),
            "趋势" to trendPredictor(seq, labels)
        )

        // 各预测器在最近50期的实际命中率作为权重
        val weights = predictors.map { (name, _) ->
            val hitRate = calcPredictorHitRate(name, seq, labels, minOf(50, seq.size))
            max(0.05, hitRate)  // 下限0.05，避免完全忽略
        }

        // 加权融合
        val totalW = weights.sum()
        var pA = 0.0
        var pB = 0.0
        predictors.forEachIndexed { i, (_, scores) ->
            pA += weights[i] * (scores[labels[0]] ?: 0.5)
            pB += weights[i] * (scores[labels[1]] ?: 0.5)
        }
        pA /= totalW
        pB /= totalW
        // 归一化
        val sum = pA + pB
        if (sum <= 0) return null
        pA /= sum
        pB /= sum

        val output = if (pA >= pB) labels[0] else labels[1]
        val confidence = max(pA, pB)

        return StrategyPrediction(
            planId = plan.planId,
            output = output,
            confidence = confidence,
            scores = mapOf(labels[0] to pA, labels[1] to pB),
            detail = "融合5预测器·权重[${weights.mapIndexed { i, w -> "${predictors[i].first}:${"%.0f".format(w * 100)}" }.joinToString(" ")}]"
        )
    }

    /** 提取方向序列（大小或单双） */
    private fun extractDirectionSeq(plan: StrategyDefinition, data: List<DrawRecord>, isDx: Boolean): List<String> {
        val type = LotteryConfig.findByKey(data.firstOrNull()?.lotteryKey.orEmpty())?.type
        return when {
            plan.playType == "名次大小" -> {
                val idx = plan.positionIndex.coerceIn(0, 9)
                data.mapNotNull { r ->
                    r.numbers.getOrNull(idx)?.takeIf { it in 1..10 }
                        ?.let { if (it >= 6) "大" else "小" }
                }
            }
            plan.playType == "名次单双" -> {
                val idx = plan.positionIndex.coerceIn(0, 9)
                data.mapNotNull { r ->
                    r.numbers.getOrNull(idx)?.takeIf { it in 1..10 }
                        ?.let { if (it % 2 == 1) "单" else "双" }
                }
            }
            plan.playType == "球大小" -> {
                val idx = plan.positionIndex.coerceIn(0, 5)
                data.mapNotNull { r ->
                    r.numbers.getOrNull(idx)?.takeIf { it in 1..6 }
                        ?.let { if (it >= 4) "大" else "小" }
                }
            }
            plan.playType == "球单双" -> {
                val idx = plan.positionIndex.coerceIn(0, 5)
                data.mapNotNull { r ->
                    r.numbers.getOrNull(idx)?.takeIf { it in 1..6 }
                        ?.let { if (it % 2 == 1) "单" else "双" }
                }
            }
            isDx -> data.mapNotNull { it.dx }
            else -> data.mapNotNull { it.ds }
        }
    }

    // --- 5个弱预测器 ---

    /** 频率预测器：多窗口频率统计 */
    private fun freqPredictor(seq: List<String>, labels: List<String>): Map<String, Double> {
        val w10 = seq.takeLast(10)
        val w20 = seq.takeLast(20)
        val w50 = seq.takeLast(50)
        val f10 = labels.associateWith { l -> w10.count { it == l }.toDouble() / max(1, w10.size) }
        val f20 = labels.associateWith { l -> w20.count { it == l }.toDouble() / max(1, w20.size) }
        val f50 = labels.associateWith { l -> w50.count { it == l }.toDouble() / max(1, w50.size) }
        return labels.associateWith { l -> f10[l]!! * 0.35 + f20[l]!! * 0.35 + f50[l]!! * 0.30 }
    }

    /** EWMA预测器：指数加权移动平均 */
    private fun ewmaPredictor(seq: List<String>, labels: List<String>): Map<String, Double> {
        val alpha = 0.15
        val ewma = mutableMapOf(labels[0] to 0.5, labels[1] to 0.5)
        seq.forEach { s ->
            labels.forEach { l ->
                val target = if (s == l) 1.0 else 0.0
                ewma[l] = alpha * target + (1 - alpha) * (ewma[l] ?: 0.5)
            }
        }
        val sum = ewma.values.sum()
        return if (sum > 0) labels.associateWith { l -> (ewma[l] ?: 0.5) / sum } else labels.associateWith { 0.5 }
    }

    /** 一阶马尔可夫预测器 */
    private fun markovPredictor(seq: List<String>, labels: List<String>): Map<String, Double> {
        if (seq.size < 3) return labels.associateWith { 0.5 }
        val last = seq.last()
        val transitions = mutableMapOf<String, Int>()
        for (i in 1 until seq.size) {
            if (seq[i - 1] == last) {
                transitions[seq[i]] = (transitions[seq[i]] ?: 0) + 1
            }
        }
        val total = transitions.values.sum().coerceAtLeast(1)
        return labels.associateWith { l -> (transitions[l] ?: 0).toDouble() / total }
    }

    /** 遗漏预测器：遗漏越久越可能回补 */
    private fun omitPredictor(seq: List<String>, labels: List<String>): Map<String, Double> {
        val omit = labels.associateWith { l -> seq.takeLast(30).count { it != l } }
        val total = omit.values.sum().coerceAtLeast(1)
        return labels.associateWith { l -> (omit[l] ?: 0).toDouble() / total }
    }

    /** 趋势预测器：近期方向延续 */
    private fun trendPredictor(seq: List<String>, labels: List<String>): Map<String, Double> {
        val recent = seq.takeLast(5)
        val momentum = labels.associateWith { l -> recent.count { it == l }.toDouble() }
        val sum = momentum.values.sum().coerceAtLeast(1.0)
        return labels.associateWith { l -> (momentum[l] ?: 0.0) / sum }
    }

    /** 计算某预测器在最近N期的命中率 */
    private fun calcPredictorHitRate(name: String, seq: List<String>, labels: List<String>, n: Int): Double {
        if (seq.size < n + 1) return 0.5
        val testSeq = seq.takeLast(n + 1)
        var hits = 0
        for (i in 1 until testSeq.size) {
            val prior = testSeq.subList(0, i)
            val pred = when (name) {
                "频率" -> freqPredictor(prior, labels).maxByOrNull { it.value }?.key
                "EWMA" -> ewmaPredictor(prior, labels).maxByOrNull { it.value }?.key
                "马尔可夫" -> markovPredictor(prior, labels).maxByOrNull { it.value }?.key
                "遗漏" -> omitPredictor(prior, labels).maxByOrNull { it.value }?.key
                "趋势" -> trendPredictor(prior, labels).maxByOrNull { it.value }?.key
                else -> null
            }
            if (pred == testSeq[i]) hits++
        }
        return hits.toDouble() / max(1, testSeq.size - 1)
    }

    // ==================== B轨：互补对冲 ====================

    /**
     * 互补对冲选择器：
     * 1) 分别预测大小方向和单双方向（各用贝叶斯融合）
     * 2) 选高置信度方向的组合作为第一口
     * 3) 第二口选与第一口在不同维度互补的选项
     */
    private fun predictHedge2(
        plan: StrategyDefinition,
        data: List<DrawRecord>,
        lotKey: String
    ): StrategyPrediction? {
        val comboLabels = listOf("大单", "大双", "小单", "小双")
        val dxSeq = extractDirectionSeq(plan.copy(playType = "大小"), data, true)
        val dsSeq = extractDirectionSeq(plan.copy(playType = "单双"), data, false)
        if (dxSeq.size < 5 || dsSeq.size < 5) return null

        // 分别预测大小和单双
        val dxScores = predictBayesFusion(plan.copy(playType = "大小"), data, lotKey)?.scores
            ?: return null
        val dsScores = predictBayesFusion(plan.copy(playType = "单双"), data, lotKey)?.scores
            ?: return null

        val pBig = dxScores["大"] ?: 0.5
        val pSmall = dxScores["小"] ?: 0.5
        val pOdd = dsScores["单"] ?: 0.5
        val pEven = dsScores["双"] ?: 0.5

        // 每个组合的概率 = P(大小方向) × P(单双方向)
        val comboProbs = mapOf(
            "大单" to pBig * pOdd,
            "大双" to pBig * pEven,
            "小单" to pSmall * pOdd,
            "小双" to pSmall * pEven
        )

        // 第一口：概率最高的组合
        val first = comboProbs.maxByOrNull { it.value }!!.key
        val firstProb = comboProbs[first]!!

        // 第二口：与第一口互补（不同维度）
        // 维度互补策略：如果第一口是"大双"，第二口选"小双"（锁定双方向，大小互补）
        // 方向互补策略：如果第一口是"大双"，第二口选"大单"（锁定大方向，单双互补）
        // 对角互补策略：选与第一口对角的
        val dxConfidence = abs(pBig - pSmall)
        val dsConfidence = abs(pOdd - pEven)

        val second = if (dxConfidence > dsConfidence) {
            // 大小方向置信度高 → 锁定大小方向，单双互补
            comboLabels.filter { it != first && it.first() == first.first() }.maxByOrNull { comboProbs[it] ?: 0.0 }
        } else {
            // 单双方向置信度高 → 锁定单双方向，大小互补
            comboLabels.filter { it != first && it.last() == first.last() }.maxByOrNull { comboProbs[it] ?: 0.0 }
        } ?: comboLabels.filter { it != first }.maxByOrNull { comboProbs[it] ?: 0.0 }!!

        val output = "$first/$second"
        val confidence = (firstProb + (comboProbs[second] ?: 0.0)) / 2.0

        return StrategyPrediction(
            planId = plan.planId,
            output = output,
            confidence = confidence,
            scores = comboProbs,
            detail = "互补对冲·第一口$first(${ "%.0f".format(firstProb*100)}%)·第二口$second(${ "%.0f".format((comboProbs[second]?:0.0)*100)}%)"
        )
    }

    // ==================== C轨：排除最弱 ====================

    /**
     * 排除最不可能口：
     * 计算每个组合的概率，排除概率最低的，选其余3个
     */
    private fun predictExclude1(
        plan: StrategyDefinition,
        data: List<DrawRecord>,
        lotKey: String
    ): StrategyPrediction? {
        val comboLabels = listOf("大单", "大双", "小单", "小双")
        val dxSeq = extractDirectionSeq(plan.copy(playType = "大小"), data, true)
        val dsSeq = extractDirectionSeq(plan.copy(playType = "单双"), data, false)
        if (dxSeq.size < 5 || dsSeq.size < 5) return null

        val dxScores = predictBayesFusion(plan.copy(playType = "大小"), data, lotKey)?.scores ?: return null
        val dsScores = predictBayesFusion(plan.copy(playType = "单双"), data, lotKey)?.scores ?: return null

        val pBig = dxScores["大"] ?: 0.5
        val pSmall = dxScores["小"] ?: 0.5
        val pOdd = dsScores["单"] ?: 0.5
        val pEven = dsScores["双"] ?: 0.5

        val comboProbs = mapOf(
            "大单" to pBig * pOdd,
            "大双" to pBig * pEven,
            "小单" to pSmall * pOdd,
            "小双" to pSmall * pEven
        ).toList().sortedByDescending { it.second }.toMap()

        // 排除概率最低的
        val selected = comboProbs.keys.take(3)
        val excluded = comboProbs.keys.last()
        val output = selected.joinToString("/")
        val confidence = selected.sumOf { comboProbs[it] ?: 0.0 }

        return StrategyPrediction(
            planId = plan.planId,
            output = output,
            confidence = confidence,
            scores = comboProbs,
            detail = "排除${excluded}(概率${ "%.0f".format((comboProbs[excluded]?:0.0)*100)}%)·选${selected.joinToString("/")}"
        )
    }

    // ==================== 评估 ====================

    /**
     * 评估预测是否命中。
     * A轨(大小/单双/名次大小/名次单双/球大小/球单双)：按方向比对，不转组合。
     * B轨/C轨(组合)：转组合后比对。
     */
    fun evaluate(plan: StrategyDefinition, output: String, actual: DrawRecord): Boolean {
        val predicted = output.removePrefix("反:").split("/", "、", ",").map { it.trim() }.filter { it.isNotEmpty() }
        if (predicted.isEmpty()) return false
        val lotKey = actual.lotteryKey
        val type = LotteryConfig.findByKey(lotKey)?.type

        // A轨方向类：直接比对方向，不走组合
        when (plan.playType) {
            "大小", "和值大小" -> {
                val actualDx = actual.dx ?: return false
                return predicted.any { it == actualDx }
            }
            "单双", "和值单双" -> {
                val actualDs = actual.ds ?: return false
                return predicted.any { it == actualDs }
            }
            "名次大小" -> {
                val idx = plan.positionIndex.coerceIn(0, 9)
                val n = actual.numbers.getOrNull(idx)?.takeIf { it in 1..10 } ?: return false
                val dx = if (n >= 6) "大" else "小"
                return predicted.any { it == dx }
            }
            "名次单双" -> {
                val idx = plan.positionIndex.coerceIn(0, 9)
                val n = actual.numbers.getOrNull(idx)?.takeIf { it in 1..10 } ?: return false
                val ds = if (n % 2 == 1) "单" else "双"
                return predicted.any { it == ds }
            }
            "球大小" -> {
                val idx = plan.positionIndex.coerceIn(0, 5)
                val n = actual.numbers.getOrNull(idx)?.takeIf { it in 1..6 } ?: return false
                val dx = if (n >= 4) "大" else "小"
                return predicted.any { it == dx }
            }
            "球单双" -> {
                val idx = plan.positionIndex.coerceIn(0, 5)
                val n = actual.numbers.getOrNull(idx)?.takeIf { it in 1..6 } ?: return false
                val ds = if (n % 2 == 1) "单" else "双"
                return predicted.any { it == ds }
            }
        }

        // B轨/C轨组合类：转组合后比对
        val actualCombo = resolveCombo(plan, actual, type)
        if (actualCombo.isBlank()) return false
        return predicted.any { it == actualCombo }
    }

    /** 解析实际开奖结果的组合方向 */
    private fun resolveCombo(plan: StrategyDefinition, actual: DrawRecord, type: LotteryType?): String {
        val dx: String?
        val ds: String?
        when {
            plan.playType == "球大小" || plan.playType == "球单双" -> {
                val idx = plan.positionIndex.coerceIn(0, 5)
                val n = actual.numbers.getOrNull(idx) ?: return ""
                dx = if (n >= 4) "大" else "小"
                ds = if (n % 2 == 1) "单" else "双"
            }
            type == LotteryType.YDH -> {
                val n = actual.numbers.getOrNull(0) ?: return ""
                dx = if (n >= 4) "大" else "小"
                ds = if (n % 2 == 1) "单" else "双"
            }
            else -> {
                dx = actual.dx
                ds = actual.ds
            }
        }
        if (dx.isNullOrBlank() || ds.isNullOrBlank()) return ""
        return "$dx$ds"
    }
}
