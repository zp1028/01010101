package com.caifenxi.app.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.caifenxi.app.data.db.entity.WorkbenchBacktestCacheEntity

@Dao
interface WorkbenchBacktestCacheDao {

    @Query("SELECT * FROM workbench_backtest_cache WHERE cacheKey = :cacheKey")
    suspend fun getByKey(cacheKey: String): WorkbenchBacktestCacheEntity?

    /** 某一彩种的全部缓存（工作台启动时加载进内存，再按 lastIssue 核对失效） */
    @Query("SELECT * FROM workbench_backtest_cache WHERE lotteryKey = :lotteryKey")
    suspend fun getByLottery(lotteryKey: String): List<WorkbenchBacktestCacheEntity>

    /** 某一彩种 + 口径（期数/档位）的缓存，用于切期数/档位后快速核对缺失键 */
    @Query("SELECT * FROM workbench_backtest_cache WHERE lotteryKey = :lotteryKey AND stage = :stage AND periods = :periods")
    suspend fun getByLotteryStage(lotteryKey: String, stage: Int, periods: Int): List<WorkbenchBacktestCacheEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: WorkbenchBacktestCacheEntity)

    @Query("DELETE FROM workbench_backtest_cache WHERE lotteryKey = :lotteryKey")
    suspend fun deleteByLottery(lotteryKey: String)

    @Query("DELETE FROM workbench_backtest_cache WHERE planId = :planId")
    suspend fun deleteByPlan(planId: String)

    @Query("DELETE FROM workbench_backtest_cache")
    suspend fun clearAll()
}