package com.caifenxi.app.domain.engine

import com.caifenxi.app.domain.model.AlgoMode
import com.caifenxi.app.domain.model.AlgoResult
import com.caifenxi.app.domain.model.DirectionPrediction
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.LotteryType
import com.caifenxi.app.domain.model.NumberScore
import com.caifenxi.app.domain.model.PositionPrediction
import com.caifenxi.app.domain.model.PredictCategory
import com.caifenxi.app.domain.model.PredictionSnapshot
import com.caifenxi.app.domain.model.UserPrefs
import kotlin.math.exp

/**
 * 多算法预测引擎（对齐原版：经验学习 / 形态匹配 / 智能融合 / 实验室最优）
 */
object PredictEngine {

    fun predict(
        history: List<DrawRecord>,
        lotteryType: LotteryType,
        prefs: UserPrefs,
        targetIssue: String,
        cutoffIssue: String,
        mode: AlgoMode = AlgoMode.fromId(prefs.currentAlgo)
    ): PredictionSnapshot {
        if (history.size < 5) {
            return PredictionSnapshot(
                lotteryKey = history.firstOrNull()?.lotteryKey ?: "",
                targetIssue = targetIssue,
                cutoffIssue = cutoffIssue,
                createdAt = System.currentTimeMillis(),
                algoTag = mode.id
            )
        }
        val window = prefs.predictionWindow.coerceIn(20, 500)
        val recent = history.takeLast(window)
        val dxSeq = recent.mapNotNull { it.dx }
        val dsSeq = recent.mapNotNull { it.ds }
        val comboSeq = recent.mapNotNull { it.combo }

        val effective = when (mode) {
            AlgoMode.COMPARE -> AlgoMode.EXPERIENCE // 主展示用经验，对比另算
            AlgoMode.LAB_BEST -> pickLabBest(dxSeq, dsSeq, prefs)
            else -> mode
        }

        val dx = predictCategory(dxSeq, listOf("大", "小"), prefs, PredictCategory.DX, effective)
        val ds = predictCategory(dsSeq, listOf("单", "双"), prefs, PredictCategory.DS, effective)
        val comboLabels = listOf("大单", "大双", "小单", "小双")
        val combo = predictCategory(comboSeq, comboLabels, prefs, PredictCategory.COMBO, effective)
        val comboList = topDirections(comboSeq, comboLabels, prefs, effective, prefs.comboPredCount.coerceIn(1, 4))

        val numberScores = when (lotteryType) {
            LotteryType.LUCK20 -> numberFrequency(recent, 1..80, 20)
            LotteryType.PKS -> numberFrequency(recent, 1..10, 10)
            LotteryType.K3 -> numberFrequency(recent, 1..6, 3)
            LotteryType.YDH -> numberFrequency(recent, 1..6, 6)
            LotteryType.PC28 -> numberFrequency(recent, 0..9, 3)
            LotteryType.GOOGLE_FF, LotteryType.SHUIGUAN_FF -> numberFrequency(recent, 0..9, 5)
            LotteryType.OTHER -> emptyList()
        }
        // 快乐8/幸运20：取消多位置(原按开奖序位拆 5/10 位)，改为单一「任选号码」池
        // 从 1～80 选 TopN，中奖口径为「与当期开出的任一号码相同即中」
        // 新彩种（快三/PC28/其它）下注类别未设计，位置预测先空
        val positions = when (lotteryType) {
            LotteryType.PKS -> positionPredict(
                recent = recent,
                posCount = 10,
                topN = prefs.positionTopN,
                mode = effective,
                prefs = prefs,
                numberRange = 1..10
            )
            LotteryType.LUCK20 -> listOf(
                luck20NumberPoolPredict(recent, prefs.positionTopN.coerceIn(1, 20), effective, prefs)
            )
            LotteryType.YDH -> positionPredict(
                recent = recent,
                posCount = 6,
                topN = prefs.positionTopN.coerceIn(1, 6),
                mode = effective,
                prefs = prefs,
                numberRange = 1..6
            )
            LotteryType.GOOGLE_FF, LotteryType.SHUIGUAN_FF -> positionPredict(
                recent = recent,
                posCount = 5,
                topN = prefs.positionTopN.coerceIn(1, 5),
                mode = effective,
                prefs = prefs,
                numberRange = 0..9
            )
            LotteryType.K3, LotteryType.PC28, LotteryType.OTHER -> emptyList()
        }

        return PredictionSnapshot(
            lotteryKey = recent.last().lotteryKey,
            targetIssue = targetIssue,
            cutoffIssue = cutoffIssue,
            createdAt = System.currentTimeMillis(),
            frozen = false,
            dx = dx,
            ds = ds,
            combo = combo,
            comboList = comboList,
            numberScores = numberScores,
            positions = positions,
            // 修复：algoTag 始终记录用户选择的算法（如 lab_best/compare），
            // 实际解析出的底层算法放到 resolvedAlgo。原实现把底层算法写进
            // algoTag，导致切换「实验室最优/多算法对比」后驾驶舱仍显示
            // 「经验学习」等其他算法的标签。
            algoTag = mode.id,
            resolvedAlgo = effective.id
        )
    }

    /** 多算法对比：每个类别返回全部算法结果 */
    fun compareAll(
        history: List<DrawRecord>,
        prefs: UserPrefs
    ): Map<String, List<AlgoResult>> {
        if (history.size < 5) return emptyMap()
        val recent = history.takeLast(prefs.predictionWindow.coerceIn(20, 500))
        val map = mutableMapOf<String, List<AlgoResult>>()
        val specs = listOf(
            Triple("大小", recent.mapNotNull { it.dx }, listOf("大", "小")),
            Triple("单双", recent.mapNotNull { it.ds }, listOf("单", "双")),
            Triple("组合", recent.mapNotNull { it.combo }, listOf("大单", "大双", "小单", "小双"))
        )
        val numSize = history.firstOrNull()?.numbers?.size ?: 0
        if (numSize >= 15) {
            // 快乐8 类：单一任选号码池对比，不再按序位拆成多个「位置」
            val seq = recent.flatMap { d -> d.numbers.filter { it in 1..80 }.map { it.toString() } }
            val labels = (1..80).map { it.toString() }
            map["位置-任选号码"] = listOf(
                AlgoMode.EXPERIENCE, AlgoMode.PATTERN, AlgoMode.FUSION
            ).map { mode ->
                val r = runAlgo(seq, labels, prefs, mode)
                AlgoResult(
                    algoId = mode.id,
                    algoLabel = mode.label,
                    direction = r.first,
                    score = r.second,
                    detail = r.third,
                    sample = seq.size,
                    confidence = confLabel(r.second)
                )
            }
        } else {
            val positionCount = numSize.coerceAtMost(10)
            for (idx in 0 until positionCount) {
                val seq = recent.mapNotNull { it.numbers.getOrNull(idx)?.toString() }
                map["位置-${positionName(idx)}"] = listOf(
                    AlgoMode.EXPERIENCE, AlgoMode.PATTERN, AlgoMode.FUSION
                ).map { mode ->
                    val r = runAlgo(seq, (1..10).map { it.toString() }, prefs, mode)
                    AlgoResult(
                        algoId = mode.id,
                        algoLabel = mode.label,
                        direction = r.first,
                        score = r.second,
                        detail = r.third,
                        sample = seq.size,
                        confidence = confLabel(r.second)
                    )
                }
            }
        }
        for ((name, seq, labels) in specs) {
            map[name] = listOf(
                AlgoMode.EXPERIENCE, AlgoMode.PATTERN, AlgoMode.FUSION
            ).map { mode ->
                val r = runAlgo(seq, labels, prefs, mode)
                AlgoResult(
                    algoId = mode.id,
                    algoLabel = mode.label,
                    direction = r.first,
                    score = r.second,
                    detail = r.third,
                    sample = seq.size,
                    confidence = confLabel(r.second)
                )
            }
        }
        return map
    }

    private fun pickLabBest(dxSeq: List<String>, dsSeq: List<String>, prefs: UserPrefs): AlgoMode {
        // 简单：在短窗回测上选命中更高的算法
        fun score(mode: AlgoMode, seq: List<String>, labels: List<String>): Double {
            if (seq.size < 20) return 0.5
            var hit = 0
            var n = 0
            for (i in 15 until seq.size) {
                val sub = seq.subList(0, i)
                val (pred, _) = runAlgo(sub, labels, prefs, mode)
                if (pred == seq[i]) hit++
                n++
            }
            return if (n == 0) 0.5 else hit.toDouble() / n
        }
        val modes = listOf(AlgoMode.EXPERIENCE, AlgoMode.PATTERN, AlgoMode.FUSION)
        return modes.maxByOrNull {
            (score(it, dxSeq, listOf("大", "小")) + score(it, dsSeq, listOf("单", "双"))) / 2
        } ?: AlgoMode.EXPERIENCE
    }

    private fun predictCategory(
        seq: List<String>,
        labels: List<String>,
        prefs: UserPrefs,
        category: PredictCategory,
        mode: AlgoMode
    ): DirectionPrediction? {
        if (seq.isEmpty()) return null
        val (dir, score, detail) = runAlgo(seq, labels, prefs, mode)
        return DirectionPrediction(
            category = category,
            direction = dir,
            score = score,
            algo = mode.id,
            detail = detail
        )
    }

    /**
     * 对外：单序列方向预测（图表回测 / 经验学习 / 形态匹配）。
     * @return 预测标签；序列不足时回退 labels 首项。
     */
    fun predictLabel(
        seq: List<String>,
        labels: List<String>,
        prefs: UserPrefs = UserPrefs(),
        mode: AlgoMode
    ): String {
        if (labels.isEmpty()) return ""
        if (seq.size < 3) return labels.first()
        return runAlgo(seq, labels, prefs, mode).first
    }

    /**
     * 对外：多候选方向（组合 TopN）。
     */
    fun predictTopLabels(
        seq: List<String>,
        labels: List<String>,
        prefs: UserPrefs = UserPrefs(),
        mode: AlgoMode,
        topN: Int = 3
    ): List<String> {
        if (labels.isEmpty()) return emptyList()
        if (seq.size < 3) return labels.take(topN.coerceAtLeast(1))
        val scores = when (mode) {
            AlgoMode.PATTERN -> patternScores(seq, labels)
            AlgoMode.FUSION -> fusionScores(seq, labels, prefs)
            else -> experienceScores(seq, labels, prefs)
        }
        val norm = normalize(scores, prefs.ewmaWeightTemperature.toDouble())
        return norm.entries.sortedByDescending { it.value }.take(topN.coerceIn(1, labels.size)).map { it.key }
    }

    /** @return Triple(direction, score 0~1, detail) */
    private fun runAlgo(
        seq: List<String>,
        labels: List<String>,
        prefs: UserPrefs,
        mode: AlgoMode
    ): Triple<String, Double, String> {
        val scores = when (mode) {
            AlgoMode.PATTERN -> patternScores(seq, labels)
            AlgoMode.MANUAL -> experienceScores(seq, labels, prefs) // 实际方向由 ViewModel 用手动标记覆盖
            AlgoMode.FUSION -> fusionScores(seq, labels, prefs)
            AlgoMode.LAB_BEST, AlgoMode.COMPARE, AlgoMode.EXPERIENCE ->
                experienceScores(seq, labels, prefs)
        }
        val norm = normalize(scores, prefs.ewmaWeightTemperature.toDouble())
        val best = norm.maxByOrNull { it.value } ?: return Triple(labels.first(), 0.5, "")
        val detail = norm.entries.sortedByDescending { it.value }
            .joinToString(" ") { "${it.key}:${"%.0f".format(it.value * 100)}%" }
        return Triple(best.key, best.value, detail)
    }

    /** 经验学习：多窗频率 + EWMA + 一阶转移 */
    private fun experienceScores(
        seq: List<String>,
        labels: List<String>,
        prefs: UserPrefs
    ): Map<String, Double> {
        val labelSet = labels.toSet()
        // 只保留合法标签,避免脏数据(如号码 13 不在 1..10)触发 getValue 崩溃
        val clean = seq.filter { it in labelSet }
        val scores = labels.associateWith { 0.0 }.toMutableMap()
        if (clean.isEmpty()) return scores
        listOf(10, 20, 50).forEachIndexed { i, w ->
            val slice = clean.takeLast(w.coerceAtMost(clean.size))
            val wt = when (i) { 0 -> 0.35; 1 -> 0.35; else -> 0.30 }
            labels.forEach { lab ->
                scores[lab] = (scores[lab] ?: 0.0) +
                    slice.count { it == lab }.toDouble() / slice.size.coerceAtLeast(1) * wt
            }
        }
        if (prefs.ewmaEnabled) {
            val alpha = prefs.ewmaAlpha.toDouble().coerceIn(0.05, 0.5)
            val ewma = labels.associateWith { 1.0 / labels.size }.toMutableMap()
            clean.forEach { x ->
                labels.forEach { lab ->
                    val t = if (lab == x) 1.0 else 0.0
                    ewma[lab] = alpha * t + (1 - alpha) * (ewma[lab] ?: 0.0)
                }
            }
            labels.forEach { lab ->
                scores[lab] = (scores[lab] ?: 0.0) * 0.55 + (ewma[lab] ?: 0.0) * 0.45
            }
        }
        if (clean.size >= 2) {
            val last = clean.last()
            val trans = labels.associateWith { 0.0 }.toMutableMap()
            var c = 0
            for (i in 1 until clean.size) {
                if (clean[i - 1] == last) {
                    val next = clean[i]
                    if (next in labelSet) {
                        trans[next] = (trans[next] ?: 0.0) + 1
                        c++
                    }
                }
            }
            if (c > 0) {
                labels.forEach { lab ->
                    scores[lab] = (scores[lab] ?: 0.0) * 0.7 + ((trans[lab] ?: 0.0) / c) * 0.3
                }
            }
        }
        if (prefs.streakDecayEnabled) {
            val last = clean.last()
            if (last in labelSet) {
                var streak = 0
                for (i in clean.indices.reversed()) {
                    if (clean[i] == last) streak++ else break
                }
                if (streak >= 3) {
                    scores[last] = (scores[last] ?: 0.0) * (1.0 - 0.08 * prefs.antiHerdStrength)
                }
            }
        }
        return scores
    }

    /** 形态匹配：找历史中与近期尾部相同的片段，看下一期分布 */
    private fun patternScores(seq: List<String>, labels: List<String>): Map<String, Double> {
        val scores = labels.associateWith { 0.01 }.toMutableMap()
        if (seq.size < 6) return frequencyScores(seq, labels)
        for (len in listOf(2, 3, 4, 5)) {
            if (seq.size <= len) continue
            val pattern = seq.takeLast(len)
            var hits = 0
            for (i in 0 until seq.size - len) {
                val slice = seq.subList(i, i + len)
                if (slice == pattern) {
                    val next = seq.getOrNull(i + len) ?: continue
                    if (next in scores) {
                        scores[next] = scores.getValue(next) + 1.0 * (6 - len)
                        hits++
                    }
                }
            }
            if (hits == 0) {
                // 回退频率
                val freq = frequencyScores(seq.takeLast(20), labels)
                labels.forEach { scores[it] = scores.getValue(it) + freq.getValue(it) }
            }
        }
        return scores
    }

    /** 智能融合：经验 + 形态加权平均 */
    private fun fusionScores(
        seq: List<String>,
        labels: List<String>,
        prefs: UserPrefs
    ): Map<String, Double> {
        val a = experienceScores(seq, labels, prefs)
        val b = patternScores(seq, labels)
        val na = normalize(a, 0.1)
        val nb = normalize(b, 0.1)
        return labels.associateWith { lab ->
            na.getValue(lab) * 0.55 + nb.getValue(lab) * 0.45
        }
    }

    private fun frequencyScores(seq: List<String>, labels: List<String>): Map<String, Double> {
        if (seq.isEmpty()) return labels.associateWith { 1.0 / labels.size }
        return labels.associateWith { lab ->
            seq.count { it == lab }.toDouble() / seq.size
        }
    }

    private fun normalize(scores: Map<String, Double>, temp: Double): Map<String, Double> {
        val t = temp.coerceIn(0.02, 0.5)
        val maxS = scores.values.maxOrNull() ?: 1.0
        val expMap = scores.mapValues { (_, v) -> exp((v - maxS) / t) }
        val sum = expMap.values.sum().coerceAtLeast(1e-9)
        return expMap.mapValues { it.value / sum }
    }

    private fun confLabel(score: Double): String = when {
        score >= 0.62 -> "高"
        score >= 0.52 -> "中"
        else -> "低"
    }


    private fun topDirections(
        seq: List<String>,
        labels: List<String>,
        prefs: UserPrefs,
        mode: AlgoMode,
        topN: Int
    ): List<DirectionPrediction> {
        if (seq.isEmpty()) return emptyList()
        val scores = when (mode) {
            AlgoMode.PATTERN -> patternScores(seq, labels)
            AlgoMode.FUSION -> fusionScores(seq, labels, prefs)
            else -> experienceScores(seq, labels, prefs)
        }
        val norm = normalize(scores, prefs.ewmaWeightTemperature.toDouble())
        return norm.entries.sortedByDescending { it.value }.take(topN.coerceAtLeast(1)).map { (dir, sc) ->
            DirectionPrediction(
                category = PredictCategory.COMBO,
                direction = dir,
                score = sc,
                algo = mode.id,
                detail = "候选"
            )
        }
    }

    private fun numberFrequency(recent: List<DrawRecord>, range: IntRange, topN: Int): List<NumberScore> {
        val cnt = range.associateWith { 0 }.toMutableMap()
        recent.forEach { row ->
            row.numbers.forEach { n -> if (n in range) cnt[n] = cnt.getValue(n) + 1 }
        }
        val total = recent.size.coerceAtLeast(1).toDouble()
        return cnt.entries.sortedByDescending { it.value }
            .mapIndexed { idx, e -> NumberScore(e.key, e.value / total, idx + 1) }
            .take(topN)
    }

    private fun positionPredict(
        recent: List<DrawRecord>,
        posCount: Int,
        topN: Int,
        mode: AlgoMode,
        prefs: UserPrefs,
        numberRange: IntRange = 1..10
    ): List<PositionPrediction> {
        val labels = numberRange.map { it.toString() }
        return (0 until posCount).map { idx ->
            val seq = recent.mapNotNull { it.numbers.getOrNull(idx)?.toString() }
            val (best, _, detail) = runAlgo(seq, labels, prefs, mode)
            val scores = when (mode) {
                AlgoMode.PATTERN -> patternScores(seq, labels)
                AlgoMode.FUSION -> fusionScores(seq, labels, prefs)
                else -> experienceScores(seq, labels, prefs)
            }
            val normalized = normalize(scores, prefs.ewmaWeightTemperature.toDouble())
            val tops = normalized.entries.sortedByDescending { it.value }.take(topN.coerceAtLeast(1))
                .mapIndexed { rank, entry ->
                    NumberScore(entry.key.toIntOrNull() ?: 0, entry.value, rank + 1)
                }.filter { it.number in numberRange }
            PositionPrediction(
                positionIndex = idx,
                positionName = positionName(idx),
                topNumbers = tops,
                algo = mode.id,
                detail = "首选 $best · $detail"
            )
        }
    }

    /**
     * 快乐8 类：单一号码池预测。
     * 统计历史每期 20 个开奖号在 1～80 上的频率/算法得分，取 TopN。
     * 投注命中：所选号码与当期开出的任一号码相同即中。
     */
    private fun luck20NumberPoolPredict(
        recent: List<DrawRecord>,
        topN: Int,
        mode: AlgoMode,
        prefs: UserPrefs
    ): PositionPrediction {
        val labels = (1..80).map { it.toString() }
        // 将每期开出的全部号码展平为序列，供频率/EWMA 类算法使用
        val seq = recent.flatMap { d -> d.numbers.filter { it in 1..80 }.map { it.toString() } }
        val scores = when (mode) {
            AlgoMode.PATTERN -> patternScores(seq, labels)
            AlgoMode.FUSION -> fusionScores(seq, labels, prefs)
            else -> experienceScores(seq, labels, prefs)
        }
        val normalized = normalize(scores, prefs.ewmaWeightTemperature.toDouble())
        val tops = normalized.entries.sortedByDescending { it.value }
            .take(topN.coerceIn(1, 20))
            .mapIndexed { rank, entry ->
                NumberScore(entry.key.toIntOrNull() ?: 0, entry.value, rank + 1)
            }.filter { it.number in 1..80 }
        val best = tops.firstOrNull()?.number?.toString() ?: "-"
        return PositionPrediction(
            positionIndex = 0,
            positionName = "任选号码",
            topNumbers = tops,
            algo = mode.id,
            detail = "任选 Top${tops.size} · 首选 $best · 与开奖任一号码相同即中"
        )
    }

    private fun positionName(index: Int): String = when (index) {
        0 -> "冠军"
        1 -> "亚军"
        else -> "第${index + 1}"
    }

    /**
     * 根据当前期号推断下一期。
     * - 纯数字期号: +1
     * - 带日期前缀的期号(如 20260825012): 尽量对末尾序号 +1
     * - 无法解析时原样返回,避免界面空白
     */
    fun suggestNextIssue(latest: String?): String {
        if (latest.isNullOrBlank()) return "-"
        val trimmed = latest.trim()
        // 纯数字
        trimmed.toLongOrNull()?.let { return (it + 1L).toString() }
        // 末尾连续数字作为序号(常见: yyyyMMdd + 序号)
        val match = Regex("^(.*?)(\\d+)$").find(trimmed)
        if (match != null) {
            val prefix = match.groupValues[1]
            val numStr = match.groupValues[2]
            val next = (numStr.toLongOrNull() ?: return trimmed) + 1L
            // 保持原有位数(前导零)
            val nextStr = next.toString().padStart(numStr.length, '0')
            return prefix + nextStr
        }
        return trimmed
    }
}
