package com.caifenxi.app.data.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * 工作台回测结果持久化缓存（v18 新增）。
 *
 * 目的：切换分类玩法 / 一期二期三期 / 直选档位、重启 App、换彩种回来时，
 * 直接命中本地回测结果，避免重复全量回测。
 *
 * 键 = cacheKey（含彩种前缀），语义与 WorkbenchBacktestCache.key 一致：
 * lotteryKey|planId|stage|periods|lastIssue|invert|outputCount|directKey|histSize。
 * reportText 为 ChartReport 的紧凑文本序列化（含点数序列 points 与 roundResults），
 * 加载时反序列化还原出 PlanRuntime/ChartReport，lastIssue 不匹配即视为失效需重算。
 */
@Entity(tableName = "workbench_backtest_cache")
data class WorkbenchBacktestCacheEntity(
    @PrimaryKey val cacheKey: String,
    val lotteryKey: String,
    val planId: String,
    val stage: Int,
    val periods: Int,
    val lastIssue: String,
    val directKey: String,
    val reportText: String,
    val updatedAt: Long
)