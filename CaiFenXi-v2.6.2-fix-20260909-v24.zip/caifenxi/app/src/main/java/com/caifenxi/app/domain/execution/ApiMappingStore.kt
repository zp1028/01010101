package com.caifenxi.app.domain.execution

import android.content.Context
import android.content.SharedPreferences
import com.caifenxi.app.util.RuntimeLog
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * API 映射表存储：按站点+玩法聚合网络日志，生成可复用的 API 投注模板。
 * 映射表持久化到 SharedPreferences。
 */
object ApiMappingStore {

    private const val PREFS = "api_mapping_store"
    private const val MIN_SAMPLES = 3
    private const val MIN_CONFIDENCE = 0.85f

    @Serializable
    data class ApiMapping(
        val domain: String = "",
        val playType: String = "",      // dx / ds / combo / number / direct_select
        val url: String = "",
        val method: String = "POST",
        val headerTemplate: Map<String, String> = emptyMap(), // 静态 header，$TOKEN 占位
        val bodyTemplate: Map<String, String> = emptyMap(),   // 模板字段，$ISSUE/$AMOUNT/$NUM/$POS
        val inputFormat: String = "",    // 直选单式专用：号码格式模板 "$NUM1,$NUM2"
        val successPattern: String = "", // 响应成功标识：如 "code==0"
        val sampleCount: Int = 0,
        val confidence: Float = 0f,      // 0-1
        val apiVersion: String = "",     // 从响应头提取的版本号
        val createdAt: Long = System.currentTimeMillis()
    ) {
        val isReady: Boolean
            get() = sampleCount >= MIN_SAMPLES && confidence >= MIN_CONFIDENCE
    }

    @Serializable
    data class ApiProfile(
        val domain: String = "",
        val tokenSource: String = "cookie", // cookie / localStorage / jsVariable
        val tokenKey: String = "",
        val tokenExpiryMs: Long = 1_800_000L, // 30min default
        val refreshUrl: String = "",
        val mappings: List<ApiMapping> = emptyList()
    ) {
        /** 获取某玩法的映射 */
        fun mappingFor(playType: String): ApiMapping? =
            mappings.find { it.playType == playType && it.isReady }

        /** 该站点是否所有指定玩法都已就绪 */
        fun isReadyFor(playTypes: List<String>): Boolean =
            playTypes.all { pt -> mappingFor(pt) != null }

        /** 已就绪的玩法列表 */
        fun readyPlayTypes(): List<String> =
            mappings.filter { it.isReady }.map { it.playType }.distinct()
    }

    /** 获取某站点的 API Profile */
    fun getProfile(context: Context, domain: String): ApiProfile {
        val json = getPrefs(context).getString("profile_$domain", "") ?: return ApiProfile(domain = domain)
        return try {
            Json.decodeFromString(json)
        } catch (_: Exception) {
            ApiProfile(domain = domain)
        }
    }

    /** 保存 Profile */
    fun saveProfile(context: Context, profile: ApiProfile) {
        try {
            val json = Json.encodeToString(profile)
            getPrefs(context).edit().putString("profile_${profile.domain}", json).apply()
        } catch (e: Exception) {
            RuntimeLog.warn("ApiMappingStore", "保存失败: ${e.message}")
        }
    }

    /** 删除某站点映射 */
    fun removeProfile(context: Context, domain: String) {
        getPrefs(context).edit().remove("profile_$domain").apply()
    }

    /** 从网络日志生成/更新映射表 */
    fun rebuildFromLogs(context: Context, domain: String) {
        val logs = NetworkLogStore.getLogsByDomain(context, domain)
        if (logs.isEmpty()) return

        val existing = getProfile(context, domain)
        val playTypeGroups = logs.groupBy { it.playType }

        val newMappings = existing.mappings.toMutableList()

        for ((playType, entries) in playTypeGroups) {
            if (playType.isBlank()) continue
            // 只取成功的请求
            val successEntries = entries.filter { it.response.status in 200..299 }
            if (successEntries.size < MIN_SAMPLES) continue

            // 检查一致性
            val urls = successEntries.map { it.request.url }.distinct()
            val methods = successEntries.map { it.request.method }.distinct()
            if (urls.size != 1 || methods.size != 1) continue

            // 解析 body 找静态/动态字段
            val bodySamples = successEntries.mapNotNull {
                try { org.json.JSONObject(it.request.body) } catch (_: Exception) { null }
            }
            if (bodySamples.size < MIN_SAMPLES) continue

            val commonKeys = bodySamples.first().keys().asSequence().toList()
                .filter { key -> bodySamples.all { it.has(key) } }

            val template = mutableMapOf<String, String>()
            for (key in commonKeys) {
                val values = bodySamples.map { it.optString(key, "") }.distinct()
                template[key] = if (values.size == 1) values.first() else "DYNAMIC"
            }

            // 简单置信度：动态字段比例越低越可靠
            val dynamicCount = template.values.count { it == "DYNAMIC" }
            val confidence = 1f - (dynamicCount.toFloat() / template.size.coerceAtLeast(1))

            // 构建或更新映射
            val idx = newMappings.indexOfFirst { it.playType == playType }
            val mapping = ApiMapping(
                domain = domain,
                playType = playType,
                url = urls.first(),
                method = methods.first(),
                bodyTemplate = template,
                sampleCount = successEntries.size,
                confidence = confidence,
                apiVersion = "", // TODO: extract from response headers if available
                createdAt = if (idx >= 0) newMappings[idx].createdAt else System.currentTimeMillis()
            )

            if (idx >= 0) {
                newMappings[idx] = mapping
            } else {
                newMappings.add(mapping)
            }

            RuntimeLog.info("ApiMappingStore", "映射生成/更新 $domain $playType samples=${successEntries.size} confidence=${String.format("%.2f", confidence)}")
        }

        saveProfile(context, existing.copy(mappings = newMappings))
    }

    /** 检查某站点是否需要提醒用户数据已够 */
    fun shouldNotify(context: Context, domain: String, activePlayTypes: List<String>): Boolean {
        val profile = getProfile(context, domain)
        return profile.isReadyFor(activePlayTypes)
    }

    private fun getPrefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
