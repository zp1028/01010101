package com.caifenxi.app.domain.execution

import android.content.Context
import com.caifenxi.app.CaiFenXiApplication
import com.caifenxi.app.util.RuntimeLog
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * 当期工单快照：给网页/挂机 UI 展示，并做「同期不重复点击」。
 */
data class ExecutionTicket(
    val cmdId: String = "",
    val lotteryKey: String = "",
    val issue: String = "",
    val planLabel: String = "",
    val stage: Int = 1,
    val leg: Int = 0,
    val dx: String? = null,
    val ds: String? = null,
    val amountText: String? = null,
    /** v2.6.2: 直选单式号码组合列表，跟随计划预测的注数 */
    val numbers: List<String> = emptyList(),
    val status: String = "IDLE",
    val message: String = "",
    val balanceBefore: String = "",
    val balanceAfter: String = "",
    val updatedAt: Long = 0L
)

object ExecutionTicketStore {
    private val _ticket = MutableStateFlow(ExecutionTicket())
    val ticket: StateFlow<ExecutionTicket> = _ticket.asStateFlow()

    /** lotteryKey|issue 已成功点击过 */
    private val placedIssues = LinkedHashSet<String>()
    /** 已处理过的 cmdId */
    private val doneCmdIds = LinkedHashSet<String>()
    /** 正在真实执行的彩种/期号；同一期只允许一个真实执行会话。 */
    private val activeIssues = LinkedHashSet<String>()
    /** 已确认点击（confirm 已触发）的彩种/期号；永久锁定，绝不允许再次执行。
     *  与 placedIssues 的区别：placedIssues 仅在 SUCCESS 时写入，
     *  而 confirmedIssues 在确认按钮点击瞬间即写入，无论后续结果 SUCCESS/FAILED/UNKNOWN。 */
    private val confirmedIssues = LinkedHashSet<String>()

    @Synchronized
    fun publish(ticket: ExecutionTicket) {
        _ticket.value = ticket
    }

    @Synchronized
    fun updateStatus(
        cmdId: String,
        status: String,
        message: String,
        balanceBefore: String = _ticket.value.balanceBefore,
        balanceAfter: String = _ticket.value.balanceAfter
    ) {
        val cur = _ticket.value
        if (cur.cmdId == cmdId || cmdId.isBlank()) {
            _ticket.value = cur.copy(
                status = status,
                message = message,
                balanceBefore = balanceBefore,
                balanceAfter = balanceAfter,
                updatedAt = System.currentTimeMillis()
            )
        }
        if (status == "SUCCESS" && cur.lotteryKey.isNotBlank() && cur.issue.isNotBlank()) {
            markPlaced(cur.lotteryKey, cur.issue)
        }
        // v2.5.3: COMMITTED_UNKNOWN 状态也确保确认锁写入（防止 markConfirmed 调用遗漏）
        if (status == "COMMITTED_UNKNOWN" && cur.lotteryKey.isNotBlank() && cur.issue.isNotBlank()) {
            markConfirmed(cur.lotteryKey, cur.issue)
        }
        // 仅终态记 done，PENDING/QUEUED/RUNNING 仍可重试/补点
        if (cmdId.isNotBlank() && status in TERMINAL) markCmdDone(cmdId)
    }

    /** v2.5.3: TERMINAL 增加 COMMITTED_UNKNOWN — 确认已点击但结果未知也是终态 */
    private val TERMINAL = setOf("SUCCESS", "FAILED", "COMMITTED_UNKNOWN", "SKIPPED", "EXPIRED", "LEDGER", "CANCELLED")

    @Synchronized
    fun isIssuePlaced(lotteryKey: String, issue: String): Boolean =
        placedIssues.contains("$lotteryKey|$issue")

    /** 同一期是否已点击过确认按钮（永久锁，无论结果 SUCCESS/FAILED/UNKNOWN） */
    @Synchronized
    fun isIssueConfirmed(lotteryKey: String, issue: String): Boolean =
        confirmedIssues.contains("$lotteryKey|$issue")

    @Synchronized
    fun isCmdDone(cmdId: String): Boolean = cmdId.isNotBlank() && doneCmdIds.contains(cmdId)

    @Synchronized
    fun claimIssue(lotteryKey: String, issue: String): Boolean {
        if (lotteryKey.isBlank() || issue.isBlank()) return false
        val key = "$lotteryKey|$issue"
        if (placedIssues.contains(key) || activeIssues.contains(key) || confirmedIssues.contains(key)) return false
        activeIssues.add(key)
        while (activeIssues.size > 40) activeIssues.remove(activeIssues.first())
        return true
    }

    /**
     * 确认按钮已点击 → 立即永久锁定本期。
     * 调用后无论后续结果 SUCCESS / FAILED / UNKNOWN / TIMEOUT，
     * 同一期绝不允许再次自动点击。
     */
    @Synchronized
    fun markConfirmed(lotteryKey: String, issue: String) {
        if (lotteryKey.isBlank() || issue.isBlank()) return
        val key = "$lotteryKey|$issue"
        confirmedIssues.add(key)
        activeIssues.remove(key)
        while (confirmedIssues.size > MAX_CONFIRMED) confirmedIssues.remove(confirmedIssues.first())
        persistLocks()
        RuntimeLog.info(
            "Execution",
            "confirmLock ${lotteryKey}/${issue} -> 本期已永久锁定（确认按钮已点击）"
        )
    }

    @Synchronized
    fun releaseIssue(lotteryKey: String, issue: String) {
        if (lotteryKey.isBlank() || issue.isBlank()) return
        val key = "$lotteryKey|$issue"
        // 已确认点击的期号绝不释放
        if (confirmedIssues.contains(key)) return
        activeIssues.remove(key)
    }

    @Synchronized
    fun isIssueActive(lotteryKey: String, issue: String): Boolean =
        activeIssues.contains("$lotteryKey|$issue")

    @Synchronized
    fun markPlaced(lotteryKey: String, issue: String) {
        val key = "$lotteryKey|$issue"
        activeIssues.remove(key)
        confirmedIssues.add(key)
        placedIssues.add(key)
        while (placedIssues.size > MAX_PLACED) placedIssues.remove(placedIssues.first())
        while (confirmedIssues.size > MAX_CONFIRMED) confirmedIssues.remove(confirmedIssues.first())
        persistLocks()
    }

    /** v2.5.3: confirmedIssues 持久化的 SharedPreferences 文件名 */
    private const val PREFS_NAME = "cfx_execution_lock"
    private const val CONFIRMED_KEY = "confirmed_issues"
    private const val PLACED_KEY = "placed_issues"
    /** v2.5.3: 容量提升至 200（LRU 淘汰） */
    private const val MAX_CONFIRMED = 200
    private const val MAX_PLACED = 200

    /** v2.5.3: 启动时从 SharedPreferences 恢复锁状态（App 重启后锁不丢失） */
    @Synchronized
    fun restoreFromPersistence() {
        try {
            val ctx = CaiFenXiApplication.instance
            val sp = ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            sp.getStringSet(CONFIRMED_KEY, emptySet())?.forEach { confirmedIssues.add(it) }
            sp.getStringSet(PLACED_KEY, emptySet())?.forEach { placedIssues.add(it) }
            if (confirmedIssues.isNotEmpty() || placedIssues.isNotEmpty()) {
                RuntimeLog.info("Execution", "锁状态恢复: confirmed=${confirmedIssues.size} placed=${placedIssues.size}")
            }
        } catch (e: Exception) {
            RuntimeLog.warn("Execution", "锁状态恢复失败: ${e.message}")
        }
    }

    /** v2.5.3: 将 confirmedIssues + placedIssues 持久化到 SharedPreferences */
    @Synchronized
    private fun persistLocks() {
        try {
            val ctx = CaiFenXiApplication.instance
            val sp = ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            sp.edit()
                .putStringSet(CONFIRMED_KEY, confirmedIssues.toSet())
                .putStringSet(PLACED_KEY, placedIssues.toSet())
                .apply()
        } catch (e: Exception) {
            RuntimeLog.warn("Execution", "锁状态持久化失败: ${e.message}")
        }
    }

    @Synchronized
    fun markCmdDone(cmdId: String) {
        if (cmdId.isBlank()) return
        doneCmdIds.add(cmdId)
        while (doneCmdIds.size > 120) doneCmdIds.remove(doneCmdIds.first())
    }

    fun stageLabel(stage: Int, leg: Int): String {
        val name = when (stage) {
            2 -> "二期"
            3 -> "三期"
            else -> "一期"
        }
        return if (stage >= 2) "$name L${leg + 1}" else name
    }
}
