package com.caifenxi.app.domain.strategy

import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.LotteryType

/**
 * 策略池计划定义（独立于原有 PlanDefinition，完全隔离）。
 *
 * 三轨架构：
 * - A轨：大小/单双，贝叶斯融合，目标单期53%
 * - B轨：组合2口，互补对冲，目标单期55%+
 * - C轨：组合3口，天然75%+，排除最不可能口
 */
data class StrategyDefinition(
    val planId: String,
    val planName: String,
    val track: StrategyTrack,
    val playType: String,          // "大小" / "单双" / "组合"
    val algorithm: String,        // "BAYES_FUSION" / "HEDGE_2" / "EXCLUDE_1"
    val window: Int = 50,
    val cyclePeriods: Int = 1,     // 1=一期, 2=二期, 3=三期
    val positionIndex: Int = -1,   // -1=非位置玩法
    val supportedTypes: Set<LotteryType> = emptySet(),
    /** 基准胜率：大小单双0.50，组合2口0.50，组合3口0.75 */
    val baselineValue: Double = 0.50,
    /** 单注金额（回测用） */
    val stake: Double = 10.0,
    /** 倍投倍数：大小单双/组合2口=2.0，组合3口=2.0 */
    val stageMult: Double = 2.0
) {
    val isCombo: Boolean get() = playType == "组合"
    val comboCount: Int get() = when (track) {
        StrategyTrack.TRACK_B -> 2
        StrategyTrack.TRACK_C -> 3
        else -> 0
    }
}

/**
 * 策略轨道
 */
enum class StrategyTrack(val label: String, val desc: String) {
    TRACK_A("A轨·大小单双", "贝叶斯融合引擎 · 追求alpha · 高赔率"),
    TRACK_B("B轨·组合2口", "互补对冲策略 · 高命中率稳定器"),
    TRACK_C("C轨·组合3口", "排除最不可能口 · 天然保底")
}

/**
 * 策略预测结果
 */
data class StrategyPrediction(
    val planId: String,
    val output: String,            // "大" / "小" / "大双/小双" 等
    val confidence: Double,       // 置信度 0~1
    val scores: Map<String, Double> = emptyMap(),  // 各候选概率
    val detail: String = ""
)

/**
 * 策略回测报告（单计划）
 */
data class StrategyBacktestReport(
    val planId: String,
    val planName: String,
    val track: StrategyTrack,
    val playType: String,
    val stage: Int,               // 回测阶段 1/2/3
    val total: Int,
    val hits: Int,
    val misses: Int,
    val hitRate: Double,          // 命中率
    val baseline: Double,         // 基准
    val edge: Double,             // hitRate - baseline
    val maxHitStreak: Int,
    val maxMissStreak: Int,
    val currentHitStreak: Int,
    val currentMissStreak: Int,
    val stability: Double,        // 稳定性 0~1
    val windowRate: Double,       // 可配置窗口命中率（按轮级别计算）
    val windowRateSize: Int,      // 使用的窗口大小
    val totalStake: Double,       // 总投入
    val totalReturn: Double,       // 总返还
    val netProfit: Double,         // 净收益
    val maxDrawdown: Double,      // 最大回撤
    val peakProfit: Double,       // 峰值收益
    val troughProfit: Double,     // 谷值收益
    val points: List<StrategyChartPoint>  // 曲线点
) {
    val missRate: Double get() = if (total == 0) 0.0 else misses.toDouble() / total
    val roi: Double get() = if (totalStake == 0.0) 0.0 else netProfit / totalStake
    val hitRatePercent: String get() = if (total == 0) "-" else "%.1f%%".format(hitRate * 100)
    val windowRatePercent: String get() = if (total == 0) "-" else "%.1f%%".format(windowRate * 100)
    /** 向后兼容 */
    val twoWindowRate: Double get() = windowRate
    val threeWindowRate: Double get() = windowRate
}

/**
 * 回测曲线点
 */
data class StrategyChartPoint(
    val issue: String,
    val prediction: String,
    val hit: Boolean,
    val stake: Double,
    val periodProfit: Double,
    val cumulativeProfit: Double,
    val peakProfit: Double,
    val troughProfit: Double,
    val drawdown: Double,
    val hitRate: Double
)

/**
 * 策略运行时状态（独立于 PlanRuntime）
 */
data class StrategyRuntime(
    val planId: String,
    val sampleCount: Int = 0,
    val hitCount: Int = 0,
    val consecutiveMiss: Int = 0,
    val consecutiveHit: Int = 0,
    val maxConsecutiveMiss: Int = 0,
    val maxConsecutiveHit: Int = 0,
    val recent10Rate: Double = 0.0,
    val recent50Rate: Double = 0.0,
    val weight: Double = 1.0,
    val status: StrategyStatus = StrategyStatus.ACTIVE,
    val lastPrediction: String? = null,
    val lastTargetIssue: String? = null
) {
    val hitRate: Double get() = if (sampleCount <= 0) 0.0 else hitCount.toDouble() / sampleCount
    val hitRatePercent: String get() = if (sampleCount <= 0) "-" else "%.1f%%".format(hitRate * 100)
}

enum class StrategyStatus {
    ACTIVE, HOLD, ELIMINATED
}

/**
 * 策略预测记录（独立于 PlanPredictionRecord）
 */
data class StrategyPredictionRecord(
    val planId: String,
    val lotteryKey: String,
    val targetIssue: String,
    val cutoffIssue: String,
    val output: String,
    val track: StrategyTrack,
    val playType: String,
    val settled: Boolean = false,
    val hit: Boolean? = null,
    val settledAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)
