package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.LotteryType
import com.caifenxi.app.domain.model.PlanDefinition

/** 谷歌分分彩 / 水管分分彩：和值两面、定位胆、定位大小单双与直选单式计划。 */
object NovaFenFenPlanPool {
    /** @deprecated 请用 forType(type)，避免一次加载双彩种导致卡顿 */
    val ALL: List<PlanDefinition> get() = PlanPoolV2.all(LotteryType.GOOGLE_FF) + PlanPoolV2.all(LotteryType.SHUIGUAN_FF)
    val CANDIDATES: List<PlanDefinition> get() = PlanPoolV2.candidates(LotteryType.GOOGLE_FF) + PlanPoolV2.candidates(LotteryType.SHUIGUAN_FF)

    fun forType(type: LotteryType): List<PlanDefinition> = when (type) {
        LotteryType.GOOGLE_FF, LotteryType.SHUIGUAN_FF -> PlanPoolV2.all(type)
        else -> emptyList()
    }

    fun candidatesFor(type: LotteryType): List<PlanDefinition> = when (type) {
        LotteryType.GOOGLE_FF, LotteryType.SHUIGUAN_FF -> PlanPoolV2.candidates(type)
        else -> emptyList()
    }

    fun find(planId: String): PlanDefinition? =
        PlanPoolV2.find(planId)?.takeIf {
            it.planId.contains("GOOGLE_FF") || it.planId.contains("SHUIGUAN_FF")
        }
}
