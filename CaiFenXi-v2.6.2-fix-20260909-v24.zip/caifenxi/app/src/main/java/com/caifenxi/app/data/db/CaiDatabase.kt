package com.caifenxi.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.caifenxi.app.data.db.dao.BetDao
import com.caifenxi.app.data.db.dao.ConsensusDao
import com.caifenxi.app.data.db.dao.CustomPlanDao
import com.caifenxi.app.data.db.dao.ExecutionTaskDao
import com.caifenxi.app.data.db.dao.DrawDao
import com.caifenxi.app.data.db.dao.ManualMarkDao
import com.caifenxi.app.data.db.dao.StatDao
import com.caifenxi.app.data.db.dao.WorkbenchBacktestCacheDao
import com.caifenxi.app.data.db.entity.BetEntity
import com.caifenxi.app.data.db.entity.BotConfigEntity
import com.caifenxi.app.data.db.entity.ConsensusEntity
import com.caifenxi.app.data.db.entity.CustomPlanEntity
import com.caifenxi.app.data.db.entity.DrawEntity
import com.caifenxi.app.data.db.entity.ManualMarkEntity
import com.caifenxi.app.data.db.entity.StatEntity
import com.caifenxi.app.data.db.entity.WalletEntity
import com.caifenxi.app.data.db.entity.ExecutionTaskEntity
import com.caifenxi.app.data.db.entity.WorkbenchBacktestCacheEntity

@Database(
    entities = [
        DrawEntity::class,
        BetEntity::class,
        BotConfigEntity::class,
        WalletEntity::class,
        StatEntity::class,
        ConsensusEntity::class,
        ManualMarkEntity::class,
        CustomPlanEntity::class,
        ExecutionTaskEntity::class,
        WorkbenchBacktestCacheEntity::class
    ],
    version = 18,
    exportSchema = false
)
abstract class CaiDatabase : RoomDatabase() {
    abstract fun drawDao(): DrawDao
    abstract fun betDao(): BetDao
    abstract fun statDao(): StatDao
    abstract fun consensusDao(): ConsensusDao
    abstract fun manualMarkDao(): ManualMarkDao
    abstract fun customPlanDao(): CustomPlanDao
    abstract fun executionTaskDao(): ExecutionTaskDao
    abstract fun workbenchBacktestCacheDao(): WorkbenchBacktestCacheDao

    companion object {

        // ------------------------------------------------------------------
        // helpers
        // ------------------------------------------------------------------

        
        /** V2.0: 创建 execution_tasks 表 */
        private fun createExecutionTasksTable(db: SupportSQLiteDatabase) {
            db.execSQL(
                """
                CREATE TABLE IF NOT EXISTS `execution_tasks` (
                    `cmdId` TEXT NOT NULL,
                    `lotteryKey` TEXT NOT NULL,
                    `issue` TEXT NOT NULL,
                    `stage` INTEGER NOT NULL,
                    `leg` INTEGER NOT NULL,
                    `state` TEXT NOT NULL,
                    `commandJson` TEXT NOT NULL,
                    `resultJson` TEXT,
                    `retryOf` TEXT,
                    `createdAt` INTEGER NOT NULL,
                    `lockedAt` INTEGER,
                    `executedAt` INTEGER,
                    `verifiedAt` INTEGER,
                    `completedAt` INTEGER,
                    PRIMARY KEY(`cmdId`)
                )
                """.trimIndent()
            )
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_execution_tasks_lotteryKey_state` ON `execution_tasks` (`lotteryKey`, `state`)")
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_execution_tasks_state` ON `execution_tasks` (`state`)")
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_execution_tasks_createdAt` ON `execution_tasks` (`createdAt`)")
        }

        private fun tableExists(db: SupportSQLiteDatabase, name: String): Boolean {
            db.query("SELECT name FROM sqlite_master WHERE type='table' AND name=?", arrayOf(name)).use {
                return it.moveToFirst()
            }
        }

        private fun columnExists(db: SupportSQLiteDatabase, table: String, column: String): Boolean {
            db.query("PRAGMA table_info(`$table`)").use { c ->
                val nameIdx = c.getColumnIndex("name")
                while (c.moveToNext()) {
                    if (c.getString(nameIdx) == column) return true
                }
            }
            return false
        }

        private fun addColumnIfMissing(
            db: SupportSQLiteDatabase,
            table: String,
            column: String,
            typeDef: String
        ) {
            if (tableExists(db, table) && !columnExists(db, table, column)) {
                db.execSQL("ALTER TABLE `$table` ADD COLUMN `$column` $typeDef")
            }
        }

        /** 重建 stats 表并加上 UNIQUE 索引(保留数据) */
        private fun rebuildStatsWithUniqueIndex(db: SupportSQLiteDatabase) {
            if (!tableExists(db, "stats")) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `stats` (
                        `id` TEXT NOT NULL,
                        `lotteryKey` TEXT NOT NULL,
                        `issue` TEXT NOT NULL,
                        `category` TEXT NOT NULL,
                        `lean` TEXT NOT NULL,
                        `candidatesJson` TEXT NOT NULL,
                        `actual` TEXT,
                        `result` TEXT NOT NULL,
                        `algoId` TEXT NOT NULL,
                        `score` REAL NOT NULL,
                        `matchMode` TEXT NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `settledAt` INTEGER,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
            } else {
                db.execSQL("DROP INDEX IF EXISTS `index_stats_lotteryKey_issue_category`")
                db.execSQL("DROP INDEX IF EXISTS `index_stats_lotteryKey_createdAt`")
                db.execSQL("ALTER TABLE `stats` RENAME TO `stats_old`")
                db.execSQL(
                    """
                    CREATE TABLE `stats` (
                        `id` TEXT NOT NULL,
                        `lotteryKey` TEXT NOT NULL,
                        `issue` TEXT NOT NULL,
                        `category` TEXT NOT NULL,
                        `lean` TEXT NOT NULL,
                        `candidatesJson` TEXT NOT NULL,
                        `actual` TEXT,
                        `result` TEXT NOT NULL,
                        `algoId` TEXT NOT NULL,
                        `score` REAL NOT NULL,
                        `matchMode` TEXT NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `settledAt` INTEGER,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    INSERT OR IGNORE INTO `stats`
                    (`id`,`lotteryKey`,`issue`,`category`,`lean`,`candidatesJson`,`actual`,`result`,`algoId`,`score`,`matchMode`,`createdAt`,`settledAt`)
                    SELECT `id`,`lotteryKey`,`issue`,`category`,`lean`,`candidatesJson`,`actual`,`result`,`algoId`,`score`,`matchMode`,`createdAt`,`settledAt`
                    FROM `stats_old`
                    """.trimIndent()
                )
                db.execSQL("DROP TABLE `stats_old`")
            }
            db.execSQL(
                "CREATE UNIQUE INDEX IF NOT EXISTS `index_stats_lotteryKey_issue_category` ON `stats` (`lotteryKey`, `issue`, `category`)"
            )
            db.execSQL(
                "CREATE INDEX IF NOT EXISTS `index_stats_lotteryKey_createdAt` ON `stats` (`lotteryKey`, `createdAt`)"
            )
        }

        /** 重建 consensus 表并加上 UNIQUE 索引(保留数据) */
        private fun rebuildConsensusWithUniqueIndex(db: SupportSQLiteDatabase) {
            if (!tableExists(db, "consensus")) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `consensus` (
                        `id` TEXT NOT NULL,
                        `lotteryKey` TEXT NOT NULL,
                        `targetIssue` TEXT NOT NULL,
                        `category` TEXT NOT NULL,
                        `leadingDirection` TEXT NOT NULL,
                        `candidatesJson` TEXT NOT NULL,
                        `supportRatio` REAL NOT NULL,
                        `participatingPlans` INTEGER NOT NULL,
                        `actual` TEXT,
                        `result` TEXT NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `settledAt` INTEGER,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
            } else {
                db.execSQL("DROP INDEX IF EXISTS `index_consensus_lotteryKey_targetIssue_category`")
                db.execSQL("DROP INDEX IF EXISTS `index_consensus_lotteryKey_createdAt`")
                db.execSQL("ALTER TABLE `consensus` RENAME TO `consensus_old`")
                db.execSQL(
                    """
                    CREATE TABLE `consensus` (
                        `id` TEXT NOT NULL,
                        `lotteryKey` TEXT NOT NULL,
                        `targetIssue` TEXT NOT NULL,
                        `category` TEXT NOT NULL,
                        `leadingDirection` TEXT NOT NULL,
                        `candidatesJson` TEXT NOT NULL,
                        `supportRatio` REAL NOT NULL,
                        `participatingPlans` INTEGER NOT NULL,
                        `actual` TEXT,
                        `result` TEXT NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `settledAt` INTEGER,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    INSERT OR IGNORE INTO `consensus`
                    (`id`,`lotteryKey`,`targetIssue`,`category`,`leadingDirection`,`candidatesJson`,`supportRatio`,`participatingPlans`,`actual`,`result`,`createdAt`,`settledAt`)
                    SELECT `id`,`lotteryKey`,`targetIssue`,`category`,`leadingDirection`,`candidatesJson`,`supportRatio`,`participatingPlans`,`actual`,`result`,`createdAt`,`settledAt`
                    FROM `consensus_old`
                    """.trimIndent()
                )
                db.execSQL("DROP TABLE `consensus_old`")
            }
            db.execSQL(
                "CREATE UNIQUE INDEX IF NOT EXISTS `index_consensus_lotteryKey_targetIssue_category` ON `consensus` (`lotteryKey`, `targetIssue`, `category`)"
            )
            db.execSQL(
                "CREATE INDEX IF NOT EXISTS `index_consensus_lotteryKey_createdAt` ON `consensus` (`lotteryKey`, `createdAt`)"
            )
        }

        /** 确保 draws 存在 lotteryKey+issue 的 UNIQUE 索引 */
        private fun ensureDrawsUniqueIndex(db: SupportSQLiteDatabase) {
            if (!tableExists(db, "draws")) return
            // Room 期望的索引名
            db.execSQL("DROP INDEX IF EXISTS `index_draws_lotteryKey_issue`")
            db.execSQL(
                "CREATE UNIQUE INDEX IF NOT EXISTS `index_draws_lotteryKey_issue` ON `draws` (`lotteryKey`, `issue`)"
            )
        }

        /** 确保 bets 存在 lotteryKey+issue 普通索引 */
        private fun ensureBetsIndex(db: SupportSQLiteDatabase) {
            if (!tableExists(db, "bets")) return
            db.execSQL(
                "CREATE INDEX IF NOT EXISTS `index_bets_lotteryKey_issue` ON `bets` (`lotteryKey`, `issue`)"
            )
        }

        /** bot_config 补齐倍投相关列(老库可能没有) */
        private fun ensureBotConfigColumns(db: SupportSQLiteDatabase) {
            if (!tableExists(db, "bot_config")) return
            addColumnIfMissing(db, "bot_config", "winMult", "REAL NOT NULL DEFAULT 1.0")
            addColumnIfMissing(db, "bot_config", "lossMult", "REAL NOT NULL DEFAULT 1.0")
            addColumnIfMissing(db, "bot_config", "winMultPeriods", "INTEGER NOT NULL DEFAULT 1")
            addColumnIfMissing(db, "bot_config", "lossMultPeriods", "INTEGER NOT NULL DEFAULT 1")
            addColumnIfMissing(db, "bot_config", "maxMult", "INTEGER NOT NULL DEFAULT 1")
            addColumnIfMissing(db, "bot_config", "betMode", "TEXT NOT NULL DEFAULT 'forward'")
            addColumnIfMissing(db, "bot_config", "rollingPredict", "INTEGER NOT NULL DEFAULT 0")
            addColumnIfMissing(db, "bot_config", "rollingStage", "INTEGER NOT NULL DEFAULT 1")
            addColumnIfMissing(db, "bot_config", "sourceIdDx", "TEXT NOT NULL DEFAULT ''")
            addColumnIfMissing(db, "bot_config", "sourceIdDs", "TEXT NOT NULL DEFAULT ''")
            addColumnIfMissing(db, "bot_config", "sourceIdCombo", "TEXT NOT NULL DEFAULT ''")
            addColumnIfMissing(db, "bot_config", "updatedAt", "INTEGER NOT NULL DEFAULT 0")
            addColumnIfMissing(db, "bot_config", "execMode", "TEXT NOT NULL DEFAULT 'auto'")
            addColumnIfMissing(db, "bot_config", "dispatchToWeb", "INTEGER NOT NULL DEFAULT 1")
            addColumnIfMissing(db, "bot_config", "guoguanEnabled", "INTEGER NOT NULL DEFAULT 0")
            addColumnIfMissing(db, "bot_config", "guoguanBaseStake", "REAL NOT NULL DEFAULT 10.0")
            addColumnIfMissing(db, "bot_config", "guoguanGateMult", "REAL NOT NULL DEFAULT 2.0")
            addColumnIfMissing(db, "bot_config", "guoguanTotalGates", "INTEGER NOT NULL DEFAULT 3")
            addColumnIfMissing(db, "bot_config", "directNoteRange", "TEXT NOT NULL DEFAULT '全部'")
            addColumnIfMissing(db, "bot_config", "positionTopN", "INTEGER NOT NULL DEFAULT 5")
        }

        /** wallet 补齐统计列 */
        private fun ensureWalletColumns(db: SupportSQLiteDatabase) {
            if (!tableExists(db, "wallet")) return
            addColumnIfMissing(db, "wallet", "initialBalance", "REAL NOT NULL DEFAULT 10000.0")
            addColumnIfMissing(db, "wallet", "balance", "REAL NOT NULL DEFAULT 10000.0")
            addColumnIfMissing(db, "wallet", "totalProfit", "REAL NOT NULL DEFAULT 0.0")
            addColumnIfMissing(db, "wallet", "totalBet", "REAL NOT NULL DEFAULT 0.0")
            addColumnIfMissing(db, "wallet", "winCount", "INTEGER NOT NULL DEFAULT 0")
            addColumnIfMissing(db, "wallet", "loseCount", "INTEGER NOT NULL DEFAULT 0")
            addColumnIfMissing(db, "wallet", "updatedAt", "INTEGER NOT NULL DEFAULT 0")
        }

        /** bets 补齐列 */
        private fun ensureBetsColumns(db: SupportSQLiteDatabase) {
            if (!tableExists(db, "bets")) return
            addColumnIfMissing(db, "bets", "sourceType", "TEXT NOT NULL DEFAULT 'algo'")
            addColumnIfMissing(db, "bets", "sourceId", "TEXT NOT NULL DEFAULT ''")
            addColumnIfMissing(db, "bets", "category", "TEXT NOT NULL DEFAULT ''")
            addColumnIfMissing(db, "bets", "betValue", "TEXT NOT NULL DEFAULT ''")
            addColumnIfMissing(db, "bets", "amount", "REAL NOT NULL DEFAULT 0.0")
            addColumnIfMissing(db, "bets", "odds", "REAL NOT NULL DEFAULT 1.0")
            addColumnIfMissing(db, "bets", "status", "TEXT NOT NULL DEFAULT '待开'")
            addColumnIfMissing(db, "bets", "profit", "REAL NOT NULL DEFAULT 0.0")
            addColumnIfMissing(db, "bets", "createdAt", "INTEGER NOT NULL DEFAULT 0")
            addColumnIfMissing(db, "bets", "settledAt", "INTEGER")
        }

        /** consensus 补齐列 + 索引重建 */
        private fun ensureConsensusColumns(db: SupportSQLiteDatabase) {
            if (!tableExists(db, "consensus")) return
            addColumnIfMissing(db, "consensus", "poolSource", "TEXT NOT NULL DEFAULT 'LEGACY'")
            addColumnIfMissing(db, "consensus", "participatingPlanIds", "TEXT NOT NULL DEFAULT ''")
            addColumnIfMissing(db, "consensus", "consensusVersion", "TEXT NOT NULL DEFAULT ''")
            try {
                db.execSQL("DROP INDEX IF EXISTS index_consensus_lotteryKey_targetIssue_category")
            } catch (_: Exception) {}
            try {
                db.execSQL(
                    "CREATE UNIQUE INDEX IF NOT EXISTS index_consensus_lotteryKey_targetIssue_category_poolSource " +
                        "ON consensus(lotteryKey, targetIssue, category, poolSource)"
                )
            } catch (_: Exception) {}
        }

        private fun ensureManualMarks(db: SupportSQLiteDatabase) {
            db.execSQL(
                """
                CREATE TABLE IF NOT EXISTS `manual_marks` (
                    `lotteryKey` TEXT NOT NULL,
                    `category` TEXT NOT NULL,
                    `direction` TEXT NOT NULL,
                    `updatedAt` INTEGER NOT NULL,
                    PRIMARY KEY(`lotteryKey`, `category`)
                )
                """.trimIndent()
            )
        }

        private fun ensureCustomPlans(db: SupportSQLiteDatabase) {
            db.execSQL(
                """
                CREATE TABLE IF NOT EXISTS `custom_plans` (
                    `planId` TEXT NOT NULL,
                    `lotteryKey` TEXT NOT NULL,
                    `planName` TEXT NOT NULL,
                    `category` TEXT NOT NULL,
                    `algorithm` TEXT NOT NULL,
                    `window` INTEGER NOT NULL,
                    `outputFormat` TEXT NOT NULL,
                    `hitCriteria` TEXT NOT NULL,
                    `enabled` INTEGER NOT NULL,
                    `participateConsensus` INTEGER NOT NULL,
                    `createdAt` INTEGER NOT NULL,
                    `updatedAt` INTEGER NOT NULL,
                    PRIMARY KEY(`planId`)
                )
                """.trimIndent()
            )
            db.execSQL(
                "CREATE INDEX IF NOT EXISTS `index_custom_plans_lotteryKey_enabled` ON `custom_plans` (`lotteryKey`, `enabled`)"
            )
        }

        /** 一次性对齐全部表结构到当前实体定义 */
        private fun ensureFullSchema(db: SupportSQLiteDatabase) {
            rebuildStatsWithUniqueIndex(db)
            rebuildConsensusWithUniqueIndex(db)
            ensureDrawsUniqueIndex(db)
            ensureBetsIndex(db)
            ensureBetsColumns(db)
            ensureConsensusColumns(db)
            ensureBotConfigColumns(db)
            ensureWalletColumns(db)
            ensureManualMarks(db)
            ensureCustomPlans(db)
        }

        // ------------------------------------------------------------------
        // migrations
        // ------------------------------------------------------------------

        private val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // no-op: v5 仅固化既有结构
            }
        }

        private val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                rebuildStatsWithUniqueIndex(db)
                rebuildConsensusWithUniqueIndex(db)
                ensureManualMarks(db)
            }
        }

        private val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                ensureCustomPlans(db)
            }
        }

        /** 修复 unique 索引问题(用户截图报错点) */
        private val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(db: SupportSQLiteDatabase) {
                rebuildStatsWithUniqueIndex(db)
                rebuildConsensusWithUniqueIndex(db)
            }
        }

        /**
         * 全表结构对齐:
         * - draws UNIQUE 索引
         * - bets 索引与列
         * - bot_config 倍投列
         * - wallet 统计列
         * - stats/consensus UNIQUE(幂等)
         * - manual_marks / custom_plans 存在性
         */
        private val MIGRATION_8_9 = object : Migration(8, 9) {
            override fun migrate(db: SupportSQLiteDatabase) {
                ensureFullSchema(db)
            }
        }

        /**
         * 从任意旧版本跨到 9 的兜底路径:
         * 用户若卡在 5/6/7 且中间迁移曾失败,直接走全量对齐。
         */
        private val MIGRATION_5_9 = object : Migration(5, 9) {
            override fun migrate(db: SupportSQLiteDatabase) {
                ensureFullSchema(db)
            }
        }
        private val MIGRATION_6_9 = object : Migration(6, 9) {
            override fun migrate(db: SupportSQLiteDatabase) {
                ensureFullSchema(db)
            }
        }
        private val MIGRATION_7_9 = object : Migration(7, 9) {
            override fun migrate(db: SupportSQLiteDatabase) {
                ensureFullSchema(db)
            }
        }

        private val MIGRATION_9_10 = object : Migration(9, 10) {
            override fun migrate(db: SupportSQLiteDatabase) {
                addColumnIfMissing(db, "custom_plans", "cyclePeriods", "INTEGER NOT NULL DEFAULT 1")
            }
        }

        
        private val MIGRATION_12_13 = object : Migration(12, 13) {
            override fun migrate(db: SupportSQLiteDatabase) {
                addColumnIfMissing(db, "bot_config", "rollingPredict", "INTEGER NOT NULL DEFAULT 0")
                addColumnIfMissing(db, "bot_config", "rollingStage", "INTEGER NOT NULL DEFAULT 1")
            }
        }

        private val MIGRATION_14_15 = object : Migration(14, 15) {
            override fun migrate(db: SupportSQLiteDatabase) {
                createExecutionTasksTable(db)
                // 兜底：旧库升级到 15 时补齐 bot_config/wallet/bets/consensus 可能缺失的列，避免 Room schema 校验失败
                ensureBotConfigColumns(db)
                ensureWalletColumns(db)
                ensureBetsColumns(db)
                ensureConsensusColumns(db)
            }
        }

        /** V16: 过关斩将配置字段（解耦倍投，下注金额只受关数控制） */
        private val MIGRATION_15_16 = object : Migration(15, 16) {
            override fun migrate(db: SupportSQLiteDatabase) {
                addColumnIfMissing(db, "bot_config", "guoguanEnabled", "INTEGER NOT NULL DEFAULT 0")
                addColumnIfMissing(db, "bot_config", "guoguanBaseStake", "REAL NOT NULL DEFAULT 10.0")
                addColumnIfMissing(db, "bot_config", "guoguanGateMult", "REAL NOT NULL DEFAULT 2.0")
                addColumnIfMissing(db, "bot_config", "guoguanTotalGates", "INTEGER NOT NULL DEFAULT 3")
            }
        }

        /** V17: 直选单式注数档位字段（工作台档位选择 → 挂机现算，如 100-200/…/700-800/全部） */
        private val MIGRATION_16_17 = object : Migration(16, 17) {
            override fun migrate(db: SupportSQLiteDatabase) {
                addColumnIfMissing(db, "bot_config", "directNoteRange", "TEXT NOT NULL DEFAULT '全部'")
            addColumnIfMissing(db, "bot_config", "positionTopN", "INTEGER NOT NULL DEFAULT 5")
            }
        }

        /** V18: 工作台回测结果持久化缓存表（避免切换分类/期数/档位、重启后重复全量回测） */
        private val MIGRATION_17_18 = object : Migration(17, 18) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `workbench_backtest_cache` (
                        `cacheKey` TEXT NOT NULL,
                        `lotteryKey` TEXT NOT NULL,
                        `planId` TEXT NOT NULL,
                        `stage` INTEGER NOT NULL,
                        `periods` INTEGER NOT NULL,
                        `lastIssue` TEXT NOT NULL,
                        `directKey` TEXT NOT NULL,
                        `reportText` TEXT NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`cacheKey`)
                    )
                    """.trimIndent()
                )
            }
        }

        private val MIGRATION_13_14 = object : Migration(13, 14) {
            override fun migrate(db: SupportSQLiteDatabase) {
                addColumnIfMissing(db, "bot_config", "sourceIdDx", "TEXT NOT NULL DEFAULT ''")
                addColumnIfMissing(db, "bot_config", "sourceIdDs", "TEXT NOT NULL DEFAULT ''")
                addColumnIfMissing(db, "bot_config", "sourceIdCombo", "TEXT NOT NULL DEFAULT ''")
            }
        }

        private val MIGRATION_11_12 = object : Migration(11, 12) {
            override fun migrate(db: SupportSQLiteDatabase) {
                addColumnIfMissing(db, "consensus", "poolSource", "TEXT NOT NULL DEFAULT 'LEGACY'")
                addColumnIfMissing(db, "consensus", "participatingPlanIds", "TEXT NOT NULL DEFAULT ''")
                addColumnIfMissing(db, "consensus", "consensusVersion", "TEXT NOT NULL DEFAULT ''")
                try {
                    db.execSQL("DROP INDEX IF EXISTS index_consensus_lotteryKey_targetIssue_category")
                } catch (_: Exception) {}
                try {
                    db.execSQL(
                        "CREATE UNIQUE INDEX IF NOT EXISTS index_consensus_lotteryKey_targetIssue_category_poolSource " +
                            "ON consensus(lotteryKey, targetIssue, category, poolSource)"
                    )
                } catch (_: Exception) {}
            }
        }

        private val MIGRATION_10_11 = object : Migration(10, 11) {
            override fun migrate(db: SupportSQLiteDatabase) {
                addColumnIfMissing(db, "bot_config", "betMode", "TEXT NOT NULL DEFAULT 'forward'")
            }
        }

        @Volatile
        private var instance: CaiDatabase? = null

        fun getInstance(context: Context): CaiDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    CaiDatabase::class.java,
                    "caifenxi.db"
                )
                    .addMigrations(
                        MIGRATION_4_5,
                        MIGRATION_5_6,
                        MIGRATION_6_7,
                        MIGRATION_7_8,
                        MIGRATION_8_9,
                        // 跨版本兜底,避免中间迁移失败后无法升级
                        MIGRATION_5_9,
                        MIGRATION_6_9,
                        MIGRATION_7_9,
                        MIGRATION_9_10,
                        MIGRATION_10_11,
                        MIGRATION_11_12,
                        MIGRATION_12_13,
                        MIGRATION_13_14,
                        MIGRATION_14_15,
                        MIGRATION_15_16,
                        MIGRATION_16_17,
                        MIGRATION_17_18
                    )
                    // 仅作最终兜底：正式路径应走 Migration_x_y；destructive 会清空用户数据
                    .fallbackToDestructiveMigration()
                    .build().also { instance = it }
            }
        }
    }
}
