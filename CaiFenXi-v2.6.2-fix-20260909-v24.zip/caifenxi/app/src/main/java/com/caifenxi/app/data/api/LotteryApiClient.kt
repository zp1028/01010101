package com.caifenxi.app.data.api

import com.caifenxi.app.domain.model.ApiConfig
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.LotteryConfig
import com.caifenxi.app.domain.model.LotteryBetRules
import com.caifenxi.app.domain.model.LotteryType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.TimeUnit

class LotteryApiClient {

    private val client = OkHttpClient.Builder()
        .connectTimeout(ApiConfig.TIMEOUT_MS, TimeUnit.MILLISECONDS)
        .readTimeout(ApiConfig.TIMEOUT_MS, TimeUnit.MILLISECONDS)
        .build()

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }
    private val dayFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    /** {主域名}/{路径}?lotCode=&apiKey= 可选 date= */
    private fun buildUrl(base: String, path: String, lotCode: Int, date: String? = null): String {
        val p = path.trim().trimStart('/')
        val sb = StringBuilder()
        sb.append(base.trimEnd('/')).append('/').append(p)
        sb.append("?lotCode=").append(lotCode)
        if (!date.isNullOrBlank()) sb.append("&date=").append(date)
        sb.append("&apiKey=").append(ApiConfig.API_KEY)
        return sb.toString()
    }

    private fun historyEndpoint(config: LotteryConfig): String {
        if (config.historyPath.isNotBlank()) return config.historyPath
        return when (config.type) {
            LotteryType.LUCK20 -> "LuckTwenty/getBaseLuckTwentyList.do"
            LotteryType.PKS -> "pks/getPksHistoryList.do"
            LotteryType.K3 -> "CQShiCai/getBaseCQShiCaiList.do"
            LotteryType.PC28 -> "Canada28/getBaseCanada28List.do"
            LotteryType.YDH -> "yundong/getYunDongHistoryList.do"
            LotteryType.GOOGLE_FF, LotteryType.SHUIGUAN_FF -> ""
            LotteryType.OTHER -> "CQShiCai/getBaseCQShiCaiList.do"
        }
    }

    private fun latestEndpoints(config: LotteryConfig): List<String> {
        if (config.latestPath.isNotBlank()) return listOf(config.latestPath)
        return when (config.type) {
            LotteryType.LUCK20 -> listOf("LuckTwenty/getBaseLuckTewnty.do")
            LotteryType.PKS -> listOf("pks/getLotteryPksInfo.do", "pks/getPksInfo.do", "pks/getBasePks.do")
            LotteryType.K3 -> listOf("CQShiCai/getBaseCQShiCai.do")
            LotteryType.PC28 -> listOf("Canada28/getBaseCanada28.do")
            LotteryType.YDH -> listOf("yundong/getLotteryYunDongInfo.do")
            LotteryType.GOOGLE_FF, LotteryType.SHUIGUAN_FF -> emptyList()
            LotteryType.OTHER -> listOf("CQShiCai/getBaseCQShiCai.do")
        }
    }

    suspend fun fetchHistory(config: LotteryConfig, days: Int = ApiConfig.DEFAULT_HISTORY_DAYS): List<DrawRecord> =
        withContext(Dispatchers.IO) {
            if (config.type == LotteryType.GOOGLE_FF || config.type == LotteryType.SHUIGUAN_FF) {
                return@withContext fetchWorldCounterHistory(config, days)
            }
            val dayList = (0 until days).map { offset ->
                Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -offset) }.time
                    .let { dayFmt.format(it) }
            }
            val endpoint = historyEndpoint(config)
            coroutineScope {
                val results = dayList.map { day ->
                    async { fetchDayItems(endpoint, config.code, day) }
                }.awaitAll()
                val rows = results.flatten().mapNotNull { parseItem(it, config) }
                rows.distinctBy { it.issue }.sortedBy { it.issue.toLongOrNull() ?: 0L }
            }
        }

    suspend fun fetchLatest(config: LotteryConfig): DrawRecord? = withContext(Dispatchers.IO) {
        if (config.type == LotteryType.GOOGLE_FF || config.type == LotteryType.SHUIGUAN_FF) {
            return@withContext fetchWorldCounterLatest(config)
        }
        val paths = latestEndpoints(config)
        for (base in ApiConfig.BASES) {
            for (path in paths) {
                try {
                    val body = getString(buildUrl(base, path, config.code))
                    val root = json.parseToJsonElement(body)
                    val candidates: List<JsonObject> = when (root) {
                        is JsonArray -> root.mapNotNull { it as? JsonObject }
                        is JsonObject -> {
                            val direct = listOfNotNull(root["data"], root["result"])
                            direct.flatMap { element ->
                                when (element) {
                                    is JsonObject -> listOfNotNull(element["data"]).flatMap { data ->
                                        when (data) {
                                            is JsonObject -> listOf(data)
                                            is JsonArray -> data.mapNotNull { it as? JsonObject }
                                            else -> emptyList()
                                        }
                                    } + listOf(element as JsonObject).filter { it["issue"] != null || it["lotteryNo"] != null || it["code"] != null }
                                    is JsonArray -> element.mapNotNull { it as? JsonObject }
                                    else -> emptyList()
                                }
                            }
                        }
                        else -> emptyList()
                    }.distinct()
                    val parsed = candidates.mapNotNull { parseItem(it, config) }
                        .filterNot { isStaleDrawTime(it.drawTime) }
                        .maxWithOrNull(compareBy<DrawRecord> { it.issue.toLongOrNull() ?: Long.MIN_VALUE }.thenBy { it.issue })
                        ?: continue
                    return@withContext parsed
                } catch (_: Exception) {
                }
            }
        }
        // 兜底:api16868 上 PKS 类「最新一期」专用端点(getPksInfo.do / getBasePks.do)
        // 已全部 404,导致极速飞艇/极速赛车等彩种自动刷新永远拿不到新期。
        // 改用当日历史列表的第一条(该接口按时间倒序,首条即最新已完成期)。
        fetchLatestFromHistoryList(config)
    }

    /** 通过历史列表接口获取最新一期(今天为空时回退查昨天,例如刚过零点) */
    private fun fetchLatestFromHistoryList(config: LotteryConfig): DrawRecord? {
        val endpoint = historyEndpoint(config)
        val today = Calendar.getInstance()
        val yesterday = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
        val dayList = listOf(dayFmt.format(today.time), dayFmt.format(yesterday.time))
        var best: DrawRecord? = null
        for (day in dayList) {
            for (base in ApiConfig.BASES) {
                try {
                    val body = getString(buildUrl(base, endpoint, config.code, day))
                    val arr = extractDataArray(body) ?: continue
                    // 不假设排序:取期号最大且未过期的一期
                    for (el in arr) {
                        val obj = el as? JsonObject ?: continue
                        val parsed = parseItem(obj, config) ?: continue
                        if (isStaleDrawTime(parsed.drawTime)) continue
                        val cur = best
                        if (cur == null || issueNewer(parsed.issue, cur.issue)) {
                            best = parsed
                        }
                    }
                } catch (_: Exception) {
                }
            }
        }
        return best
    }

    // ---- worldcounter.cn 独立数据源（谷歌分分彩 / 水管分分彩） ----

    private fun worldCounterUrl(config: LotteryConfig): String = when (config.type) {
        LotteryType.GOOGLE_FF -> "https://worldcounter.cn/api/statistics/gdata"
        LotteryType.SHUIGUAN_FF -> "https://worldcounter.cn/api/statistics/ydata"
        else -> ""
    }

    /**
     * worldcounter.cn 历史接口：/welcome/data?gameType=gdata|ydata&sDate=YYYY-MM-DD
     * 按天返回当天全量（约 1440 期/天，每分钟一期），按时间倒序。
     * 首页/统计接口(/api/statistics/gdata)固定只给最近 10 条，导致此前回测最多十期；
     * 这里改为按 days 逐天拉取并合并，让谷歌/水管分分彩也能获得与其它彩种一致的真实历史。
     */
    private fun fetchWorldCounterHistory(config: LotteryConfig, days: Int): List<DrawRecord> {
        val gameType = when (config.type) {
            LotteryType.GOOGLE_FF -> "gdata"
            LotteryType.SHUIGUAN_FF -> "ydata"
            else -> return emptyList()
        }
        val dayList = (0 until days.coerceIn(1, 7)).map { offset ->
            Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -offset) }.time
                .let { dayFmt.format(it) }
        }
        val rows = dayList.flatMap { day ->
            try {
                val url = "https://worldcounter.cn/welcome/data?gameType=$gameType&sDate=$day"
                val body = getString(url)
                val root = json.parseToJsonElement(body) as? JsonObject ?: return@flatMap emptyList()
                val arr = root["pagingResults"] as? JsonArray ?: return@flatMap emptyList()
                arr.mapNotNull { el ->
                    (el as? JsonObject)?.let { parseWorldCounterItem(it, config) }
                }
            } catch (_: Exception) {
                emptyList()
            }
        }
        return rows.distinctBy { it.issue }.sortedBy { it.issue.toLongOrNull() ?: 0L }
    }

    private fun fetchWorldCounterLatest(config: LotteryConfig): DrawRecord? {
        val url = worldCounterUrl(config)
        if (url.isBlank()) return null
        return try {
            val body = getString(url)
            val arr = json.parseToJsonElement(body) as? JsonArray ?: return null
            arr.firstOrNull()
                ?.let { it as? JsonObject }
                ?.let { parseWorldCounterItem(it, config) }
        } catch (_: Exception) {
            null
        }
    }

    /**
     * 解析 worldcounter.cn JSON 元素为 DrawRecord。
     * 字段映射：gametime(yyyy-MM-dd HH:mm:ss) -> 期号(去非数字,取12位) + drawTime；gamenumber("a,b,c,d,e") -> List<Int>
     */
    private fun parseWorldCounterItem(obj: JsonObject, config: LotteryConfig): DrawRecord? {
        val gametime = obj["gametime"]?.jsonPrimitive?.contentOrNull ?: return null
        val gamenumber = obj["gamenumber"]?.jsonPrimitive?.contentOrNull ?: return null
        // "2026-09-08 22:59:10" -> "202609082259"
        val issue = gametime.filter { it.isDigit() }.take(12)
        if (issue.length < 12) return null
        val numbers = gamenumber.split(",", " ", "|")
            .mapNotNull { it.trim().toIntOrNull() }
            .filter { it in 0..9 }
        if (numbers.size < 5) return null
        val classified = LotteryBetRules.classify(config.type, numbers)
        return DrawRecord(
            lotteryKey = config.key,
            issue = issue,
            drawTime = gametime,
            numbers = numbers,
            sum = classified?.sum,
            dx = classified?.dx,
            ds = classified?.ds,
            combo = classified?.combo,
            nextIssue = null
        )
    }

    /** 期号 a 是否比 b 更新(优先数值比较) */
    private fun issueNewer(a: String, b: String): Boolean {
        val na = a.toLongOrNull()
        val nb = b.toLongOrNull()
        if (na != null && nb != null) return na > nb
        return a > b
    }

    /**
     * 判断开奖时间是否已过期:距今超过 7 天视为无效数据(防止旧示例污染最新一期)。
     * 原阈值 2 天过于激进:设备时钟与 API 时间偏差稍大时会把全部新数据误判为过期,
     * 导致 fetchLatest 永远拿不到新期 → 共识/计划不自动更新、挂机不自动下注。
     */
    private fun isStaleDrawTime(drawTime: String): Boolean {
        if (drawTime.isBlank()) return true
        return try {
            val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            val t = fmt.parse(drawTime.take(19).replace('T', ' ')) ?: return true
            System.currentTimeMillis() - t.time > 7L * 24 * 3600_000
        } catch (_: Exception) {
            true
        }
    }

    /** 从接口响应中提取 data 数组(兼容裸数组与 result.data 两种结构) */
    private fun extractDataArray(body: String): JsonArray? {
        return try {
            when (val root = json.parseToJsonElement(body)) {
                is JsonArray -> root
                is JsonObject -> {
                    val data = root["result"]?.jsonObject?.get("data") ?: root["data"]
                    when (data) {
                        is JsonArray -> data
                        is JsonObject -> null
                        else -> null // data 可能是空字符串 ""
                    }
                }
                else -> null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun fetchDayItems(endpoint: String, lotCode: Int, day: String): List<JsonObject> {
        for (base in ApiConfig.BASES) {
            try {
                val body = getString(buildUrl(base, endpoint, lotCode, day))
                val root = json.parseToJsonElement(body)
                val arr: JsonArray = when (root) {
                    is JsonArray -> root
                    is JsonObject -> {
                        root["result"]?.jsonObject?.get("data")?.jsonArray
                            ?: root["data"]?.jsonArray
                            ?: continue
                    }
                    else -> continue
                }
                val items = arr.mapNotNull { it as? JsonObject }
                if (items.isNotEmpty()) return items
            } catch (_: Exception) {
            }
        }
        return emptyList()
    }

    private fun getString(url: String): String {
        var lastError: Exception? = null
        repeat(ApiConfig.RETRIES + 1) { attempt ->
            try {
                val req = Request.Builder()
                    .url(url)
                    .header("User-Agent", "Mozilla/5.0")
                    .header("Accept", "application/json")
                    .get()
                    .build()
                client.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) error("HTTP ${resp.code}")
                    val body = resp.body?.string()?.takeIf { it.isNotBlank() }
                        ?: error("empty body")
                    return body
                }
            } catch (e: Exception) {
                lastError = e
                if (attempt < ApiConfig.RETRIES) {
                    Thread.sleep(250L shl attempt)
                }
            }
        }
        throw lastError ?: IllegalStateException("request failed")
    }

    private fun parseItem(it: JsonObject, config: LotteryConfig): DrawRecord? {
        fun str(vararg keys: String): String {
            for (k in keys) {
                val p = it[k]?.jsonPrimitive ?: continue
                // 兼容数字字段(期号等):contentOrNull 只对字符串返回内容,
                // 数字(如 preDrawIssue:751963)会返回 null,导致整期被丢弃
                val v = if (p is JsonNull) null else p.content
                if (!v.isNullOrBlank()) return v
            }
            return ""
        }
        fun intOrNull(vararg keys: String): Int? {
            for (k in keys) {
                val p = it[k]?.jsonPrimitive
                val n = p?.intOrNull ?: p?.contentOrNull?.toIntOrNull()
                if (n != null) return n
            }
            return null
        }

        // 当前期优先 preDrawIssue;drawIssue 在部分接口表示「下一期」,放最后兜底
        val issue = str("preDrawIssue", "issue", "expect", "drawIssue")
        if (issue.isBlank()) return null
        val time = str("preDrawTime", "drawTime", "time")
        val code = str("preDrawCode", "drawCode", "openCode", "code")
        val nums = code.split(",", " ", "|")
            .mapNotNull { it.trim().toIntOrNull() }
            .filter { it >= 0 }
        if (nums.isEmpty()) return null

        // 下期期号:仅当与当前期不同才采用,避免把本期误当成下期
        val nextIssueRaw = listOf(
            str("drawIssue"),
            str("nextIssue"),
            str("nextExpect"),
            str("drawNumber")
        ).firstOrNull { it.isNotBlank() && it != issue }

        return when (config.type) {
            LotteryType.LUCK20 -> {
                if (nums.size < 20) return null
                val take = nums.take(20)
                if (take.size != 20 || take.any { it !in 1..80 } || take.distinct().size != 20) return null
                val classified = LotteryBetRules.classify(
                    LotteryType.LUCK20,
                    take,
                    apiSum = intOrNull("sumNum", "sum"),
                    apiDx = intOrNull("sumBigSmall"),
                    apiDs = intOrNull("sumSingleDouble")
                ) ?: return null
                DrawRecord(
                    lotteryKey = config.key,
                    issue = issue,
                    drawTime = time,
                    numbers = take,
                    sum = classified.sum,
                    dx = classified.dx,
                    ds = classified.ds,
                    combo = classified.combo,
                    extra = nums.getOrNull(20),
                    nextIssue = nextIssueRaw
                )
            }
            LotteryType.PKS -> {
                if (nums.size < 10) return null
                val take = nums.take(10)
                if (take.size != 10 || take.any { it !in 1..10 } || take.distinct().size != 10) return null
                val classified = LotteryBetRules.classify(LotteryType.PKS, take) ?: return null
                DrawRecord(
                    lotteryKey = config.key,
                    issue = issue,
                    drawTime = time,
                    numbers = take,
                    sum = classified.sum,
                    dx = classified.dx,
                    ds = classified.ds,
                    combo = classified.combo,
                    nextIssue = nextIssueRaw
                )
            }
            // 新彩种：只入库展示号码，大小单双/下注后续再设计
            LotteryType.K3 -> {
                if (nums.size < 3) return null
                val take = nums.take(3)
                if (take.any { it !in 1..6 }) return null
                val classified = LotteryBetRules.classifyK3(take)
                DrawRecord(
                    lotteryKey = config.key,
                    issue = issue,
                    drawTime = time,
                    numbers = take,
                    sum = classified?.sum ?: take.sum(),
                    dx = classified?.dx,
                    ds = classified?.ds,
                    combo = classified?.combo,
                    nextIssue = nextIssueRaw
                )
            }
            LotteryType.YDH -> {
                if (nums.size < 6) return null
                val take = nums.take(6)
                if (take.any { it !in 1..6 }) return null
                val classified = LotteryBetRules.classifyYdh(take) ?: return null
                DrawRecord(
                    lotteryKey = config.key,
                    issue = issue,
                    drawTime = time,
                    numbers = take,
                    sum = classified.sum,
                    dx = classified.dx,
                    ds = classified.ds,
                    combo = classified.combo,
                    nextIssue = nextIssueRaw
                )
            }
            LotteryType.PC28 -> {
                if (nums.size < 3) return null
                val take = nums.take(3)
                if (take.any { it !in 0..9 }) return null
                DrawRecord(
                    lotteryKey = config.key,
                    issue = issue,
                    drawTime = time,
                    numbers = take,
                    sum = take.sum(),
                    dx = null,
                    ds = null,
                    combo = null,
                    nextIssue = nextIssueRaw
                )
            }
            LotteryType.OTHER -> {
                if (nums.isEmpty()) return null
                DrawRecord(
                    lotteryKey = config.key,
                    issue = issue,
                    drawTime = time,
                    numbers = nums,
                    sum = nums.sum(),
                    dx = null,
                    ds = null,
                    combo = null,
                    nextIssue = nextIssueRaw
                )
            }
            LotteryType.GOOGLE_FF, LotteryType.SHUIGUAN_FF -> null
        }
    }
}
