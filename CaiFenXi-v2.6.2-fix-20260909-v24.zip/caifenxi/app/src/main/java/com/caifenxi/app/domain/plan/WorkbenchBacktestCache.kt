package com.caifenxi.app.domain.plan

import com.caifenxi.app.CaiFenXiApplication
import com.caifenxi.app.data.db.entity.WorkbenchBacktestCacheEntity
import com.caifenxi.app.domain.model.PlanDefinition
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * 工作台/图表回测结果缓存：内存 LRU + 本地磁盘（Room v18）双层。
 *
 * v2.6.3 优化：切换分类玩法 / 一期二期三期 / 直选注数档位 / 重启 App / 换彩种回来，
 * 直接命中相同口径的回测结果，不再重复全量回测。
 *
 * key = 内存 map 键，也作为磁盘表主键：
 * lotteryKey|planId|stage|periods|lastIssue|histSize|invert|outputCount|directKey
 * - stage/periods/lastIssue/directKey（直选档位+定位TopN指纹）都参与键 → 口径变化只补算缺失键，互不覆盖；
 * - lotteryKey 参与键 → 切换彩种天然隔离，无需 clear()。
 *
 * 正确性约束：lastIssue 必须参与键。新开奖后 lastIssue 变化 → 旧键不再命中 → 触发重算/增量追加，
 * 不会出现"开奖后仍显示旧连中"。
 */
object WorkbenchBacktestCache {
    private const val MAX = 400
    private val map = ConcurrentHashMap<String, NovaPlanAnalytics.ChartReport>()
    private val order = java.util.concurrent.ConcurrentLinkedDeque<String>()

    private val io = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private fun dao() = CaiFenXiApplication.instance.database.workbenchBacktestCacheDao()

    fun key(
        lotteryKey: String,
        planId: String,
        stage: Int,
        periods: Int,
        lastIssue: String,
        histSize: Int,
        invert: Boolean = false,
        outputCount: Int = 0,
        /** 直选单式注数档位 + 定位胆 TopN 指纹；影响预测输出，必须参与缓存键 */
        directKey: String = "",
        /** v2.6.2: 单注金额参与缓存键——回测金额变化后不得命中旧金额的缓存结果 */
        stake: Double = 0.01
    ): String = "$lotteryKey|$planId|$stage|$periods|$lastIssue|$histSize|$invert|$outputCount|$directKey|stake=${"%.4f".format(stake)}"

    fun get(k: String): NovaPlanAnalytics.ChartReport? = map[k]

    /** 同计划+同阶段的最近一次回测报告（lastIssue 最大者），供新开奖增量追加使用；无匹配返回 null */
    fun latestFor(planId: String, stage: Int): NovaPlanAnalytics.ChartReport? {
        var best: NovaPlanAnalytics.ChartReport? = null
        var bestIssue = ""
        map.forEach { (k, v) ->
            val parts = k.split("|")
            if (parts.getOrNull(1) == planId && parts.getOrNull(2)?.toIntOrNull() == stage) {
                val issue = parts.getOrNull(4).orEmpty()
                if (issue >= bestIssue) {
                    bestIssue = issue
                    best = v
                }
            }
        }
        return best
    }

    @Synchronized
    fun put(k: String, report: NovaPlanAnalytics.ChartReport) {
        if (map.put(k, report) == null) {
            order.addLast(k)
            while (order.size > MAX) {
                val old = order.pollFirst() ?: break
                map.remove(old)
            }
        }
        persist(k, report)
    }

    /** 仅内存（不落盘）：启动读盘时灌回，避免重复写库 */
    @Synchronized
    fun putMemoryOnly(k: String, report: NovaPlanAnalytics.ChartReport) {
        if (map.put(k, report) == null) {
            order.addLast(k)
            while (order.size > MAX) {
                val old = order.pollFirst() ?: break
                map.remove(old)
            }
        }
    }

    fun clear() {
        map.clear()
        order.clear()
    }

    fun clearPlan(planId: String) {
        val keys = map.keys.filter { it.split("|").getOrNull(1) == planId }
        keys.forEach {
            map.remove(it)
            order.remove(it)
        }
        io.launch { try { dao().deleteByPlan(planId) } catch (_: Exception) {} }
    }

    /** 清除指定彩种全部缓存（内存+磁盘） */
    fun clearLottery(lotteryKey: String) {
        val keys = map.keys.filter { it.startsWith("$lotteryKey|") }
        keys.forEach {
            map.remove(it)
            order.remove(it)
        }
        io.launch { try { dao().deleteByLottery(lotteryKey) } catch (_: Exception) {} }
    }

    // ------------------------------------------------------------------
    // 磁盘持久化（Room v18）：put 时异步写盘；启动时按彩种读回
    // ------------------------------------------------------------------

    private fun persist(k: String, report: NovaPlanAnalytics.ChartReport) {
        val parts = k.split("|")
        if (parts.size < 3) return
        val lotteryKey = parts[0]
        val planId = parts[1]
        val stage = parts.getOrNull(2)?.toIntOrNull() ?: return
        val periods = parts.getOrNull(3)?.toIntOrNull() ?: 0
        val lastIssue = parts.getOrNull(4).orEmpty()
        val directKey = parts.drop(5).joinToString("|")
        io.launch {
            try {
                dao().upsert(
                    WorkbenchBacktestCacheEntity(
                        cacheKey = k,
                        lotteryKey = lotteryKey,
                        planId = planId,
                        stage = stage,
                        periods = periods,
                        lastIssue = lastIssue,
                        directKey = directKey,
                        reportText = encode(report),
                        updatedAt = System.currentTimeMillis()
                    )
                )
            } catch (_: Exception) {}
        }
    }

    /** 从磁盘读出某彩种全部缓存并灌入内存（不落盘）；返回 (cacheKey, report) 列表供重建 runtimeCache */
    fun loadLottery(lotteryKey: String, planResolver: (String) -> PlanDefinition?): List<Pair<String, NovaPlanAnalytics.ChartReport>> {
        val loaded = mutableListOf<Pair<String, NovaPlanAnalytics.ChartReport>>()
        val entities = try {
            kotlinx.coroutines.runBlocking { dao().getByLottery(lotteryKey) }
        } catch (_: Exception) {
            emptyList()
        }
        entities
            .sortedByDescending { it.updatedAt }
            .take(MAX)
            .forEach { e ->
                val plan = planResolver(e.planId) ?: return@forEach
                val report = decode(e.reportText, plan) ?: return@forEach
                putMemoryOnly(e.cacheKey, report)
                loaded += e.cacheKey to report
            }
        return loaded
    }

    // ------------------------------------------------------------------
    // ChartReport 紧凑文本编解码（无损恢复详情页所需全部字段）
    // 预测值可能含 "|"（如 "位置:345"），字段分隔用 \t，prediction 内 "|" 用 §(U+00A7) 转义
    // ------------------------------------------------------------------

    private fun esc(s: String) = s.replace("|", "\u00A7")
    private fun unesc(s: String) = s.replace("\u00A7", "|")

    fun encode(r: NovaPlanAnalytics.ChartReport): String {
        val sb = StringBuilder()
        sb.append("V=1\n")
        sb.append("periods=").append(r.periods).append('\n')
        sb.append("stake=").append(r.stake).append('\n')
        sb.append("hits=").append(r.hits).append('\n')
        sb.append("misses=").append(r.misses).append('\n')
        sb.append("totalStake=").append(r.totalStake).append('\n')
        sb.append("netProfit=").append(r.netProfit).append('\n')
        sb.append("hitRate=").append(r.hitRate).append('\n')
        sb.append("maxHitRate=").append(r.maxHitRate).append('\n')
        sb.append("minHitRate=").append(r.minHitRate).append('\n')
        sb.append("maxHitStreak=").append(r.maxHitStreak).append('\n')
        sb.append("maxMissStreak=").append(r.maxMissStreak).append('\n')
        sb.append("currentHitStreak=").append(r.currentHitStreak).append('\n')
        sb.append("currentMissStreak=").append(r.currentMissStreak).append('\n')
        sb.append("maxPeriodHitStreak=").append(r.maxPeriodHitStreak).append('\n')
        sb.append("maxPeriodMissStreak=").append(r.maxPeriodMissStreak).append('\n')
        sb.append("maxDrawdown=").append(r.maxDrawdown).append('\n')
        sb.append("maxPeak=").append(r.maxPeak).append('\n')
        sb.append("minTrough=").append(r.minTrough).append('\n')
        sb.append("currentTrend=").append(esc(r.currentTrend)).append('\n')
        sb.append("positionPercent=").append(r.positionPercent).append('\n')
        sb.append("distanceFromPeak=").append(r.distanceFromPeak).append('\n')
        sb.append("reboundFromTrough=").append(r.reboundFromTrough).append('\n')
        sb.append("guanguanEnabled=").append(r.guanguanEnabled).append('\n')
        sb.append("guanguanTarget=").append(r.guanguanTarget).append('\n')
        sb.append("guanguanCompleted=").append(r.guanguanCompleted).append('\n')
        sb.append("guanguanCurrentLevel=").append(r.guanguanCurrentLevel).append('\n')
        sb.append("guanguanMaxLevel=").append(r.guanguanMaxLevel).append('\n')
        sb.append("lossMultBacktest=").append(r.lossMultBacktest).append('\n')
        sb.append("lossMult=").append(r.lossMult).append('\n')
        sb.append("lossMultPeriods=").append(r.lossMultPeriods).append('\n')
        sb.append("lossMultMaxStreak=").append(r.lossMultMaxStreak).append('\n')
        sb.append("R=").append(r.roundResults.joinToString(",")).append('\n')
        r.points.forEach { p ->
            sb.append("P=").append(p.issue).append('\t').append(esc(p.prediction)).append('\t')
                .append(p.hit).append('\t').append(p.stake).append('\t').append(p.periodProfit).append('\t')
                .append(p.cumulativeProfit).append('\t').append(p.peakProfit).append('\t').append(p.troughProfit).append('\t')
                .append(p.drawdown).append('\t').append(p.hitRate).append('\n')
        }
        return sb.toString()
    }

    fun decode(text: String, plan: PlanDefinition): NovaPlanAnalytics.ChartReport? {
        try {
            val fields = mutableMapOf<String, String>()
            val rows = mutableListOf<List<String>>()
            text.lines().forEach { line ->
                if (line.isBlank()) return@forEach
                if (line.startsWith("P=")) {
                    rows += line.substring(2).split("\t")
                } else if (line.startsWith("R=")) {
                    fields["R"] = line.substring(2)
                } else {
                    val idx = line.indexOf('=')
                    if (idx > 0) fields[line.substring(0, idx)] = line.substring(idx + 1)
                }
            }
            fun d(k: String) = fields[k]?.toDoubleOrNull() ?: 0.0
            fun i(k: String) = fields[k]?.toIntOrNull() ?: 0
            fun b(k: String) = fields[k]?.toBooleanStrictOrNull() ?: false
            val points = rows.map { v ->
                NovaPlanAnalytics.ChartPoint(
                    issue = v.getOrNull(0).orEmpty(),
                    prediction = unesc(v.getOrNull(1).orEmpty()),
                    hit = v.getOrNull(2)?.toBooleanStrictOrNull() ?: false,
                    stake = v.getOrNull(3)?.toDoubleOrNull() ?: 0.0,
                    periodProfit = v.getOrNull(4)?.toDoubleOrNull() ?: 0.0,
                    cumulativeProfit = v.getOrNull(5)?.toDoubleOrNull() ?: 0.0,
                    peakProfit = v.getOrNull(6)?.toDoubleOrNull() ?: 0.0,
                    troughProfit = v.getOrNull(7)?.toDoubleOrNull() ?: 0.0,
                    drawdown = v.getOrNull(8)?.toDoubleOrNull() ?: 0.0,
                    hitRate = v.getOrNull(9)?.toDoubleOrNull() ?: 0.0
                )
            }
            val roundResults = fields["R"].orEmpty()
                .split(",").filter { it.isNotBlank() }
                .map { it.toBooleanStrictOrNull() ?: false }
            return NovaPlanAnalytics.ChartReport(
                plan = plan,
                periods = i("periods"),
                stake = d("stake"),
                points = points,
                hits = i("hits"),
                misses = i("misses"),
                totalStake = d("totalStake"),
                netProfit = d("netProfit"),
                hitRate = d("hitRate"),
                maxHitRate = d("maxHitRate"),
                minHitRate = d("minHitRate"),
                maxHitStreak = i("maxHitStreak"),
                maxMissStreak = i("maxMissStreak"),
                currentHitStreak = i("currentHitStreak"),
                currentMissStreak = i("currentMissStreak"),
                roundResults = roundResults,
                maxPeriodHitStreak = i("maxPeriodHitStreak"),
                maxPeriodMissStreak = i("maxPeriodMissStreak"),
                maxDrawdown = d("maxDrawdown"),
                maxPeak = d("maxPeak"),
                minTrough = d("minTrough"),
                currentTrend = unesc(fields["currentTrend"].orEmpty()),
                positionPercent = d("positionPercent"),
                distanceFromPeak = d("distanceFromPeak"),
                reboundFromTrough = d("reboundFromTrough"),
                guanguanEnabled = b("guanguanEnabled"),
                guanguanTarget = i("guanguanTarget"),
                guanguanCompleted = i("guanguanCompleted"),
                guanguanCurrentLevel = i("guanguanCurrentLevel"),
                guanguanMaxLevel = i("guanguanMaxLevel"),
                lossMultBacktest = b("lossMultBacktest"),
                lossMult = d("lossMult"),
                lossMultPeriods = i("lossMultPeriods"),
                lossMultMaxStreak = i("lossMultMaxStreak")
            )
        } catch (_: Exception) {
            return null
        }
    }
}