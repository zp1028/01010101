package com.caifenxi.app.domain.execution

import android.content.Context
import android.content.SharedPreferences
import com.caifenxi.app.util.RuntimeLog
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.Executors

/**
 * 网络日志本地存储：WebView 标注点击时自动记录 XHR/fetch 请求。
 * 7天自动清理，上限500条，过滤无关请求（图片/CSS/字体等）。
 * 不发送到任何远程服务器。
 */
object NetworkLogStore {

    private const val PREFS = "network_log_store"
    private const val MAX_LOGS = 500
    private const val MAX_AGE_DAYS = 7

    private val executor = Executors.newSingleThreadExecutor()
    private val pendingQueue = ConcurrentLinkedQueue<NetworkLogEntry>()
    @Volatile private var initialized = false

    @Serializable
    data class NetworkLogEntry(
        val timestamp: Long = System.currentTimeMillis(),
        val domain: String = "",
        val playType: String = "",      // 玩法类型：dx/ds/combo/number/...
        val step: String = "",          // 操作步骤：click/input/confirm
        val targetValue: String = "",   // 目标值：大/小/3/100
        val request: RequestRecord = RequestRecord(),
        val response: ResponseRecord = ResponseRecord()
    ) {
        @Serializable
        data class RequestRecord(
            val url: String = "",
            val method: String = "",
            val headers: String = "",     // JSON string of key headers
            val body: String = ""        // request body
        )
        @Serializable
        data class ResponseRecord(
            val status: Int = 0,
            val body: String = ""       // response body (truncated)
        )
    }

    fun init(context: Context) {
        if (initialized) return
        synchronized(this) {
            if (initialized) return
            cleanupOldLogs(context)
            initialized = true
        }
    }

    /** 从 JS 侧读取的原始日志字符串解析并追加 */
    fun appendFromJson(context: Context, rawJson: String) {
        if (!initialized) init(context)
        executor.execute {
            try {
                val arr = org.json.JSONArray(rawJson)
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val entry = parseEntry(obj)
                    if (entry != null && !shouldFilter(entry)) {
                        pendingQueue.add(entry)
                    }
                }
                flushPending(context)
            } catch (e: Exception) {
                RuntimeLog.warn("NetworkLogStore", "解析日志失败: ${e.message}")
            }
        }
    }

    /** 获取某站点某玩法的日志条目（用于映射表生成） */
    fun getLogs(context: Context, domain: String, playType: String): List<NetworkLogEntry> {
        val all = loadAll(context)
        return all.filter { it.domain == domain && it.playType == playType }
    }

    /** 获取某站点的全部日志 */
    fun getLogsByDomain(context: Context, domain: String): List<NetworkLogEntry> {
        return loadAll(context).filter { it.domain == domain }
    }

    /** 删除某站点全部日志 */
    fun clearDomain(context: Context, domain: String) {
        executor.execute {
            val all = loadAll(context).filter { it.domain != domain }
            saveAll(context, all)
        }
    }

    /** 全部清空 */
    fun clearAll(context: Context) {
        executor.execute {
            getPrefs(context).edit().remove("logs").apply()
        }
    }

    private fun parseEntry(obj: JSONObject): NetworkLogEntry? = try {
        NetworkLogEntry(
            timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
            domain = obj.optString("domain", ""),
            playType = obj.optString("playType", ""),
            step = obj.optString("step", ""),
            targetValue = obj.optString("targetValue", ""),
            request = NetworkLogEntry.RequestRecord(
                url = obj.optJSONObject("request")?.optString("url", "") ?: "",
                method = obj.optJSONObject("request")?.optString("method", "") ?: "",
                headers = obj.optJSONObject("request")?.optString("headers", "") ?: "",
                body = obj.optJSONObject("request")?.optString("body", "") ?: ""
            ),
            response = NetworkLogEntry.ResponseRecord(
                status = obj.optJSONObject("response")?.optInt("status", 0) ?: 0,
                body = obj.optJSONObject("response")?.optString("body", "") ?: ""
            )
        )
    } catch (_: Exception) { null }

    private fun shouldFilter(entry: NetworkLogEntry): Boolean {
        val url = entry.request.url.lowercase()
        // 过滤静态资源
        if (url.endsWith(".jpg") || url.endsWith(".png") || url.endsWith(".gif") ||
            url.endsWith(".css") || url.endsWith(".js") || url.endsWith(".woff") ||
            url.endsWith(".ttf") || url.endsWith(".svg") || url.endsWith(".ico")
        ) return true
        // 过滤 heartbeat/ping
        if (url.contains("/ping") || url.contains("/heartbeat") || url.contains("/keepalive")) return true
        // 过滤长度为零的无效记录
        if (entry.request.url.isBlank()) return true
        return false
    }

    private fun flushPending(context: Context) {
        val batch = mutableListOf<NetworkLogEntry>()
        while (true) {
            val e = pendingQueue.poll() ?: break
            batch.add(e)
        }
        if (batch.isEmpty()) return
        val all = loadAll(context).toMutableList()
        all.addAll(batch)
        // 上限截断
        if (all.size > MAX_LOGS) {
            all.sortBy { it.timestamp }
            val trimmed = all.takeLast(MAX_LOGS)
            saveAll(context, trimmed)
        } else {
            saveAll(context, all)
        }
    }

    private fun loadAll(context: Context): List<NetworkLogEntry> {
        val json = getPrefs(context).getString("logs", "") ?: return emptyList()
        if (json.isBlank()) return emptyList()
        return try {
            Json.decodeFromString(json)
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun saveAll(context: Context, list: List<NetworkLogEntry>) {
        try {
            val json = Json.encodeToString(list)
            getPrefs(context).edit().putString("logs", json).apply()
        } catch (e: Exception) {
            RuntimeLog.warn("NetworkLogStore", "保存日志失败: ${e.message}")
        }
    }

    private fun cleanupOldLogs(context: Context) {
        val cutoff = System.currentTimeMillis() - MAX_AGE_DAYS * 24 * 60 * 60 * 1000L
        val all = loadAll(context).filter { it.timestamp >= cutoff }
        saveAll(context, all)
    }

    private fun getPrefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
