package com.caifenxi.app.domain.execution

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import com.caifenxi.app.util.RuntimeLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.random.Random

/**
 * API 注入执行器：通过 WebView evaluateJavascript 直接构造 fetch 请求，绕过 DOM 点击。
 * 依赖 ApiMappingStore 的映射表 + TokenManager 的 token。
 * 具备拟人化延迟、期号校验、金额复核、风控检测、自动 fallback。
 */
class ApiInjectExecutor(
    private val context: Context,
    private val webViewRef: () -> WebView?
) : Executor {

    override val id: String = "api_inject"

    override val isAvailable: Boolean
        get() = webViewRef() != null && TokenManager.getToken(context, currentDomain()) != null

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile private var runningCmdId: String? = null
    @Volatile private var consecutiveFailures = 0
    @Volatile private var lastFailureTime = 0L
    private val maxConsecutiveFailures = 2
    private val failureCooldownMs = 60_000L

    @Volatile private var windControlTriggered = false

    private fun currentDomain(): String {
        val url = webViewRef()?.url ?: ""
        return try {
            android.net.Uri.parse(url).host ?: ""
        } catch (_: Exception) { "" }
    }

    override fun execute(command: BetCommand, onResult: (ExecutionResult) -> Unit): Boolean {
        val wv = webViewRef()
        if (wv == null) {
            onResult(ExecutionResult.fail(command.cmdId, ExecutionResult.WEBVIEW_DISCONNECTED, "WebView 未连接"))
            return false
        }

        val domain = currentDomain()
        val profile = ApiMappingStore.getProfile(context, domain)

        // 检查映射表是否就绪
        val activePlayTypes = command.bets.map { bet ->
            when (bet.category) {
                BetAction.CAT_DX -> "dx"
                BetAction.CAT_DS -> "ds"
                BetAction.CAT_COMBO -> "combo"
                BetAction.CAT_NUMBER -> "number"
                else -> "text"
            }
        }.distinct()

        val missing = activePlayTypes.filter { profile.mappingFor(it) == null }
        if (missing.isNotEmpty()) {
            RuntimeLog.warn("ApiInject", "映射表缺失玩法 ${missing.joinToString()}, fallback DOM")
            onResult(ExecutionResult.fail(command.cmdId, ExecutionResult.ELEMENT_NOT_FOUND, "API映射表未就绪: ${missing.joinToString()}"))
            return false
        }

        // 风控熔断检查
        if (windControlTriggered) {
            RuntimeLog.warn("ApiInject", "风控熔断中，拒绝执行")
            onResult(ExecutionResult.fail(command.cmdId, ExecutionResult.ACTION_FAILED, "API风控熔断，请稍后重试"))
            return false
        }

        // 并发防重
        if (runningCmdId != null) {
            RuntimeLog.warn("ApiInject", "已有执行中任务 $runningCmdId，拒绝 ${command.cmdId}")
            return false
        }
        runningCmdId = command.cmdId

        scope.launch {
            val result = runApiLoop(command, wv, profile)
            withContext(Dispatchers.Main) {
                runningCmdId = null
                onResult(result)
            }
        }
        return true
    }

    private suspend fun runApiLoop(
        command: BetCommand,
        wv: WebView,
        profile: ApiMappingStore.ApiProfile
    ): ExecutionResult {
        val domain = currentDomain()

        // === 阶段 1: 拟人化延迟 ===
        val thinkDelay = Random.nextLong(200, 800)
        delay(thinkDelay)

        // === 阶段 2: 期号校验 ===
        val issueCheck = checkIssueMatch(wv, command.issue)
        if (!issueCheck) {
            return ExecutionResult.fail(command.cmdId, ExecutionResult.COMMAND_EXPIRED, "期号不匹配或页面已封盘")
        }

        // === 阶段 3: Token 获取 ===
        val token = TokenManager.getToken(context, domain)
        if (token == null || !token.isValid || token.isExpired) {
            // 尝试从页面刷新提取
            val freshToken = extractTokenFromPage(wv, profile)
            if (freshToken != null) {
                TokenManager.saveToken(context, freshToken)
            } else {
                return ExecutionResult.fail(command.cmdId, ExecutionResult.WEBVIEW_DISCONNECTED, "Token 失效且无法刷新")
            }
        }

        // === 阶段 4: 金额复核 ===
        val amount = command.amountText?.toIntOrNull() ?: 0
        if (amount <= 0) {
            return ExecutionResult.fail(command.cmdId, ExecutionResult.ACTION_FAILED, "金额无效")
        }

        // === 阶段 5: 逐玩法执行 ===
        val results = mutableListOf<Boolean>()
        for (bet in command.bets) {
            val playType = when (bet.category) {
                BetAction.CAT_DX -> "dx"
                BetAction.CAT_DS -> "ds"
                BetAction.CAT_COMBO -> "combo"
                BetAction.CAT_NUMBER -> "number"
                else -> continue
            }

            val mapping = profile.mappingFor(playType) ?: continue

            // 操作间隔延迟（拟人化）
            delay(Random.nextLong(300, 1200))

            // 构造请求
            val jsScript = buildFetchScript(mapping, command, bet, token!!.token)
            val response = executeJsFetch(wv, jsScript)

            // 解析响应
            val (success, message, isWindControl) = parseResponse(response, mapping)

            if (isWindControl) {
                windControlTriggered = true
                consecutiveFailures++
                return ExecutionResult.fail(command.cmdId, ExecutionResult.ACTION_FAILED, "触发风控: $message")
            }

            if (!success) {
                consecutiveFailures++
                lastFailureTime = System.currentTimeMillis()
                if (consecutiveFailures >= maxConsecutiveFailures) {
                    windControlTriggered = true
                }
                results.add(false)
                RuntimeLog.warn("ApiInject", "玩法 $playType 失败: $message")
            } else {
                results.add(true)
                consecutiveFailures = 0
            }
        }

        return if (results.all { it }) {
            ExecutionResult.success(command.cmdId, "API投注成功")
        } else {
            ExecutionResult.fail(command.cmdId, ExecutionResult.ACTION_FAILED, "部分玩法失败")
        }
    }

    private suspend fun checkIssueMatch(wv: WebView, expectedIssue: String): Boolean {
        return suspendCancellableCoroutine { cont ->
            mainHandler.post {
                try {
                    wv.evaluateJavascript(
                        "(function(){ try{ var el=document.querySelector('[class*=issue],[class*=period],[id*=issue],[id*=period],.qihao,.issue,.period'); return el ? (el.innerText||el.textContent||'').trim() : ''; }catch(e){ return ''; } })()"
                    ) { result ->
                        val pageIssue = result?.trim()?.trim('"') ?: ""
                        cont.resume(pageIssue == expectedIssue)
                    }
                } catch (_: Exception) {
                    cont.resume(false)
                }
            }
        }
    }

    private suspend fun extractTokenFromPage(
        wv: WebView,
        profile: ApiMappingStore.ApiProfile
    ): TokenManager.TokenEntry? {
        val script = TokenManager.buildTokenExtractorScript(profile.tokenSource, profile.tokenKey)
        val tokenValue = executeJsFetch(wv, script)
        return if (tokenValue.isNotBlank() && tokenValue != "null") {
            TokenManager.TokenEntry(
                domain = profile.domain,
                token = tokenValue,
                source = profile.tokenSource,
                key = profile.tokenKey,
                acquiredAt = System.currentTimeMillis(),
                expiresAt = System.currentTimeMillis() + profile.tokenExpiryMs
            )
        } else null
    }

    private fun buildFetchScript(
        mapping: ApiMappingStore.ApiMapping,
        command: BetCommand,
        bet: BetAction,
        token: String
    ): String {
        val headers = mapping.headerTemplate.map { (k, v) ->
            val resolved = if (v == "\$TOKEN") "Bearer $token" else v
            "\"$k\":\"$resolved\""
        }.joinToString(",")

        val body = mapping.bodyTemplate.map { (k, v) ->
            val resolved = when (v) {
                "DYNAMIC" -> when (k) {
                    "issue", "issueNo", "period" -> "\"$k\":\"${command.issue}\""
                    "amount", "money", "betAmount" -> "\"$k\":${command.amountText ?: "0"}"
                    "num", "number", "betNum" -> "\"$k\":\"${bet.value}\""
                    "playId", "type" -> "\"$k\":\"$v\"" // playId 从映射表固定值
                    else -> "\"$k\":\"${bet.value}\""
                }
                else -> "\"$k\":\"$v\""
            }
            resolved
        }.joinToString(",")

        return """
            (async function(){
                try{
                    var resp = await fetch('${mapping.url}', {
                        method: '${mapping.method}',
                        headers: {$headers},
                        body: JSON.stringify({$body})
                    });
                    var text = await resp.text();
                    return JSON.stringify({status: resp.status, body: text});
                }catch(e){
                    return JSON.stringify({status: 0, body: String(e.message || e)});
                }
            })()
        """.trimIndent()
    }

    private suspend fun executeJsFetch(wv: WebView, script: String): String {
        return suspendCancellableCoroutine { cont ->
            mainHandler.post {
                try {
                    wv.evaluateJavascript(script) { result ->
                        cont.resume(result ?: "")
                    }
                } catch (e: Exception) {
                    cont.resume("")
                }
            }
        }
    }

    private fun parseResponse(
        rawResponse: String,
        mapping: ApiMappingStore.ApiMapping
    ): Triple<Boolean, String, Boolean> {
        return try {
            val obj = org.json.JSONObject(rawResponse)
            val status = obj.optInt("status", 0)
            val body = obj.optString("body", "")

            // 风控码检测
            if (status == 429 || body.contains("rate limit") || body.contains("太频繁")) {
                return Triple(false, "请求过于频繁", true)
            }
            if (body.contains("验证码") || body.contains("captcha") || body.contains("人机验证")) {
                return Triple(false, "触发验证码", true)
            }

            // 成功判定
            val success = when {
                mapping.successPattern.isNotBlank() -> body.contains(mapping.successPattern)
                status in 200..299 -> true
                else -> false
            }

            Triple(success, body, false)
        } catch (_: Exception) {
            Triple(false, "响应解析失败", false)
        }
    }

    override fun cancel(cmdId: String) {
        if (runningCmdId == cmdId) {
            runningCmdId = null
        }
    }

    override fun queryState(cmdId: String): ExecutionResult? {
        return if (runningCmdId == cmdId) {
            ExecutionResult.fail(cmdId, ExecutionResult.TIMEOUT, "执行中")
        } else null
    }

    /** 重置风控状态（用户手动重置或时间冷却） */
    fun resetWindControl() {
        windControlTriggered = false
        consecutiveFailures = 0
    }
}
