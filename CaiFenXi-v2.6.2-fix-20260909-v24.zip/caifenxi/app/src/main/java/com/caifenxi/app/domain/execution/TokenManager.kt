package com.caifenxi.app.domain.execution

import android.content.Context
import android.content.SharedPreferences
import android.webkit.CookieManager
import com.caifenxi.app.util.RuntimeLog
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * Token 管理：按站点域名隔离，从 Cookie/localStorage/JS 变量提取，自动检测过期。
 */
object TokenManager {

    private const val PREFS = "token_manager"
    private const val TOKEN_EXPIRY_BUFFER_MS = 300_000L // 提前5分钟标记过期

    @Serializable
    data class TokenEntry(
        val domain: String = "",
        val token: String = "",
        val source: String = "cookie", // cookie / localStorage / jsVariable
        val key: String = "",
        val acquiredAt: Long = System.currentTimeMillis(),
        val expiresAt: Long = 0L,      // 0 = 未知
        val isValid: Boolean = true
    ) {
        val isExpired: Boolean
            get() = expiresAt > 0 && System.currentTimeMillis() > expiresAt - TOKEN_EXPIRY_BUFFER_MS
    }

    /** 保存站点 token */
    fun saveToken(context: Context, entry: TokenEntry) {
        try {
            val json = Json.encodeToString(entry)
            getPrefs(context).edit().putString("token_${entry.domain}", json).apply()
            RuntimeLog.info("TokenManager", "Token 已保存 domain=${entry.domain} source=${entry.source}")
        } catch (e: Exception) {
            RuntimeLog.warn("TokenManager", "保存失败: ${e.message}")
        }
    }

    /** 获取站点 token */
    fun getToken(context: Context, domain: String): TokenEntry? {
        val json = getPrefs(context).getString("token_$domain", "") ?: return null
        return try {
            val entry = Json.decodeFromString<TokenEntry>(json)
            if (!entry.isValid || entry.isExpired) {
                RuntimeLog.warn("TokenManager", "Token 已失效/过期 domain=$domain")
                null
            } else {
                entry
            }
        } catch (_: Exception) { null }
    }

    /** 标记 token 失效（401/403 时调用） */
    fun invalidateToken(context: Context, domain: String) {
        val json = getPrefs(context).getString("token_$domain", "") ?: return
        try {
            val entry = Json.decodeFromString<TokenEntry>(json)
            saveToken(context, entry.copy(isValid = false))
            RuntimeLog.warn("TokenManager", "Token 已标记失效 domain=$domain")
        } catch (_: Exception) {}
    }

    /** 从 WebView Cookie 提取 token */
    fun extractFromCookie(domain: String, cookieKey: String): String? {
        return try {
            val cm = CookieManager.getInstance()
            val cookies = cm.getCookie(domain) ?: return null
            cookies.split(";").find { it.trim().startsWith("$cookieKey=") }
                ?.substringAfter("$cookieKey=")
                ?.trim()
        } catch (e: Exception) {
            RuntimeLog.warn("TokenManager", "Cookie提取失败: ${e.message}")
            null
        }
    }

    /** 生成 JS 脚本从页面提取 token */
    fun buildTokenExtractorScript(source: String, key: String): String {
        return when (source) {
            "localStorage" -> "(function(){ try{ return localStorage.getItem('$key') || ''; }catch(e){ return ''; } })()"
            "jsVariable" -> "(function(){ try{ return window.$key || window.__$key || ''; }catch(e){ return ''; } })()"
            "cookie" -> "(function(){ try{ var match = document.cookie.match(new RegExp('(^| )$key=([^;]+)')); return match ? match[2] : ''; }catch(e){ return ''; } })()"
            else -> "''"
        }
    }

    private fun getPrefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
