package com.caifenxi.app.domain.strategy

import com.caifenxi.app.domain.model.LotteryType

/**
 * 策略池计划定义工厂（独立于原有 NovaPlanPool / PlanPoolV2）。
 *
 * 三轨计划池，每条轨道面向不同玩法、使用不同算法：
 * - A轨：大小/单双，贝叶斯融合引擎，目标单期53%
 * - B轨：组合2口，互补对冲策略，目标单期55%+
 * - C轨：组合3口，排除最不可能口，天然75%+
 */
object StrategyPool {

    /** A轨：大小/单双贝叶斯融合计划 */
    val TRACK_A_PLANS: List<StrategyDefinition> = listOf(
        StrategyDefinition(
            planId = "STRAT-A-DX-BAYES",
            planName = "大小·贝叶斯融合",
            track = StrategyTrack.TRACK_A,
            playType = "大小",
            algorithm = "BAYES_FUSION",
            window = 50,
            baselineValue = 0.50,
            stageMult = 2.0,
            supportedTypes = LotteryType.entries.toSet()
        ),
        StrategyDefinition(
            planId = "STRAT-A-DS-BAYES",
            planName = "单双·贝叶斯融合",
            track = StrategyTrack.TRACK_A,
            playType = "单双",
            algorithm = "BAYES_FUSION",
            window = 50,
            baselineValue = 0.50,
            stageMult = 2.0,
            supportedTypes = LotteryType.entries.toSet()
        ),
        // PK10 名次大小单双
        StrategyDefinition(
            planId = "STRAT-A-RANK-DX",
            planName = "名次大小·贝叶斯",
            track = StrategyTrack.TRACK_A,
            playType = "名次大小",
            algorithm = "BAYES_FUSION",
            window = 50,
            positionIndex = 0,
            baselineValue = 0.50,
            stageMult = 2.0,
            supportedTypes = setOf(LotteryType.PKS)
        ),
        StrategyDefinition(
            planId = "STRAT-A-RANK-DS",
            planName = "名次单双·贝叶斯",
            track = StrategyTrack.TRACK_A,
            playType = "名次单双",
            algorithm = "BAYES_FUSION",
            window = 50,
            positionIndex = 0,
            baselineValue = 0.50,
            stageMult = 2.0,
            supportedTypes = setOf(LotteryType.PKS)
        ),
        // 运动会球大小单双
        StrategyDefinition(
            planId = "STRAT-A-YDH-DX",
            planName = "球大小·贝叶斯",
            track = StrategyTrack.TRACK_A,
            playType = "球大小",
            algorithm = "BAYES_FUSION",
            window = 50,
            positionIndex = 0,
            baselineValue = 0.50,
            stageMult = 2.0,
            supportedTypes = setOf(LotteryType.YDH)
        ),
        StrategyDefinition(
            planId = "STRAT-A-YDH-DS",
            planName = "球单双·贝叶斯",
            track = StrategyTrack.TRACK_A,
            playType = "球单双",
            algorithm = "BAYES_FUSION",
            window = 50,
            positionIndex = 0,
            baselineValue = 0.50,
            stageMult = 2.0,
            supportedTypes = setOf(LotteryType.YDH)
        ),
        // 快三和值大小单双
        StrategyDefinition(
            planId = "STRAT-A-K3-DX",
            planName = "和值大小·贝叶斯",
            track = StrategyTrack.TRACK_A,
            playType = "大小",
            algorithm = "BAYES_FUSION",
            window = 50,
            baselineValue = 0.50,
            stageMult = 2.0,
            supportedTypes = setOf(LotteryType.K3)
        ),
        StrategyDefinition(
            planId = "STRAT-A-K3-DS",
            planName = "和值单双·贝叶斯",
            track = StrategyTrack.TRACK_A,
            playType = "单双",
            algorithm = "BAYES_FUSION",
            window = 50,
            baselineValue = 0.50,
            stageMult = 2.0,
            supportedTypes = setOf(LotteryType.K3)
        )
    )

    /** B轨：组合2口互补对冲计划 */
    val TRACK_B_PLANS: List<StrategyDefinition> = listOf(
        StrategyDefinition(
            planId = "STRAT-B-COMBO2-HEDGE",
            planName = "组合2口·互补对冲",
            track = StrategyTrack.TRACK_B,
            playType = "组合",
            algorithm = "HEDGE_2",
            window = 50,
            baselineValue = 0.50,
            stageMult = 2.0,
            supportedTypes = LotteryType.entries.toSet()
        ),
        // 运动会组合2口
        StrategyDefinition(
            planId = "STRAT-B-YDH-COMBO2",
            planName = "运动会组合2口·对冲",
            track = StrategyTrack.TRACK_B,
            playType = "组合",
            algorithm = "HEDGE_2",
            window = 50,
            baselineValue = 0.50,
            stageMult = 2.0,
            supportedTypes = setOf(LotteryType.YDH)
        )
    )

    /** C轨：组合3口排除最不可能口计划 */
    val TRACK_C_PLANS: List<StrategyDefinition> = listOf(
        StrategyDefinition(
            planId = "STRAT-C-COMBO3-EXCLUDE",
            planName = "组合3口·排除最弱",
            track = StrategyTrack.TRACK_C,
            playType = "组合",
            algorithm = "EXCLUDE_1",
            window = 50,
            baselineValue = 0.75,
            stageMult = 2.0,
            supportedTypes = LotteryType.entries.toSet()
        ),
        StrategyDefinition(
            planId = "STRAT-C-YDH-COMBO3",
            planName = "运动会组合3口·排除最弱",
            track = StrategyTrack.TRACK_C,
            playType = "组合",
            algorithm = "EXCLUDE_1",
            window = 50,
            baselineValue = 0.75,
            stageMult = 2.0,
            supportedTypes = setOf(LotteryType.YDH)
        )
    )

    /** 全部计划 */
    val ALL: List<StrategyDefinition> = TRACK_A_PLANS + TRACK_B_PLANS + TRACK_C_PLANS

    /** 按轨道获取 */
    fun byTrack(track: StrategyTrack): List<StrategyDefinition> = when (track) {
        StrategyTrack.TRACK_A -> TRACK_A_PLANS
        StrategyTrack.TRACK_B -> TRACK_B_PLANS
        StrategyTrack.TRACK_C -> TRACK_C_PLANS
    }

    /** 按彩种类型筛选可用计划 */
    fun forLotteryType(type: LotteryType): List<StrategyDefinition> =
        ALL.filter { it.supportedTypes.isEmpty() || type in it.supportedTypes }

    /** 按 planId 查找 */
    fun byId(planId: String): StrategyDefinition? = ALL.find { it.planId == planId }
}
