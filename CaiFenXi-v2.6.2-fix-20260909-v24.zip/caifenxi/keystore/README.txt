彩析 Release 签名密钥

文件: caifenxi-release.jks
alias: caifenxi

签名凭据请通过 local.properties 配置，不要在此文件或任何代码/文档中明文写入密码。

覆盖安装必须使用同一把 keystore。请自行备份，不要公开上传到开源仓库。
