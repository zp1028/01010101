# Smart Trader — Final Analysis-Only Hardening

本版本将产品边界固定为：**全市场行情与研究分析，只读，不模拟、不纸面交易、不连接交易账户、不提供下单/执行接口。**

## 已收口能力
- Crypto：Binance Spot + USD-M Futures 动态发现、实时行情、衍生品只读数据。
- US：SEC issuer/ticker 动态发现 + SEC XBRL 基本面；实时行情通过可配置 provider 接入。
- HK：HKEX/信息供应商接口抽象；未配置真实 provider 时明确显示 `provider_required`，不伪造实时行情。
- Commodities：期货 universe/provider 抽象；未配置实时 provider 时明确为非实时/有限覆盖。
- 7 周期独立分析：5m / 15m / 30m / 1h / 4h / 1d / 1w。
- 技术指标、市场结构、超买超卖、背离、多空情景、持仓观察、数据质量。
- 32 类报告能力中心。
- 多交易所加密货币只读增强：Binance / OKX / Bybit（可用字段按 provider 实际能力返回）。
- 统一 instrument analysis contract。
- Market capability matrix 与单市场 capability 查询。

## 公共 API 边界
最终 FastAPI 路由不注册：
- `/risk/account`
- `/portfolio/risk`
- `/replay`
- `/backtests`
- 任何 order / execute / trading-account endpoint

内部 backtest / risk / research modules 可以保留作为研发计算层，但不会成为 APP 的交易操作入口。

## 数据真实性规则
1. Provider 没有提供的数据返回 unavailable / provider_required。
2. 不用 0、空数组或默认值冒充实时数据。
3. 实时未收盘 K 线只能作为观察，突破/跌破需要对应周期收盘确认。
4. 基本面与行情价格分开维护，只有数据时间和来源可对齐时才生成估值倍数。
5. HKEX Level 1/Level 2/Full Book 等市场深度按 provider capability 区分，不把普通报价冒充完整盘口。

## 验证
- Backend pytest: 70 passed
- Backend compileall: PASS
- Public sensitive route audit: PASS（44 registered FastAPI routes）
- ZIP integrity: PASS
- Android Gradle/APK：本环境没有成功完成 Gradle 8.9 下载，因此未虚报 APK 构建成功；请在联网 CI 中执行最终 Android build。

## 关键官方数据依据
- SEC EDGAR API：公司申报/XBRL 数据，官方接口实时更新申报数据。
- HKEX OMD-C/OMD-D：官方证券/衍生品实时数据feed，按 Level 1/Level 2/Full Book 等能力区分。
- CME：商品期货及期权产品、实时价格与合约信息由交易所数据体系提供。
