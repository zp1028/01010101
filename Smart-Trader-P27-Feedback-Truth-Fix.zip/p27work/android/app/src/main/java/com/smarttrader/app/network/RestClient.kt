package com.smarttrader.app.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit


data class CandleDto(
    val openTime: Long,
    val closeTime: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double,
)

data class IndicatorDto(
    val symbol: String,
    val timeframe: String,
    val lastPrice: Double?,
    val rsi: Double?,
    val macdHist: Double?,
    val bbPct: Double?,
    val trendSma: String?,
    val summary: String,
    val oscillators: List<String>,
    val signals: List<String>,
    val trendLabel: String = "未知",
    val trendStrength: String = "未知",
    val overboughtCount: Int = 0,
    val oversoldCount: Int = 0,
    val narrative: String = "",
    val realtimeNote: String = "",
    val details: List<String> = emptyList(),
    val structureNote: String = "",
    val divergence: String = "",
)

data class MultiTimeframeDto(
    val symbol: String,
    val currentTimeframe: String,
    val current: IndicatorDto,
    val timeframes: Map<String, IndicatorDto>,
    val resonance: String,
    val resonanceNote: String,
    val realtimeNote: String,
)

data class EntryPlanDto(
    val direction: String,
    val conviction: Double,
    val entryLow: Double?,
    val entryHigh: Double?,
    val entry: Double?,
    val stop: Double?,
    val tp1: Double?,
    val tp2: Double?,
    val positionPct: Double?,
    val rr: Double?,
    val rationale: List<String>,
)

data class AnalysisFeedItemDto(val symbol:String,val market:String,val timeframe:String,val confidence:Double,val state:String,val direction:String,val summary:String,val reportId:String,val generatedAt:Long,val feedbackState:String,val feedbackSummary:String)
data class AnalysisFeedDto(val items:List<AnalysisFeedItemDto>,val generatedAt:Long,val dataQuality:String)
data class FeedbackHistoryDto(val reportId:String,val generatedAt:Long,val direction:String,val confidence:Double,val state:String,val feedbackState:String,val feedbackSummary:String,val priceAtReport:Double?,val currentPrice:Double?)
data class AnalysisFeedbackDto(val xSymbol:String,val market:String,val timeframe:String,val currentState:String,val currentSummary:String,val history:List<FeedbackHistoryDto>)

data class AdviceDto(
    val symbol: String,
    val bias: String,
    val longPlan: EntryPlanDto,
    val shortPlan: EntryPlanDto,
    val direction: String,
    val conviction: Double,
    val entryLow: Double?,
    val entryHigh: Double?,
    val entry: Double?,
    val stop: Double?,
    val tp1: Double?,
    val tp2: Double?,
    val positionPct: Double?,
    val rr: Double?,
    val positionAction: String,
    val positionNote: String,
    val rationale: List<String>,
    val lastPrice: Double?,
)


data class ReportCatalogItemDto(
    val id: Int, val key: String, val name: String, val domain: String, val priority: String, val update: String, val markets: List<String>,
    val status: String = "unknown", val statusReason: String = ""
)

data class ReportResultDto(
    val key: String, val name: String, val domain: String, val priority: String,
    val summary: String, val availability: String, val availabilityReason: String,
    val dataQuality: String, val generatedAt: String, val content: List<String>
)

data class InstrumentAnalysisSnapshotDto(
    val symbol: String,
    val market: String,
    val timeframe: String,
    val snapshotAvailable: Boolean,
    val capabilityStatus: String,
    val provider: String,
    val quality: String = "unknown",
    val realtime: Boolean = false,
    val missing: List<String> = emptyList(),
)

data class DerivativesDto(
    val symbol: String, val provider: String, val available: Boolean, val readOnly: Boolean,
    val fundingRate: Double?, val openInterest: Double?, val markPrice: Double?, val indexPrice: Double?,
    val longShortRatio: Double?, val buySellRatio: Double?, val basisRate: Double?, val liquidationPrice: Double?,
)

data class ExchangeMarketDto(
    val provider: String, val available: Boolean, val markPrice: Double?, val indexPrice: Double?,
    val fundingRate: Double?, val openInterest: Double?,
)

data class MultiExchangeDto(
    val symbol: String, val providers: List<ExchangeMarketDto>, val providerCount: Int,
    val markPriceMean: Double?, val fundingRateMean: Double?, val openInterestMean: Double?,
    val fundingSpread: Double?, val markSpreadPct: Double?,
)

data class UnifiedReportDto(
    val symbol: String, val timeframe: String, val summary: String, val narrative: String,
    val dataQuality: String, val generatedAt: String, val realtimeNote: String,
    val longSummary: String, val shortSummary: String, val holdingSummary: String, val riskNotes: List<String>
)

object RestClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val json = "application/json; charset=utf-8".toMediaType()

    suspend fun fetchReportCatalog(): Result<List<ReportCatalogItemDto>> = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder().url("${ApiConfig.baseUrl.trimEnd('/')}/api/v1/reports/catalog").get().build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                val root = JSONObject(resp.body?.string().orEmpty())
                val arr = root.optJSONArray("reports") ?: return@withContext Result.success(emptyList())
                val out = mutableListOf<ReportCatalogItemDto>()
                for (i in 0 until arr.length()) {
                    val x = arr.getJSONObject(i)
                    val markets = mutableListOf<String>()
                    x.optJSONArray("markets")?.let { a -> for (j in 0 until a.length()) markets += a.optString(j) }
                    out += ReportCatalogItemDto(x.optInt("id"), x.optString("key"), x.optString("name"), x.optString("domain"), x.optString("priority"), x.optString("update"), markets)
                }
                Result.success(out)
            }
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun fetchInstrumentReportManifest(symbol: String, timeframe: String, market: String): Result<List<ReportCatalogItemDto>> = withContext(Dispatchers.IO) {
        try {
            val raw = symbol.replace("/", "")
            val url = "${ApiConfig.baseUrl.trimEnd('/')}/api/v1/reports/instrument/$raw?timeframe=$timeframe&market=$market"
            val req = Request.Builder().url(url).get().build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                val root = JSONObject(resp.body?.string().orEmpty())
                val arr = root.optJSONArray("reports") ?: return@withContext Result.success(emptyList())
                val out = mutableListOf<ReportCatalogItemDto>()
                for (i in 0 until arr.length()) {
                    val x = arr.getJSONObject(i)
                    val reqs = mutableListOf<String>()
                    x.optJSONArray("source_requirements")?.let { a -> for (j in 0 until a.length()) reqs += a.optString(j) }
                    out += ReportCatalogItemDto(
                        x.optInt("id"), x.optString("key"), x.optString("name"),
                        x.optString("domain"), x.optString("priority"), x.optString("update"),
                        reqs, x.optString("status", "unknown"), x.optString("reason", "")
                    )
                }
                Result.success(out)
            }
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun fetchReport(reportKey: String, symbol: String, timeframe: String, market: String): Result<ReportResultDto> = withContext(Dispatchers.IO) {
        try {
            val raw = symbol.replace("/", "")
            val url = "${ApiConfig.baseUrl.trimEnd('/')}/api/v1/reports/$reportKey/$raw?timeframe=$timeframe&market=$market"
            val req = Request.Builder().url(url).get().build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                val o = JSONObject(resp.body?.string().orEmpty())
                val r = o.optJSONObject("report") ?: JSONObject()
                val a = o.optJSONObject("availability") ?: JSONObject()
                val content = mutableListOf<String>()
                fun flatten(value: Any?, prefix: String = "") {
                    when (value) {
                        is JSONObject -> value.keys().forEach { k -> flatten(value.opt(k), if (prefix.isBlank()) k else "$prefix.$k") }
                        is org.json.JSONArray -> for (i in 0 until value.length()) flatten(value.opt(i), "$prefix[$i]")
                        else -> if (value != null && value.toString().isNotBlank() && value.toString() != "null") content += "$prefix: $value"
                    }
                }
                flatten(o.opt("content"))
                Result.success(ReportResultDto(r.optString("key"), r.optString("name"), r.optString("domain"), r.optString("priority"), o.optString("summary"), a.optString("status"), a.optString("reason"), o.optJSONObject("data_quality")?.toString() ?: "—", o.optString("generated_at"), content.take(24)))
            }
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun fetchDerivatives(symbol: String, period: String = "1h"): Result<DerivativesDto> = withContext(Dispatchers.IO) {
        try {
            val raw = symbol.replace("/", "")
            val url = "${ApiConfig.baseUrl.trimEnd('/')}/api/v1/derivatives/crypto/$raw?period=$period"
            client.newCall(Request.Builder().url(url).get().build()).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                val o = JSONObject(resp.body?.string().orEmpty())
                val f=o.optJSONObject("funding")?.optJSONObject("latest")
                val oi=o.optJSONObject("open_interest")?.optJSONObject("latest")
                val mi=o.optJSONObject("mark_index")
                val ls=o.optJSONObject("long_short")?.optJSONObject("latest")
                val tk=o.optJSONObject("taker_flow")?.optJSONObject("latest")
                val ba=o.optJSONObject("basis")?.optJSONObject("latest")
                val li=o.optJSONObject("liquidations")?.optJSONObject("latest")
                Result.success(DerivativesDto(
                    o.optString("symbol",symbol), o.optString("provider"), o.optBoolean("available"), o.optBoolean("read_only",true),
                    f?.optDouble("fundingRate")?.takeUnless { it.isNaN() } ?: mi?.optDouble("last_funding_rate")?.takeUnless { it.isNaN() },
                    oi?.optDouble("open_interest")?.takeUnless { it.isNaN() }, mi?.optDouble("mark_price")?.takeUnless { it.isNaN() },
                    mi?.optDouble("index_price")?.takeUnless { it.isNaN() }, ls?.optDouble("longShortRatio")?.takeUnless { it.isNaN() },
                    tk?.optDouble("buySellRatio")?.takeUnless { it.isNaN() }, ba?.optDouble("basisRate")?.takeUnless { it.isNaN() },
                    li?.optDouble("price")?.takeUnless { it.isNaN() }
                ))
            }
        } catch(e:Exception){ Result.failure(e) }
    }

    suspend fun fetchMultiExchange(symbol: String): Result<MultiExchangeDto> = withContext(Dispatchers.IO) {
        try {
            val raw=symbol.replace("/","")
            val url="${ApiConfig.baseUrl.trimEnd('/')}/api/v1/crypto/$raw/multi-exchange"
            client.newCall(Request.Builder().url(url).get().build()).execute().use { resp ->
                if(!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                val o=JSONObject(resp.body?.string().orEmpty()); val arr=o.optJSONArray("providers") ?: org.json.JSONArray()
                val rows=mutableListOf<ExchangeMarketDto>()
                for(i in 0 until arr.length()){ val x=arr.getJSONObject(i); rows+=ExchangeMarketDto(x.optString("provider"),x.optBoolean("available"),x.optDouble("mark_price").takeUnless{it.isNaN()},x.optDouble("index_price").takeUnless{it.isNaN()},x.optDouble("funding_rate").takeUnless{it.isNaN()},x.optDouble("open_interest").takeUnless{it.isNaN()}) }
                val c=o.optJSONObject("consensus") ?: JSONObject(); val d=o.optJSONObject("divergence") ?: JSONObject()
                Result.success(MultiExchangeDto(o.optString("symbol",symbol),rows,o.optInt("available_provider_count"),c.optDouble("mark_price_mean").takeUnless{it.isNaN()},c.optDouble("funding_rate_mean").takeUnless{it.isNaN()},c.optDouble("open_interest_mean").takeUnless{it.isNaN()},d.optDouble("funding_rate_spread").takeUnless{it.isNaN()},d.optDouble("mark_price_spread_pct").takeUnless{it.isNaN()}))
            }
        } catch(e:Exception){ Result.failure(e) }
    }

    suspend fun fetchUnifiedReport(symbol: String, timeframe: String, market: String): Result<UnifiedReportDto> = withContext(Dispatchers.IO) {
        try {
            val raw = symbol.replace("/", "")
            val url = "${ApiConfig.baseUrl.trimEnd('/')}/api/v1/unified-report/$raw?timeframe=$timeframe&market=$market"
            val req = Request.Builder().url(url).get().build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                val o = JSONObject(resp.body?.string().orEmpty())
                val sc = o.optJSONObject("scenario_analysis") ?: JSONObject()
                val risk = mutableListOf<String>()
                sc.optJSONArray("risk_notes")?.let { a -> for (i in 0 until a.length()) risk += a.optString(i) }
                val longObj = sc.optJSONObject("long") ?: JSONObject()
                val shortObj = sc.optJSONObject("short") ?: JSONObject()
                val holdObj = sc.optJSONObject("holding") ?: JSONObject()
                fun one(x: JSONObject): String = x.optString("summary").ifBlank { x.optString("rationale").ifBlank { x.toString() } }
                Result.success(UnifiedReportDto(o.optString("symbol", symbol), o.optString("timeframe", timeframe), o.optString("summary"), o.optString("narrative"), o.optJSONObject("data_quality")?.toString() ?: "—", o.optString("generated_at"), o.optString("realtime_note"), one(longObj), one(shortObj), one(holdObj), risk))
            }
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun fetchInstrumentAnalysisSnapshot(symbol: String, timeframe: String, market: String): Result<InstrumentAnalysisSnapshotDto> = withContext(Dispatchers.IO) {
        try {
            val raw = symbol.replace("/", "")
            val url = "${ApiConfig.baseUrl.trimEnd('/')}/api/v1/instrument/$market/$raw/analysis?timeframe=$timeframe&limit=250"
            val req = Request.Builder().url(url).get().build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                val o = JSONObject(resp.body?.string().orEmpty())
                val inst = o.optJSONObject("instrument") ?: JSONObject()
                val snap = o.optJSONObject("snapshot") ?: JSONObject()
                val caps = o.optJSONObject("capabilities") ?: JSONObject()
                val missing = mutableListOf<String>()
                caps.optJSONArray("missing")?.let { a -> for (i in 0 until a.length()) missing += a.optString(i) }
                Result.success(InstrumentAnalysisSnapshotDto(
                    inst.optString("symbol", symbol),
                    inst.optString("market", market),
                    inst.optString("timeframe", timeframe),
                    snap.optBoolean("available", false),
                    caps.optString("status", "unknown"),
                    caps.optString("provider", "unknown"),
                    caps.optString("quality", "unknown"),
                    caps.optBoolean("realtime", false),
                    missing,
                ))
            }
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun fetchCandles(symbol: String, timeframe: String, market: String, limit: Int = 180): Result<List<CandleDto>> = withContext(Dispatchers.IO) {
        try {
            val raw = symbol.replace("/", "")
            val url = "${ApiConfig.baseUrl.trimEnd('/')}/api/v1/candles/$raw?timeframe=$timeframe&market=$market&limit=$limit"
            val req = Request.Builder().url(url).get().build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                val arr = JSONObject(resp.body?.string().orEmpty()).optJSONArray("candles") ?: return@withContext Result.success(emptyList())
                val out = mutableListOf<CandleDto>()
                for (i in 0 until arr.length()) {
                    val x = arr.getJSONObject(i)
                    out += CandleDto(x.optLong("open_time"), x.optLong("close_time"), x.optDouble("open"), x.optDouble("high"), x.optDouble("low"), x.optDouble("close"), x.optDouble("volume"))
                }
                Result.success(out)
            }
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun health(): Boolean = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder().url(ApiConfig.healthUrl).get().build()
            client.newCall(req).execute().use { it.isSuccessful }
        } catch (_: Exception) {
            false
        }
    }

    suspend fun fetchIndicators(symbol: String, timeframe: String, market: String = "crypto"): Result<IndicatorDto> =
        withContext(Dispatchers.IO) {
            try {
                val raw = symbol.replace("/", "")
                val url = "${ApiConfig.baseUrl.trimEnd('/')}/api/v1/indicators/$raw?timeframe=$timeframe&market=$market"
                val req = Request.Builder().url(url).get().build()
                client.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                    val body = resp.body?.string().orEmpty()
                    val o = JSONObject(body)
                    val osc = o.optJSONArray("oscillators")
                    val oscList = mutableListOf<String>()
                    if (osc != null) {
                        for (i in 0 until osc.length()) {
                            val x = osc.getJSONObject(i)
                            oscList.add("${x.optString("name")}: ${x.optString("state")} (${x.optString("note")})")
                        }
                    }
                    val sig = o.optJSONArray("active_signals")
                    val sigList = mutableListOf<String>()
                    if (sig != null) {
                        for (i in 0 until sig.length()) {
                            val x = sig.getJSONObject(i)
                            sigList.add("${x.optString("name")} → ${x.optString("direction")}")
                        }
                    }
                    Result.success(
                        IndicatorDto(
                            symbol = o.optString("symbol", symbol),
                            timeframe = o.optString("timeframe", timeframe),
                            lastPrice = o.optDoubleOrNull("last_price"),
                            rsi = o.optDoubleOrNull("rsi_14"),
                            macdHist = o.optDoubleOrNull("macd_hist"),
                            bbPct = o.optDoubleOrNull("bb_pct"),
                            trendSma = o.optString("trend_sma", null),
                            summary = o.optString("summary"),
                            oscillators = oscList,
                            signals = sigList,
                            trendLabel = o.optString("trend_label", "未知"),
                            trendStrength = o.optString("trend_strength", "未知"),
                            overboughtCount = o.optInt("overbought_count", 0),
                            oversoldCount = o.optInt("oversold_count", 0),
                            narrative = o.optString("narrative", ""),
                            realtimeNote = o.optString("realtime_note", ""),
                            details = listOf(
                                "MA20 ${o.optDoubleOrNull("sma_20") ?: "—"} · MA50 ${o.optDoubleOrNull("sma_50") ?: "—"} · MA200 ${o.optDoubleOrNull("sma_200") ?: "—"}",
                                "EMA12 ${o.optDoubleOrNull("ema_12") ?: "—"} · EMA26 ${o.optDoubleOrNull("ema_26") ?: "—"}",
                                "Stoch K ${o.optDoubleOrNull("stoch_k") ?: "—"} / D ${o.optDoubleOrNull("stoch_d") ?: "—"} · StochRSI ${o.optDoubleOrNull("stoch_rsi") ?: "—"}",
                                "CCI ${o.optDoubleOrNull("cci_20") ?: "—"} · Williams %R ${o.optDoubleOrNull("williams_r") ?: "—"} · UO ${o.optDoubleOrNull("ultimate_osc") ?: "—"}",
                                "ATR ${o.optDoubleOrNull("atr_14") ?: "—"} · ADX ${o.optDoubleOrNull("adx_14") ?: "—"} · DMI+ ${o.optDoubleOrNull("dmi_plus") ?: "—"} / DMI- ${o.optDoubleOrNull("dmi_minus") ?: "—"}",
                                "BOLL ${o.optDoubleOrNull("bb_lower") ?: "—"} / ${o.optDoubleOrNull("bb_mid") ?: "—"} / ${o.optDoubleOrNull("bb_upper") ?: "—"} · % ${o.optDoubleOrNull("bb_pct") ?: "—"}",
                                "VWAP ${o.optDoubleOrNull("vwap") ?: "—"} · MFI ${o.optDoubleOrNull("mfi_14") ?: "—"} · CMF ${o.optDoubleOrNull("cmf_20") ?: "—"}",
                                "OBV ${o.optDoubleOrNull("obv") ?: "—"} · ROC ${o.optDoubleOrNull("roc_12") ?: "—"} · Volume比 ${o.optDoubleOrNull("volume_ratio") ?: "—"}",
                                "Keltner ${o.optDoubleOrNull("keltner_lower") ?: "—"} / ${o.optDoubleOrNull("keltner_mid") ?: "—"} / ${o.optDoubleOrNull("keltner_upper") ?: "—"}",
                                "Donchian ${o.optDoubleOrNull("donchian_low") ?: "—"} / ${o.optDoubleOrNull("donchian_mid") ?: "—"} / ${o.optDoubleOrNull("donchian_high") ?: "—"} · PSAR ${o.optDoubleOrNull("psar") ?: "—"}",
                            ),
                            structureNote = o.optJSONObject("structure")?.optString("note", "") ?: "",
                            divergence = o.optString("divergence", "无明显背离"),
                        )
                    )
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }


    suspend fun fetchMultiTimeframe(symbol: String, current: String, market: String = "crypto"): Result<MultiTimeframeDto> =
        withContext(Dispatchers.IO) {
            try {
                val raw = symbol.replace("/", "")
                val url = "${ApiConfig.baseUrl.trimEnd('/')}/api/v1/indicators/$raw/multi?current=$current&market=$market"
                val req = Request.Builder().url(url).get().build()
                client.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                    val root = JSONObject(resp.body?.string().orEmpty())
                    fun parse(o: JSONObject): IndicatorDto {
                        val osc = mutableListOf<String>()
                        o.optJSONArray("oscillators")?.let { arr -> for (i in 0 until arr.length()) { val x = arr.getJSONObject(i); osc += "${x.optString("name")}: ${x.optString("state")} (${x.optString("note")})" } }
                        val sig = mutableListOf<String>()
                        o.optJSONArray("active_signals")?.let { arr -> for (i in 0 until arr.length()) { val x = arr.getJSONObject(i); sig += "${x.optString("name")} → ${x.optString("direction")}" } }
                        return IndicatorDto(
                            symbol=o.optString("symbol", symbol), timeframe=o.optString("timeframe"),
                            lastPrice=o.optDoubleOrNull("last_price"), rsi=o.optDoubleOrNull("rsi_14"),
                            macdHist=o.optDoubleOrNull("macd_hist"), bbPct=o.optDoubleOrNull("bb_pct"),
                            trendSma=o.optString("trend_sma", null), summary=o.optString("summary"),
                            oscillators=osc, signals=sig, trendLabel=o.optString("trend_label", "未知"),
                            trendStrength=o.optString("trend_strength", "未知"), overboughtCount=o.optInt("overbought_count", 0),
                            oversoldCount=o.optInt("oversold_count", 0), narrative=o.optString("narrative", ""),
                            realtimeNote=o.optString("realtime_note", ""),
                            details = listOf(
                                "RSI ${o.optDoubleOrNull("rsi_14") ?: "—"} · MACD柱 ${o.optDoubleOrNull("macd_hist") ?: "—"} · ADX ${o.optDoubleOrNull("adx_14") ?: "—"}",
                                "MA20 ${o.optDoubleOrNull("sma_20") ?: "—"} · MA50 ${o.optDoubleOrNull("sma_50") ?: "—"} · ATR ${o.optDoubleOrNull("atr_14") ?: "—"}",
                                "Stoch ${o.optDoubleOrNull("stoch_k") ?: "—"} · CCI ${o.optDoubleOrNull("cci_20") ?: "—"} · MFI ${o.optDoubleOrNull("mfi_14") ?: "—"}",
                            ),
                            structureNote=o.optJSONObject("structure")?.optString("note", "") ?: "",
                            divergence=o.optString("divergence", "无明显背离")
                        )
                    }
                    val map = mutableMapOf<String, IndicatorDto>()
                    root.optJSONObject("timeframes")?.let { obj -> obj.keys().forEach { k -> obj.optJSONObject(k)?.let { map[k] = parse(it) } } }
                    val currentDto = root.optJSONObject("current")?.let { parse(it) } ?: return@withContext Result.failure(Exception("current timeframe missing"))
                    Result.success(MultiTimeframeDto(root.optString("symbol", symbol), root.optString("current_timeframe", current), currentDto, map, root.optString("resonance", ""), root.optString("resonance_note", ""), root.optString("realtime_note", "")))
                }
            } catch (e: Exception) { Result.failure(e) }
        }

    suspend fun fetchAdvice(symbol: String, timeframe: String = "15m", market: String = "crypto"): Result<AdviceDto> =
        withContext(Dispatchers.IO) {
            try {
                val raw = symbol.replace("/", "")
                val url =
                    "${ApiConfig.baseUrl.trimEnd('/')}/api/v1/advice/$raw?timeframe=$timeframe&run_analysis=true&market=$market"
                val req = Request.Builder().url(url).get().build()
                client.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                    val o = JSONObject(resp.body?.string().orEmpty())
                    val entry = o.optJSONObject("entry")
                    val long = o.optJSONObject("long_entry")
                    val short = o.optJSONObject("short_entry")
                    val pos = o.optJSONObject("position")
                    fun plan(x: JSONObject?): EntryPlanDto {
                        val ra = mutableListOf<String>()
                        x?.optJSONArray("rationale")?.let { arr ->
                            for (i in 0 until arr.length()) ra.add(arr.getString(i))
                        }
                        return EntryPlanDto(
                            direction = x?.optString("direction") ?: "wait",
                            conviction = x?.optDouble("conviction") ?: 0.0,
                            entryLow = x?.optDoubleOrNull("entry_zone_low"),
                            entryHigh = x?.optDoubleOrNull("entry_zone_high"),
                            entry = x?.optDoubleOrNull("suggested_entry"),
                            stop = x?.optDoubleOrNull("stop_loss"),
                            tp1 = x?.optDoubleOrNull("take_profit_1"),
                            tp2 = x?.optDoubleOrNull("take_profit_2"),
                            positionPct = x?.optDoubleOrNull("position_pct"),
                            rr = x?.optDoubleOrNull("risk_reward"),
                            rationale = ra,
                        )
                    }
                    val lp = plan(long)
                    val sp = plan(short)
                    val selectedRationale = mutableListOf<String>()
                    entry?.optJSONArray("rationale")?.let { arr ->
                        for (i in 0 until arr.length()) selectedRationale.add(arr.getString(i))
                    }
                    Result.success(
                        AdviceDto(
                            symbol = o.optString("symbol", symbol),
                            bias = o.optString("market_bias"),
                            longPlan = lp,
                            shortPlan = sp,
                            direction = entry?.optString("direction") ?: "wait",
                            conviction = entry?.optDouble("conviction") ?: 0.0,
                            entryLow = entry?.optDoubleOrNull("entry_zone_low"),
                            entryHigh = entry?.optDoubleOrNull("entry_zone_high"),
                            entry = entry?.optDoubleOrNull("suggested_entry"),
                            stop = entry?.optDoubleOrNull("stop_loss"),
                            tp1 = entry?.optDoubleOrNull("take_profit_1"),
                            tp2 = entry?.optDoubleOrNull("take_profit_2"),
                            positionPct = entry?.optDoubleOrNull("position_pct"),
                            rr = entry?.optDoubleOrNull("risk_reward"),
                            positionAction = pos?.optString("action") ?: "wait",
                            positionNote = pos?.optString("note") ?: "",
                            rationale = selectedRationale,
                            lastPrice = o.optDoubleOrNull("last_price"),
                        )
                    )
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }


private fun JSONObject.optDoubleOrNull(key: String): Double? {
    if (!has(key) || isNull(key)) return null
    val v = optDouble(key, Double.NaN)
    return if (v.isNaN()) null else v
}

    data class MarketPage(val items: List<com.smarttrader.app.data.MarketItem>, val hasMore: Boolean, val total: Int, val offset: Int)

    suspend fun fetchMarketsPage(market: String? = null, query: String? = null, limit: Int = 250, offset: Int = 0): Result<MarketPage> = withContext(Dispatchers.IO) {
        try {
            val parts = mutableListOf("limit=$limit", "offset=$offset")
            if (!market.isNullOrBlank()) parts += "market=${java.net.URLEncoder.encode(market, "UTF-8")}"
            if (!query.isNullOrBlank()) parts += "q=${java.net.URLEncoder.encode(query, "UTF-8")}"
            val url = "${ApiConfig.baseUrl.trimEnd('/')}/api/v1/markets?${parts.joinToString("&")}"
            client.newCall(Request.Builder().url(url).get().build()).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                val root = JSONObject(resp.body?.string().orEmpty())
                val arr = root.optJSONArray("markets") ?: org.json.JSONArray()
                val out = mutableListOf<com.smarttrader.app.data.MarketItem>()
                for (i in 0 until arr.length()) {
                    val x = arr.getJSONObject(i)
                    out += com.smarttrader.app.data.MarketItem(
                        symbol=x.optString("symbol"), name=x.optString("name", x.optString("symbol")),
                        price=x.optDoubleOrNull("price")?.let { java.text.DecimalFormat("#,##0.####").format(it) } ?: "--",
                        changePct=x.optDoubleOrNull("change_pct") ?: 0.0, attention=0.0, regime="—",
                        assetClass=x.optString("market", "crypto"), venue=x.optString("venue"), currency=x.optString("currency")
                    )
                }
                Result.success(MarketPage(out, root.optBoolean("has_more", false), root.optInt("total", out.size), root.optInt("offset", offset)))
            }
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun fetchMarkets(market: String? = null, query: String? = null, limit: Int = 1000): Result<List<com.smarttrader.app.data.MarketItem>> =
        fetchMarketsPage(market, query, limit, 0).map { it.items }

    suspend fun fetchAnalysisFeed(market: String = "crypto", timeframe: String = "15m", limit: Int = 8): Result<AnalysisFeedDto> = withContext(Dispatchers.IO) {
        try {
            val url = "${ApiConfig.baseUrl.trimEnd('/')}/api/v1/analysis-feed?market=${java.net.URLEncoder.encode(market, "UTF-8")}&timeframe=${java.net.URLEncoder.encode(timeframe, "UTF-8")}&limit=$limit"
            client.newCall(Request.Builder().url(url).get().build()).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                val root=JSONObject(resp.body?.string().orEmpty())
                val arr=root.optJSONArray("items") ?: org.json.JSONArray()
                val items=mutableListOf<AnalysisFeedItemDto>()
                for(i in 0 until arr.length()){ val x=arr.getJSONObject(i); items += AnalysisFeedItemDto(x.optString("symbol"),x.optString("market"),x.optString("timeframe"),x.optDouble("confidence"),x.optString("state"),x.optString("direction"),x.optString("summary"),x.optString("report_id"),x.optLong("generated_at"),x.optString("feedback_state"),x.optString("feedback_summary")) }
                Result.success(AnalysisFeedDto(items, root.optLong("generated_at"), root.optString("data_quality")))
            }
        } catch(e:Exception){ Result.failure(e) }
    }

    suspend fun fetchAnalysisFeedback(symbol: String, market: String, timeframe: String): Result<AnalysisFeedbackDto> = withContext(Dispatchers.IO) {
        try {
            val url="${ApiConfig.baseUrl.trimEnd('/')}/api/v1/analysis-feedback/${java.net.URLEncoder.encode(symbol, "UTF-8")}?market=${java.net.URLEncoder.encode(market, "UTF-8")}&timeframe=${java.net.URLEncoder.encode(timeframe, "UTF-8")}"
            client.newCall(Request.Builder().url(url).get().build()).execute().use { resp ->
                if(!resp.isSuccessful) return@withContext Result.failure(Exception("HTTP ${resp.code}"))
                val root=JSONObject(resp.body?.string().orEmpty()); val arr=root.optJSONArray("history") ?: org.json.JSONArray(); val h=mutableListOf<FeedbackHistoryDto>()
                for(i in 0 until arr.length()){ val x=arr.getJSONObject(i); h += FeedbackHistoryDto(x.optString("report_id"),x.optLong("generated_at"),x.optString("direction"),x.optDouble("confidence"),x.optString("state"),x.optString("feedback_state"),x.optString("feedback_summary"),x.optDoubleOrNull("price_at_report"),x.optDoubleOrNull("current_price")) }
                Result.success(AnalysisFeedbackDto(xSymbol=root.optString("symbol",symbol), market=root.optString("market",market), timeframe=root.optString("timeframe",timeframe), currentState=root.optString("current_state"), currentSummary=root.optString("current_summary"), history=h))
            }
        } catch(e:Exception){ Result.failure(e) }
    }

}
