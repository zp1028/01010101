package com.smarttrader.app.data

data class MarketItem(
    val symbol: String,
    val name: String,
    val price: String,
    val changePct: Double,
    val attention: Double,
    val regime: String,
    val assetClass: String = "crypto",
    val venue: String = "",
    val currency: String = "",
)

data class SignalItem(
    val symbol: String,
    val name: String,
    val direction: String,
    val strength: Double,
    val timeframe: String,
)

data class PositionUi(
    val symbol: String,
    val side: String,
    val qty: String,
    val entry: String,
    val pnl: String,
    val pnlPct: Double,
)

object Watchlist {
    val defaults = listOf(
        MarketItem("BTC/USDT", "Bitcoin", "--", 0.0, 0.0, "—"),
        MarketItem("ETH/USDT", "Ethereum", "--", 0.0, 0.0, "—"),
        MarketItem("SOL/USDT", "Solana", "--", 0.0, 0.0, "—"),
        MarketItem("BNB/USDT", "BNB", "--", 0.0, 0.0, "—"),
        MarketItem("XRP/USDT", "XRP", "--", 0.0, 0.0, "—"),
        MarketItem("DOGE/USDT", "Dogecoin", "--", 0.0, 0.0, "—"),
        MarketItem("ADA/USDT", "Cardano", "--", 0.0, 0.0, "—"),
        MarketItem("AVAX/USDT", "Avalanche", "--", 0.0, 0.0, "—"),
        MarketItem("LINK/USDT", "Chainlink", "--", 0.0, 0.0, "—"),
        MarketItem("DOT/USDT", "Polkadot", "--", 0.0, 0.0, "—"),
    )
}
