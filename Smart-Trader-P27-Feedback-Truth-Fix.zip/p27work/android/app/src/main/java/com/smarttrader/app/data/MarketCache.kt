package com.smarttrader.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Small persistent fallback cache for the last known market state. */
object MarketCache {
    private const val PREFS = "smart_trader_market_cache"
    private const val KEY_ITEMS = "items"
    private const val KEY_SAVED_AT = "saved_at"
    private const val KEY_FAVORITES = "favorites"
    private lateinit var prefs: android.content.SharedPreferences

    fun init(context: Context) {
        if (!::prefs.isInitialized) {
            prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        }
    }

    fun load(): Pair<List<MarketItem>, Long> {
        if (!::prefs.isInitialized) return Watchlist.defaults to 0L
        val raw = prefs.getString(KEY_ITEMS, null) ?: return Watchlist.defaults to 0L
        return try {
            val arr = JSONArray(raw)
            val list = buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    add(MarketItem(
                        symbol = o.optString("symbol"), name = o.optString("name"),
                        price = o.optString("price", "--"), changePct = o.optDouble("changePct", 0.0),
                        attention = o.optDouble("attention", 0.0), regime = o.optString("regime", "—"),
                    ))
                }
            }
            (if (list.isEmpty()) Watchlist.defaults else list) to prefs.getLong(KEY_SAVED_AT, 0L)
        } catch (_: Exception) {
            Watchlist.defaults to 0L
        }
    }

    fun loadFavorites(): Set<String> {
        if (!::prefs.isInitialized) return emptySet()
        return prefs.getStringSet(KEY_FAVORITES, emptySet())?.toSet() ?: emptySet()
    }

    fun saveFavorites(symbols: Set<String>) {
        if (!::prefs.isInitialized) return
        prefs.edit().putStringSet(KEY_FAVORITES, symbols).apply()
    }

    fun save(items: List<MarketItem>) {
        if (!::prefs.isInitialized) return
        val arr = JSONArray()
        items.forEach { m ->
            arr.put(JSONObject().apply {
                put("symbol", m.symbol); put("name", m.name); put("price", m.price)
                put("changePct", m.changePct); put("attention", m.attention); put("regime", m.regime)
            })
        }
        prefs.edit().putString(KEY_ITEMS, arr.toString())
            .putLong(KEY_SAVED_AT, System.currentTimeMillis()).apply()
    }
}
