package com.smarttrader.app.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.Analytics
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.ShowChart
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.smarttrader.app.ui.screens.*
import com.smarttrader.app.ui.theme.*
import com.smarttrader.app.viewmodel.AppState

sealed class Tab(val route: String, val label: String, val icon: ImageVector) {
    data object Discover : Tab("discover", "发现", Icons.Outlined.Explore)
    data object Market : Tab("market", "市场", Icons.Outlined.ShowChart)
    data object Analysis : Tab("analysis", "分析", Icons.Outlined.Analytics)
    data object Account : Tab("account", "账户", Icons.Outlined.AccountBalanceWallet)
}

val tabs = listOf(Tab.Discover, Tab.Market, Tab.Analysis, Tab.Account)

@Composable
fun AppNav(state: AppState = viewModel()) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val current = backStack?.destination?.route

    // 详情页覆盖在主导航之上
    if (state.selectedSymbol != null) {
        DetailScreen(state)
        return
    }

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Surface, tonalElevation = 0.dp, modifier = Modifier.navigationBarsPadding()) {
                tabs.forEach { tab ->
                    val selected = current == tab.route
                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            nav.navigate(tab.route) {
                                popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = TextPrimary,
                            selectedTextColor = TextPrimary,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted,
                            indicatorColor = Border.copy(alpha = 0.5f),
                        ),
                    )
                }
            }
        },
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = Tab.Discover.route,
            modifier = Modifier.padding(padding).background(Bg),
        ) {
            composable(Tab.Discover.route) { DiscoverScreen(state) }
            composable(Tab.Market.route) { MarketScreen(state) }
            composable(Tab.Analysis.route) { AnalysisScreen(state) }
            composable(Tab.Account.route) { AccountScreen(state) }
        }
    }
}
