package com.smarttrader.app.network

/**
 * 模拟器默认 10.0.2.2 → 电脑 localhost
 * 真机请改为电脑局域网 IP，例如 http://192.168.1.8:8000
 */
object ApiConfig {
    var baseUrl: String = "http://10.0.2.2:8000"
    val wsUrl: String
        get() {
            val http = baseUrl.trimEnd('/')
            return when {
                http.startsWith("https://") ->
                    "wss://" + http.removePrefix("https://") + "/api/v1/ws/market"
                else ->
                    "ws://" + http.removePrefix("http://") + "/api/v1/ws/market"
            }
        }
    val healthUrl: String get() = baseUrl.trimEnd('/') + "/health"
}
