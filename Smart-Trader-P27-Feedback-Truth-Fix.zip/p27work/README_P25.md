# Smart Trader P25

P25 是“智能分析首页 + 报告生命周期 + 行情反馈”版本。

## 首页
当前高置信度分析 → 点击直接进入品种详情。

## 品种详情
当前分析 + 多周期 + 多空情景 + 历史报告反馈。

## 反馈闭环
报告 R001 → 行情变化 → R001-F1 → 新分析 R002。
历史 R001 不会被覆盖。

## 运行
Backend:
```bash
cd backend
pytest -q
```
Android 使用项目自带 Gradle wrapper。若构建环境不能访问 services.gradle.org，需要预先提供 Gradle 8.9 distribution/cache。
