# Smart Trader P24

## 本轮完成
- 市场列表从一次性最多 1000 条改为分页加载，默认 250 条，可继续加载。
- 保留后端全市场 universe；Android 不再用固定 10 个币种充当完整市场。
- 新增本地自选收藏：市场列表/卡片/详情页均可收藏，持久化到 SharedPreferences。
- 新增“自选”筛选。
- 清理 Android 客户端 `fetchPortfolio()` / `placeOrder()` 以及订单 API URL，客户端不再保留账户查询/下单调用。
- 清理已不再使用的 order body / portfolio URL 配置。
- 保持所有分析、行情、衍生品、报告接口为只读分析用途。

## 验证
- Backend pytest: 70 passed
- Python compileall: PASS
- Android compile: 当前环境仍因 Gradle Wrapper 需要访问 services.gradle.org 而无法启动编译；未声称 APK 编译成功。
