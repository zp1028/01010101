from __future__ import annotations
import time
from typing import Any
import httpx
from app.services.crypto_derivatives import BinanceDerivativesService

TIMEFRAME_MAP = {
    '5m':'5m','15m':'15m','30m':'30m','1h':'1h','4h':'4h','1d':'1d','1w':'1wk'
}

class InstrumentSnapshotService:
    """Read-only quote/market-context adapters for the instrument detail page."""
    def __init__(self, timeout: float = 8.0):
        self.timeout = timeout
        self.derivatives = BinanceDerivativesService(timeout=timeout)

    async def snapshot(self, symbol: str, market: str, timeframe: str = '1h') -> dict[str, Any]:
        market = market.lower(); symbol = symbol.strip(); timeframe = timeframe.lower()
        if market == 'crypto':
            return await self._crypto(symbol, timeframe)
        if market in {'us','commodities'}:
            return await self._yahoo(symbol, market, timeframe)
        if market == 'hk':
            return {'symbol': symbol, 'market': market, 'timeframe': timeframe,
                    'available': False, 'provider': 'configured HK provider',
                    'reason': 'HK quote provider must be configured/licensed; no fabricated quote is returned.'}
        return {'symbol': symbol, 'market': market, 'timeframe': timeframe, 'available': False, 'reason': 'unsupported market'}

    async def _yahoo(self, symbol: str, market: str, timeframe: str) -> dict[str, Any]:
        interval = TIMEFRAME_MAP.get(timeframe, '1h')
        url = f'https://query1.finance.yahoo.com/v8/finance/chart/{symbol}'
        params = {'range': '1mo' if interval in {'5m','15m','30m','1h','4h'} else '1y', 'interval': interval}
        async with httpx.AsyncClient(timeout=self.timeout, headers={'User-Agent':'SmartTrader/1.3'}) as client:
            r = await client.get(url, params=params); r.raise_for_status(); raw = r.json()
        result = raw.get('chart', {}).get('result', [None])[0]
        if not result: raise RuntimeError('quote provider returned no chart data')
        meta = result.get('meta', {})
        ts = result.get('timestamp', [])
        q = (result.get('indicators', {}).get('quote') or [{}])[0]
        candles = []
        for i, t in enumerate(ts):
            row = {k: (q.get(k, [None]*len(ts))[i] if i < len(q.get(k, [])) else None) for k in ('open','high','low','close','volume')}
            if row['close'] is not None: candles.append({'timestamp': t, **row})
        return {'symbol': symbol, 'market': market, 'timeframe': timeframe, 'provider':'Yahoo-compatible chart',
                'available': bool(candles), 'realtime': False, 'data_time': candles[-1]['timestamp'] if candles else None,
                'quote': {'price': meta.get('regularMarketPrice'), 'previous_close': meta.get('previousClose'),
                          'currency': meta.get('currency'), 'exchange': meta.get('exchangeName')},
                'candles': candles[-200:], 'retrieved_at': time.time()}

    async def _crypto(self, symbol: str, timeframe: str) -> dict[str, Any]:
        s = symbol.replace('/','').upper()
        interval = TIMEFRAME_MAP.get(timeframe, '1h')
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            r = await client.get('https://api.binance.com/api/v3/klines', params={'symbol':s,'interval':interval,'limit':200}); r.raise_for_status(); rows=r.json()
            p = await client.get('https://api.binance.com/api/v3/ticker/24hr', params={'symbol':s}); p.raise_for_status(); price=p.json()
        candles=[{'timestamp':x[0], 'open':float(x[1]), 'high':float(x[2]), 'low':float(x[3]), 'close':float(x[4]), 'volume':float(x[5]), 'closed':True} for x in rows]
        try:
            derivatives = await self.derivatives.snapshot(symbol, period=timeframe if timeframe in {'5m','15m','30m','1h','4h','1d'} else '1h')
        except Exception as exc:
            derivatives = {'available': False, 'reason': str(exc), 'capabilities': {}}
        return {'symbol':symbol,'market':'crypto','timeframe':timeframe,'provider':'Binance Spot REST','available':bool(candles),'realtime':True,
                'data_time':candles[-1]['timestamp'] if candles else None,
                'quote':{'price':float(price['lastPrice']),'previous_close':float(price['prevClosePrice']),'change_pct':float(price['priceChangePercent']),
                         'volume':float(price['volume'])}, 'candles':candles, 'derivatives': derivatives, 'retrieved_at':time.time()}
