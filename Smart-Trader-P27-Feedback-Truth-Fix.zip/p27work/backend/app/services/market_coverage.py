from __future__ import annotations

import os
from typing import Any

from app.services.market_universe import MarketUniverseService


class MarketCoverageService:
    def __init__(self, universe: MarketUniverseService | None = None) -> None:
        self.universe = universe or MarketUniverseService()

    async def snapshot(self) -> dict[str, Any]:
        crypto, us, hk, commodities = await __import__("asyncio").gather(
            self.universe.crypto(), self.universe.us(), self.universe.hk(), self.universe.commodities()
        )
        return {
            "generated_at": __import__("time").time_ns() // 1_000_000,
            "analysis_only": True,
            "markets": {
                "crypto": {"count": len(crypto), "universe": "Binance Spot + Futures", "realtime": True},
                "us": {"count": len(us), "universe": "SEC issuer/ticker master", "realtime": False, "quote_note": "SEC ticker master is discovery metadata, not a quote feed."},
                "hk": {"count": len(hk), "universe": "HKEX/provider configured", "realtime": False, "configured": bool(os.getenv("SMART_TRADER_HK_UNIVERSE_URL"))},
                "commodities": {"count": len(commodities), "universe": "major futures symbols", "realtime": False},
            },
            "coverage_rule": "Never label a market as fully covered unless its symbol master and quote provider are configured.",
        }
