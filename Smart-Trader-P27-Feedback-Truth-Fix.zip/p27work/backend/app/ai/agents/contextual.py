from __future__ import annotations
from dataclasses import dataclass

@dataclass(slots=True)
class ContextFinding:
    agent: str
    stance: str
    score: float
    confidence: float
    reasons: list[str]

def _finding(agent: str, score: float, reason: str, confidence: float = .35) -> ContextFinding:
    score=max(0.0,min(1.0,float(score)))
    stance='bullish' if score>.55 else 'bearish' if score<.45 else 'neutral'
    return ContextFinding(agent, stance, score, confidence, [reason])

def analyze_news(features):
    value=features.get('news_sentiment')
    if value is None: return _finding('NewsAgent', .5, 'no point-in-time news sentiment supplied', .2)
    return _finding('NewsAgent', (float(value)+1)/2, 'point-in-time news sentiment', .5)

def analyze_macro(features):
    value=features.get('macro_score')
    if value is None: return _finding('MacroAgent', .5, 'no point-in-time macro score supplied', .2)
    return _finding('MacroAgent', (float(value)+1)/2, 'point-in-time macro context', .45)

def analyze_onchain(features):
    value=features.get('onchain_score')
    if value is None: return _finding('OnChainAgent', .5, 'no on-chain score supplied', .2)
    return _finding('OnChainAgent', (float(value)+1)/2, 'on-chain flow context', .4)
