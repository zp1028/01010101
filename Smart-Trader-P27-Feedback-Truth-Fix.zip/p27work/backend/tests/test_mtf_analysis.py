import pytest
from app.services.mtf_analysis import MTFAnalysisService

@pytest.mark.asyncio
async def test_mtf_contract(monkeypatch):
    async def fake(symbol, market, interval, limit):
        return [{"open":1,"high":2,"low":0.5,"close":1.5,"volume":10,"timestamp":i} for i in range(80)]
    monkeypatch.setattr("app.services.mtf_analysis.fetch_market_klines", fake)
    out = await MTFAnalysisService().build("BTCUSDT", "crypto", "1h", 80)
    assert out["data_contract"] == "mtf-analysis-v1"
    assert out["analysis_only"] is True
    assert out["read_only"] is True
    assert out["current_timeframe"] == "1h"
