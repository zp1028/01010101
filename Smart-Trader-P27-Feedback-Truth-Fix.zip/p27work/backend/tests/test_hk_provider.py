from app.services.hk_provider import HKMarketProvider


def test_hk_provider_requires_both_endpoints(monkeypatch):
    monkeypatch.delenv("SMART_TRADER_HK_UNIVERSE_URL", raising=False)
    monkeypatch.delenv("SMART_TRADER_HK_QUOTE_URL", raising=False)
    p = HKMarketProvider()
    assert p.configured is False
    assert p.status()["analysis_only"] is True
