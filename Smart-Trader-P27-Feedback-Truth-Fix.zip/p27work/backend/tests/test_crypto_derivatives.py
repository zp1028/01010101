import pytest
import httpx
from app.services.crypto_derivatives import BinanceDerivativesService

@pytest.mark.asyncio
async def test_crypto_derivatives_snapshot(monkeypatch):
    class Resp:
        def __init__(self, data): self._data=data
        def raise_for_status(self): pass
        def json(self): return self._data
    async def fake_get(self, url, params=None):
        if url.endswith('/premiumIndex'):
            return Resp({'markPrice':'101','indexPrice':'100','lastFundingRate':'0.001','nextFundingTime':123,'time':456})
        if url.endswith('/openInterest'):
            return Resp({'openInterest':'1234','time':456})
        if url.endswith('/fundingRate'):
            return Resp([{'fundingTime':456,'fundingRate':'0.001','markPrice':'101'}])
        if url.endswith('/globalLongShortAccountRatio'):
            return Resp([{'timestamp':456,'longShortRatio':'1.2','longAccount':'0.55','shortAccount':'0.45'}])
        if url.endswith('/openInterestHist'):
            return Resp([{'timestamp':456,'sumOpenInterest':'1234','sumOpenInterestValue':'99999'}])
        if url.endswith('/takerlongshortRatio'):
            return Resp([{'timestamp':456,'buyVol':'60','sellVol':'40','buySellRatio':'1.5'}])
        return Resp({})
    monkeypatch.setattr(httpx.AsyncClient, 'get', fake_get)
    out = await BinanceDerivativesService().snapshot('BTC/USDT')
    assert out['available'] is True
    assert out['capabilities']['funding_rate'] is True
    assert out['capabilities']['open_interest'] is True
    assert out['long_short']['latest']['longShortRatio'] == 1.2
