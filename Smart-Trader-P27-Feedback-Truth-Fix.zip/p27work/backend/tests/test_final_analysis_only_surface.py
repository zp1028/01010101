from app.main import app


def test_public_api_has_no_execution_or_account_surface():
    paths = {getattr(r, 'path', '') for r in app.routes}
    assert '/api/v1/risk/account' not in paths
    assert '/api/v1/portfolio/risk' not in paths
    assert '/api/v1/replay' not in paths
    assert '/api/v1/backtests' not in paths
    assert '/api/v1/advice/{instrument_key}' in paths


def test_market_capability_contract_is_read_only():
    paths = {getattr(r, 'path', '') for r in app.routes}
    assert '/api/v1/market-capabilities' in paths
    assert '/api/v1/market-capabilities/{market}' in paths
