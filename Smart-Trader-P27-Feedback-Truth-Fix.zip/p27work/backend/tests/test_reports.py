import pytest
from app.services.report_registry import REGISTRY, SCENES, catalog
from app.services.report_orchestrator import ReportOrchestrator

def test_report_registry_has_32_reports():
    assert len(REGISTRY) == 32
    assert set(SCENES) >= {"pre_market", "intraday", "post_market", "deep_research", "event_driven", "all"}
    assert catalog()["count"] == 32

def test_report_definitions_are_unique():
    ids = [x.id for x in REGISTRY.values()]
    assert ids == list(range(1, 33))
    assert len(set(REGISTRY)) == 32

def test_scene_contains_expected_report_ids():
    o = ReportOrchestrator()
    scene = o.scene("intraday")
    assert scene["report_ids"] == [1, 10, 9, 21, 32]


@pytest.mark.asyncio
async def test_instrument_detail_is_scoped_to_symbol_market_timeframe(monkeypatch):
    from app.services.report_orchestrator import ReportOrchestrator

    async def fake_build(self, symbol, market, timeframe, limit):
        return {
            "symbol": symbol, "generated_at": "2026-09-22T00:00:00Z",
            "data_quality": {"score": 1.0},
            "evidence": {"data_timestamp": "2026-09-22T00:00:00Z"},
            "summary": "exact instrument", "scenario_analysis": {},
            "disclaimer": "analysis only",
        }

    monkeypatch.setattr(
        "app.services.report_orchestrator.UnifiedAnalysisReportService.build",
        fake_build,
    )
    monkeypatch.setattr(
        "app.services.report_orchestrator.MarketDataStatusService.snapshot",
        lambda self: {"providers": {"us": {"configured": True}}},
    )
    result = await ReportOrchestrator().instrument_detail("AAPL", "us", "1h")
    assert result["instrument"] == {"symbol": "AAPL", "market": "us", "timeframe": "1h"}
    assert result["analysis_only"] is True
    assert result["report_manifest"]["report_count"] == 32
