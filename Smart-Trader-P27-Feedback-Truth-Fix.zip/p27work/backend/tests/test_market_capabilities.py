import os
from app.services.market_capabilities import MarketCapabilityService

def test_capability_matrix_truthful(monkeypatch):
    monkeypatch.delenv("SMART_TRADER_HK_UNIVERSE_URL", raising=False)
    monkeypatch.delenv("SMART_TRADER_HK_QUOTE_URL", raising=False)
    monkeypatch.delenv("SMART_TRADER_US_QUOTE_URL", raising=False)
    data = MarketCapabilityService().snapshot()
    assert data["analysis_only"] is True
    assert data["markets"]["crypto"]["funding"] is True
    assert data["markets"]["us"]["quote"] is False
    assert data["markets"]["hk"]["status"] == "provider_required"

def test_capability_configured(monkeypatch):
    monkeypatch.setenv("SMART_TRADER_US_QUOTE_URL", "https://example.invalid/quote")
    monkeypatch.setenv("SMART_TRADER_HK_UNIVERSE_URL", "https://example.invalid/u")
    monkeypatch.setenv("SMART_TRADER_HK_QUOTE_URL", "https://example.invalid/q")
    data = MarketCapabilityService().snapshot()
    assert data["markets"]["us"]["status"] == "available"
    assert data["markets"]["hk"]["realtime"] is True
