import pytest
from app.services.instrument_snapshot import InstrumentSnapshotService

@pytest.mark.asyncio
async def test_hk_is_explicitly_unavailable_without_provider():
    r = await InstrumentSnapshotService().snapshot('0700.HK','hk','1h')
    assert r['available'] is False
    assert 'provider' in r

@pytest.mark.asyncio
async def test_unsupported_market_is_not_fabricated():
    r = await InstrumentSnapshotService().snapshot('X','unknown','1h')
    assert r['available'] is False
