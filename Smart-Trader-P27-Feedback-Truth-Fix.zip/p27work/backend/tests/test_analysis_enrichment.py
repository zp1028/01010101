import pytest
from app.services.unified_analysis_report import UnifiedAnalysisReportService

@pytest.mark.asyncio
async def test_unified_report_contains_market_enrichment(monkeypatch):
    svc = UnifiedAnalysisReportService()
    async def fake_human(*a, **k):
        return {"symbol":"BTCUSDT","generated_at":123,"summary":"ok","data_quality":{}}
    async def fake_bars(*a, **k):
        return [{"open":1,"high":2,"low":0.5,"close":1.5,"volume":10,"timestamp":i} for i in range(40)]
    async def fake_enrich(*a, **k):
        return {"market":"crypto","available":True,"multi_exchange":{"available_provider_count":3},"analysis_only":True}
    monkeypatch.setattr(svc.human,'build',fake_human)
    monkeypatch.setattr('app.services.unified_analysis_report.fetch_market_klines',fake_bars)
    monkeypatch.setattr(svc.enrichment,'enrich',fake_enrich)
    r=await svc.build('BTCUSDT','crypto','1h',40)
    assert r['analysis_version']=='P17-unified-enriched-v2'
    assert r['evidence']['market_enrichment']['multi_exchange']['available_provider_count']==3
    assert r['evidence']['closed_candle_confirmation_required'] is True
