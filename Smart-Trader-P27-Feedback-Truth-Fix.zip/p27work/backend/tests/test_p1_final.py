from app.ai.guard import PostAIGuard
from app.account import AccountSnapshot, AccountPosition, reconcile
from app.ai.agents.contextual import analyze_news, analyze_macro, analyze_onchain

def test_post_ai_guard_blocks_low_quality():
    r=PostAIGuard().evaluate(confidence=.8,data_quality=.2)
    assert not r.allowed and 'insufficient data quality' in r.reasons

def test_contextual_agents_are_deterministic():
    f={'news_sentiment':.8,'macro_score':-.4,'onchain_score':.2}
    assert analyze_news(f).stance=='bullish'
    assert analyze_macro(f).stance=='bearish'
    assert analyze_onchain(f).stance=='bullish'

def test_account_reconciliation():
    a=AccountSnapshot(provider='local',observed_at=1,equity=100,available_balance=80,positions=[AccountPosition(symbol='BTC',quantity=1,mark_price=100)])
    b=AccountSnapshot(provider='remote',observed_at=2,equity=100,available_balance=80,positions=[AccountPosition(symbol='BTC',quantity=1.1,mark_price=100)])
    r=reconcile(a,b)
    assert not r.matched and r.mismatched==['BTC']
