from app.services.us_fundamentals import UsFundamentalsService


def test_resolve_ticker(monkeypatch):
    s = UsFundamentalsService()
    monkeypatch.setattr(s, "ticker_map", lambda: {"ABC": {"cik": "123", "name": "Example Corp"}})
    assert s.resolve("abc")["cik"] == "123"


def test_latest_derives_margins_and_fcf(monkeypatch):
    s = UsFundamentalsService()
    monkeypatch.setattr(s, "resolve", lambda ticker: {"ticker": "ABC", "cik": "123", "name": "Example Corp"})
    raw = {"entityName": "Example Corp", "facts": {"us-gaap": {
        "RevenueFromContractWithCustomerExcludingAssessedTax": {"units": {"USD": [{"val": 1000, "end": "2025-12-31", "filed": "2026-02-01", "form": "10-K"}]}},
        "GrossProfit": {"units": {"USD": [{"val": 400, "end": "2025-12-31", "filed": "2026-02-01", "form": "10-K"}]}},
        "OperatingIncomeLoss": {"units": {"USD": [{"val": 200, "end": "2025-12-31", "filed": "2026-02-01", "form": "10-K"}]}},
        "NetIncomeLoss": {"units": {"USD": [{"val": 100, "end": "2025-12-31", "filed": "2026-02-01", "form": "10-K"}]}},
        "StockholdersEquity": {"units": {"USD": [{"val": 500, "end": "2025-12-31", "filed": "2026-02-01", "form": "10-K"}]}},
        "NetCashProvidedByUsedInOperatingActivities": {"units": {"USD": [{"val": 150, "end": "2025-12-31", "filed": "2026-02-01", "form": "10-K"}]}},
        "PaymentsToAcquirePropertyPlantAndEquipment": {"units": {"USD": [{"val": 50, "end": "2025-12-31", "filed": "2026-02-01", "form": "10-K"}]}},
    }}}
    monkeypatch.setattr(s, "company_facts", lambda cik: raw)
    out = s.latest("ABC")
    assert out["derived"]["gross_margin"] == 0.4
    assert out["derived"]["operating_margin"] == 0.2
    assert out["derived"]["roe"] == 0.2
    assert out["derived"]["free_cash_flow"] == 100
