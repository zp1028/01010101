from app.services.us_valuation import UsValuationService

class FakeFund:
    def latest(self, ticker):
        return {"ticker": ticker.upper(), "facts": {
            "shares_diluted": {"val": 10}, "equity": {"val": 100},
            "revenue": {"val": 200}, "net_income": {"val": 20},
            "liabilities": {"val": 50}, "cash": {"val": 10},
        }}

def test_valuation_requires_price():
    out = UsValuationService(FakeFund()).build("ABC", None)
    assert out["market_cap"] is None
    assert out["availability"]["pe"] is False

def test_valuation_derives_multiples():
    out = UsValuationService(FakeFund()).build("ABC", 15.0, "2026-09-22T00:00:00Z")
    assert out["market_cap"] == 150
    assert out["pe"] == 7.5
    assert out["pb"] == 1.5
    assert out["ps"] == 0.75
    assert out["enterprise_value"] == 190
