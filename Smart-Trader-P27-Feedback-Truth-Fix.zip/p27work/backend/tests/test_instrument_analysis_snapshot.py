import asyncio

from app.services.instrument_analysis_snapshot import InstrumentAnalysisSnapshotService


def test_service_is_read_only_contract(monkeypatch):
    service = InstrumentAnalysisSnapshotService()

    async def snap(symbol, market, timeframe):
        return {"symbol": symbol, "market": market, "timeframe": timeframe, "available": True}

    async def caps(market):
        return {"market": market, "analysis_only": True}

    async def report(symbol, market, timeframe, limit):
        return {"symbol": symbol, "market": market, "timeframe": timeframe, "scenario_analysis": {}}

    monkeypatch.setattr(service.snapshot_service, "snapshot", snap)
    monkeypatch.setattr(service.capability_service, "get", caps)
    monkeypatch.setattr(service.report_service, "build", report)

    out = asyncio.run(service.build("BTCUSDT", "crypto", "1h", 100))
    assert out["analysis_only"] is True
    assert out["read_only"] is True
    assert out["data_contract"] == "instrument-analysis-v1"
    assert out["analysis"]["symbol"] == "BTCUSDT"
