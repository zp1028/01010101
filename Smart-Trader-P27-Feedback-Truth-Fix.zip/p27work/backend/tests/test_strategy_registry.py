from app.quant.features.engine import FeatureSnapshot
from app.quant.strategies import default_registry


def snap(**features):
    return FeatureSnapshot("binance:BTCUSDT", "BTCUSDT", "1m", 100, 100, features, 100)


def test_registry_is_versioned_and_parameterized():
    r = default_registry()
    s = r.get("rsi")
    assert s.key == "rsi@1.0.0"
    out = r.evaluate("rsi", snap(rsi_14=20))
    assert out[0]["direction"] == "long"
    out = r.evaluate("rsi", snap(rsi_14=80), {"high": 75})
    assert out[0]["direction"] == "short"


def test_registry_returns_empty_when_rule_not_triggered():
    r = default_registry()
    assert r.evaluate("rsi", snap(rsi_14=50)) == []
