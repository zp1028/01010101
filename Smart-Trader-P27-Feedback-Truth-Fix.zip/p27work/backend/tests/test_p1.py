from app.quant.regime.engine import RegimeEngine
from app.portfolio.risk import PortfolioRiskEngine, PositionRisk
from app.alerts.engine import AlertEngine
from app.ai.agents.research import analyze_money_flow, analyze_sentiment, debate, AgentFinding

def test_regime():
    r=RegimeEngine().classify({'adx_14':35,'atr_pct':3,'volume_ratio':1.5})
    assert r.name=='trending' and r.confidence>0

def test_portfolio_risk():
    r=PortfolioRiskEngine().evaluate(10000,[PositionRisk('BTC',7000),PositionRisk('ETH',1000)])
    assert r.concentration>.5 and 'single-position concentration exceeds 50%' in r.warnings

def test_alert_once():
    e=AlertEngine(); e.add('BTC','price','gt',100)
    assert len(e.evaluate('BTC','price',101))==1
    assert len(e.evaluate('BTC','price',101))==0

def test_debate():
    m=analyze_money_flow({'volume_ratio':2,'obv_slope':1})
    s=analyze_sentiment({'sentiment_score':.5})
    d=debate(AgentFinding('TechnicalAgent','bullish',.8,.8,[]),m,s)
    assert d.stance=='bullish'
