from pathlib import Path

from app.services.analysis_feedback import AnalysisFeedbackService


def test_feedback_evaluation_long_and_short(tmp_path: Path):
    svc = AnalysisFeedbackService(str(tmp_path / "feedback.json"))
    long_r = {"price_at_report": 100.0, "direction": "long"}
    assert svc._evaluate(long_r, 102.0)[0] == "validated"
    assert svc._evaluate(long_r, 98.0)[0] == "invalidated"
    short_r = {"price_at_report": 100.0, "direction": "short"}
    assert svc._evaluate(short_r, 98.0)[0] == "validated"
    assert svc._evaluate(short_r, 102.0)[0] == "invalidated"


def test_report_ids_are_immutable_and_feedback_persists(tmp_path: Path):
    svc = AnalysisFeedbackService(str(tmp_path / "feedback.json"))
    snapshot = {
        "report_id": "R-TEST", "key": "crypto:BTC/USDT:15m", "symbol": "BTC/USDT",
        "market": "crypto", "timeframe": "15m", "generated_at": 1,
        "price_at_report": 100.0, "direction": "long", "confidence": .8,
        "state": "tracking", "summary": "test", "narrative": "",
        "feedback": {"state": "waiting", "summary": "waiting", "evaluated_at": 1},
    }
    svc._reports[snapshot["report_id"]] = snapshot
    out = svc.feedback_for("BTC/USDT", "crypto", "15m", 102.0)
    assert out["history"][0]["report_id"] == "R-TEST"
    assert out["history"][0]["feedback_state"] == "validated"
    assert svc._reports["R-TEST"]["summary"] == "test"

import asyncio


def test_feed_uses_fresh_price_not_frozen_report_price(tmp_path: Path):
    svc = AnalysisFeedbackService(str(tmp_path / "feedback.json"))

    async def fake_capture(symbol, market, timeframe, limit=250):
        return {
            "report_id": "R-FRESH", "symbol": symbol, "market": market, "timeframe": timeframe,
            "generated_at": 1000, "price_at_report": 100.0, "direction": "long",
            "confidence": .8, "state": "tracking", "summary": "test",
        }

    async def fake_current_price(symbol, market, timeframe, limit=250):
        return 102.0

    svc.capture = fake_capture
    svc.current_price = fake_current_price
    svc._reports["R-FRESH"] = awaitable_snapshot = {
        "report_id": "R-FRESH", "key": "crypto:BTC/USDT:15m", "symbol": "BTC/USDT",
        "market": "crypto", "timeframe": "15m", "generated_at": 1000,
        "price_at_report": 100.0, "direction": "long", "confidence": .8,
        "state": "tracking", "summary": "test",
    }
    out = asyncio.run(svc.feed("crypto", "15m", ["BTC/USDT"], 1))
    assert out["items"][0]["feedback_state"] == "validated"
    assert out["items"][0]["feedback_summary"].find("2.00%") >= 0
