import asyncio

from app.services import analysis_report


def _bars(n=220):
    out=[]
    price=100.0
    for i in range(n):
        price += 0.08 if i % 7 else -0.03
        out.append({
            "open_time": i*60000,
            "close_time": i*60000+59999,
            "open": price-0.2,
            "high": price+0.5,
            "low": price-0.5,
            "close": price,
            "volume": 1000+i,
        })
    return out


def test_human_report_has_change_section(monkeypatch):
    async def fake_fetch(*args, **kwargs):
        return _bars()
    monkeypatch.setattr(analysis_report, "fetch_market_klines", fake_fetch)
    service = analysis_report.HumanAnalysisReportService()
    first = asyncio.run(service.build("BTCUSDT", "crypto", "15m"))
    second = asyncio.run(service.build("BTCUSDT", "crypto", "15m"))
    assert first["realtime"]["is_live_snapshot"] is True
    assert "interpretation" in first["overbought"]
    assert second["change"]["available"] is True


def test_analysis_only_unified_report_contract():
    from app.services.market_data_status import MarketDataStatusService
    s = MarketDataStatusService().snapshot()
    assert s["analysis_only"] is True
    assert "crypto" in s["providers"]
    assert "hk" in s["providers"]
