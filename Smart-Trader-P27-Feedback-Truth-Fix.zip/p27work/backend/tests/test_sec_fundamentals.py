from app.services.sec_fundamentals import SecFundamentalsService


def test_sec_latest_extracts_common_facts(monkeypatch):
    raw = {
        "entityName": "Example Corp",
        "facts": {"us-gaap": {
            "RevenueFromContractWithCustomerExcludingAssessedTax": {"units": {"USD": [{"val": 100, "end": "2025-12-31", "filed": "2026-02-01", "form": "10-K"}]}},
            "NetIncomeLoss": {"units": {"USD": [{"val": 20, "end": "2025-12-31", "filed": "2026-02-01", "form": "10-K"}]}},
        }}
    }
    monkeypatch.setattr(SecFundamentalsService, "company_facts", lambda self, cik: raw)
    out = SecFundamentalsService().latest("123")
    assert out["company"] == "Example Corp"
    assert out["facts"]["revenue"]["value"] == 100
    assert out["facts"]["net_income"]["value"] == 20
