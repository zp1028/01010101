import pytest
from app.services.crypto_multi_exchange import CryptoMultiExchangeService


def test_normalize():
    assert CryptoMultiExchangeService.normalize('BTC/USDT') == 'BTCUSDT'
    assert CryptoMultiExchangeService._okx_inst('BTCUSDT') == 'BTC-USDT-SWAP'

@pytest.mark.asyncio
async def test_aggregation_shape(monkeypatch):
    svc=CryptoMultiExchangeService()
    async def b(*a,**k): return {'provider':'binance','available':True,'mark_price':100.0,'index_price':99.0,'funding_rate':0.001,'open_interest':10}
    async def o(*a,**k): return {'provider':'okx','available':True,'mark_price':101.0,'index_price':100.0,'funding_rate':0.002,'open_interest':12}
    async def y(*a,**k): return {'provider':'bybit','available':True,'mark_price':99.0,'index_price':98.0,'funding_rate':0.0,'open_interest':8}
    monkeypatch.setattr(svc,'_binance',b); monkeypatch.setattr(svc,'_okx',o); monkeypatch.setattr(svc,'_bybit',y)
    r=await svc.snapshot('BTC/USDT')
    assert r['available_provider_count']==3
    assert r['consensus']['funding_rate_mean']==pytest.approx(0.001)
    assert r['divergence']['mark_price_spread_pct'] > 0
    assert r['analysis_only'] is True
