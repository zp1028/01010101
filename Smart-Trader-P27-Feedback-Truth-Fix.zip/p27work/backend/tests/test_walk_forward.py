from app.backtest.models import BacktestConfig
from app.backtest.walk_forward import run_walk_forward, split_bars


def bars(n=120):
    out=[]
    price=100.0
    for i in range(n):
        price += 0.2 if i % 7 else -0.8
        out.append({"open":price-0.1,"high":price+0.4,"low":price-0.4,"close":price,"volume":100+i,"open_time":i*60000,"close_time":(i+1)*60000})
    return out


def test_split_is_chronological():
    a,b,c=split_bars(bars())
    assert a[-1]["close_time"] < b[0]["close_time"] < c[0]["close_time"]


def test_walk_forward_uses_oos():
    cfg=BacktestConfig(instrument_id="x",symbol="BTCUSDT",bars=bars(),strategy="rsi")
    result=run_walk_forward(cfg)
    assert result["method"] == "train_validate_oos"
    assert result["splits"]["oos_bars"] > 0
    assert result["strategy_params_selected"]
    assert "oos" in result and "optimization" in result
