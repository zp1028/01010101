## P11.2 — Per-Instrument Detail Snapshot

- Added exact `symbol + market + timeframe` report manifest/detail endpoint.
- Added per-instrument report availability states to Android.
- Report catalog on detail page is now bound to the selected instrument instead of global-only status.
- Added coverage counts for available / provider-pending / unavailable reports.
- Preserved analysis-only behavior: report bodies are lazy-loaded and no execution/order/account APIs were introduced.

# CHANGELOG

## P0-02 — 2026-09-22
- Integrated real Android market WebSocket consumption.
- Added reconnect/backoff behavior.
- Preserved backend-only exchange connectivity.
- Fixed PaperExecutionEngine market tick subscription lifecycle.
- Backend: 37 tests passing.
- Android build not executed successfully because Gradle 8.9 distribution download was unavailable in the current environment.

## P0-03 — 2026-09-22 — Persistent Candle Cache & Recovery
- Added persistent `candles` OHLCV table with unique `(instrument_id, timeframe, open_time)` key.
- Added `CandleRepository` for closed-WebSocket candle persistence and REST upsert.
- Added `CandleRecoveryService` to detect WebSocket candle gaps and backfill missing bars from Binance REST.
- Added cold-start bootstrap for 1m/5m/15m/1h/4h/1d caches.
- Added `GET /api/v1/candles/{symbol}` for cached candle retrieval.
- Added Android `MarketCache` using SharedPreferences so last known prices/attention survive process restarts and can be displayed offline.
- Backend verification: `37 passed`.
- Android APK build remains unverified in this environment because Gradle 8.9 distribution download is unavailable.

## P0-04 — 2026-09-22 — Feature/Snapshot Pipeline Hardening
- Added explicit `FeatureSnapshotEvent` between Feature Engine and Signal Engine.
- Removed the CandleEvent race where Signal Engine could run before Feature Engine because EventBus dispatches handlers concurrently.
- Added persistent FeatureSnapshot and Signal repositories.
- Added unique PIT feature key `(instrument_id, timeframe, available_at)` for idempotent feature storage.
- Added `signals` table with source timestamp and generated timestamp indexes.
- Added `feature.updated` downstream WebSocket event for Android/realtime clients.
- Feature snapshots remain PIT-safe: `available_at` is the closed candle time.
- Backend verification: `37 passed`.

## P0-05 Strategy Registry
- Replaced hard-coded SignalEngine rules with versioned StrategyRegistry.
- Added RSI/MACD/Bollinger/Volume strategy definitions with runtime parameter overrides.
- Added strategy discovery API endpoints.
- Added registry tests; backend test suite now 39 passed.

## P0-06 — Unified Backtest Core
- Fast/vectorized backtest now routes strategy evaluation through `StrategyRegistry` instead of maintaining a separate hard-coded RSI/MACD/Bollinger rule set.
- Event-driven backtest now evaluates the configured versioned strategy through the same registry.
- Legacy strategy aliases (`bb`) remain compatible.
- Added causal feature snapshots for each bar with no future-bar access when PIT is enabled.
- Added profit factor, gross profit/loss, expectancy, net PnL and Sharpe-style metrics.
- Backtest result records strategy id/version/parameters.
- Backtest API accepts registered strategy identifiers rather than a closed Literal list.
- PIT mode sorts bars chronologically before simulation; disabled PIT emits a warning.
- Existing test suite: 39 passed.

## P0-07 — Walk-Forward + Parameter Optimization
- Added deterministic train/validation/OOS walk-forward engine.
- Added strategy-specific parameter candidate grids and custom API candidates.
- Optimization is fit only on the training segment; validation and OOS are untouched by fitting.
- Added parameter stability and low-OOS-sample warnings.
- Added chronological PIT sorting and ratio validation.
- Extended backtest API with train_ratio, validation_ratio, and parameter_candidates.
- Preserved legacy `results` response field for compatibility.
- Backend tests: 41 passed.

## P0-14 — 2026-09-22 — AI Persistence + Historical Replay
- Persisted structured AIAnalysis with evidence, PIT availability and trigger metadata.
- Added AnalysisRepository with bounded historical retrieval.
- Added replay snapshot storage using the existing PIT Feature/Signal/AI contracts.
- Added `POST /api/v1/replay` and `GET /api/v1/replay/{snapshot_id}`.
- Replay rejects future feature/signal/AI state relative to the requested analysis timestamp.

## P0-15 — 2026-09-22 — Production Convergence
- Consolidated the P0 architecture around Provider → EventBus → Feature → Strategy → Risk → Paper Execution → AI/Replay.
- Verified backend test suite from the backend working directory: 41 passed.
- Android release/debug build remains an external CI verification step because the current sandbox cannot download Gradle distributions.

## P1-01 ~ P1-05 — Multi-market / Regime / Multi-agent foundation
- Added market-provider contracts and priority-based provider registry.
- Added market-regime classifier for trending/ranging/high-volatility/low-liquidity states.
- Added Money Flow, Sentiment and Debate research agents with structured findings.
- Extended AI orchestrator to combine independent findings and regime context into evidence-backed AnalysisResult.
- Added portfolio-level exposure/concentration/drawdown risk engine.
- Added observation/alert engine for price/indicator/composite-style nodes.
- Added P1 API endpoints for portfolio risk, provider health, and alert management.
- Backend validation: 45 tests passed; compileall passed.

## P1 Final — 2026-09-22
- Added contextual News/Macro/OnChain agents.
- Added deterministic Post-AI Guard between analysis and action candidates.
- Added account snapshot/reconciliation primitives.
- Fixed Replay to select persisted PIT feature/signal/AI records at or before the requested analysis timestamp instead of current in-memory state.
- Added P1 final completion documentation.
- Backend verification: 48 passed.

## P5 — Full-Market Human Analysis / 2026-09-22
- Added unified non-crypto OHLCV adapter for US/HK/commodities.
- Added extended indicators: Stoch RSI, VWAP, ADL, CMF, DMI, PSAR, Donchian, Keltner, Ultimate Oscillator.
- Added market structure, support/resistance, RSI divergence candidate detection.
- Added human-readable overbought/oversold interpretation and trend-strength explanation.
- Added `market` parameter to indicator, MTF and advice APIs.
- Android detail now displays a complete indicator block, structure explanation and divergence.
- Android supports 1m through 1w timeframe selection.
- Removed backtest/replay API routes from the analysis-only product surface; research source remains in repository.
- Backend validation: 48 tests passed; Python compileall passed; main import passed.
- Android Gradle compile could not be executed because the environment cannot resolve services.gradle.org for Gradle 8.9.

## P8 — Unified market-analysis hardening
- Added explicit provider capability/status endpoint.
- Added paginated/sorted market-universe API.
- Added one unified report contract combining human-readable analysis, technical evidence, long/short scenarios and holding observation.
- Preserved analysis-only product boundary; no execution/account features exposed.
- Added coverage truth rules so missing HK/quote feeds are reported instead of mocked.

## P9 — 32 类报告引擎与场景编排
- 新增 `ReportRegistry`：32 类报告统一 ID/key/domain/priority/update/source requirements。
- 新增 `ReportOrchestrator`：统一调用分析证据，缺少专用数据源时明确返回 unavailable/pending_provider，不生成伪数据。
- 新增报告目录 API、场景 API、单报告 API。
- 场景：盘前、盘中、盘后、深度研究、事件驱动、全部报告。
- 多周期报告扩展到 5m/15m/30m/1h/4h/1d/1w。
- API 版本提升到 1.0.4。

## P10 — Android报告接入准备 + 美股SEC基本面适配
- 新增只读 SEC XBRL fundamentals adapter 与 `/api/v1/fundamentals/us/{cik}`。
- 保持分析-only：不涉及账户、下单、交易执行。
- SEC 基本面缺失时不生成伪数据。

## P11 — US Fundamentals / Ticker Discovery
- Added SEC ticker→CIK discovery using the public company ticker mapping.
- Added `/api/v1/fundamentals/us/ticker/{ticker}` for ticker-based fundamentals.
- Added SEC-derived gross margin, operating margin, net margin, ROE and FCF when source facts are available.
- Added filing freshness and explicit availability flags; no PE/PB/PS/EV-EBITDA values are fabricated without synchronized market data.
- Kept fundamentals read-only and analysis-only.
- Removed legacy paper-execution/order API modules from the release source to enforce analysis-only product scope. Historical backtest research remains separate and read-only.

## P11.1 — Per-instrument report binding
- 每一个市场品种点击详情页后均绑定独立 `symbol + market + timeframe` 分析上下文。
- 新增 `/api/v1/reports/instrument/{symbol}`，返回该具体品种的完整 32 类报告清单及逐项数据可用状态。
- 报告状态严格按该品种实际数据能力计算，不使用全局假状态或伪造报告内容。
- Android 从市场卡片点击详情时同步传递 `assetClass/market`，避免跨市场同名代码使用错误的数据源。

## P13 — Instrument Data Snapshot / Provider Completion
- Added read-only per-instrument snapshot endpoint: `/api/v1/instrument/{market}/{symbol}/snapshot`.
- Added provider-backed US/commodity chart snapshots and Binance crypto quote/K-line snapshots.
- HK remains explicitly provider-configured; no fabricated quote data is returned.
- Snapshot is keyed by symbol + market + timeframe and is analysis-only.
- API version 1.3.0.

## P14 - Crypto Derivatives Market Analytics

- Added read-only Binance USD-M derivatives adapter.
- Added funding-rate history and current funding context.
- Added open-interest snapshot/history.
- Added mark/index price context.
- Added long/short account ratio history.
- Added taker long/short flow history.
- Added basis history when the provider returns it.
- Added public liquidation/force-order observations when available.
- Bound derivatives data to the same `symbol + market + timeframe` instrument context.
- Instrument snapshots now include derivatives context for crypto instruments.
- Added `/api/v1/derivatives/crypto/{symbol}`.
- No API keys, account endpoints, order endpoints, or execution logic are used.
- Test suite: 59 passed.

## P15 — Market Capability Matrix + US Valuation
- Added machine-readable `/api/v1/market-capabilities` capability matrix.
- Added truthful per-market availability/status, including configured-provider requirements for US quotes, HK feeds and commodity futures feeds.
- Added configurable commodity futures universe via `SMART_TRADER_COMMODITY_UNIVERSE_URL`, retaining a clearly labeled curated fallback when absent.
- Added read-only `/api/v1/valuation/us/{ticker}` deriving market cap, PE, PB, PS, EV and EV/Sales only when synchronized quote + SEC facts are available.
- No valuation multiple is fabricated when price, shares or financial facts are unavailable.
- API version 1.4.0.

## P16 — Crypto multi-exchange aggregation
- Added read-only Binance/OKX/Bybit public derivatives aggregation.
- Added `/api/v1/crypto/{symbol}/multi-exchange` with provider-level availability, mean consensus and divergence metrics.
- No account credentials, order endpoints, or execution actions are used.
- Provider failures remain isolated; unavailable data is not replaced with fabricated zero values.
- API version advanced to 1.5.0.

## P17 — Unified Market Analysis Enrichment
- UnifiedAnalysisReportService now incorporates read-only crypto multi-exchange and derivatives evidence.
- Added `AnalysisEnrichmentService` with graceful provider failure handling.
- Unified evidence now distinguishes live/intrabar context from confirmed closed-candle context.
- Analysis version advanced to `P17-unified-enriched-v2`.
- No account, order, execution, or trading connection was added.

## P18 — Analysis-only final hardening + unified instrument contract
- Added `instrument_analysis_snapshot` read-only endpoint combining snapshot, capability truth, and unified analysis for one instrument/timeframe.
- Removed the mutable `/api/v1/risk/account` router from the public FastAPI surface; risk calculations remain internal analysis components and no account state is exposed through the API.
- Kept execution/paper/replay routes out of the public app surface.
- Bumped API version to 1.6.0.
- Added regression coverage for the unified read-only instrument contract.
- Android detail now consumes the unified instrument-analysis contract and displays per-instrument provider/capability status.
- Android source update was syntax-integrated, but Gradle/Kotlin compilation was not completed in this offline environment because Gradle 8.9 was not cached and `services.gradle.org` was unreachable.

## P19 · Final analysis-engine hardening · 2026-09-22
- Added `backend/app/services/mtf_analysis.py` with a single read-only `mtf-analysis-v1` contract for 5m/15m/30m/1h/4h/1d/1w independent recalculation.
- Added `GET /api/v1/analysis/{symbol}/multi-timeframe` and explicit closed-candle confirmation semantics.
- Expanded 32-report orchestration so realtime, probability, holding-risk, MTF, divergence/pattern/volume/volatility and market-enrichment reports expose their actual evidence rather than one generic template payload.
- Kept analysis-only public surface: no public order, execution, account, paper-trading, replay or backtest route is registered in `main.py`.
- Backend validation: 68 pytest tests passed; compileall passed; 48 registered HTTP/WebSocket routes; no sensitive execution/account/backtest/replay route detected in the public application.
- Android Gradle compilation remains environment-blocked because Gradle 8.9 distribution is not cached and the current build environment cannot resolve `services.gradle.org`; no APK success is claimed.

## P20 — TradingView / Binance 风格市场与品种详情 UI
- 市场首页重构为四大市场分类：加密、美股、港股、大宗商品。
- 增加品种搜索、涨跌幅/关注度排序、排行/卡片视图切换。
- 加密市场列表接入 Binance 24h ticker，展示真实最新价、24h 涨跌幅与数据源状态；其他市场没有实时源时保持明确不可用状态，不伪造行情。
- 品种详情增加真实后端 K 线读取与 K 线图绘制，支持 5m/15m/30m/1h/4h/1d/1w 周期切换并随周期重新加载。
- 保留统一行情报告、技术指标、AI 多空情景、持仓观察、多周期共振与 32 类报告中心。
- UI 信息密度向 TradingView 的研究/筛选/图表布局与 Binance 的行情列表/实时信息密度靠拢，同时维持本产品“仅分析、不模拟、不下单、不连接交易账户”定位。
- 修复 AppState 重复 private setter 与旧信号模型字段引用问题。
- 后端测试：70 passed；Python compileall 通过。
- Android Debug APK：本环境无法完成 Gradle 编译，因为 Gradle 8.9 wrapper 需要访问 services.gradle.org，而当前构建环境网络不可用；未伪造 APK 构建成功状态。

## P23 — 最终市场研究驾驶舱增强
- Android 详情页接入已有公开加密衍生品 API：Funding、OI、Mark/Index、多空账户比、Taker 流、Basis、最近可用强平观察。
- Android 详情页接入 Binance/OKX/Bybit 只读聚合：可用交易所数量、共识价格、Funding/OI 均值、价格与 Funding 离散度及逐交易所状态。
- 所有衍生品/交易所数据保持 analysis-only，不增加账户、API Key、下单或执行能力。
- 数据不可用时明确显示不可用，不以 0 或假值替代。
