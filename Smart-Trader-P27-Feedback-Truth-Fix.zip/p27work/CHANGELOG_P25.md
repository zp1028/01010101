# Smart Trader P25 — 报告生命周期与行情反馈

## 本轮目标
把首页从“当前行情列表”升级为“当前高置信度分析 + 历史报告反馈”入口，并把同一反馈链同步到每个品种详情页。

## 已完成
- 新增 `analysis_feedback` 服务：冻结历史报告快照，后续行情只产生反馈，不改写历史报告。
- 新增 `/api/v1/analysis-feed`：按市场/周期返回当前高置信度分析条目。
- 新增 `/api/v1/analysis-feedback/{symbol}`：详情页获取该品种、该周期的历史分析反馈。
- 报告反馈状态：等待 / 跟踪 / 阶段验证 / 已失效。
- 当前报告与历史报告通过 `report_id` 关联。
- 后续价格变化相对于报告生成时价格进行评估。
- Android 首页增加“当前高置信度分析”。
- Android 品种详情页增加“历史分析反馈”。
- 周期切换时反馈链按新周期独立计算。
- 修复 P24 包中 `RestClient.kt` 被重复拼接导致的超大文件损坏问题，恢复到干净版本后重新加入分页接口。
- Android 客户端移除 portfolio / order API 调用路径，保持分析-only。
- 保留市场分页与本地自选能力。

## 反馈原则
历史报告：冻结。
新行情：新增反馈。
当前判断：重新生成。
失效：停止继续作为当前高置信度条目展示。

## 验证
- Backend pytest: 72 passed
- Python compileall: PASS
- Android compile: 未完成；当前环境无法访问 services.gradle.org 下载 Gradle 8.9。
