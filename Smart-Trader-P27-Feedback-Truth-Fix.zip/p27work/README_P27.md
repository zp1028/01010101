# Smart Trader P27 — Feedback Loop Truth Fix

P27 is a hardening release on top of P26.

## Key fix
Historical analysis reports are immutable, but feedback evaluation now uses a **fresh market observation** instead of the report's frozen `price_at_report`.

This fixes the previous logical failure where a newly-created report could immediately evaluate itself against its own frozen price and remain `waiting` even after the market had moved.

## Android
- Timeframe switching refreshes the home high-confidence analysis feed.
- Removed unused portfolio/position DTOs from the analysis-only Android network layer.
- Product remains read-only: no account connection, order placement, or execution APIs.

## Verification
- Python compileall: required.
- Backend pytest: required.
- Android full Gradle compile depends on the CI environment's Gradle distribution availability; do not claim APK success unless CI completes `assembleDebug`.
