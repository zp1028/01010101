# Final Static Audit

Date: 2026-09-22

## Public surface
Registered FastAPI routes: 44

Sensitive execution/account routes absent from app registration:
- risk/account
- portfolio/risk
- replay
- backtests
- order
- execute

## Analysis surface
Present:
- markets
- candles
- indicators
- multi-timeframe analysis
- unified report
- instrument analysis snapshot
- derivatives read-only
- market capabilities
- fundamentals
- valuation when synchronized data exists
- reports
- analytical advice GET

## Truthfulness
- HK provider-required state is explicit.
- US realtime quote capability is explicit.
- Commodity fallback is explicitly non-exhaustive.
- Crypto public providers are read-only.

## Tests
70 passed; compileall PASS.
