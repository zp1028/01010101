# P27 Changelog

- Fixed analysis feedback to compare historical reports against a fresh current price.
- Fixed `/analysis-feedback/{symbol}` to use a fresh market observation.
- Fixed home `/analysis-feed` feedback evaluation to use a fresh market observation.
- Added regression test proving a 2% move validates a frozen long report.
- Timeframe switching now refreshes the high-confidence analysis feed.
- Removed unused PortfolioDto/PositionDto from Android read-only client.
