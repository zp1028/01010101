package com.diveintocrypto.android.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Button
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.diveintocrypto.android.AppContainer
import com.diveintocrypto.android.domain.consensus.DEFAULT_F2_WEIGHTS
import com.diveintocrypto.android.domain.consensus.DEFAULT_FULL_WEIGHTS
import com.diveintocrypto.android.platform.AppInfo
import com.diveintocrypto.android.platform.format
import com.diveintocrypto.android.ui.theme.DiveColors
import com.diveintocrypto.android.ui.theme.DiveDims
import com.diveintocrypto.android.ui.theme.DiveFonts
import com.diveintocrypto.android.ui.notifications.rememberNotificationPermission
import com.diveintocrypto.android.platform.rememberBackgroundScanSync

/**
 * Enriched Settings screen (2026-05-24).
 *   1. Analysis settings: consensus confidence thresholds and the ADX regime matrix.
 *   2. Indicator weights: coefficients for RSI, MACD, Bollinger, etc. (+/- stepper).
 *   3. Scanner settings: phase-2 candidate count and concurrent-request limit.
 *   4. Favorite coins: manage the coins listed on the Panel screen (search + add/remove).
 *   5. Theme & About: static version info.
 */
@Composable
fun SettingsScreen(container: AppContainer) {
    val vm: SettingsViewModel = viewModel { SettingsViewModel(container) }
    val state by vm.ui.collectAsStateWithLifecycle()
    val strings = com.diveintocrypto.android.ui.i18n.LocalDiveStrings.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DiveColors.RootBg)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        // 1. Favorite coin management
        FavoritesCard(
            title = strings.setTitleFavorites,
            favorites = state.favorites,
            searchQuery = state.favoriteSearchQuery,
            filteredSymbols = state.filteredSymbols,
            onSearchChange = vm::setFavoriteSearchQuery,
            onAddFavorite = vm::addFavorite,
            onRemoveFavorite = vm::removeFavorite
        )

        // 2. Analysis threshold settings
        ConsensusSettingsCard(
            title = strings.setTitleConsensus,
            confidenceThreshold = state.confidenceThreshold,
            minConfidenceForTrade = state.minConfidenceForTrade,
            enableRegimeMatrix = state.enableRegimeMatrix,
            onConfThresholdChange = vm::updateConfidenceThreshold,
            onTradeThresholdChange = vm::updateMinConfidenceForTrade,
            onToggleRegime = vm::toggleRegimeMatrix
        )

        // AI cloud analysis
        AiSettingsCard(
            enabled = state.aiEnabled,
            baseUrl = state.aiApiBaseUrl,
            model = state.aiModel,
            apiKey = state.aiApiKey,
            onSave = vm::updateAiSettings,
        )

        // 3. Indicator weight coefficients
        WeightsCard(
            title = strings.setTitleWeights,
            weights = state.weights,
            onUpdateWeight = vm::updateIndicatorWeight,
            onResetWeights = {
                // SIFIRLA: restore EVERY indicator (core + extended) to its canonical
                // default from DEFAULT_FULL_WEIGHTS via the existing public VM method.
                DEFAULT_FULL_WEIGHTS.forEach { (key, default) ->
                    vm.updateIndicatorWeight(key, default)
                }
            }
        )

        // 4. Scanner engine settings
        ScanningCard(
            title = strings.setTitleScanner,
            survivors = state.scanSurvivors,
            parallelism = state.scanParallelism,
            onSurvivorsChange = vm::updateScanSurvivors,
            onParallelismChange = vm::updateScanParallelism
        )

        // 4.1 Quantitative chart settings
        QuantitativeChartSettingsCard(
            title = strings.setTitleQuantChart,
            wsDataSource = state.wsDataSource,
            chartCandleCount = state.chartCandleCount,
            onSourceChange = vm::updateWsDataSource,
            onLimitChange = vm::updateChartCandleCount
        )

        NetworkEndpointsCard(
            restBaseUrl = state.restBaseUrl,
            wsBaseUrl = state.wsBaseUrl,
            onSave = vm::updateApiEndpoints,
        )

        // 4.2 Quant Bias weight settings
        QuantBiasSettingsCard(
            title = strings.setTitleQuantBias,
            taker = state.weightTakerLs,
            oi = state.weightOiMomentum,
            whale = state.weightWhaleLs,
            account = state.weightAccountLs,
            onWeightsChange = vm::updateQuantBiasWeights
        )

        // 4.3 Notification permission (API 33+ runtime grant) — Task 2d
        NotificationsCard(title = strings.setTitleNotifications)

        // 4.4 Background scans (WorkManager, opt-in) — honest scheduling card
        val syncBackgroundScans = rememberBackgroundScanSync()
        BackgroundScansCard(
            title = strings.setTitleBackgroundScans,
            enabled = state.backgroundScansEnabled,
            unmeteredOnly = state.backgroundScansUnmetered,
            onToggleEnabled = { enabled ->
                vm.updateBackgroundScans(enabled = enabled)
                syncBackgroundScans()
            },
            onToggleUnmetered = { unmetered ->
                vm.updateBackgroundScans(unmetered = unmetered)
                syncBackgroundScans()
            },
        )

        // 5. Theme, Language & About
        ThemeCard(title = strings.setTitleTheme)
        LanguageCard(container = container)
        AboutCard(title = strings.setTitleAbout)

        Spacer(modifier = Modifier.height(30.dp))
    }
}

/**
 * BACKGROUND SCANS card — opt-in periodic WorkManager scan. Persisting flips
 * [SettingsData.backgroundScansEnabled]/[backgroundScansUnmetered] AND calls
 * the platform sync ([rememberBackgroundScanSync] → WorkManager enqueue/cancel
 * with fresh constraints). The description is deliberately honest: WorkManager's
 * 15-minute minimum + Doze means the OS can and will defer runs.
 */
@Composable
private fun BackgroundScansCard(
    title: String,
    enabled: Boolean,
    unmeteredOnly: Boolean,
    onToggleEnabled: (Boolean) -> Unit,
    onToggleUnmetered: (Boolean) -> Unit,
) {
    val strings = com.diveintocrypto.android.ui.i18n.LocalDiveStrings.current
    SettingsCard(title = title) {        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ToggleRow(
                label = strings.tglBackgroundScan,
                value = enabled,
                onToggle = onToggleEnabled
            )
            Text(
                text = "应用关闭时约每15分钟粗扫一次 · 可能被 Doze 延迟",
                color = DiveColors.TextDim,
                fontSize = 11.sp,
                lineHeight = 15.sp,
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(enabled = enabled) { onToggleUnmetered(!unmeteredOnly) }
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = strings.tglUnmetered,
                        color = if (enabled) DiveColors.Text else DiveColors.TextDim,
                        fontSize = 13.sp,
                    )
                    Text(
                        text = if (enabled) "仅在非计费网络下运行"
                        else "主开关关闭时无效",
                        color = DiveColors.TextDim,
                        fontSize = 10.sp,
                    )
                }
                Box(
                    modifier = Modifier
                        .width(44.dp)
                        .height(24.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (enabled && unmeteredOnly) DiveColors.Accent else DiveColors.BgCardHover)
                        .border(1.dp, DiveColors.Border, RoundedCornerShape(12.dp))
                        .semantics {
                            role = Role.Switch
                            stateDescription = if (enabled && unmeteredOnly) strings.switchOn else strings.switchOff
                        }
                        .clickable(enabled = enabled) { onToggleUnmetered(!unmeteredOnly) }
                        .padding(horizontal = 4.dp),
                    contentAlignment = if (enabled && unmeteredOnly) Alignment.CenterEnd else Alignment.CenterStart,
                ) {
                    Box(
                        modifier = Modifier
                            .width(16.dp)
                            .height(16.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.White)
                    )
                }
            }
            Text(
                text = "结果写入警报历史与扫描缓存；打开应用时从中读取。",
                color = DiveColors.TextDim,
                fontSize = 11.sp,
                lineHeight = 15.sp,
            )
        }
    }
}

@Composable
private fun ConsensusSettingsCard(
    title: String,
    confidenceThreshold: Int,
    minConfidenceForTrade: Int,
    enableRegimeMatrix: Boolean,
    onConfThresholdChange: (Int) -> Unit,
    onTradeThresholdChange: (Int) -> Unit,
    onToggleRegime: (Boolean) -> Unit
) {
    val strings = com.diveintocrypto.android.ui.i18n.LocalDiveStrings.current
    SettingsCard(title = title) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            // Regime Matrix Toggle
            ToggleRow(
                label = strings.tglRegimeMatrix,
                value = enableRegimeMatrix,
                onToggle = onToggleRegime
            )
            Text(
                text = "启用后，将根据趋势强度（ADX）自动优化震荡指标或趋势指标的权重。",
                color = DiveColors.TextMuted,
                fontSize = 11.sp
            )

            Spacer(Modifier.height(4.dp))

            // Consensus Confidence Threshold
            StepperRow(
                label = "最低共识阈值（置信度）",
                value = "$confidenceThreshold%",
                onDecrease = { onConfThresholdChange((confidenceThreshold - 5).coerceAtLeast(10)) },
                onIncrease = { onConfThresholdChange((confidenceThreshold + 5).coerceAtMost(90)) }
            )

            // Min Confidence for Trade
            StepperRow(
                label = "最低交易阈值（交易信号）",
                value = "$minConfidenceForTrade%",
                onDecrease = { onTradeThresholdChange((minConfidenceForTrade - 5).coerceAtLeast(15)) },
                onIncrease = { onTradeThresholdChange((minConfidenceForTrade + 5).coerceAtMost(95)) }
            )
        }
    }
}

/**
 * Indicator weight keys, derived from the engine's canonical maps (never hardcoded):
 *   - CORE (15)      = [DEFAULT_F2_WEIGHTS] keys — the F2 consensus matrix the
 *                      production engine has always applied.
 *   - EXTENDED (42)  = [DEFAULT_FULL_WEIGHTS] keys minus the core set — the
 *                      desktop-reference parity indicators.
 */
private val CORE_WEIGHT_KEYS: List<String> = DEFAULT_F2_WEIGHTS.keys.toList()
private val EXTENDED_WEIGHT_KEYS: List<String> =
    DEFAULT_FULL_WEIGHTS.keys.filter { it !in DEFAULT_F2_WEIGHTS }

@Composable
private fun WeightsCard(
    title: String,
    weights: Map<String, Double>,
    onUpdateWeight: (String, Double) -> Unit,
    onResetWeights: () -> Unit,
) {
    val strings = com.diveintocrypto.android.ui.i18n.LocalDiveStrings.current
    SettingsCard(title = title) {
        // Collapsed by default so first paint composes the 15 core steppers only;
        // expanding adds the 42 extended rows to the (already scrollable) column.
        var extendedOpen by remember { mutableStateOf(false) }
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                text = "各指标对最终共识投票的贡献系数（可用 +/- 以 0.1 步进调整）：",
                color = DiveColors.TextMuted,
                fontSize = 11.sp
            )
            Spacer(Modifier.height(6.dp))

            // ── CORE (15) ─────────────────────────────────────────────
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = "${strings.lblCore} (${CORE_WEIGHT_KEYS.size})",
                    color = DiveColors.TextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp,
                    fontFamily = DiveFonts.body,
                    modifier = Modifier.weight(1f),
                )
                // SIFIRLA — resets ALL indicators (core + extended) to defaults.
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(DiveDims.RadiusSm))
                        .background(DiveColors.RedTint15)
                        .border(1.dp, DiveColors.RedTint25, RoundedCornerShape(DiveDims.RadiusSm))
                        .semantics { role = Role.Button }
                        .clickable(onClick = onResetWeights)
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                ) {
                    Text(
                        text = strings.btnResetWeights,
                        color = DiveColors.Red,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp,
                        fontFamily = DiveFonts.body,
                    )
                }
            }
            CORE_WEIGHT_KEYS.forEach { key ->
                WeightStepperRow(key = key, weights = weights, onUpdateWeight = onUpdateWeight)
            }

            // ── EXTENDED (42) — collapsible ───────────────────────────
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp)
                    .clip(RoundedCornerShape(DiveDims.RadiusSm))
                    .background(DiveColors.BgCardHover)
                    .border(1.dp, DiveColors.Border, RoundedCornerShape(DiveDims.RadiusSm))
                    .semantics {
                        role = Role.Button
                        stateDescription = if (extendedOpen) strings.switchOn else strings.switchOff
                    }
                    .clickable { extendedOpen = !extendedOpen }
                    .padding(horizontal = 12.dp, vertical = 8.dp),
            ) {
                Text(
                    text = if (extendedOpen) "▾ ${strings.lblExtended} (${EXTENDED_WEIGHT_KEYS.size})" else "▸ ${strings.lblExtended} (${EXTENDED_WEIGHT_KEYS.size})",
                    color = DiveColors.Accent,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp,
                    fontFamily = DiveFonts.body,
                )
            }
            if (extendedOpen) {
                Text(
                    text = "与桌面版对齐的扩展指标。降低权重（或设为 0.0）可在共识中静音该指标。",
                    color = DiveColors.TextDim,
                    fontSize = 10.sp,
                )
                EXTENDED_WEIGHT_KEYS.forEach { key ->
                    WeightStepperRow(key = key, weights = weights, onUpdateWeight = onUpdateWeight)
                }
            }
        }
    }
}

/** One indicator weight stepper row (reuse of the shared StepperRow). */
@Composable
private fun WeightStepperRow(
    key: String,
    weights: Map<String, Double>,
    onUpdateWeight: (String, Double) -> Unit,
) {
    val currentWeight = weights[key] ?: 1.0
    val displayName = key.replace("_", " ").uppercase()
    StepperRow(
        label = displayName,
        value = currentWeight.format(1),
        onDecrease = {
            val newVal = (currentWeight - 0.1).coerceAtLeast(0.0)
            onUpdateWeight(key, newVal)
        },
        onIncrease = {
            val newVal = (currentWeight + 0.1).coerceAtMost(5.0)
            onUpdateWeight(key, newVal)
        }
    )
}

@Composable
private fun ScanningCard(
    title: String,
    survivors: Int,
    parallelism: Int,
    onSurvivorsChange: (Int) -> Unit,
    onParallelismChange: (Int) -> Unit
) {
    SettingsCard(title = title) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("阶段2 候选数量（存活）", color = DiveColors.TextMuted, fontSize = 11.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(30, 50, 75).forEach { count ->
                        val active = count == survivors
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (active) DiveColors.Accent else DiveColors.BgCardHover)
                                .border(1.dp, if (active) DiveColors.Accent else DiveColors.Border, RoundedCornerShape(20.dp))
                                .clickable { onSurvivorsChange(count) }
                                .padding(horizontal = 14.dp, vertical = 6.dp),
                        ) {
                            Text(
                                text = count.toString(),
                                color = if (active) Color.White else DiveColors.TextMuted,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("并发请求上限（并行度）", color = DiveColors.TextMuted, fontSize = 11.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(4, 8, 12).forEach { limit ->
                        val active = limit == parallelism
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (active) DiveColors.Accent else DiveColors.BgCardHover)
                                .border(1.dp, if (active) DiveColors.Accent else DiveColors.Border, RoundedCornerShape(20.dp))
                                .clickable { onParallelismChange(limit) }
                                .padding(horizontal = 14.dp, vertical = 6.dp),
                        ) {
                            Text(
                                text = limit.toString(),
                                color = if (active) Color.White else DiveColors.TextMuted,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FavoritesCard(
    title: String,
    favorites: List<String>,
    searchQuery: String,
    filteredSymbols: List<String>,
    onSearchChange: (String) -> Unit,
    onAddFavorite: (String) -> Unit,
    onRemoveFavorite: (String) -> Unit
) {
    SettingsCard(title = title) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = "在面板页管理你的快速访问列表。",
                color = DiveColors.TextMuted,
                fontSize = 11.sp
            )

            if (favorites.isEmpty()) {
                Text("尚未添加收藏币种。", color = DiveColors.TextDim, fontSize = 12.sp)
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    favorites.forEach { symbol ->
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(DiveColors.BgCardHover)
                                .border(1.dp, DiveColors.Border, RoundedCornerShape(20.dp))
                                .padding(start = 12.dp, end = 6.dp, top = 4.dp, bottom = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = symbol,
                                color = DiveColors.Text,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = DiveFonts.body
                            )
                            Spacer(Modifier.width(4.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .clickable { onRemoveFavorite(symbol) }
                                    .padding(4.dp)
                            ) {
                                Text("×", color = DiveColors.Red, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(4.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(DiveColors.BgCardHover)
                    .border(1.dp, DiveColors.Border, RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
            ) {
                if (searchQuery.isEmpty()) {
                    Text("搜索币种加入收藏…", color = DiveColors.TextDim, fontSize = 12.sp)
                }
                BasicTextField(
                    value = searchQuery,
                    onValueChange = onSearchChange,
                    singleLine = true,
                    textStyle = TextStyle(color = DiveColors.Text, fontSize = 13.sp, fontFamily = DiveFonts.body),
                    cursorBrush = SolidColor(DiveColors.Accent),
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            if (searchQuery.isNotEmpty()) {
                if (filteredSymbols.isEmpty()) {
                    Text("未找到匹配币种。", color = DiveColors.TextMuted, fontSize = 11.sp)
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        filteredSymbols.take(4).forEach { symbol ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .clickable { onAddFavorite(symbol) }
                                    .padding(vertical = 6.dp, horizontal = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = symbol,
                                    color = DiveColors.Text,
                                    fontSize = 12.sp,
                                    fontFamily = DiveFonts.body
                                )
                                Text("+ Add", color = DiveColors.Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ToggleRow(label: String, value: Boolean, onToggle: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onToggle(!value) }
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = DiveColors.Text, fontSize = 13.sp)
        Box(
            modifier = Modifier
                .width(44.dp)
                .height(24.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(if (value) DiveColors.Accent else DiveColors.BgCardHover)
                .border(1.dp, DiveColors.Border, RoundedCornerShape(12.dp))
                .padding(horizontal = 4.dp),
            contentAlignment = if (value) Alignment.CenterEnd else Alignment.CenterStart
        ) {
            Box(
                modifier = Modifier
                    .width(16.dp)
                    .height(16.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.White)
            )
        }
    }
}

@Composable
private fun StepperRow(
    label: String,
    value: String,
    onDecrease: () -> Unit,
    onIncrease: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = DiveColors.Text, fontSize = 13.sp)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(DiveColors.BgCardHover)
                    .border(1.dp, DiveColors.Border, RoundedCornerShape(6.dp))
                    .clickable { onDecrease() }
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("-", color = DiveColors.Text, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }

            Text(
                text = value,
                color = DiveColors.Accent,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = DiveFonts.body,
                modifier = Modifier.width(44.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(DiveColors.BgCardHover)
                    .border(1.dp, DiveColors.Border, RoundedCornerShape(6.dp))
                    .clickable { onIncrease() }
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("+", color = DiveColors.Text, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun ThemeCard(title: String) {
    SettingsCard(title = title) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, DiveColors.Border, RoundedCornerShape(8.dp))
                    .padding(4.dp),
                verticalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    Swatch(DiveColors.Bg); Swatch(DiveColors.BgCard); Swatch(DiveColors.BgCardHover)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    Swatch(DiveColors.Accent); Swatch(DiveColors.Green); Swatch(DiveColors.Red)
                }
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "深色",
                    color = DiveColors.Text,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = "Dive Into Crypto 品牌 — 固定",
                    color = DiveColors.TextMuted,
                    fontSize = 12.sp,
                )
            }
        }
    }
}

@Composable
private fun Swatch(color: Color) {
    Spacer(
        modifier = Modifier
            .width(16.dp)
            .height(16.dp)
            .clip(RoundedCornerShape(3.dp))
            .background(color),
    )
}

@Composable
private fun AboutCard(title: String) {
    SettingsCard(title = title) {
        AboutRow("应用", "Dive Into Crypto")
        Spacer(Modifier.height(8.dp))
        AboutRow("版本", AppInfo.versionName)
        Spacer(Modifier.height(8.dp))
        AboutRow("构建", AppInfo.versionCode.toString())
        Spacer(Modifier.height(8.dp))
        AboutRow("模式", if (AppInfo.isDebug) "Debug" else "Release")
        Spacer(Modifier.height(8.dp))
        AboutRow("数据源", "Binance USDT-M Futures")
        Spacer(Modifier.height(8.dp))
        AboutRow("指标", "60 (Dive Into Crypto consensus engine)")
        Spacer(Modifier.height(8.dp))
        AboutRow("时间框架数", "12")
    }
}

@Composable
private fun AboutRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = label,
            color = DiveColors.TextMuted,
            fontSize = 12.sp,
            modifier = Modifier.weight(1f),
        )
        Text(
            text = value,
            color = DiveColors.Text,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = DiveFonts.body,
        )
    }
}

/**
 * TR/EN/ZH language switch (LANE-7 i18n) — chips persisting the "language"
 * KeyValueStore key via [AppContainer.setLanguage]; the active catalog flows
 * back through AppContainer.language → LocalDiveStrings app-wide.
 */
@Composable
private fun LanguageCard(container: AppContainer) {
    val strings = com.diveintocrypto.android.ui.i18n.LocalDiveStrings.current
    val current by container.language.collectAsStateWithLifecycle()
    SettingsCard(title = strings.setTitleLanguage) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("zh" to strings.langZh, "en" to strings.langEn, "tr" to strings.langTr).forEach { (code, label) ->
                val active = current.code == code
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (active) DiveColors.Accent else DiveColors.BgCardHover)
                        .border(
                            1.dp,
                            if (active) DiveColors.Accent else DiveColors.Border,
                            RoundedCornerShape(20.dp),
                        )
                        .semantics {
                            role = Role.Button
                            stateDescription = if (active) strings.selected else strings.notSelected
                        }
                        .clickable { container.setLanguage(code) }
                        .padding(horizontal = 18.dp, vertical = 8.dp),
                ) {
                    Text(
                        text = label,
                        color = if (active) Color.White else DiveColors.TextMuted,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
    }
}


@Composable
private fun AiSettingsCard(
    enabled: Boolean,
    baseUrl: String,
    model: String,
    apiKey: String,
    onSave: (baseUrl: String, model: String, apiKey: String, enabled: Boolean) -> Unit,
) {
    var base by remember(baseUrl) { mutableStateOf(baseUrl) }
    var mod by remember(model) { mutableStateOf(model) }
    var key by remember(apiKey) { mutableStateOf(apiKey) }
    var on by remember(enabled) { mutableStateOf(enabled) }
    SettingsCard(title = "云端 AI 分析") {
        Text(
            "DeepSeek / OpenAI 兼容接口。Key 仅存本机。分析页使用此处配置。",
            color = DiveColors.TextMuted,
            fontSize = 11.sp,
        )
        Spacer(Modifier.height(8.dp))
        Text("API Base", color = DiveColors.TextMuted, fontSize = 11.sp)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(DiveColors.BgCardHover)
                .border(1.dp, DiveColors.Border, RoundedCornerShape(8.dp))
                .padding(horizontal = 12.dp, vertical = 10.dp),
        ) {
            BasicTextField(
                value = base,
                onValueChange = { base = it },
                singleLine = true,
                textStyle = TextStyle(color = DiveColors.Text, fontSize = 12.sp, fontFamily = DiveFonts.body),
                cursorBrush = SolidColor(DiveColors.Accent),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        Spacer(Modifier.height(6.dp))
        Text("模型", color = DiveColors.TextMuted, fontSize = 11.sp)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(DiveColors.BgCardHover)
                .border(1.dp, DiveColors.Border, RoundedCornerShape(8.dp))
                .padding(horizontal = 12.dp, vertical = 10.dp),
        ) {
            BasicTextField(
                value = mod,
                onValueChange = { mod = it },
                singleLine = true,
                textStyle = TextStyle(color = DiveColors.Text, fontSize = 12.sp, fontFamily = DiveFonts.body),
                cursorBrush = SolidColor(DiveColors.Accent),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        Spacer(Modifier.height(6.dp))
        Text("API Key", color = DiveColors.TextMuted, fontSize = 11.sp)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(DiveColors.BgCardHover)
                .border(1.dp, DiveColors.Border, RoundedCornerShape(8.dp))
                .padding(horizontal = 12.dp, vertical = 10.dp),
        ) {
            BasicTextField(
                value = key,
                onValueChange = { key = it },
                singleLine = true,
                textStyle = TextStyle(color = DiveColors.Text, fontSize = 12.sp, fontFamily = DiveFonts.body),
                cursorBrush = SolidColor(DiveColors.Accent),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(if (on) "已启用" else "未启用", color = DiveColors.Text, fontSize = 13.sp)
            TextButton(onClick = {
                on = !on
                onSave(base, mod, key, on)
            }) { Text(if (on) "关闭" else "启用") }
        }
        Button(
            onClick = { onSave(base, mod, key, on) },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("保存 AI 配置") }
    }
}

@Composable
private fun SettingsCard(title: String, content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(DiveColors.BgCard)
            .border(1.dp, DiveColors.Border, RoundedCornerShape(12.dp))
            .padding(horizontal = 16.dp, vertical = 14.dp),
    ) {
        Text(
            text = title,
            color = DiveColors.TextMuted,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp,
            fontFamily = DiveFonts.body,
        )
        Spacer(Modifier.height(12.dp))
        content()
    }
}


@Composable
private fun NetworkEndpointsCard(
    restBaseUrl: String,
    wsBaseUrl: String,
    onSave: (String, String) -> Unit,
) {
    var rest by remember(restBaseUrl) { androidx.compose.runtime.mutableStateOf(restBaseUrl) }
    var ws by remember(wsBaseUrl) { androidx.compose.runtime.mutableStateOf(wsBaseUrl) }
    SettingsCard(title = "网络线路（国内可访问）") {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "官方 fapi.binance.com / fstream.binance.com 在国内常不可用。" +
                    "可填写自建反向代理地址（需转发 /fapi 与 /ws）。改完点保存，立即生效。",
                color = DiveColors.TextMuted,
                fontSize = 11.sp,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(
                    "官方" to Pair("https://fapi.binance.com", "wss://fstream.binance.com"),
                ).forEach { (label, pair) ->
                    val active = rest == pair.first && ws == pair.second
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (active) DiveColors.Accent else DiveColors.BgCardHover)
                            .border(1.dp, if (active) DiveColors.Accent else DiveColors.Border, RoundedCornerShape(20.dp))
                            .clickable {
                                rest = pair.first
                                ws = pair.second
                                onSave(pair.first, pair.second)
                            }
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                    ) {
                        Text(
                            text = label,
                            color = if (active) androidx.compose.ui.graphics.Color.White else DiveColors.TextMuted,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }
            }
            Text("合约 REST 地址", color = DiveColors.TextMuted, fontSize = 11.sp)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(DiveColors.BgCardHover)
                    .border(1.dp, DiveColors.Border, RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 10.dp),
            ) {
                BasicTextField(
                    value = rest,
                    onValueChange = { rest = it },
                    singleLine = true,
                    textStyle = TextStyle(color = DiveColors.Text, fontSize = 12.sp, fontFamily = DiveFonts.body),
                    cursorBrush = SolidColor(DiveColors.Accent),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Text("合约 WebSocket 地址", color = DiveColors.TextMuted, fontSize = 11.sp)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(DiveColors.BgCardHover)
                    .border(1.dp, DiveColors.Border, RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 10.dp),
            ) {
                BasicTextField(
                    value = ws,
                    onValueChange = { ws = it },
                    singleLine = true,
                    textStyle = TextStyle(color = DiveColors.Text, fontSize = 12.sp, fontFamily = DiveFonts.body),
                    cursorBrush = SolidColor(DiveColors.Accent),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(DiveColors.Accent)
                    .clickable { onSave(rest.trim(), ws.trim()) }
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text("保存线路", color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            Text(
                text = "自建代理示例：Cloudflare Worker / Nginx 将请求转发到 https://fapi.binance.com 与 wss://fstream.binance.com。" +
                    "代理需保留路径 /fapi/... 与 /ws/... 。不要使用不明第三方「币安镜像」。",
                color = DiveColors.TextDim,
                fontSize = 10.sp,
            )
        }
    }
}

@Composable
private fun QuantitativeChartSettingsCard(
    title: String,
    wsDataSource: String,
    chartCandleCount: Int,
    onSourceChange: (String) -> Unit,
    onLimitChange: (Int) -> Unit
) {
    SettingsCard(title = title) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("实时价格数据源（WS）", color = DiveColors.TextMuted, fontSize = 11.sp)
                Spacer(Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("FUTURES", "SPOT").forEach { source ->
                        val active = source == wsDataSource
                        val displayName = if (source == "FUTURES") "合约 WS（默认）" else "现货 WS（备用 - 更快）"
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (active) DiveColors.Accent else DiveColors.BgCardHover)
                                .border(1.dp, if (active) DiveColors.Accent else DiveColors.Border, RoundedCornerShape(20.dp))
                                .clickable { onSourceChange(source) }
                                .padding(horizontal = 14.dp, vertical = 6.dp),
                        ) {
                            Text(
                                text = displayName,
                                color = if (active) Color.White else DiveColors.TextMuted,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("图表K线数量（宽度）", color = DiveColors.TextMuted, fontSize = 11.sp)
                Spacer(Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(30, 50, 75, 100).forEach { limit ->
                        val active = limit == chartCandleCount
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (active) DiveColors.Accent else DiveColors.BgCardHover)
                                .border(1.dp, if (active) DiveColors.Accent else DiveColors.Border, RoundedCornerShape(20.dp))
                                .clickable { onLimitChange(limit) }
                                .padding(horizontal = 14.dp, vertical = 6.dp),
                        ) {
                            Text(
                                text = "$limit Candles",
                                color = if (active) Color.White else DiveColors.TextMuted,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuantBiasSettingsCard(
    title: String,
    taker: Double,
    oi: Double,
    whale: Double,
    account: Double,
    onWeightsChange: (Double, Double, Double, Double) -> Unit
) {
    SettingsCard(title = title) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            val total = taker + oi + whale + account
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "市场方向得分的加权组成：",
                    color = DiveColors.TextMuted,
                    fontSize = 11.sp,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = "合计：" + total.format(2),
                    color = if (kotlin.math.abs(total - 1.0) < 0.001) DiveColors.Green else DiveColors.Orange,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = DiveFonts.body
                )
            }
            Spacer(Modifier.height(6.dp))

            StepperRow(
                label = "主动买卖动量（买卖比）",
                value = taker.format(2),
                onDecrease = {
                    val newVal = (taker - 0.05).coerceAtLeast(0.0)
                    onWeightsChange(newVal, oi, whale, account)
                },
                onIncrease = {
                    val newVal = (taker + 0.05).coerceAtMost(1.0)
                    onWeightsChange(newVal, oi, whale, account)
                }
            )

            StepperRow(
                label = "OI 动量（持仓与价格一致性）",
                value = oi.format(2),
                onDecrease = {
                    val newVal = (oi - 0.05).coerceAtLeast(0.0)
                    onWeightsChange(taker, newVal, whale, account)
                },
                onIncrease = {
                    val newVal = (oi + 0.05).coerceAtMost(1.0)
                    onWeightsChange(taker, newVal, whale, account)
                }
            )

            StepperRow(
                label = "鲸鱼偏差（鲸鱼持仓多空）",
                value = whale.format(2),
                onDecrease = {
                    val newVal = (whale - 0.05).coerceAtLeast(0.0)
                    onWeightsChange(taker, oi, newVal, account)
                },
                onIncrease = {
                    val newVal = (whale + 0.05).coerceAtMost(1.0)
                    onWeightsChange(taker, oi, newVal, account)
                }
            )

            StepperRow(
                label = "账户偏差（账户多空）",
                value = account.format(2),
                onDecrease = {
                    val newVal = (account - 0.05).coerceAtLeast(0.0)
                    onWeightsChange(taker, oi, whale, newVal)
                },
                onIncrease = {
                    val newVal = (account + 0.05).coerceAtMost(1.0)
                    onWeightsChange(taker, oi, whale, newVal)
                }
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════
// BİLDİRİMLER (Task 2d) — honest POST_NOTIFICATIONS runtime-permission card.
// The actual request is wired platform-side (rememberNotificationPermission:
// ActivityResultContracts.RequestPermission on Android, API 33+). In-app
// banners + alarm history work regardless of the OS grant — said explicitly.
// ═══════════════════════════════════════════════════════════════════════
@Composable
private fun NotificationsCard(title: String) {
    val perm = rememberNotificationPermission()
    val strings = com.diveintocrypto.android.ui.i18n.LocalDiveStrings.current
    SettingsCard(title = title) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = "警报规则触发时发送系统通知 " +
                    "（价格规则走实时流，裁决/置信度/OI 规则走扫描循环）。",
                color = DiveColors.TextMuted,
                fontSize = 11.sp,
                lineHeight = 15.sp,
            )

            when {
                // Platform doesn't require a runtime grant (API < 33): nothing to ask.
                !perm.needed -> Text(
                    text = "✓ 本设备无需通知权限 — 通知可正常工作。",
                    color = DiveColors.Green,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                )
                perm.granted -> Text(
                    text = "✓ 已授权 — 系统通知已开启。",
                    color = DiveColors.Green,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                )
                else -> {
                    Text(
                        text = "⚠ 未授权 — 系统通知静音。应用内警报 " +
                            "区间与触发历史仍会运行。",
                        color = DiveColors.Warn,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        lineHeight = 16.sp,
                    )
                    // Request button — the OS dialog fires from the platform launcher.
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(DiveColors.Accent)
                            .semantics { role = Role.Button }
                            .clickable { perm.request() }
                            .padding(horizontal = 16.dp, vertical = 9.dp),
                    ) {
                        Text(
                            text = strings.btnRequestNotifPermission,
                            color = MaterialTheme.colorScheme.onPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.8.sp,
                            fontFamily = DiveFonts.body,
                        )
                    }
                }
            }
        }
    }
}
