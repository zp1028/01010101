package com.diveintocrypto.android.ui.analysis

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import com.diveintocrypto.android.AppContainer
import com.diveintocrypto.android.domain.analysis.AnalysisPlanMath
import com.diveintocrypto.android.domain.analysis.PatternDetector
import com.diveintocrypto.android.domain.analysis.TrendLineBuilder
import com.diveintocrypto.android.domain.analysis.WatchSession
import com.diveintocrypto.android.domain.analysis.AnalysisExplain
import com.diveintocrypto.android.domain.analysis.AnalysisStructurePlan
import com.diveintocrypto.android.data.ai.AiAnalysisClient
import com.diveintocrypto.android.domain.scanner.StructureAwareRiskPlan
import com.diveintocrypto.android.domain.model.Candle
import com.diveintocrypto.android.domain.model.Signal
import com.diveintocrypto.android.domain.scanner.HistoricalCandleAlignment
import com.diveintocrypto.android.domain.scanner.MarketDataFreshness
import com.diveintocrypto.android.domain.scanner.RiskPlanCalculator
import com.diveintocrypto.android.domain.scanner.RiskPlanEligibility
import com.diveintocrypto.android.platform.nowMillis
import com.diveintocrypto.android.ui.theme.DiveColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min

@Composable
fun AnalysisScreen(container: AppContainer) {
    val scope = rememberCoroutineScope()
    var symbol by remember { mutableStateOf(container.activeSymbol.value) }
    var timeframe by remember { mutableStateOf(container.activeTimeframe.value.ifBlank { "15m" }) }
    var targetR by remember {
        mutableStateOf(
            container.settingsStore.getSettings().riskTargetR.coerceIn(
                AnalysisPlanMath.TARGET_R_MIN,
                AnalysisPlanMath.TARGET_R_MAX,
            ),
        )
    }
    var loading by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("选择标的后点击「开始分析」。") }
    var candles by remember { mutableStateOf<List<Candle>>(emptyList()) }
    var signal by remember { mutableStateOf(Signal.NEUTRAL) }
    var confidence by remember { mutableStateOf(0) }
    var shouldTrade by remember { mutableStateOf(false) }
    var allowPlan by remember { mutableStateOf(false) }
    var entry by remember { mutableStateOf<Double?>(null) }
    var atrValue by remember { mutableStateOf<Double?>(null) }
    var narrative by remember { mutableStateOf<List<String>>(emptyList()) }
    var supports by remember { mutableStateOf<List<Double>>(emptyList()) }
    var resistances by remember { mutableStateOf<List<Double>>(emptyList()) }
    var rsiSeries by remember { mutableStateOf<List<Double?>>(emptyList()) }
    var macdSeries by remember { mutableStateOf<List<AnalysisPlanMath.MacdPoint>>(emptyList()) }
    var patternHits by remember { mutableStateOf<List<PatternDetector.Hit>>(emptyList()) }
    var trendSegments by remember { mutableStateOf<List<TrendLineBuilder.Segment>>(emptyList()) }
    var patternIndex by remember { mutableIntStateOf(0) }
    var showOutline by remember { mutableStateOf(true) }
    var showTrends by remember { mutableStateOf(true) }
    var watch by remember { mutableStateOf(WatchSession.State.Idle) }
    var useStructureStop by remember { mutableStateOf(false) }
    var explainAnswer by remember { mutableStateOf<String?>(null) }
    var aiReport by remember { mutableStateOf<String?>(null) }
    var aiLoading by remember { mutableStateOf(false) }
    var aiStatus by remember { mutableStateOf("") }
    var aiQuestion by remember { mutableStateOf("") }
    var aiHistory by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var aiPlan by remember { mutableStateOf<AiAnalysisClient.AiPlan?>(null) }
    var useAiPlan by remember { mutableStateOf(true) }
    var multiTfEnabled by remember { mutableStateOf(true) }
    var symbolInput by remember { mutableStateOf(container.activeSymbol.value) }


    var showPriceLines by remember { mutableStateOf(true) }
    var showStructure by remember { mutableStateOf(true) }
    var showRsi by remember { mutableStateOf(true) }
    var showMacd by remember { mutableStateOf(true) }
    var supportIndex by remember { mutableIntStateOf(0) }
    var resistanceIndex by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        runCatching { container.liveTickerEngine.ensureStarted() }
    }
    val tickers by container.liveTickerEngine.tickers.collectAsState()
    val aiSession by container.aiSessionHub.session.collectAsState()
    val liveFromWs = tickers[symbol.uppercase()]?.price
    var lastClose by remember { mutableStateOf<Double?>(null) }
    val livePrice = liveFromWs ?: lastClose

    val planAndSource = remember(signal, entry, atrValue, targetR, allowPlan, useStructureStop, supports, resistances, supportIndex, resistanceIndex) {
        val e = entry
        val a = atrValue
        val d = AnalysisPlanMath.directionFromSignal(signal)
        if (!allowPlan || e == null || a == null || d == null) null to null
        else if (useStructureStop) {
            val sStop = AnalysisStructurePlan.structureStopForDirection(
                d,
                supports.getOrNull(supportIndex),
                resistances.getOrNull(resistanceIndex),
            )
            val res = AnalysisStructurePlan.calculate(d, e, a, targetR, sStop)
            val label = when (res.stopSource) {
                StructureAwareRiskPlan.StopSource.STRUCTURE_AND_ATR -> "结构+ATR"
                StructureAwareRiskPlan.StopSource.ATR_ONLY -> "ATR（结构不可用）"
            }
            res.plan to label
        } else {
            AnalysisPlanMath.buildPlan(signal, e, a, targetR) to "ATR"
        }
    }
    val localPlan = planAndSource.first
    val localSource = planAndSource.second
    val hubPlan = aiSession.lastPlan
    val effectiveAiPlan = hubPlan ?: aiPlan
    val plan = if (useAiPlan && effectiveAiPlan != null) AiAnalysisClient.toRiskPlan(effectiveAiPlan) else localPlan
    val stopSourceLabel = if (useAiPlan && effectiveAiPlan != null) "AI计划" else localSource
    val direction = effectiveAiPlan?.direction ?: AnalysisPlanMath.directionFromSignal(signal)
    // Keep local state mirrored from hub for display
    LaunchedEffect(aiSession.lastReport, aiSession.streamingText, aiSession.status, aiSession.lastPlan, aiSession.running) {
        if (aiSession.streamingText.isNotBlank()) aiReport = aiSession.streamingText
        else if (aiSession.lastReport != null) aiReport = aiSession.lastReport
        aiStatus = aiSession.status
        aiLoading = aiSession.running
        if (aiSession.lastPlan != null) aiPlan = aiSession.lastPlan
        if (aiSession.symbol.isNotBlank() && aiSession.symbol != symbol) {
            symbol = aiSession.symbol
            symbolInput = aiSession.symbol
        }
    }
    // direction: AI plan preferred when active (see above)
    val liveRr = remember(plan, livePrice, direction) {
        val p = plan
        val lp = livePrice
        val d = direction
        if (p == null || lp == null || d == null) null
        else AnalysisPlanMath.liveRiskReward(d, p.entry, p.stopLoss, p.takeProfit, lp)
    }
    val progress = remember(plan, livePrice, direction) {
        val p = plan
        val lp = livePrice
        val d = direction
        if (p == null || lp == null || d == null) 0.5
        else AnalysisPlanMath.priceProgress(d, p.stopLoss, p.takeProfit, lp)
    }

    fun runAnalyze() {
        if (loading) return
        loading = true
        status = "正在拉取 K 线并计算共识与计划…"
        val sym = symbol.trim().uppercase()
        val tf = timeframe
        scope.launch {
            try {
                val raw = withContext(Dispatchers.IO) {
                    container.repository.futuresHistory(sym, tf, limit = 300)
                }
                val closed = HistoricalCandleAlignment.sanitize(raw)
                if (closed.size < 40) {
                    status = "K 线不足（${closed.size}），请换周期或稍后重试。"
                    candles = closed
                    allowPlan = false
                    return@launch
                }
                val last = closed.last()
                val freshness = MarketDataFreshness.assess(
                    candleOpenTimeMs = last.openTime,
                    timeframeMs = periodMs(tf),
                    nowMs = nowMillis(),
                )
                val indicatorOuts = withContext(Dispatchers.Default) {
                    container.indicators.map { it.calculate(closed) }
                }
                val consensus = container.consensus.evaluate(indicatorOuts)
                val elig = RiskPlanEligibility.evaluate(consensus.finalSignal, mtfDirection = 0)
                val canShow = freshness.status == MarketDataFreshness.Status.FRESH &&
                    elig.status == RiskPlanEligibility.Status.ELIGIBLE &&
                    consensus.shouldTrade
                val atr = AnalysisPlanMath.atr(closed)
                val book = AnalysisPlanMath.structureBook(
                    highs = closed.map { it.high },
                    lows = closed.map { it.low },
                    currentPrice = last.close,
                )
                candles = closed.takeLast(120)
                val chartCloses = candles.map { it.close }
                rsiSeries = AnalysisPlanMath.rsiSeries(chartCloses)
                macdSeries = AnalysisPlanMath.macdSeries(chartCloses)
                patternHits = PatternDetector.detect(candles)
                trendSegments = TrendLineBuilder.build(candles)
                patternIndex = 0
                signal = consensus.finalSignal
                confidence = consensus.confidence
                shouldTrade = consensus.shouldTrade
                entry = last.close
                atrValue = atr
                lastClose = last.close
                supports = book.supports
                resistances = book.resistances
                supportIndex = 0
                resistanceIndex = 0
                allowPlan = canShow && atr != null
                val sNote = book.supports.firstOrNull()?.let { "近端支撑 ${AnalysisPlanMath.formatPrice(it)}" }
                val rNote = book.resistances.firstOrNull()?.let { "近端阻力 ${AnalysisPlanMath.formatPrice(it)}" }
                narrative = AnalysisPlanMath.defaultNarrative(
                    consensus.finalSignal,
                    consensus.confidence,
                    tf,
                    consensus.shouldTrade,
                ) + listOfNotNull(
                    listOfNotNull(sNote, rNote).takeIf { it.isNotEmpty() }?.joinToString("；"),
                )
                container.activeSymbol.value = sym
                container.activeTimeframe.value = tf
                symbol = sym
                status = when {
                    freshness.status != MarketDataFreshness.Status.FRESH ->
                        "行情未通过新鲜度检查（${freshness.status}）；已隐藏方向性计划价位。"
                    !consensus.shouldTrade || elig.status != RiskPlanEligibility.Status.ELIGIBLE ->
                        "方向或门槛未通过；可查看 K 线与结构位。"
                    atr == null -> "ATR 无效，无法生成计划。"
                    else -> "分析完成。已自动打开计划线/结构/趋势/形态/RSI（可关）。"
                }
                // Trend-IQ style: auto-draw technical layers after analysis
                showPriceLines = true
                showStructure = true
                showTrends = true
                showOutline = true
                showRsi = true
                showMacd = true
            } catch (t: Throwable) {
                status = "分析失败：${t.message ?: t::class.simpleName}"
                allowPlan = false
            } finally {
                loading = false
            }
        }
    }

    LaunchedEffect(Unit) {
        if (symbol.isNotBlank()) runAnalyze()
    }

    LaunchedEffect(livePrice, watch.enabled, watch.plan?.stopLoss, watch.plan?.takeProfit) {
        if (watch.enabled) {
            watch = WatchSession.evaluate(watch, livePrice)
        }
    }


    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DiveColors.RootBg)
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("行情分析", fontWeight = FontWeight.Bold, color = DiveColors.Text, fontSize = 18.sp)
        Text(
            "研究参考 · 不下单 · 开始分析后自动绘计划线/结构/趋势/形态/RSI·MACD",
            color = DiveColors.TextMuted,
            fontSize = 12.sp,
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column {
                Text(symbol.ifBlank { "—" }, fontWeight = FontWeight.Bold, color = DiveColors.Accent, fontSize = 16.sp)
                val lp = livePrice
                val src = if (liveFromWs != null) "WS" else "K线"
                Text(
                    if (lp != null) "${AnalysisPlanMath.formatPrice(lp)} · $src" else "—",
                    color = DiveColors.Text,
                    fontSize = 14.sp,
                )
            }
            Text(timeframe, color = DiveColors.TextMuted, fontSize = 13.sp)
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            OutlinedTextField(
                value = symbolInput,
                onValueChange = { symbolInput = it.uppercase() },
                modifier = Modifier.weight(1f),
                singleLine = true,
                label = { Text("合约符号") },
            )
            Button(onClick = {
                val s = symbolInput.trim().uppercase()
                if (s.isNotEmpty()) {
                    symbol = s
                    container.activeSymbol.value = s
                    runAnalyze()
                }
            }) { Text("切换") }
        }
        Text("无截图识图：可手动输入如 BTCUSDT 后点切换（截图分析列为后续可选）。", color = DiveColors.TextMuted, fontSize = 11.sp)

        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            listOf("5m", "15m", "30m", "1h", "4h", "1d").forEach { tf ->
                val active = tf == timeframe
                TextButton(onClick = { timeframe = tf }) {
                    Text(
                        tf,
                        color = if (active) DiveColors.Accent else DiveColors.TextMuted,
                        fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                    )
                }
            }
        }
        Button(
            onClick = { runAnalyze() },
            enabled = !loading && symbol.isNotBlank(),
            modifier = Modifier.fillMaxWidth(),
        ) {
            if (loading) CircularProgressIndicator(modifier = Modifier.height(18.dp).width(18.dp), strokeWidth = 2.dp)
            else Text("开始分析")
        }
        Text(status, color = DiveColors.TextMuted, fontSize = 12.sp)

        AnalysisMiniChart(
            candles = candles,
            plan = if (showPriceLines) plan else null,
            livePrice = livePrice,
            activeSupport = supports.getOrNull(supportIndex).takeIf { showStructure },
            activeResistance = resistances.getOrNull(resistanceIndex).takeIf { showStructure },
            patternHit = patternHits.getOrNull(patternIndex).takeIf { showOutline },
            trendSegments = if (showTrends) trendSegments else emptyList(),
            modifier = Modifier.fillMaxWidth().height(220.dp),
        )

        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            LayerChip(label = "价格线", active = showPriceLines, onClick = { showPriceLines = !showPriceLines })
            LayerChip(
                label = if (supports.isEmpty()) "支撑 0/0" else "支撑 ${supportIndex + 1}/${supports.size}",
                active = showStructure && supports.isNotEmpty(),
                onClick = {
                    if (supports.isEmpty()) return@LayerChip
                    showStructure = true
                    supportIndex = (supportIndex + 1) % supports.size
                },
            )
            LayerChip(
                label = if (resistances.isEmpty()) "阻力 0/0" else "阻力 ${resistanceIndex + 1}/${resistances.size}",
                active = showStructure && resistances.isNotEmpty(),
                onClick = {
                    if (resistances.isEmpty()) return@LayerChip
                    showStructure = true
                    resistanceIndex = (resistanceIndex + 1) % resistances.size
                },
            )
            LayerChip(label = "RSI", active = showRsi, onClick = { showRsi = !showRsi })
            LayerChip(label = "MACD", active = showMacd, onClick = { showMacd = !showMacd })
            LayerChip(
                label = if (patternHits.isEmpty()) "图形 0/0" else "图形 ${patternIndex + 1}/${patternHits.size}",
                active = showOutline && patternHits.isNotEmpty(),
                onClick = {
                    if (patternHits.isEmpty()) return@LayerChip
                    showOutline = true
                    patternIndex = (patternIndex + 1) % patternHits.size
                },
            )
            LayerChip(label = "趋势线", active = showTrends, onClick = { showTrends = !showTrends })
            LayerChip(label = "轮廓", active = showOutline, onClick = { showOutline = !showOutline })
            LayerChip(label = "结构", active = showStructure, onClick = { showStructure = !showStructure })
        }

        if (showRsi && rsiSeries.any { it != null }) {
            IndicatorStrip(
                title = "RSI(14)",
                values = rsiSeries,
                guideLines = listOf(30.0, 70.0),
                yMin = 0.0,
                yMax = 100.0,
            )
        }
        if (showMacd && macdSeries.any { it.hist != null }) {
            MacdStrip(title = "MACD(12,26,9)", series = macdSeries)
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(DiveColors.BgCard, RoundedCornerShape(8.dp))
                .border(1.dp, DiveColors.Border, RoundedCornerShape(8.dp))
                .padding(12.dp),
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("信号", color = DiveColors.TextMuted, fontSize = 11.sp)
                Text(
                    AnalysisPlanMath.signalHeadline(signal, plan?.entry ?: entry),
                    color = DiveColors.Text,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp,
                )
                Text(
                    "置信度 $confidence% · ${if (shouldTrade) "可交易门槛" else "未过门槛"}",
                    color = DiveColors.TextMuted,
                    fontSize = 11.sp,
                )
            }
        }

        patternHits.getOrNull(patternIndex)?.let { hit ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DiveColors.BgCard, RoundedCornerShape(8.dp))
                    .border(1.dp, DiveColors.Border, RoundedCornerShape(8.dp))
                    .padding(12.dp),
            ) {
                Column {
                    Text(hit.name, fontWeight = FontWeight.SemiBold, color = DiveColors.Accent, fontSize = 14.sp)
                    Text(hit.oneLiner, color = DiveColors.TextMuted, fontSize = 12.sp)
                    Text("规则置信 ${fmtPct(hit.confidence * 100)}%", color = DiveColors.TextDim, fontSize = 11.sp)
                }
            }
        }

        // Watch card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(DiveColors.BgCard, RoundedCornerShape(8.dp))
                .border(1.dp, DiveColors.Border, RoundedCornerShape(8.dp))
                .padding(12.dp),
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("盯盘", fontWeight = FontWeight.Bold, color = DiveColors.Text)
                Text(watch.message, color = DiveColors.TextMuted, fontSize = 12.sp)
                if (plan != null && direction != null) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                watch = if (watch.enabled) {
                                    WatchSession.disarm()
                                } else {
                                    WatchSession.arm(symbol, direction, plan.entry, plan.stopLoss, plan.takeProfit)
                                }
                            },
                        ) {
                            Text(if (watch.enabled) "停止盯盘" else "开始盯盘")
                        }
                    }
                    if (watch.enabled && watch.plan != null) {
                        val wp = watch.plan!!
                        Text(
                            "入场 ${AnalysisPlanMath.formatPrice(wp.entry)} · 止盈 ${AnalysisPlanMath.formatPrice(wp.takeProfit)} · 止损 ${AnalysisPlanMath.formatPrice(wp.stopLoss)}",
                            color = DiveColors.Text,
                            fontSize = 12.sp,
                        )
                    }
                } else {
                    Text("需有效方向计划后可盯盘。", color = DiveColors.TextMuted, fontSize = 12.sp)
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(DiveColors.BgCard, RoundedCornerShape(8.dp))
                .border(1.dp, DiveColors.Border, RoundedCornerShape(8.dp))
                .padding(12.dp),
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("风险收益", fontWeight = FontWeight.Bold, color = DiveColors.Text)
                if (plan == null) {
                    Text("暂无方向性计划。", color = DiveColors.TextMuted, fontSize = 12.sp)
                } else {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        MetricCell("风险%", "${fmtPct(plan.stopDistancePercent)}%")
                        MetricCell("R:R", "${fmtPct(plan.riskRewardRatio)}:1")
                        MetricCell("入场", AnalysisPlanMath.formatPrice(plan.entry))
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        MetricCell("实时 R:R", liveRr?.let { "${fmtPct(it)}:1" } ?: "—")
                        MetricCell("目标 R", fmtPct(targetR))
                    }
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .background(DiveColors.Border, RoundedCornerShape(4.dp)),
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(progress.toFloat().coerceIn(0.02f, 1f))
                                .height(8.dp)
                                .background(DiveColors.Accent, RoundedCornerShape(4.dp)),
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            "止损来源：${stopSourceLabel ?: "—"}",
                            color = DiveColors.TextMuted,
                            fontSize = 11.sp,
                        )
                        LayerChip(
                            label = if (useStructureStop) "结构止损·开" else "结构止损·关",
                            active = useStructureStop,
                            onClick = { useStructureStop = !useStructureStop },
                        )
                    }
                    Text("目标 R（滑块调整止盈）", color = DiveColors.TextMuted, fontSize = 11.sp)
                    Slider(
                        value = targetR.toFloat(),
                        onValueChange = {
                        val r = AnalysisPlanMath.snapTargetR(it.toDouble())
                        targetR = r
                        val e = entry
                        val a = atrValue
                        if (watch.enabled && e != null && a != null && allowPlan) {
                            val d = AnalysisPlanMath.directionFromSignal(signal)
                            val np = if (d != null && useStructureStop) {
                                val sStop = AnalysisStructurePlan.structureStopForDirection(
                                    d, supports.getOrNull(supportIndex), resistances.getOrNull(resistanceIndex),
                                )
                                AnalysisStructurePlan.calculate(d, e, a, r, sStop).plan
                            } else AnalysisPlanMath.buildPlan(signal, e, a, r)
                            if (np != null) {
                                watch = WatchSession.updatePlan(watch, np.stopLoss, np.takeProfit)
                            }
                        }
                    },
                        valueRange = AnalysisPlanMath.TARGET_R_MIN.toFloat()..AnalysisPlanMath.TARGET_R_MAX.toFloat(),
                        steps = ((AnalysisPlanMath.TARGET_R_MAX - AnalysisPlanMath.TARGET_R_MIN) / AnalysisPlanMath.TARGET_R_STEP).toInt() - 1,
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(Color(0x33AA4444), RoundedCornerShape(8.dp))
                                .padding(10.dp),
                        ) {
                            Column {
                                Text("止损", color = DiveColors.TextMuted, fontSize = 11.sp)
                                Text(AnalysisPlanMath.formatPrice(plan.stopLoss), color = DiveColors.Text, fontWeight = FontWeight.Bold)
                            }
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(Color(0x3344AA66), RoundedCornerShape(8.dp))
                                .padding(10.dp),
                        ) {
                            Column {
                                Text("止盈", color = DiveColors.TextMuted, fontSize = 11.sp)
                                Text(AnalysisPlanMath.formatPrice(plan.takeProfit), color = DiveColors.Text, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(DiveColors.BgCard, RoundedCornerShape(8.dp))
                .border(1.dp, DiveColors.Border, RoundedCornerShape(8.dp))
                .padding(12.dp),
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("交易逻辑", fontWeight = FontWeight.Bold, color = DiveColors.Text)
                if (narrative.isEmpty()) {
                    Text("完成分析后显示说明。", color = DiveColors.TextMuted, fontSize = 12.sp)
                } else {
                    narrative.forEach { line ->
                        Text("• $line", color = DiveColors.Text, fontSize = 13.sp)
                    }
                }
            }
        }

        Text("云端 AI 分析", fontWeight = FontWeight.Bold, color = DiveColors.Text)
        val aiSettings = container.settingsStore.getSettings()
        Text(
            if (aiSettings.aiEnabled && aiSettings.aiApiKey.isNotBlank())
                "已启用 · ${aiSettings.aiModel} · 配置在「设置」中修改"
            else
                "未配置或未启用：请到「更多 → 设置 → 云端 AI 分析」填写 Base / 模型 / Key 并启用",
            color = DiveColors.TextMuted,
            fontSize = 11.sp,
        )
        OutlinedTextField(
            value = aiQuestion,
            onValueChange = { aiQuestion = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("追问 / 自定义分析要求（可空）") },
        )
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            LayerChip(
                label = if (multiTfEnabled) "多周期·开" else "多周期·关",
                active = multiTfEnabled,
                onClick = { multiTfEnabled = !multiTfEnabled },
            )
            LayerChip(
                label = if (useAiPlan) "用AI计划" else "用引擎计划",
                active = useAiPlan,
                onClick = { useAiPlan = !useAiPlan },
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    val cfg = container.settingsStore.getSettings()
                    if (!cfg.aiEnabled || cfg.aiApiKey.isBlank()) {
                        aiStatus = "请先在设置页启用 AI 并填写 API Key"
                        return@Button
                    }
                    if (aiSession.running) return@Button
                    if (candles.size < 10) {
                        aiStatus = "请先「开始分析」拉取主周期 K 线"
                        return@Button
                    }
                    scope.launch {
                        val tf = timeframe
                        val sym = symbol
                        val primary = candles
                        val slices = mutableListOf(AiAnalysisClient.TfSlice(tf, primary))
                        if (multiTfEnabled) {
                            for (etf in listOf("15m", "1h", "4h").filter { it != tf }.take(2)) {
                                val raw = withContext(Dispatchers.IO) {
                                    runCatching { container.repository.futuresHistory(sym, etf, limit = 120) }.getOrDefault(emptyList())
                                }
                                val cleaned = HistoricalCandleAlignment.sanitize(raw)
                                if (cleaned.size >= 10) slices.add(AiAnalysisClient.TfSlice(etf, cleaned.takeLast(80)))
                            }
                        }
                        container.aiSessionHub.startAnalysis(
                            symbol = sym,
                            timeframe = tf,
                            primaryCandles = primary,
                            multiTf = slices,
                            signal = signal,
                            confidence = confidence,
                            shouldTrade = shouldTrade,
                            enginePlan = localPlan,
                            support = supports.getOrNull(supportIndex),
                            resistance = resistances.getOrNull(resistanceIndex),
                            patternName = patternHits.getOrNull(patternIndex)?.name,
                            livePrice = livePrice,
                            userQuestion = aiQuestion.trim().ifBlank { null },
                            source = "Analysis",
                            appendHistory = true,
                        )
                    }
                },
                enabled = !aiLoading,
            ) {
                if (aiLoading) CircularProgressIndicator(modifier = Modifier.height(18.dp).width(18.dp), strokeWidth = 2.dp)
                else Text(if (aiHistory.isEmpty()) "AI 分析" else "继续追问")
            }
            TextButton(onClick = {
                aiHistory = emptyList()
                aiReport = null
                aiPlan = null
                aiQuestion = ""
                aiStatus = "已清空对话"
                container.aiSessionHub.clear(symbol)
            }) { Text("清空对话") }
        }
        if (aiStatus.isNotBlank()) {
            Text(aiStatus, color = DiveColors.TextMuted, fontSize = 11.sp)
        }
        aiPlan?.let { ap ->
            Text(
                "AI计划：${ap.direction} 入场 ${AnalysisPlanMath.formatPrice(ap.entry)} / 止损 ${AnalysisPlanMath.formatPrice(ap.stopLoss)} / 止盈 ${AnalysisPlanMath.formatPrice(ap.takeProfit)} · R ${fmtPct(ap.riskRewardRatio)}" +
                    (ap.thesis?.let { " · $it" } ?: ""),
                color = DiveColors.Accent,
                fontSize = 12.sp,
            )
        }
        aiReport?.let { report ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DiveColors.BgCard, RoundedCornerShape(8.dp))
                    .border(1.dp, DiveColors.Accent.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                    .padding(12.dp),
            ) {
                Text(report, color = DiveColors.Text, fontSize = 13.sp)
            }
        }

        Text("本机说明（非 AI 云端）", fontWeight = FontWeight.Bold, color = DiveColors.Text)
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            listOf(
                "为什么是这个方向？" to "方向",
                "止损止盈怎么来的？" to "计划",
                "现在能不能做？" to "交易",
                "支撑阻力在哪？" to "结构",
                "形态说明了什么？" to "形态",
            ).forEach { (q, shortLabel) ->
                LayerChip(
                    label = shortLabel,
                    active = false,
                    onClick = {
                        val snap = AnalysisExplain.Snapshot(
                            symbol = symbol,
                            timeframe = timeframe,
                            signal = signal,
                            confidence = confidence,
                            shouldTrade = shouldTrade,
                            entry = entry,
                            plan = plan,
                            direction = direction,
                            patternName = patternHits.getOrNull(patternIndex)?.name,
                            support = supports.getOrNull(supportIndex),
                            resistance = resistances.getOrNull(resistanceIndex),
                            stopSource = stopSourceLabel,
                            livePrice = livePrice,
                        )
                        explainAnswer = AnalysisExplain.answer(q, snap)
                    },
                )
            }
        }
        explainAnswer?.let { ans ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DiveColors.BgCard, RoundedCornerShape(8.dp))
                    .border(1.dp, DiveColors.Border, RoundedCornerShape(8.dp))
                    .padding(12.dp),
            ) {
                Text(ans, color = DiveColors.Text, fontSize = 13.sp)
            }
        }

        Text(
            "非投资建议。结构位为已确认摆动点；改目标 R 不重跑共识。",
            color = DiveColors.TextMuted,
            fontSize = 11.sp,
        )
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun LayerChip(label: String, active: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(
                if (active) DiveColors.Accent.copy(alpha = 0.2f) else DiveColors.BgCard,
                RoundedCornerShape(6.dp),
            )
            .border(1.dp, if (active) DiveColors.Accent else DiveColors.Border, RoundedCornerShape(6.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp),
    ) {
        Text(
            label,
            color = if (active) DiveColors.Accent else DiveColors.TextMuted,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

@Composable
private fun MetricCell(label: String, value: String) {
    Column {
        Text(label, color = DiveColors.TextMuted, fontSize = 11.sp)
        Text(value, color = DiveColors.Text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

@Composable
private fun IndicatorStrip(
    title: String,
    values: List<Double?>,
    guideLines: List<Double>,
    yMin: Double,
    yMax: Double,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DiveColors.BgCard, RoundedCornerShape(8.dp))
            .border(1.dp, DiveColors.Border, RoundedCornerShape(8.dp))
            .padding(8.dp),
    ) {
        val last = values.lastOrNull { it != null }
        Text(
            "$title · ${last?.let { fmtPct(it) } ?: "—"}",
            color = DiveColors.TextMuted,
            fontSize = 11.sp,
        )
        Canvas(Modifier.fillMaxWidth().height(56.dp)) {
            val w = size.width
            val h = size.height
            val span = (yMax - yMin).takeIf { it > 0 } ?: 1.0
            fun yOf(v: Double) = (h * (1f - ((v - yMin) / span).toFloat())).coerceIn(0f, h)
            guideLines.forEach { g ->
                val y = yOf(g)
                drawLine(DiveColors.Border, Offset(0f, y), Offset(w, y), strokeWidth = 1f)
            }
            val pts = values.mapIndexedNotNull { i, v -> v?.let { i to it } }
            if (pts.size >= 2) {
                val path = Path()
                pts.forEachIndexed { idx, (i, v) ->
                    val x = w * i / (values.size - 1).coerceAtLeast(1)
                    val y = yOf(v)
                    if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawPath(path, DiveColors.Accent, style = Stroke(width = 2f))
            }
        }
    }
}

@Composable
private fun MacdStrip(title: String, series: List<AnalysisPlanMath.MacdPoint>) {
    val last = series.lastOrNull { it.hist != null }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DiveColors.BgCard, RoundedCornerShape(8.dp))
            .border(1.dp, DiveColors.Border, RoundedCornerShape(8.dp))
            .padding(8.dp),
    ) {
        Text(
            "$title · hist ${last?.hist?.let { fmtPct(it) } ?: "—"}",
            color = DiveColors.TextMuted,
            fontSize = 11.sp,
        )
        Canvas(Modifier.fillMaxWidth().height(56.dp)) {
            val w = size.width
            val h = size.height
            val histVals = series.mapNotNull { it.hist }
            val maxAbs = histVals.maxOfOrNull { kotlin.math.abs(it) }?.takeIf { it > 0 } ?: 1.0
            val n = series.size.coerceAtLeast(1)
            series.forEachIndexed { i, pt ->
                val hist = pt.hist ?: return@forEachIndexed
                val x = w * i / n + w / n / 2
                val half = (hist / maxAbs * h / 2).toFloat()
                val col = if (hist >= 0) DiveColors.Green else DiveColors.Red
                drawLine(col, Offset(x, h / 2), Offset(x, h / 2 - half), strokeWidth = (w / n * 0.6f).coerceAtLeast(1f))
            }
        }
    }
}

@Composable
private fun AnalysisMiniChart(
    candles: List<Candle>,
    plan: RiskPlanCalculator.Plan?,
    livePrice: Double?,
    activeSupport: Double?,
    activeResistance: Double?,
    patternHit: PatternDetector.Hit? = null,
    trendSegments: List<TrendLineBuilder.Segment> = emptyList(),
    modifier: Modifier = Modifier,
) {
    val textMeasurer = rememberTextMeasurer()
    val labelStyle = TextStyle(
        color = DiveColors.Text,
        fontSize = 9.sp,
        fontWeight = FontWeight.Bold,
    )
    Box(
        modifier = modifier
            .background(DiveColors.BgCard, RoundedCornerShape(8.dp))
            .border(1.dp, DiveColors.Border, RoundedCornerShape(8.dp))
            .padding(8.dp),
    ) {
        if (candles.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("无 K 线数据", color = DiveColors.TextMuted)
            }
            return
        }
        var yMin = candles.minOf { it.low }
        var yMax = candles.maxOf { it.high }
        plan?.let {
            yMin = min(yMin, min(it.stopLoss, it.takeProfit))
            yMax = max(yMax, max(it.stopLoss, it.takeProfit))
        }
        livePrice?.let {
            yMin = min(yMin, it)
            yMax = max(yMax, it)
        }
        activeSupport?.let { yMin = min(yMin, it) }
        activeResistance?.let { yMax = max(yMax, it) }
        if (yMax <= yMin) yMax = yMin + 1.0
        val pad = (yMax - yMin) * 0.05
        yMin -= pad
        yMax += pad
        val green = DiveColors.Green
        val red = DiveColors.Red
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val n = candles.size
            val slot = w / n.coerceAtLeast(1)
            fun yOf(price: Double): Float {
                val t = ((price - yMin) / (yMax - yMin)).toFloat()
                return h * (1f - t)
            }
            candles.forEachIndexed { i, c ->
                val cx = slot * i + slot / 2
                val yHigh = yOf(c.high)
                val yLow = yOf(c.low)
                val yOpen = yOf(c.open)
                val yClose = yOf(c.close)
                val up = c.close >= c.open
                val col = if (up) green else red
                drawLine(col, Offset(cx, yHigh), Offset(cx, yLow), strokeWidth = 1.5f)
                val top = min(yOpen, yClose)
                val bot = max(yOpen, yClose)
                drawRect(col, Offset(cx - slot * 0.3f, top), Size(slot * 0.6f, (bot - top).coerceAtLeast(1f)))
            }
            fun level(price: Double, color: Color, label: String, dashed: Boolean = false, width: Float = 2f) {
                val y = yOf(price)
                drawLine(
                    color = color,
                    start = Offset(0f, y),
                    end = Offset(w * 0.78f, y),
                    strokeWidth = width,
                    pathEffect = if (dashed) PathEffect.dashPathEffect(floatArrayOf(10f, 8f)) else null,
                )
                val layout = textMeasurer.measure(
                    text = "$label ${AnalysisPlanMath.formatPrice(price)}",
                    style = labelStyle.copy(color = color),
                )
                val lx = (w * 0.78f).coerceAtMost(w - layout.size.width - 4f)
                val ly = (y - layout.size.height / 2).coerceIn(0f, h - layout.size.height)
                drawText(layout, topLeft = Offset(lx, ly))
            }
            // Pattern outline + name
            patternHit?.let { hit ->
                val from = hit.fromIndex.coerceIn(0, n - 1)
                val to = hit.toIndex.coerceIn(from, n - 1)
                val left = slot * from
                val right = slot * (to + 1)
                var top = Float.POSITIVE_INFINITY
                var bot = Float.NEGATIVE_INFINITY
                for (i in from..to) {
                    top = min(top, yOf(candles[i].high))
                    bot = max(bot, yOf(candles[i].low))
                }
                drawRect(
                    Color(0x33FFC107),
                    Offset(left, top),
                    Size((right - left).coerceAtLeast(1f), (bot - top).coerceAtLeast(1f)),
                )
                val nameLayout = textMeasurer.measure(hit.name, style = labelStyle.copy(color = Color(0xFFFFC107)))
                drawText(nameLayout, topLeft = Offset(left.coerceAtLeast(0f), (top - nameLayout.size.height - 2f).coerceAtLeast(0f)))
            }
            trendSegments.forEach { seg ->
                val x0 = slot * seg.fromIndex + slot / 2
                val x1 = slot * seg.toIndex + slot / 2
                val col = if (seg.rising) Color(0xFF66BB88) else Color(0xFFCC6666)
                drawLine(col, Offset(x0, yOf(seg.fromPrice)), Offset(x1, yOf(seg.toPrice)), strokeWidth = 2.5f)
            }
            activeSupport?.let { level(it, Color(0xFF4CAF50), "S1", dashed = true, width = 1.5f) }
            activeResistance?.let { level(it, Color(0xFFFF7043), "R1", dashed = true, width = 1.5f) }
            plan?.let {
                level(it.stopLoss, Color(0xFFCC6666), "SL")
                level(it.entry, Color(0xFFCCCCCC), "ENTRY")
                level(it.takeProfit, Color(0xFF66BB88), "TP")
            }
            livePrice?.let { level(it, DiveColors.Accent, "LAST", dashed = true) }
        }
    }
}


private fun periodMs(tf: String): Long = when (tf) {
    "1m" -> 60_000L
    "3m" -> 180_000L
    "5m" -> 300_000L
    "15m" -> 900_000L
    "30m" -> 1_800_000L
    "1h" -> 3_600_000L
    "2h" -> 7_200_000L
    "4h" -> 14_400_000L
    "6h" -> 21_600_000L
    "8h" -> 28_800_000L
    "12h" -> 43_200_000L
    "1d" -> 86_400_000L
    else -> 900_000L
}

private fun fmtPct(v: Double): String {
    if (!v.isFinite()) return "—"
    return (kotlin.math.round(v * 100.0) / 100.0).toString()
}
