package com.diveintocrypto.android.data.ai

import com.diveintocrypto.android.domain.model.Candle
import com.diveintocrypto.android.domain.model.Signal
import com.diveintocrypto.android.domain.scanner.RiskPlanCalculator
import com.diveintocrypto.android.platform.httpEngine
import com.diveintocrypto.android.platform.nowMillis
import io.ktor.client.HttpClient
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.request.header
import io.ktor.client.request.preparePost
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.client.statement.bodyAsChannel
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.contentType
import io.ktor.http.isSuccess
import io.ktor.utils.io.readUTF8Line
import kotlin.math.abs

/**
 * OpenAI-compatible client with multi-TF context, streaming, follow-ups, and
 * structured AI plan (entry/SL/TP) parsing — Trend-IQ-style analysis layer.
 */
object AiAnalysisClient {

    data class Config(
        val baseUrl: String,
        val apiKey: String,
        val model: String,
    )

    data class TfSlice(
        val timeframe: String,
        val candles: List<Candle>,
    )

    data class MarketContext(
        val symbol: String,
        /** Primary chart timeframe (also first in [multiTf] when present). */
        val timeframe: String,
        val candles: List<Candle>,
        /** Extra timeframes for multi-scale analysis (e.g. 15m + 1h + 4h). */
        val multiTf: List<TfSlice> = emptyList(),
        val signal: Signal,
        val confidence: Int,
        val shouldTrade: Boolean,
        val enginePlan: RiskPlanCalculator.Plan?,
        val support: Double?,
        val resistance: Double?,
        val patternName: String?,
        val livePrice: Double?,
        val userQuestion: String? = null,
        /** Prior turns for follow-up dialogue (role + content). */
        val history: List<Pair<String, String>> = emptyList(),
    )

    data class AiPlan(
        val direction: RiskPlanCalculator.Direction,
        val entry: Double,
        val stopLoss: Double,
        val takeProfit: Double,
        val riskRewardRatio: Double,
        val thesis: String?,
    )

    data class Result(
        val ok: Boolean,
        val text: String,
        val model: String?,
        val latencyMs: Long,
        val error: String? = null,
        val plan: AiPlan? = null,
    )

    fun chatCompletionsUrl(baseUrl: String): String {
        val b = baseUrl.trim().trimEnd('/')
        return when {
            b.endsWith("/chat/completions") -> b
            b.endsWith("/v1") -> "$b/chat/completions"
            else -> "$b/v1/chat/completions"
        }
    }

    private fun client(): HttpClient = HttpClient(httpEngine()) {
        install(HttpTimeout) {
            connectTimeoutMillis = 20_000
            requestTimeoutMillis = 120_000
            socketTimeoutMillis = 120_000
        }
    }

    fun systemPrompt(): String = """
你是资深加密货币合约技术分析交易助手（类似专业图表分析终端）。
根据用户提供的多周期 K 线与辅助信息，完成独立分析并给出可执行参考计划。

必须：
1. 综合多周期结构、动量、关键位，给出方向：LONG / SHORT / NEUTRAL 与核心理由。
2. 给出明确参考价：入场、止损、止盈（数字需合理，空头止损在入场上方、多头止损在入场下方）。
3. 说明失效条件与主要风险；可做突破/跌破情景推演。
4. 简体中文，分点清晰，正文控制在 700 字内。
5. 文末单独输出一个 JSON 代码块（不要省略），格式严格为：
```json
{"direction":"LONG|SHORT|NEUTRAL","entry":0,"stop":0,"target":0,"rr":0,"thesis":"一句话"}
```
6. 声明：研究参考，非投资建议，不构成自动下单。
""".trimIndent()

    fun buildUserPayload(ctx: MarketContext): String {
        val primary = ctx.multiTf.firstOrNull { it.timeframe == ctx.timeframe }?.candles
            ?: ctx.candles
        val stats = candleStats(primary)
        val planLine = ctx.enginePlan?.let {
            "本地引擎参考（可忽略）：入场 ${it.entry} 止损 ${it.stopLoss} 止盈 ${it.takeProfit}"
        } ?: "本地引擎：无方向计划"
        return buildString {
            appendLine("标的：${ctx.symbol}")
            appendLine("主周期：${ctx.timeframe}  现价：${ctx.livePrice ?: primary.lastOrNull()?.close ?: "—"}")
            appendLine("本地共识（参考）：${ctx.signal.name} 置信度 ${ctx.confidence}% shouldTrade=${ctx.shouldTrade}")
            appendLine(planLine)
            appendLine("结构辅助：支撑=${ctx.support ?: "—"} 阻力=${ctx.resistance ?: "—"} 形态=${ctx.patternName ?: "—"}")
            appendLine("主周期统计：N=${stats.count} 区间涨跌%=${stats.rangePct} ATR≈${stats.atrApprox}")
            val tfs = if (ctx.multiTf.isNotEmpty()) ctx.multiTf else listOf(TfSlice(ctx.timeframe, ctx.candles))
            tfs.forEach { slice ->
                val bars = slice.candles.takeLast(40)
                appendLine("--- K线 ${slice.timeframe}（最近 ${bars.size} 根 OHLC）---")
                appendLine(formatOhlc(bars))
            }
            appendLine()
            appendLine(
                ctx.userQuestion?.takeIf { it.isNotBlank() }
                    ?: "请做完整多周期技术分析，并给出你的方向与入场/止损/止盈计划（JSON）。",
            )
        }
    }

    /**
     * Streaming analysis: [onDelta] receives incremental text; returns final [Result] with parsed plan.
     */
    suspend fun analyzeStreaming(
        config: Config,
        ctx: MarketContext,
        onDelta: (String) -> Unit,
    ): Result {
        if (config.apiKey.isBlank()) {
            return Result(false, "", config.model, 0, "未配置 API Key")
        }
        if (ctx.candles.size < 10 && ctx.multiTf.all { it.candles.size < 10 }) {
            return Result(false, "", config.model, 0, "K 线不足")
        }
        val url = chatCompletionsUrl(config.baseUrl)
        val messagesJson = buildMessagesJson(ctx)
        val body = """
            {
              "model": ${jsonStr(config.model)},
              "temperature": 0.35,
              "stream": true,
              "messages": $messagesJson
            }
        """.trimIndent()
        val started = nowMillis()
        val http = client()
        val acc = StringBuilder()
        return try {
            http.preparePost(url) {
                header(HttpHeaders.Authorization, "Bearer ${config.apiKey.trim()}")
                contentType(ContentType.Application.Json)
                setBody(body)
            }.execute { response ->
                if (!response.status.isSuccess()) {
                    val err = response.bodyAsChannel().readRemainingText()
                    return@execute Result(
                        false, "", config.model, nowMillis() - started,
                        "HTTP ${response.status.value}: ${err.take(240)}",
                    )
                }
                val channel = response.bodyAsChannel()
                while (!channel.isClosedForRead) {
                    val line = channel.readUTF8Line() ?: break
                    if (line.isBlank()) continue
                    if (!line.startsWith("data:")) continue
                    val data = line.removePrefix("data:").trim()
                    if (data == "[DONE]") break
                    val piece = extractStreamDelta(data)
                    if (!piece.isNullOrEmpty()) {
                        acc.append(piece)
                        onDelta(piece)
                    }
                }
                val full = acc.toString().trim()
                val latency = nowMillis() - started
                if (full.isEmpty()) {
                    Result(false, "", config.model, latency, "流式响应为空")
                } else {
                    Result(true, full, config.model, latency, null, parseAiPlan(full))
                }
            }
        } catch (t: Throwable) {
            // Fallback: non-stream once
            try {
                analyzeNonStream(config, ctx, started)
            } catch (t2: Throwable) {
                Result(false, acc.toString(), config.model, nowMillis() - started, t.message ?: t2.message)
            }
        } finally {
            http.close()
        }
    }

    suspend fun analyze(config: Config, ctx: MarketContext): Result =
        analyzeStreaming(config, ctx) { }

    private suspend fun analyzeNonStream(config: Config, ctx: MarketContext, started: Long): Result {
        val url = chatCompletionsUrl(config.baseUrl)
        val messagesJson = buildMessagesJson(ctx)
        val body = """
            {
              "model": ${jsonStr(config.model)},
              "temperature": 0.35,
              "stream": false,
              "messages": $messagesJson
            }
        """.trimIndent()
        val http = client()
        return try {
            val response = http.post(url) {
                header(HttpHeaders.Authorization, "Bearer ${config.apiKey.trim()}")
                contentType(ContentType.Application.Json)
                setBody(body)
            }
            val raw = response.bodyAsText()
            val latency = nowMillis() - started
            if (!response.status.isSuccess()) {
                Result(false, "", config.model, latency, "HTTP ${response.status.value}: ${raw.take(240)}")
            } else {
                val text = extractAssistantText(raw)?.trim().orEmpty()
                if (text.isEmpty()) Result(false, "", config.model, latency, "无 content")
                else Result(true, text, config.model, latency, null, parseAiPlan(text))
            }
        } finally {
            http.close()
        }
    }

    private fun buildMessagesJson(ctx: MarketContext): String {
        val parts = mutableListOf<String>()
        parts.add("""{"role":"system","content":${jsonStr(systemPrompt())}}""")
        ctx.history.takeLast(6).forEach { (role, content) ->
            val r = if (role == "assistant") "assistant" else "user"
            parts.add("""{"role":${jsonStr(r)},"content":${jsonStr(content)}}""")
        }
        parts.add("""{"role":"user","content":${jsonStr(buildUserPayload(ctx))}}""")
        return parts.joinToString(",", prefix = "[", postfix = "]")
    }

    /** Parse trailing JSON plan from model output. */
    fun parseAiPlan(fullText: String): AiPlan? {
        val jsonBlob = extractJsonObject(fullText) ?: return null
        val directionRaw = readJsonField(jsonBlob, "direction")?.uppercase() ?: return null
        val direction = when {
            directionRaw.contains("LONG") || directionRaw.contains("BUY") -> RiskPlanCalculator.Direction.LONG
            directionRaw.contains("SHORT") || directionRaw.contains("SELL") -> RiskPlanCalculator.Direction.SHORT
            else -> return null
        }
        val entry = readJsonNumber(jsonBlob, "entry") ?: return null
        val stop = readJsonNumber(jsonBlob, "stop") ?: readJsonNumber(jsonBlob, "stopLoss") ?: return null
        val target = readJsonNumber(jsonBlob, "target") ?: readJsonNumber(jsonBlob, "takeProfit") ?: return null
        if (entry <= 0 || stop <= 0 || target <= 0) return null
        val valid = when (direction) {
            RiskPlanCalculator.Direction.LONG -> stop < entry && target > entry
            RiskPlanCalculator.Direction.SHORT -> stop > entry && target < entry
        }
        if (!valid) return null
        val risk = abs(entry - stop)
        val reward = abs(target - entry)
        val rr = if (risk > 0) reward / risk else 0.0
        val thesis = readJsonField(jsonBlob, "thesis")
        return AiPlan(direction, entry, stop, target, rr, thesis)
    }

    fun toRiskPlan(ai: AiPlan): RiskPlanCalculator.Plan {
        val risk = abs(ai.entry - ai.stopLoss)
        val reward = abs(ai.takeProfit - ai.entry)
        return RiskPlanCalculator.Plan(
            entry = ai.entry,
            stopLoss = ai.stopLoss,
            takeProfit = ai.takeProfit,
            riskPerUnit = risk,
            rewardPerUnit = reward,
            riskRewardRatio = if (risk > 0) reward / risk else ai.riskRewardRatio,
            stopDistancePercent = if (ai.entry > 0) risk / ai.entry * 100.0 else 0.0,
        )
    }

    internal fun extractStreamDelta(data: String): String? {
        // "delta":{"content":"..."} or "text":"..."
        val idx = data.indexOf("\"content\"")
        if (idx >= 0) {
            val start = data.indexOf('"', idx + 9)
            // find : then "
            val colon = data.indexOf(':', idx)
            if (colon > 0) {
                val q = data.indexOf('"', colon + 1)
                if (q >= 0) return readJsonString(data, q)
            }
        }
        return null
    }

    internal fun extractAssistantText(json: String): String? {
        val markers = listOf("\"content\":")
        for (m in markers) {
            var idx = 0
            while (true) {
                val p = json.indexOf(m, idx)
                if (p < 0) break
                val colon = json.indexOf(':', p)
                val start = json.indexOf('"', colon + 1)
                if (start < 0) break
                val parsed = readJsonString(json, start)
                if (parsed != null && parsed.length > 10) return parsed
                idx = start + 1
            }
        }
        return null
    }

    private fun extractJsonObject(text: String): String? {
        val fence = text.indexOf("```")
        if (fence >= 0) {
            val after = text.indexOf('{', fence)
            val endFence = text.indexOf("```", fence + 3)
            if (after >= 0) {
                val end = text.indexOf('}', after)
                // find matching last } before end fence or use balanced
                val slice = if (endFence > after) text.substring(after, endFence) else text.substring(after)
                val balanced = takeBalancedObject(slice)
                if (balanced != null) return balanced
            }
        }
        val last = text.lastIndexOf('{')
        if (last >= 0) return takeBalancedObject(text.substring(last))
        return null
    }

    private fun takeBalancedObject(s: String): String? {
        var depth = 0
        var start = -1
        for (i in s.indices) {
            when (s[i]) {
                '{' -> {
                    if (depth == 0) start = i
                    depth++
                }
                '}' -> {
                    depth--
                    if (depth == 0 && start >= 0) return s.substring(start, i + 1)
                }
            }
        }
        return null
    }

    private fun readJsonField(obj: String, key: String): String? {
        val k = "\"$key\""
        val p = obj.indexOf(k)
        if (p < 0) return null
        val colon = obj.indexOf(':', p + k.length)
        if (colon < 0) return null
        var i = colon + 1
        while (i < obj.length && obj[i].isWhitespace()) i++
        if (i >= obj.length) return null
        return if (obj[i] == '"') readJsonString(obj, i) else {
            val end = obj.indexOfAny(charArrayOf(',', '}'), i).let { if (it < 0) obj.length else it }
            obj.substring(i, end).trim().trim('"')
        }
    }

    private fun readJsonNumber(obj: String, key: String): Double? =
        readJsonField(obj, key)?.toDoubleOrNull()

    private fun readJsonString(s: String, startQuote: Int): String? {
        if (startQuote >= s.length || s[startQuote] != '"') return null
        val out = StringBuilder()
        var i = startQuote + 1
        while (i < s.length) {
            val c = s[i]
            when {
                c == '\\' && i + 1 < s.length -> {
                    when (val n = s[i + 1]) {
                        'n' -> out.append('\n')
                        't' -> out.append('\t')
                        'r' -> out.append('\r')
                        '"' -> out.append('"')
                        '\\' -> out.append('\\')
                        else -> out.append(n)
                    }
                    i += 2
                }
                c == '"' -> return out.toString()
                else -> {
                    out.append(c)
                    i++
                }
            }
        }
        return null
    }

    private fun jsonStr(s: String): String {
        val escaped = buildString {
            for (c in s) {
                when (c) {
                    '\\' -> append("\\\\")
                    '"' -> append("\\\"")
                    '\n' -> append("\\n")
                    '\r' -> append("\\r")
                    '\t' -> append("\\t")
                    else -> append(c)
                }
            }
        }
        return "\"$escaped\""
    }

    private fun formatOhlc(candles: List<Candle>): String =
        candles.joinToString("\n") { c ->
            "t=${c.openTime} o=${c.open} h=${c.high} l=${c.low} c=${c.close} v=${c.volume}"
        }

    private data class Stats(val count: Int, val rangePct: String, val atrApprox: String)

    private fun candleStats(candles: List<Candle>): Stats {
        if (candles.isEmpty()) return Stats(0, "—", "—")
        val first = candles.first().close
        val last = candles.last().close
        val range = if (first > 0) ((last - first) / first * 100.0) else 0.0
        val trs = candles.zipWithNext { a, b ->
            maxOf(b.high - b.low, abs(b.high - a.close), abs(b.low - a.close))
        }
        val atr = if (trs.isEmpty()) 0.0 else trs.takeLast(14).average()
        return Stats(
            count = candles.size,
            rangePct = (kotlin.math.round(range * 100) / 100.0).toString(),
            atrApprox = (kotlin.math.round(atr * 1e6) / 1e6).toString(),
        )
    }

    private suspend fun io.ktor.utils.io.ByteReadChannel.readRemainingText(): String {
        val sb = StringBuilder()
        while (!isClosedForRead) {
            val line = readUTF8Line() ?: break
            sb.appendLine(line)
        }
        return sb.toString()
    }
}
