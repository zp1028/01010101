# 彩析 v2.4.0-AI 更新日志

## 🧠 AI 大模型视觉执行（核心功能）

### 新增功能
- **AI 视觉执行器**：基于多模态 LLM 的页面理解与自动化执行
- **三种 LLM 提供商支持**：
  - OpenAI (GPT-4o / GPT-4o-mini)
  - Anthropic (Claude 3.5 Sonnet)
  - Google (Gemini 1.5 Pro / Flash)
- **智能执行模式**：AI 视觉 → WebView → 无障碍，自动降级
- **执行后校验**：截图二次确认，失败自动重试
- **AI 设置页面**：完整的 LLM 配置、测试、保存界面

### 技术架构
```
BetCommand → ExecutorManager → [AI Vision] → [WebView] → [Accessibility]
                ↓
         PerceptionEngine (截图 + Accessibility节点树)
                ↓
         LlmClient (多模态API调用)
                ↓
         AiVisionExecutor (手势执行 + 结果校验)
```

### 新增文件
| 文件 | 路径 | 说明 |
|------|------|------|
| AiVisionExecutor.kt | domain/execution/ | AI视觉执行器核心 |
| LlmClient.kt | domain/execution/ | LLM API客户端 |
| PerceptionEngine.kt | domain/execution/ | 截图+节点树提取 |
| AiPromptBuilder.kt | domain/execution/ | 多模态Prompt构建 |
| ActionParser.kt | domain/execution/ | LLM响应解析 |
| LlmConfigStore.kt | data/config/ | LLM配置本地存储 |
| AiSettingsScreen.kt | ui/screens/ | AI设置UI界面 |
| AiSettingsActivity.kt | ui/screens/ | AI设置Activity |

### 修改文件
| 文件 | 修改内容 |
|------|---------|
| accessibility_service_config.xml | 添加 canTakeScreenshot="true" |
| ExecutorManager.kt | 添加 ai_vision 优先级 |
| CaiFenXiApplication.kt | 注册AI执行器 |
| build.gradle.kts | 添加 kotlinx-datetime依赖，版本号2.4.0-AI |
| AndroidManifest.xml | 添加 AiSettingsActivity |
| MoreScreen.kt | 添加AI设置入口 |
| CaiFenXiApp.kt | 添加 ai_settings 路由 |
| SettingsScreen.kt | 添加AI设置导航 |
| README.md | 更新AI功能说明 |

### 使用说明
1. 打开「更多 → 🧠 AI 大模型设置」
2. 选择提供商并输入API Key
3. 选择模型（推荐GPT-4o-mini降低成本）
4. 选择执行模式（自动/仅AI/仅网页/仅无障碍）
5. 点击「测试连接」验证
6. 保存配置即可使用

### 成本参考
| 模型 | 单次投注 | 月费用(1000次) |
|------|---------|---------------|
| GPT-4o-mini | ~¥0.03 | ~¥30 |
| GPT-4o | ~¥0.15 | ~¥150 |
| Claude 3.5 | ~¥0.50 | ~¥500 |

### 注意事项
- AI模式需要设备联网
- 需要开启无障碍服务（用于截图和手势执行）
- Android 11+ 支持原生截图，低版本需MediaProjection授权
- API Key 请妥善保管，建议使用环境变量或加密存储

---

## 兼容性
- 最低 Android 7.0 (API 24)
- 编译 SDK 35
- Kotlin 2.0.20
- Jetpack Compose 2024.09

AI Agent V2 completed: 2026-09-05
