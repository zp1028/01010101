/* cfx_inject.js - Core DOM scoring & click logic for GenericSiteAdapter
 * Loaded from assets at runtime, injected via WebView.evaluateJavascript
 * This file contains all __cfx* helper functions and the main __caiFenXiRunCommand entry point
 */

function __cfxNorm(s){ return (s||'').replace(/\s+/g,'').trim(); }
function __cfxVisible(el){
  if(!el||el.disabled) return false;
  var st=window.getComputedStyle(el);
  if(st.display==='none'||st.visibility==='hidden'||parseFloat(st.opacity||'1')===0) return false;
  var r=el.getBoundingClientRect();
  return r.width>8&&r.height>8&&r.bottom>0&&r.top<innerHeight&&r.right>0&&r.left<innerWidth;
}
function __cfxBlob(el){
  var bits=[el.className&&String(el.className), el.id,
    el.getAttribute('data-type'), el.getAttribute('data-play'),
    el.getAttribute('data-name'), el.getAttribute('data-value'),
    el.getAttribute('aria-label'), el.name, el.getAttribute('title')];
  return bits.filter(Boolean).join(' ').toLowerCase();
}
function __cfxPath(el){
  var s='', cur=el, d=0;
  while(cur&&d<6){ s+=' '+__cfxBlob(cur); cur=cur.parentElement; d++; }
  return s.toLowerCase();
}
function __cfxOwnText(el){
  var t='';
  for(var i=0;i<el.childNodes.length;i++){
    var n=el.childNodes[i];
    if(n.nodeType===3) t+=n.nodeValue||'';
  }
  var own=__cfxNorm(t);
  if(own) return own;
  if(el.tagName&&el.tagName.toLowerCase()==='input') return __cfxNorm(el.value||el.getAttribute('value')||'');
  if(!el.children||el.children.length===0) return __cfxNorm(el.innerText||el.textContent||'');
  return '';
}
var __CFX_BET_HINTS=['bet','play','wager','order','touzhu','xz','chip','game-bet','betting','handicap','盘口','投注','下注','玩法','赔率','选号'];
var __CFX_NOISE=['history','record','trend','chart','help','rule','notice','news','draw','open','result','statistic','统计','历史','走势','说明','开奖','记录','规则','公告','新闻','教程','客服','关于'];
function __cfxInRegion(el){
  var R=window.__CFX_REGION;
  if(!R||!R.enabled) return true;
  var r=el.getBoundingClientRect();
  var cx=r.left+r.width/2, cy=r.top+r.height/2;
  var L=innerWidth*(R.left||0)/100, T=innerHeight*(R.top||0)/100;
  var Rt=innerWidth*(R.right||100)/100, B=innerHeight*(R.bottom||100)/100;
  return cx>=L&&cx<=Rt&&cy>=T&&cy<=B;
}
function __cfxScore(el, label){
  if(!__cfxVisible(el)) return -1e9;
  if(!__cfxInRegion(el)) return -1e9;
  var own=__cfxOwnText(el);
  var full=__cfxNorm(el.innerText||el.textContent||'');
  if(own!==label && full!==label){
    var ownHasLabel = own.indexOf(label)>=0 && own.length<=8;
    var labelHasOwn = own.length>0 && label.indexOf(own)>=0;
    if(!ownHasLabel && !labelHasOwn) return -1e9;
  }
  if(full.length>30 && full!==label) return -1e9;
  if(el.children && el.children.length>12) return -1e9;
  var rect=el.getBoundingClientRect();
  var blob=__cfxPath(el);
  var score=0;
  var tag=(el.tagName||'').toLowerCase();
  if(own===label || full===label) score+=50;
  if(tag==='button'||tag==='a') score+=40;
  if(el.getAttribute('role')==='button') score+=30;
  if(typeof el.onclick==='function'||el.hasAttribute('ng-click')||el.hasAttribute('@click')||el.hasAttribute('onclick')) score+=25;
  if(tag==='input'&&/button|submit/.test(el.type||'')) score+=35;
  if(tag==='div'||tag==='span'||tag==='li'||tag==='label'||tag==='p'||tag==='i'||tag==='em') score+=5;
  for(var i=0;i<__CFX_BET_HINTS.length;i++){ if(blob.indexOf(__CFX_BET_HINTS[i])>=0) score+=28; }
  for(var j=0;j<__CFX_NOISE.length;j++){ if(blob.indexOf(__CFX_NOISE[j])>=0) score-=80; }
  var area=rect.width*rect.height;
  if(rect.width>=24&&rect.width<=200&&rect.height>=22&&rect.height<=90) score+=30;
  if(area<180||area>60000) score-=30;
  var cy=rect.top+rect.height/2;
  if(cy>innerHeight*0.18&&cy<innerHeight*0.92) score+=15;
  if(cy<innerHeight*0.12) score-=40;
  if(cy>innerHeight*0.96) score-=20;
  var parent=el.parentElement;
  if(parent){
    var sib=__cfxNorm(parent.innerText||'');
    if(sib.length<=20){
      if((label==='大'||label==='小')&&sib.indexOf('大')>=0&&sib.indexOf('小')>=0) score+=35;
      if((label==='单'||label==='双')&&sib.indexOf('单')>=0&&sib.indexOf('双')>=0) score+=35;
    } else {
      score-=15;
    }
  }
  if(/active|selected|on|checked|current|choose/.test(blob)) score+=8;
  return score;
}
function __cfxFindBest(label){
  var want=__cfxNorm(label);
  var best=null, bestScore=20;
  // Round 1: high-priority elements only (button, a, role=button, input)
  var prioritySelector='button,a,[role=button],input[type=button],input[type=submit],label,li';
  var allNodes=[];
  try{
    allNodes=allNodes.concat(Array.prototype.slice.call(document.querySelectorAll(prioritySelector)));
  }catch(e){}
  // Round 2: if no hit, expand to all tags
  if(!best){
    var expandedSelector='button,a,[role=button],input[type=button],input[type=submit],label,li,span,div,p,i,em';
    try{
      allNodes=allNodes.concat(Array.prototype.slice.call(document.querySelectorAll(expandedSelector)));
    }catch(e){}
    try{
      var frames=document.querySelectorAll('iframe');
      for(var fi=0;fi<frames.length;fi++){
        try{
          var fd=frames[fi].contentDocument||frames[fi].contentWindow.document;
          if(fd){
            allNodes=allNodes.concat(Array.prototype.slice.call(fd.querySelectorAll(expandedSelector)));
          }
        }catch(e){ }
      }
    }catch(e){}
  }
  for(var i=0;i<allNodes.length;i++){
    var el=allNodes[i];
    if(el.closest && el.closest('header,nav,footer,aside')) continue;
    if(!__cfxInRegion(el)) continue;
    var own=__cfxOwnText(el);
    var full=__cfxNorm(el.innerText||el.textContent||'');
    if(want.length>=2){
      if(own!==want && full!==want && !(own.length>0 && want.indexOf(own)>=0) && !(full.length<=20 && full.indexOf(want)>=0)) continue;
      var sc=__cfxScore(el, want);
      if(own===want||full===want) sc+=40;
      if(sc>bestScore){ bestScore=sc; best=el; }
      continue;
    }
    var sc2=__cfxScore(el, want);
    if(sc2>bestScore){ bestScore=sc2; best=el; }
  }
  return best?{el:best,score:bestScore}:null;
}
function __cfxHighlight(el, ok){
  if(!el) return;
  var prev=el.style.outline;
  el.style.outline=ok?'3px solid #00c853':'3px solid #ff1744';
  setTimeout(function(){ el.style.outline=prev; }, 1200);
}
function __cfxClick(el){
  el.scrollIntoView({block:'center',inline:'center'});
  var o={bubbles:true,cancelable:true,view:window};
  el.dispatchEvent(new MouseEvent('mouseover',o));
  el.dispatchEvent(new MouseEvent('mousedown',o));
  el.dispatchEvent(new MouseEvent('mouseup',o));
  el.dispatchEvent(new MouseEvent('click',o));
  if(typeof el.click==='function') el.click();
}
function __cfxSleep(ms){
  var t0=Date.now();
  while(Date.now()-t0<ms){ }
}
function __cfxFindConfirm(){
  var texts=['确认投注','立即下注','马上投注','确认下注','提交订单','立即投注','确认','确定','提交','下注','是的','同意','继续','我知道了','知道了','OK','Ok','ok','YES','Yes','验证通过','二次确认'];
  var nodes=document.querySelectorAll('button,a,[role=button],input[type=button],input[type=submit],div,span');
  var best=null, bestScore=25;
  for(var i=0;i<nodes.length;i++){
    var el=nodes[i];
    if(!__cfxVisible(el)) continue;
    var text=__cfxNorm(el.innerText||el.value||el.getAttribute('aria-label')||'');
    if(!text||text.length>16) continue;
    var hit=-1;
    for(var t=0;t<texts.length;t++){
      if(text===texts[t]||text.indexOf(texts[t])>=0){ hit=t; break; }
    }
    if(hit<0) continue;
    var sc=40-Math.min(hit,15);
    var blob=__cfxPath(el);
    for(var h=0;h<__CFX_BET_HINTS.length;h++) if(blob.indexOf(__CFX_BET_HINTS[h])>=0) sc+=15;
    for(var n=0;n<__CFX_NOISE.length;n++) if(blob.indexOf(__CFX_NOISE[n])>=0) sc-=50;
    if(el.closest && (el.closest('.modal')||el.closest('[class*=dialog]')||el.closest('[class*=popup]')||el.closest('[class*=mask]')||el.closest('[class*=confirm]'))) sc+=25;
    var r=el.getBoundingClientRect();
    if(r.width>=48&&r.height>=28) sc+=12;
    if(sc>bestScore){ bestScore=sc; best=el; }
  }
  return best;
}
function __cfxInputAmount(amount){
  if(!amount) return {ok:true,message:'无金额'};
  var inputs=document.querySelectorAll('input[type=text],input[type=number],input:not([type]),textarea');
  var target=null, bestSc=-1;
  for(var i=0;i<inputs.length;i++){
    var el=inputs[i];
    if(!__cfxVisible(el)) continue;
    var blob=(__cfxPath(el)+' '+(el.placeholder||'')+' '+(el.name||'')).toLowerCase();
    var sc=0;
    if(/金额|额度|amount|money|bet|投注|下注|元/.test(blob)) sc+=30;
    if(/search|user|pass|账号|密码|手机/.test(blob)) sc-=50;
    if(__cfxInRegion(el)) sc+=10;
    if(sc>bestSc){ bestSc=sc; target=el; }
  }
  if(!target||bestSc<0){
    var chip=__cfxFindBest(String(amount));
    if(chip){ __cfxHighlight(chip.el,true); __cfxClick(chip.el); return {ok:true,message:'点筹码'+amount}; }
    return {ok:false,message:'未找到金额框'};
  }
  target.focus();
  target.value='';
  target.value=String(amount);
  try{ target.dispatchEvent(new InputEvent('input',{bubbles:true,data:String(amount)})); }catch(e){ target.dispatchEvent(new Event('input',{bubbles:true})); }
  target.dispatchEvent(new Event('change',{bubbles:true}));
  target.dispatchEvent(new Event('blur',{bubbles:true}));
  return {ok:true,message:'已填金额'+amount};
}
function __cfxConfirmLoop(dryRun, maxRound, confirmSelector){
  var rounds=[];
  maxRound = maxRound||4;
  for(var r=0;r<maxRound;r++){
    var conf=null;
    /* ① selector 精确优先 */
    if(confirmSelector){
      try{ conf=document.querySelector(confirmSelector); }catch(e){}
      if(conf && !__cfxVisible(conf)) conf=null;
    }
    /* ② 无 selector 或失配 → 评分兜底 */
    if(!conf) conf=__cfxFindConfirm();
    if(!conf){
      rounds.push({round:r+1,ok:false,detail:'无确认钮'});
      break;
    }
    var txt=__cfxNorm(conf.innerText||conf.value||'');
    __cfxHighlight(conf,true);
    if(!dryRun) __cfxClick(conf);
    rounds.push({round:r+1,ok:true,text:txt});
    __cfxSleep(350);
  }
  return rounds;
}
window.__caiFenXiRunCommand=function(CMD){
  var steps=[];
  try{
    window.__CFX_REGION = CMD.region || {enabled:false};
    if(!CMD||!CMD.bets||!CMD.bets.length){
      return {ok:false,message:'指令无注项',steps:steps};
    }
    for(var i=0;i<CMD.bets.length;i++){
      var bet=CMD.bets[i];
      var logical=bet.value||'';
      var label=bet.pageText|| (CMD.labelMap&&CMD.labelMap[logical]) || logical;
      if(!label) continue;
      /* ① selector 精确优先（用户标注过） */
      var selStr=CMD.selectors && CMD.selectors[logical];
      if(selStr){
        try{
          var selEl=document.querySelector(selStr);
          if(selEl && __cfxVisible(selEl)){
            __cfxHighlight(selEl,true);
            if(!CMD.dryRun) __cfxClick(selEl);
            steps.push({step:'play:'+logical+'→selector',ok:true,method:'selector'});
            __cfxSleep(280);
            continue;
          }
        }catch(e){}
      }
      /* ② 无 selector 或失配 → DOM 评分兜底 */
      var hit=__cfxFindBest(label);
      if(!hit){
        hit=__cfxFindBest(label.replace(/\s+/g,''));
      }
      if(!hit){
        var core=label.replace(/[^大小单双龙虎]/g,'');
        if(core && core!==label) hit=__cfxFindBest(core);
      }
      if(!hit){
        steps.push({step:'play:'+logical+'→'+label,ok:false});
        return {ok:false,message:'未找到玩法【'+label+'】',steps:steps};
      }
      __cfxHighlight(hit.el,true);
      if(!CMD.dryRun) __cfxClick(hit.el);
      steps.push({step:'play:'+logical+'→'+label,ok:true,score:hit.score});
      __cfxSleep(280);
    }
    /* 金额输入：selector 精确优先 */
    var amtOk=false, amtMsg='';
    if(CMD.selectors && CMD.selectors.selector_amount && CMD.amount){
      try{
        var amtEl=document.querySelector(CMD.selectors.selector_amount);
        if(amtEl && __cfxVisible(amtEl)){
          amtEl.focus();
          amtEl.value='';
          amtEl.value=String(CMD.amount);
          try{ amtEl.dispatchEvent(new InputEvent('input',{bubbles:true,data:String(CMD.amount)})); }catch(e){ amtEl.dispatchEvent(new Event('input',{bubbles:true})); }
          amtEl.dispatchEvent(new Event('change',{bubbles:true}));
          amtEl.dispatchEvent(new Event('blur',{bubbles:true}));
          amtOk=true; amtMsg='selector已填金额'+CMD.amount;
        }
      }catch(e){}
    }
    if(!amtOk){
      var amt=__cfxInputAmount(CMD.amount);
      amtOk=!!amt.ok; amtMsg=amt.message;
    }
    steps.push({step:'amount',ok:amtOk,detail:amtMsg});
    if(!amtOk) return {ok:false,message:amtMsg,steps:steps};
    __cfxSleep(280);
    var confirms=__cfxConfirmLoop(!!CMD.dryRun, 4, CMD.selectors&&CMD.selectors.selector_confirm);
    steps.push({step:'confirm',ok:confirms.some(function(x){return x.ok;}),rounds:confirms});
    var anyConfirm=confirms.some(function(x){return x.ok;});
    if(!anyConfirm){
      return {ok:false,message:'未找到确认/验证按钮',steps:steps};
    }
    return {
      ok:true,
      message:'完成:玩法→金额→确认'+(confirms.length>1?('×'+confirms.filter(function(x){return x.ok;}).length):''),
      steps:steps
    };
  }catch(err){
    return {ok:false,message:String(err&&err.message||err),steps:steps};
  }
};
