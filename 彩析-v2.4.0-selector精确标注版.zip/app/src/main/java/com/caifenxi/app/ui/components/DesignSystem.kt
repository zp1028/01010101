package com.caifenxi.app.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.ui.theme.CaiTokens
import com.caifenxi.app.ui.theme.LocalCaiElevation

/**
 * 页面容器：左右 24、底 34（对齐提示词 ScreenContainer）
 */
@Composable
fun ScreenContainer(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(
                start = CaiTokens.ScreenHPadding,
                end = CaiTokens.ScreenHPadding,
                top = CaiTokens.S16,
                bottom = CaiTokens.ScreenBottom
            ),
        content = content
    )
}

/** GlobalCard：20 圆角 + 柔和阴影 elevation 5 */
@Composable
fun GlobalCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    containerColor: Color = MaterialTheme.colorScheme.surface,
    content: @Composable ColumnScope.() -> Unit
) {
    val elev = LocalCaiElevation.current
    val shape = RoundedCornerShape(CaiTokens.RadiusCard)
    Card(
        modifier = modifier
            .fillMaxWidth()
            .shadow(
                elevation = elev.cardElevation,
                shape = shape,
                ambientColor = Color.Black.copy(alpha = elev.cardAlpha),
                spotColor = Color.Black.copy(alpha = elev.cardAlpha)
            )
            .then(
                if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
            ),
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = containerColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(Modifier.padding(CaiTokens.S16), content = content)
    }
}

/** PrimaryButton：胶囊 + 按压缩放反馈 */
@Composable
fun PrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    ghost: Boolean = false,
    enabled: Boolean = true
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.96f else 1f,
        animationSpec = tween(durationMillis = 180),
        label = "btnScale"
    )
    val shape = RoundedCornerShape(CaiTokens.RadiusButton)
    if (ghost) {
        OutlinedButton(
            onClick = onClick,
            enabled = enabled,
            modifier = modifier.scale(scale),
            shape = shape,
            interactionSource = interaction,
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = MaterialTheme.colorScheme.primary
            )
        ) {
            Text(text, fontWeight = FontWeight.SemiBold)
        }
    } else {
        Button(
            onClick = onClick,
            enabled = enabled,
            modifier = modifier.scale(scale),
            shape = shape,
            interactionSource = interaction,
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.secondary,
                contentColor = MaterialTheme.colorScheme.onSecondary
            ),
            contentPadding = PaddingValues(horizontal = CaiTokens.S24, vertical = CaiTokens.S12)
        ) {
            Text(text, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(bottom = CaiTokens.S8, top = CaiTokens.S8)
    )
}

@Composable
fun CaptionMuted(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@Composable
fun AccentTag(text: String, danger: Boolean = false) {
    val bg = if (danger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary
    val fg = if (danger) Color.White else MaterialTheme.colorScheme.onSecondary
    Box(
        Modifier
            .clip(RoundedCornerShape(CaiTokens.RadiusIcon))
            .background(bg)
            .padding(horizontal = CaiTokens.S12, vertical = CaiTokens.S4)
    ) {
        Text(text, color = fg, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
    }
}

// ========== 骨架屏 ==========

/** 骨架块：灰色占位 + 呼吸闪烁 */
@Composable
fun SkeletonBlock(
    modifier: Modifier = Modifier,
    height: androidx.compose.ui.unit.Dp = 16.dp
) {
    val transition = rememberInfiniteTransition(label = "skeleton")
    val alpha by transition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.6f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 800, easing = LinearEasing),
            repeatMode = androidx.compose.animation.core.RepeatMode.Reverse
        ),
        label = "skeletonAlpha"
    )
    Box(
        modifier
            .height(height)
            .clip(RoundedCornerShape(CaiTokens.RadiusSmall))
            .background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = alpha * 0.3f))
    )
}

/** 骨架卡片：模拟 GlobalCard 结构 */
@Composable
fun SkeletonCard(modifier: Modifier = Modifier) {
    GlobalCard(modifier = modifier) {
        SkeletonBlock(height = 20.dp, modifier = Modifier.fillMaxWidth(0.6f))
        Spacer(Modifier.height(CaiTokens.S8))
        SkeletonBlock(height = 14.dp, modifier = Modifier.fillMaxWidth(0.9f))
        Spacer(Modifier.height(CaiTokens.S4))
        SkeletonBlock(height = 14.dp, modifier = Modifier.fillMaxWidth(0.8f))
        Spacer(Modifier.height(CaiTokens.S8))
        Row(horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)) {
            SkeletonBlock(height = 28.dp, modifier = Modifier.width(60.dp))
            SkeletonBlock(height = 28.dp, modifier = Modifier.width(60.dp))
        }
    }
}

/** 骨架列表：多张骨架卡片 */
@Composable
fun SkeletonList(count: Int = 3) {
    Column(verticalArrangement = Arrangement.spacedBy(CaiTokens.S12)) {
        repeat(count) { SkeletonCard(Modifier.fillMaxWidth()) }
    }
}

// ========== 入场动画 ==========

/** 淡入+上滑入场：页面内容首次渲染时的过渡 */
@Composable
fun FadeInSlideUp(
    visible: Boolean = true,
    content: @Composable () -> Unit
) {
    val alpha = remember { Animatable(if (visible) 0f else 1f) }
    val offsetY = remember { Animatable(if (visible) 30f else 0f) }
    LaunchedEffect(visible) {
        if (visible) {
            alpha.animateTo(1f, tween(CaiTokens.AnimNormal))
            offsetY.animateTo(0f, tween(CaiTokens.AnimNormal))
        }
    }
    Box(
        Modifier
            .graphicsLayer {
                this.alpha = alpha.value
                translationY = offsetY.value
            }
    ) { content() }
}

/** 列表项交错入场：index 越大延迟越久 */
@Composable
fun StaggeredEntrance(
    index: Int,
    content: @Composable () -> Unit
) {
    val delayMs = (index * 50L).coerceAtMost(300L)
    val alpha = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(delayMs)
        alpha.animateTo(1f, tween(CaiTokens.AnimNormal))
    }
    Box(Modifier.graphicsLayer { this.alpha = alpha.value }) { content() }
}

// ========== 确认弹窗 ==========

/** 操作确认弹窗：危险操作前二次确认 */
@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    confirmLabel: String = "确认",
    cancelLabel: String = "取消",
    danger: Boolean = false,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = { Text(message, style = MaterialTheme.typography.bodyMedium) },
        confirmButton = {
            TextButton(
                onClick = onConfirm,
                colors = if (danger) ButtonDefaults.textButtonColors(
                    contentColor = MaterialTheme.colorScheme.error
                ) else ButtonDefaults.textButtonColors()
            ) { Text(confirmLabel, fontWeight = FontWeight.SemiBold) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(cancelLabel) }
        }
    )
}

// ========== 信息横幅 ==========

/** 信息横幅：success / warning / error / info 四态 */
@Composable
fun InfoBanner(
    message: String,
    type: BannerType = BannerType.INFO,
    modifier: Modifier = Modifier,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    val (bg, fg, icon) = when (type) {
        BannerType.SUCCESS -> Triple(CaiTokens.SuccessBg, CaiTokens.Success, "✓")
        BannerType.WARNING -> Triple(CaiTokens.WarningBg, CaiTokens.Warning, "⚠")
        BannerType.ERROR -> Triple(CaiTokens.DangerBg, CaiTokens.Danger, "✕")
        BannerType.INFO -> Triple(CaiTokens.InfoBg, CaiTokens.Info, "ℹ")
    }
    Row(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(CaiTokens.RadiusIcon))
            .background(bg)
            .padding(horizontal = CaiTokens.S12, vertical = CaiTokens.S8),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(icon, color = fg, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.width(CaiTokens.S8))
        Text(
            message,
            color = fg,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.weight(1f)
        )
        if (actionLabel != null && onAction != null) {
            TextButton(onClick = onAction) { Text(actionLabel, fontSize = 12.sp) }
        }
    }
}

enum class BannerType { SUCCESS, WARNING, ERROR, INFO }
