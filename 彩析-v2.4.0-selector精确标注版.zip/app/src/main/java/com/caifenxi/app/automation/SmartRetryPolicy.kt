package com.caifenxi.app.automation

/** 按失败原因决定重试 / 停 / 等下期 */
object SmartRetryPolicy {
    sealed class Action {
        object GiveUp : Action()
        object AlertPause : Action()
        object DeferNextPeriod : Action()
        data class Retry(val delayMs: Long) : Action()
    }

    private val backoff = longArrayOf(3_000L, 10_000L, 30_000L)

    fun decide(reason: String, attempt: Int): Action {
        val r = reason.uppercase()
        return when {
            r.contains("PLATFORM_REJECT") || r.contains("余额") -> Action.GiveUp
            r.contains("SELECTOR_CONFIG_BROKEN") ||
                r.contains("PAGE_NOT_READY") ||
                r.contains("NO_BET") ||
                r.contains("未找到") ||
                r.contains("ELEMENT_NOT_FOUND") -> Action.AlertPause
            r.contains("MARKET_CLOSED") || r.contains("封盘") -> Action.DeferNextPeriod
            attempt < backoff.size -> Action.Retry(backoff[attempt])
            else -> Action.GiveUp
        }
    }
}
