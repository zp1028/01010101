package com.caifenxi.app.automation

import org.json.JSONObject

/**
 * 本地/内置选择器配置（不依赖 Moshi）。
 * 改版时改 selectors.json 即可，无需发版。
 */
data class BetAutomationConfig(
    val platform: String = "default",
    val version: String = "",
    val selectors: Selectors = Selectors(),
    val timing: Timing = Timing(),
    val options: Options = Options()
) {
    data class Selectors(
        val pageReady: String = ".bet-panel, .lottery-panel",
        val dxBig: String = "",
        val dxSmall: String = "",
        val dsOdd: String = "",
        val dsEven: String = "",
        val amountInput: String = "input.bet-amount, input[type=number]",
        val betButton: String = ".btn-submit, .btn-bet, button",
        val confirmButton: String = ".modal .btn-ok, .dialog .btn-ok",
        val successMarker: String = ".toast-success, .bet-success",
        val failMarker: String = ".toast-fail, .bet-fail",
        val countdown: String = ".countdown",
        val iframe: String = ""
    )

    data class Timing(
        val elementTimeoutMs: Long = 8_000,
        val pollIntervalMs: Long = 300,
        val stepDelayMs: Long = 400
    )

    data class Options(
        val preferCssSelector: Boolean = true,
        val fallbackTextScore: Boolean = true,
        val dryRun: Boolean = false
    )

    fun selectorForLabel(label: String): String = when (label) {
        "大" -> selectors.dxBig
        "小" -> selectors.dxSmall
        "单" -> selectors.dsOdd
        "双" -> selectors.dsEven
        else -> ""
    }

    companion object {
        fun fromJson(json: String): BetAutomationConfig? = try {
            val o = JSONObject(json)
            val sel = o.optJSONObject("selectors") ?: JSONObject()
            val timing = o.optJSONObject("timing") ?: JSONObject()
            val opt = o.optJSONObject("options") ?: JSONObject()
            BetAutomationConfig(
                platform = o.optString("platform", "default"),
                version = o.optString("version", ""),
                selectors = Selectors(
                    pageReady = sel.optString("pageReady", Selectors().pageReady),
                    dxBig = sel.optString("dxBig", ""),
                    dxSmall = sel.optString("dxSmall", ""),
                    dsOdd = sel.optString("dsOdd", ""),
                    dsEven = sel.optString("dsEven", ""),
                    amountInput = sel.optString("amountInput", Selectors().amountInput),
                    betButton = sel.optString("betButton", Selectors().betButton),
                    confirmButton = sel.optString("confirmButton", Selectors().confirmButton),
                    successMarker = sel.optString("successMarker", Selectors().successMarker),
                    failMarker = sel.optString("failMarker", Selectors().failMarker),
                    countdown = sel.optString("countdown", Selectors().countdown),
                    iframe = sel.optString("iframe", "")
                ),
                timing = Timing(
                    elementTimeoutMs = timing.optLong("elementTimeoutMs", 8_000),
                    pollIntervalMs = timing.optLong("pollIntervalMs", 300),
                    stepDelayMs = timing.optLong("stepDelayMs", 400)
                ),
                options = Options(
                    preferCssSelector = opt.optBoolean("preferCssSelector", true),
                    fallbackTextScore = opt.optBoolean("fallbackTextScore", true),
                    dryRun = opt.optBoolean("dryRun", false)
                )
            )
        } catch (_: Exception) {
            null
        }
    }
}
