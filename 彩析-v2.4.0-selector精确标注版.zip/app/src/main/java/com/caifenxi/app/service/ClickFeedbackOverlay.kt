package com.caifenxi.app.service

import android.content.Context
import android.graphics.Color as AndroidColor
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView

/**
 * 在点击坐标显示短暂标记 + 标签（如「大」），用于确认实际点击位置。
 * 优先 TYPE_ACCESSIBILITY_OVERLAY，失败则尝试应用悬浮窗类型。
 *
 * 增强版：支持 action 类型着色（click=红 / type=蓝 / scroll=橙 / wait=灰 / fail=暗红），
 * 显示时长可配，标签更长时自动加宽。
 */
object ClickFeedbackOverlay {

    enum class ActionType(val color: Int, val durationMs: Long, val label: String) {
        CLICK(AndroidColor.argb(200, 244, 67, 54), 900, "点击"),
        TYPE(AndroidColor.argb(200, 33, 150, 243), 1200, "输入"),
        SCROLL(AndroidColor.argb(200, 255, 152, 0), 800, "滚动"),
        WAIT(AndroidColor.argb(200, 158, 158, 158), 600, "等待"),
        FAIL(AndroidColor.argb(220, 183, 28, 28), 1500, "失败"),
        SUCCESS(AndroidColor.argb(200, 0, 200, 83), 1000, "成功")
    }

    private val handler = Handler(Looper.getMainLooper())

    /** 兼容旧调用：默认 CLICK 类型 */
    fun show(context: Context, x: Float, y: Float, label: String, fromA11y: Boolean) {
        show(context, x, y, label, fromA11y, ActionType.CLICK)
    }

    /** 增强：指定动作类型，自动着色和调整显示时长 */
    fun show(
        context: Context,
        x: Float,
        y: Float,
        label: String,
        fromA11y: Boolean,
        actionType: ActionType
    ) {
        handler.post {
            try {
                showInternal(context.applicationContext, x, y, label, fromA11y, actionType)
            } catch (_: Exception) {
            }
        }
    }

    private fun showInternal(
        context: Context,
        x: Float,
        y: Float,
        label: String,
        fromA11y: Boolean,
        actionType: ActionType
    ) {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val baseSize = dp(context, 52)
        // 标签较长时加宽，避免文字被截断
        val width = if (label.length > 3) dp(context, 72) else baseSize
        val height = baseSize
        val type = when {
            fromA11y && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1 ->
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ->
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else ->
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
        }
        val lp = WindowManager.LayoutParams(
            width,
            height,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = (x - width / 2f).toInt()
            this.y = (y - height / 2f).toInt()
        }

        val ring = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(actionType.color)
            setStroke(dp(context, 3), AndroidColor.WHITE)
        }
        val box = FrameLayout(context).apply {
            background = ring
        }
        // 上半：动作类型图标文字
        val typeLabel = TextView(context).apply {
            text = actionType.label
            setTextColor(AndroidColor.argb(180, 255, 255, 255))
            textSize = 8f
            gravity = android.view.Gravity.CENTER
        }
        // 下半：实际标签
        val valLabel = TextView(context).apply {
            text = label
            setTextColor(AndroidColor.WHITE)
            textSize = 13f
            gravity = android.view.Gravity.CENTER
            setSingleLine(true)
        }
        val layout = android.widget.LinearLayout(context).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
        }
        layout.addView(typeLabel)
        layout.addView(valLabel)
        box.addView(
            layout,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )

        try {
            wm.addView(box, lp)
        } catch (_: Exception) {
            return
        }
        handler.postDelayed({
            try {
                if (box.isAttachedToWindow) wm.removeViewImmediate(box)
            } catch (_: Exception) {
            }
        }, actionType.durationMs)
    }

    private fun dp(context: Context, v: Int): Int =
        (v * context.resources.displayMetrics.density).toInt()
}
