package com.caifenxi.app.domain.execution

/**
 * 统一执行任务：cmdId 第一主键 + 彩种/期号隔离。
 * 兼容调度器（State + command）与任务管理器（TaskStatus）。
 */
data class ExecutionTask(
    val cmdId: String,
    val lotteryKey: String,
    val issue: String,
    val stage: Int = 1,
    val leg: Int = 0,
    val dx: String? = null,
    val ds: String? = null,
    val amountText: String? = null,
    val combo: String? = null,
    val predNumbers: List<String> = emptyList(),
    val textActions: List<String> = emptyList(),
    val source: String = "",
    val executor: String = "",
    /** 调度器状态机 */
    val state: State = State.CREATED,
    /** 与 state 同步的任务状态（UI/TaskManager） */
    val status: TaskStatus = TaskStatus.CREATED,
    /** 完整指令（执行器只认这个） */
    val command: BetCommand? = null,
    val retryCount: Int = 0,
    val retryOf: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val expireAt: Long = 0L,
    val lastError: String? = null,
    val result: ExecutionResult? = null
) {
    enum class State {
        CREATED, LOCKED, EXECUTING, VERIFYING, SUCCESS, FAILED, UNKNOWN, EXPIRED, CANCELLED
    }

    enum class TaskStatus {
        CREATED, PUBLISHED, RECEIVED, VALIDATING, READY, EXECUTING, VERIFYING,
        SUCCESS, FAILED, UNKNOWN, EXPIRED, CANCELLED
    }

    val isTerminal: Boolean
        get() = state in TERMINAL_STATES || status in TERMINAL_STATUSES

    fun copyState(
        status: TaskStatus = this.status,
        updatedAt: Long = System.currentTimeMillis(),
        lastError: String? = this.lastError,
        result: ExecutionResult? = this.result
    ): ExecutionTask = copy(
        status = status,
        state = status.toState(),
        updatedAt = updatedAt,
        lastError = lastError,
        result = result
    )

    companion object {
        val TERMINAL_STATES = setOf(
            State.SUCCESS, State.FAILED, State.UNKNOWN, State.EXPIRED, State.CANCELLED
        )
        val TERMINAL_STATUSES = setOf(
            TaskStatus.SUCCESS, TaskStatus.FAILED, TaskStatus.UNKNOWN,
            TaskStatus.EXPIRED, TaskStatus.CANCELLED
        )
        val TERMINAL = TERMINAL_STATUSES

        fun fromCommand(command: BetCommand, source: String = ""): ExecutionTask {
            val dx = command.bets.firstOrNull { it.category == BetAction.CAT_DX }?.value
            val ds = command.bets.firstOrNull { it.category == BetAction.CAT_DS }?.value
            val combo = command.bets.firstOrNull { it.category == BetAction.CAT_COMBO }?.value
            val nums = command.bets.filter { it.category == BetAction.CAT_NUMBER }.map { it.value }
            return ExecutionTask(
                cmdId = command.cmdId,
                lotteryKey = command.lotteryKey,
                issue = command.issue,
                stage = command.stage,
                leg = command.leg,
                dx = dx,
                ds = ds,
                amountText = command.amountText,
                combo = combo,
                predNumbers = nums,
                source = source,
                command = command,
                expireAt = command.expireAt,
                createdAt = command.createdAt
            )
        }
    }
}

private fun ExecutionTask.TaskStatus.toState(): ExecutionTask.State = when (this) {
    ExecutionTask.TaskStatus.CREATED, ExecutionTask.TaskStatus.PUBLISHED,
    ExecutionTask.TaskStatus.RECEIVED, ExecutionTask.TaskStatus.VALIDATING,
    ExecutionTask.TaskStatus.READY -> ExecutionTask.State.CREATED
    ExecutionTask.TaskStatus.EXECUTING -> ExecutionTask.State.EXECUTING
    ExecutionTask.TaskStatus.VERIFYING -> ExecutionTask.State.VERIFYING
    ExecutionTask.TaskStatus.SUCCESS -> ExecutionTask.State.SUCCESS
    ExecutionTask.TaskStatus.FAILED -> ExecutionTask.State.FAILED
    ExecutionTask.TaskStatus.UNKNOWN -> ExecutionTask.State.UNKNOWN
    ExecutionTask.TaskStatus.EXPIRED -> ExecutionTask.State.EXPIRED
    ExecutionTask.TaskStatus.CANCELLED -> ExecutionTask.State.CANCELLED
}
