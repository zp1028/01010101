package com.caifenxi.app.data.config

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * URL 历史与书签存储：用 SharedPreferences 持久化最近访问的投注站地址。
 * - 自动记录访问过的 URL（最多 20 条，去重）
 * - 支持手动收藏/取消收藏书签
 * - 提供快速回访列表
 */
object UrlHistoryStore {

    private const val PREFS_NAME = "cfx_url_history"
    private const val KEY_HISTORY = "history"
    private const val KEY_BOOKMARKS = "bookmarks"
    private const val MAX_HISTORY = 20
    private const val MAX_BOOKMARKS = 50

    data class UrlEntry(
        val url: String,
        val title: String = "",
        val timestamp: Long = System.currentTimeMillis(),
        val bookmarked: Boolean = false
    )

    private fun getPrefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    /** 记录一次 URL 访问（自动去重，最新在前） */
    fun recordVisit(context: Context, url: String, title: String = "") {
        if (url.isBlank() || url == "about:blank") return
        val prefs = getPrefs(context)
        val history = getHistory(context).toMutableList()
        // 去重：移除同 URL 旧记录
        history.removeAll { it.url == url }
        // 加到头部
        history.add(0, UrlEntry(url, title, System.currentTimeMillis(), history.find { it.url == url }?.bookmarked == true))
        // 截断
        if (history.size > MAX_HISTORY) {
            history.subList(MAX_HISTORY, history.size).clear()
        }
        prefs.edit().putString(KEY_HISTORY, encodeList(history)).apply()
    }

    /** 获取访问历史列表 */
    fun getHistory(context: Context): List<UrlEntry> {
        val prefs = getPrefs(context)
        val raw = prefs.getString(KEY_HISTORY, null) ?: return emptyList()
        return decodeList(raw)
    }

    /** 切换书签状态 */
    fun toggleBookmark(context: Context, url: String): Boolean {
        val history = getHistory(context).toMutableList()
        val entry = history.find { it.url == url } ?: return false
        val newState = !entry.bookmarked
        val idx = history.indexOf(entry)
        history[idx] = entry.copy(bookmarked = newState)
        getPrefs(context).edit().putString(KEY_HISTORY, encodeList(history)).apply()

        // 同步书签列表
        val bookmarks = getBookmarks(context).toMutableList()
        if (newState) {
            if (bookmarks.none { it.url == url }) {
                bookmarks.add(0, entry.copy(bookmarked = true))
                if (bookmarks.size > MAX_BOOKMARKS) {
                    bookmarks.subList(MAX_BOOKMARKS, bookmarks.size).clear()
                }
            }
        } else {
            bookmarks.removeAll { it.url == url }
        }
        getPrefs(context).edit().putString(KEY_BOOKMARKS, encodeList(bookmarks)).apply()
        return newState
    }

    /** 获取书签列表 */
    fun getBookmarks(context: Context): List<UrlEntry> {
        val prefs = getPrefs(context)
        val raw = prefs.getString(KEY_BOOKMARKS, null) ?: return emptyList()
        return decodeList(raw)
    }

    /** 清空历史（书签不受影响） */
    fun clearHistory(context: Context) {
        // 保留书签状态
        val history = getHistory(context)
        val bookmarks = history.filter { it.bookmarked }
        getPrefs(context).edit().putString(KEY_HISTORY, encodeList(bookmarks)).apply()
    }

    private fun encodeList(list: List<UrlEntry>): String {
        val arr = JSONArray()
        for (e in list) {
            arr.put(JSONObject().apply {
                put("url", e.url)
                put("title", e.title)
                put("ts", e.timestamp)
                put("bm", e.bookmarked)
            })
        }
        return arr.toString()
    }

    private fun decodeList(raw: String): List<UrlEntry> {
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                UrlEntry(
                    url = o.optString("url"),
                    title = o.optString("title"),
                    timestamp = o.optLong("ts"),
                    bookmarked = o.optBoolean("bm")
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
