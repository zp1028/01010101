package com.caifenxi.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.caifenxi.app.data.config.LlmConfigStore
import com.caifenxi.app.domain.execution.AiAgentBrain
import com.caifenxi.app.domain.agent.AiAgentBackgroundController
import com.caifenxi.app.domain.agent.AiAgentBackgroundStore
import com.caifenxi.app.domain.execution.AiAgentMetricsStore
import com.caifenxi.app.domain.execution.AiAgentOrchestrator
import com.caifenxi.app.domain.execution.AiAgentPolicy
import com.caifenxi.app.domain.execution.LlmClient
import kotlinx.coroutines.launch

/** AI 大脑控制台：模型决策 + 感知摘要 + 策略校验 + Timeline + 运行统计。 */
@Composable
fun AiAgentLabScreen(onBack: () -> Unit = {}) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val brain = remember { AiAgentBrain() }
    val metricsStore = remember { AiAgentMetricsStore(context) }
    val client = remember { LlmClient(LlmConfigStore.load(context)) }
    val orchestrator = remember { AiAgentOrchestrator(client) }

    var snapshot by remember { mutableStateOf<AiAgentBrain.Snapshot?>(null) }
    var metrics by remember { mutableStateOf(metricsStore.load()) }
    var target by remember { mutableStateOf("测试页面目标") }
    var screenSummary by remember { mutableStateOf("这是一个用于 UI 自动化测试的模拟页面，包含一个“继续”按钮和状态文本。") }
    var running by remember { mutableStateOf(false) }
    var resultMessage by remember { mutableStateOf("等待运行") }
    var backgroundStatus by remember { mutableStateOf(AiAgentBackgroundStore(context).load()) }

    LaunchedEffect(Unit) { snapshot = brain.snapshot() }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = onBack) { Text("← 返回") }
            Text("🧠 AI Agent 大脑", style = MaterialTheme.typography.headlineSmall)
        }
        Text("完整链路：感知 → 分析 → 决策 → 策略校验 → Dry-Run 验证 → Timeline。", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(12.dp))

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("运行总览", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Text("运行次数：${metrics.runs}    成功：${metrics.success}    失败：${metrics.failed}")
                Text("拦截：${metrics.blocked}    成功率：${"%.1f".format(metrics.successRate * 100)}%")
                Text("平均延迟：${metrics.avgLatencyMs}ms")
                Text("最近：${metrics.lastMessage}")
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(progress = { metrics.successRate }, Modifier.fillMaxWidth())
            }
        }

        Spacer(Modifier.height(12.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("感知输入", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(target, { target = it }, Modifier.fillMaxWidth(), label = { Text("测试目标") })
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(screenSummary, { screenSummary = it }, Modifier.fillMaxWidth(), minLines = 3, label = { Text("截图/DOM/Accessibility 摘要") })
                Spacer(Modifier.height(8.dp))
                Text("策略：${AiAgentPolicy.reason(target)}", style = MaterialTheme.typography.bodySmall)
            }
        }

        Spacer(Modifier.height(12.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("后台 / 小窗运行", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                Text(if (backgroundStatus.enabled) "后台心跳：已开启" else "后台心跳：未开启")
                Text(if (backgroundStatus.lastHeartbeat > 0) "最近心跳：${java.text.SimpleDateFormat("MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(backgroundStatus.lastHeartbeat))}" else "最近心跳：暂无")
                Text("小窗：已启用 Android 多窗口自适应")
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { AiAgentBackgroundController.start(context); backgroundStatus = AiAgentBackgroundStore(context).load() }) { Text("开启后台") }
                    TextButton(onClick = { AiAgentBackgroundController.stop(context); backgroundStatus = AiAgentBackgroundStore(context).load() }) { Text("停止后台") }
                }
                Text("后台模式只维护 Agent Dry-Run 状态与心跳，不执行真实页面操作。", style = MaterialTheme.typography.bodySmall)
            }
        }

        Spacer(Modifier.height(12.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Agent 状态", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                Text("${snapshot?.state ?: AiAgentBrain.State.IDLE} · 目标：${snapshot?.currentTarget ?: "未开始"}")
                Text("候选动作：${snapshot?.proposedAction?.type ?: "—"}")
                Text("结果：$resultMessage")
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(enabled = !running, onClick = {
                        scope.launch {
                            running = true
                            val started = System.currentTimeMillis()
                            snapshot = brain.begin(target)
                            if (!AiAgentPolicy.isAllowedTarget(target)) {
                                val message = AiAgentPolicy.reason(target)
                                snapshot = brain.verify(message, false)
                                metricsStore.record(false, true, System.currentTimeMillis() - started, message)
                                resultMessage = message
                            } else {
                                snapshot = brain.recordAnalysis("完成截图/结构摘要分析，进入 AI 决策", 0)
                                val decision = orchestrator.decide(AiAgentOrchestrator.Observation(target, screenSummary))
                                if (decision.allowed && decision.action != null) {
                                    snapshot = brain.propose(decision.action)
                                    snapshot = brain.verify("Dry-Run 动作验证通过：${decision.action.type}", true, decision.latencyMs)
                                    metricsStore.record(true, false, System.currentTimeMillis() - started, "动作：${decision.action.type}")
                                    resultMessage = "候选动作已生成，未执行真实页面操作"
                                } else {
                                    snapshot = brain.verify(decision.message, false, decision.latencyMs)
                                    metricsStore.record(false, false, System.currentTimeMillis() - started, decision.message)
                                    resultMessage = decision.message
                                }
                            }
                            metrics = metricsStore.load()
                            running = false
                        }
                    }) { Text(if (running) "运行中…" else "运行 Agent") }
                    TextButton(onClick = {
                        scope.launch { snapshot = brain.reset(); resultMessage = "已重置" }
                    }) { Text("重置") }
                    TextButton(onClick = { metricsStore.clear(); metrics = metricsStore.load() }) { Text("清空统计") }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Agent Timeline", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                val events = snapshot?.events.orEmpty().asReversed()
                if (events.isEmpty()) Text("暂无事件")
                events.take(30).forEach { event ->
                    Text("${event.state} · ${event.message} · ${event.latencyMs}ms")
                    Spacer(Modifier.height(3.dp))
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Text("架构状态：AI 模型层 / 感知层 / 策略层 / Agent 状态机 / 统计层已拆分。下一步接入真实截图、DOM 与 Accessibility 数据时无需改动大脑核心。", style = MaterialTheme.typography.bodySmall)
    }
}
