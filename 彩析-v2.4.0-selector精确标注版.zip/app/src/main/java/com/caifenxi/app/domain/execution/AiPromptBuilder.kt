package com.caifenxi.app.domain.execution

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 构建多模态 LLM Prompt
 * 包含系统指令、任务目标、历史操作、当前页面状态
 */
object AiPromptBuilder {

    private const val SYSTEM_PROMPT = """你是一个Android彩票投注页面的自动化操作助手。
你的任务是根据截图和页面结构，精确识别并点击指定的投注按钮。

## 可用操作（严格JSON输出）
- click(x, y, target): 在屏幕坐标(x,y)处点击，target是元素描述
- type(x, y, text): 在坐标(x,y)的输入框输入文本
- scroll(direction, amount): 滚动页面，direction: up/down/left/right
- wait(ms): 等待指定毫秒（建议500-2000）
- finish(message): 任务完成
- fail(reason): 任务失败，说明原因

## 识别规则
1. 优先匹配文字完全一致的按钮（如"大""小""单""双"）
2. 如果目标文字不存在，返回 fail("未找到目标按钮: {text}")
3. 如果按钮显示为禁用状态（灰色、不可点击），返回 fail("按钮禁用: {text}")
4. 如果当前期号与目标期号不一致，先返回 wait(5000) 等待更新
5. 遇到验证码、登录弹窗、维护页面，返回 fail("遇到人工验证: {type}")
6. 坐标使用屏幕绝对像素坐标（基于截图分辨率）
7. 金额输入框通常是数字键盘，输入时直接输入数字即可

## 输出格式（严格JSON，不要markdown代码块）
{
  "thought": "推理过程，说明当前页面状态和下一步计划",
  "action": { "type": "click", "x": 540, "y": 890, "target": "大" },
  "confidence": 0.95
}"""

    fun build(
        command: BetCommand,
        screenshotBase64: String,
        nodeTree: String,
        history: List<ActionRecord>,
        currentIssue: String?
    ): LlmPrompt {
        val userText = buildString {
            appendLine("任务：在彩票投注页面执行以下操作")
            appendLine("彩种：${command.lotteryKey}")
            appendLine("目标期号：${command.issue}")
            appendLine("投注内容：${command.bets.joinToString { "${it.category}->${it.value}" }}")
            appendLine("金额：${command.amountText ?: "未指定"}")
            appendLine()

            appendLine("历史操作：")
            history.takeLast(5).forEachIndexed { idx, record ->
                appendLine("${idx + 1}. [${formatTime(record.timestamp)}] ${record.action}")
            }
            if (history.isEmpty()) appendLine("（无）")
            appendLine()

            appendLine("当前页面 Accessibility 节点树（精简）：")
            appendLine(nodeTree.take(4000)) // 限制 token
            appendLine()

            if (currentIssue != null) {
                appendLine("当前页面期号：$currentIssue")
                if (currentIssue != command.issue) {
                    appendLine("⚠️ 期号不匹配，可能需要等待更新")
                }
            }

            appendLine()
            appendLine("请分析当前状态并输出下一步操作（严格JSON格式）：")
        }

        return LlmPrompt(
            system = SYSTEM_PROMPT,
            userText = userText,
            imageBase64 = screenshotBase64
        )
    }

    private fun formatTime(ts: Long): String {
        val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        return sdf.format(Date(ts))
    }
}

data class ActionRecord(
    val step: Int,
    val action: String,
    val timestamp: Long
)
