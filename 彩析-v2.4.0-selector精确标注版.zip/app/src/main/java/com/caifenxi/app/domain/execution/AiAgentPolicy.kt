package com.caifenxi.app.domain.execution

/**
 * AI Agent 安全策略层。
 * 只允许非交易、非资金、非账号敏感操作进入 Agent Dry-Run。
 */
object AiAgentPolicy {
    private val blocked = listOf(
        "下注", "投注", "下单", "支付", "付款", "转账", "提现", "充值",
        "交易", "购买", "buy", "purchase", "pay", "payment", "transfer",
        "withdraw", "deposit", "bet", "wager", "order"
    )

    fun isAllowedTarget(target: String): Boolean {
        val value = target.trim().lowercase()
        return value.isNotBlank() && blocked.none { value.contains(it.lowercase()) }
    }

    fun reason(target: String): String = if (isAllowedTarget(target)) {
        "目标通过 Agent Dry-Run 策略"
    } else {
        "目标包含交易/资金操作关键词，Agent 仅允许规划与识别，不执行该类动作"
    }
}
