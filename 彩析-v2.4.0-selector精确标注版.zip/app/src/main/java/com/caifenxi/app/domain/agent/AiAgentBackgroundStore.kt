package com.caifenxi.app.domain.agent

import android.content.Context

/** 持久化后台 Agent 生命周期状态；不保存截图、密钥或页面敏感内容。 */
class AiAgentBackgroundStore(context: Context) {
    private val sp = context.getSharedPreferences("ai_agent_background", Context.MODE_PRIVATE)
    data class Status(val enabled: Boolean, val lastHeartbeat: Long, val lastState: String, val lastTarget: String, val lastError: String)
    fun load() = Status(
        sp.getBoolean("enabled", false), sp.getLong("last_heartbeat", 0L),
        sp.getString("last_state", "IDLE") ?: "IDLE", sp.getString("last_target", "") ?: "",
        sp.getString("last_error", "") ?: ""
    )
    fun setEnabled(enabled: Boolean) = sp.edit().putBoolean("enabled", enabled).apply()
    fun heartbeat(state: String, target: String = "") = sp.edit()
        .putLong("last_heartbeat", System.currentTimeMillis()).putString("last_state", state.take(80))
        .putString("last_target", target.take(160)).putString("last_error", "").apply()
    fun error(message: String) = sp.edit().putLong("last_heartbeat", System.currentTimeMillis())
        .putString("last_error", message.take(240)).apply()
}
