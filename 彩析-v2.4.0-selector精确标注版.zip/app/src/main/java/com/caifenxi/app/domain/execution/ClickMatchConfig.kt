package com.caifenxi.app.domain.execution

import android.content.Context

/**
 * 网页点击识别配置：自定义玩法文字 + 可选点击区域（相对屏幕百分比）+ CSS Selector 精确标注。
 * 配置后脚本优先用 selector 精确匹配，无 selector 时走 DOM 评分兜底。
 */
object ClickMatchConfig {

    private const val PREFS = "click_match_config"

    data class Profile(
        /** 逻辑键 → 页面真实按钮文字 */
        val labelBig: String = "大",
        val labelSmall: String = "小",
        val labelOdd: String = "单",
        val labelEven: String = "双",
        /** 是否启用区域限制 */
        val regionEnabled: Boolean = false,
        /** 相对视口百分比 0~100 */
        val regionLeft: Int = 0,
        val regionTop: Int = 15,
        val regionRight: Int = 100,
        val regionBottom: Int = 90,
        /** CSS Selector 精确标注（用户在标注模式中点击元素自动生成；空=未标注，走评分兜底） */
        val selectorBig: String = "",
        val selectorSmall: String = "",
        val selectorOdd: String = "",
        val selectorEven: String = "",
        val selectorAmount: String = "",
        val selectorConfirm: String = "",
        val selectorBalance: String = ""
    ) {
        fun mapLabel(logical: String): String = when (logical.trim()) {
            "大" -> labelBig.ifBlank { "大" }
            "小" -> labelSmall.ifBlank { "小" }
            "单" -> labelOdd.ifBlank { "单" }
            "双" -> labelEven.ifBlank { "双" }
            else -> logical
        }

        /** 返回逻辑键→selector 的映射表（供 JS 注入用） */
        fun selectorMap(): Map<String, String> = mapOf(
            "大" to selectorBig,
            "小" to selectorSmall,
            "单" to selectorOdd,
            "双" to selectorEven
        )

        /** 是否已标注了至少一个 selector */
        fun hasMapping(): Boolean = listOf(
            selectorBig, selectorSmall, selectorOdd, selectorEven,
            selectorAmount, selectorConfirm, selectorBalance
        ).any { it.isNotBlank() }
    }

    @Volatile
    private var cached: Profile? = null

    fun load(context: Context): Profile {
        cached?.let { return it }
        val sp = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return Profile(
            labelBig = sp.getString("label_big", "大") ?: "大",
            labelSmall = sp.getString("label_small", "小") ?: "小",
            labelOdd = sp.getString("label_odd", "单") ?: "单",
            labelEven = sp.getString("label_even", "双") ?: "双",
            regionEnabled = sp.getBoolean("region_enabled", false),
            regionLeft = sp.getInt("region_left", 0).coerceIn(0, 100),
            regionTop = sp.getInt("region_top", 15).coerceIn(0, 100),
            regionRight = sp.getInt("region_right", 100).coerceIn(0, 100),
            regionBottom = sp.getInt("region_bottom", 90).coerceIn(0, 100),
            selectorBig = sp.getString("selector_big", "") ?: "",
            selectorSmall = sp.getString("selector_small", "") ?: "",
            selectorOdd = sp.getString("selector_odd", "") ?: "",
            selectorEven = sp.getString("selector_even", "") ?: "",
            selectorAmount = sp.getString("selector_amount", "") ?: "",
            selectorConfirm = sp.getString("selector_confirm", "") ?: "",
            selectorBalance = sp.getString("selector_balance", "") ?: ""
        ).also { cached = it }
    }

    fun save(context: Context, profile: Profile) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("label_big", profile.labelBig.trim().ifBlank { "大" })
            .putString("label_small", profile.labelSmall.trim().ifBlank { "小" })
            .putString("label_odd", profile.labelOdd.trim().ifBlank { "单" })
            .putString("label_even", profile.labelEven.trim().ifBlank { "双" })
            .putBoolean("region_enabled", profile.regionEnabled)
            .putInt("region_left", profile.regionLeft.coerceIn(0, 100))
            .putInt("region_top", profile.regionTop.coerceIn(0, 100))
            .putInt("region_right", profile.regionRight.coerceIn(0, 100))
            .putInt("region_bottom", profile.regionBottom.coerceIn(0, 100))
            .putString("selector_big", profile.selectorBig.trim())
            .putString("selector_small", profile.selectorSmall.trim())
            .putString("selector_odd", profile.selectorOdd.trim())
            .putString("selector_even", profile.selectorEven.trim())
            .putString("selector_amount", profile.selectorAmount.trim())
            .putString("selector_confirm", profile.selectorConfirm.trim())
            .putString("selector_balance", profile.selectorBalance.trim())
            .apply()
        cached = profile
    }

    fun clearCache() {
        cached = null
    }
}
