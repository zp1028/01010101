package com.caifenxi.app.ui.screens

import android.content.pm.PackageManager
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PageHeader
import com.caifenxi.app.ui.components.SectionTitle
import com.caifenxi.app.ui.components.StaggeredEntrance
import com.caifenxi.app.ui.theme.CaiTokens

private data class MoreItem(
    val route: String,
    val title: String,
    val subtitle: String,
    val icon: ImageVector
)

@Composable
fun MoreScreen(vm: MainViewModel, navController: NavHostController) {
    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = CaiTokens.ScreenHPadding, vertical = CaiTokens.S16)
            .padding(bottom = CaiTokens.ScreenBottom)
    ) {
        PageHeader(title = "更多", subtitle = "工具、配置与实验功能")
        Spacer(Modifier.height(CaiTokens.S16))

        val items = listOf(
            MoreItem("stats", "历史 / 统计", "完整开奖历史与命中统计", Icons.Filled.History),
            MoreItem("lab", "实验室", "策略调试与参数实验", Icons.Filled.Science),
            MoreItem("web_bet", "内置网页执行", "WebView 投注站挂机台", Icons.Filled.Public),
            MoreItem("executor_control", "执行器控制", "调度器状态与手动控制", Icons.Filled.Analytics),
            MoreItem("executor_logs", "执行日志", "执行流水线日志查看", Icons.Filled.BugReport),
            MoreItem("ai_settings", "AI 大模型设置", "多模态 LLM 配置与测试", Icons.Filled.Psychology),
            MoreItem("ai_agent_lab", "AI Agent 实验台", "Agent 编排与 Dry-Run", Icons.Filled.SmartToy),
            MoreItem("settings", "设置 / 悬浮窗", "主题、参数、权限与数据管理", Icons.Filled.Settings)
        )

        SectionTitle("数据与工具")
        items.forEachIndexed { idx, item ->
            StaggeredEntrance(index = idx) {
                GlobalCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = CaiTokens.S8),
                    onClick = { navController.navigate(item.route) }
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(CaiTokens.RadiusIcon))
                                .background(MaterialTheme.colorScheme.secondaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                item.icon,
                                contentDescription = item.title,
                                tint = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(Modifier.width(CaiTokens.S12))
                        Column(Modifier.weight(1f)) {
                            Text(item.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            CaptionMuted(item.subtitle)
                        }
                        Text("›", fontSize = 20.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        Spacer(Modifier.height(CaiTokens.S12))
        GlobalCard {
            val ctx = LocalContext.current
            val version = remember {
                try {
                    val pm = ctx.packageManager
                    val info = pm.getPackageInfo(ctx.packageName, 0)
                    val vName = info.versionName ?: ""
                    val vCode = if (android.os.Build.VERSION.SDK_INT >= 28) {
                        info.longVersionCode
                    } else {
                        @Suppress("DEPRECATION")
                        info.versionCode.toLong()
                    }
                    "v$vName ($vCode)"
                } catch (_: PackageManager.NameNotFoundException) {
                    ""
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("彩析", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(version, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(CaiTokens.S8))
            Text(
                "走势统计、计划回测、预测共识与跟投记录工具。仅供开奖数据统计与研究，非中奖保证，请理性对待。",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}
