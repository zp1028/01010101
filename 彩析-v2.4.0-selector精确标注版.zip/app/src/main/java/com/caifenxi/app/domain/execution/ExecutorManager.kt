package com.caifenxi.app.domain.execution

import com.caifenxi.app.util.RuntimeLog

/**
 * 执行器统一管理器。
 *
 * 主路径：WebView DOM 执行器（selector 精确点击 + DOM 评分兜底）
 * 降级链：webview → accessibility → ai_vision
 *
 * 执行失败时自动降级到下一个可用执行器，直到全部失败才返回错误。
 */
object ExecutorManager {

    private val executors = LinkedHashMap<String, Executor>()

    @Volatile
    private var mode: String = "webview"

    /** 执行器降级链顺序 */
    private val fallbackOrder = listOf("webview", "accessibility", "ai_vision")

    /** 不触发降级的结果码（这些错误重试别的执行器也没意义） */
    private val noFallbackErrors = setOf(
        ExecutionResult.DUPLICATE_COMMAND,
        ExecutionResult.COMMAND_EXPIRED,
        ExecutionResult.CANCELLED
    )

    /** 注册执行器（App 启动时调用） */
    fun register(executor: Executor) {
        if (executor.id.isBlank()) return
        executors[executor.id] = executor
        RuntimeLog.info("Execution", "注册执行器 ${executor.id}")
    }

    /** 注销执行器（服务销毁时调用） */
    fun unregister(executorId: String) {
        if (executors.remove(executorId) != null) {
            RuntimeLog.info("Execution", "注销执行器 $executorId")
        }
    }

    fun setMode(newMode: String) {
        mode = newMode
        RuntimeLog.info("Execution", "执行模式切换为 $newMode")
    }

    fun getMode(): String = mode

    /** 按降级链返回当前可用的执行器列表 */
    fun pickChain(): List<Executor> =
        fallbackOrder.mapNotNull { id -> executors[id]?.takeIf { it.isAvailable } }

    /** 兼容旧调用：返回首个可用执行器 */
    fun pick(): Executor? = pickChain().firstOrNull()

    fun pickOrNull(): Executor? = pick()

    /**
     * 执行统一指令，带降级 fallback。
     *
     * 尝试顺序：webview → accessibility → ai_vision
     * 某个执行器返回失败且不属于 noFallbackErrors 时，自动降级到下一个。
     *
     * @return true 表示已受理；false 表示当前没有可用执行器。
     */
    fun execute(command: BetCommand, onResult: (ExecutionResult) -> Unit): Boolean {
        val chain = pickChain()
        if (chain.isEmpty()) {
            RuntimeLog.warn("Execution", "无可用执行器 cmdId=${command.cmdId}，任务挂起等待")
            return false
        }
        RuntimeLog.info(
            "Execution",
            "执行链 [${chain.joinToString { it.id }}] cmdId=${command.cmdId} 彩种=${command.lotteryKey} 期号=${command.issue}"
        )
        executeWithFallback(command, chain, 0, onResult)
        return true
    }

    private fun executeWithFallback(
        command: BetCommand,
        chain: List<Executor>,
        index: Int,
        onResult: (ExecutionResult) -> Unit
    ) {
        if (index >= chain.size) {
            onResult(
                ExecutionResult.fail(
                    command.cmdId,
                    ExecutionResult.ACTION_FAILED,
                    "所有执行器均失败"
                )
            )
            return
        }

        val executor = chain[index]
        RuntimeLog.info("Execution", "尝试执行器 ${executor.id} (idx=$index) cmdId=${command.cmdId}")

        val accepted = executor.execute(command) { result ->
            RuntimeLog.info(
                "Execution",
                "执行器 ${executor.id} 返回 cmdId=${result.cmdId} success=${result.success} code=${result.code} ${result.message}"
            )

            // 成功 → 直接返回
            if (result.success) {
                onResult(result)
                return@execute
            }

            // 不可降级的错误码 → 直接返回（重复/过期/取消）
            if (result.errorType in noFallbackErrors) {
                onResult(result)
                return@execute
            }

            // 还有后续执行器 → 降级
            if (index < chain.size - 1) {
                RuntimeLog.warn(
                    "Execution",
                    "${executor.id} 失败(${result.errorType})，降级到 ${chain[index + 1].id} cmdId=${command.cmdId}"
                )
                executeWithFallback(command, chain, index + 1, onResult)
            } else {
                // 最后一个执行器也失败了
                onResult(result)
            }
        }

        // 执行器未接受任务（如 WebView 未连接）→ 立即降级
        if (!accepted) {
            RuntimeLog.warn(
                "Execution",
                "${executor.id} 未接受任务，降级 cmdId=${command.cmdId}"
            )
            if (index < chain.size - 1) {
                executeWithFallback(command, chain, index + 1, onResult)
            } else {
                onResult(
                    ExecutionResult.fail(
                        command.cmdId,
                        ExecutionResult.WEBVIEW_DISCONNECTED,
                        "无执行器接受任务"
                    )
                )
            }
        }
    }

    fun isAvailable(executorId: String): Boolean =
        executors[executorId]?.isAvailable == true

    fun availableExecutorIds(): List<String> = executors.values.filter { it.isAvailable }.map { it.id }

    fun queryState(cmdId: String): ExecutionResult? {
        for (e in executors.values) {
            e.queryState(cmdId)?.let { return it }
        }
        return null
    }

    fun cancel(cmdId: String) {
        executors.values.forEach { it.cancel(cmdId) }
    }

    fun clear() {
        executors.clear()
    }
}
