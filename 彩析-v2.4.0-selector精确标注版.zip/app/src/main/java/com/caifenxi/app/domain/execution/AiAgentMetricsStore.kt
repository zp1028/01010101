package com.caifenxi.app.domain.execution

import android.content.Context
import org.json.JSONObject

/** 持久化 Agent 运行统计，不保存截图或 API Key。 */
class AiAgentMetricsStore(context: Context) {
    private val sp = context.getSharedPreferences("ai_agent_metrics", Context.MODE_PRIVATE)

    data class Metrics(
        val runs: Int,
        val success: Int,
        val failed: Int,
        val blocked: Int,
        val totalLatencyMs: Long,
        val lastMessage: String
    ) {
        val successRate: Float get() = if (runs == 0) 0f else success.toFloat() / runs.toFloat()
        val avgLatencyMs: Long get() = if (runs == 0) 0 else totalLatencyMs / runs
    }

    fun record(success: Boolean, blocked: Boolean, latencyMs: Long, message: String) {
        val current = load()
        sp.edit()
            .putInt("runs", current.runs + 1)
            .putInt("success", current.success + if (success) 1 else 0)
            .putInt("failed", current.failed + if (!success) 1 else 0)
            .putInt("blocked", current.blocked + if (blocked) 1 else 0)
            .putLong("latency", current.totalLatencyMs + latencyMs.coerceAtLeast(0))
            .putString("last_message", message.take(240))
            .apply()
    }

    fun load(): Metrics = Metrics(
        sp.getInt("runs", 0), sp.getInt("success", 0), sp.getInt("failed", 0),
        sp.getInt("blocked", 0), sp.getLong("latency", 0L),
        sp.getString("last_message", "暂无运行记录") ?: "暂无运行记录"
    )

    fun clear() { sp.edit().clear().apply() }
}
