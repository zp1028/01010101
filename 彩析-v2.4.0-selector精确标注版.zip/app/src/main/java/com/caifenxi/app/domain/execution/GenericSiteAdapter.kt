package com.caifenxi.app.domain.execution

/**
 * 通用站点适配：不绑死具体域名，用 DOM 评分识别真正的大小单双下注按钮。
 * 过滤历史/说明里同名文字；供 WebView evaluateJavascript 注入。
 */
object GenericSiteAdapter : SiteAdapter {

    override val siteId: String = "generic"

    override val whitelistDomains: List<String> = emptyList()

    override fun getUrl(lotteryKey: String): String = "about:blank"

    override val issueSelector: String =
        "[class*='issue'],[class*='period'],[id*='issue'],[id*='period'],.qihao,.issue,.period"

    override val balanceSnapshotScript: String = """
        (function(){
          var profile = window.__CFX_PROFILE || {};
          if(profile.selectorBalance){
            try{
              var el=document.querySelector(profile.selectorBalance);
              if(el) return (el.innerText||el.textContent||'').trim();
            }catch(e){}
          }
          var t = document.body ? (document.body.innerText||'') : '';
          var m = t.match(/(余额|可用|金额)[^0-9]{0,6}([0-9]+(?:\.[0-9]+)?)/);
          return m ? m[2] : String((t.length||0));
        })()
    """.trimIndent()

    override fun buildInjectScript(command: BetCommand): String {
        val profile = try {
            ClickMatchConfig.load(com.caifenxi.app.CaiFenXiApplication.instance)
        } catch (_: Exception) {
            ClickMatchConfig.Profile()
        }
        // 逻辑值（大/小/单/双）映射为用户配置的页面真实文字
        val betsJson = command.bets.joinToString(",") { bet ->
            val mapped = profile.mapLabel(bet.value)
            """{"cat":${jsonStr(bet.category)},"value":${jsonStr(bet.value)},"pageText":${jsonStr(mapped)}}"""
        }
        val amount = command.amountText?.let { jsonStr(it) } ?: "null"
        val issue = jsonStr(command.issue)
        val dryRun = command.options["dryRun"] == "1" || command.options["dryRun"] == "true"
        return """
            (function(){
              var CMD = {
                cmdId: ${jsonStr(command.cmdId)},
                issue: $issue,
                amount: $amount,
                dryRun: ${if (dryRun) "true" else "false"},
                bets: [$betsJson],
                labelMap: {
                  "大": ${jsonStr(profile.labelBig)},
                  "小": ${jsonStr(profile.labelSmall)},
                  "单": ${jsonStr(profile.labelOdd)},
                  "双": ${jsonStr(profile.labelEven)}
                },
                selectors: {
                  "大": ${jsonStr(profile.selectorBig)},
                  "小": ${jsonStr(profile.selectorSmall)},
                  "单": ${jsonStr(profile.selectorOdd)},
                  "双": ${jsonStr(profile.selectorEven)},
                  "selector_amount": ${jsonStr(profile.selectorAmount)},
                  "selector_confirm": ${jsonStr(profile.selectorConfirm)}
                },
                region: {
                  enabled: ${if (profile.regionEnabled) "true" else "false"},
                  left: ${profile.regionLeft},
                  top: ${profile.regionTop},
                  right: ${profile.regionRight},
                  bottom: ${profile.regionBottom}
                }
              };
              window.__CFX_PROFILE = {
                selectorBalance: ${jsonStr(profile.selectorBalance)}
              };
              ${coreJs()}
              return JSON.stringify(window.__caiFenXiRunCommand(CMD));
            })()
        """.trimIndent()
    }

    override fun parseReceipt(rawJson: String): ExecutionReceipt {
        val raw = rawJson.trim().removeSurrounding("\"").replace("\\\"", "\"")
        if (raw.isBlank() || raw == "null") {
            return ExecutionReceipt(false, true, "空回执")
        }
        return try {
            val ok = raw.contains("\"ok\":true") || raw.contains("\"ok\": true")
            val err = raw.contains("\"ok\":false") || raw.contains("\"ok\": false")
            val msg = Regex("\"message\"\\s*:\\s*\"([^\"]*)\"").find(raw)?.groupValues?.getOrNull(1)
                ?: raw.take(120)
            ExecutionReceipt(isSuccess = ok, isError = err && !ok, message = msg)
        } catch (e: Exception) {
            ExecutionReceipt(false, true, "解析失败: ${e.message}")
        }
    }

    private fun jsonStr(s: String): String =
        "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n") + "\""

    /** 核心识别与点击逻辑：从 assets/cfx_inject.js 加载，便于独立调试和迭代 */
    @Volatile
    private var cachedCoreJs: String? = null

    private fun coreJs(): String {
        cachedCoreJs?.let { return it }
        return try {
            val ctx = com.caifenxi.app.CaiFenXiApplication.instance
            val raw = ctx.assets.open("cfx_inject.js").bufferedReader().use { it.readText() }
            raw.also { cachedCoreJs = it }
        } catch (e: Exception) {
            // assets 读取失败时回退空串，避免构建脚本崩溃
            ""
        }
    }
}
