package com.caifenxi.app.domain.execution

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * AI Agent 大脑核心（安全规划层）。
 * 负责感知状态、生成候选动作、校验状态转移与记录 Agent Timeline。
 * 本层只产生“建议动作”，不直接执行网页点击、资金操作或交易提交。
 */
class AiAgentBrain {
    enum class State {
        IDLE, PERCEIVE, ANALYZE, PLAN, VERIFY, SUCCESS, FAILED
    }

    enum class ActionType { CLICK, TYPE, SCROLL, WAIT, FINISH, FAIL }

    data class ProposedAction(
        val type: ActionType,
        val target: String = "",
        val text: String = "",
        val x: Float = 0f,
        val y: Float = 0f,
        val confidence: Float = 0f,
        val reason: String = ""
    )

    data class TimelineEvent(
        val timestamp: Long,
        val state: State,
        val message: String,
        val latencyMs: Long = 0L
    )

    data class Snapshot(
        val state: State,
        val currentTarget: String,
        val proposedAction: ProposedAction?,
        val events: List<TimelineEvent>
    )

    private val mutex = Mutex()
    private var state = State.IDLE
    private var currentTarget = ""
    private var proposedAction: ProposedAction? = null
    private val events = ArrayDeque<TimelineEvent>()

    suspend fun begin(target: String): Snapshot = mutex.withLock {
        currentTarget = target
        proposedAction = null
        transition(State.PERCEIVE, "开始感知目标页面")
        snapshotUnsafe()
    }

    suspend fun recordAnalysis(message: String, latencyMs: Long): Snapshot = mutex.withLock {
        transition(State.ANALYZE, message, latencyMs)
        snapshotUnsafe()
    }

    suspend fun propose(action: ProposedAction): Snapshot = mutex.withLock {
        proposedAction = action
        transition(State.PLAN, "生成候选动作：${action.type}")
        snapshotUnsafe()
    }

    suspend fun verify(message: String, success: Boolean, latencyMs: Long = 0L): Snapshot = mutex.withLock {
        transition(if (success) State.SUCCESS else State.FAILED, message, latencyMs)
        snapshotUnsafe()
    }

    suspend fun reset(): Snapshot = mutex.withLock {
        currentTarget = ""
        proposedAction = null
        transition(State.IDLE, "Agent 已重置")
        snapshotUnsafe()
    }

    suspend fun snapshot(): Snapshot = mutex.withLock { snapshotUnsafe() }

    private fun snapshotUnsafe() = Snapshot(state, currentTarget, proposedAction, events.toList())

    private fun transition(next: State, message: String, latencyMs: Long = 0L) {
        state = next
        events.addLast(TimelineEvent(System.currentTimeMillis(), next, message, latencyMs))
        while (events.size > 100) events.removeFirst()
    }
}
