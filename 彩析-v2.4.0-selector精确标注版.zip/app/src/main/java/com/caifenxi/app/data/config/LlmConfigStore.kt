package com.caifenxi.app.data.config

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.caifenxi.app.domain.execution.LlmClient

/**
 * LLM API 配置本地存储（API Key 使用 EncryptedSharedPreferences 加密存储）
 */
object LlmConfigStore {

    private const val PREFS_NAME = "llm_config"

    private fun getPrefs(context: Context): SharedPreferences {
        return try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context,
                PREFS_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            // 回退到普通 SharedPreferences（首次升级或加密初始化失败时）
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        }
    }

    fun load(context: Context): LlmClient.LlmConfig {
        val sp = getPrefs(context)
        val apiKey = sp.getString("api_key", "") ?: ""

        // 迁移：加密 prefs 无 key 但旧 prefs 有，迁移一次
        if (apiKey.isBlank()) {
            val legacy = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val legacyKey = legacy.getString("api_key", "") ?: ""
            if (legacyKey.isNotBlank()) {
                sp.edit().apply {
                    putString("provider", legacy.getString("provider", "OPENAI"))
                    putString("base_url", legacy.getString("base_url", "https://api.openai.com/v1"))
                    putString("api_key", legacyKey)
                    putString("model", legacy.getString("model", "gpt-4o-mini"))
                    putInt("max_tokens", legacy.getInt("max_tokens", 512))
                    putFloat("temperature", legacy.getFloat("temperature", 0.1f))
                    putString("image_detail", legacy.getString("image_detail", "low"))
                    apply()
                }
                legacy.edit().clear().apply()
                return load(context)
            }
        }

        return LlmClient.LlmConfig(
            provider = try {
                LlmClient.LlmProvider.valueOf(sp.getString("provider", "OPENAI") ?: "OPENAI")
            } catch (_: Exception) {
                LlmClient.LlmProvider.OPENAI
            },
            baseUrl = sp.getString("base_url", "https://api.openai.com/v1") ?: "https://api.openai.com/v1",
            apiKey = apiKey,
            model = sp.getString("model", "gpt-4o-mini") ?: "gpt-4o-mini",
            maxTokens = sp.getInt("max_tokens", 512),
            temperature = sp.getFloat("temperature", 0.1f).toDouble(),
            imageDetail = sp.getString("image_detail", "low") ?: "low"
        )
    }

    fun save(context: Context, config: LlmClient.LlmConfig) {
        getPrefs(context).edit().apply {
            putString("provider", config.provider.name)
            putString("base_url", config.baseUrl)
            putString("api_key", config.apiKey)
            putString("model", config.model)
            putInt("max_tokens", config.maxTokens)
            putFloat("temperature", config.temperature.toFloat())
            putString("image_detail", config.imageDetail)
            apply()
        }
    }
}
