package com.caifenxi.app.data.repository

import com.caifenxi.app.data.db.CaiDatabase
import com.caifenxi.app.domain.execution.BetCommand
import com.caifenxi.app.domain.execution.ExecutionRepository
import com.caifenxi.app.domain.execution.ExecutionResult
import com.caifenxi.app.domain.execution.ExecutionTask
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import java.util.concurrent.ConcurrentHashMap

/**
 * 执行任务仓库：内存为主，保证可编译、可调度。
 * （Room 表可后续再做完整持久化，避免实体字段与序列化不同步导致编译失败）
 */
class ExecutionRepositoryImpl(
    @Suppress("UNUSED_PARAMETER") private val db: CaiDatabase
) : ExecutionRepository {

    private val tasks = ConcurrentHashMap<String, ExecutionTask>()
    private val revision = MutableStateFlow(0L)

    private fun bump() {
        revision.value = System.currentTimeMillis()
    }

    override suspend fun create(command: BetCommand): ExecutionTask {
        val task = ExecutionTask.fromCommand(command, source = command.source).copy(
            state = ExecutionTask.State.CREATED,
            status = ExecutionTask.TaskStatus.CREATED
        )
        tasks[task.cmdId] = task
        bump()
        return task
    }

    override suspend fun transition(
        cmdId: String,
        from: ExecutionTask.State,
        to: ExecutionTask.State
    ): Boolean {
        val cur = tasks[cmdId] ?: return false
        if (cur.state != from) return false
        tasks[cmdId] = cur.copy(state = to, updatedAt = System.currentTimeMillis())
        bump()
        return true
    }

    override suspend fun findById(cmdId: String): ExecutionTask? = tasks[cmdId]

    override suspend fun findPendingByLottery(lotteryKey: String): List<ExecutionTask> {
        val terminal = ExecutionTask.TERMINAL_STATES
        return tasks.values.filter { it.lotteryKey == lotteryKey && it.state !in terminal }
    }

    override suspend fun findUnknowns(): List<ExecutionTask> =
        tasks.values.filter { it.state == ExecutionTask.State.UNKNOWN }

    override suspend fun findLastSuccess(lotteryKey: String): ExecutionTask? =
        tasks.values
            .filter { it.lotteryKey == lotteryKey && it.state == ExecutionTask.State.SUCCESS }
            .maxByOrNull { it.updatedAt }

    override suspend fun isLotteryBlocked(lotteryKey: String): Boolean =
        tasks.values.any {
            it.lotteryKey == lotteryKey && it.state == ExecutionTask.State.UNKNOWN
        }

    override suspend fun complete(cmdId: String, result: ExecutionResult): Boolean {
        val cur = tasks[cmdId] ?: return false
        val state = when (result.code) {
            ExecutionResult.ResultCode.SUCCESS -> ExecutionTask.State.SUCCESS
            ExecutionResult.ResultCode.FAILED -> ExecutionTask.State.FAILED
            ExecutionResult.ResultCode.UNKNOWN -> ExecutionTask.State.UNKNOWN
            ExecutionResult.ResultCode.EXPIRED -> ExecutionTask.State.EXPIRED
            ExecutionResult.ResultCode.CANCELLED -> ExecutionTask.State.CANCELLED
            ExecutionResult.ResultCode.TIMEOUT -> ExecutionTask.State.FAILED
            ExecutionResult.ResultCode.DUPLICATE -> ExecutionTask.State.FAILED
            ExecutionResult.ResultCode.WEBVIEW_DISCONNECTED -> ExecutionTask.State.FAILED
        }
        tasks[cmdId] = cur.copy(
            state = state,
            result = result,
            lastError = if (!result.success) result.message else cur.lastError,
            updatedAt = System.currentTimeMillis()
        )
        bump()
        return true
    }

    override suspend fun expire(cmdId: String): Boolean {
        val cur = tasks[cmdId] ?: return false
        tasks[cmdId] = cur.copy(
            state = ExecutionTask.State.EXPIRED,
            updatedAt = System.currentTimeMillis()
        )
        bump()
        return true
    }

    override suspend fun acknowledgeUnknown(cmdId: String): Boolean {
        val cur = tasks[cmdId] ?: return false
        if (cur.state != ExecutionTask.State.UNKNOWN) return false
        tasks[cmdId] = cur.copy(
            state = ExecutionTask.State.CANCELLED,
            updatedAt = System.currentTimeMillis()
        )
        bump()
        return true
    }

    override fun observeLotteryTasks(lotteryKey: String): Flow<List<ExecutionTask>> =
        revision.map {
            tasks.values.filter { t -> t.lotteryKey == lotteryKey }
                .sortedByDescending { t -> t.createdAt }
        }

    override fun observeUnknowns(): Flow<List<ExecutionTask>> =
        revision.map {
            tasks.values.filter { t -> t.state == ExecutionTask.State.UNKNOWN }
        }
}
