package com.caifenxi.app.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.caifenxi.app.domain.agent.AiAgentBackgroundStore

/** 可恢复的后台 Agent 心跳；只维护 Dry-Run 状态，不执行真实页面操作。 */
class AiAgentBackgroundWorker(appContext: Context, workerParams: WorkerParameters) : CoroutineWorker(appContext, workerParams) {
    override suspend fun doWork(): Result {
        val store = AiAgentBackgroundStore(applicationContext)
        val status = store.load()
        if (!status.enabled) return Result.success()
        return try {
            store.heartbeat(if (status.lastState.isBlank()) "IDLE" else status.lastState, status.lastTarget)
            Result.success()
        } catch (t: Throwable) {
            store.error(t.message ?: t.javaClass.simpleName)
            Result.retry()
        }
    }
}
