package com.caifenxi.app.domain.execution

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Build
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import kotlin.coroutines.resume

/**
 * 感知引擎：截图 + Accessibility 节点树提取
 *
 * Android 11+ 使用 AccessibilityService.takeScreenshot()
 * Android 7-10 回退到 MediaProjection（需用户预授权）
 */
class PerceptionEngine(private val service: AccessibilityService) {

    private val mainExecutor = service.mainExecutor

    /**
     * 检查是否可以捕获截图
     */
    fun canCapture(): Boolean = service.rootInActiveWindow != null

    /**
     * 捕获当前屏幕截图，返回 JPEG 压缩后的 base64
     */
    suspend fun captureScreenshot(): String = suspendCancellableCoroutine { cont ->
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            service.takeScreenshot(
                android.view.Display.DEFAULT_DISPLAY,
                mainExecutor,
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(screenshot: AccessibilityService.ScreenshotResult) {
                        val bitmap = Bitmap.wrapHardwareBuffer(
                            screenshot.hardwareBuffer,
                            screenshot.colorSpace
                        ) ?: run {
                            cont.resume("")
                            return
                        }
                        // HardwareBuffer 不能直接压缩，需要 copy 到软件 Bitmap
                        val softBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, false)
                        bitmap.recycle()
                        screenshot.hardwareBuffer.close()

                        val stream = ByteArrayOutputStream()
                        // 压缩到原图 50% 分辨率，减少 LLM token
                        val scaled = Bitmap.createScaledBitmap(
                            softBitmap,
                            (softBitmap.width * 0.5f).toInt().coerceAtLeast(320),
                            (softBitmap.height * 0.5f).toInt().coerceAtLeast(640),
                            true
                        )
                        scaled.compress(Bitmap.CompressFormat.JPEG, 60, stream)
                        softBitmap.recycle()
                        scaled.recycle()

                        val base64 = android.util.Base64.encodeToString(
                            stream.toByteArray(),
                            android.util.Base64.NO_WRAP
                        )
                        cont.resume(base64)
                    }

                    override fun onFailure(errorCode: Int) {
                        cont.resume("")
                    }
                }
            )
        } else {
            // 低版本回退：使用 MediaProjection（彩析已有悬浮窗截图能力，可复用）
            cont.resume(captureViaMediaProjection())
        }
    }

    /**
     * 提取 Accessibility 节点树（结构化 JSON，控制 token 量）
     * 只提取可交互元素，最多 3 层深度，每层最多 10 个子节点
     */
    fun extractNodeTree(): String {
        val windows = service.windows ?: return "[]"
        val result = JSONArray()

        for (window in windows) {
            val root = window.root ?: continue
            // 跳过彩析自己的窗口
            if (root.packageName?.toString() == service.packageName) continue
            result.put(serializeNode(root, depth = 0))
        }
        return result.toString()
    }

    private fun serializeNode(node: AccessibilityNodeInfo, depth: Int): JSONObject {
        val obj = JSONObject()
        val bounds = Rect()
        node.getBoundsInScreen(bounds)

        obj.put("class", node.className?.toString() ?: "")
        obj.put("text", node.text?.toString()?.take(50) ?: "")
        obj.put("contentDesc", node.contentDescription?.toString()?.take(50) ?: "")
        obj.put("bounds", JSONObject().apply {
            put("left", bounds.left)
            put("top", bounds.top)
            put("right", bounds.right)
            put("bottom", bounds.bottom)
        })
        obj.put("clickable", node.isClickable)
        obj.put("editable", node.isEditable)
        obj.put("enabled", node.isEnabled)
        obj.put("visible", node.isVisibleToUser)

        // 控制深度和广度，减少 token
        if (depth < 2 && node.childCount > 0) {
            val children = JSONArray()
            val maxChildren = if (depth == 0) 15 else 8
            for (i in 0 until minOf(node.childCount, maxChildren)) {
                node.getChild(i)?.let { child ->
                    children.put(serializeNode(child, depth + 1))
                }
            }
            if (children.length() > 0) obj.put("children", children)
        }
        return obj
    }

    /**
     * 从节点树中提取期号
     */
    fun extractIssueNumber(nodeTree: String): String? {
        val regex = Regex("""期号[:\s]*(\d+)""")
        return regex.find(nodeTree)?.groupValues?.getOrNull(1)
    }

    /**
     * 从节点树中提取余额
     */
    fun extractBalance(nodeTree: String): String? {
        val regex = Regex("""(余额|可用|金额)[^\d]{0,6}(\d+(?:\.\d+)?)""")
        return regex.find(nodeTree)?.groupValues?.getOrNull(2)
    }

    private fun captureViaMediaProjection(): String {
        // TODO: 复用彩析已有的 MediaProjection 截图逻辑
        // 或 FloatingOverlayController 的截图能力
        return ""
    }
}
