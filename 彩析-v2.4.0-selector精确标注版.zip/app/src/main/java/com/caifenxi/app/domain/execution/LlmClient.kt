package com.caifenxi.app.domain.execution

import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.Continuation
import kotlin.coroutines.resume

/**
 * LLM client with dynamic model discovery, diagnostics and multimodal chat.
 * OpenAI-compatible APIs and Google Gemini are discovered from their model APIs.
 */
class LlmClient(private val config: LlmConfig) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    val isReady: Boolean
        get() = config.apiKey.isNotBlank() && config.model.isNotBlank()

    suspend fun listModels(): ModelListResult = suspendCancellableCoroutine { cont ->
        val start = System.currentTimeMillis()
        val request = when (config.provider) {
            LlmProvider.OPENAI -> Request.Builder()
                .url(normalizeBaseUrl(config.baseUrl) + "/models")
                .header("Authorization", "Bearer ${config.apiKey}")
                .header("Content-Type", "application/json")
                .get().build()
            LlmProvider.GOOGLE -> Request.Builder()
                .url(normalizeBaseUrl(config.baseUrl) + "/models?key=${config.apiKey}")
                .header("Content-Type", "application/json")
                .get().build()
            LlmProvider.ANTHROPIC -> {
                cont.resume(ModelListResult.Error("Anthropic 官方 API 当前不提供与 OpenAI / Gemini 等价的公开模型列表接口，请手动填写模型名。", System.currentTimeMillis() - start))
                return@suspendCancellableCoroutine
            }
        }
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                cont.resume(ModelListResult.Error("网络错误: ${e.message ?: "unknown"}", System.currentTimeMillis() - start))
            }
            override fun onResponse(call: Call, response: Response) {
                val duration = System.currentTimeMillis() - start
                val text = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    cont.resume(ModelListResult.Error(formatHttpError(response.code, text), duration))
                    return
                }
                try {
                    val models = when (config.provider) {
                        LlmProvider.OPENAI -> parseOpenAiModels(text)
                        LlmProvider.GOOGLE -> parseGoogleModels(text)
                        LlmProvider.ANTHROPIC -> emptyList()
                    }
                    cont.resume(ModelListResult.Success(models, duration))
                } catch (e: Exception) {
                    cont.resume(ModelListResult.Error("模型列表解析失败: ${e.message}", duration))
                }
            }
        })
    }

    suspend fun testConnection(): LlmResponse = chat(
        LlmPrompt(
            system = "You are a connectivity test assistant. Reply with exactly OK.",
            userText = "Connection test",
            imageBase64 = ""
        )
    )

    suspend fun chat(prompt: LlmPrompt): LlmResponse {
        val first = chatOnce(prompt)
        if (first is LlmResponse.Error) {
            // 重试一次：降级去掉图片（减少 token），避免网络抖动直接失败
            val retryPrompt = if (prompt.imageBase64.isNotBlank()) {
                prompt.copy(imageBase64 = "")
            } else {
                prompt
            }
            return chatOnce(retryPrompt)
        }
        return first
    }

    private suspend fun chatOnce(prompt: LlmPrompt): LlmResponse = suspendCancellableCoroutine { cont ->
        val startTime = System.currentTimeMillis()
        when (config.provider) {
            LlmProvider.OPENAI -> callOpenAI(prompt, cont, startTime)
            LlmProvider.ANTHROPIC -> callAnthropic(prompt, cont, startTime)
            LlmProvider.GOOGLE -> callGoogle(prompt, cont, startTime)
        }
    }

    private fun callOpenAI(prompt: LlmPrompt, cont: Continuation<LlmResponse>, startTime: Long) {
        val userContent = JSONArray()
        if (prompt.imageBase64.isNotBlank()) {
            userContent.put(JSONObject().apply {
                put("type", "image_url")
                put("image_url", JSONObject().apply {
                    put("url", "data:image/jpeg;base64,${prompt.imageBase64}")
                    put("detail", config.imageDetail)
                })
            })
        }
        userContent.put(JSONObject().apply {
            put("type", "text")
            put("text", prompt.userText)
        })
        val body = JSONObject().apply {
            put("model", config.model)
            put("messages", JSONArray().apply {
                put(JSONObject().apply { put("role", "system"); put("content", prompt.system) })
                put(JSONObject().apply { put("role", "user"); put("content", userContent) })
            })
            put("max_tokens", config.maxTokens)
            put("temperature", config.temperature)
            put("response_format", JSONObject().apply { put("type", "json_object") })
        }
        val request = Request.Builder().url(normalizeBaseUrl(config.baseUrl) + "/chat/completions")
            .header("Authorization", "Bearer ${config.apiKey}")
            .header("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        enqueueResponse(request, cont, startTime) { text ->
            JSONObject(text).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
        }
    }

    private fun callAnthropic(prompt: LlmPrompt, cont: Continuation<LlmResponse>, startTime: Long) {
        val content = JSONArray()
        if (prompt.imageBase64.isNotBlank()) content.put(JSONObject().apply {
            put("type", "image")
            put("source", JSONObject().apply { put("type", "base64"); put("media_type", "image/jpeg"); put("data", prompt.imageBase64) })
        })
        content.put(JSONObject().apply { put("type", "text"); put("text", prompt.system + "\n\n" + prompt.userText) })
        val body = JSONObject().apply {
            put("model", config.model); put("max_tokens", config.maxTokens); put("temperature", config.temperature)
            put("messages", JSONArray().put(JSONObject().apply { put("role", "user"); put("content", content) }))
        }
        val request = Request.Builder().url(normalizeBaseUrl(config.baseUrl) + "/messages")
            .header("x-api-key", config.apiKey).header("anthropic-version", "2023-06-01")
            .header("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        enqueueResponse(request, cont, startTime) { text -> JSONObject(text).getJSONArray("content").getJSONObject(0).getString("text") }
    }

    private fun callGoogle(prompt: LlmPrompt, cont: Continuation<LlmResponse>, startTime: Long) {
        val parts = JSONArray()
        if (prompt.imageBase64.isNotBlank()) parts.put(JSONObject().apply {
            put("inlineData", JSONObject().apply { put("mimeType", "image/jpeg"); put("data", prompt.imageBase64) })
        })
        parts.put(JSONObject().apply { put("text", prompt.system + "\n\n" + prompt.userText) })
        val body = JSONObject().apply {
            put("contents", JSONArray().put(JSONObject().apply { put("parts", parts) }))
            put("generationConfig", JSONObject().apply { put("maxOutputTokens", config.maxTokens); put("temperature", config.temperature) })
        }
        val request = Request.Builder().url(normalizeBaseUrl(config.baseUrl) + "/models/${config.model}:generateContent?key=${config.apiKey}")
            .header("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        enqueueResponse(request, cont, startTime) { text ->
            JSONObject(text).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        }
    }

    private fun enqueueResponse(request: Request, cont: Continuation<LlmResponse>, startTime: Long, parser: (String) -> String) {
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                cont.resume(LlmResponse.Error("网络错误: ${e.message ?: "unknown"}", System.currentTimeMillis() - startTime))
            }
            override fun onResponse(call: Call, response: Response) {
                val duration = System.currentTimeMillis() - startTime
                val text = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    cont.resume(LlmResponse.Error(formatHttpError(response.code, text), duration)); return
                }
                try { cont.resume(LlmResponse.Success(parser(text), duration)) }
                catch (e: Exception) { cont.resume(LlmResponse.Error("响应解析失败: ${e.message}", duration)) }
            }
        })
    }

    private fun parseOpenAiModels(text: String): List<ModelInfo> {
        val data = JSONObject(text).optJSONArray("data") ?: JSONArray()
        return (0 until data.length()).mapNotNull { i ->
            val o = data.optJSONObject(i) ?: return@mapNotNull null
            val id = o.optString("id").takeIf { it.isNotBlank() } ?: return@mapNotNull null
            ModelInfo(id, "OpenAI-compatible", supportsVision = looksVision(id), supportsChat = true)
        }.sortedBy { it.id }
    }

    private fun parseGoogleModels(text: String): List<ModelInfo> {
        val data = JSONObject(text).optJSONArray("models") ?: JSONArray()
        return (0 until data.length()).mapNotNull { i ->
            val o = data.optJSONObject(i) ?: return@mapNotNull null
            val raw = o.optString("name")
            val id = raw.removePrefix("models/").takeIf { it.isNotBlank() } ?: return@mapNotNull null
            val methods = o.optJSONArray("supportedGenerationMethods")
            val supportsChat = (0 until (methods?.length() ?: 0)).any { methods?.optString(it) == "generateContent" }
            ModelInfo(id, "Google Gemini", supportsVision = looksVision(id), supportsChat = supportsChat)
        }.filter { it.supportsChat }.sortedBy { it.id }
    }

    private fun looksVision(id: String): Boolean = !id.contains("embedding", true) && !id.contains("tts", true) && !id.contains("audio", true)

    private fun formatHttpError(code: Int, body: String): String {
        val detail = try {
            val o = JSONObject(body)
            o.optJSONObject("error")?.let { it.optString("message").takeIf(String::isNotBlank) }
                ?: o.optString("message").takeIf(String::isNotBlank)
        } catch (_: Exception) { null }
        return "HTTP $code${if (detail != null) ": $detail" else ": ${body.take(240)}"}"
    }

    private fun normalizeBaseUrl(url: String): String = url.trim().trimEnd('/').removeSuffix("/v1") + if (url.trim().trimEnd('/').endsWith("/v1")) "/v1" else ""

    data class LlmConfig(
        val provider: LlmProvider = LlmProvider.OPENAI,
        val baseUrl: String = "https://api.openai.com/v1",
        val apiKey: String = "",
        val model: String = "gpt-4o-mini",
        val maxTokens: Int = 512,
        val temperature: Double = 0.1,
        val imageDetail: String = "low"
    )
    enum class LlmProvider { OPENAI, ANTHROPIC, GOOGLE }
}

data class ModelInfo(val id: String, val providerLabel: String, val supportsVision: Boolean, val supportsChat: Boolean)

sealed class ModelListResult {
    data class Success(val models: List<ModelInfo>, val durationMs: Long) : ModelListResult()
    data class Error(val message: String, val durationMs: Long) : ModelListResult()
}

sealed class LlmResponse {
    data class Success(val content: String, val durationMs: Long) : LlmResponse()
    data class Error(val message: String, val durationMs: Long) : LlmResponse()
}

data class LlmPrompt(val system: String, val userText: String, val imageBase64: String)
