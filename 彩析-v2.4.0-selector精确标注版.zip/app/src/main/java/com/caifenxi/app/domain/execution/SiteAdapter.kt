package com.caifenxi.app.domain.execution

/**
 * V2.0 网站适配器接口
 * 每个投注网站需实现此接口，提供 DOM 操作脚本
 */
interface SiteAdapter {
    val siteId: String
    val whitelistDomains: List<String>

    /** 获取目标页面 URL */
    fun getUrl(lotteryKey: String): String

    /** 期号元素选择器（用于三验） */
    val issueSelector: String

    /** 余额快照脚本（返回 Hash 字符串） */
    val balanceSnapshotScript: String

    /** 构建注入执行脚本 */
    fun buildInjectScript(command: BetCommand): String

    /** 解析执行回执 */
    fun parseReceipt(rawJson: String): ExecutionReceipt
}

/** 执行回执 */
data class ExecutionReceipt(
    val isSuccess: Boolean,
    val isError: Boolean,
    val message: String,
    val orderId: String? = null
)
