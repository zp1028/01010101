package com.caifenxi.app.ui.screens

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import com.caifenxi.app.automation.LocalSelectorLoader
import com.caifenxi.app.data.config.UrlHistoryStore
import com.caifenxi.app.domain.execution.ClickMatchConfig
import com.caifenxi.app.domain.execution.ExecutorManager
import com.caifenxi.app.domain.execution.ExecutionTicketStore
import com.caifenxi.app.service.WebViewExecutor
import com.caifenxi.app.ui.ExecutorViewModel
import com.caifenxi.app.ui.MainViewModel

/**
 * 按钮标注 JavascriptInterface：用户在 WebView 点击元素 → JS 生成 selector → 回传 Android。
 */
class MappingBridge {
    @Volatile
    var onPicked: ((String, String) -> Unit)? = null

    @JavascriptInterface
    fun onPicked(selector: String, text: String) {
        onPicked?.invoke(selector, text)
    }
}

/**
 * 标注模式注入的 JS：监听点击，生成 CSS selector，通过 bridge 回传。
 * 使用全局 flag 控制开关，不重复绑定。
 */
private const val MAPPING_JS = """
if(!window.__CFX_MAPPING_LOADED){
  window.__CFX_MAPPING_LOADED = true;
  window.__CFX_MAPPING_ACTIVE = false;
  window.__cfxMappingClick = function(e){
    if(!window.__CFX_MAPPING_ACTIVE) return;
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    var el = e.target;
    if(!el || el === document) return false;
    var sel = '';
    if(el.id){
      sel = '#' + el.id;
    } else if(el.className && typeof el.className === 'string'){
      var fc = el.className.split(/\s+/)[0];
      sel = fc ? el.tagName.toLowerCase() + '.' + fc : el.tagName.toLowerCase();
    } else {
      var path = [];
      var cur = el;
      while(cur && cur !== document.body){
        var p = cur.parentElement;
        if(!p) break;
        var idx = Array.prototype.indexOf.call(p.children, cur) + 1;
        path.unshift(cur.tagName.toLowerCase() + ':nth-child(' + idx + ')');
        cur = p;
      }
      sel = path.join(' > ');
    }
    el.style.outline = '4px solid #00c853';
    setTimeout(function(){ el.style.outline = ''; }, 2000);
    if(window.CfxMappingBridge){
      window.CfxMappingBridge.onPicked(sel, (el.innerText || '').substring(0, 50));
    }
    return false;
  };
  document.addEventListener('click', window.__cfxMappingClick, true);
}
"""

/**
 * 一级导航全屏网页执行台：
 * - 主区域 WebView
 * - 顶部可折叠状态条：期号/口径/方向金额/执行器/选择器
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebBetScreen(
    mainViewModel: MainViewModel = viewModel(),
    executorViewModel: ExecutorViewModel = viewModel(),
    onBack: () -> Unit = {},
    onWorkbench: () -> Unit = {},
    onBet: () -> Unit = {}
) {
    val context = LocalContext.current
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    val executorStatus by executorViewModel.executorStatus.collectAsState()
    val currentTask by executorViewModel.currentTask.collectAsState()
    val executorLogs by executorViewModel.executorLogs.collectAsState()
    val lastFailedTask by executorViewModel.lastFailedTask.collectAsState()
    val ticket by ExecutionTicketStore.ticket.collectAsState()

    var urlInput by rememberSaveable { mutableStateOf("https://www.baidu.com") }
    var pageTitle by rememberSaveable { mutableStateOf("未加载") }
    var pageStatus by rememberSaveable { mutableStateOf("待命") }
    var panelExpanded by rememberSaveable { mutableStateOf(true) }
    var dryRun by rememberSaveable { mutableStateOf(true) }
    var selectorInfo by remember {
        mutableStateOf(LocalSelectorLoader.current(context))
    }

    // URL 历史/书签
    var urlHistory by remember { mutableStateOf(UrlHistoryStore.getHistory(context)) }
    var showHistory by remember { mutableStateOf(false) }
    val currentEntry = urlHistory.find { it.url == urlInput }
    val isBookmarked = currentEntry?.bookmarked == true

    val lotteryName = mainViewModel.currentLottery.value.name
    val targetIssue = mainViewModel.nextIssueText.value
    val webReady = WebViewExecutor.isAvailable
    val mode = ExecutorManager.getMode()
    var clickProfile by remember { mutableStateOf(ClickMatchConfig.load(context)) }

    // 标注模式状态
    var mappingMode by rememberSaveable { mutableStateOf(false) }
    var mappingStep by rememberSaveable { mutableStateOf(0) }
    var mappingFeedback by remember { mutableStateOf("") }
    val mappingSteps = listOf("大按钮", "小按钮", "单按钮", "双按钮", "金额输入框", "确认按钮", "余额元素")
    val mappingBridge = remember { MappingBridge() }
    val mappingHandler = remember { Handler(Looper.getMainLooper()) }

    // 标注模式：设置 bridge 回调
    LaunchedEffect(mappingMode) {
        if (mappingMode && mappingStep == 0) {
            // 首次进入标注模式：注入 JS + 注册 bridge
            webViewRef?.let { wv ->
                wv.addJavascriptInterface(mappingBridge, "CfxMappingBridge")
                wv.evaluateJavascript(MAPPING_JS, null)
            }
        }
        // 切换 mapping flag
        webViewRef?.evaluateJavascript(
            "window.__CFX_MAPPING_ACTIVE = ${if (mappingMode) "true" else "false"};",
            null
        )
    }

    // bridge 回调：保存 selector 到 ClickMatchConfig，推进到下一步
    mappingBridge.onPicked = { selector, text ->
        mappingHandler.post {
            val step = mappingStep
            if (step >= mappingSteps.size) return@post
            val newProfile = when (step) {
                0 -> clickProfile.copy(selectorBig = selector)
                1 -> clickProfile.copy(selectorSmall = selector)
                2 -> clickProfile.copy(selectorOdd = selector)
                3 -> clickProfile.copy(selectorEven = selector)
                4 -> clickProfile.copy(selectorAmount = selector)
                5 -> clickProfile.copy(selectorConfirm = selector)
                6 -> clickProfile.copy(selectorBalance = selector)
                else -> clickProfile
            }
            ClickMatchConfig.save(context, newProfile)
            ClickMatchConfig.clearCache()
            clickProfile = newProfile
            mappingFeedback = "已保存: ${mappingSteps[step]} → $selector (${text.take(15)})"
            mappingStep = step + 1
            if (mappingStep >= mappingSteps.size) {
                mappingMode = false
                webViewRef?.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = false;", null)
                webViewRef?.removeJavascriptInterface("CfxMappingBridge")
            }
        }
    }

    BackHandler {
        val wv = webViewRef
        if (wv?.canGoBack() == true) wv.goBack() else onBack()
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface)) {
        // —— 顶栏状态（功能可视化）——
        Surface(tonalElevation = 2.dp, shadowElevation = 2.dp) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "返回")
                    }
                    Column(Modifier.weight(1f)) {
                        Text("网页执行台", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(
                            "$lotteryName · 目标期 $targetIssue · 识别:大→${clickProfile.labelBig}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    TextButton(onClick = onWorkbench) { Text("工作台", fontSize = 12.sp) }
                    TextButton(onClick = onBet) { Text("挂机", fontSize = 12.sp) }
                    IconButton(onClick = { panelExpanded = !panelExpanded }) {
                        Icon(
                            if (panelExpanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                            contentDescription = "展开状态"
                        )
                    }
                }

                // 一行关键状态
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatusChip(
                        "按钮映射",
                        if (clickProfile.hasMapping()) "已配置" else "未配置",
                        if (clickProfile.hasMapping()) Color(0xFF2E7D32) else Color(0xFFC62828)
                    )
                    StatusChip(
                        "WebView",
                        if (webReady) "已连接" else "未连接",
                        if (webReady) Color(0xFF2E7D32) else Color(0xFFC62828)
                    )
                    StatusChip(
                        "执行",
                        when (executorStatus) {
                            ExecutorViewModel.ExecutorStatus.IDLE -> "待机"
                            ExecutorViewModel.ExecutorStatus.RUNNING -> "执行中"
                            ExecutorViewModel.ExecutorStatus.COMPLETED -> "完成"
                            else -> executorStatus.name
                        },
                        MaterialTheme.colorScheme.primary
                    )
                    StatusChip(
                        "模式",
                        if (dryRun) "仅识别" else "实盘",
                        if (dryRun) Color(0xFFF9A825) else Color(0xFFC62828)
                    )
                }

                if (panelExpanded) {
                    Spacer(Modifier.height(8.dp))
                    // 选择器
                    val selText = when (val s = selectorInfo) {
                        is LocalSelectorLoader.State.Ok ->
                            "选择器: ${if (s.source == LocalSelectorLoader.Source.EXTERNAL) "外部" else "内置"} v${s.version}"
                        is LocalSelectorLoader.State.ExternalBroken ->
                            "选择器损坏: ${s.message.take(40)}"
                    }
                    Text(selText, style = MaterialTheme.typography.bodySmall,
                        color = if (selectorInfo is LocalSelectorLoader.State.ExternalBroken)
                            MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.onSurfaceVariant)

                    // 工单条：计划 / 口径 / 方向 / 金额 / 回执 / 余额
                    val tk = ticket
                    if (tk.cmdId.isNotBlank()) {
                        Text(
                            "工单 ${ExecutionTicketStore.stageLabel(tk.stage, tk.leg)} · ${tk.planLabel.ifBlank { "挂机" }}",
                            fontWeight = FontWeight.SemiBold,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            "期号 ${tk.issue} · 方向 ${tk.dx ?: "-"}/${tk.ds ?: "-"} · 金额 ${tk.amountText ?: "-"}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            "状态 ${tk.status} · ${tk.message}",
                            style = MaterialTheme.typography.bodySmall,
                            color = when (tk.status) {
                                "SUCCESS" -> Color(0xFF2E7D32)
                                "FAILED", "SKIPPED" -> Color(0xFFC62828)
                                "CLICKED" -> Color(0xFFF9A825)
                                else -> MaterialTheme.colorScheme.onSurfaceVariant
                            }
                        )
                        if (tk.balanceBefore.isNotBlank() || tk.balanceAfter.isNotBlank()) {
                            Text(
                                "余额 ${tk.balanceBefore.ifBlank { "?" }} → ${tk.balanceAfter.ifBlank { "?" }}" +
                                    if (tk.balanceBefore.isNotBlank() && tk.balanceAfter.isNotBlank() && tk.balanceBefore != tk.balanceAfter)
                                        "（已变动，视为点站成功）" else "（未变动，可能未成功或重复）",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    } else {
                        Text(
                            "工单: 等待挂机派发（选计划 → 挂机开启并派发 → 本页执行）",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Text("页面: $pageStatus · $pageTitle", style = MaterialTheme.typography.bodySmall)

                    // URL + 书签 + 历史
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = urlInput,
                            onValueChange = { urlInput = it },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            label = { Text("投注站地址") },
                            textStyle = LocalTextStyle.current.copy(fontSize = 13.sp)
                        )
                        IconButton(onClick = {
                            val newState = UrlHistoryStore.toggleBookmark(context, urlInput)
                            urlHistory = UrlHistoryStore.getHistory(context)
                            val msg = if (newState) "已收藏" else "已取消收藏"
                            android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_SHORT).show()
                        }) {
                            Icon(
                                if (isBookmarked) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                                contentDescription = "书签",
                                tint = if (isBookmarked) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = { showHistory = !showHistory }) {
                            Icon(Icons.Filled.History, contentDescription = "历史",
                                tint = if (showHistory) MaterialTheme.colorScheme.primary
                                       else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { webViewRef?.loadUrl(urlInput) }) {
                            Icon(Icons.Filled.Refresh, contentDescription = "加载")
                        }
                    }

                    // URL 历史下拉
                    if (showHistory) {
                        val items = urlHistory
                        if (items.isEmpty()) {
                            Text("暂无历史记录", fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(vertical = 4.dp))
                        } else {
                            Column(
                                Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = 120.dp)
                                    .verticalScroll(rememberScrollState())
                            ) {
                                items.forEach { entry ->
                                    Row(
                                        Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 2.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        TextButton(
                                            onClick = {
                                                urlInput = entry.url
                                                webViewRef?.loadUrl(entry.url)
                                                showHistory = false
                                            },
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text(
                                                "${if (entry.bookmarked) "★ " else ""}${entry.url}",
                                                fontSize = 11.sp,
                                                maxLines = 1
                                            )
                                        }
                                        Text(
                                            entry.title.ifBlank { "" }.take(20),
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                TextButton(onClick = {
                                    UrlHistoryStore.clearHistory(context)
                                    urlHistory = UrlHistoryStore.getHistory(context)
                                }) { Text("清空历史", fontSize = 11.sp, color = Color(0xFFC62828)) }
                            }
                        }
                    }

                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = dryRun,
                            onClick = { dryRun = true },
                            label = { Text("仅识别") }
                        )
                        FilterChip(
                            selected = !dryRun,
                            onClick = { dryRun = false },
                            label = { Text("实盘点击") }
                        )
                        TextButton(onClick = {
                            selectorInfo = LocalSelectorLoader.reload(context)
                        }) { Text("重载选择器") }
                        TextButton(onClick = {
                            LocalSelectorLoader.exportTemplate(context)
                            selectorInfo = LocalSelectorLoader.reload(context)
                        }) { Text("导出模板") }
                    }

                    // 按钮标注模式
                    Surface(
                        shape = MaterialTheme.shapes.small,
                        color = if (mappingMode) Color(0xFFE8F5E9) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                    ) {
                        Column(Modifier.fillMaxWidth().padding(8.dp)) {
                            Row(
                                Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "按钮标注",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp,
                                    modifier = Modifier.weight(1f)
                                )
                                if (mappingMode) {
                                    Text(
                                        "第 ${mappingStep + 1}/${mappingSteps.size} 步",
                                        fontSize = 11.sp,
                                        color = Color(0xFF2E7D32)
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    TextButton(onClick = {
                                        mappingMode = false
                                        webViewRef?.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = false;", null)
                                        webViewRef?.removeJavascriptInterface("CfxMappingBridge")
                                    }) { Text("退出", color = Color(0xFFC62828), fontSize = 12.sp) }
                                } else {
                                    Button(
                                        onClick = {
                                            mappingStep = 0
                                            mappingFeedback = ""
                                            mappingMode = true
                                        },
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                                    ) { Text("开始标注", fontSize = 12.sp) }
                                }
                            }

                            if (mappingMode) {
                                Text(
                                    "请在页面上点击：${mappingSteps[mappingStep]}",
                                    fontSize = 12.sp,
                                    color = Color(0xFF2E7D32),
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            if (mappingFeedback.isNotBlank()) {
                                Text(
                                    mappingFeedback,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            // 显示已标注的 selector 摘要
                            if (clickProfile.hasMapping()) {
                                val mapped = buildList {
                                    if (clickProfile.selectorBig.isNotBlank()) add("大")
                                    if (clickProfile.selectorSmall.isNotBlank()) add("小")
                                    if (clickProfile.selectorOdd.isNotBlank()) add("单")
                                    if (clickProfile.selectorEven.isNotBlank()) add("双")
                                    if (clickProfile.selectorAmount.isNotBlank()) add("金额")
                                    if (clickProfile.selectorConfirm.isNotBlank()) add("确认")
                                    if (clickProfile.selectorBalance.isNotBlank()) add("余额")
                                }
                                Text(
                                    "已标注: ${mapped.joinToString(" · ")}",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                TextButton(
                                    onClick = {
                                        val cleared = clickProfile.copy(
                                            selectorBig = "", selectorSmall = "",
                                            selectorOdd = "", selectorEven = "",
                                            selectorAmount = "", selectorConfirm = "",
                                            selectorBalance = ""
                                        )
                                        ClickMatchConfig.save(context, cleared)
                                        ClickMatchConfig.clearCache()
                                        clickProfile = cleared
                                        mappingFeedback = "已清空所有标注"
                                    },
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
                                ) { Text("清空标注", fontSize = 10.sp, color = Color(0xFFC62828)) }
                            }
                        }
                    }
                    Spacer(Modifier.height(4.dp))

                    // 操作
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                val t = executorViewModel.generateTestTask()
                                executorViewModel.startTask(t)
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("测试执行") }
                        if (lastFailedTask != null) {
                            Button(
                                onClick = { executorViewModel.retryLastTask() },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFFC62828)
                                )
                            ) {
                                Icon(Icons.Filled.Replay, contentDescription = "重试",
                                    modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("重试")
                            }
                        }
                        OutlinedButton(
                            onClick = { executorViewModel.clearLogs() },
                            modifier = Modifier.weight(1f)
                        ) { Text("清空日志") }
                    }

                    // 日志
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .heightIn(max = 100.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        if (executorLogs.isEmpty()) {
                            Text("日志空 · 挂机下单后将自动派发到本页", fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        } else {
                            executorLogs.takeLast(8).forEach { log ->
                                Text(
                                    log,
                                    fontSize = 11.sp,
                                    color = when {
                                        log.contains("成功") -> Color(0xFF2E7D32)
                                        log.contains("失败") || log.contains("未找到") -> Color(0xFFC62828)
                                        else -> MaterialTheme.colorScheme.onSurface
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // —— 全屏 WebView ——
        AndroidView(
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.useWideViewPort = true
                    settings.loadWithOverviewMode = true
                    settings.domStorageEnabled = true
                    settings.userAgentString =
                        "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                    webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView?, url: String?) {
                            pageStatus = "已加载"
                            pageTitle = view?.title ?: url ?: ""
                            if (url != null) {
                                urlInput = url
                                UrlHistoryStore.recordVisit(ctx, url, pageTitle)
                                urlHistory = UrlHistoryStore.getHistory(ctx)
                            }
                            WebViewExecutor.attach(this@apply)
                            WebViewExecutor.heartbeat()
                        }
                    }
                    webChromeClient = object : WebChromeClient() {
                        override fun onReceivedTitle(view: WebView?, title: String?) {
                            if (!title.isNullOrBlank()) pageTitle = title
                        }
                    }
                    WebViewExecutor.attach(this)
                    webViewRef = this
                    // 使用已保存的 URL，而非硬编码默认值
                    val currentUrl = urlInput.ifBlank { "https://www.baidu.com" }
                    loadUrl(currentUrl)
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            update = { wv ->
                webViewRef = wv
            }
        )
    }
}

@Composable
private fun StatusChip(label: String, value: String, color: Color) {
    Surface(
        shape = MaterialTheme.shapes.small,
        color = color.copy(alpha = 0.12f)
    ) {
        Text(
            "$label $value",
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            fontSize = 11.sp,
            color = color,
            fontWeight = FontWeight.Medium
        )
    }
}
