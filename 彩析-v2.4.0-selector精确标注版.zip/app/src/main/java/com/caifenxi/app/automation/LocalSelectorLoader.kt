package com.caifenxi.app.automation

import android.content.Context
import com.caifenxi.app.util.RuntimeLog
import java.io.File

/**
 * 选择器加载：外部 files/selectors.json > assets/selectors_default.json
 * 外部文件损坏则熔断（不静默回退），避免旧选择器误下单。
 */
object LocalSelectorLoader {
    enum class Source { EXTERNAL, ASSETS }

    sealed class State {
        data class Ok(val config: BetAutomationConfig, val source: Source, val version: String) : State()
        data class ExternalBroken(val message: String) : State()
    }

    private const val EXT_NAME = "selectors.json"
    private const val ASSET_NAME = "selectors_default.json"

    @Volatile private var cached: State? = null
    @Volatile private var lastMtime = Long.MIN_VALUE

    fun externalFile(ctx: Context): File {
        val ext = ctx.getExternalFilesDir(null)
        return if (ext != null) File(ext, EXT_NAME) else File(ctx.filesDir, EXT_NAME)
    }

    fun current(ctx: Context): State {
        val mtime = mtimeOf(ctx)
        cached?.let { if (mtime == lastMtime) return it }
        synchronized(this) {
            val m = mtimeOf(ctx)
            cached?.let { if (m == lastMtime) return it }
            return load(ctx).also { cached = it; lastMtime = m }
        }
    }

    fun reload(ctx: Context): State = synchronized(this) {
        lastMtime = Long.MIN_VALUE
        current(ctx)
    }

    fun exportTemplate(ctx: Context, overwrite: Boolean = false): Result<File> = runCatching {
        val dst = externalFile(ctx)
        check(overwrite || !dst.exists()) { "外部配置已存在: ${dst.path}" }
        ctx.assets.open(ASSET_NAME).use { ins -> dst.outputStream().use { ins.copyTo(it) } }
        RuntimeLog.info("Selector", "已导出模板: ${dst.path}")
        dst
    }

    private fun mtimeOf(ctx: Context): Long =
        externalFile(ctx).let { if (it.exists()) it.lastModified() else 0L }

    private fun load(ctx: Context): State {
        val ext = externalFile(ctx)
        return if (ext.exists()) {
            runCatching {
                val text = ext.readText()
                val cfg = BetAutomationConfig.fromJson(text) ?: error("字段缺失或类型不符")
                State.Ok(cfg, Source.EXTERNAL, cfg.version.ifEmpty { "external" }).also {
                    RuntimeLog.info("Selector", "外部配置生效 v=${it.version}")
                }
            }.getOrElse {
                val msg = "${it.message} · ${ext.path}"
                RuntimeLog.warn("Selector", "外部配置损坏，已阻止使用旧配置: $msg")
                State.ExternalBroken(msg)
            }
        } else {
            val text = ctx.assets.open(ASSET_NAME).bufferedReader().use { it.readText() }
            val cfg = BetAutomationConfig.fromJson(text)
                ?: BetAutomationConfig(version = "builtin-fallback")
            State.Ok(cfg, Source.ASSETS, cfg.version.ifEmpty { "builtin" }).also {
                RuntimeLog.info("Selector", "内置配置生效 v=${it.version}")
            }
        }
    }
}
