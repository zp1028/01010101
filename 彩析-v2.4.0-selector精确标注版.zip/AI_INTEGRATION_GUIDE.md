# 彩析 AI 大模型集成指南

## 快速开始

### 1. 配置 LLM API

打开「更多 → 🧠 AI 大模型设置」，填写以下信息：

#### OpenAI (推荐)
- **提供商**: OPENAI
- **Base URL**: `https://api.openai.com/v1`
- **API Key**: 你的 OpenAI API Key (sk-...)
- **模型**: `gpt-4o-mini` (推荐) 或 `gpt-4o`

#### Anthropic Claude
- **提供商**: ANTHROPIC
- **Base URL**: `https://api.anthropic.com/v1`
- **API Key**: 你的 Anthropic API Key
- **模型**: `claude-3-5-sonnet-20241022`

#### Google Gemini
- **提供商**: GOOGLE
- **Base URL**: `https://generativelanguage.googleapis.com/v1beta`
- **API Key**: 你的 Google API Key
- **模型**: `gemini-1.5-pro` 或 `gemini-1.5-flash`

### 2. 选择执行模式

| 模式 | 说明 | 适用场景 |
|------|------|---------|
| 自动 | AI优先，不可用时降级 | 推荐日常使用 |
| 仅AI视觉 | 强制使用AI | 测试AI能力 |
| 仅内置网页 | 强制使用WebView | 网页稳定时 |
| 仅无障碍 | 强制使用传统方式 | AI不可用时 |

### 3. 测试连接

点击「测试连接」按钮，验证API连通性。成功后会显示响应时间。

### 4. 保存并开始使用

保存配置后，AI执行器会自动注册。下次执行投注时会优先使用AI视觉模式。

---

## 工作原理

### 执行流程
```
1. BetCommand 生成（预测/计划/倍投逻辑不变）
2. ExecutorManager 选择执行器（AI优先）
3. AiVisionExecutor 开始执行：
   a. 截图当前页面（AccessibilityService.takeScreenshot）
   b. 提取 Accessibility 节点树
   c. 构建多模态 Prompt（截图+节点树+任务目标）
   d. 调用 LLM API 获取决策
   e. 解析 Action（click/type/scroll/wait/finish/fail）
   f. 执行手势操作
   g. 循环直到完成或失败
4. 执行后校验（再次截图确认）
5. 返回 ExecutionResult
```

### 降级策略
```
AI视觉失败 → WebView → 无障碍 → 仅记账
```

触发降级条件：
- LLM 连续3次失败
- API 响应 > 5秒
- 截图失败
- 置信度 < 0.75

---

## 高级配置

### Temperature
- **0.0-0.3**: 确定性输出，推荐用于投注执行
- **0.3-0.7**: 平衡模式
- **0.7-1.0**: 创造性模式，不推荐

### Max Tokens
- **256**: 快速响应，简单页面
- **512**: 标准配置（推荐）
- **1024+**: 复杂页面，响应较慢

### 图像质量
- **low**: 512x512，token最少，成本最低（推荐）
- **medium**: 768x768，平衡
- **high**: 原图，精度最高但成本高

---

## 故障排查

### "AI视觉执行器不可用"
- 检查无障碍服务是否已开启
- 检查 API Key 是否正确
- 检查网络连接

### "截图失败"
- Android 11+ 需要 `canTakeScreenshot="true"`（已配置）
- 低版本需要 MediaProjection 授权
- 检查无障碍服务权限

### "LLM请求失败"
- 检查 API Key 是否有效
- 检查 Base URL 是否正确
- 检查网络是否可访问API
- 查看日志获取详细错误

### "执行后校验不确定"
- 页面响应较慢，可增加等待时间
- 页面结构复杂，可尝试更高分辨率
- 可切换到传统模式执行

---

## 安全建议

1. **API Key 安全**
   - 不要硬编码在代码中
   - 使用环境变量或加密存储
   - 定期轮换 API Key

2. **数据隐私**
   - 截图可能包含敏感信息
   - 使用本地模型可避免上传截图
   - 定期检查 API 调用日志

3. **成本控制**
   - 设置每日/每月预算上限
   - 使用 GPT-4o-mini 降低成本
   - 监控 API 调用频率

---

## 开发扩展

### 添加新的 LLM 提供商

在 `LlmClient.kt` 中：
1. 在 `LlmProvider` 枚举中添加新提供商
2. 实现 `callXXX()` 方法
3. 在 `chat()` 方法中添加分支

### 自定义 Prompt

修改 `AiPromptBuilder.kt` 中的 `SYSTEM_PROMPT`：
- 调整识别规则
- 添加新的操作类型
- 修改输出格式

### 本地模型部署

如需使用本地模型（如 Qwen2.5-VL）：
1. 部署模型到本地服务器
2. 设置 Base URL 为本地地址
3. 选择兼容 OpenAI API 格式的模型

---

## 版本历史

| 版本 | 日期 | 更新内容 |
|------|------|---------|
| 2.4.0-AI | 2024-09 | AI大模型视觉执行 |
| 2.3.4 | 2024-08 | 工作台计划预测+挂机倍投 |
