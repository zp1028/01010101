# 彩析 CaiFenXi 2.4.0-AI

工作台计划预测 + 挂机一期/二期/三期倍投 + 内置 WebView 执行台 + **AI 大模型视觉执行**。

- `versionName` 2.4.0-AI / `versionCode` 35
- 最低 Android 7.0（API 24），compile/target SDK 35
- **新增：AI 视觉执行器，支持 GPT-4o / Claude 3.5 Sonnet / Gemini**

> 预测与自动执行仅供统计、回测和研究，不构成投注建议。

## 🧠 AI 大模型视觉执行（v2.4.0 新增）

### 功能
- **多模态理解**：截图 + Accessibility 节点树 → LLM 分析 → 结构化 Action
- **三种执行器**：AI 视觉（优先）→ 内置网页 → 无障碍，自动降级
- **支持模型**：OpenAI GPT-4o/4o-mini、Anthropic Claude 3.5 Sonnet、Google Gemini
- **智能校验**：执行后截图二次确认，失败自动重试

### 配置
1. 打开「更多 → 🧠 AI 大模型设置」
2. 选择 LLM 提供商（OpenAI/Anthropic/Google）
3. 输入 API Key 和模型名称
4. 选择执行模式（自动/仅AI/仅网页/仅无障碍）
5. 点击「测试连接」验证
6. 保存配置

### 成本估算
| 模型 | 单次投注成本 | 推荐场景 |
|------|------------|---------|
| GPT-4o-mini | ~¥0.03 | 日常高频 |
| GPT-4o | ~¥0.15 | 复杂页面 |
| Claude 3.5 Sonnet | ~¥0.50 | 高精度需求 |

## 用 Git 仓库构建 APK

### 1. 环境

- JDK 17
- Android SDK（platforms;android-35，build-tools 35.0.0）
- 本仓库已含 Gradle Wrapper 8.9

### 2. 克隆

```bash
git clone <你的仓库地址> CaiFenXi
cd CaiFenXi
```

### 3. 配置 SDK

```bash
cp local.properties.example local.properties
# 编辑 sdk.dir 为本机 Android SDK 路径
```

Android Studio：直接 Open 本目录，会自动生成 `local.properties`。

### 4. 本地出包

```bash
chmod +x ./gradlew
./gradlew assembleDebug
# 产物: app/build/outputs/apk/debug/app-debug.apk

./gradlew assembleRelease
# 产物: app/build/outputs/apk/release/app-release-unsigned.apk
```

或运行 `./build.sh`。

### 5. GitHub Actions 出包

1. 把本仓库推到 GitHub（源码在仓库根目录，不要只传 zip）
2. 打开 Actions → **Build APK** → Run workflow
3. 下载 Artifact `caifenxi-debug-apk`

正式签名包用 **Build Release APK**，需在仓库 Secrets 配置：

- `ANDROID_KEYSTORE_B64`
- `ANDROID_KEYSTORE_PASS`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASS`

打 tag 也会触发正式包：`git tag v2.4.0-ai && git push origin v2.4.0-ai`

## 目录

```
app/                 Android 应用
gradle/wrapper/      Gradle 8.9 Wrapper
.github/workflows/   CI 构建 APK
```

## 主要入口

- 工作台：计划与回测
- 挂机：选计划、一期/二期/三期、金额倍投、执行方式
- 网页：全屏 WebView 执行台与工单/余额校验
- **AI 设置：🧠 大模型配置与测试**

## 架构

```
BetCommand → ExecutorManager → [AI Vision] → [WebView] → [Accessibility]
                ↓
         PerceptionEngine (截图+节点树)
                ↓
         LlmClient (GPT-4o/Claude/Gemini)
                ↓
         AiVisionExecutor (手势执行)
```
