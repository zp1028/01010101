package com.diveintocrypto.android.domain.scanner

import kotlin.math.abs

/** Structured AI advice passed into deterministic post-scan guardrails. */
data class AiFusionAdvice(
    val direction: String,
    val confidence: Int,
    val fakeBreakoutRisk: Int,
    val entry: Double?,
    val stop: Double?,
    val target: Double?,
    val riskRewardRatio: Double?,
)

/**
 * Deterministic guardrail for post-scan AI ranking. Strong AI evidence may reverse the
 * displayed direction, but only when confidence, breakout-risk, price geometry and RR pass.
 */
object AiFusionPolicy {
    data class Decision(
        val delta: Double,
        val status: String,
        val reason: String,
        val acceptedPlan: Boolean,
        val finalDirection: Int,
    )

    fun evaluate(
        localDirection: Int,
        localPrice: Double,
        atrPct: Double?,
        advice: AiFusionAdvice?,
    ): Decision {
        if (advice == null) return Decision(0.0, "NO_ADVICE", "AI未返回可解析结果，保留本地方向与排名", false, localDirection)
        val aiDirection = when (advice.direction.uppercase()) { "LONG" -> 1; "SHORT" -> -1; else -> 0 }
        if (aiDirection == 0) return Decision(-0.01, "AI-NEUTRAL", "AI证据不足，建议观望；保留本地方向", false, localDirection)
        if (advice.confidence < 60) return Decision(-0.01, "LOW_CONFIDENCE", "AI置信度低于60%，不改变方向", false, localDirection)

        val entry = advice.entry
        val stop = advice.stop
        val target = advice.target
        val risk = if (entry != null && stop != null) abs(entry - stop) else 0.0
        val reward = if (entry != null && target != null) abs(target - entry) else 0.0
        val computedRr = if (risk > 0.0) reward / risk else 0.0
        val geometryValid = entry != null && stop != null && target != null &&
            entry > 0 && stop > 0 && target > 0 &&
            (if (aiDirection > 0) stop < entry && target > entry else stop > entry && target < entry) &&
            computedRr >= 1.2 && (advice.riskRewardRatio == null || advice.riskRewardRatio >= 1.0) &&
            localPrice > 0 && abs(entry - localPrice) / localPrice * 100.0 <=
            (atrPct?.takeIf { it > 0 }?.times(1.5) ?: 0.75).coerceIn(0.25, 2.0)

        val sameDirection = localDirection != 0 && aiDirection == localDirection
        val reversalAccepted = localDirection != 0 && aiDirection != localDirection &&
            advice.confidence >= 78 && advice.fakeBreakoutRisk <= 55 && geometryValid
        val neutralAdoptionAccepted = localDirection == 0 && advice.confidence >= 78 &&
            advice.fakeBreakoutRisk <= 45 && geometryValid
        val finalDirection = when {
            sameDirection || reversalAccepted || neutralAdoptionAccepted -> aiDirection
            else -> localDirection
        }
        val acceptedPlan = geometryValid && (sameDirection || reversalAccepted || neutralAdoptionAccepted)
        val delta = when {
            reversalAccepted -> 0.04 * (advice.confidence / 100.0)
            sameDirection -> 0.025 * (advice.confidence / 100.0)
            else -> -0.075 * (advice.confidence / 100.0)
        } - if (advice.fakeBreakoutRisk >= 75) 0.02 else 0.0
        val status = when {
            reversalAccepted -> "REVERSAL"
            neutralAdoptionAccepted -> "AI-DIRECTION-SET"
            sameDirection -> "ALIGNED"
            else -> "CONFLICT"
        }
        val directionLabel = when {
            reversalAccepted -> "AI方向反转已通过校验（置信度${advice.confidence}%，假突破风险${advice.fakeBreakoutRisk}%）"
            neutralAdoptionAccepted -> "本地方向中性，AI方向通过高置信度与计划校验"
            sameDirection -> "AI与本地方向一致"
            else -> "AI方向与本地冲突或证据不足，未满足方向变更门槛，保留本地方向"
        }
        val planLabel = if (acceptedPlan) "AI计划通过价格结构/RR校验" else "AI计划未通过校验，不采用其入场止损止盈"
        return Decision(delta.coerceIn(-0.10, 0.05), status, "$directionLabel；$planLabel", acceptedPlan, finalDirection)
    }
}
