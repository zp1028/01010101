# 挂机跟随优化说明（v2.4.8）

## 目标
挂机页选计划 / 一期·二期 / 金额 → 每期自动派发方向+金额 → 网页与无障碍同源执行。

## 数据流
挂机 BotConfig → BetEngine.placeAutoBets → BetCommand(dx/ds/amount) → dispatchBetCommand
  → WebView 执行 / 无障碍跟随 placed 缓存 / 未就绪则 PendingBetQueue

## 配置
1. 挂机开启（开启时若未派发会自动打开「同步派发」）
2. 计划来源 + 一期/二期 + 金额
3. 同步派发 = 开；执行模式 = 自动或网页
4. 网页页已连接并完成按钮标注

## 日志
搜索 `HANG→EXEC`：每期派发的期号、stage、leg、方向、金额、计划名。

## 工单状态
QUEUED / RUNNING / PENDING（排队）/ SUCCESS / FAILED

## 验收
- 每期自动出单并派发
- 工单方向金额与挂机一致
- 网页未开时 PENDING，打开后自动补点
