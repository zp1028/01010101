# WebView 自动挂机全链路优化 v2.5.0

## 核心目标
挂机页产生的每期方向、一期/二期/三期 stage/leg 与实际金额，必须原样形成唯一执行工单，再由 WebView 严格按标注 selector 执行。

## 已完成
- 会话级安全总闸增加当前彩种绑定，未主动开启当前挂机会话不得执行。
- WebView、调度器、Pending 队列均受安全总闸控制。
- 同彩种同一期增加 in-flight claim，阻止并发重复执行。
- 显式选择 webview/accessibility 时不再偷偷跨执行器 fallback。
- UNKNOWN/TIMEOUT 不自动换执行器或重试，避免已提交但未确认导致重复下注。
- WebView 生产执行必须完成四个方向 selector、金额 selector、确认 selector。
- 删除金额输入的模糊/筹码 fallback；金额 selector 失效直接停止。
- 金额输入后再次解析真实 input 并复核页面实际值。
- 执行前校验 issue、stage、leg、金额和方向。
- 挂机调度器 start 会恢复合法队列，stop 清空生产队列。
- BetEngine 对大小/单双实际单注金额进行一致性检查；发现同一期方向金额不一致时不向 WebView 派发，避免错单。
- 每期工单继续携带 stage/leg、amountText、方向、来源。

## 关键执行链
挂机策略 → 预测方向 → stage/leg → 实际下注金额 → 唯一 BetCommand → SafetyGate → Scheduler → WebView 精确 selector → 金额输入 → 金额复核 → 确认 → 结果记录。
