package com.caifenxi.app.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.caifenxi.app.domain.execution.BetAction
import com.caifenxi.app.domain.execution.BetCommand
import com.caifenxi.app.domain.execution.ExecutionResult
import com.caifenxi.app.domain.execution.ExecutionTask
import com.caifenxi.app.domain.execution.ClickMatchConfig
import com.caifenxi.app.domain.execution.ExecutorManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * 网页执行台 ViewModel：真实派发 ExecutorManager，日志供 UI 展示。
 */
class ExecutorViewModel : ViewModel() {

    private val _executorStatus = MutableStateFlow(ExecutorStatus.IDLE)
    val executorStatus: StateFlow<ExecutorStatus> = _executorStatus.asStateFlow()

    private val _currentTask = MutableStateFlow<ExecutionTask?>(null)
    val currentTask: StateFlow<ExecutionTask?> = _currentTask.asStateFlow()

    private val _executorLogs = MutableStateFlow<List<String>>(emptyList())
    val executorLogs: StateFlow<List<String>> = _executorLogs.asStateFlow()

    private val _lastFailedTask = MutableStateFlow<ExecutionTask?>(null)
    val lastFailedTask: StateFlow<ExecutionTask?> = _lastFailedTask.asStateFlow()

    private val _executorStats = MutableStateFlow(ExecutorStats())
    val executorStats: StateFlow<ExecutorStats> = _executorStats.asStateFlow()

    private val _autoRunning = MutableStateFlow(false)
    val autoRunning: StateFlow<Boolean> = _autoRunning.asStateFlow()

    private val _executionMode = MutableStateFlow(ExecutorManager.getMode())
    val executionMode: StateFlow<String> = _executionMode.asStateFlow()

    init {
        addLog("执行器就绪 · 等待挂机指令或测试执行")
        addLog("WebView=${if (ExecutorManager.isAvailable("webview")) "可用" else "未连接"} 无障碍=${if (ExecutorManager.isAvailable("accessibility")) "可用" else "未开启"} 模式=${ExecutorManager.getMode()}")
    }

    /** 切换执行模式：webview（DOM注入）或 accessibility（无障碍手势） */
    fun setExecutionMode(mode: String) {
        ExecutorManager.setMode(mode)
        _executionMode.value = mode
        addLog("执行模式切换为: ${if (mode == "accessibility") "无障碍" else "WebView DOM"}")
    }

    /** 开始自动挂机：标记运行状态 + arm 安全闸 + 清空测试参数 */
    fun startAuto(lotteryKey: String = "") {
        _autoRunning.value = true
        com.caifenxi.app.domain.execution.ExecutionSafetyGate.arm(lotteryKey, "executor_start")
        addLog("▶ 自动挂机已开启 · 模式=${if (_executionMode.value == "accessibility") "无障碍" else "WebView DOM"}")
    }

    /** 停止自动挂机：disarm 安全闸 */
    fun stopAuto() {
        _autoRunning.value = false
        com.caifenxi.app.domain.execution.ExecutionSafetyGate.disarm("executor_stop")
        stopAllTasks()
        addLog("■ 自动挂机已停止")
    }

    /** 页面回到前台时同步 SafetyGate 状态，防止 UI 与实际状态脱节 */
    fun syncSafetyGateState() {
        val armed = com.caifenxi.app.domain.execution.ExecutionSafetyGate.isArmed()
        if (armed && !_autoRunning.value) {
            _autoRunning.value = true
            addLog("▶ 自动挂机状态已同步（SafetyGate 已开启）")
        } else if (!armed && _autoRunning.value) {
            _autoRunning.value = false
            addLog("■ 自动挂机状态已同步（SafetyGate 已关闭）")
        }
    }

    /**
     * 旧“测试点击”入口改为纯诊断，避免无参数时偷偷使用固定方向/金额去点网页。
     * 真正的测试执行必须通过 WebBetScreen 显式选择方向和金额后触发。
     */
    fun testClick(context: android.content.Context) {
        addLog("测试点击已改为安全诊断 · 不派发、不点击网页")
        testSelectorsOnly(context)
    }

    fun startTask(task: ExecutionTask) {
        viewModelScope.launch {
            _executorStatus.value = ExecutorStatus.RUNNING
            _currentTask.value = task
            addLog("开始 ${task.cmdId} ${task.lotteryKey}/${task.issue} ${task.dx ?: "-"}/${task.ds ?: "-"} 金额=${task.amountText}")

            val cmd = task.command ?: BetCommand(
                cmdId = task.cmdId,
                lotteryKey = task.lotteryKey,
                issue = task.issue,
                stage = task.stage,
                leg = task.leg,
                bets = buildList {
                    task.dx?.let { add(BetAction(BetAction.CAT_DX, it)) }
                    task.ds?.let { add(BetAction(BetAction.CAT_DS, it)) }
                    task.combo?.let { add(BetAction(BetAction.CAT_COMBO, it)) }
                    task.predNumbers.forEach { add(BetAction(BetAction.CAT_NUMBER, it)) }
                },
                amountText = task.amountText,
                source = task.source,
                expireAt = task.expireAt
            )

            if (cmd.bets.isEmpty()) {
                addLog("失败: 无注项")
                _executorStatus.value = ExecutorStatus.FAILED
                _currentTask.value = null
                return@launch
            }

            val result = suspendCancellableCoroutine { cont ->
                val accepted = ExecutorManager.execute(cmd) { r ->
                    if (cont.isActive) cont.resume(r)
                }
                if (!accepted) {
                    if (cont.isActive) {
                        cont.resume(
                            com.caifenxi.app.domain.execution.ExecutionResult.fail(
                                cmd.cmdId,
                                com.caifenxi.app.domain.execution.ExecutionResult.WEBVIEW_DISCONNECTED,
                                "无可用执行器（需开启无障碍服务+配置LLM以启用AI视觉，或打开网页加载投注站）"
                            )
                        )
                    }
                }
            }

            val stats = _executorStats.value
            if (result.success) {
                _executorStatus.value = ExecutorStatus.COMPLETED
                addLog("成功: ${result.message}")
                _lastFailedTask.value = null
                _executorStats.value = stats.copy(
                    totalTasks = stats.totalTasks + 1,
                    successfulTasks = stats.successfulTasks + 1
                )
            } else {
                _executorStatus.value = ExecutorStatus.FAILED
                addLog("失败: ${result.message}")
                _lastFailedTask.value = task
                _executorStats.value = stats.copy(
                    totalTasks = stats.totalTasks + 1,
                    failedTasks = stats.failedTasks + 1
                )
            }
            _currentTask.value = null
            _executorStatus.value = ExecutorStatus.IDLE
        }
    }

    fun stopAllTasks() {
        _executorStatus.value = ExecutorStatus.IDLE
        _currentTask.value = null
        addLog("已停止")
    }

    /** 重试上一次失败的任务：生成新 cmdId 避免去重拦截 */
    fun retryLastTask() {
        val failed = _lastFailedTask.value ?: run {
            addLog("无可重试的失败任务")
            return
        }
        val newCmdId = "retry_${System.currentTimeMillis()}"
        val retried = failed.copy(cmdId = newCmdId, command = null)
        addLog("重试任务 $newCmdId（原 ${failed.cmdId}）")
        startTask(retried)
    }

    fun clearLogs() {
        _executorLogs.value = emptyList()
        addLog("日志已清空")
    }

    /**
     * 生成测试工单：绝不再写死 pk10/test-issue/大/单/10。
     * 测试方向、金额必须由 UI 显式传入，避免“测试执行”误点旧方向。
     */
    fun generateTestTask(
        dryRun: Boolean = true,
        dx: String? = null,
        ds: String? = null,
        amountText: String? = null,
        lotteryKey: String = "test",
        issue: String = "test-${System.currentTimeMillis()}"
    ): ExecutionTask {
        // v2.5.3: 测试执行安全增强 — 拒绝多方向同时下注（防误点）
        val safeDx = dx?.takeIf { it in setOf("大", "小") }
        val safeDs = ds?.takeIf { it in setOf("单", "双") }
        val bets = buildList {
            safeDx?.let { add(BetAction(BetAction.CAT_DX, it)) }
            safeDs?.let { add(BetAction(BetAction.CAT_DS, it)) }
        }
        val cmd = BetCommand(
            cmdId = "test_${System.currentTimeMillis()}",
            lotteryKey = lotteryKey,
            issue = issue,
            stage = 1,
            leg = 0,
            bets = bets,
            amountText = amountText?.trim()?.takeIf { it.isNotBlank() },
            source = "manual-test",
            expireAt = System.currentTimeMillis() + 300_000,
            options = mapOf(
                "dryRun" to if (dryRun) "true" else "false",
                "manualTest" to "1",
                "testExplicit" to "1"
            )
        )
        return ExecutionTask.fromCommand(cmd, source = "manual-test").copy(executor = _executionMode.value)
    }

    /** 仅检查选择器配置，不触发网页点击。 */
    fun testSelectorsOnly(context: android.content.Context) {
        val p = ClickMatchConfig.load(context)
        val missing = buildList {
            if (p.selectorBig.isBlank()) add("大")
            if (p.selectorSmall.isBlank()) add("小")
            if (p.selectorOdd.isBlank()) add("单")
            if (p.selectorEven.isBlank()) add("双")
            if (p.selectorAmount.isBlank()) add("金额")
            if (p.selectorConfirm.isBlank()) add("确认")
        }
        val mappingError = p.executionValidationError()
        if (mappingError == null) {
            addLog("选择器检查通过 · 大/小/单/双/金额/确认均唯一 · 本次未点击网页")
        } else {
            addLog("选择器检查未通过 · $mappingError · 本次未点击网页")
        }
    }

    private fun addLog(message: String) {
        val line = "${java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())} $message"
        _executorLogs.value = (_executorLogs.value + line).takeLast(50)
    }

    enum class ExecutorStatus { IDLE, RUNNING, COMPLETED, FAILED, CANCELLED }

    data class ExecutorStats(
        val totalTasks: Int = 0,
        val successfulTasks: Int = 0,
        val failedTasks: Int = 0
    )
}
