package com.caifenxi.app.domain.execution

import com.caifenxi.app.service.WebViewBetExecutor
import com.caifenxi.app.util.RuntimeLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout
import kotlin.coroutines.resume

/**
 * 下注调度器：按彩种排队，优先 WebView，其次无障碍。
 */
class BetScheduler(
    private val repository: ExecutionRepository,
    private val webViewExecutor: WebViewBetExecutor,
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
) {
    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning

    private val queues = java.util.concurrent.ConcurrentHashMap<String, ArrayDeque<ExecutionTask>>()
    private val activeJobs = java.util.concurrent.ConcurrentHashMap<String, Job>()
    private val queueLock = Any()

    fun attachWebView(webView: android.webkit.WebView) {
        webViewExecutor.attachWebView(webView)
    }

    fun dispatch(task: ExecutionTask) {
        val key = task.lotteryKey
        synchronized(queueLock) {
            queues.computeIfAbsent(key) { ArrayDeque() }.addLast(task)
        }
        val size = synchronized(queueLock) { queues[key]?.size ?: 0 }
        RuntimeLog.info(
            "Scheduler",
            "派发任务 cmdId=${task.cmdId} $key/${task.issue} 队列=$size"
        )
        triggerNext(key)
    }

    fun start() {
        _isRunning.value = true
        val keys = synchronized(queueLock) { queues.keys.toList() }
        keys.forEach { triggerNext(it) }
        RuntimeLog.info("Scheduler", "调度器启动，恢复队列=${keys.size}")
    }

    fun stop() {
        _isRunning.value = false
        synchronized(activeJobs) {
            activeJobs.values.forEach { it.cancel() }
            activeJobs.clear()
        }
        synchronized(queueLock) { queues.values.forEach { it.clear() } }
        RuntimeLog.info("Scheduler", "调度器停止并清空生产队列")
    }

    private fun triggerNext(lotteryKey: String) {
        if (!_isRunning.value) return
        synchronized(activeJobs) {
            if (activeJobs[lotteryKey]?.isActive == true) return
        }
        val task: ExecutionTask
        synchronized(queueLock) {
            val queue = queues[lotteryKey] ?: return
            task = queue.removeFirstOrNull() ?: return
        }
        synchronized(activeJobs) {
            activeJobs[lotteryKey] = scope.launch {
                try {
                    executeTask(task)
                } finally {
                    synchronized(activeJobs) { activeJobs.remove(lotteryKey) }
                    triggerNext(lotteryKey)
                }
            }
        }
    }

    private suspend fun executeTask(task: ExecutionTask) {
        val cmd = task.command ?: run {
            RuntimeLog.warn("Scheduler", "任务无 command，跳过 cmdId=${task.cmdId}")
            return
        }
        RuntimeLog.info("Scheduler", "开始执行 cmdId=${cmd.cmdId} ${cmd.lotteryKey}/${cmd.issue}")

        // v2.5.3: 执行前前置拦截 — 确认按钮已点击过的期号绝对不执行
        if (ExecutionTicketStore.isIssueConfirmed(cmd.lotteryKey, cmd.issue)) {
            RuntimeLog.info(
                "Scheduler",
                "【执行前拦截】本期已确认点击，永久锁定不执行 cmdId=${cmd.cmdId} ${cmd.lotteryKey}/${cmd.issue}"
            )
            repository.complete(
                cmd.cmdId,
                ExecutionResult.committedUnknown(cmd.cmdId, "本期已确认点击，执行被前置拦截")
            )
            return
        }

        if (ExecutionTicketStore.isIssuePlaced(cmd.lotteryKey, cmd.issue)) {
            RuntimeLog.info(
                "Scheduler",
                "本期已成功，跳过执行 cmdId=${cmd.cmdId} ${cmd.lotteryKey}/${cmd.issue}"
            )
            repository.complete(
                cmd.cmdId,
                ExecutionResult.ok(cmd.cmdId, "本期已成功，跳过执行")
            )
            return
        }

        if (cmd.expireAt > 0L && System.currentTimeMillis() > cmd.expireAt) {
            repository.expire(cmd.cmdId)
            RuntimeLog.warn("Scheduler", "任务过期 cmdId=${cmd.cmdId}")
            return
        }

        if (repository.isLotteryBlocked(cmd.lotteryKey) && task.state == ExecutionTask.State.CREATED) {
            RuntimeLog.warn("Scheduler", "彩种阻塞，稍后重试 cmdId=${cmd.cmdId}")
            queues.getOrPut(cmd.lotteryKey) { ArrayDeque() }.addFirst(task)
            delay(5000)
            return
        }

        // 通过 ExecutorManager 统一派发，AI 视觉优先，失败降级 webview→accessibility
        repository.transition(cmd.cmdId, ExecutionTask.State.CREATED, ExecutionTask.State.LOCKED)
        val result = try {
            // AI 视觉执行链多步 LLM 调用 + 降级 fallback，给足 120s
            withTimeout(120_000) {
                suspendCancellableCoroutine<ExecutionResult> { cont ->
                    val cb: (ExecutionResult) -> Unit = { res ->
                        if (cont.isActive) cont.resume(res)
                    }
                    val accepted = ExecutorManager.execute(cmd, cb)
                    if (!accepted && cont.isActive) {
                        cont.resume(
                            ExecutionResult.fail(
                                cmd.cmdId,
                                ExecutionResult.WEBVIEW_DISCONNECTED,
                                "无可用执行器（需开启无障碍服务并配置 LLM，或打开网页页加载投注站）"
                            )
                        )
                    }
                }
            }
        } catch (_: TimeoutCancellationException) {
            ExecutionResult.timeout(cmd.cmdId, "执行超时(120s)")
        } catch (e: Exception) {
            ExecutionResult.unknown(cmd.cmdId, "异常: ${e.message}")
        }

        repository.complete(cmd.cmdId, result)
        RuntimeLog.info("Scheduler", "执行完成 cmdId=${cmd.cmdId} code=${result.code}")

        // v2.5.3: 确认按钮已点击过的期号，无论结果 FAILED/UNKNOWN/TIMEOUT/COMMITTED_UNKNOWN，
        // 绝不自动重试——网站可能已经实际下单，重试=重复下单。
        if (ExecutionTicketStore.isIssueConfirmed(cmd.lotteryKey, cmd.issue)) {
            RuntimeLog.info(
                "Scheduler",
                "【重试拦截】本期已确认点击，永久锁定不重试 cmdId=${cmd.cmdId} ${cmd.lotteryKey}/${cmd.issue} code=${result.code}"
            )
            // COMMITTED_UNKNOWN 工单转交 ResultQueryScheduler 后续查询
            if (result.code == ExecutionResult.ResultCode.COMMITTED_UNKNOWN) {
                ResultQueryScheduler.enqueue(
                    cmd.lotteryKey, cmd.issue, cmd.cmdId,
                    cmd.amountText ?: "",
                    ExecutionTicketStore.ticket.value.balanceBefore
                )
            }
            return
        }

        // COMMITTED_UNKNOWN 显式不重试（双重保险，即使 isIssueConfirmed 未生效）
        if (result.code == ExecutionResult.ResultCode.COMMITTED_UNKNOWN) {
            RuntimeLog.info(
                "Scheduler",
                "【重试拦截】COMMITTED_UNKNOWN 不重试 cmdId=${cmd.cmdId} ${cmd.lotteryKey}/${cmd.issue}"
            )
            ResultQueryScheduler.enqueue(
                cmd.lotteryKey, cmd.issue, cmd.cmdId,
                cmd.amountText ?: "",
                ExecutionTicketStore.ticket.value.balanceBefore
            )
            return
        }

        // 明确失败可有限重试一次（新 cmdId）——仅在确认按钮尚未点击时允许
        if (result.code == ExecutionResult.ResultCode.FAILED && task.retryCount < 1) {
            // 重试前二次检查 isIssueConfirmed
            if (ExecutionTicketStore.isIssueConfirmed(cmd.lotteryKey, cmd.issue)) {
                RuntimeLog.info(
                    "Scheduler",
                    "【重试拦截】重试前二次检查：本期已确认点击，不重试 cmdId=${cmd.cmdId}"
                )
                return
            }
            val retryCmd = cmd.copy(
                cmdId = BetCommand.generateCmdId(cmd.lotteryKey, cmd.issue),
                expireAt = System.currentTimeMillis() + 60_000L
            )
            val retryTask = repository.create(retryCmd).copy(retryCount = task.retryCount + 1)
            delay(3000)
            dispatch(retryTask)
            RuntimeLog.info("Scheduler", "自动重试 ${cmd.cmdId} -> ${retryCmd.cmdId}")
        }
    }

    fun getQueueSize(lotteryKey: String): Int = synchronized(queueLock) { queues[lotteryKey]?.size ?: 0 }

    fun clearQueue(lotteryKey: String) {
        synchronized(queueLock) { queues[lotteryKey]?.clear() }
        synchronized(activeJobs) { activeJobs[lotteryKey]?.cancel() }
    }
}
