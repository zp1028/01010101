package com.caifenxi.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.caifenxi.app.domain.execution.ClickMatchConfig
import com.caifenxi.app.domain.execution.ExecutorManager
import com.caifenxi.app.ui.ExecutorViewModel
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.theme.CaiTokens

@Composable
fun ExecutorControlScreen(executorViewModel: ExecutorViewModel = viewModel()) {
    val context = LocalContext.current
    val logs by executorViewModel.executorLogs.collectAsState()
    val status by executorViewModel.executorStatus.collectAsState()

    val initial = remember { ClickMatchConfig.load(context) }
    var labelBig by remember { mutableStateOf(initial.labelBig) }
    var labelSmall by remember { mutableStateOf(initial.labelSmall) }
    var labelOdd by remember { mutableStateOf(initial.labelOdd) }
    var labelEven by remember { mutableStateOf(initial.labelEven) }
    var regionEnabled by remember { mutableStateOf(initial.regionEnabled) }
    var regionLeft by remember { mutableStateOf(initial.regionLeft.toString()) }
    var regionTop by remember { mutableStateOf(initial.regionTop.toString()) }
    var regionRight by remember { mutableStateOf(initial.regionRight.toString()) }
    var regionBottom by remember { mutableStateOf(initial.regionBottom.toString()) }
    var saveTip by remember { mutableStateOf("") }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = CaiTokens.ScreenHPadding, vertical = CaiTokens.S16)
    ) {
        Text("执行器控制", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(CaiTokens.S12))

        GlobalCard {
            Text("状态: ${status.name}", fontWeight = FontWeight.Bold)
            Text("模式: ${ExecutorManager.getMode()}")
            Text("可用: ${ExecutorManager.availableExecutorIds().joinToString().ifBlank { "无" }}")
            Spacer(Modifier.height(CaiTokens.S8))
            PrimaryButton(
                text = "测试任务",
                onClick = { executorViewModel.testSelectorsOnly(context) }
            )
            Spacer(Modifier.height(CaiTokens.S8))
            PrimaryButton(
                text = "清空日志",
                onClick = { executorViewModel.clearLogs() }
            )
        }

        Spacer(Modifier.height(CaiTokens.S12))

        GlobalCard {
            Text("文字识别（玩法名）", fontWeight = FontWeight.Bold)
            Text(
                "填写页面上真实按钮文字。例如把「大」映射为「总和大」，之后只会点「总和大」。",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = {
                    labelBig = "总和大"; labelSmall = "总和小"
                    labelOdd = "总和单"; labelEven = "总和双"
                }) { Text("预设:总和", fontSize = 12.sp) }
                TextButton(onClick = {
                    labelBig = "大"; labelSmall = "小"
                    labelOdd = "单"; labelEven = "双"
                }) { Text("预设:单字", fontSize = 12.sp) }
            }
            LabelField("大 → 页面文字", labelBig) { labelBig = it }
            LabelField("小 → 页面文字", labelSmall) { labelSmall = it }
            LabelField("单 → 页面文字", labelOdd) { labelOdd = it }
            LabelField("双 → 页面文字", labelEven) { labelEven = it }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = regionEnabled, onCheckedChange = { regionEnabled = it })
                Text("启用区域限制（只在框内点击）")
            }
            if (regionEnabled) {
                Text(
                    "单位：屏幕百分比 0~100。上/下/左/右 限定点击范围。",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmallField("左%", regionLeft, Modifier.weight(1f)) { regionLeft = it }
                    SmallField("上%", regionTop, Modifier.weight(1f)) { regionTop = it }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmallField("右%", regionRight, Modifier.weight(1f)) { regionRight = it }
                    SmallField("下%", regionBottom, Modifier.weight(1f)) { regionBottom = it }
                }
            }
            Spacer(Modifier.height(8.dp))
            PrimaryButton(
                text = "保存识别设置",
                onClick = {
                    val profile = ClickMatchConfig.Profile(
                        labelBig = labelBig,
                        labelSmall = labelSmall,
                        labelOdd = labelOdd,
                        labelEven = labelEven,
                        regionEnabled = regionEnabled,
                        regionLeft = regionLeft.toIntOrNull() ?: 0,
                        regionTop = regionTop.toIntOrNull() ?: 15,
                        regionRight = regionRight.toIntOrNull() ?: 100,
                        regionBottom = regionBottom.toIntOrNull() ?: 90
                    )
                    ClickMatchConfig.save(context, profile)
                    saveTip = "已保存：大→${profile.labelBig} 小→${profile.labelSmall} 单→${profile.labelOdd} 双→${profile.labelEven}" +
                        if (profile.regionEnabled) " | 区域 ${profile.regionLeft},${profile.regionTop}-${profile.regionRight},${profile.regionBottom}" else ""
                    executorViewModel.clearLogs()
                }
            )
            if (saveTip.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(saveTip, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
            }
        }

        Spacer(Modifier.height(CaiTokens.S12))
        GlobalCard {
            Text("最近日志", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(CaiTokens.S8))
            if (logs.isEmpty()) {
                Text("暂无", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                logs.takeLast(16).forEach {
                    Text(it, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun LabelField(title: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(title) },
        singleLine = true,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    )
}

@Composable
private fun SmallField(title: String, value: String, modifier: Modifier, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(title) },
        singleLine = true,
        modifier = modifier.padding(vertical = 4.dp)
    )
}
