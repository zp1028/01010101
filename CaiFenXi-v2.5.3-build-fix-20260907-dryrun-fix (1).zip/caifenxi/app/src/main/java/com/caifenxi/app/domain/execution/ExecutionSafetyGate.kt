package com.caifenxi.app.domain.execution

/**
 * 真实网页执行的会话级安全总闸。
 * 默认关闭；只有用户在挂机页主动开启当前彩种后，生产工单才允许进入真实执行器。
 */
object ExecutionSafetyGate {
    @Volatile private var hangSessionArmed: Boolean = false
    @Volatile private var activeLotteryKey: String? = null
    @Volatile private var sessionId: Long = 0L

    @Synchronized
    fun arm(lotteryKey: String = "", reason: String = "user_start") {
        hangSessionArmed = true
        activeLotteryKey = lotteryKey.ifBlank { null }
        sessionId = System.currentTimeMillis()
        com.caifenxi.app.util.RuntimeLog.info(
            "SafetyGate",
            "真实执行总闸开启 lottery=${activeLotteryKey ?: "*"} session=$sessionId reason=$reason"
        )
    }

    @Synchronized
    fun disarm(reason: String = "user_stop") {
        hangSessionArmed = false
        activeLotteryKey = null
        sessionId = 0L
        com.caifenxi.app.util.RuntimeLog.info("SafetyGate", "真实执行总闸关闭 reason=$reason")
    }

    fun isArmed(): Boolean = hangSessionArmed

    fun isArmed(lotteryKey: String): Boolean {
        if (!hangSessionArmed) return false
        val active = activeLotteryKey
        return active == null || active == lotteryKey
    }

    fun activeLotteryKey(): String? = activeLotteryKey
    fun currentSessionId(): Long = sessionId
}
