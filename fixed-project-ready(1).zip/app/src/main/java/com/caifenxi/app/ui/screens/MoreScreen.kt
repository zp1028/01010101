package com.caifenxi.app.ui.screens

import android.content.pm.PackageManager
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.SectionTitle
import com.caifenxi.app.ui.theme.CaiTokens

@Composable
fun MoreScreen(vm: MainViewModel, navController: NavHostController) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = CaiTokens.ScreenHPadding, vertical = CaiTokens.S16)
    ) {
        Text("更多", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(CaiTokens.S16))
        SectionTitle("数据与工具")
        GlobalCard {
            listOf(
                "stats" to "历史战绩",
                "lab" to "实验室",
                "accessibility" to "无障碍跟投",
                "web_executor" to "内置网页执行",
                "executor_control" to "执行器控制",
                "executor_logs" to "执行日志",
                "settings" to "设置 / 悬浮窗"
            ).forEach { (route, title) ->
                TextButton(
                    onClick = { navController.navigate(route) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(title) }
            }
        }
        Spacer(Modifier.height(CaiTokens.S12))
        GlobalCard {
            // 从 PackageManager 读取真实版本号，避免与 build.gradle 硬编码版本脱节
            val ctx = LocalContext.current
            val version = remember {
                try {
                    val pm = ctx.packageManager
                    val info = pm.getPackageInfo(ctx.packageName, 0)
                    val vName = info.versionName ?: ""
                    val vCode = if (android.os.Build.VERSION.SDK_INT >= 28)
                        info.longVersionCode else info.versionCode.toLong()
                    "v$vName ($vCode)"
                } catch (_: PackageManager.NameNotFoundException) {
                    ""
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("彩析", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                CaptionMuted(version)
            }
            Spacer(Modifier.height(CaiTokens.S8))
            Text(
                "走势统计、计划回测、预测共识与跟投记录工具。仅供开奖数据统计与研究，非中奖保证，请理性对待。",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}
