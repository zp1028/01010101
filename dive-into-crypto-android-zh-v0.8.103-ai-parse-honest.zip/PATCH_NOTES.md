Fix AI JSON extract first-{ + honest fusion success/fallback counts
