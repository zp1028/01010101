package com.caifenxi.app.ui

import android.app.Application
import android.content.Intent
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.caifenxi.app.BtcQuantApplication
import com.caifenxi.app.domain.btc.BinanceDerivativesRepository
import com.caifenxi.app.domain.btc.BinanceMarketRepository
import com.caifenxi.app.domain.btc.BtcDashboardState
import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.BtcPlanEngine
import com.caifenxi.app.domain.btc.BtcSignalFactory
import com.caifenxi.app.domain.btc.DerivativesFeatureEngine
import com.caifenxi.app.domain.btc.TradingSignal
import com.caifenxi.app.domain.btc.ai.AiBrain
import com.caifenxi.app.domain.btc.ai.AiPolicy
import com.caifenxi.app.domain.btc.ai.AiPolicyConfig
import com.caifenxi.app.domain.btc.backtest.BacktestConfig
import com.caifenxi.app.domain.btc.backtest.BacktestResult
import com.caifenxi.app.domain.btc.backtest.BtcBacktestEngine
import com.caifenxi.app.domain.btc.broker.BinanceFuturesBroker
import com.caifenxi.app.domain.btc.broker.BrokerCredentialStore
import com.caifenxi.app.domain.btc.broker.BrokerCredentials
import com.caifenxi.app.domain.btc.broker.BrokerFactory
import com.caifenxi.app.domain.btc.broker.PerpBroker
import com.caifenxi.app.domain.btc.broker.PerpBroker
import com.caifenxi.app.domain.btc.futures.FuturesDailyStats
import com.caifenxi.app.domain.btc.futures.FuturesLogEntry
import com.caifenxi.app.domain.btc.futures.FuturesPosition
import com.caifenxi.app.domain.btc.futures.FuturesQuantConfig
import com.caifenxi.app.domain.btc.futures.FuturesQuantEngine
import com.caifenxi.app.domain.btc.futures.FuturesSignal
import com.caifenxi.app.domain.btc.futures.LogLevel
import com.caifenxi.app.domain.btc.futures.MarginMode
import com.caifenxi.app.domain.btc.futures.PositionManager
import com.caifenxi.app.domain.btc.futures.PositionSide
import com.caifenxi.app.domain.btc.futures.ClosePositionRequest
import com.caifenxi.app.domain.btc.futures.FuturesOrderType
import com.caifenxi.app.domain.btc.news.CryptoNewsRepository
import com.caifenxi.app.domain.btc.paper.BinaryOptionAccount
import com.caifenxi.app.domain.btc.paper.BinaryOptionConfig
import com.caifenxi.app.domain.btc.paper.BinaryOptionEngine
import com.caifenxi.app.domain.btc.paper.BinaryOptionStats
import com.caifenxi.app.domain.btc.paper.BetDirection
import com.caifenxi.app.domain.btc.paper.BetRequest
import com.caifenxi.app.domain.btc.paper.BetResult
import com.caifenxi.app.domain.btc.paper.BetSource
import com.caifenxi.app.domain.btc.paper.BinanceOrderRequest
import com.caifenxi.app.domain.btc.paper.BinanceOrderResult
import com.caifenxi.app.domain.btc.paper.DailyControlConfig
import com.caifenxi.app.domain.btc.paper.DailyStats
import com.caifenxi.app.domain.btc.paper.EdgeAssessment
import com.caifenxi.app.domain.btc.paper.EdgeAssessmentEngine
import com.caifenxi.app.domain.btc.paper.MarketOdds
import com.caifenxi.app.domain.btc.paper.PolymarketOrderRequest
import com.caifenxi.app.domain.btc.paper.PolymarketOrderResult
import com.caifenxi.app.domain.btc.paper.PredictionMarketConnector
import com.caifenxi.app.domain.btc.paper.PredictionRound
import com.caifenxi.app.domain.btc.paper.SettledBet
import com.caifenxi.app.domain.btc.paper.StakeSizingEngine
import com.caifenxi.app.domain.btc.portfolio.MultiEngineOrchestrator
import com.caifenxi.app.domain.btc.runtime.BtcRunMode
import com.caifenxi.app.domain.btc.runtime.BtcRuntimeConfig
import com.caifenxi.app.domain.btc.runtime.BtcRuntimeState
import com.caifenxi.app.domain.btc.runtime.BtcRuntimeStatus
import com.caifenxi.app.domain.btc.runtime.BtcRuntimeStore
import com.caifenxi.app.service.btc.BtcQuantRuntimeService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * BTC 量化交易 ViewModel — 不再接受 Context 参数，通过 AndroidViewModel 获取 Application。
 */
class BtcQuantViewModel(application: Application) : AndroidViewModel(application) {

    private val app = getApplication<BtcQuantApplication>()

    private val runtimeStore: BtcRuntimeStore = BtcRuntimeStore(app)
    private val credentialStore = BrokerCredentialStore(app)

    private val repo = BinanceMarketRepository()
    private val derivRepo = BinanceDerivativesRepository()
    private val newsRepo = CryptoNewsRepository()
    private val aiBrain = AiBrain()
    private val aiPolicy = AiPolicyConfig(allowLiveAiOrders = false)
    private val orchestrator = MultiEngineOrchestrator()
    private val engine = BtcPlanEngine()
    private val signalFactory = BtcSignalFactory()
    private val backtestEngine = BtcBacktestEngine()
    private val binaryOptionEngine = BinaryOptionEngine()
    private val predictionMarketConnector = PredictionMarketConnector()
    private val stakeSizingEngine = StakeSizingEngine()
    private val edgeAssessmentEngine = EdgeAssessmentEngine()

    // === 合约量化引擎 ===
    private val futuresEngine = FuturesQuantEngine()
    private var positionManager = PositionManager(FuturesQuantConfig())
    private var perpBroker: PerpBroker = BrokerFactory.perp(credentialStore.load(), forcePaper = true)
    private var lastFuturesAutoTickTime = 0L

    private val _state = MutableStateFlow(BtcDashboardState())
    val state: StateFlow<BtcDashboardState> = _state.asStateFlow()

    private val _orch = MutableStateFlow<String?>(null)
    val orchestratorNote: StateFlow<String?> = _orch.asStateFlow()

    private val _runtimeState = MutableStateFlow(runtimeStore.state())
    val runtimeState: StateFlow<BtcRuntimeState> = _runtimeState.asStateFlow()

    private val _runtimeConfig = MutableStateFlow(runtimeStore.config())
    val runtimeConfig: StateFlow<BtcRuntimeConfig> = _runtimeConfig.asStateFlow()

    private val _creds = MutableStateFlow(credentialStore.load())
    val credentials: StateFlow<BrokerCredentials> = _creds.asStateFlow()

    // === 策略池管理 ===
    data class PlanPoolConfig(
        val enabledPlans: Set<String> = setOf(
            "BTC-TREND", "BTC-MOMENTUM", "BTC-STRUCTURE",
            "BTC-VOLUME", "BTC-VOLATILITY", "BTC-FUNDING-FADE"
        ),
        val weightOverrides: Map<String, Double> = emptyMap()
    )

    private val _planPoolConfig = MutableStateFlow(PlanPoolConfig())
    val planPoolConfig: StateFlow<PlanPoolConfig> = _planPoolConfig.asStateFlow()

    fun togglePlan(planId: String, enabled: Boolean) {
        val current = _planPoolConfig.value.enabledPlans.toMutableSet()
        if (enabled) current.add(planId) else current.remove(planId)
        _planPoolConfig.value = _planPoolConfig.value.copy(enabledPlans = current)
    }

    fun updatePlanWeight(planId: String, weight: Double) {
        _planPoolConfig.value = _planPoolConfig.value.copy(
            weightOverrides = _planPoolConfig.value.weightOverrides + (planId to weight)
        )
    }

    fun resetPlanPool() {
        _planPoolConfig.value = PlanPoolConfig()
    }

    // === 回测 ===
    data class BacktestUiState(
        val planId: String = "BTC-TREND",
        val config: BacktestConfig = BacktestConfig(),
        val result: BacktestResult? = null,
        val loading: Boolean = false,
        val error: String? = null
    )

    private val _backtestState = MutableStateFlow(BacktestUiState())
    val backtestState: StateFlow<BacktestUiState> = _backtestState.asStateFlow()

    val availablePlans = listOf(
        "BTC-TREND" to "趋势结构",
        "BTC-MOMENTUM" to "动量共振",
        "BTC-STRUCTURE" to "K线结构",
        "BTC-VOLUME" to "量价确认",
        "BTC-VOLATILITY" to "波动状态",
        "BTC-FUNDING-FADE" to "资金费率消退"
    )

    fun selectBacktestPlan(planId: String) {
        _backtestState.value = _backtestState.value.copy(planId = planId)
    }

    fun updateBacktestConfig(config: BacktestConfig) {
        _backtestState.value = _backtestState.value.copy(config = config)
    }

    fun runBacktest() {
        val candles = _state.value.candles
        if (candles.size < 80) {
            _backtestState.value = _backtestState.value.copy(
                error = "K 线数据不足（需 >= 80 根，当前 ${candles.size} 根）"
            )
            return
        }
        _backtestState.value = _backtestState.value.copy(loading = true, error = null)
        viewModelScope.launch(Dispatchers.Default) {
            runCatching {
                val bt = _backtestState.value
                val result = backtestEngine.run(bt.planId, candles, bt.config)
                _backtestState.value = bt.copy(result = result, loading = false)
            }.onFailure { e ->
                _backtestState.value = _backtestState.value.copy(
                    loading = false,
                    error = e.message ?: "回测执行失败"
                )
            }
        }
    }

    fun buildPerpSignalPreview(positionSize: Double = 0.001): TradingSignal.ContractSignal? {
        val s = _state.value
        val c = s.consensus ?: return null
        return signalFactory.buildPerpSignal(s.symbol, s.candles, s.plans, c, positionSize)
    }

    // === 二元期权自动下注日志 ===
    data class AutoTradeLogEntry(
        val timestamp: Long,
        val direction: String,         // YES / NO
        val betAmount: Double,         // 下注金额 USDT
        val odds: Double,              // 赔率
        val roundId: Long,             // 周期 ID
        val openPrice: Double,         // 开窗价格
        val mode: String,              // PAPER / POLYMARKET / BINANCE
        val result: String
    )

    private val _autoTradeLog = MutableStateFlow<List<AutoTradeLogEntry>>(emptyList())
    val autoTradeLog: StateFlow<List<AutoTradeLogEntry>> = _autoTradeLog.asStateFlow()

    fun addAutoTradeLog(entry: AutoTradeLogEntry) {
        _autoTradeLog.value = (listOf(entry) + _autoTradeLog.value).take(100)
    }

    fun clearAutoTradeLog() {
        _autoTradeLog.value = emptyList()
    }

    /** 更新运行时配置（自动下注参数） */
    fun updateRuntimeConfig(
        symbol: String? = null,
        timeframe: String? = null,
        runMode: BtcRunMode? = null,
        maxPositionQty: Double? = null,
        pollSeconds: Long? = null
    ) {
        val current = runtimeStore.config()
        val updated = current.copy(
            symbol = symbol ?: current.symbol,
            timeframe = timeframe ?: current.timeframe,
            runMode = runMode ?: current.runMode,
            maxPositionQty = maxPositionQty ?: current.maxPositionQty,
            pollSeconds = pollSeconds ?: current.pollSeconds
        )
        runtimeStore.saveConfig(updated)
        _runtimeConfig.value = runtimeStore.config()
    }

    /**
     * 执行一次二元期权自动下注。
     * 变动赔率链路：EdgeAssessment(模型概率 vs 市场定价) -> 锁定方向 -> 固定1U + 变动赔率 -> 平台下单
     * 日级控制：日亏损达阈值或日止盈达目标时自动停机。
     */
    fun executeAutoTradeTick() {
        val s = _state.value
        val cfg = _runtimeConfig.value
        val now = System.currentTimeMillis()
        val currentPrice = s.candles.lastOrNull()?.close ?: s.markPrice ?: 0.0

        if (currentPrice <= 0) {
            addAutoTradeLog(AutoTradeLogEntry(
                now, "FLAT", 0.0, 0.0, 0L, 0.0,
                cfg.runMode.name, "无可用价格，跳过"
            ))
            return
        }

        // === 日级止盈止损检查 ===
        if (binaryOptionEngine.shouldStopAutoTrading()) {
            val reason = binaryOptionEngine.dailyStopReason() ?: "日级控制停机"
            addAutoTradeLog(AutoTradeLogEntry(
                now, "FLAT", 0.0, 0.0, 0L, 0.0,
                cfg.runMode.name, "日级停机: $reason"
            ))
            refreshBinaryOptionState()
            return
        }

        // 确保周期存在（方向已在 tickBinaryRound 中通过 edge 评估锁定）
        val round = binaryOptionEngine.ensureRound(now, currentPrice)

        val direction = round.lockedDirection

        if (direction == null) {
            val assessment = _edgeAssessment.value
            addAutoTradeLog(AutoTradeLogEntry(
                now, "FLAT", 0.0, assessment?.chosenOdds ?: 0.0,
                round.roundId, round.openPrice,
                cfg.runMode.name,
                if (assessment != null) "Edge 不足，跳过: ${assessment.reason}" else "本周期未锁定方向"
            ))
            return
        }

        // === 防止同周期重复下注 ===
        if (binaryOptionEngine.account().hasBetForRound(round.roundId)) {
            addAutoTradeLog(AutoTradeLogEntry(
                now, direction.name, 0.0,
                _edgeAssessment.value?.chosenOdds ?: 0.0,
                round.roundId, round.openPrice,
                cfg.runMode.name, "本周期已下注，等待结算"
            ))
            return
        }

        // === 变动赔率 + 固定 1U 下注 ===
        val assessment = _edgeAssessment.value
        val odds = assessment?.chosenOdds ?: 1.9  // 回退到默认赔率（无市场数据时）
        val betAmount = 1.0  // 固定 1 USDT/注

        // 余额检查
        val balance = _binaryAccount.value.balance
        if (balance < betAmount) {
            addAutoTradeLog(AutoTradeLogEntry(
                now, direction.name, 0.0, odds, round.roundId, round.openPrice,
                cfg.runMode.name, "余额不足: 需 %.0f, 可用 %.2f".format(betAmount, balance)
            ))
            return
        }

        // 更新 stake preview（供 UI 展示）
        val suggestion = stakeSizingEngine.calculate(
            balance = balance,
            odds = odds,
            consensusProbability = assessment?.chosenModelProb ?: 0.5,
            consensusStrength = s.consensus?.consensusStrength ?: 0.5
        )
        _stakePreview.value = suggestion

        val betSource = when (cfg.runMode) {
            BtcRunMode.PAPER -> BetSource.PAPER
            BtcRunMode.TESTNET -> BetSource.POLYMARKET
            BtcRunMode.LIVE -> BetSource.BINANCE
        }

        when (betSource) {
            BetSource.PAPER -> executePaperBet(direction, betAmount, odds, round, now, cfg.runMode.name, suggestion)
            BetSource.POLYMARKET -> executePolymarketBet(direction, betAmount, odds, round, now, suggestion)
            BetSource.BINANCE -> executeBinanceBet(direction, betAmount, odds, round, now, suggestion)
        }
    }

    /** Paper 模式：本地模拟下注 */
    private fun executePaperBet(
        direction: BetDirection,
        amount: Double,
        odds: Double,
        round: PredictionRound,
        now: Long,
        modeName: String,
        suggestion: StakeSizingEngine.StakeSuggestion
    ) {
        val req = BetRequest(
            direction = direction,
            amount = amount,
            odds = odds,
            source = BetSource.PAPER,
            timestamp = now
        )
        when (val result = binaryOptionEngine.placeBet(req, now)) {
            is BetResult.Accepted -> {
                val msg = "PAPER -> ${direction.label} · %.0f USDT @ %.2fx · EV=%+.3f".format(
                    amount, odds, suggestion.expectedValue
                )
                addAutoTradeLog(AutoTradeLogEntry(
                    now, direction.name, amount, odds, round.roundId, round.openPrice, modeName, msg
                ))
                _lastExecution.value = ExecutionResult(
                    now, direction, amount, odds, round.roundId, round.openPrice,
                    modeName, true, result.bet.betId, msg
                )
                refreshBinaryOptionState()
            }
            is BetResult.Rejected -> {
                val msg = "REJECTED: ${result.reason}"
                addAutoTradeLog(AutoTradeLogEntry(
                    now, direction.name, amount, odds, round.roundId, round.openPrice, modeName, msg
                ))
                _lastExecution.value = ExecutionResult(
                    now, direction, amount, odds, round.roundId, round.openPrice,
                    modeName, false, null, msg
                )
            }
        }
    }

    /** Polymarket 模式：真实下单到 Polymarket CLOB */
    private fun executePolymarketBet(
        direction: BetDirection,
        amount: Double,
        odds: Double,
        round: PredictionRound,
        now: Long,
        suggestion: StakeSizingEngine.StakeSuggestion
    ) {
        val creds = credentialStore.load()
        val polyMarket = _marketOddsList.value.firstOrNull { it.platform == "POLYMARKET" && !it.resolved }

        // 查找匹配的 Polymarket 市场 tokenId
        val tokenId = polyMarket?.marketId ?: ""
        val price = if (direction == BetDirection.YES) {
            polyMarket?.yesPrice ?: MarketOdds.oddsToPrice(odds)
        } else {
            polyMarket?.noPrice ?: MarketOdds.oddsToPrice(odds)
        }
        val size = if (price > 0) amount / price else amount / odds

        val orderReq = PolymarketOrderRequest(
            tokenId = tokenId,
            side = "BUY",
            price = price,
            size = size,
            feeRateBps = 0
        )

        viewModelScope.launch {
            val result = predictionMarketConnector.placePolymarketOrder(
                request = orderReq,
                apiKey = creds.polymarketApiKey,
                apiSecret = creds.polymarketApiSecret,
                passphrase = creds.polymarketPassphrase,
                dryRun = creds.polymarketDryRun || creds.polymarketApiKey.isBlank()
            )

            val modeName = if (creds.polymarketDryRun || creds.polymarketApiKey.isBlank()) "POLYMARKET-DRY" else "POLYMARKET"

            if (result.success) {
                // 同时在本地引擎记录 Paper 账本（用于跟踪统计）
                val localReq = BetRequest(
                    direction = direction,
                    amount = amount,
                    odds = odds,
                    source = BetSource.POLYMARKET,
                    platformMarketId = tokenId,
                    timestamp = now
                )
                binaryOptionEngine.placeBet(localReq, now)
                refreshBinaryOptionState()

                val msg = "$modeName -> ${direction.label} · %.0f USDT @ %.1fx · orderId=%s".format(
                    amount, odds, result.orderId ?: "?"
                )
                addAutoTradeLog(AutoTradeLogEntry(
                    now, direction.name, amount, odds, round.roundId, round.openPrice, modeName, msg
                ))
                _lastExecution.value = ExecutionResult(
                    now, direction, amount, odds, round.roundId, round.openPrice,
                    modeName, true, result.orderId, msg
                )
            } else {
                val msg = "POLYMARKET FAIL: ${result.error ?: result.status}"
                addAutoTradeLog(AutoTradeLogEntry(
                    now, direction.name, amount, odds, round.roundId, round.openPrice, modeName, msg
                ))
                _lastExecution.value = ExecutionResult(
                    now, direction, amount, odds, round.roundId, round.openPrice,
                    modeName, false, null, msg
                )
            }
        }
    }

    /** Binance 模式：真实现货下单作为方向代理 */
    private fun executeBinanceBet(
        direction: BetDirection,
        amount: Double,
        odds: Double,
        round: PredictionRound,
        now: Long,
        suggestion: StakeSizingEngine.StakeSuggestion
    ) {
        val creds = credentialStore.load()
        if (creds.binanceApiKey.isBlank()) {
            val msg = "BINANCE: API Key 未配置，降级为 Paper"
            addAutoTradeLog(AutoTradeLogEntry(
                now, direction.name, amount, odds, round.roundId, round.openPrice, "BINANCE-NOKEY", msg
            ))
            executePaperBet(direction, amount, odds, round, now, "BINANCE-NOKEY", suggestion)
            return
        }

        // 方向 -> Binance 交易方向：YES(涨)=BUY，NO(跌)=SELL（先卖出再买回）
        // 但现货不能做空，所以 NO 方向时买入 BTC 后在结算时卖出
        // 简化处理：YES=BUY BTC（赌涨），NO 不下单仅本地记录（真实做空需要合约，违反无杠杆约束）
        val binanceSide = if (direction == BetDirection.YES) "BUY" else "SELL"

        // 计算购买 BTC 数量
        val btcPrice = round.openPrice
        val quantity = if (btcPrice > 0) amount / btcPrice * 0.99 else 0.0  // 0.99 留手续费

        if (quantity <= 0) {
            addAutoTradeLog(AutoTradeLogEntry(
                now, direction.name, amount, odds, round.roundId, round.openPrice,
                "BINANCE", "数量计算失败: price=$btcPrice"
            ))
            return
        }

        val orderReq = BinanceOrderRequest(
            symbol = _state.value.symbol,
            side = binanceSide,
            quantity = quantity,
            orderType = "MARKET"
        )

        val testnet = creds.binanceEndpoint.name != "MAINNET"

        viewModelScope.launch {
            val result = predictionMarketConnector.placeBinanceOrder(
                request = orderReq,
                apiKey = creds.binanceApiKey,
                apiSecret = creds.binanceSecret,
                testnet = testnet
            )

            val modeName = if (testnet) "BINANCE-TESTNET" else "BINANCE-LIVE"

            if (result.success) {
                // 同时在本地引擎记录
                val localReq = BetRequest(
                    direction = direction,
                    amount = amount,
                    odds = odds,
                    source = BetSource.BINANCE,
                    platformMarketId = result.orderId?.toString(),
                    timestamp = now
                )
                binaryOptionEngine.placeBet(localReq, now)
                refreshBinaryOptionState()

                val msg = "$modeName -> ${direction.label} · %.0f USDT · qty=%.6f BTC · orderId=%d · status=%s".format(
                    amount, quantity, result.orderId ?: 0L, result.status
                )
                addAutoTradeLog(AutoTradeLogEntry(
                    now, direction.name, amount, odds, round.roundId, round.openPrice, modeName, msg
                ))
                _lastExecution.value = ExecutionResult(
                    now, direction, amount, odds, round.roundId, round.openPrice,
                    modeName, true, result.orderId?.toString(), msg
                )
            } else {
                val msg = "BINANCE FAIL: ${result.error ?: result.status}"
                addAutoTradeLog(AutoTradeLogEntry(
                    now, direction.name, amount, odds, round.roundId, round.openPrice, modeName, msg
                ))
                _lastExecution.value = ExecutionResult(
                    now, direction, amount, odds, round.roundId, round.openPrice,
                    modeName, false, null, msg
                )
            }
        }
    }

    /** 预览当前 edge 评估结果（供执行台面板展示，不下单） */
    fun previewStakeSizing(): StakeSizingEngine.StakeSuggestion {
        val s = _state.value
        val balance = _binaryAccount.value.balance
        val marketOdds = _marketOddsList.value.firstOrNull { !it.resolved }
            ?: _marketOddsList.value.firstOrNull()

        val assessment = edgeAssessmentEngine.assess(s.consensus, marketOdds)
        _edgeAssessment.value = assessment

        val odds = assessment.chosenOdds
        val suggestion = stakeSizingEngine.calculate(
            balance = balance,
            odds = odds,
            consensusProbability = assessment.chosenModelProb,
            consensusStrength = s.consensus?.consensusStrength ?: 0.5
        )
        _stakePreview.value = suggestion
        return suggestion
    }

    /** 检查平台连接状态和余额 */
    fun checkPlatformConnectivity() {
        val creds = credentialStore.load()
        viewModelScope.launch {
            val polyBalance = 0.0  // Polymarket 余额需通过 API 查询，此处简化
            val binanceBalance = if (creds.binanceApiKey.isNotBlank()) {
                predictionMarketConnector.fetchBinanceAccountBalance(
                    creds.binanceApiKey,
                    creds.binanceSecret,
                    testnet = creds.binanceEndpoint.name != "MAINNET"
                )
            } else 0.0

            _platformStatus.value = PlatformStatus(
                polymarketConnected = creds.polymarketApiKey.isNotBlank(),
                binanceConnected = creds.binanceApiKey.isNotBlank() && binanceBalance > 0,
                polymarketBalance = polyBalance,
                binanceBalance = binanceBalance,
                lastCheck = System.currentTimeMillis()
            )
            addBetLog("平台检查: Polymarket=%s Binance=%s(%.2f USDT)".format(
                if (creds.polymarketApiKey.isNotBlank()) "OK" else "NO_KEY",
                if (creds.binanceApiKey.isNotBlank()) "OK" else "NO_KEY",
                binanceBalance
            ))
        }
    }

    /** 刷新运行时状态（供 UI 轮询） */
    fun refreshRuntimeState() {
        _runtimeState.value = runtimeStore.state()
        _runtimeConfig.value = runtimeStore.config()
    }

    fun setRuntimeEnabled(enabled: Boolean, mode: BtcRunMode = BtcRunMode.PAPER) {
        runtimeStore.saveConfig(runtimeStore.config().copy(enabled = enabled, runMode = mode))
        _runtimeConfig.value = runtimeStore.config()
        val intent = Intent(app, BtcQuantRuntimeService::class.java)
        if (enabled) {
            ContextCompat.startForegroundService(app, intent)
        } else {
            intent.action = BtcQuantRuntimeService.ACTION_STOP
            app.startService(intent)
        }
        refreshRuntimeState()
    }

    fun killRuntime() {
        runtimeStore.setKillSwitch(true)
        app.startService(
            Intent(app, BtcQuantRuntimeService::class.java)
                .setAction(BtcQuantRuntimeService.ACTION_KILL)
        )
        refreshRuntimeState()
    }

    fun resumeRuntime() {
        runtimeStore.setKillSwitch(false)
        runtimeStore.saveConfig(runtimeStore.config().copy(enabled = true))
        _runtimeConfig.value = runtimeStore.config()
        ContextCompat.startForegroundService(
            app,
            Intent(app, BtcQuantRuntimeService::class.java)
                .setAction(BtcQuantRuntimeService.ACTION_RESUME)
        )
        refreshRuntimeState()
    }

    // === 二元期权预测下注 ===
    private val _binaryAccount = MutableStateFlow(binaryOptionEngine.account())
    val binaryAccount: StateFlow<BinaryOptionAccount> = _binaryAccount.asStateFlow()

    private val _binaryStats = MutableStateFlow(binaryOptionEngine.statsSummary())
    val binaryStats: StateFlow<BinaryOptionStats> = _binaryStats.asStateFlow()

    private val _currentRound = MutableStateFlow<PredictionRound?>(null)
    val currentRound: StateFlow<PredictionRound?> = _currentRound.asStateFlow()

    private val _betLog = MutableStateFlow<List<String>>(emptyList())
    val betLog: StateFlow<List<String>> = _betLog.asStateFlow()

    private val _marketOddsList = MutableStateFlow<List<MarketOdds>>(emptyList())
    val marketOddsList: StateFlow<List<MarketOdds>> = _marketOddsList.asStateFlow()

    // === 动态份额预览（供执行台面板展示） ===
    private val _stakePreview = MutableStateFlow<StakeSizingEngine.StakeSuggestion?>(null)
    val stakePreview: StateFlow<StakeSizingEngine.StakeSuggestion?> = _stakePreview.asStateFlow()

    // === Edge 评估结果（变动赔率核心） ===
    private val _edgeAssessment = MutableStateFlow<EdgeAssessment?>(null)
    val edgeAssessment: StateFlow<EdgeAssessment?> = _edgeAssessment.asStateFlow()

    // === 平台连接状态 ===
    data class PlatformStatus(
        val polymarketConnected: Boolean = false,
        val binanceConnected: Boolean = false,
        val polymarketBalance: Double = 0.0,
        val binanceBalance: Double = 0.0,
        val lastCheck: Long = 0L
    )
    private val _platformStatus = MutableStateFlow(PlatformStatus())
    val platformStatus: StateFlow<PlatformStatus> = _platformStatus.asStateFlow()

    // === 自动下注执行结果（最新一笔） ===
    data class ExecutionResult(
        val timestamp: Long,
        val direction: BetDirection,
        val amount: Double,
        val odds: Double,
        val roundId: Long,
        val openPrice: Double,
        val mode: String,
        val success: Boolean,
        val orderId: String?,
        val message: String
    )
    private val _lastExecution = MutableStateFlow<ExecutionResult?>(null)
    val lastExecution: StateFlow<ExecutionResult?> = _lastExecution.asStateFlow()

    // === 日级盈亏统计 ===
    private val _dailyStats = MutableStateFlow<DailyStats>(DailyStats(
        date = "",
        startBalance = 10_000.0,
        currentBalance = 10_000.0,
        peakBalance = 10_000.0
    ))
    val dailyStats: StateFlow<DailyStats> = _dailyStats.asStateFlow()

    // === 日级控制配置 ===
    private val _dailyControlConfig = MutableStateFlow(DailyControlConfig())
    val dailyControlConfig: StateFlow<DailyControlConfig> = _dailyControlConfig.asStateFlow()

    private fun addBetLog(msg: String) {
        _betLog.value = (listOf("[${System.currentTimeMillis()}] $msg") + _betLog.value).take(50)
    }

    /**
     * 确保 5 分钟周期存在并更新倒计时。
     * 新周期开始时通过 EdgeAssessmentEngine 计算一次方向并锁定，周期内不再改变。
     *
     * 变动赔率核心：不是简单映射 consensus→YES/NO，
     * 而是比较模型概率与市场定价，选 edge 为正的方向。
     */
    fun tickBinaryRound() {
        val s = _state.value
        val now = System.currentTimeMillis()
        val price = s.candles.lastOrNull()?.close ?: s.markPrice ?: 0.0
        if (price <= 0) return

        val current = binaryOptionEngine.currentRound()
        val needsNewRound = current == null || now >= current.endTime

        // 新周期开始时，通过 edge 评估决定方向
        val lockedDir: BetDirection? = if (needsNewRound) {
            // 获取市场赔率（Polymarket 优先，否则用 Binance 本地市场）
            val marketOdds = _marketOddsList.value.firstOrNull { !it.resolved }
                ?: _marketOddsList.value.firstOrNull()

            // Edge 评估：比较模型概率与市场定价
            val assessment = edgeAssessmentEngine.assess(s.consensus, marketOdds)
            _edgeAssessment.value = assessment

            if (assessment.shouldBet) assessment.chosenDirection else null
        } else {
            current!!.lockedDirection
        }

        val round = binaryOptionEngine.ensureRound(now, price, lockedDir)
        _currentRound.value = round
        refreshBinaryOptionState()
    }

    /** 手动下注：在当前周期内下 Yes 或 No */
    fun placeBinaryBet(direction: BetDirection, amount: Double, odds: Double = 1.9) {  // odds 默认仅作回退，实际由 EdgeAssessment 提供
        val now = System.currentTimeMillis()
        val s = _state.value
        val price = s.candles.lastOrNull()?.close ?: s.markPrice ?: 0.0
        if (price <= 0) {
            addBetLog("下注失败: 无可用价格")
            return
        }
        // 确保周期存在（传入共识方向作为锁定方向）
        val lockedDir = s.consensus?.direction?.let {
            when (it) {
                BtcDirection.UP -> BetDirection.YES
                BtcDirection.DOWN -> BetDirection.NO
                else -> null
            }
        }
        val round = binaryOptionEngine.ensureRound(now, price, lockedDir)
        _currentRound.value = round

        val req = BetRequest(
            direction = direction,  // 用户手动选择的方向（覆盖锁定方向）
            amount = amount,
            odds = odds,
            source = BetSource.PAPER,
            timestamp = now
        )
        when (val result = binaryOptionEngine.placeBet(req, now)) {
            is BetResult.Accepted -> {
                addBetLog("BET ${direction.label} \u00b7 %.0f USDT @ %.1fx \u00b7 Round #%d \u00b7 Open=%.2f".format(
                    amount, odds, round.roundId / 300_000, round.openPrice))
                refreshBinaryOptionState()
            }
            is BetResult.Rejected -> addBetLog("REJECTED: ${result.reason}")
        }
    }

    /** 自动信号下注：通过 EdgeAssessment 决定方向 + 变动赔率 + 固定 1U */
    fun executeBinaryAutoBet() {
        val s = _state.value
        val consensus = s.consensus ?: run {
            addBetLog("无共识方向，跳过")
            return
        }

        // 获取市场赔率
        val marketOdds = _marketOddsList.value.firstOrNull { !it.resolved }
            ?: _marketOddsList.value.firstOrNull()

        // Edge 评估
        val assessment = edgeAssessmentEngine.assess(consensus, marketOdds)
        _edgeAssessment.value = assessment

        if (!assessment.shouldBet || assessment.chosenDirection == null) {
            addBetLog("Edge 不足，跳过: ${assessment.reason}")
            return
        }

        val direction = assessment.chosenDirection!!
        val odds = assessment.chosenOdds
        val betAmount = 1.0  // 固定 1 USDT

        addBetLog("EDGE -> ${direction.label} · 1 USDT @ %.2fx · edge=+%.1f%% · EV=+%.3f".format(
            odds, assessment.chosenEdge * 100, assessment.evPerBet
        ))
        placeBinaryBet(direction, betAmount, odds)
    }

    /** 强制结算当前周期（手动测试用） */
    fun forceSettleCurrentRound() {
        val s = _state.value
        val price = s.candles.lastOrNull()?.close ?: s.markPrice ?: 0.0
        if (price <= 0) return
        val now = System.currentTimeMillis()
        binaryOptionEngine.forceSettle(now, price)
        addBetLog("手动结算: close=%.2f".format(price))
        // 立即开启新周期
        tickBinaryRound()
    }

    /** 重置二元期权账户 */
    fun resetBinaryAccount() {
        binaryOptionEngine.reset()
        _currentRound.value = null
        refreshBinaryOptionState()
        addBetLog("账户已重置: 初始资金 %.0f USDT".format(binaryOptionEngine.account().initialBalance))
    }

    /** 获取当前周期倒计时（秒） */
    fun binaryRemainingSec(): Long {
        val now = System.currentTimeMillis()
        return binaryOptionEngine.remainingSeconds(now)
    }

    /** 获取当前价格相对开窗的涨跌幅 */
    fun binaryCurrentMovePct(): Double {
        val s = _state.value
        val price = s.candles.lastOrNull()?.close ?: s.markPrice ?: 0.0
        return binaryOptionEngine.currentMovePct(price)
    }

    /** 获取当前实时方向（未结算） */
    fun binaryLiveDirection(): BetDirection {
        val s = _state.value
        val price = s.candles.lastOrNull()?.close ?: s.markPrice ?: 0.0
        return binaryOptionEngine.currentLiveDirection(price)
    }

    /** 获取历史周期列表 */
    fun binaryRoundHistory(): List<PredictionRound> = binaryOptionEngine.roundHistory()

    /** 获取已结算下注列表 */
    fun binarySettledBets(): List<SettledBet> = binaryOptionEngine.account().settledBets

    /** 刷新 Polymarket + Binance 市场赔率 */
    fun refreshMarketOdds() {
        viewModelScope.launch {
            runCatching {
                val roundEnd = _currentRound.value?.endTime ?: 0L
                val result = predictionMarketConnector.fetchAllMarkets(
                    _state.value.symbol, roundEnd
                )
                _marketOddsList.value = result.allMarkets
                addBetLog("市场刷新: ${result.polymarketMarkets.size} Polymarket + 1 Binance \u00b7 price=%.2f".format(
                    result.binancePrice))
            }.onFailure { e ->
                addBetLog("市场刷新失败: ${e.message}")
            }
        }
    }

    private fun refreshBinaryOptionState() {
        _binaryAccount.value = binaryOptionEngine.account()
        _binaryStats.value = binaryOptionEngine.statsSummary()
        _dailyStats.value = binaryOptionEngine.dailyStats()
    }

    /** 更新日级控制配置（止损/止盈百分比） */
    fun updateDailyControlConfig(
        stopLossPct: Double? = null,
        takeProfitPct: Double? = null,
        maxDailyBets: Int? = null,
        enabled: Boolean? = null
    ) {
        val current = _dailyControlConfig.value
        _dailyControlConfig.value = current.copy(
            dailyStopLossPct = stopLossPct ?: current.dailyStopLossPct,
            dailyTakeProfitPct = takeProfitPct ?: current.dailyTakeProfitPct,
            maxDailyBets = maxDailyBets ?: current.maxDailyBets,
            enabled = enabled ?: current.enabled
        )
    }

    fun clearBetLog() {
        _betLog.value = emptyList()
    }

    // ==================== 合约量化交易 ====================

    private val _futuresConfig = MutableStateFlow(FuturesQuantConfig())
    val futuresConfig: StateFlow<FuturesQuantConfig> = _futuresConfig.asStateFlow()

    private val _futuresSignal = MutableStateFlow<FuturesSignal?>(null)
    val futuresSignal: StateFlow<FuturesSignal?> = _futuresSignal.asStateFlow()

    private val _futuresPosition = MutableStateFlow(FuturesPosition.empty())
    val futuresPosition: StateFlow<FuturesPosition> = _futuresPosition.asStateFlow()

    private val _futuresDailyStats = MutableStateFlow(FuturesDailyStats(
        date = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
    ))
    val futuresDailyStats: StateFlow<FuturesDailyStats> = _futuresDailyStats.asStateFlow()

    private val _futuresLog = MutableStateFlow<List<FuturesLogEntry>>(emptyList())
    val futuresLog: StateFlow<List<FuturesLogEntry>> = _futuresLog.asStateFlow()

    private val _futuresAutoMode = MutableStateFlow(false)
    val futuresAutoMode: StateFlow<Boolean> = _futuresAutoMode.asStateFlow()

    private fun addFuturesLog(action: String, detail: String, level: LogLevel = LogLevel.INFO, pnl: Double? = null) {
        val entry = FuturesLogEntry(System.currentTimeMillis(), action, detail, pnl, level)
        _futuresLog.value = (listOf(entry) + _futuresLog.value).take(100)
    }

    /** Update futures quant configuration */
    fun updateFuturesConfig(
        leverage: Int? = null,
        positionSizePct: Double? = null,
        stopLossAtrMult: Double? = null,
        takeProfitAtrMult: Double? = null,
        trailingStopPct: Double? = null,
        marginMode: MarginMode? = null,
        minConfidence: Double? = null,
        maxDailyLossUsdt: Double? = null,
        maxPositions: Int? = null,
        enableFundingArb: Boolean? = null,
        enableMultiTakeProfit: Boolean? = null
    ) {
        val cur = _futuresConfig.value
        _futuresConfig.value = cur.copy(
            leverage = leverage ?: cur.leverage,
            positionSizePct = positionSizePct ?: cur.positionSizePct,
            stopLossAtrMult = stopLossAtrMult ?: cur.stopLossAtrMult,
            takeProfitAtrMult = takeProfitAtrMult ?: cur.takeProfitAtrMult,
            trailingStopPct = trailingStopPct ?: cur.trailingStopPct,
            marginMode = marginMode ?: cur.marginMode,
            minConfidence = minConfidence ?: cur.minConfidence,
            maxDailyLossUsdt = maxDailyLossUsdt ?: cur.maxDailyLossUsdt,
            maxPositions = maxPositions ?: cur.maxPositions,
            enableFundingArb = enableFundingArb ?: cur.enableFundingArb,
            enableMultiTakeProfit = enableMultiTakeProfit ?: cur.enableMultiTakeProfit
        )
        // Re-init position manager with new config
        positionManager = PositionManager(_futuresConfig.value)
    }

    /** Toggle auto trading mode */
    fun setFuturesAutoMode(enabled: Boolean) {
        _futuresAutoMode.value = enabled
        addFuturesLog("AUTO", if (enabled) "自动交易已开启" else "自动交易已关闭",
            if (enabled) LogLevel.SUCCESS else LogLevel.WARN)
    }

    /**
     * Main tick for futures quant: called on each refresh cycle.
     * Full automatic chain when autoMode is ON:
     * 1. Generate signal from consensus + candles
     * 2. If no position and signal is valid → execute full open chain
     * 3. If position exists → update mark price, check trailing stop / emergency close / signal reversal
     * 4. Auto-close if any trigger fires
     *
     * When autoMode is OFF: only updates signal preview and position monitoring.
     */
    fun tickFuturesQuant() {
        val s = _state.value
        val now = System.currentTimeMillis()
        val config = _futuresConfig.value

        // Throttle: don't auto-execute more than once per 10 seconds
        if (now - lastFuturesAutoTickTime < 10_000L && _futuresAutoMode.value) return

        val consensus = s.consensus
        val candles = s.candles
        if (candles.isEmpty() || consensus == null) return

        // Get account balance (use cached value; actual broker call in execute)
        val balance = _binaryAccount.value.balance.coerceAtLeast(1_000.0)

        // Generate / update signal preview
        val signal = futuresEngine.evaluateSignal(
            consensus = consensus,
            candles = candles,
            config = config,
            balance = balance
        )
        _futuresSignal.value = signal

        // === Position management branch ===
        if (positionManager.isActive()) {
            // Update mark price for existing position
            val markPrice = candles.lastOrNull()?.close ?: 0.0
            val fundingRate = s.fundingRate ?: 0.0
            positionManager.updateMarkPrice(markPrice, fundingRate)
            val snapshot = positionManager.snapshot()
            _futuresPosition.value = snapshot.position

            // Check emergency close (margin ratio / liquidation distance / trailing stop)
            snapshot.emergencyReason?.let { reason ->
                addFuturesLog("EMERGENCY_CLOSE", reason, LogLevel.ERROR, snapshot.position.unrealizedPnl)
                if (_futuresAutoMode.value) {
                    closeFuturesPositionInternal("emergency: $reason")
                }
                return
            }

            // Check signal reversal close
            val closeReason = futuresEngine.shouldClosePosition(
                currentPosition = snapshot.position,
                newConsensus = consensus,
                dailyPnlUsdt = _futuresDailyStats.value.netPnl,
                config = config
            )
            closeReason?.let { reason ->
                addFuturesLog("SIGNAL_CLOSE", reason, LogLevel.WARN, snapshot.position.unrealizedPnl)
                if (_futuresAutoMode.value) {
                    closeFuturesPositionInternal("signal: $reason")
                }
                return
            }

            // Position healthy — just update log
            if (snapshot.isProfitable) {
                addFuturesLog("POSITION", "PnL=+%.2fU ROI=+%.1f%% liqDist=%.1f%%".format(
                    snapshot.position.unrealizedPnl,
                    snapshot.pnlRoi,
                    snapshot.liquidationDistancePct
                ), LogLevel.INFO)
            }
            return
        }

        // === No position: check if we should open one ===
        if (!_futuresAutoMode.value) return
        if (signal == null) {
            if (consensus.direction != BtcDirection.FLAT) {
                addFuturesLog("SKIP", "Signal=null consensus=${consensus.direction} conf=${"%.0f%%".format(consensus.probability * 100)}")
            }
            return
        }

        // Throttle check passed
        lastFuturesAutoTickTime = now

        // === Execute full open chain ===
        executeFuturesOrderInternal(signal, balance)
    }

    /**
     * Execute the full automated opening chain:
     * setLeverage → setMarginMode → MARKET entry → STOP_MARKET(SL) → TAKE_PROFIT_MARKET(TP) → register position
     */
    private fun executeFuturesOrderInternal(signal: FuturesSignal, balance: Double) {
        val config = _futuresConfig.value
        val symbol = config.symbol
        val now = System.currentTimeMillis()

        addFuturesLog("AUTO_OPEN", signal.reason, LogLevel.INFO)

        viewModelScope.launch(Dispatchers.IO) {
            var step = "setLeverage"
            try {
                // 1. Set leverage
                val levResult = perpBroker.setLeverage(symbol, signal.leverage)
                if (!levResult.success) {
                    addFuturesLog("OPEN_FAIL", "setLeverage: ${levResult.message}", LogLevel.ERROR)
                    return@launch
                }
                addFuturesLog("LEVERAGE", "set to ${signal.leverage}x", LogLevel.SUCCESS)

                // 2. Set margin mode
                step = "setMarginMode"
                perpBroker.setMarginMode(symbol, config.marginMode)

                // 3. Build ContractSignal for MARKET entry
                step = "marketEntry"
                val contractSignal = TradingSignal.ContractSignal(
                    planId = "FUTURES-QUANT",
                    barId = now,
                    symbol = symbol,
                    direction = signal.direction,
                    probability = signal.confidence,
                    expectedMovePct = (signal.takeProfit - signal.entry) / signal.entry * 100.0,
                    entry = signal.entry,
                    stopLoss = signal.stopLoss,
                    takeProfit = signal.takeProfit,
                    horizonBars = 12,
                    positionSize = signal.quantity,
                    leverageCap = signal.leverage,
                    confidence = signal.confidence,
                    reasonPlanIds = listOf("FUTURES-QUANT")
                )

                val entryResult = perpBroker.place(contractSignal, "fq-entry-$now".take(36))
                if (!entryResult.success) {
                    addFuturesLog("OPEN_FAIL", "entry: ${entryResult.message}", LogLevel.ERROR)
                    return@launch
                }
                addFuturesLog("ENTRY", "MARKET ${signal.direction} qty=${"%.4f".format(signal.quantity)} @ ${"%.0f".format(signal.entry)} lev=${signal.leverage}x", LogLevel.SUCCESS)

                // 4. Place STOP_MARKET for stop loss
                step = "stopLoss"
                val slSide = if (signal.direction == BtcDirection.UP) "SELL" else "BUY"
                val slResult = perpBroker.placeConditionalOrder(
                    symbol = symbol,
                    side = slSide,
                    type = FuturesOrderType.STOP_MARKET,
                    quantity = signal.quantity,
                    stopPrice = signal.stopLoss,
                    reduceOnly = true,
                    clientOrderId = "fq-sl-$now".take(36)
                )
                if (slResult.success) {
                    addFuturesLog("STOP_LOSS", "STOP_MARKET @ ${"%.0f".format(signal.stopLoss)}", LogLevel.SUCCESS)
                } else {
                    addFuturesLog("SL_WARN", "stop loss order: ${slResult.message}", LogLevel.WARN)
                }

                // 5. Place TAKE_PROFIT_MARKET for take profit
                step = "takeProfit"
                val tpSide = if (signal.direction == BtcDirection.UP) "SELL" else "BUY"
                val tpResult = perpBroker.placeConditionalOrder(
                    symbol = symbol,
                    side = tpSide,
                    type = FuturesOrderType.TAKE_PROFIT_MARKET,
                    quantity = signal.quantity,
                    stopPrice = signal.takeProfit,
                    reduceOnly = true,
                    clientOrderId = "fq-tp-$now".take(36)
                )
                if (tpResult.success) {
                    addFuturesLog("TAKE_PROFIT", "TP_MARKET @ ${"%.0f".format(signal.takeProfit)}", LogLevel.SUCCESS)
                } else {
                    addFuturesLog("TP_WARN", "take profit order: ${tpResult.message}", LogLevel.WARN)
                }

                // 6. Trailing stop if configured
                if (config.trailingStopPct != null) {
                    step = "trailingStop"
                    val trailResult = perpBroker.placeConditionalOrder(
                        symbol = symbol,
                        side = tpSide,
                        type = FuturesOrderType.TRAILING_STOP_MARKET,
                        quantity = signal.quantity,
                        trailingDelta = config.trailingStopPct * 100, // bps
                        reduceOnly = true,
                        clientOrderId = "fq-trail-$now".take(36)
                    )
                    if (trailResult.success) {
                        addFuturesLog("TRAILING", "TRAILING_STOP delta=${config.trailingStopPct}%", LogLevel.SUCCESS)
                    }
                }

                // 7. Register position in PositionManager
                step = "register"
                val posSide = if (signal.direction == BtcDirection.UP) PositionSide.LONG else PositionSide.SHORT
                // Simplified liquidation price: entry - (margin/qty) for long, entry + (margin/qty) for short
                val liqDist = if (signal.quantity > 0.0) signal.margin / signal.quantity else 0.0
                val liqPrice = if (posSide == PositionSide.LONG) {
                    (signal.entry - liqDist).coerceAtLeast(0.0)
                } else {
                    signal.entry + liqDist
                }

                positionManager.register(
                    entryPrice = signal.entry,
                    quantity = signal.quantity,
                    leverage = signal.leverage,
                    margin = signal.margin,
                    liquidationPrice = liqPrice,
                    stopLoss = signal.stopLoss,
                    takeProfit = signal.takeProfit,
                    trailingStopPct = config.trailingStopPct,
                    side = posSide,
                    symbol = symbol,
                    openTime = now
                )
                _futuresPosition.value = positionManager.current()

                addFuturesLog("POSITION_OPENED", "FULL CHAIN COMPLETE: ${signal.direction} ${"%.4f".format(signal.quantity)} BTC @ ${signal.leverage}x", LogLevel.SUCCESS)

            } catch (e: Exception) {
                addFuturesLog("OPEN_ERROR", "step=$step: ${e.message ?: "unknown"}", LogLevel.ERROR)
            }
        }
    }

    /**
     * Close the current futures position (auto or manual).
     * Cancels conditional orders via reduceOnly, then closes with MARKET reduceOnly.
     */
    fun closeFuturesPosition(reason: String = "manual") {
        closeFuturesPositionInternal(reason)
    }

    private fun closeFuturesPositionInternal(reason: String) {
        if (!positionManager.isActive()) {
            addFuturesLog("CLOSE_SKIP", "no open position", LogLevel.WARN)
            return
        }
        val pos = positionManager.current()
        val pnl = pos.unrealizedPnl
        val now = System.currentTimeMillis()

        viewModelScope.launch(Dispatchers.IO) {
            try {
                val result = perpBroker.closePosition(
                    ClosePositionRequest(
                        symbol = pos.symbol,
                        reduceOnly = true,
                        reason = reason
                    )
                )
                if (result.success) {
                    addFuturesLog("CLOSED", "$reason | pnl=${"%+.2f".format(pnl)}U qty=${"%.4f".format(pos.quantity)}", LogLevel.SUCCESS, pnl)

                    // Update daily stats
                    val cur = _futuresDailyStats.value
                    val newStats = cur.copy(
                        totalTrades = cur.totalTrades + 1,
                        wins = if (pnl > 0) cur.wins + 1 else cur.wins,
                        losses = if (pnl < 0) cur.losses + 1 else cur.losses,
                        grossProfit = if (pnl > 0) cur.grossProfit + pnl else cur.grossProfit,
                        grossLoss = if (pnl < 0) cur.grossLoss + abs(pnl) else cur.grossLoss,
                        netPnl = cur.netPnl + pnl,
                        currentConsecutiveLosses = if (pnl < 0) cur.currentConsecutiveLosses + 1 else 0,
                        maxConsecutiveLosses = maxOf(cur.maxConsecutiveLosses, if (pnl < 0) cur.currentConsecutiveLosses + 1 else 0),
                        stopLossHits = if (reason.contains("stop") || reason.contains("emergency")) cur.stopLossHits + 1 else cur.stopLossHits,
                        takeProfitHits = if (reason.contains("signal") && pnl > 0) cur.takeProfitHits + 1 else cur.takeProfitHits
                    )
                    _futuresDailyStats.value = newStats
                } else {
                    addFuturesLog("CLOSE_FAIL", "${result.message}", LogLevel.ERROR)
                }

                positionManager.clear()
                _futuresPosition.value = FuturesPosition.empty(pos.symbol)

            } catch (e: Exception) {
                addFuturesLog("CLOSE_ERROR", e.message ?: "unknown", LogLevel.ERROR)
            }
        }
    }

    /** Initialize broker with real credentials (called from settings) */
    fun initFuturesBroker() {
        val creds = credentialStore.load()
        perpBroker = BrokerFactory.perp(creds, forcePaper = creds.binanceApiKey.isBlank())
        val mode = if (creds.binanceApiKey.isBlank()) "PAPER" else creds.binanceEndpoint.label.uppercase()
        addFuturesLog("BROKER", "initialized: $mode", LogLevel.INFO)
    }

    fun clearFuturesLog() {
        _futuresLog.value = emptyList()
    }

    fun resetFuturesDailyStats() {
        val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
        _futuresDailyStats.value = FuturesDailyStats(date = today)
        addFuturesLog("RESET", "daily stats reset", LogLevel.INFO)
    }

    fun saveBrokerCredentials(creds: BrokerCredentials) {
        credentialStore.save(creds)
        _creds.value = creds
    }

    fun loadBrokerCredentials(): BrokerCredentials = credentialStore.load()

    fun runMultiEngineTickWithKeys(paperPerp: Boolean = true) {
        viewModelScope.launch {
            runCatching {
                val creds = credentialStore.load()
                val orch = MultiEngineOrchestrator.fromCredentials(creds, paperPerp = paperPerp)
                val report = orch.tick(_state.value.symbol, _state.value.timeframe)
                _orch.value = buildString {
                    append("perp=${report.perpResult?.message ?: "-"}")
                    append(" | event=${report.eventResult?.message ?: "-"}")
                    append(" | poly=${report.polyResults.joinToString { it.message }}")
                    if (report.notes.isNotEmpty()) append(" | ").append(report.notes.joinToString(";"))
                }
            }.onFailure { _orch.value = it.message }
        }
    }

    fun testBinanceConnectivity() {
        viewModelScope.launch {
            runCatching {
                val c = credentialStore.load()
                if (c.binanceApiKey.isBlank()) {
                    _orch.value = "未配置币安Key：仅公共行情可用"
                    return@launch
                }
                val b = BinanceFuturesBroker(c.binanceApiKey, c.binanceSecret, c.binanceEndpoint)
                val ping = b.ping()
                val acct = runCatching { b.accountSnapshot() }.getOrNull()
                _orch.value = "ping=$ping endpoint=${c.binanceEndpoint.label} bal=${acct?.availableBalance}"
            }.onFailure { _orch.value = "连通性失败: ${it.message}" }
        }
    }

    fun runMultiEngineTick() {
        viewModelScope.launch {
            runCatching {
                val report = orchestrator.tick(_state.value.symbol, _state.value.timeframe)
                _orch.value = buildString {
                    append("perp=${report.perpResult?.message ?: "-"}")
                    append(" | event=${report.eventResult?.message ?: "-"}")
                    append(" | poly=${report.polyResults.size}")
                    if (report.notes.isNotEmpty()) append(" | ").append(report.notes.joinToString(";"))
                }
            }.onFailure { _orch.value = it.message }
        }
    }

    init { refresh() }

    fun refresh(symbol: String = "BTCUSDT", timeframe: String = _state.value.timeframe) {
        _state.value = _state.value.copy(symbol = symbol, timeframe = timeframe, loading = true, error = null)
        viewModelScope.launch {
            runCatching {
                val candles = repo.loadKlines(symbol, timeframe, 300)
                val funding = runCatching { derivRepo.fundingHistory(symbol, 100) }.getOrDefault(emptyList())
                val oi = runCatching { derivRepo.openInterestHistory(symbol, timeframe, 100) }.getOrDefault(emptyList())
                val snap = runCatching { derivRepo.snapshot(symbol) }.getOrNull()
                val last = candles.lastOrNull()
                val prev = candles.getOrNull((candles.size - 2).coerceAtLeast(0))
                val deriv = if (last != null) DerivativesFeatureEngine.build(last.openTime, last.close, prev?.close, funding, oi, snap) else null
                val news = runCatching { newsRepo.snapshot() }.getOrNull()
                val (basePlans, baseConsensus) = engine.evaluate(candles, deriv)
                val aiCand = aiBrain.generateCandidate(candles, basePlans, baseConsensus, news, deriv)
                val aiJson = aiBrain.toForcedJson(aiCand)
                val aiPlan = AiPolicy.toPlanSignal(aiCand, aiPolicy)
                val (plans, consensus) = if (aiPlan != null) {
                    engine.evaluate(candles, deriv, extraSignals = listOf(aiPlan))
                } else basePlans to baseConsensus
                _state.value = _state.value.copy(
                    candles = candles,
                    plans = plans,
                    consensus = consensus,
                    loading = false,
                    updatedAt = System.currentTimeMillis(),
                    newsNetSentiment = news?.netSentiment,
                    newsBlackSwan = news?.blackSwan == true,
                    newsHeadlines = news?.topHeadlines ?: emptyList(),
                    aiDirection = aiCand.direction,
                    aiConfidence = aiCand.confidence,
                    aiJson = aiJson,
                    aiLiveAllowed = AiPolicy.mayExecuteLive(aiPolicy, aiCand),
                    fundingRate = deriv?.fundingRate ?: snap?.fundingRate,
                    fundingZScore = deriv?.fundingZScore,
                    fundingExtreme = deriv?.fundingExtreme == true,
                    oiChangePct = deriv?.oiChangePct,
                    derivativesScore = deriv?.derivativesScore,
                    markPrice = snap?.markPrice
                )
                // 触发二元期权周期管理
                tickBinaryRound()
                // 触发合约量化 tick
                tickFuturesQuant()
            }.onFailure { e ->
                _state.value = _state.value.copy(loading = false, error = e.message ?: "行情加载失败")
            }
        }
    }
}
