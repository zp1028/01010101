# SmartTraderAPK — 完整自包含 APK

这是一个**完整自包含的 Android APK 项目**：
- Python FastAPI 后端（Chaquopy 打包进 APK）
- 前端静态资源打包进 assets
- APP 启动时本地起 uvicorn（127.0.0.1:8000）
- WebView 加载本地页面，不需要远程服务器

## 使用步骤

### 1. 推到 GitHub
- 新建仓库（如 `smart-trader-apk`）
- 把本文件夹所有内容传上去
- Commit

### 2. Actions 自动构建
- 仓库顶部点 **Actions** 标签
- 看到 "Build Full APK" 在跑（黄圆点）
- 等 5–10 分钟（Chaquopy 要编译 Python 依赖，比纯壳慢）
- 变绿勾即成功

### 3. 下载 APK
- 点进完成的 Build 记录
- 拉到底部 **Artifacts**
- 点 `smart-trader-full-apk` 下载（zip，解压后里面是 `app-debug.apk`）
- 传到手机安装，允许"未知来源"

## 说明

- 这是 **debug 签名** APK，自用没问题
- APP 启动后会主动探测本地 Runtime；行情不可用时仍进入终端，并显示降级/诊断状态，不会白屏
- 不需要 Render、不需要 URL、不需要外网（除了拉行情数据）
- 行情由统一 Market Data Hub 管理 Binance / Gate / OKX / Bybit，并保留 provider 来源与 freshness
- 数据存在手机本地 SQLite
- 按返回键先回退网页，再退出

## 技术栈

- Chaquopy 15.0.1（Python 运行时打包进 APK）
- FastAPI + uvicorn（后端）
- WebView（前端加载）
- minSdk 24（Android 7.0+），targetSdk 34

## V2 核心链路

```text
Android Runtime → FastAPI → Market Data Hub → Quant → Strategy → Risk → Backtest → AI Research
```

运行时与行情状态分离：`/api/v1/runtime/ready` 的 `status=ready` 表示本地终端可运行，`market_ready` 单独表示是否存在真实实时行情。这样交易所或网络故障不会把整个应用变成空白页面。

新增核心接口：
- `/api/v1/datahub/snapshot`
- `/api/v1/strategies`
- `/api/v1/backtest/run`
- `/api/v1/quant/snapshot`
- `/api/v1/risk/evaluate`
- `/api/v1/paper/orders`
- `/api/v1/research/overview`
- `/api/v1/diagnostics`
