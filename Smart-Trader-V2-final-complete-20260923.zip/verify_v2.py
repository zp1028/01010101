import ast, pathlib, subprocess, sys
root=pathlib.Path(__file__).parent/'app/src/main/python'
for p in root.rglob('*.py'):
    ast.parse(p.read_text(encoding='utf-8'))
print('AST_OK')
print('V2 endpoints: datahub, strategies, backtest/run, research/overview, diagnostics')
