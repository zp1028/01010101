# Smart Trader V2 — 2026-09-23 全量阶段记录

## 本阶段
- 新增 MarketDataHub：统一实时行情真值、来源、freshness、quality。
- 新增 `/api/v1/datahub/snapshot`。
- 新增 `/api/v1/strategies`：暴露统一 StrategyRegistry。
- 新增 `/api/v1/backtest/run`：实时/回测共享 Strategy Core 的向量化回测入口。
- 新增 `/api/v1/research/overview`。
- 新增 `/api/v1/diagnostics`：Runtime、数据库、实时行情和 Provider 诊断。
- Android 启动链路由“HTTP 可用即加载”升级为“HTTP Ready → Live Market Ready → WebView”。
- WebView renderer 崩溃增加恢复状态；主页面错误不会伪装成空白成功。
- Python 全量 `compileall` 通过。

## 架构原则
- UI 不直接决定 Provider。
- Provider 不直接决定 Strategy。
- Strategy 必须经过 Risk。
- 回测与实时信号使用同一 Strategy Registry。
- 没有真实行情时，Runtime 不声明 APP_READY。
- 行情故障不能导致整个 UI 消失。

## 构建验证
- Python compileall: PASS
- Strategy Registry import: PASS（4 个策略）
- Android Gradle assembleDebug: 当前执行环境无法完成，因为 Gradle Wrapper 需要访问 services.gradle.org，而该环境 DNS/外网不可用；未伪造 BUILD SUCCESS。

## 2026-09-23 — V2 Terminal Completion Pass
- Rebuilt the embedded V2 terminal UI around real API-backed Command / Market / Quant / Strategy / Backtest / Research views.
- Quant view now consumes `/indicators`, multi-timeframe analysis and `/quant/snapshot` instead of placeholder cards.
- Strategy view now consumes the versioned Strategy Registry and exposes strategy metadata/parameters.
- Backtest view now fetches real OHLCV data and runs `/backtest/run`, displaying return, drawdown, trade count, win rate, Sharpe, profit factor, equity curve and recent trades.
- Research view now consumes `/research/overview` and surfaces current market truth plus risk-model metadata.
- Replaced the previous placeholder Strategy/Backtest/Quant/Research panels; the UI no longer claims these modules are merely "next stage".
- Kept degraded-data behavior explicit: provider failure is shown as degraded instead of fabricating prices or blocking the terminal.
- Python compile/import/routing smoke checks passed after this pass.

## 2026-09-23 — Final Runtime/CI Hardening
- Corrected Binance adapter naming to `BinanceSpotMarketData`; the gateway no longer exposes a USDⓈ-M class name for Spot REST endpoints.
- Added `received_at` to market quotes and changed MarketDataHub freshness calculations to use local receipt time rather than exchange ticker close time.
- Added `scripts/smoke_v2.py` for AST, route, and six-section UI smoke validation.
- CI now validates Python/UI before Android build, accepts SDK licenses, verifies Gradle wrapper, builds both Debug and Release, and uploads failure diagnostics.
- Runtime health now distinguishes paper execution from live execution instead of reporting the paper execution path as unavailable.
- Removed unused Android WebView retry state.
