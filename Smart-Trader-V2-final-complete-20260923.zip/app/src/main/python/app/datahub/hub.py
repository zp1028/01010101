from __future__ import annotations
import time
from typing import Any
from app.services.crypto_provider_gateway import CryptoProviderGateway

class MarketDataHub:
    """Single read path for normalized market truth."""
    def __init__(self, gateway: CryptoProviderGateway | None = None):
        self.gateway = gateway or CryptoProviderGateway()
        self._last: dict[str, Any] = {}

    async def snapshot(self, symbols: list[str] | None = None) -> dict[str, Any]:
        rows = await self.gateway.market_rows()
        wanted = {s.upper().replace('/','').replace('-','') for s in symbols or []}
        if wanted:
            rows = [r for r in rows if str(r.get('symbol','')).upper().replace('/','').replace('-','') in wanted]
        now = int(time.time()*1000)
        normalized = []
        for r in rows:
            item = dict(r)
            received_at = int(item.get('received_at') or now)
            source_time = int(item.get('data_time') or item.get('book_data_time') or received_at)
            age = max(0, now-received_at)
            item['freshness_ms'] = age
            item['received_at'] = received_at
            item['source_time'] = source_time
            item['quality'] = 'live' if item.get('quote_status') == 'live' and age <= 10_000 else ('stale' if item.get('price') is not None else 'offline')
            item['source'] = item.get('provider') or item.get('venue') or item.get('source')
            normalized.append(item)
        providers = {}
        for r in normalized:
            p = r.get('provider') or 'unknown'
            providers.setdefault(p, {'provider':p,'live':0,'stale':0})
            providers[p]['live'] += int(r['quality']=='live')
            providers[p]['stale'] += int(r['quality']=='stale')
        result = {'generated_at':now,'count':len(normalized),'markets':normalized,'providers':list(providers.values()),'truth':'live' if any(x['quality']=='live' for x in normalized) else 'degraded'}
        self._last=result
        return result
