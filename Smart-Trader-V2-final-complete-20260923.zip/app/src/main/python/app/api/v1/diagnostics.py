from __future__ import annotations
import time
from fastapi import APIRouter

router=APIRouter(tags=['diagnostics'])

@router.get('/diagnostics')
async def diagnostics():
    from app.main import runtime_state, crypto_market_gateway, instruments
    checks=[]
    try:
        rows=await crypto_market_gateway.market_rows()
        live=[r for r in rows if r.get('quote_status')=='live' and r.get('price') is not None]
        checks.append({'name':'live_market','status':'ok' if live else 'degraded','count':len(live)})
    except Exception as exc:
        checks.append({'name':'live_market','status':'error','error':str(exc)})
    checks += [
        {'name':'runtime','status':'ok' if runtime_state.get('backend')=='ready' else 'degraded'},
        {'name':'database','status':'ok' if runtime_state.get('last_error') is None else 'degraded'},
        {'name':'instruments','status':'ok','count':len(instruments.list_all())},
    ]
    return {'generated_at':int(time.time()*1000),'overall':'ok' if all(c['status']=='ok' for c in checks) else 'degraded','checks':checks,'runtime':dict(runtime_state),'providers':list(crypto_market_gateway.order)}
