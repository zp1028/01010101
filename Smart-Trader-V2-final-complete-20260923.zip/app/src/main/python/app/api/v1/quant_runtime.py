from __future__ import annotations
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import Any, Literal

from app.main import feature_engine, risk_engine
from app.quant.strategies import default_registry
from app.risk.models import TradeProposal
from app.execution import PaperExecutionEngine

router = APIRouter(tags=["quant-runtime"])
paper = PaperExecutionEngine(risk_engine)

class RiskRequest(BaseModel):
    instrument_id: str
    symbol: str
    side: Literal["long", "short", "flat"]
    entry_price: float | None = None
    stop_price: float | None = None
    take_profit: float | None = None
    position_pct: float | None = Field(default=None, ge=0, le=1)
    quantity: float | None = Field(default=None, ge=0)
    leverage: float = Field(default=1, gt=0)
    reason: str = ""
    source: str = "strategy"

@router.get("/quant/snapshot")
async def quant_snapshot(symbol: str = "BTCUSDT", timeframe: str = "15m"):
    key = f"crypto:{symbol.upper()}"
    snap = feature_engine.get_latest(key, timeframe)
    if snap is None:
        return {"status":"waiting", "symbol":symbol.upper(), "timeframe":timeframe, "features":{}}
    registry = default_registry()
    signals=[]
    for s in registry.list():
        if timeframe in s.timeframes:
            signals.extend([{**x, "strategy":s.id, "version":s.version} for x in registry.evaluate(s.id, snap)])
    return {"status":"ready", "snapshot":feature_engine.snapshot_dict(snap), "signals":signals}

@router.post("/risk/evaluate")
def evaluate_risk(body: RiskRequest):
    proposal=TradeProposal(**body.model_dump())
    return risk_engine.validate(proposal).model_dump()

@router.get("/paper/orders")
def paper_orders():
    return {"mode":"paper","orders":paper.list()}

@router.post("/paper/orders")
def paper_order(body: RiskRequest):
    proposal=TradeProposal(**body.model_dump())
    return paper.submit(proposal)
