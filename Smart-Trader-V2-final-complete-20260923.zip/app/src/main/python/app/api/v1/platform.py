from __future__ import annotations
import time
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field
from app.datahub.hub import MarketDataHub
from app.quant.strategies import default_registry
from app.backtest.models import BacktestConfig
from app.backtest.vectorized.engine import run_vectorized
from app.risk.models import RiskLimits

router = APIRouter(tags=['v2-platform'])
hub = MarketDataHub()

@router.get('/datahub/snapshot')
async def datahub_snapshot(symbols: str | None = Query(None)):
    wanted = [x.strip() for x in symbols.split(',')] if symbols else None
    return await hub.snapshot(wanted)

@router.get('/strategy-registry')
def strategies():
    r=default_registry()
    return {'strategies':[{'id':s.id,'version':s.version,'name':s.name,'description':s.description,'markets':list(s.markets),'timeframes':list(s.timeframes),'parameters':s.parameters} for s in r.list()]}

class BacktestRequest(BaseModel):
    symbol: str = 'BTCUSDT'
    timeframe: str = '15m'
    strategy: str = 'rsi'
    strategy_params: dict = Field(default_factory=dict)
    initial_cash: float = Field(default=10000, gt=0)
    fee_rate: float = Field(default=0.0004, ge=0)
    slippage_bps: float = Field(default=1.0, ge=0)
    bars: list[dict]

@router.post('/backtest/run')
def backtest_run(body: BacktestRequest):
    cfg=BacktestConfig(instrument_id=f'crypto:{body.symbol.upper()}',symbol=body.symbol.upper(),timeframe=body.timeframe,bars=body.bars,initial_cash=body.initial_cash,fee_rate=body.fee_rate,slippage_bps=body.slippage_bps,strategy=body.strategy,strategy_params=body.strategy_params)
    try:
        result=run_vectorized(cfg)
    except Exception as exc:
        raise HTTPException(422, detail=str(exc)) from exc
    return result.model_dump()

@router.get('/research/overview')
async def research_overview(symbol: str='BTCUSDT'):
    snap=await hub.snapshot([symbol])
    row=(snap['markets'] or [None])[0]
    return {'generated_at':int(time.time()*1000),'symbol':symbol.upper(),'market':row,'strategy_count':len(default_registry().list()),'risk_model':RiskLimits().model_dump(),'research_state':'ready' if row else 'waiting'}
