from __future__ import annotations
import time, uuid
from dataclasses import dataclass, asdict
from typing import Any

from app.risk.engine import RiskEngine
from app.risk.models import TradeProposal

@dataclass
class PaperOrder:
    order_id: str
    symbol: str
    side: str
    quantity: float
    price: float
    status: str
    created_at: int
    source: str
    reason: str = ""

class PaperExecutionEngine:
    """Deterministic paper execution adapter. It never calls an exchange."""
    def __init__(self, risk: RiskEngine):
        self.risk = risk
        self.orders: dict[str, PaperOrder] = {}

    def submit(self, proposal: TradeProposal) -> dict[str, Any]:
        decision = self.risk.validate(proposal)
        if not decision.approved:
            return {"accepted": False, "risk": decision.model_dump(), "order": None}
        p = decision.adjusted or proposal
        price = float(p.entry_price or 0)
        qty = float(p.quantity or 0)
        if price <= 0 or qty <= 0:
            return {"accepted": False, "risk": decision.model_dump(), "order": None, "error": "entry_price and quantity are required"}
        oid = f"paper_{uuid.uuid4().hex[:12]}"
        order = PaperOrder(oid, p.symbol, p.side, qty, price, "filled", int(time.time()*1000), p.source, p.reason)
        self.orders[oid] = order
        return {"accepted": True, "risk": decision.model_dump(), "order": asdict(order)}

    def list(self) -> list[dict[str, Any]]:
        return [asdict(x) for x in self.orders.values()]
