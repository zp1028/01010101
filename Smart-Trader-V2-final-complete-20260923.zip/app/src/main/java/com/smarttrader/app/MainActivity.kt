package com.smarttrader.app

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private lateinit var statusTitle: TextView
    private lateinit var statusDetail: TextView
    private lateinit var progressBar: ProgressBar
    private val mainHandler = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val loaded = AtomicBoolean(false)
    private var destroyed = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildStartupUi()
        configureWebView()
        startBackend()
    }

    private fun buildStartupUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(8, 12, 20))
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        statusTitle = TextView(this).apply {
            text = "SMART TRADER"
            textSize = 28f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        statusDetail = TextView(this).apply {
            text = "正在启动运行时…"
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 5
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 8)
        }
        root.addView(statusTitle, LinearLayout.LayoutParams(-1, -2))
        root.addView(statusDetail, LinearLayout.LayoutParams(-1, -2))
        root.addView(progressBar)
        webView = WebView(this)
        webView.visibility = View.GONE
        root.addView(webView, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.databaseEnabled = true
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        webView.settings.setSupportZoom(false)
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return request.url.host != "127.0.0.1"
            }
            override fun onRenderProcessGone(view: WebView, detail: android.webkit.RenderProcessGoneDetail): Boolean {
                loaded.set(false)
                showStartupStatus("正在恢复终端", "Web 渲染进程已重启…", 80)
                mainHandler.postDelayed({ loadApp() }, 350)
                return true
            }
            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) showStartupError("Web 页面加载失败：${error.description}")
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progressBar.progress = newProgress
                if (newProgress >= 100) progressBar.visibility = View.GONE
            }
        }
    }

    private fun startBackend() {
        try {
            if (!Python.isStarted()) Python.start(AndroidPlatform(this))
            val py = Python.getInstance()
            io.execute {
                try {
                    py.getModule("main").callAttr("run_server")
                } catch (e: Exception) {
                    mainHandler.post { showStartupError("Backend 启动失败：${e.message ?: e.javaClass.simpleName}") }
                }
            }
            mainHandler.postDelayed({ probeHttp(0) }, 150)
        } catch (e: Exception) {
            showStartupError("Python Runtime 启动失败：${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun probeHttp(attempt: Int) {
        if (destroyed || loaded.get()) return
        io.execute {
            val ok = try {
                val conn = (URL("http://127.0.0.1:8000/api/v1/runtime/status").openConnection() as HttpURLConnection).apply {
                    connectTimeout = 700
                    readTimeout = 900
                    requestMethod = "GET"
                }
                val result = conn.responseCode in 200..299 && conn.responseCode != 204
                conn.disconnect()
                result
            } catch (_: Exception) { false }
            mainHandler.post {
                if (ok) {
                    showStartupStatus("运行时已连接", "正在验证实时行情…", 70)
                    probeReady(0)
                } else if (attempt < 60) {
                    val pct = (10 + attempt).coerceAtMost(65)
                    showStartupStatus("正在启动运行时", "等待本地服务就绪… ${attempt + 1}s", pct)
                    mainHandler.postDelayed({ probeHttp(attempt + 1) }, 500)
                } else {
                    showStartupError("本地服务启动超时。请点击系统重启后再试。")
                }
            }
        }
    }


    private fun probeReady(attempt: Int) {
        if (destroyed || loaded.get()) return
        io.execute {
            val ready = try {
                val conn = (URL("http://127.0.0.1:8000/api/v1/runtime/ready").openConnection() as HttpURLConnection).apply {
                    connectTimeout = 1200
                    readTimeout = 1800
                    requestMethod = "GET"
                }
                val ok = conn.responseCode == 200
                conn.disconnect()
                ok
            } catch (_: Exception) { false }
            mainHandler.post {
                if (ready) {
                    showStartupStatus("运行时已就绪", "正在进入 Smart Trader…", 100)
                    loadApp()
                } else if (attempt < 20) {
                    showStartupStatus("正在连接运行时", "等待本地服务响应… ${attempt + 1}s", (72 + attempt).coerceAtMost(92))
                    mainHandler.postDelayed({ probeReady(attempt + 1) }, 600)
                } else {
                    // The terminal must remain usable even when live providers are offline.
                    // The web UI will show MARKET_DEGRADED instead of becoming a blank screen.
                    showStartupStatus("行情暂不可用", "进入终端诊断模式…", 100)
                    loadApp()
                }
            }
        }
    }

    private fun loadApp() {
        if (!loaded.compareAndSet(false, true)) return
        webView.visibility = View.VISIBLE
        statusTitle.visibility = View.GONE
        statusDetail.visibility = View.GONE
        webView.loadUrl("http://127.0.0.1:8000/")
    }

    private fun showStartupStatus(title: String, detail: String, progress: Int) {
        if (destroyed) return
        statusTitle.text = title
        statusDetail.text = detail
        progressBar.progress = progress
    }

    private fun showStartupError(detail: String) {
        if (destroyed) return
        loaded.set(false)
        webView.visibility = View.GONE
        statusTitle.visibility = View.VISIBLE
        statusDetail.visibility = View.VISIBLE
        statusTitle.text = "SMART TRADER"
        statusDetail.text = "⚠ $detail\n\n请检查系统诊断或重新启动应用。"
        progressBar.progress = 0
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView.visibility == View.VISIBLE && webView.canGoBack()) {
            webView.goBack()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        destroyed = true
        mainHandler.removeCallbacksAndMessages(null)
        io.shutdownNow()
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
