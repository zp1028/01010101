package com.caifenxi.app.ui.screens

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.graphics.Bitmap
import android.os.Bundle
import android.os.Message
import android.webkit.JavascriptInterface
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.CookieManager
import android.webkit.WebViewClient
import com.caifenxi.app.util.RuntimeLog
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.DragHandle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.draw.scale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlin.math.roundToInt
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.automation.LocalSelectorLoader
import com.caifenxi.app.data.config.UrlHistoryStore
import com.caifenxi.app.domain.execution.ClickMatchConfig
import com.caifenxi.app.domain.execution.ExecutorManager
import com.caifenxi.app.domain.execution.ExecutionTicketStore
import com.caifenxi.app.domain.execution.ApiMappingStore
import com.caifenxi.app.domain.execution.NetworkLogStore
import com.caifenxi.app.domain.execution.ApiInjectExecutor
import com.caifenxi.app.service.WebViewExecutor
import com.caifenxi.app.ui.ExecutorViewModel
import com.caifenxi.app.ui.MainViewModel
import okhttp3.MediaType.Companion.toMediaType

/**
 * CORS 代理 Bridge：SPA 站点跨域 API 请求被浏览器同源策略拦截时，
 * 通过 Android 原生层转发请求并注入 Access-Control-Allow-Origin 头。
 */
class CorsProxyBridge(private val client: okhttp3.OkHttpClient) {
    @JavascriptInterface
    fun fetch(method: String, url: String, headers: String, body: String): String {
        return try {
            val req = okhttp3.Request.Builder().url(url)
            if (headers.isNotBlank()) {
                headers.split("\n").forEach { line ->
                    val idx = line.indexOf(":")
                    if (idx > 0) req.header(line.substring(0, idx).trim(), line.substring(idx + 1).trim())
                }
            }
            if (method.equals("POST", ignoreCase = true) && body.isNotBlank()) {
                req.post(okhttp3.RequestBody.create("application/json;charset=utf-8".toMediaType(), body))
            } else if (method.equals("POST", ignoreCase = true)) {
                req.post(okhttp3.RequestBody.create(null, ByteArray(0)))
            }
            val resp = client.newCall(req.build()).execute()
            val respBody = resp.body?.string() ?: ""
            val json = buildString {
                append("{\"status\":").append(resp.code)
                append(",\"headers\":\"")
                val hdr = StringBuilder()
                resp.headers.names().forEach { name ->
                    hdr.append(name).append(":").append(resp.header(name)).append("\n")
                }
                append(hdr.toString().replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n"))
                append("\",\"body\":\"")
                append(respBody.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n"))
                append("\"}")
            }
            json
        } catch (e: Exception) {
            "{\"error\":\"" + e.message?.replace("\\", "\\\\")?.replace("\"", "\\\"") + "\"}"
        }
    }
}

/**
 * CORS 代理注入 JS：劫持 fetch/XMLHttpRequest，跨域请求经 Android CfxCorsProxy 转发。
 */
private const val CORS_PROXY_JS = """
(function(){
  if(window.__CFX_CORS_PATCHED) return;
  window.__CFX_CORS_PATCHED = true;
  var origFetch = window.fetch;
  window.fetch = function(url, opts) {
    opts = opts || {};
    var u = (typeof url === 'string') ? url : (url && url.url ? url.url : '');
    try {
      var parsed = new URL(u, location.href);
      if(parsed.origin !== location.origin) {
        return new Promise(function(resolve, reject) {
          var method = (opts.method || 'GET').toUpperCase();
          var hdrs = '';
          if(opts.headers) {
            if(typeof opts.headers === 'object') {
              for(var k in opts.headers) hdrs += k + ':' + opts.headers[k] + '\n';
            }
          }
          var body = '';
          if(opts.body && typeof opts.body === 'string') body = opts.body;
          var result = CfxCorsProxy.fetch(method, parsed.href, hdrs, body);
          var resp = JSON.parse(result);
          if(resp.error) { reject(new TypeError(resp.error)); return; }
          var blob = new Blob([resp.body || ''], {type: 'application/json'});
          var r = new Response(blob, {status: resp.status || 200, statusText: 'OK'});
          resolve(r);
        });
      }
    } catch(e) {}
    return origFetch.apply(this, arguments);
  };
  var OrigXHR = window.XMLHttpRequest;
  window.XMLHttpRequest = function() {
    var xhr = new OrigXHR();
    var origOpen = xhr.open;
    var origSend = xhr.send;
    var _method = 'GET', _url = '', _async = true, _hdrs = {};
    xhr.open = function(method, url, async) {
      _method = method; _url = url; _async = (async !== false);
      return origOpen.apply(xhr, arguments);
    };
    xhr.setRequestHeader = function(name, value) {
      _hdrs[name] = value;
      if(xhr.setRequestHeader) xhr.setRequestHeader.call(xhr, name, value);
    };
    xhr.send = function(body) {
      try {
        var parsed = new URL(_url, location.href);
        if(parsed.origin !== location.origin) {
          var hdrs = '';
          for(var k in _hdrs) hdrs += k + ':' + _hdrs[k] + '\n';
          var result = CfxCorsProxy.fetch(_method, parsed.href, hdrs, (body || ''));
          var resp = JSON.parse(result);
          Object.defineProperty(xhr, 'status', {value: resp.status || 200, writable: false});
          Object.defineProperty(xhr, 'responseText', {value: resp.body || '', writable: false});
          Object.defineProperty(xhr, 'readyState', {value: 4, writable: false});
          if(xhr.onreadystatechange) xhr.onreadystatechange();
          if(xhr.onload) xhr.onload();
          return;
        }
      } catch(e) {}
      return origSend.apply(xhr, arguments);
    };
    return xhr;
  };
})();
"""

/**
 * 按钮标注 JavascriptInterface：用户在 WebView 点击元素 → JS 生成 selector → 回传 Android。
 */
class MappingBridge {
    @Volatile
    var pickedCallback: ((String, String) -> Unit)? = null

    @JavascriptInterface
    fun onPicked(selector: String, text: String) {
        pickedCallback?.invoke(selector, text)
    }
}

/** 持久化 WebView 状态，防止页面切换时白屏 */
private object WebViewStateHolder {
    var savedState: Bundle? = null
}

/**
 * 标注模式注入的 JS：监听 click + touchend，生成 CSS selector，通过 bridge 回传。
 * 支持同源 iframe 内元素标注；页面导航后由 onPageFinished 重新注入。
 */
private const val MAPPING_JS = """
(function(){
  // 允许重复注入：页面 SPA 导航后重新绑定
  window.__CFX_MAPPING_ACTIVE = window.__CFX_MAPPING_ACTIVE || false;
  window.__cfxMappingLastEvent = 0;

  function __cfxCssEscape(s){
    if(window.CSS && CSS.escape) return CSS.escape(s);
    return String(s).replace(/([ !"#$%&'()*+,./:;<=>?@\[\\\]^`{|}~])/g, '\\$1');
  }

  function __cfxGetClasses(el){
    try{
      if(el.classList && el.classList.length){
        return Array.prototype.slice.call(el.classList).filter(function(c){
          return c && c.indexOf('cfx-')!==0 && !/^ng-|^css-|^sc-|^emotion-|^jsx-/.test(c);
        });
      }
      var cn = el.className;
      if(typeof cn === 'string') return cn.trim().split(/\s+/).filter(Boolean);
      if(cn && typeof cn.baseVal === 'string') return cn.baseVal.trim().split(/\s+/).filter(Boolean);
    }catch(e){}
    return [];
  }

  function __cfxUniqueSelector(el){
    if(!el || el.nodeType !== 1) return '';
    if(el.id && typeof el.id === 'string' && el.id.indexOf('cfx-')!==0){
      var idSel = '#' + __cfxCssEscape(el.id);
      try{ if(document.querySelectorAll(idSel).length === 1) return idSel; }catch(e){}
    }
    var attrs = ['data-testid','data-id','data-play','data-type','data-value','data-name','data-code','name','aria-label','role'];
    for(var ai=0; ai<attrs.length; ai++){
      var av = el.getAttribute(attrs[ai]);
      if(av && av.length < 64){
        var aSel = el.tagName.toLowerCase() + '[' + attrs[ai] + '="' + av.replace(/"/g,'\\"') + '"]';
        try{ if(document.querySelectorAll(aSel).length === 1) return aSel; }catch(e){}
      }
    }
    var tag = el.tagName.toLowerCase();
    var classes = __cfxGetClasses(el).slice(0, 4);
    var sel = tag;
    for(var ci=0; ci<classes.length; ci++){
      sel += '.' + __cfxCssEscape(classes[ci]);
      try{ if(document.querySelectorAll(sel).length === 1) return sel; }catch(e){}
    }
    var path = [];
    var cur = el;
    var depth = 0;
    while(cur && cur !== document.body && cur !== document.documentElement && depth < 10){
      var p = cur.parentElement;
      if(!p) break;
      var sameTag = 0, idx = 0;
      for(var i=0;i<p.children.length;i++){
        if(p.children[i].tagName === cur.tagName){
          sameTag++;
          if(p.children[i] === cur) idx = sameTag;
        }
      }
      var part = cur.tagName.toLowerCase();
      var pcs = __cfxGetClasses(cur).slice(0, 1);
      if(pcs.length) part += '.' + __cfxCssEscape(pcs[0]);
      if(sameTag > 1) part += ':nth-of-type(' + idx + ')';
      path.unshift(part);
      var trial = path.join(' > ');
      try{ if(document.querySelectorAll(trial).length === 1) return trial; }catch(e){}
      cur = p;
      depth++;
    }
    return path.join(' > ');
  }

  function __cfxReport(el){
    var sel = __cfxUniqueSelector(el);
    if(!sel) return;
    // v2.5.3: 验证生成的 selector 是否唯一且能正确找到目标元素
    try{
      var matched = document.querySelectorAll(sel);
      if(matched.length !== 1 || matched[0] !== el){
        // 不唯一或匹配到错误元素 → 追加 nth-child 精确化
        var parent = el.parentElement;
        if(parent){
          var siblings = Array.prototype.slice.call(parent.children);
          var idx = siblings.indexOf(el) + 1;
          sel = sel + ':nth-child(' + idx + ')';
          // 再次验证
          var matched2 = document.querySelectorAll(sel);
          if(matched2.length !== 1 || matched2[0] !== el){
            console.warn('[CFX] selector not unique after nth-child fix:', sel, 'matched', matched2.length);
          }
        }
      }
    }catch(e){ console.warn('[CFX] selector validation error:', e); }
    try{
      el.style.outline = '4px solid #00c853';
      el.style.outlineOffset = '2px';
      setTimeout(function(){ try{ el.style.outline=''; el.style.outlineOffset=''; }catch(_){} }, 1800);
    }catch(_){}
    var txt = (el.innerText || el.value || el.getAttribute('aria-label') || el.getAttribute('placeholder') || '').replace(/\s+/g,' ').substring(0, 50);
    try{
      if(window.CfxMappingBridge && typeof window.CfxMappingBridge.onPicked === 'function'){
        window.CfxMappingBridge.onPicked(sel, txt);
        return;
      }
    }catch(e){}
    try{
      if(window.top && window.top !== window){
        window.top.postMessage({__cfxMapping:true, selector:sel, text:txt}, '*');
      }
    }catch(e){}
  }

  window.__cfxMappingHandler = function(e){
    if(!window.__CFX_MAPPING_ACTIVE) return;
    var now = Date.now();
    // v2.5.3: 去抖间隔从 280ms 提升到 600ms，防止快速连击/触屏抖动产生重复选择
    if(now - window.__cfxMappingLastEvent < 600) return;
    window.__cfxMappingLastEvent = now;
    var el = e.target;
    var hops = 0;
    while(el && hops < 5){
      if(el === document || el === document.body || el === document.documentElement) break;
      if(el.id && String(el.id).indexOf('cfx-')===0) return;
      var tag = (el.tagName||'').toLowerCase();
      var role = el.getAttribute && el.getAttribute('role');
      var clickable = tag==='button'||tag==='a'||tag==='input'||tag==='label'||tag==='li'||
        role==='button'|| (el.onclick) || (el.getAttribute && (el.getAttribute('ng-click')||el.getAttribute('@click')));
      if(clickable || hops===0){
        try{ e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); }catch(_){}
        __cfxReport(el);
        return false;
      }
      el = el.parentElement;
      hops++;
    }
    if(e.target && e.target !== document.body){
      try{ e.preventDefault(); e.stopPropagation(); }catch(_){}
      __cfxReport(e.target);
    }
    return false;
  };

  try{
    document.removeEventListener('click', window.__cfxMappingHandler, true);
    document.removeEventListener('touchend', window.__cfxMappingHandler, true);
    document.removeEventListener('pointerup', window.__cfxMappingHandler, true);
  }catch(e){}
  document.addEventListener('click', window.__cfxMappingHandler, true);
  document.addEventListener('touchend', window.__cfxMappingHandler, true);
  document.addEventListener('pointerup', window.__cfxMappingHandler, true);

  if(!window.__cfxMappingMsgBound){
    window.__cfxMappingMsgBound = true;
    window.addEventListener('message', function(ev){
      try{
        var d = ev.data;
        if(d && d.__cfxMapping && d.selector && window.CfxMappingBridge){
          window.CfxMappingBridge.onPicked(d.selector, d.text||'');
        }
      }catch(e){}
    });
  }

  window.__cfxInjectIframes = function(){
    try{
      var frames = document.querySelectorAll('iframe');
      for(var i=0;i<frames.length;i++){
        try{
          var fd = frames[i].contentDocument || (frames[i].contentWindow && frames[i].contentWindow.document);
          if(!fd) continue;
          // v2.5.3: iframe 使用与主页面完全一致的 __cfxMappingHandler（函数引用共享），
          // 确保事件去抖、selector 生成、验证逻辑完全一致
          var win = frames[i].contentWindow;
          if(win && !win.__cfxMappingInjected){
            win.__cfxMappingInjected = true;
            win.__CFX_MAPPING_ACTIVE = window.__CFX_MAPPING_ACTIVE;
            win.__cfxMappingLastEvent = 0;
            win.__cfxMappingHandler = window.__cfxMappingHandler;
            win.__cfxUniqueSelector = window.__cfxUniqueSelector;
            win.__cfxReport = window.__cfxReport;
            win.__cfxCssEscape = window.__cfxCssEscape;
            win.__cfxGetClasses = window.__cfxGetClasses;
            fd.removeEventListener('click', win.__cfxMappingHandler, true);
            fd.removeEventListener('touchend', win.__cfxMappingHandler, true);
            fd.addEventListener('click', win.__cfxMappingHandler, true);
            fd.addEventListener('touchend', win.__cfxMappingHandler, true);
          }
        }catch(e){}
      }
    }catch(e){}
  };
  // v2.5.3: 监听 iframe 动态插入（SPA 懒加载 iframe），自动注入标注能力
  if(!window.__cfxIframeObserver){
    window.__cfxIframeObserver = new MutationObserver(function(mutations){
      var hasNewIframe = false;
      for(var mi=0; mi<mutations.length; mi++){
        var nodes = mutations[mi].addedNodes;
        for(var ni=0; nodes && ni<nodes.length; ni++){
          if(nodes[ni].tagName === 'IFRAME'){ hasNewIframe = true; break; }
          if(nodes[ni].querySelectorAll && nodes[ni].querySelectorAll('iframe').length > 0){ hasNewIframe = true; break; }
        }
        if(hasNewIframe) break;
      }
      if(hasNewIframe){
        setTimeout(window.__cfxInjectIframes, 300);
      }
    });
    window.__cfxIframeObserver.observe(document.body || document.documentElement, {childList:true, subtree:true});
  }
  window.__cfxInjectIframes();
  setTimeout(window.__cfxInjectIframes, 1500);
  setTimeout(window.__cfxInjectIframes, 3500);
})();
"""

/**
 * 一级导航全屏网页执行台：
 * - 主区域 WebView
 * - 顶部可折叠状态条：期号/口径/方向金额/执行器/选择器
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebBetScreen(
    mainViewModel: MainViewModel = viewModel(),
    executorViewModel: ExecutorViewModel = viewModel(),
    onBack: () -> Unit = {},
    onWorkbench: () -> Unit = {},
    onBet: () -> Unit = {}
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    val executorStatus by executorViewModel.executorStatus.collectAsState()
    val currentTask by executorViewModel.currentTask.collectAsState()
    val executorLogs by executorViewModel.executorLogs.collectAsState()
    val lastFailedTask by executorViewModel.lastFailedTask.collectAsState()
    val ticket by ExecutionTicketStore.ticket.collectAsState()
    val pendingQueueSize by com.caifenxi.app.domain.execution.PendingBetQueue.pendingSize.collectAsState()
    val pendingQueueMsg by com.caifenxi.app.domain.execution.PendingBetQueue.lastMessage.collectAsState()
    val autoRunning by executorViewModel.autoRunning.collectAsState()
    val executionMode by executorViewModel.executionMode.collectAsState()

    var urlInput by rememberSaveable { mutableStateOf("https://www.baidu.com") }
    var pageTitle by rememberSaveable { mutableStateOf("未加载") }
    var pageStatus by rememberSaveable { mutableStateOf("待命") }
    var panelExpanded by rememberSaveable { mutableStateOf(true) }
    var dryRun by rememberSaveable { mutableStateOf(true) }
    var testDx by rememberSaveable { mutableStateOf("") }
    var testDs by rememberSaveable { mutableStateOf("") }
    var testAmount by rememberSaveable { mutableStateOf("") }
    var pageLoading by remember { mutableStateOf(false) }
    var pageProgress by remember { mutableStateOf(0) }
    var selectorInfo by remember {
        mutableStateOf(LocalSelectorLoader.current(context))
    }

    // URL 历史/书签
    var urlHistory by remember { mutableStateOf(UrlHistoryStore.getHistory(context)) }
    var showHistory by remember { mutableStateOf(false) }
    val currentEntry = urlHistory.find { it.url == urlInput }
    val isBookmarked = currentEntry?.bookmarked == true

    val lotteryName = mainViewModel.currentLottery.value.name
    val targetIssue = mainViewModel.nextIssueText.value
    val webReady = WebViewExecutor.isAvailable
    val mode = ExecutorManager.getMode()
    // v2.6.3fix: API投注状态
    var apiBetEnabled by rememberSaveable { mutableStateOf(false) }
    var apiBetReady by rememberSaveable { mutableStateOf(false) }
    var showApiNotification by rememberSaveable { mutableStateOf(false) }

    // v2.6.3fix: 检查API映射表就绪状态（定期轮询）
    LaunchedEffect(urlInput) {
        while (true) {
            val domain = try { android.net.Uri.parse(urlInput).host ?: "" } catch (_: Exception) { "" }
            if (domain.isNotBlank()) {
                val profile = ApiMappingStore.getProfile(context, domain)
                val readyTypes = profile.readyPlayTypes()
                apiBetReady = readyTypes.isNotEmpty()
                val activeTypes = listOf("dx", "ds", "combo", "number")
                val allReady = activeTypes.all { profile.mappingFor(it) != null }
                if (allReady && !apiBetEnabled && !showApiNotification) {
                    showApiNotification = true
                }
            }
            delay(5000)
        }
    }

    // v2.6.3fix: 网络日志定期读取
    LaunchedEffect(webViewRef) {
        while (true) {
            webViewRef?.evaluateJavascript("window.__cfxExportNetworkLogs ? window.__cfxExportNetworkLogs() : '[]'") { result ->
                if (result != null && result != "null" && result.length > 5) {
                    NetworkLogStore.appendFromJson(context, result)
                    val domain = try { android.net.Uri.parse(urlInput).host ?: "" } catch (_: Exception) { "" }
                    if (domain.isNotBlank()) {
                        ApiMappingStore.rebuildFromLogs(context, domain)
                    }
                }
            }
            delay(5000)
        }
    }

    // 点击识别配置 Profile：从持久化加载；编辑后经 ClickMatchConfig.save 保存并清缓存
    var clickProfile by remember {
        mutableStateOf(ClickMatchConfig.load(context))
    }

    // 标注模式状态 —— 大小单双标注（原有，不改动）
    var mappingMode by rememberSaveable { mutableStateOf(false) }
    var mappingStep by rememberSaveable { mutableStateOf(0) }
    var mappingPaused by rememberSaveable { mutableStateOf(false) }
    var mappingFeedback by remember { mutableStateOf("") }
    val mappingSteps = listOf("大按钮", "小按钮", "单按钮", "双按钮", "金额输入框", "确认按钮", "余额元素")
    val mappingBridge = remember { MappingBridge() }
    val mappingHandler = remember { Handler(Looper.getMainLooper()) }

    // 组合标注模式状态 —— 独立一套标注动作（新创，与大小单双互不干扰）
    var comboMappingMode by rememberSaveable { mutableStateOf(false) }
    var comboMappingStep by rememberSaveable { mutableStateOf(0) }
    var comboMappingPaused by rememberSaveable { mutableStateOf(false) }
    var comboMappingFeedback by remember { mutableStateOf("") }
    val comboMappingSteps = listOf("组合-大单按钮", "组合-大双按钮", "组合-小单按钮", "组合-小双按钮")

    // 直选单式标注模式状态 —— 独立于大小单双和组合
    var directSelectMappingMode by rememberSaveable { mutableStateOf(false) }
    var directSelectMappingStep by rememberSaveable { mutableStateOf(0) }
    var directSelectMappingPaused by rememberSaveable { mutableStateOf(false) }
    var directSelectMappingFeedback by remember { mutableStateOf("") }
    val directSelectMappingSteps = listOf("号码输入框", "粘贴按钮", "金额输入框", "确认按钮")

    // 数字玩法标注模式状态 —— 独立于大小单双、组合、直选单式（1-10 数字 → 金额框 → 确定下单）
    var numberMappingMode by rememberSaveable { mutableStateOf(false) }
    var numberMappingStep by rememberSaveable { mutableStateOf(0) }
    var numberMappingPaused by rememberSaveable { mutableStateOf(false) }
    var numberMappingFeedback by remember { mutableStateOf("") }
    var numberRange by rememberSaveable { mutableStateOf(clickProfile.numberRange) }
    val numberMappingSteps by remember(numberRange) {
        mutableStateOf(
            if (numberRange == "1-10") {
                (1..10).map { "数字$it" } + listOf("金额输入框", "确定下单按钮")
            } else {
                (0..9).map { "数字$it" } + listOf("金额输入框", "确定下单按钮")
            }
        )
    }

    // 数字玩法下单参数（与标注独立，标注完成后可手动选择数字下单）
    var selectedNumMask by rememberSaveable { mutableStateOf(0) } // bit i-1 = 数字i
    var numberBetAmount by rememberSaveable { mutableStateOf("") }
    var numberExecFeedback by remember { mutableStateOf("") }
    var numberExecuting by rememberSaveable { mutableStateOf(false) }

    // 标注模式：mappingMode 或 WebView 就绪时重新注册 bridge + 注入 JS（SPA 导航后也需重注）
    LaunchedEffect(mappingMode, webViewRef) {
        if (mappingMode) {
            webViewRef?.let { wv ->
                try { wv.removeJavascriptInterface("CfxMappingBridge") } catch (_: Exception) {}
                wv.addJavascriptInterface(mappingBridge, "CfxMappingBridge")
                wv.evaluateJavascript(MAPPING_JS, null)
                wv.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = ${if (mappingPaused) "false" else "true"};", null)
                wv.evaluateJavascript("if(window.__cfxInjectIframes) window.__cfxInjectIframes();", null)
            }
        } else {
            webViewRef?.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = false;", null)
            try { webViewRef?.removeJavascriptInterface("CfxMappingBridge") } catch (_: Exception) {}
        }
    }

    // 暂停/继续标注：切换 mapping flag 但不注销 bridge
    LaunchedEffect(mappingPaused) {
        if (mappingMode) {
            webViewRef?.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = ${if (mappingPaused) "false" else "true"};", null)
        }
    }

    // 组合标注模式：独立注册 bridge + 注入 JS（与大小单双共用同一 bridge，互斥激活）
    LaunchedEffect(comboMappingMode, webViewRef) {
        if (comboMappingMode) {
            webViewRef?.let { wv ->
                try { wv.removeJavascriptInterface("CfxMappingBridge") } catch (_: Exception) {}
                wv.addJavascriptInterface(mappingBridge, "CfxMappingBridge")
                wv.evaluateJavascript(MAPPING_JS, null)
                wv.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = ${if (comboMappingPaused) "false" else "true"};", null)
                wv.evaluateJavascript("if(window.__cfxInjectIframes) window.__cfxInjectIframes();", null)
            }
        } else {
            // 仅当大小单双标注也未激活时才关闭
            if (!mappingMode) {
                webViewRef?.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = false;", null)
                try { webViewRef?.removeJavascriptInterface("CfxMappingBridge") } catch (_: Exception) {}
            }
        }
    }

    // 组合标注暂停/继续
    LaunchedEffect(comboMappingPaused) {
        if (comboMappingMode) {
            webViewRef?.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = ${if (comboMappingPaused) "false" else "true"};", null)
        }
    }

    // 直选单式标注模式：独立注册 bridge + 注入 JS
    LaunchedEffect(directSelectMappingMode, webViewRef) {
        if (directSelectMappingMode) {
            webViewRef?.let { wv ->
                try { wv.removeJavascriptInterface("CfxMappingBridge") } catch (_: Exception) {}
                wv.addJavascriptInterface(mappingBridge, "CfxMappingBridge")
                wv.evaluateJavascript(MAPPING_JS, null)
                wv.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = ${if (directSelectMappingPaused) "false" else "true"};", null)
                wv.evaluateJavascript("if(window.__cfxInjectIframes) window.__cfxInjectIframes();", null)
            }
        } else {
            if (!mappingMode && !comboMappingMode) {
                webViewRef?.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = false;", null)
                try { webViewRef?.removeJavascriptInterface("CfxMappingBridge") } catch (_: Exception) {}
            }
        }
    }

    // 直选单式标注暂停/继续
    LaunchedEffect(directSelectMappingPaused) {
        if (directSelectMappingMode) {
            webViewRef?.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = ${if (directSelectMappingPaused) "false" else "true"};", null)
        }
    }

    // 数字玩法标注模式：独立注册 bridge + 注入 JS（与三套现有标注互斥激活）
    LaunchedEffect(numberMappingMode, webViewRef) {
        if (numberMappingMode) {
            webViewRef?.let { wv ->
                try { wv.removeJavascriptInterface("CfxMappingBridge") } catch (_: Exception) {}
                wv.addJavascriptInterface(mappingBridge, "CfxMappingBridge")
                wv.evaluateJavascript(MAPPING_JS, null)
                wv.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = ${if (numberMappingPaused) "false" else "true"};", null)
                wv.evaluateJavascript("if(window.__cfxInjectIframes) window.__cfxInjectIframes();", null)
            }
        } else {
            if (!mappingMode && !comboMappingMode && !directSelectMappingMode) {
                webViewRef?.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = false;", null)
                try { webViewRef?.removeJavascriptInterface("CfxMappingBridge") } catch (_: Exception) {}
            }
        }
    }

    // 数字玩法标注暂停/继续
    LaunchedEffect(numberMappingPaused) {
        if (numberMappingMode) {
            webViewRef?.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = ${if (numberMappingPaused) "false" else "true"};", null)
        }
    }

    // 保存 selector 到 ClickMatchConfig，推进到下一步（大小单双专用，原有逻辑不改动）
    // 必须在 pickedCallback 之前声明，否则 lambda 内前向引用未初始化的 val 会编译失败
    val saveMappingStep: (Int, String, String) -> Unit = { step, selector, text ->
        val newProfile = when (step) {
            0 -> clickProfile.copy(selectorBig = selector)
            1 -> clickProfile.copy(selectorSmall = selector)
            2 -> clickProfile.copy(selectorOdd = selector)
            3 -> clickProfile.copy(selectorEven = selector)
            4 -> clickProfile.copy(selectorAmount = selector)
            5 -> clickProfile.copy(selectorConfirm = selector)
            6 -> clickProfile.copy(selectorBalance = selector)
            else -> clickProfile
        }
        ClickMatchConfig.save(context, newProfile)
        ClickMatchConfig.clearCache()
        clickProfile = newProfile
        mappingFeedback = "已保存: ${mappingSteps[step]} → $selector (${text.take(15)})"
        mappingStep = step + 1
        if (mappingStep >= mappingSteps.size) {
            mappingMode = false
            webViewRef?.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = false;", null)
            webViewRef?.removeJavascriptInterface("CfxMappingBridge")
        }
    }

    // 保存组合玩法 selector（独立于大小单双，新创标注动作）
    val saveComboMappingStep: (Int, String, String) -> Unit = { step, selector, text ->
        val newProfile = when (step) {
            0 -> clickProfile.copy(selectorComboDaDan = selector)
            1 -> clickProfile.copy(selectorComboDaShuang = selector)
            2 -> clickProfile.copy(selectorComboXiaoDan = selector)
            3 -> clickProfile.copy(selectorComboXiaoShuang = selector)
            else -> clickProfile
        }
        ClickMatchConfig.save(context, newProfile)
        ClickMatchConfig.clearCache()
        clickProfile = newProfile
        comboMappingFeedback = "已保存: ${comboMappingSteps[step]} → $selector (${text.take(15)})"
        comboMappingStep = step + 1
        if (comboMappingStep >= comboMappingSteps.size) {
            comboMappingMode = false
            webViewRef?.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = false;", null)
            webViewRef?.removeJavascriptInterface("CfxMappingBridge")
        }
    }

    // 保存直选单式 selector（独立于大小单双和组合）
    val saveDirectSelectMappingStep: (Int, String, String) -> Unit = { step, selector, text ->
        val newProfile = when (step) {
            0 -> clickProfile.copy(selectorDirectSelectInput = selector)
            1 -> clickProfile.copy(selectorDirectSelectPaste = selector)
            2 -> clickProfile.copy(selectorDirectSelectAmount = selector)  // 复用金额标注
            3 -> clickProfile.copy(selectorDirectSelectConfirm = selector)  // 复用确认标注
            else -> clickProfile
        }
        ClickMatchConfig.save(context, newProfile)
        ClickMatchConfig.clearCache()
        clickProfile = newProfile
        directSelectMappingFeedback = "已保存: ${directSelectMappingSteps[step]} → $selector (${text.take(15)})"
        directSelectMappingStep = step + 1
        if (directSelectMappingStep >= directSelectMappingSteps.size) {
            directSelectMappingMode = false
            webViewRef?.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = false;", null)
            webViewRef?.removeJavascriptInterface("CfxMappingBridge")
        }
    }

    // 保存数字玩法 selector（独立于大小单双、组合、直选单式）
    val saveNumberMappingStep: (Int, String, String) -> Unit = { step, selector, text ->
        val newProfile = when (step) {
            0 -> clickProfile.copy(selectorNum1 = selector)
            1 -> clickProfile.copy(selectorNum2 = selector)
            2 -> clickProfile.copy(selectorNum3 = selector)
            3 -> clickProfile.copy(selectorNum4 = selector)
            4 -> clickProfile.copy(selectorNum5 = selector)
            5 -> clickProfile.copy(selectorNum6 = selector)
            6 -> clickProfile.copy(selectorNum7 = selector)
            7 -> clickProfile.copy(selectorNum8 = selector)
            8 -> clickProfile.copy(selectorNum9 = selector)
            9 -> clickProfile.copy(selectorNum10 = selector)
            10 -> clickProfile.copy(selectorNumAmount = selector)  // 金额输入框
            11 -> clickProfile.copy(selectorNumConfirm = selector) // 确定下单按钮
            else -> clickProfile
        }
        ClickMatchConfig.save(context, newProfile)
        ClickMatchConfig.clearCache()
        clickProfile = newProfile
        numberMappingFeedback = "已保存: ${numberMappingSteps[step]} → $selector (${text.take(15)})"
        numberMappingStep = step + 1
        if (numberMappingStep >= numberMappingSteps.size) {
            numberMappingMode = false
            webViewRef?.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = false;", null)
            webViewRef?.removeJavascriptInterface("CfxMappingBridge")
        }
    }

    // 数字玩法下单执行：点击选中数字 → 填金额 → 点确定（自包含 JS，不依赖 cfx_inject.js 注入时序）
    fun jsStr(s: String): String = "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\""
    fun placeNumberOrder() {
        val wv = webViewRef
        val amount = numberBetAmount.trim()
        val amountOk = amount.toDoubleOrNull()?.let { it > 0.0 && it.isFinite() } == true
        if (wv == null) {
            numberExecFeedback = "WebView 未连接，请等待页面加载完成"
            return
        }
        val isZeroBased = clickProfile.numberRange != "1-10"
        val numRange = if (isZeroBased) (0..9) else (1..10)
        val selected = numRange.filter { 
            val bitIdx = if (isZeroBased) it else it - 1
            (selectedNumMask and (1 shl bitIdx)) != 0 
        }
        if (selected.isEmpty()) {
            numberExecFeedback = "请先选择至少一个数字（${if (isZeroBased) "0-9" else "1-10"}）"
            return
        }
        if (!amountOk) {
            numberExecFeedback = "请输入有效金额"
            return
        }
        val missingLabels = buildList {
            numRange.forEach { n -> if (clickProfile.selectorForNum(n).isBlank()) add("数字$n") }
            if (clickProfile.selectorNumAmount.isBlank()) add("金额框")
            if (clickProfile.selectorNumConfirm.isBlank()) add("确定按钮")
        }
        if (missingLabels.isNotEmpty() && !clickProfile.allowPartialNumberMapping) {
            numberExecFeedback = "数字标注未完成，缺少：${missingLabels.joinToString("、")}"
            return
        }
        val numSelList = numRange.joinToString(",") { n -> jsStr(clickProfile.selectorForNum(n)) }
        val dry = dryRun
        numberExecuting = true
        numberExecFeedback = "正在${if (dry) "识别" else "执行"}..."
        val js = """
            (function(){
                try{
                    var dry = ${dry};
                    var numbers = [${selected.joinToString(",")}];
                    var numSels = [$numSelList];
                    var numberOffset = ${if (isZeroBased) "0" else "1"};
                    var amountSel = ${jsStr(clickProfile.selectorNumAmount)};
                    var confirmSel = ${jsStr(clickProfile.selectorNumConfirm)};
                    var amount = ${jsStr(amount)};
                    function qry(sel){
                        if(!sel) return null;
                        try{
                            var l = document.querySelectorAll(sel);
                            if(l.length >= 1) return l[0];
                        }catch(e){}
                        try{
                            var fs = document.querySelectorAll('iframe');
                            for(var fi=0; fi<fs.length; fi++){
                                try{
                                    var fd = fs[fi].contentDocument || fs[fi].contentWindow.document;
                                    if(!fd) continue;
                                    var l2 = fd.querySelectorAll(sel);
                                    if(l2.length >= 1) return l2[0];
                                }catch(e){}
                            }
                        }catch(e){}
                        return null;
                    }
                    function resolveInput(el){
                        if(!el) return null;
                        try{
                            var t = (el.tagName||'').toLowerCase();
                            if(t==='input'||t==='textarea') return el;
                            var inner = el.querySelector && el.querySelector('input,textarea,[contenteditable="true"]');
                            if(inner) return inner;
                            return null;
                        }catch(e){ return null; }
                    }
                    function setVal(el,v){
                        if(!el) return '';
                        try{ el.focus(); }catch(e){}
                        var tag = el.tagName ? el.tagName.toLowerCase() : '';
                        var ce = el.getAttribute && el.getAttribute('contenteditable')==='true';
                        if(ce || tag==='div' || tag==='span' || tag==='p'){
                            try{
                                el.innerText = String(v); el.textContent = String(v);
                                el.dispatchEvent(new InputEvent('input',{bubbles:true,data:String(v),inputType:'insertText'}));
                                el.dispatchEvent(new Event('change',{bubbles:true}));
                                return String(el.innerText||el.textContent||'');
                            }catch(e){}
                        }
                        var proto = tag==='textarea' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
                        try{
                            var desc = Object.getOwnPropertyDescriptor(proto,'value');
                            if(desc && desc.set) desc.set.call(el, v); else el.value = v;
                        }catch(e){ el.value = v; }
                        try{ var tk = el._valueTracker; if(tk && typeof tk.setValue==='function') tk.setValue(''); }catch(e){}
                        try{ el.dispatchEvent(new InputEvent('input',{bubbles:true,data:v,inputType:'insertText'})); }catch(e){ el.dispatchEvent(new Event('input',{bubbles:true})); }
                        try{ el.dispatchEvent(new Event('change',{bubbles:true})); }catch(e){}
                        try{ el.dispatchEvent(new KeyboardEvent('keyup',{bubbles:true,key:'0'})); }catch(e){}
                        return String(el.value||'');
                    }
                    function clickEl(el){
                        if(!el) return false;
                        try{ el.scrollIntoView({block:'center',inline:'center'}); }catch(e){}
                        try{ if(typeof el.click==='function'){ el.click(); try{ el.focus && el.focus(); }catch(e){} return true; } }catch(e){}
                        return false;
                    }
                    var missing = [];
                    var doneNums = 0;
                    for(var i=0;i<numbers.length;i++){
                        var n = numbers[i];
                        var idx = n - numberOffset;
                        var sel = (idx >= 0 && idx < numSels.length) ? numSels[idx] : '';
                        if(!sel){ missing.push('数字'+n); continue; }
                        var el = qry(sel);
                        if(!el){ missing.push('数字'+n); continue; }
                        if(dry){ doneNums++; }
                        else if(clickEl(el)){ doneNums++; }
                        else { missing.push('数字'+n); }
                    }
                    var amtEl = resolveInput(qry(amountSel));
                    if(!amtEl) missing.push('金额框');
                    var amtActual = '';
                    if(!dry && amtEl) amtActual = setVal(amtEl, amount);
                    var confEl = qry(confirmSel);
                    if(!confEl) missing.push('确定按钮');
                    var confDone = false;
                    if(!dry && confEl) confDone = clickEl(confEl);
                    var msg = (dry?'识别':'执行') + '完成：数字 ' + doneNums + '/' + numbers.length + ' 命中' + (amtEl?' · 金额框已定位':'') + (confEl?' · 确定按钮已定位':'');
                    if(!dry){
                        msg += (amtActual!==''?' · 实际写入 ' + amtActual:'') + (confDone?' · 已点确定':'');
                    }
                    if(missing.length>0) msg = (dry?'识别':'执行') + '部分缺失：' + missing.join(',') + '。' + msg;
                    try{ window.__CFX_LAST_NUM_BET = msg; }catch(e){}
                    return 'NUMBET|' + (missing.length===0?'OK':'PART') + '|' + msg;
                }catch(err){
                    return 'NUMBET|ERR|' + String(err && err.message || err);
                }
            })()
        """.trimIndent()
        wv.evaluateJavascript(js) { res ->
            val decoded = try {
                val txt = res ?: ""
                if (txt.startsWith("\"")) org.json.JSONTokener(txt).nextValue().toString() else txt
            } catch (_: Exception) { "" }
            numberExecuting = false
            if (decoded.startsWith("NUMBET|")) {
                val parts = decoded.split("|", limit = 3)
                val status = parts.getOrNull(1) ?: "ERR"
                val msg = parts.getOrNull(2) ?: decoded
                numberExecFeedback = when (status) {
                    "OK" -> if (dry) "✅ $msg" else "✅ 下单执行完毕：$msg"
                    "PART" -> "⚠ $msg"
                    else -> "❌ 注入失败：$msg"
                }
            } else {
                numberExecFeedback = "❌ 未收到页面响应（$decoded）"
            }
        }
    }

    // bridge 回调：根据当前激活的标注模式（大小单双 vs 组合）分别路由保存
    // v2.5.3: 保存前通过 WebView JS 验证 selector 唯一性，不唯一则提示重新标注
    mappingBridge.pickedCallback = { selector, text ->
        mappingHandler.post {
            // 判断当前处于哪个标注模式
            val isNumber = numberMappingMode && !numberMappingPaused
            val isDirectSelect = directSelectMappingMode && !directSelectMappingPaused
            val isCombo = comboMappingMode && !comboMappingPaused
            val isDx = mappingMode && !mappingPaused
            if (!isNumber && !isDirectSelect && !isCombo && !isDx) return@post

            val step = when {
                isNumber -> numberMappingStep
                isDirectSelect -> directSelectMappingStep
                isCombo -> comboMappingStep
                else -> mappingStep
            }
            val steps = when {
                isNumber -> numberMappingSteps
                isDirectSelect -> directSelectMappingSteps
                isCombo -> comboMappingSteps
                else -> mappingSteps
            }
            if (step >= steps.size) return@post

            // 验证 selector 唯一性
            val verifiedSelector = selector
            val wv = webViewRef
            if (wv != null) {
                val verifyJs = """
                    (function(){
                        try{
                            var matched = document.querySelectorAll('$selector');
                            if(matched.length === 1) return {ok:true, count:1};
                            return {ok:false, count:matched.length};
                        }catch(e){ return {ok:false, error:e.message}; }
                    })()
                """.trimIndent()
                wv.evaluateJavascript(verifyJs) { result ->
                    val count = result?.let {
                        val m = it.replace("\"", "").replace("'", "")
                        val c = Regex("count:(\\d+)").find(m)?.groupValues?.get(1)?.toIntOrNull() ?: 0
                        c
                    } ?: 0
                    if (count != 1) {
                        val fb = "⚠ selector 不唯一（匹配 $count 个元素），请重新点击"
                        when {
                            isNumber -> numberMappingFeedback = fb
                            isDirectSelect -> directSelectMappingFeedback = fb
                            isCombo -> comboMappingFeedback = fb
                            else -> mappingFeedback = fb
                        }
                        RuntimeLog.warn("Mapping", "selector 不唯一: $selector 匹配 $count 个")
                        return@evaluateJavascript
                    }
                    // 唯一 → 保存到对应流程
                    when {
                        isNumber -> saveNumberMappingStep(step, verifiedSelector, text)
                        isDirectSelect -> saveDirectSelectMappingStep(step, verifiedSelector, text)
                        isCombo -> saveComboMappingStep(step, verifiedSelector, text)
                        else -> saveMappingStep(step, verifiedSelector, text)
                    }
                }
            } else {
                when {
                    isNumber -> saveNumberMappingStep(step, verifiedSelector, text)
                    isDirectSelect -> saveDirectSelectMappingStep(step, verifiedSelector, text)
                    isCombo -> saveComboMappingStep(step, verifiedSelector, text)
                    else -> saveMappingStep(step, verifiedSelector, text)
                }
            }
        }
    }

    BackHandler {
        val wv = webViewRef
        if (wv?.canGoBack() == true) wv.goBack() else onBack()
    }

    // 离开页面时保存 WebView 状态，防止返回时白屏
    DisposableEffect(Unit) {
        onDispose {
            try {
                webViewRef?.saveState(Bundle().also { WebViewStateHolder.savedState = it })
            } catch (_: Exception) {}
        }
    }

    // 页面回到前台时：同步 SafetyGate 状态 + 刷新 WebView 心跳 + flush 待执行队列
    DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                executorViewModel.syncSafetyGateState()
                webViewRef?.let { wv ->
                    WebViewExecutor.heartbeat()
                    WebViewExecutor.reattach(wv)
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // —— 持久连接：周期 keep-alive 探活（15s 一次）+ 渲染层失效自愈（黑屏自动恢复） ——
    LaunchedEffect(Unit) {
        // 页面回到前台时同步 SafetyGate 状态，防止离开/返回后 Switch 与真实状态脱节
        executorViewModel.syncSafetyGateState()
        while (true) {
            delay(15_000)
            try {
                val wv = webViewRef
                if (wv != null) {
                    WebViewExecutor.keepAlive(wv)
                    if (!WebViewExecutor.isAvailable) {
                        WebViewExecutor.reattach(wv)
                    } else {
                        // P1: 条件门控——页面加载中或非稳定态时跳过 probeRender/selfHeal
                        // 仅在真正「已加载」后探测；SPA「脚本渲染中」阶段禁止 selfHeal，否则会反复白屏
                        if (!pageLoading && pageStatus == "已加载") {
                            WebViewExecutor.probeRender(wv)
                            delay(3_000)
                            if (WebViewExecutor.isRenderStalled()) {
                                WebViewExecutor.selfHeal(wv)
                            }
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    val panelScrollState = rememberScrollState()
    val screenWidth = LocalConfiguration.current.screenWidthDp.dp
    // 浮动面板拖拽位置
    var panelOffsetX by remember { mutableStateOf(0f) }
    var panelOffsetY by remember { mutableStateOf(0f) }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface)) {
        // —— 全屏 WebView（底层）——
        AndroidView(
            factory = { ctx ->
                WebView(ctx).apply {
                    // v2.6.3fix: SPA 投注站白屏常见原因——脏缓存 + 未开多窗口 + Cookie 未放行
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.databaseEnabled = true
                    settings.useWideViewPort = true
                    settings.loadWithOverviewMode = true
                    // 不用 LOAD_CACHE_ELSE_NETWORK：坏缓存会导致永远停在「加载中请稍候」
                    settings.cacheMode = WebSettings.LOAD_DEFAULT
                    // 贴近系统 Chrome 移动 UA，减少站点对 WebView 的差异化空壳
                    settings.userAgentString =
                        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36"
                    settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                    settings.javaScriptCanOpenWindowsAutomatically = true
                    settings.setSupportMultipleWindows(true)
                    settings.mediaPlaybackRequiresUserGesture = false
                    settings.loadsImagesAutomatically = true
                    settings.blockNetworkImage = false
                    settings.textZoom = 100
                    settings.setSupportZoom(true)
                    settings.builtInZoomControls = true
                    settings.displayZoomControls = false
                    settings.allowFileAccess = true
                    settings.setGeolocationEnabled(false)
                    // v2.6.3fix-cors: 注册 CORS 代理 Bridge（SPA 跨域 API 请求被拦截时由 Android 层转发）
                    val corsProxyBridge = CorsProxyBridge(okhttp3.OkHttpClient.Builder().build())
                    addJavascriptInterface(corsProxyBridge, "CfxCorsProxy")
                    // v2.6.3fix-diag: 开启 WebView 远程调试（Chrome DevTools 可抓 console/network）
                    android.webkit.WebView.setWebContentsDebuggingEnabled(true)
                    try {
                        val cm = CookieManager.getInstance()
                        cm.setAcceptCookie(true)
                        cm.setAcceptThirdPartyCookies(this, true)
                    } catch (_: Exception) {
                    }
                    // 硬件加速层，避免部分机型 SPA 合成白屏
                    setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null)
                    webViewClient = object : WebViewClient() {
                        // v2.6.3fix: SPA探测跨reload防死循环计数器
                        private var spaReloadCount = 0
                        private var spaCheckAttempt = 0

                        // v2.6.3fix: 重定向循环检测
                        private var redirectCount = 0
                        private var lastRedirectUrl = ""
                        private var lastRedirectTime = 0L

                        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                            val url = request?.url?.toString() ?: return false
                            // 重定向循环检测：3秒内同一URL重定向3次则拦截
                            val now = System.currentTimeMillis()
                            if (url == lastRedirectUrl && now - lastRedirectTime < 3000) {
                                redirectCount++
                                if (redirectCount >= 3) {
                                    RuntimeLog.warn("WebView", "检测到重定向循环，拦截 url=$url")
                                    pageStatus = "检测到页面循环跳转，已阻止"
                                    return true
                                }
                            } else {
                                redirectCount = 1
                                lastRedirectUrl = url
                                lastRedirectTime = now
                            }
                            // 所有导航留在 WebView 内
                            return false
                        }
                        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                            pageStatus = "加载中..."
                            pageLoading = true
                        }
                        override fun onPageFinished(view: WebView?, url: String?) {
                            // SPA 站点 HTML 先完成、JS 后挂载；先标「渲染中」，避免过早自愈 reload 打断加载
                            pageStatus = "页面壳已加载，脚本渲染中…"
                            pageLoading = false
                            pageProgress = 100

                            // v2.6.3fix: SPA 就绪探测——多轮检测骨架屏/白屏，自动刷新兜底
                            // 跨 reload 防死循环：累计 reload > 5 次则停止
                            spaCheckAttempt = 0
                            fun checkSpaReady() {
                                if (view == null) return
                                spaCheckAttempt++
                                if (spaCheckAttempt > 5) {
                                    spaReloadCount++
                                    if (spaReloadCount > 5) {
                                        pageStatus = "页面多次重载后仍无法就绪，请检查站点地址或网络"
                                        RuntimeLog.warn("WebView", "SPA探测5次reload仍无法就绪，停止自动reload url=$url")
                                        return
                                    }
                                    pageStatus = "页面加载超时，自动刷新(第${spaReloadCount}/5次)…"
                                    RuntimeLog.warn("WebView", "SPA探测5次仍未就绪，自动reload(${spaReloadCount}/5) url=$url")
                                    view.reload()
                                    return
                                }
                                try {
                                    view.evaluateJavascript(
                                        """(function(){try{var body=document.body;if(!body){return '{"status":"no-body","textLen":0,"visibleCount":0,"readyState":"'+(document.readyState||'')+'","jsErr":""}';}var text=(body.innerText||'').trim();var textLen=text.length;var interactives=document.querySelectorAll('button,a,input,[role="button"],[onclick],select,textarea');var visibleCount=0;for(var i=0;i<interactives.length;i++){var el=interactives[i];var rect=el.getBoundingClientRect();if(rect.width>0&&rect.height>0&&rect.top<window.innerHeight)visibleCount++;}var hasLoading=text.indexOf('加载中')>=0||text.indexOf('loading')>=0||text.indexOf('请稍候')>=0||text.indexOf('努力加载')>=0||text.indexOf('载入中')>=0;var isSkeleton=(textLen<300&&visibleCount<3)||(hasLoading&&textLen<1500)||(textLen<800&&visibleCount<2);var status;if(textLen<20&&visibleCount===0)status='blank';else if(textLen>200||visibleCount>=1)status='ok';else status='wait';return '{"status":"'+status+'","textLen":'+textLen+',"visibleCount":'+visibleCount+',"readyState":"'+(document.readyState||'')+'","jsErr":""}';}catch(e){return '{"status":"err","textLen":0,"visibleCount":0,"readyState":"'+(document.readyState||'')+'","jsErr":"'+e.message+'"}';}})()"""
                                    ) { res ->
                                        // v2.6.3fix-diag2: 解析JS返回的结构化JSON诊断数据
                                        val raw = (res ?: "").trim().trim('"').trim(''')
                                        val diag = try {
                                            if (raw.startsWith("{")) {
                                                val parts = kotlinx.serialization.json.Json.decodeFromString<JsonObject>(raw)
                                                val status = parts["status"]?.jsonPrimitive?.content ?: "?"
                                                val tl = parts["textLen"]?.jsonPrimitive?.content ?: "?"
                                                val vc = parts["visibleCount"]?.jsonPrimitive?.content ?: "?"
                                                val rs = parts["readyState"]?.jsonPrimitive?.content ?: "?"
                                                val err = parts["jsErr"]?.jsonPrimitive?.content ?: ""
                                                RuntimeLog.info("WebView", "SPA探测(${spaCheckAttempt}/5) status=$status textLen=$tl visibleCount=$vc readyState=$rs jsErr=$err [raw=$raw]")
                                                status to "textLen=$tl visibleCount=$vc readyState=$rs jsErr=$err"
                                            } else {
                                                RuntimeLog.info("WebView", "SPA探测(${spaCheckAttempt}/5) raw=$raw [非JSON]")
                                                raw to "raw=$raw"
                                            }
                                        } catch (e: Exception) {
                                            RuntimeLog.info("WebView", "SPA探测(${spaCheckAttempt}/5) raw=$raw [解析异常: ${e.message}]")
                                            raw to "raw=$raw parseErr=${e.message}"
                                        }
                                        val s = diag.first
                                        when (s) {
                                            "ok", "complete", "interactive" -> {
                                                pageStatus = "已加载"
                                                // 加载成功恢复默认缓存
                                                try { view.settings.cacheMode = WebSettings.LOAD_DEFAULT } catch (_: Exception) {}
                                                // 加载成功，重置reload计数器
                                                spaReloadCount = 0
                                            }
                                            "blank" -> {
                                                // 空壳HTML(302到SPA壳页)先到、JS后渲染：立即reload会形成刷新死循环
                                                // 前2次等待重试(6s)，仅第3次仍空白才刷新兜底
                                                pageStatus = "页面渲染中(${spaCheckAttempt}/5)…"
                                                if (spaCheckAttempt < 5) {
                                                    view.postDelayed({ checkSpaReady() }, 6000)
                                                } else {
                                                    pageStatus = "页面渲染超时，自动刷新(第${spaReloadCount}/5次)…"
                                                    RuntimeLog.warn("WebView", "SPA探测5次blank，自动reload(${spaReloadCount}/5) url=$url")
                                                    view.reload()
                                                }
                                            }
                                            "wait", "no-body", "err" -> {
                                                pageStatus = "站点脚本加载中(${spaCheckAttempt}/5)…"
                                                if (spaCheckAttempt < 5) {
                                                    view.postDelayed({ checkSpaReady() }, 6000)
                                                } else {
                                                    pageStatus = "页面加载超时，自动刷新(第${spaReloadCount}/5次)…"
                                                    RuntimeLog.warn("WebView", "SPA探测5次wait，自动reload(${spaReloadCount}/5) url=$url")
                                                    view.reload()
                                                }
                                            }
                                            else -> {
                                                pageStatus = "已加载"
                                            }
                                        }
                                    }
                                } catch (_: Exception) {
                                    pageStatus = "已加载"
                                }
                            }
                            // 8秒后首次探测（空壳SPA的webpack chunk下载+渲染需更长时间）
                            view?.postDelayed({ checkSpaReady() }, 8000)

                            pageTitle = view?.title ?: url ?: ""
                            if (url != null) {
                                urlInput = url
                                UrlHistoryStore.recordVisit(ctx, url, pageTitle)
                                urlHistory = UrlHistoryStore.getHistory(ctx)
                            }
                            WebViewExecutor.reattach(this@apply)
                            WebViewExecutor.heartbeat()
                            // 任一标注模式激活时：重注册 bridge + 重注入 JS（SPA 导航后也需重注）
                            val anyMappingActive = mappingMode || comboMappingMode || directSelectMappingMode || numberMappingMode
                            if (anyMappingActive) {
                                view?.addJavascriptInterface(mappingBridge, "CfxMappingBridge")
                                view?.evaluateJavascript(MAPPING_JS, null)
                                view?.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = ${anyMappingActive};", null)
                                view?.evaluateJavascript("if(window.__cfxInjectIframes) window.__cfxInjectIframes();", null)
                            }
                            // v2.6.3fix-cors: 注入跨域代理，劫持 fetch/XMLHttpRequest → 经 Android CfxCorsProxy 转发
                            view?.evaluateJavascript(CORS_PROXY_JS, null)
                        }
                        override fun onReceivedSslError(view: WebView?, handler: android.webkit.SslErrorHandler?, error: android.net.http.SslError?) {
                            // 测试/生产环境允许自签名/过期证书：SPA 站点常走 CDN 边缘，旧 WebView 可能因证书链不完整被拒绝
                            RuntimeLog.warn("WebView", "SSL error=${error?.primaryError} proceed anyway")
                            handler?.proceed()
                        }
                        override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                            val u = request?.url?.toString().orEmpty()
                            if (request?.isForMainFrame == true) {
                                pageLoading = false
                                pageStatus = "加载失败(${error?.errorCode})，请检查站点地址或网络后刷新"
                            } else if (u.contains(".js") || u.contains("client-mobile") || u.contains("chunk") || u.contains("vendor")) {
                                // SPA 主脚本失败会永久停在「加载中请稍候」——自动刷新恢复
                                RuntimeLog.warn("WebView", "脚本资源失败 code=${error?.errorCode} url=$u")
                                pageStatus = "站点脚本加载失败，正在自动恢复…"
                                view?.postDelayed({
                                    if (pageStatus.contains("脚本加载失败")) {
                                        RuntimeLog.info("WebView", "脚本失败后自动reload url=$url")
                                        view.reload()
                                    }
                                }, 2000)
                            }
                        }
                        override fun onRenderProcessGone(view: WebView?, detail: android.webkit.RenderProcessGoneDetail?): Boolean {
                            // 渲染进程被杀（内存不足等）→ 提示并自动重载，避免白屏/黑屏
                            RuntimeLog.warn("WebView", "渲染进程异常终止：${detail?.didCrash()}")
                            pageStatus = "页面渲染异常，自动恢复中..."
                            mappingHandler.postDelayed({
                                try {
                                    // 重建绑定 + 重载当前页：光 reload 有时不恢复显示，须重挂执行器
                                    view?.let { wv ->
                                        WebViewExecutor.reattach(wv)
                                        wv.reload()
                                        WebViewExecutor.heartbeat()
                                    }
                                } catch (_: Exception) {
                                }
                            }, 600)
                            return true
                        }
                        override fun onReceivedHttpError(view: WebView?, request: WebResourceRequest?, errorResponse: android.webkit.WebResourceResponse?) {
                            val u = request?.url?.toString().orEmpty()
                            val code = errorResponse?.statusCode ?: 0
                            if (request?.isForMainFrame == true) {
                                pageStatus = "页面响应异常($code)，请刷新"
                            } else if (code >= 400 && (u.contains(".js") || u.contains("client-mobile") || u.contains("chunk") || u.contains("vendor"))) {
                                RuntimeLog.warn("WebView", "脚本 HTTP $code url=$u")
                                pageStatus = "站点脚本 HTTP $code，正在自动恢复…"
                                view?.postDelayed({
                                    if (pageStatus.contains("HTTP") && pageStatus.contains("恢复")) {
                                        RuntimeLog.info("WebView", "脚本HTTP错误后自动reload url=$url")
                                        view.reload()
                                    }
                                }, 2000)
                            }
                        }
                    }
                    webChromeClient = object : WebChromeClient() {
                        override fun onConsoleMessage(consoleMessage: android.webkit.ConsoleMessage?): Boolean {
                            val msg = consoleMessage?.message().orEmpty()
                            if (consoleMessage?.messageLevel() == android.webkit.ConsoleMessage.MessageLevel.ERROR) {
                                RuntimeLog.warn("WebViewJS", msg.take(200))
                                if (msg.contains("ChunkLoadError", true) || msg.contains("Loading chunk", true) ||
                                    msg.contains("Failed to fetch", true) || msg.contains("net::ERR", true)
                                ) {
                                    pageStatus = "站点脚本异常，请强刷或换网络"
                                }
                            }
                            return super.onConsoleMessage(consoleMessage)
                        }
                        override fun onReceivedTitle(view: WebView?, title: String?) {
                            if (!title.isNullOrBlank()) pageTitle = title
                        }
                        override fun onProgressChanged(view: WebView?, newProgress: Int) {
                            pageProgress = newProgress
                            // 加载期间持续保活
                            if (newProgress in 1..99) {
                                WebViewExecutor.heartbeat()
                            }
                        }
                        // —— 接管 JS 弹窗：自动确认 + 提示，防止系统对话框阻塞渲染导致黑屏 ——
                        private fun reviveAfterPopup(view: WebView?) {
                            // 弹窗应答后，JS 线程可能挂起未恢复渲染提交；
                            // 用一次无意义 JS 执行"唤醒"Chromium 主线程，触发渲染管线继续提交帧
                            try { view?.evaluateJavascript("(function(){ return document.visibilityState; })()", null) } catch (_: Exception) {}
                            // 延迟复检：若页面 still 挂死（visibilityState 异常或渲染未恢复），自动 reload
                            mappingHandler.postDelayed({
                                try {
                                    view?.evaluateJavascript(
                                        "(function(){ try{ return document.visibilityState + '|' + (document.body?.scrollHeight||0); }catch(e){ return 'dead'; } })()"
                                    ) { result ->
                                        val dead = result == null || result == "null" || (result?.contains("dead") ?: false)
                                        if (dead) {
                                            RuntimeLog.warn("WebView", "弹窗后复检页面挂死，触发自动恢复")
                                            view?.let { wv ->
                                                WebViewExecutor.reattach(wv)
                                                wv.reload()
                                                WebViewExecutor.heartbeat()
                                            }
                                        }
                                    }
                                } catch (_: Exception) {}
                            }, 1_200)
                        }

                        override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                            try {
                                mappingHandler.post {
                                    try {
                                        android.widget.Toast.makeText(ctx, message ?: "网页提示", android.widget.Toast.LENGTH_SHORT).show()
                                    } catch (_: Exception) {}
                                }
                                result?.confirm()
                                reviveAfterPopup(view)
                            } catch (e: Exception) {
                                RuntimeLog.warn("WebView", "onJsAlert 异常: ${e.message}")
                                result?.confirm()
                                reviveAfterPopup(view)
                            }
                            return true
                        }
                        override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                            try {
                                mappingHandler.post {
                                    try {
                                        android.widget.Toast.makeText(ctx, "网页确认: ${message ?: ""}", android.widget.Toast.LENGTH_SHORT).show()
                                    } catch (_: Exception) {}
                                }
                                result?.confirm() // 自动化流程自动点确定，避免卡死
                                reviveAfterPopup(view)
                            } catch (e: Exception) {
                                RuntimeLog.warn("WebView", "onJsConfirm 异常: ${e.message}")
                                result?.confirm()
                                reviveAfterPopup(view)
                            }
                            return true
                        }
                        override fun onJsPrompt(view: WebView?, url: String?, message: String?, defaultValue: String?, result: android.webkit.JsPromptResult?): Boolean {
                            try {
                                result?.cancel()
                                reviveAfterPopup(view)
                            } catch (e: Exception) {
                                RuntimeLog.warn("WebView", "onJsPrompt 异常: ${e.message}")
                                result?.cancel()
                                reviveAfterPopup(view)
                            }
                            return true
                        }
                        override fun onJsBeforeUnload(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                            // 下注成功站点常触发 beforeunload（离开确认），自动确认放行，避免页面挂起黑屏
                            try {
                                result?.confirm()
                                reviveAfterPopup(view)
                            } catch (e: Exception) {
                                RuntimeLog.warn("WebView", "onJsBeforeUnload 异常: ${e.message}")
                                result?.confirm()
                                reviveAfterPopup(view)
                            }
                            return true
                        }
                        override fun onCreateWindow(
                            view: WebView?,
                            isDialog: Boolean,
                            isUserGesture: Boolean,
                            resultMsg: Message?
                        ): Boolean {
                            // target=_blank 新窗口：直接在当前 WebView 打开，保持页面完整
                            val newWebView = WebView(view?.context ?: ctx)
                            newWebView.settings.javaScriptEnabled = true
                            // 新窗口同样接管 JS 弹窗，避免站点在新窗内弹 alert/confirm 时卡死黑屏
                            newWebView.webChromeClient = object : WebChromeClient() {
                                override fun onJsAlert(v: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                                    try { result?.confirm() } catch (_: Exception) { result?.confirm() }
                                    return true
                                }
                                override fun onJsConfirm(v: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                                    try { result?.confirm() } catch (_: Exception) { result?.confirm() }
                                    return true
                                }
                                override fun onJsPrompt(v: WebView?, url: String?, message: String?, defaultValue: String?, result: android.webkit.JsPromptResult?): Boolean {
                                    try { result?.cancel() } catch (_: Exception) { result?.cancel() }
                                    return true
                                }
                                override fun onJsBeforeUnload(v: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                                    try { result?.confirm() } catch (_: Exception) { result?.confirm() }
                                    return true
                                }
                            }
                            newWebView.webViewClient = object : WebViewClient() {
                                override fun shouldOverrideUrlLoading(v: WebView?, request: WebResourceRequest?): Boolean {
                                    view?.loadUrl(request?.url?.toString() ?: "")
                                    v?.destroy()
                                    return true
                                }
                            }
                            resultMsg?.obj = newWebView
                            resultMsg?.sendToTarget()
                            return true
                        }
                    }
                    WebViewExecutor.reattach(this)
                    WebViewExecutor.watchRendering(this)
                    webViewRef = this
                    val saved = WebViewStateHolder.savedState
                    if (saved != null && !saved.isEmpty()) {
                        restoreState(saved)
                        WebViewStateHolder.savedState = null
                    } else {
                        val currentUrl = urlInput.ifBlank { "https://www.baidu.com" }
                        // 投注站 SPA 首次进入禁用缓存，降低「加载中请稍候」卡死概率
                        if (!currentUrl.contains("baidu.com")) {
                            try {
                                settings.cacheMode = WebSettings.LOAD_NO_CACHE
                                clearCache(true)
                            } catch (_: Exception) {
                            }
                        }
                        loadUrl(currentUrl)
                        // v2.6.3fix: 延长无缓存时间到30秒，SPA初始化慢的站点需要更长时间
                        postDelayed({
                            try { settings.cacheMode = WebSettings.LOAD_DEFAULT } catch (_: Exception) {}
                        }, 30000)
                    }
                }
            },
            modifier = Modifier.fillMaxSize(),
            update = { wv ->
                webViewRef = wv
                if (!WebViewExecutor.isAvailable) {
                    WebViewExecutor.reattach(wv)
                }
                WebViewExecutor.watchRendering(wv)
            }
        )

        // 加载进度条
        if (pageLoading) {
            LinearProgressIndicator(
                progress = { pageProgress / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
            )
        }

        // —— 浮动控制面板（叠加在 WebView 上层）——
        Surface(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(horizontal = 4.dp, vertical = 2.dp)
                .offset { IntOffset(0, panelOffsetY.roundToInt()) }
                .pointerInput(Unit) {
                    detectDragGestures { _, drag ->
                        panelOffsetY = (panelOffsetY + drag.y).coerceAtLeast(0f)
                    }
                }
                .widthIn(max = screenWidth - 8.dp),
            shape = RoundedCornerShape(12.dp),
            tonalElevation = 4.dp,
            shadowElevation = 8.dp
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .verticalScroll(panelScrollState)
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Icon(Icons.Filled.DragHandle, contentDescription = "拖拽",
                        modifier = Modifier.size(18.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "返回")
                    }
                    Column(Modifier.weight(1f)) {
                        Text("网页执行台", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        if (!panelExpanded) {
                            Text(
                                buildString {
                                    append(lotteryName)
                                    append(" · ")
                                    append(if (webReady) "已连接" else "未连接")
                                    append(" · 跟随挂机")
                                    if (pendingQueueSize > 0) append(" · 排队$pendingQueueSize")
                                    val tk = ticket
                                    if (tk.cmdId.isNotBlank()) {
                                        append(" · ")
                                        append(tk.status)
                                        if (!tk.dx.isNullOrBlank() || !tk.ds.isNullOrBlank()) {
                                            append(" ")
                                            append(listOfNotNull(tk.dx, tk.ds).joinToString("/"))
                                        }
                                        if (!tk.amountText.isNullOrBlank()) append(" ¥${tk.amountText}")
                                    }
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1
                            )
                        }
                    }
                    if (panelExpanded) {
                        TextButton(onClick = onWorkbench) { Text("工作台", fontSize = 12.sp) }
                        TextButton(onClick = onBet) { Text("挂机", fontSize = 12.sp) }
                    }
                    IconButton(onClick = { panelExpanded = !panelExpanded }) {
                        Icon(
                            if (panelExpanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                            contentDescription = "展开状态"
                        )
                    }
                }

                if (panelExpanded) {
                // 一行关键状态
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatusChip(
                        "按钮映射",
                        if (clickProfile.hasMapping()) "已配置" else "未配置",
                        if (clickProfile.hasMapping()) Color(0xFF2E7D32) else Color(0xFFC62828)
                    )
                    StatusChip(
                        "WebView",
                        if (webReady) "已连接" else "未连接",
                        if (webReady) Color(0xFF2E7D32) else Color(0xFFC62828)
                    )
                    StatusChip(
                        "执行",
                        when (executorStatus) {
                            ExecutorViewModel.ExecutorStatus.IDLE -> "待机"
                            ExecutorViewModel.ExecutorStatus.RUNNING -> "执行中"
                            ExecutorViewModel.ExecutorStatus.COMPLETED -> "完成"
                            else -> executorStatus.name
                        },
                        MaterialTheme.colorScheme.primary
                    )
                    StatusChip(
                        "模式",
                        if (dryRun) "仅识别" else "实盘",
                        if (dryRun) Color(0xFFF9A825) else Color(0xFFC62828)
                    )
                }

                    Spacer(Modifier.height(8.dp))
                    // v2.6.3fix: API投注Toggle
                    if (apiBetReady) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("API 投注", modifier = Modifier.weight(1f), fontSize = 12.sp)
                            Switch(
                                checked = apiBetEnabled,
                                onCheckedChange = { enabled ->
                                    apiBetEnabled = enabled
                                    ExecutorManager.setMode(if (enabled) "api_inject" else "webview")
                                }
                            )
                        }
                        if (apiBetEnabled) {
                            Text("当前模式：API 直接请求", fontSize = 11.sp, color = Color(0xFF00C853))
                        } else {
                            Text("当前模式：页面模拟点击", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    // v2.6.3fix: API投注通知弹窗
                    if (showApiNotification) {
                        AlertDialog(
                            onDismissRequest = { showApiNotification = false },
                            title = { Text("API 投注已就绪") },
                            text = {
                                Text("该站点已采集足够数据，可以开启 API 投注模式。API 投注直接发送网络请求，比页面点击更快更稳。")
                            },
                            confirmButton = {
                                TextButton(onClick = {
                                    apiBetEnabled = true
                                    ExecutorManager.setMode("api_inject")
                                    showApiNotification = false
                                }) {
                                    Text("开启 API 投注")
                                }
                            },
                            dismissButton = {
                                TextButton(onClick = { showApiNotification = false }) {
                                    Text("稍后")
                                }
                            }
                        )
                    }
                    // 选择器
                    val selText = when (val s = selectorInfo) {
                        is LocalSelectorLoader.State.Ok ->
                            "选择器: ${if (s.source == LocalSelectorLoader.Source.EXTERNAL) "外部" else "内置"} v${s.version}"
                        is LocalSelectorLoader.State.ExternalBroken ->
                            "选择器损坏: ${s.message.take(40)}"
                    }
                    Text(selText, style = MaterialTheme.typography.bodySmall,
                        color = if (selectorInfo is LocalSelectorLoader.State.ExternalBroken)
                            MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.onSurfaceVariant)

                    // 工单条：跟随挂机 · 计划 / 口径 / 方向 / 金额 / 回执
                    val tk = ticket
                    LaunchedEffect(tk.cmdId) {
                        if (tk.cmdId.isNotBlank()) {
                            tk.dx?.takeIf { it in setOf("大", "小") }?.let { testDx = it }
                            tk.ds?.takeIf { it in setOf("单", "双") }?.let { testDs = it }
                            tk.amountText?.takeIf { it.isNotBlank() }?.let { testAmount = it }
                        }
                    }
                    Text(
                        "跟随挂机（方向与金额仅来自挂机页派发，本页不重算计划）",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    if (tk.cmdId.isNotBlank()) {
                        Text(
                            "工单 ${ExecutionTicketStore.stageLabel(tk.stage, tk.leg)} · ${tk.planLabel.ifBlank { "挂机" }}",
                            fontWeight = FontWeight.SemiBold,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            "期号 ${tk.issue} · 方向 ${tk.dx ?: "-"}/${tk.ds ?: "-"} · 金额 ${tk.amountText ?: "-"}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            "状态 ${tk.status} · ${tk.message}",
                            style = MaterialTheme.typography.bodySmall,
                            color = when (tk.status) {
                                "SUCCESS" -> Color(0xFF2E7D32)
                                "FAILED", "EXPIRED" -> Color(0xFFC62828)
                                "PENDING", "QUEUED", "RUNNING" -> Color(0xFFEF6C00)
                                else -> MaterialTheme.colorScheme.onSurfaceVariant
                            }
                        )
                        if (tk.balanceBefore.isNotBlank() || tk.balanceAfter.isNotBlank()) {
                            Text(
                                "余额 ${tk.balanceBefore.ifBlank { "-" }} → ${tk.balanceAfter.ifBlank { "-" }}",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    } else {
                        Text(
                            "工单: 等待挂机派发（挂机页选计划并开启 → 每期自动带方向+金额到本页执行）",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (pendingQueueSize > 0) {
                        Text(
                            "排队补点 $pendingQueueSize 条 · ${pendingQueueMsg.ifBlank { "连接后自动执行" }}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFEF6C00)
                        )
                    }

                    // URL + 书签 + 历史
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = urlInput,
                            onValueChange = { urlInput = it },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            label = { Text("投注站地址") },
                            textStyle = LocalTextStyle.current.copy(fontSize = 13.sp)
                        )
                        IconButton(onClick = {
                            val newState = UrlHistoryStore.toggleBookmark(context, urlInput)
                            urlHistory = UrlHistoryStore.getHistory(context)
                            val msg = if (newState) "已收藏" else "已取消收藏"
                            android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_SHORT).show()
                        }) {
                            Icon(
                                if (isBookmarked) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                                contentDescription = "书签",
                                tint = if (isBookmarked) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = { showHistory = !showHistory }) {
                            Icon(Icons.Filled.History, contentDescription = "历史",
                                tint = if (showHistory) MaterialTheme.colorScheme.primary
                                       else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = {
                            try {
                                // 强刷：清磁盘缓存，避免 SPA 空壳+坏脚本永久白屏
                                webViewRef?.settings?.cacheMode = WebSettings.LOAD_NO_CACHE
                                webViewRef?.clearCache(true)
                                webViewRef?.clearHistory()
                            } catch (_: Exception) {
                            }
                            pageStatus = "强刷加载中…"
                            pageLoading = true
                            webViewRef?.loadUrl(urlInput)
                            // 恢复默认缓存策略（下次普通导航仍可用缓存）
                            webViewRef?.postDelayed({
                                try { webViewRef?.settings?.cacheMode = WebSettings.LOAD_DEFAULT } catch (_: Exception) {}
                            }, 8000)
                        }) {
                            Icon(Icons.Filled.Refresh, contentDescription = "加载")
                        }
                    }

                    // URL 历史下拉
                    if (showHistory) {
                        val items = urlHistory
                        if (items.isEmpty()) {
                            Text("暂无历史记录", fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(vertical = 4.dp))
                        } else {
                            Column(
                                Modifier
                                    .fillMaxWidth()
                                    .height(120.dp)
                                    .verticalScroll(rememberScrollState())
                            ) {
                                items.forEach { entry ->
                                    Row(
                                        Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 2.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        TextButton(
                                            onClick = {
                                                urlInput = entry.url
                                                webViewRef?.loadUrl(entry.url)
                                                showHistory = false
                                            },
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text(
                                                "${if (entry.bookmarked) "★ " else ""}${entry.url}",
                                                fontSize = 11.sp,
                                                maxLines = 1
                                            )
                                        }
                                        Text(
                                            entry.title.ifBlank { "" }.take(20),
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                TextButton(onClick = {
                                    UrlHistoryStore.clearHistory(context)
                                    urlHistory = UrlHistoryStore.getHistory(context)
                                }) { Text("清空历史", fontSize = 11.sp, color = Color(0xFFC62828)) }
                            }
                        }
                    }

                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = dryRun,
                            onClick = { dryRun = true },
                            label = { Text("仅识别") }
                        )
                        FilterChip(
                            selected = !dryRun,
                            onClick = { dryRun = false },
                            label = { Text("实盘点击") }
                        )
                        TextButton(onClick = {
                            selectorInfo = LocalSelectorLoader.reload(context)
                        }) { Text("重载选择器") }
                        TextButton(onClick = {
                            LocalSelectorLoader.exportTemplate(context)
                            selectorInfo = LocalSelectorLoader.reload(context)
                        }) { Text("导出模板") }
                    }

                    // 按钮标注模式
                    Surface(
                        shape = MaterialTheme.shapes.small,
                        color = if (mappingMode) Color(0xFFE8F5E9) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                    ) {
                        Column(Modifier.fillMaxWidth().padding(8.dp)) {
                            Row(
                                Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "按钮标注",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp,
                                    modifier = Modifier.weight(1f)
                                )
                                if (mappingMode) {
                                    Text(
                                        "第 ${mappingStep + 1}/${mappingSteps.size} 步${if (mappingPaused) " (暂停)" else ""}",
                                        fontSize = 11.sp,
                                        color = if (mappingPaused) Color(0xFFF9A825) else Color(0xFF2E7D32)
                                    )
                                } else {
                                    Button(
                                        onClick = {
                                            mappingStep = 0
                                            mappingFeedback = ""
                                            mappingMode = true
                                            // 互斥：关闭直选单式标注、组合标注和数字标注
                                            directSelectMappingMode = false
                                            comboMappingMode = false
                                            numberMappingMode = false
                                        },
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                                    ) { Text("开始标注", fontSize = 12.sp) }
                                }
                            }

                            if (mappingMode) {
                                Text(
                                    if (mappingPaused) "标注已暂停 · 可在网页上自由操作" else "请在页面上点击：${mappingSteps[mappingStep]}",
                                    fontSize = 12.sp,
                                    color = if (mappingPaused) Color(0xFFF9A825) else Color(0xFF2E7D32),
                                    fontWeight = FontWeight.Medium
                                )
                                Row(
                                    Modifier.fillMaxWidth().padding(top = 4.dp),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    TextButton(
                                        onClick = { mappingPaused = !mappingPaused },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                                    ) {
                                        Text(
                                            if (mappingPaused) "继续标注" else "暂停(操作网页)",
                                            fontSize = 11.sp,
                                            color = if (mappingPaused) Color(0xFF2E7D32) else Color(0xFFF9A825)
                                        )
                                    }
                                    if (mappingStep > 0) {
                                        TextButton(
                                            onClick = {
                                                mappingStep = mappingStep - 1
                                                mappingFeedback = "返回上一步：${mappingSteps[mappingStep]}"
                                            },
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                                        ) { Text("上一步", fontSize = 11.sp) }
                                    }
                                    TextButton(
                                        onClick = {
                                            mappingFeedback = "已跳过：${mappingSteps[mappingStep]}"
                                            mappingStep = mappingStep + 1
                                            if (mappingStep >= mappingSteps.size) {
                                                mappingMode = false
                                                webViewRef?.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = false;", null)
                                                webViewRef?.removeJavascriptInterface("CfxMappingBridge")
                                            }
                                        },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                                    ) { Text("跳过", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                                    TextButton(
                                        onClick = {
                                            mappingMode = false
                                            mappingPaused = false
                                            webViewRef?.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = false;", null)
                                            webViewRef?.removeJavascriptInterface("CfxMappingBridge")
                                        },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                                    ) { Text("退出", color = Color(0xFFC62828), fontSize = 11.sp) }
                                }
                            }

                            // 允许部分标注执行开关
                            Row(
                                Modifier.fillMaxWidth().padding(top = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Switch(
                                    checked = clickProfile.allowPartialMapping,
                                    onCheckedChange = { on ->
                                        val updated = clickProfile.copy(allowPartialMapping = on)
                                        ClickMatchConfig.save(context, updated)
                                        ClickMatchConfig.clearCache()
                                        clickProfile = updated
                                    },
                                    modifier = Modifier.scale(0.8f)
                                )
                                Spacer(Modifier.width(4.dp))
                                Text(
                                    "允许未标全即可执行",
                                    fontSize = 11.sp,
                                    color = if (clickProfile.allowPartialMapping) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            if (mappingFeedback.isNotBlank()) {
                                Text(
                                    mappingFeedback,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            // 显示已标注的 selector 摘要
                            if (clickProfile.hasMapping()) {
                                val mapped = remember(clickProfile) {
                                    buildList {
                                        if (clickProfile.selectorBig.isNotBlank()) add("大")
                                        if (clickProfile.selectorSmall.isNotBlank()) add("小")
                                        if (clickProfile.selectorOdd.isNotBlank()) add("单")
                                        if (clickProfile.selectorEven.isNotBlank()) add("双")
                                        if (clickProfile.selectorAmount.isNotBlank()) add("金额")
                                        if (clickProfile.selectorConfirm.isNotBlank()) add("确认")
                                        if (clickProfile.selectorBalance.isNotBlank()) add("余额")
                                        if (clickProfile.selectorComboDaDan.isNotBlank()) add("大单")
                                        if (clickProfile.selectorComboDaShuang.isNotBlank()) add("大双")
                                        if (clickProfile.selectorComboXiaoDan.isNotBlank()) add("小单")
                                        if (clickProfile.selectorComboXiaoShuang.isNotBlank()) add("小双")
                                        if (clickProfile.selectorDirectSelectInput.isNotBlank()) add("直选-号码框")
                                        if (clickProfile.selectorDirectSelectPaste.isNotBlank()) add("直选-粘贴")
                                        if (clickProfile.selectorDirectSelectConfirm.isNotBlank()) add("直选-确认")
                                    }
                                }
                                Text(
                                    "已标注: ${mapped.joinToString(" · ")}",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                TextButton(
                                    onClick = {
                                        val cleared = clickProfile.copy(
                                            selectorBig = "", selectorSmall = "",
                                            selectorOdd = "", selectorEven = "",
                                            selectorAmount = "", selectorConfirm = "",
                                            selectorBalance = "",
                                            selectorComboDaDan = "", selectorComboDaShuang = "",
                                            selectorComboXiaoDan = "", selectorComboXiaoShuang = "",
                                            selectorDirectSelectInput = "",
                                            selectorDirectSelectPaste = "",
                                            selectorDirectSelectConfirm = ""
                                        )
                                        ClickMatchConfig.save(context, cleared)
                                        ClickMatchConfig.clearCache()
                                        clickProfile = cleared
                                        mappingFeedback = "已清空所有标注"
                                    },
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
                                ) { Text("清空标注", fontSize = 10.sp, color = Color(0xFFC62828)) }
                            }

                            // ---- 组合玩法标注（独立于大小单双，新创标注动作） ----
                            HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
                            Surface(
                                shape = MaterialTheme.shapes.small,
                                color = if (comboMappingMode) Color(0xFFE8F5E9) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                            ) {
                                Column(Modifier.fillMaxWidth().padding(8.dp)) {
                                    Row(
                                        Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            "组合玩法标注",
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 13.sp,
                                            modifier = Modifier.weight(1f)
                                        )
                                        if (comboMappingMode) {
                                            Text(
                                                "第 ${comboMappingStep + 1}/${comboMappingSteps.size} 步${if (comboMappingPaused) " (暂停)" else ""}",
                                                fontSize = 11.sp,
                                                color = if (comboMappingPaused) Color(0xFFF9A825) else Color(0xFF2E7D32)
                                            )
                                        } else {
                                            Button(
                                                onClick = {
                                                    comboMappingStep = 0
                                                    comboMappingFeedback = ""
                                                    comboMappingMode = true
                                                    // 互斥：关闭大小单双标注和直选单式标注、数字标注
                                                    mappingMode = false
                                                    directSelectMappingMode = false
                                                    numberMappingMode = false
                                                },
                                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                                            ) { Text("开始标注", fontSize = 12.sp) }
                                        }
                                    }

                                    if (comboMappingMode) {
                                        Text(
                                            if (comboMappingPaused) "标注已暂停 · 可在网页上自由操作" else "请在页面上点击：${comboMappingSteps[comboMappingStep]}",
                                            fontSize = 12.sp,
                                            color = if (comboMappingPaused) Color(0xFFF9A825) else Color(0xFF2E7D32),
                                            fontWeight = FontWeight.Medium
                                        )
                                        Row(
                                            Modifier.fillMaxWidth().padding(top = 4.dp),
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            TextButton(
                                                onClick = { comboMappingPaused = !comboMappingPaused },
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                                            ) {
                                                Text(
                                                    if (comboMappingPaused) "继续标注" else "暂停(操作网页)",
                                                    fontSize = 11.sp,
                                                    color = if (comboMappingPaused) Color(0xFF2E7D32) else Color(0xFFF9A825)
                                                )
                                            }
                                            if (comboMappingStep > 0) {
                                                TextButton(
                                                    onClick = {
                                                        comboMappingStep = comboMappingStep - 1
                                                        comboMappingFeedback = "返回上一步：${comboMappingSteps[comboMappingStep]}"
                                                    },
                                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                                                ) { Text("上一步", fontSize = 11.sp) }
                                            }
                                            TextButton(
                                                onClick = {
                                                    comboMappingFeedback = "已跳过：${comboMappingSteps[comboMappingStep]}"
                                                    comboMappingStep = comboMappingStep + 1
                                                    if (comboMappingStep >= comboMappingSteps.size) {
                                                        comboMappingMode = false
                                                        webViewRef?.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = false;", null)
                                                        webViewRef?.removeJavascriptInterface("CfxMappingBridge")
                                                    }
                                                },
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                                            ) { Text("跳过", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                                            TextButton(
                                                onClick = {
                                                    comboMappingMode = false
                                                    comboMappingPaused = false
                                                    webViewRef?.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = false;", null)
                                                    webViewRef?.removeJavascriptInterface("CfxMappingBridge")
                                                },
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                                            ) { Text("退出", color = Color(0xFFC62828), fontSize = 11.sp) }
                                        }
                                    }

                                    // 允许部分组合标注执行开关
                                    Row(
                                        Modifier.fillMaxWidth().padding(top = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Switch(
                                            checked = clickProfile.allowPartialComboMapping,
                                            onCheckedChange = { on ->
                                                val updated = clickProfile.copy(allowPartialComboMapping = on)
                                                ClickMatchConfig.save(context, updated)
                                                ClickMatchConfig.clearCache()
                                                clickProfile = updated
                                            },
                                            modifier = Modifier.scale(0.8f)
                                        )
                                        Spacer(Modifier.width(4.dp))
                                        Text(
                                            "允许未标全即可执行",
                                            fontSize = 11.sp,
                                            color = if (clickProfile.allowPartialComboMapping) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    if (comboMappingFeedback.isNotBlank()) {
                                        Text(
                                            comboMappingFeedback,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    // 显示已标注的组合 selector 摘要
                                    if (clickProfile.hasComboMapping()) {
                                        val comboMapped = remember(clickProfile) {
                                            buildList {
                                                if (clickProfile.selectorComboDaDan.isNotBlank()) add("大单")
                                                if (clickProfile.selectorComboDaShuang.isNotBlank()) add("大双")
                                                if (clickProfile.selectorComboXiaoDan.isNotBlank()) add("小单")
                                                if (clickProfile.selectorComboXiaoShuang.isNotBlank()) add("小双")
                                            }
                                        }
                                        Text(
                                            "已标注: ${comboMapped.joinToString(" · ")}",
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        TextButton(
                                            onClick = {
                                                val cleared = clickProfile.copy(
                                                    selectorComboDaDan = "", selectorComboDaShuang = "",
                                                    selectorComboXiaoDan = "", selectorComboXiaoShuang = ""
                                                )
                                                ClickMatchConfig.save(context, cleared)
                                                ClickMatchConfig.clearCache()
                                                clickProfile = cleared
                                                comboMappingFeedback = "已清空组合标注"
                                            },
                                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
                                        ) { Text("清空组合标注", fontSize = 10.sp, color = Color(0xFFC62828)) }
                                    }
                                }
                            }

                            // ---- 直选单式标注（独立于大小单双和组合） ----
                            HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
                            Surface(
                                shape = MaterialTheme.shapes.small,
                                color = if (directSelectMappingMode) Color(0xFFFFF3E0) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                            ) {
                                Column(Modifier.fillMaxWidth().padding(8.dp)) {
                                    Row(
                                        Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            "直选单式标注",
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 13.sp,
                                            modifier = Modifier.weight(1f)
                                        )
                                        if (directSelectMappingMode) {
                                            Text(
                                                "第 ${directSelectMappingStep + 1}/${directSelectMappingSteps.size} 步${if (directSelectMappingPaused) " (暂停)" else ""}",
                                                fontSize = 11.sp,
                                                color = if (directSelectMappingPaused) Color(0xFFF9A825) else Color(0xFF2E7D32)
                                            )
                                        } else {
                                            Button(
                                                onClick = {
                                                    directSelectMappingStep = 0
                                                    directSelectMappingFeedback = ""
                                                    directSelectMappingMode = true
                                                    // 互斥：关闭大小单双标注和组合标注、数字标注
                                                    mappingMode = false
                                                    comboMappingMode = false
                                                    numberMappingMode = false
                                                },
                                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                                            ) { Text("开始标注", fontSize = 12.sp) }
                                        }
                                    }

                                    if (directSelectMappingMode) {
                                        Text(
                                            if (directSelectMappingPaused) "标注已暂停 · 可在网页上自由操作" else "请在页面上点击：${directSelectMappingSteps[directSelectMappingStep]}",
                                            fontSize = 12.sp,
                                            color = if (directSelectMappingPaused) Color(0xFFF9A825) else Color(0xFF2E7D32),
                                            fontWeight = FontWeight.Medium
                                        )
                                        Row(
                                            Modifier.fillMaxWidth().padding(top = 4.dp),
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            TextButton(
                                                onClick = { directSelectMappingPaused = !directSelectMappingPaused },
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                                            ) {
                                                Text(
                                                    if (directSelectMappingPaused) "继续标注" else "暂停(操作网页)",
                                                    fontSize = 11.sp,
                                                    color = if (directSelectMappingPaused) Color(0xFF2E7D32) else Color(0xFFF9A825)
                                                )
                                            }
                                            if (directSelectMappingStep > 0) {
                                                TextButton(
                                                    onClick = {
                                                        directSelectMappingStep = directSelectMappingStep - 1
                                                        directSelectMappingFeedback = "返回上一步：${directSelectMappingSteps[directSelectMappingStep]}"
                                                    },
                                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                                                ) { Text("上一步", fontSize = 11.sp) }
                                            }
                                            TextButton(
                                                onClick = {
                                                    directSelectMappingFeedback = "已跳过：${directSelectMappingSteps[directSelectMappingStep]}"
                                                    directSelectMappingStep = directSelectMappingStep + 1
                                                    if (directSelectMappingStep >= directSelectMappingSteps.size) {
                                                        directSelectMappingMode = false
                                                        webViewRef?.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = false;", null)
                                                        webViewRef?.removeJavascriptInterface("CfxMappingBridge")
                                                    }
                                                },
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                                            ) { Text("跳过", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                                            TextButton(
                                                onClick = {
                                                    directSelectMappingMode = false
                                                    directSelectMappingPaused = false
                                                    webViewRef?.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = false;", null)
                                                    webViewRef?.removeJavascriptInterface("CfxMappingBridge")
                                                },
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                                            ) { Text("退出", color = Color(0xFFC62828), fontSize = 11.sp) }
                                        }
                                    }

                                    if (directSelectMappingFeedback.isNotBlank()) {
                                        Text(
                                            directSelectMappingFeedback,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    // 显示已标注的直选单式 selector 摘要
                                    if (clickProfile.hasDirectSelectMapping()) {
                                        val dsMapped = remember(clickProfile) {
                                            buildList {
                                                if (clickProfile.selectorDirectSelectInput.isNotBlank()) add("号码框")
                                                if (clickProfile.selectorDirectSelectPaste.isNotBlank()) add("粘贴")
                                                if (clickProfile.selectorDirectSelectAmount.isNotBlank()) add("金额")
                                                if (clickProfile.selectorDirectSelectConfirm.isNotBlank()) add("确认")
                                            }
                                        }
                                        Text(
                                            "已标注: ${dsMapped.joinToString(" · ")}",
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        TextButton(
                                            onClick = {
                                                val cleared = clickProfile.copy(
                                                    selectorDirectSelectInput = "",
                                                    selectorDirectSelectPaste = "",
                                                    selectorDirectSelectAmount = "",
                                                    selectorDirectSelectConfirm = ""
                                                )
                                                ClickMatchConfig.save(context, cleared)
                                                ClickMatchConfig.clearCache()
                                                clickProfile = cleared
                                                directSelectMappingFeedback = "已清空直选单式标注"
                                            },
                                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
                                        ) { Text("清空直选标注", fontSize = 10.sp, color = Color(0xFFC62828)) }
                                    }
                                }
                            }

                            // ---- 数字玩法标注 + 手动下单（独立于大小单双、组合、直选单式） ----
                            HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
                            Surface(
                                shape = MaterialTheme.shapes.small,
                                color = if (numberMappingMode) Color(0xFFE3F2FD) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                            ) {
                                Column(Modifier.fillMaxWidth().padding(8.dp)) {
                                    Row(
                                        Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            "数字玩法标注",
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 13.sp,
                                            modifier = Modifier.weight(1f)
                                        )
                                        if (numberMappingMode) {
                                            Text(
                                                "第 ${numberMappingStep + 1}/${numberMappingSteps.size} 步${if (numberMappingPaused) " (暂停)" else ""}",
                                                fontSize = 11.sp,
                                                color = if (numberMappingPaused) Color(0xFFF9A825) else Color(0xFF2E7D32)
                                            )
                                        } else {
                                            Button(
                                                onClick = {
                                                    numberMappingStep = 0
                                                    numberMappingFeedback = ""
                                                    numberMappingMode = true
                                                    // 保存当前范围选择
                                                    if (clickProfile.numberRange != numberRange) {
                                                        val updated = clickProfile.copy(numberRange = numberRange)
                                                        ClickMatchConfig.save(context, updated)
                                                        ClickMatchConfig.clearCache()
                                                        clickProfile = updated
                                                    }
                                                    // 互斥：关闭大小单双、组合、直选单式标注
                                                    mappingMode = false
                                                    comboMappingMode = false
                                                    directSelectMappingMode = false
                                                },
                                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                                            ) { Text("开始标注", fontSize = 12.sp) }
                                        }
                                    }

                                    // v2.6.3fix: 数字范围选择
                                    if (!numberMappingMode) {
                                        Row(
                                            Modifier.fillMaxWidth().padding(top = 4.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text("数字范围：", fontSize = 11.sp)
                                            Row(
                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                FilterChip(
                                                    selected = numberRange == "0-9",
                                                    onClick = { numberRange = "0-9" },
                                                    label = { Text("定位胆 0-9", fontSize = 11.sp) }
                                                )
                                                FilterChip(
                                                    selected = numberRange == "1-10",
                                                    onClick = { numberRange = "1-10" },
                                                    label = { Text("PK10 1-10", fontSize = 11.sp) }
                                                )
                                            }
                                        }
                                    }

                                    if (numberMappingMode) {
                                        Text(
                                            if (numberMappingPaused) "标注已暂停 · 可在网页上自由操作" else "请在页面上点击：${numberMappingSteps[numberMappingStep]}",
                                            fontSize = 12.sp,
                                            color = if (numberMappingPaused) Color(0xFFF9A825) else Color(0xFF2E7D32),
                                            fontWeight = FontWeight.Medium
                                        )
                                        Row(
                                            Modifier.fillMaxWidth().padding(top = 4.dp),
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            TextButton(
                                                onClick = { numberMappingPaused = !numberMappingPaused },
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                                            ) {
                                                Text(
                                                    if (numberMappingPaused) "继续标注" else "暂停(操作网页)",
                                                    fontSize = 11.sp,
                                                    color = if (numberMappingPaused) Color(0xFF2E7D32) else Color(0xFFF9A825)
                                                )
                                            }
                                            TextButton(
                                                onClick = {
                                                    numberMappingFeedback = "已跳过：${numberMappingSteps[numberMappingStep]}"
                                                    numberMappingStep = numberMappingStep + 1
                                                    if (numberMappingStep >= numberMappingSteps.size) {
                                                        numberMappingMode = false
                                                        webViewRef?.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = false;", null)
                                                        webViewRef?.removeJavascriptInterface("CfxMappingBridge")
                                                    }
                                                },
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                                            ) { Text("跳过", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                                            TextButton(
                                                onClick = {
                                                    numberMappingMode = false
                                                    numberMappingPaused = false
                                                    webViewRef?.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = false;", null)
                                                    webViewRef?.removeJavascriptInterface("CfxMappingBridge")
                                                },
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                                            ) { Text("退出", color = Color(0xFFC62828), fontSize = 11.sp) }
                                        }
                                        if (numberMappingStep > 0) {
                                            TextButton(
                                                onClick = {
                                                    numberMappingStep = numberMappingStep - 1
                                                    numberMappingFeedback = "返回上一步：${numberMappingSteps[numberMappingStep]}"
                                                },
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                                            ) { Text("上一步", fontSize = 11.sp) }
                                        }
                                    }

                                    if (numberMappingFeedback.isNotBlank()) {
                                        Text(
                                            numberMappingFeedback,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    // 显示已标注的数字玩法 selector 摘要
                                    if (clickProfile.hasCompleteNumberMapping() || clickProfile.numberMappingSummary().isNotEmpty()) {
                                        val numMapped = remember(clickProfile) { clickProfile.numberMappingSummary() }
                                        Text(
                                            "已标注: ${numMapped.joinToString(" · ")}",
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        TextButton(
                                            onClick = {
                                                val cleared = clickProfile.copy(
                                                    selectorNum0 = "", selectorNum1 = "", selectorNum2 = "", selectorNum3 = "",
                                                    selectorNum4 = "", selectorNum5 = "", selectorNum6 = "",
                                                    selectorNum7 = "", selectorNum8 = "", selectorNum9 = "",
                                                    selectorNum10 = "", selectorNumAmount = "", selectorNumConfirm = ""
                                                )
                                                ClickMatchConfig.save(context, cleared)
                                                ClickMatchConfig.clearCache()
                                                clickProfile = cleared
                                                selectedNumMask = 0
                                                numberBetAmount = ""
                                                numberMappingFeedback = "已清空数字玩法标注"
                                            },
                                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
                                        ) { Text("清空数字标注", fontSize = 10.sp, color = Color(0xFFC62828)) }
                                    }

                                    // ---- 数字下单区：选择数字 → 金额 → 确定下单 ----
                                    HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
                                    Text("数字下单", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                                    CaptionMuted("标注完成后，先选数字（可多选），再填金额，点确定下单。${if (dryRun) "当前为仅识别模式，不会真正点击。" else "当前为实盘模式，将真实点击下单！"}")
                                    Row(
                                        Modifier.fillMaxWidth().padding(top = 4.dp),
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        if (numberRange == "0-9") {
                                            (0..4).forEach { n ->
                                                val bitIdx = n
                                                val sel = (selectedNumMask and (1 shl bitIdx)) != 0
                                                FilterChip(
                                                    selected = sel,
                                                    onClick = { selectedNumMask = selectedNumMask xor (1 shl bitIdx) },
                                                    label = { Text("$n", fontSize = 13.sp) },
                                                    enabled = !numberExecuting
                                                )
                                            }
                                        } else {
                                            (1..5).forEach { n ->
                                                val bitIdx = n - 1
                                                val sel = (selectedNumMask and (1 shl bitIdx)) != 0
                                                FilterChip(
                                                    selected = sel,
                                                    onClick = { selectedNumMask = selectedNumMask xor (1 shl bitIdx) },
                                                    label = { Text("$n", fontSize = 13.sp) },
                                                    enabled = !numberExecuting
                                                )
                                            }
                                        }
                                    }
                                    Row(
                                        Modifier.fillMaxWidth().padding(top = 4.dp),
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        if (numberRange == "0-9") {
                                            (5..9).forEach { n ->
                                                val bitIdx = n
                                                val sel = (selectedNumMask and (1 shl bitIdx)) != 0
                                                FilterChip(
                                                    selected = sel,
                                                    onClick = { selectedNumMask = selectedNumMask xor (1 shl bitIdx) },
                                                    label = { Text("$n", fontSize = 13.sp) },
                                                    enabled = !numberExecuting
                                                )
                                            }
                                        } else {
                                            (6..10).forEach { n ->
                                                val bitIdx = n - 1
                                                val sel = (selectedNumMask and (1 shl bitIdx)) != 0
                                                FilterChip(
                                                    selected = sel,
                                                    onClick = { selectedNumMask = selectedNumMask xor (1 shl bitIdx) },
                                                    label = { Text("$n", fontSize = 13.sp) },
                                                    enabled = !numberExecuting
                                                )
                                            }
                                        }
                                    }
                                    OutlinedTextField(
                                        value = numberBetAmount,
                                        onValueChange = { value -> numberBetAmount = value.filter { it.isDigit() || it == '.' }.take(12) },
                                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                                        singleLine = true,
                                        label = { Text("金额") },
                                        placeholder = { Text("例如 1、2、5") },
                                        textStyle = LocalTextStyle.current.copy(fontSize = 13.sp),
                                        enabled = !numberExecuting
                                    )
                                    Row(
                                        Modifier.fillMaxWidth().padding(top = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Button(
                                            onClick = { placeNumberOrder() },
                                            enabled = !numberExecuting && !autoRunning,
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = if (dryRun) Color(0xFFF9A825) else Color(0xFFC62828)
                                            )
                                        ) {
                                            Text(
                                                if (numberExecuting) "执行中..." else if (dryRun) "仅识别" else "确定下单",
                                                fontSize = 12.sp
                                            )
                                        }
                                        Spacer(Modifier.width(8.dp))
                                         val selCount = if (numberRange == "0-9") {
                                            (0..9).count { (selectedNumMask and (1 shl it)) != 0 }
                                        } else {
                                            (1..10).count { (selectedNumMask and (1 shl (it - 1))) != 0 }
                                        }
                                        Text(
                                            "已选 $selCount 个数字",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    if (numberExecFeedback.isNotBlank()) {
                                        Text(
                                            numberExecFeedback,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.padding(top = 4.dp)
                                        )
                                    }
                                }
                            }

                            // 真实按钮文字填写：当目标网站按钮文字不是标准"大/小/单/双"时，
                            // 用户在此填写页面实际显示的文字，JS 执行时用该文字做 selector 消歧。
                            HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
                            Text(
                                "真实按钮文字",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            CaptionMuted("填写页面上大小单双按钮的实际显示文字，用于 selector 匹配多元素时自动消歧。留空则用默认值。")
                            Row(
                                Modifier.fillMaxWidth().padding(top = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                LabelTextInput(
                                    label = "大",
                                    value = clickProfile.labelBig,
                                    onValueChange = { v ->
                                        val updated = clickProfile.copy(labelBig = v)
                                        ClickMatchConfig.save(context, updated)
                                        ClickMatchConfig.clearCache()
                                        clickProfile = updated
                                    },
                                    modifier = Modifier.weight(1f)
                                )
                                LabelTextInput(
                                    label = "小",
                                    value = clickProfile.labelSmall,
                                    onValueChange = { v ->
                                        val updated = clickProfile.copy(labelSmall = v)
                                        ClickMatchConfig.save(context, updated)
                                        ClickMatchConfig.clearCache()
                                        clickProfile = updated
                                    },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            Row(
                                Modifier.fillMaxWidth().padding(top = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                LabelTextInput(
                                    label = "单",
                                    value = clickProfile.labelOdd,
                                    onValueChange = { v ->
                                        val updated = clickProfile.copy(labelOdd = v)
                                        ClickMatchConfig.save(context, updated)
                                        ClickMatchConfig.clearCache()
                                        clickProfile = updated
                                    },
                                    modifier = Modifier.weight(1f)
                                )
                                LabelTextInput(
                                    label = "双",
                                    value = clickProfile.labelEven,
                                    onValueChange = { v ->
                                        val updated = clickProfile.copy(labelEven = v)
                                        ClickMatchConfig.save(context, updated)
                                        ClickMatchConfig.clearCache()
                                        clickProfile = updated
                                    },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(4.dp))

                    // 执行模式切换 + 自动挂机开关
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("执行模式", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        FilterChip(
                            selected = executionMode == "webview",
                            onClick = { executorViewModel.setExecutionMode("webview") },
                            label = { Text("WebView", fontSize = 11.sp) }
                        )
                        FilterChip(
                            selected = executionMode == "accessibility",
                            onClick = { executorViewModel.setExecutionMode("accessibility") },
                            label = { Text("无障碍", fontSize = 11.sp) }
                        )
                        Spacer(Modifier.weight(1f))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                if (autoRunning) "挂机中" else "挂机",
                                fontSize = 12.sp,
                                color = if (autoRunning) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(Modifier.width(4.dp))
                            Switch(
                                checked = autoRunning,
                                onCheckedChange = { on ->
                                    if (on) {
                                        // v2.5.3-fix: 开启挂机时清空测试参数，但保留用户已选的 dryRun/实盘模式
                                        // 传入空字符串表示全局放行，不限制具体彩种
                                        testDx = ""
                                        testDs = ""
                                        testAmount = ""
                                        executorViewModel.startAuto("")
                                    } else executorViewModel.stopAuto()
                                }
                            )
                        }
                    }

                    // 模式状态提示
                    Text(
                        when (executionMode) {
                            "accessibility" -> {
                                val a11yReady = com.caifenxi.app.service.AutoBetAccessibilityService.isRunning()
                                if (a11yReady) "无障碍已就绪 · 复用已配置的点击流水线"
                                else "⚠ 无障碍服务未连接 · 请到「更多→无障碍跟投」开启"
                            }
                            else -> {
                                if (WebViewExecutor.isAvailable) "WebView已连接 · DOM注入点击"
                                else "⚠ WebView未连接 · 请等页面加载完成"
                            }
                        },
                        fontSize = 10.sp,
                        color = when {
                            executionMode == "accessibility" && !com.caifenxi.app.service.AutoBetAccessibilityService.isRunning() -> Color(0xFFC62828)
                            executionMode != "accessibility" && !WebViewExecutor.isAvailable -> Color(0xFFC62828)
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )

                    // 测试参数：方向/金额必须显式确定；不再存在固定“大/单/10”测试工单
                    Surface(
                        shape = MaterialTheme.shapes.small,
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                    ) {
                        Column(Modifier.fillMaxWidth().padding(8.dp)) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text("测试执行参数", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                                TextButton(onClick = {
                                    if (tk.cmdId.isNotBlank()) {
                                        testDx = tk.dx.orEmpty()
                                        testDs = tk.ds.orEmpty()
                                        testAmount = tk.amountText.orEmpty()
                                    }
                                }) { Text("同步当前工单", fontSize = 11.sp) }
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("大小", fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterVertically))
                                listOf("大", "小").forEach { v ->
                                    FilterChip(selected = testDx == v, onClick = { testDx = if (testDx == v) "" else v }, label = { Text(v) })
                                }
                                Spacer(Modifier.width(4.dp))
                                Text("单双", fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterVertically))
                                listOf("单", "双").forEach { v ->
                                    FilterChip(selected = testDs == v, onClick = { testDs = if (testDs == v) "" else v }, label = { Text(v) })
                                }
                            }
                            OutlinedTextField(
                                value = testAmount,
                                onValueChange = { value -> testAmount = value.filter { it.isDigit() || it == '.' }.take(12) },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                label = { Text("测试金额")
                                },
                                placeholder = { Text("必须手动确认，例如 1、2、5") },
                                textStyle = LocalTextStyle.current.copy(fontSize = 13.sp)
                            )
                            Text(
                                "测试只执行上面明确选择的方向；未选择方向或金额无效时不会派发。当前模式：${if (dryRun) "仅识别，不点击" else "实盘点击"}",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // 操作
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                if (autoRunning) return@Button
                                val amountOk = testAmount.toDoubleOrNull()?.let { it > 0.0 && it.isFinite() } == true
                                if ((testDx.isBlank() && testDs.isBlank()) || !amountOk) {
                                    executorViewModel.testSelectorsOnly(context)
                                } else {
                                    val t = executorViewModel.generateTestTask(
                                        dryRun = dryRun,
                                        dx = testDx.takeIf { it.isNotBlank() },
                                        ds = testDs.takeIf { it.isNotBlank() },
                                        amountText = testAmount,
                                        lotteryKey = "manual-test",
                                        issue = "test-${System.currentTimeMillis()}"
                                    )
                                    executorViewModel.startTask(t)
                                }
                            },
                            enabled = !autoRunning,
                            modifier = Modifier.weight(1f)
                        ) { Text(if (dryRun) "测试识别" else "测试执行") }
                        OutlinedButton(
                            onClick = { executorViewModel.testSelectorsOnly(context) },
                            modifier = Modifier.weight(1f)
                        ) { Text("检查选择器") }
                        if (lastFailedTask != null) {
                            Button(
                                onClick = { executorViewModel.retryLastTask() },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFFC62828)
                                )
                            ) {
                                Icon(Icons.Filled.Replay, contentDescription = "重试",
                                    modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("重试")
                            }
                        }
                        OutlinedButton(
                            onClick = { executorViewModel.clearLogs() },
                            modifier = Modifier.weight(1f)
                        ) { Text("清空") }
                    }

                    // 日志（P1: 独立 LazyColumn，避免 takeLast+forEach 在主 Column 内全量组合）
                    val displayLogs = remember(executorLogs) { executorLogs.takeLast(50) }
                    if (displayLogs.isEmpty()) {
                        Box(
                            Modifier.fillMaxWidth().height(100.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("日志空 \u00b7 挂机下单后将自动派发到本页", fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    } else {
                        LazyColumn(
                            Modifier.fillMaxWidth().height(100.dp),
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            items(displayLogs.size, key = { "log-$it" }) { idx ->
                                Text(
                                    displayLogs[idx],
                                    fontSize = 11.sp,
                                    color = when {
                                        displayLogs[idx].contains("成功") -> Color(0xFF2E7D32)
                                        displayLogs[idx].contains("失败") || displayLogs[idx].contains("未找到") -> Color(0xFFC62828)
                                        else -> MaterialTheme.colorScheme.onSurface
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusChip(label: String, value: String, color: Color) {
    Surface(
        shape = MaterialTheme.shapes.small,
        color = color.copy(alpha = 0.12f)
    ) {
        Text(
            "$label $value",
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            fontSize = 11.sp,
            color = color,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun LabelTextInput(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Text(
            label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 2.dp)
        )
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            textStyle = androidx.compose.ui.text.TextStyle(
                fontSize = 13.sp
            )
        )
    }
}
