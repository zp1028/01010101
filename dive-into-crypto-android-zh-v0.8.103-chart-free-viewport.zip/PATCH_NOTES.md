Chart free viewport B: pan negative leaves empty right of latest
