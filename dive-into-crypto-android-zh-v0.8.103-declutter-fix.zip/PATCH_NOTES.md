# Declutter fix — compile errors resolved

- ScannerRankBoardUi: closed RankBoardPill brace
- ScannerRiskAdvisorUi: imports Box, Spacer, PaddingValues, width, DiveFonts
- ScannerScreen: removed extra top-level closing brace
