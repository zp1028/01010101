package com.caifenxi.app.domain.plan

import java.util.concurrent.ConcurrentHashMap

/**
 * 工作台/图表回测结果内存缓存。
 * key = planId|stage|periods|historyTailIssue|invert
 * 避免同一口径重复全量回测。
 */
object WorkbenchBacktestCache {
    private const val MAX = 128
    private val map = ConcurrentHashMap<String, NovaPlanAnalytics.ChartReport>()
    private val order = java.util.concurrent.ConcurrentLinkedDeque<String>()

    fun key(
        planId: String,
        stage: Int,
        periods: Int,
        lastIssue: String,
        histSize: Int,
        invert: Boolean = false,
        outputCount: Int = 0,
        /** 直选单式注数档位指纹（如 "5_5_5"）；影响预测输出，必须参与缓存键 */
        directKey: String = ""
    ): String = "$planId|$stage|$periods|$lastIssue|$histSize|$invert|$outputCount|$directKey"

    fun get(k: String): NovaPlanAnalytics.ChartReport? = map[k]

    @Synchronized
    fun put(k: String, report: NovaPlanAnalytics.ChartReport) {
        if (map.put(k, report) == null) {
            order.addLast(k)
            while (order.size > MAX) {
                val old = order.pollFirst() ?: break
                map.remove(old)
            }
        }
    }

    fun clear() {
        map.clear()
        order.clear()
    }

    fun clearPlan(planId: String) {
        val keys = map.keys.filter { it.startsWith("$planId|") }
        keys.forEach {
            map.remove(it)
            order.remove(it)
        }
    }
}
