package com.caifenxi.app.domain.engine

import com.caifenxi.app.data.config.StreakCalc
import com.caifenxi.app.data.db.dao.BetDao
import com.caifenxi.app.data.db.entity.BetEntity
import com.caifenxi.app.data.db.entity.BotConfigEntity
import com.caifenxi.app.data.db.entity.WalletEntity
import com.caifenxi.app.domain.model.BetCategory
import com.caifenxi.app.domain.model.BetOdds
import com.caifenxi.app.domain.model.LotteryConfig
import com.caifenxi.app.domain.model.LotteryType
import com.caifenxi.app.domain.model.BetSourceType
import com.caifenxi.app.domain.model.BetStats
import com.caifenxi.app.domain.model.CatBetStats
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.ModelConsensus
import com.caifenxi.app.domain.model.PlanPredictionRecord
import com.caifenxi.app.domain.model.PksPositions
import com.caifenxi.app.domain.model.PredictionSnapshot
import com.caifenxi.app.domain.model.ProfitPoint
import com.caifenxi.app.domain.plan.NovaPlanPool
import com.caifenxi.app.domain.plan.LotteryPlanPools
import com.caifenxi.app.domain.plan.NovaYdhPlanPool
import com.caifenxi.app.domain.plan.NovaK3PlanPool
import com.caifenxi.app.domain.plan.NovaPlanAnalytics
import com.caifenxi.app.domain.plan.PlanPool
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * 模拟下注引擎:下单 + 每期自动结算 + 倍投 + 统计。
 *
 * 金额口径（与工作台 NovaPlanAnalytics 对齐）:
 * - 一期：按「错了倍投期数」做 121212 式周期；对了倍投仍受 winMultPeriods 限制
 * - 二期/三期：轮次锁定，轮内第 k 腿 = 基数 × lossMult^k；整轮结束后从基数再开
 * 各分类独立追踪连对/连错。
 */
class BetEngine(private val dao: BetDao) {

    companion object {
        const val DEFAULT_INITIAL = 10000.0
    }

    // ---- 内存中追踪各分类上一注结果(lotteryKey -> catName -> lastHit?)----
    /**
     * 二期/三期工作台轮次：锁定一轮预测方向，最多追 stage 期。
     * nextLeg = 下一期要下的腿序号（0=轮首用新预测；1..=沿用锁定方向）。
     */
    private data class StageRoundLock(
        val picks: Map<BetCategory, List<String>>,
        val nextLeg: Int,
        val stage: Int,
        val sourceKey: String
    )
    private val stageRoundLocks = mutableMapOf<String, StageRoundLock>()

    private fun stagePrefs() = try {
        com.caifenxi.app.CaiFenXiApplication.instance
            .getSharedPreferences("bet_engine_stage_lock", android.content.Context.MODE_PRIVATE)
    } catch (e: Exception) {
        com.caifenxi.app.util.RuntimeLog.warn("BetEngine", "stagePrefs 读取失败: ${e.message}")
        null
    }

    private fun persistStageLock(lotteryKey: String, lock: StageRoundLock?) {
        val sp = stagePrefs() ?: return
        val ed = sp.edit()
        if (lock == null) {
            ed.remove("sk_$lotteryKey").remove("leg_$lotteryKey").remove("st_$lotteryKey")
                .remove("picks_$lotteryKey").apply()
            return
        }
        // picks: catId=v1/v2;catId2=...
        val picksStr = lock.picks.entries.joinToString(";") { (c, vs) ->
            "${c.id}=${vs.joinToString("/")}"
        }
        ed.putString("sk_$lotteryKey", lock.sourceKey)
            .putInt("leg_$lotteryKey", lock.nextLeg)
            .putInt("st_$lotteryKey", lock.stage)
            .putString("picks_$lotteryKey", picksStr)
            .apply()
    }

    private fun loadStageLock(lotteryKey: String): StageRoundLock? {
        stageRoundLocks[lotteryKey]?.let { return it }
        val sp = stagePrefs() ?: return null
        val sk = sp.getString("sk_$lotteryKey", null) ?: return null
        val leg = sp.getInt("leg_$lotteryKey", -1)
        val st = sp.getInt("st_$lotteryKey", 0)
        val picksStr = sp.getString("picks_$lotteryKey", null) ?: return null
        if (leg < 0 || st < 2) return null
        val map = mutableMapOf<BetCategory, List<String>>()
        for (part in picksStr.split(";")) {
            val kv = part.split("=", limit = 2)
            if (kv.size != 2) continue
            val cat = BetCategory.fromId(kv[0]) ?: continue
            map[cat] = kv[1].split("/").map { it.trim() }.filter { it.isNotBlank() }
        }
        if (map.isEmpty()) return null
        return StageRoundLock(map, leg, st, sk).also { stageRoundLocks[lotteryKey] = it }
    }

    private val lastHitMap = mutableMapOf<String, MutableMap<String, Boolean?>>()
    /** 同彩种下单互斥,避免 UI 心跳与 Service 并发各下一遍 */
    private val placeMutex = Mutex()

    // ---- 过关斩将：独立于倍投，下注金额只受关数设置控制 ----
    private fun guoguanPrefs() = try {
        com.caifenxi.app.CaiFenXiApplication.instance
            .getSharedPreferences("bet_engine_guoguan", android.content.Context.MODE_PRIVATE)
    } catch (e: Exception) {
        com.caifenxi.app.util.RuntimeLog.warn("BetEngine", "guoguanPrefs 读取失败: ${e.message}")
        null
    }

    /** 读取当前过关斩将关数（0=尚未开始/刚被斩将） */
    private fun getGuoGuanGate(lotteryKey: String): Int {
        return guoguanPrefs()?.getInt("gg_gate_$lotteryKey", 0) ?: 0
    }

    /** 写入当前过关斩将关数 */
    private fun setGuoGuanGate(lotteryKey: String, gate: Int) {
        guoguanPrefs()?.edit()?.putInt("gg_gate_$lotteryKey", gate)?.apply()
    }

    /** 计算过关斩将第N关下注金额（1-based：第1关=baseStake，第N关=baseStake*gateMult^(N-1)） */
    private fun guoGuanStakeAtGate(
        baseStake: Double, gateMult: Double, gate: Int
    ): Double {
        val g = gate.coerceAtLeast(0)
        if (g <= 0 || gateMult <= 1.0) return baseStake
        var stake = baseStake
        var i = 0
        while (i < g) {
            stake *= gateMult
            i++
        }
        return stake
    }

    /**
     * 下单诊断结果(便于状态栏说明为何没下单)。
     */
    data class PlaceResult(
        val placed: Int,
        val reason: String,
        val picksSummary: String = ""
    )

    /**
     * 根据挂机策略 + 当前预测,为指定目标期自动下单。
     * @return 本次实际下的注数量
     */
    suspend fun placeAutoBets(
        lotteryKey: String,
        targetIssue: String,
        prediction: PredictionSnapshot?,
        planPredictions: List<PlanPredictionRecord>,
        consensus: List<ModelConsensus>,
        history: List<DrawRecord> = emptyList()
    ): Int = placeAutoBetsDetailed(
        lotteryKey, targetIssue, prediction, planPredictions, consensus, history
    ).placed

    /**
     * 带回原因的自动下单,供界面提示「为何没挂上」。
     * 全程互斥,防止心跳/Service/手动同时触发导致同一目标期下两遍。
     * @param history 滚动预测开启时用于图表同款现算（从最新往前）
     */
    suspend fun placeAutoBetsDetailed(
        lotteryKey: String,
        targetIssue: String,
        prediction: PredictionSnapshot?,
        planPredictions: List<PlanPredictionRecord>,
        consensus: List<ModelConsensus>,
        history: List<DrawRecord> = emptyList()
    ): PlaceResult = placeMutex.withLock {
        val config = dao.getBotConfig(lotteryKey)
            ?: return@withLock PlaceResult(0, "无挂机配置(请到挂机页开启并保存)")
        if (!config.enabled) return@withLock PlaceResult(0, "挂机未开启")
        if (config.amount <= 0) return@withLock PlaceResult(0, "单注金额为0")
        if (targetIssue.isBlank() || targetIssue == "-") {
            return@withLock PlaceResult(0, "目标期无效")
        }

        // 防重:目标期已有「待开」订单则跳过
        if (dao.getPendingBets(lotteryKey, targetIssue).isNotEmpty()) {
            return@withLock PlaceResult(0, "目标期 $targetIssue 已有待开单")
        }

        val categories = config.categories.split(",").mapNotNull { BetCategory.fromId(it.trim()) }
        if (categories.isEmpty()) return@withLock PlaceResult(0, "未勾选下注分类")

        val stage = config.rollingStage.coerceIn(1, 3)
        val effectiveLossMult = if (stage >= 2 && config.lossMult <= 1.0) 2.0 else config.lossMult
        val effectiveWinMult = if (stage >= 2 && config.winMult <= 1.0) 2.0 else config.winMult
        val sourceKey =
            listOf(
                config.sourceType, config.sourceId,
                config.sourceIdDx, config.sourceIdDs, config.sourceIdCombo,
                config.betMode, config.rollingPredict.toString(),
                config.rollingStage.toString()
            ).joinToString("|")
        ensureLastHitFromDb(lotteryKey)
        val catStreaksEarly = lastHitMap.getOrPut(lotteryKey) { mutableMapOf() }

        // 二期/三期：若本轮未结束且上期未中，沿用锁定轮次（leg/stage/sourceKey），
        // 但方向每期从工作台最新 planPredictions 同步，不使用第一期锁存方向。
        var activeLeg = 0
        val lock = loadStageLock(lotteryKey)
        val reuseLock = stage >= 2 &&
            lock != null &&
            lock.stage == stage &&
            lock.sourceKey == sourceKey &&
            lock.nextLeg in 1 until stage &&
            categories.any { catStreaksEarly[it.id] == false }

        val picksRaw = if (reuseLock) {
            activeLeg = lock!!.nextLeg
            // 方向同步工作台最新计划预测，不沿用第一期锁存方向
            resolvePicks(config, prediction, planPredictions, consensus, history)
        } else {
            if (stage >= 2 && (lock == null || lock.nextLeg >= stage || lock.sourceKey != sourceKey)) {
                stageRoundLocks.remove(lotteryKey)
                persistStageLock(lotteryKey, null)
            }
            activeLeg = 0
            resolvePicks(config, prediction, planPredictions, consensus, history)
        }
        // 滚动现算结果已按 rolling 内反投处理；非滚动仍用 betMode 反投
        val picks = if (!config.rollingPredict && config.betMode.equals("reverse", ignoreCase = true)) {
            invertPicks(picksRaw)
        } else {
            picksRaw
        }
        if (picks.isEmpty()) {
            val why = when (BetSourceType.fromId(config.sourceType)) {
                BetSourceType.COCKPIT, BetSourceType.ALGO ->
                    if (prediction == null) "算法预测为空(未生成)"
                    else "算法预测无可用方向(检查分类是否匹配)"
                BetSourceType.PLAN, BetSourceType.NOVA, BetSourceType.FAVORITE ->
                    "计划「${config.sourceId}」无预测(请确认计划已在工作台生成/回测并与目标期一致；也可开启滚动现算用图表同款现算)"
                BetSourceType.AUTO_BEST ->
                    "竞技场暂无可用计划预测"
                BetSourceType.CONSENSUS ->
                    "共识预测为空(请打开计划-共识预测页刷新)"
                BetSourceType.NOVA_CONSENSUS ->
                    "新计划共识为空(请打开新计划页-共识预测刷新)"
            }
            return@withLock PlaceResult(0, why)
        }

        val wallet = dao.getWallet(lotteryKey) ?: ensureWallet(lotteryKey, DEFAULT_INITIAL)
        var balance = wallet.balance
        val initial = wallet.initialBalance
        val catStreaks = catStreaksEarly
        var placed = 0
        var spent = 0.0
        /** 派发网页/无障碍的单注金额：必须与本轮实际下单 currentAmount 一致（含一期倍投、二期腿） */
        var dispatchUnitAmount = 0.0
        val dispatchAmountByCategory = mutableMapOf<String, Double>()
        val pickDesc = picks.entries.joinToString(";") { (k, v) -> "${k.id}:${v.joinToString("/")}" } +
            if (stage >= 2) " ·${stage}期轮L${activeLeg + 1}" else ""

        for (cat in categories) {
            val values = picks[cat]?.distinct()?.filter { it.isNotBlank() } ?: continue
            if (values.isEmpty()) continue
            val lastHit = catStreaks[cat.id]
            val prevAmount = getLastAmount(lotteryKey, cat.id).let { if (it > 0) it else config.amount }
            val streak = if (lastHit == null) 0 else getRecentStreak(lotteryKey, cat.id, lastHit)
            // 过关斩将：启用时下注金额只受关数设置控制，完全绕过倍投 winMult/lossMult
            val currentAmount = if (config.guoguanEnabled) {
                val ggGate = getGuoGuanGate(lotteryKey)
                guoGuanStakeAtGate(
                    baseStake = config.guoguanBaseStake,
                    gateMult = config.guoguanGateMult,
                    gate = ggGate
                )
            } else {
                // 二期/三期优先用轮内腿序号算金额（与工作台 unitStake 递进一致）
                calcAmount(
                    baseAmount = config.amount,
                    lastAmount = prevAmount,
                    lastHit = lastHit,
                    streak = streak,
                    winMult = effectiveWinMult,
                    lossMult = effectiveLossMult,
                    winMultPeriods = config.winMultPeriods,
                    lossMultPeriods = config.lossMultPeriods,
                    maxMult = config.maxMult,
                    maxCap = initial * config.maxMult.coerceAtLeast(1),
                    rollingStage = stage,
                    stageLegOverride = if (stage >= 2) activeLeg else null
                )
            }.coerceAtMost((balance - spent).coerceAtLeast(0.0))

            if (currentAmount <= 0 || balance - spent <= 0) {
                if (placed == 0) {
                    return@withLock PlaceResult(0, "余额不足(可用 ${"%.1f".format(balance - spent)})", pickDesc)
                }
                break
            }
            // 大小/单双：记录本轮单注，供网页派发（避免另算一遍导致一期永远基数、二期腿错乱）
            if (cat == BetCategory.DX || cat == BetCategory.DS) {
                dispatchAmountByCategory[cat.id] = currentAmount
                if (dispatchUnitAmount <= 0.0) dispatchUnitAmount = currentAmount
            }

            // 组合/数字:多候选合并为一注;组合赔率随覆盖数变化
            if (cat == BetCategory.COMBO) {
                // 一口单注 currentAmount；n 口总成本 n×单注；返还按 1:4 单口（4×单注），再减成本
                val n = values.size.coerceAtLeast(1)
                val totalCost = currentAmount * n
                if (balance - spent < totalCost) break
                val odds = BetOdds.resolveForBet(BetCategory.COMBO, values, lotteryKey)
                dao.insertBet(
                    BetEntity(
                        lotteryKey = lotteryKey,
                        issue = targetIssue,
                        sourceType = config.sourceType,
                        sourceId = config.sourceId,
                        category = cat.id,
                        betValue = values.joinToString("/"),
                        amount = totalCost,
                        odds = odds,
                        status = "待开",
                        profit = 0.0
                    )
                )
                spent += totalCost
                placed++
            } else if (cat == BetCategory.NUMBER && values.size > 1) {
                // 快乐8/定位等多码：每码一注成本，总成本 = n × 单注；命中口径与结算用展示赔率对齐
                val n = values.size.coerceAtLeast(1)
                val totalCost = currentAmount * n
                if (balance - spent < totalCost) break
                dao.insertBet(
                    BetEntity(
                        lotteryKey = lotteryKey,
                        issue = targetIssue,
                        sourceType = config.sourceType,
                        sourceId = config.sourceId,
                        category = cat.id,
                        betValue = values.joinToString("/"),
                        amount = totalCost,
                        odds = if (values.all { it.length == 3 && it.all { c -> c.isDigit() } })
                            (BetOdds.DIRECT_RETURN / n).coerceAtLeast(1.0)
                        else BetOdds.resolveForBet(BetCategory.NUMBER, values, lotteryKey),
                        status = "待开",
                        profit = 0.0
                    )
                )
                spent += totalCost
                placed++
            } else {
                // 大小/单双:每方向一注
                for (value in values) {
                    val playHint = value.substringBefore(":", "").takeIf { ":" in value }.orEmpty()
                    val bare = value.substringAfter(":").takeIf { ":" in value } ?: value
                    val odds = BetOdds.resolveForBet(cat, listOf(bare), lotteryKey, playHint)
                    if (balance - spent < currentAmount) break
                    dao.insertBet(
                        BetEntity(
                            lotteryKey = lotteryKey,
                            issue = targetIssue,
                            sourceType = config.sourceType,
                            sourceId = config.sourceId,
                            category = cat.id,
                            betValue = bare,
                            amount = currentAmount,
                            odds = odds,
                            status = "待开",
                            profit = 0.0
                        )
                    )
                    spent += currentAmount
                    placed++
                }
            }
        }
        if (spent > 0) {
            dao.upsertWallet(
                wallet.copy(
                    balance = (balance - spent).coerceAtLeast(0.0),
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
        if (placed > 0) {
            // 供无障碍「跟随挂机」只点下单结果，不读悬浮窗原预测
            try {
                fun bareDir(v: String): String = v.substringAfter(":").takeIf { ":" in v } ?: v
                // 只派发用户勾选的分类方向，未勾选的分类即使预测有值也不派发
                val dx = if (BetCategory.DX in categories)
                    picks[BetCategory.DX]?.map { bareDir(it) }?.firstOrNull { it == "大" || it == "小" }
                else null
                val ds = if (BetCategory.DS in categories)
                    picks[BetCategory.DS]?.map { bareDir(it) }?.firstOrNull { it == "单" || it == "双" }
                else null
                val combo = if (BetCategory.COMBO in categories)
                    picks[BetCategory.COMBO]?.joinToString("/")
                else null
                // v2.6.2: 直选单式号码组合跟随计划注数（用于 ExecutionTicket 展示与派发）
                val dispatchNumbers = if (BetCategory.NUMBER in categories)
                    picks[BetCategory.NUMBER]?.map { bareDir(it) }?.filter { it.isNotBlank() }
                else null
                com.caifenxi.app.service.AutoBetController.recordPlacedPicks(
                    context = com.caifenxi.app.CaiFenXiApplication.instance,
                    lotteryKey = lotteryKey,
                    targetIssue = targetIssue,
                    dx = dx,
                    ds = ds,
                    combo = combo
                )
                // 下单缓存写入后衔接无障碍（跟随挂机时避免点到 READY 时的旧方向）
                com.caifenxi.app.service.AutoBetController.onHangUpPlaced(
                    context = com.caifenxi.app.CaiFenXiApplication.instance,
                    lotteryKey = lotteryKey,
                    targetIssue = targetIssue
                )
                // WebView/无障碍统一指令：方向 + 本期金额（与本轮实际下单单注一致，含一期倍投/二期腿）
                val legAmount = when {
                    dispatchUnitAmount > 0 -> dispatchUnitAmount
                    config.guoguanEnabled -> {
                        // 过关斩将：回退也用关数金额，不用倍投
                        val ggGate = getGuoGuanGate(lotteryKey)
                        guoGuanStakeAtGate(
                            baseStake = config.guoguanBaseStake,
                            gateMult = config.guoguanGateMult,
                            gate = ggGate
                        )
                    }
                    else -> {
                        // 仅下了组合/数字时回退按口径重算
                        calcAmount(
                            baseAmount = config.amount,
                            lastAmount = config.amount,
                            lastHit = if (stage >= 2 && activeLeg > 0) false else null,
                            streak = if (stage >= 2) activeLeg else 0,
                            winMult = effectiveWinMult,
                            lossMult = effectiveLossMult,
                            winMultPeriods = config.winMultPeriods,
                            lossMultPeriods = config.lossMultPeriods,
                            maxMult = config.maxMult,
                            maxCap = initial * config.maxMult.coerceAtLeast(1),
                            rollingStage = stage,
                            stageLegOverride = if (stage >= 2) activeLeg else null
                        )
                    }
                }
                val directionAmounts = dispatchAmountByCategory.values.distinctBy { "%.8f".format(it) }
                if (directionAmounts.size > 1) {
                    val detail = dispatchAmountByCategory.entries.joinToString(",") { "${it.key}=${it.value}" }
                    com.caifenxi.app.util.RuntimeLog.warn(
                        "HANG→AMT",
                        "本期方向金额不一致，拒绝向WebView派发以防错单 lottery=$lotteryKey issue=$targetIssue detail=$detail"
                    )
                }
                val amountText = "%.2f".format(legAmount)
                com.caifenxi.app.util.RuntimeLog.info(
                    "HANG→AMT",
                    "lottery=$lotteryKey issue=$targetIssue stage=$stage leg=$activeLeg " +
                        "baseAmount=${config.amount} unit=$legAmount amountText=$amountText " +
                        "fromPlaced=${dispatchUnitAmount > 0} lossMult=$effectiveLossMult"
                )
                val bets = mutableListOf<com.caifenxi.app.domain.execution.BetAction>()
                // v2.5.3: 组合投注（combo）不生成独立 BetAction。
                // 所有组合投注（如"大双"）通过 dx+ds 分别点击实现。
                // 若站点有独立 combo 按钮，需后续在 ClickMatchConfig 中增加 combo selector 标注支持。
                if (dx != null) bets += com.caifenxi.app.domain.execution.BetAction(
                    com.caifenxi.app.domain.execution.BetAction.CAT_DX, dx
                )
                if (ds != null) bets += com.caifenxi.app.domain.execution.BetAction(
                    com.caifenxi.app.domain.execution.BetAction.CAT_DS, ds
                )
                // v2.6.2: 直选单式注数跟随计划——将计划预测的号码组合全部派发为 BetAction
                // 每条号码预测生成一条 BetAction(CAT_NUMBER, value)，bets.size 即实际注数
                if (BetCategory.NUMBER in categories) {
                    picks[BetCategory.NUMBER]?.forEach { num ->
                        bets += com.caifenxi.app.domain.execution.BetAction(
                            com.caifenxi.app.domain.execution.BetAction.CAT_NUMBER, num
                        )
                    }
                }
                if (bets.isNotEmpty()) {
                    val planLabel = listOf(config.sourceIdDx, config.sourceIdDs, config.sourceId)
                        .firstOrNull { it.isNotBlank() } ?: config.sourceType
                    val cmd = com.caifenxi.app.domain.execution.BetCommand(
                        cmdId = "${System.currentTimeMillis()}-$lotteryKey-$targetIssue-L$activeLeg",
                        lotteryKey = lotteryKey,
                        issue = targetIssue,
                        stage = stage,
                        leg = activeLeg,
                        bets = bets,
                        amountText = amountText,
                        source = planLabel,
                        expireAt = System.currentTimeMillis() + 480_000L, // 8分钟：给网页连接与排队补点留足时间
                        options = mapOf(
                            "execMode" to config.execMode.ifBlank { "auto" },
                            "dispatchToWeb" to if (config.dispatchToWeb) "1" else "0",
                            "amountSource" to "hangup_actual_unit",
                            "stageLeg" to "$stage:$activeLeg"
                        )
                    )
                    val directionAmountMismatch = dispatchAmountByCategory.values
                        .distinctBy { "%.8f".format(it) }.size > 1
                    if (directionAmountMismatch && config.dispatchToWeb && config.execMode != "ledger") {
                        com.caifenxi.app.domain.execution.ExecutionTicketStore.publish(
                            com.caifenxi.app.domain.execution.ExecutionTicket(
                                cmdId = cmd.cmdId, lotteryKey = lotteryKey, issue = targetIssue,
                                planLabel = planLabel, stage = stage, leg = activeLeg, dx = dx, ds = ds,
                                amountText = amountText, numbers = dispatchNumbers ?: emptyList(), status = "FAILED",
                                message = "方向金额不一致，已阻止网页执行，防止一期/二期/三期金额错配",
                                updatedAt = System.currentTimeMillis()
                            )
                        )
                    } else if (!config.dispatchToWeb || config.execMode == "ledger") {
                        com.caifenxi.app.domain.execution.ExecutionTicketStore.publish(
                            com.caifenxi.app.domain.execution.ExecutionTicket(
                                cmdId = cmd.cmdId,
                                lotteryKey = lotteryKey,
                                issue = targetIssue,
                                planLabel = planLabel,
                                stage = stage,
                                leg = activeLeg,
                                dx = dx,
                                ds = ds,
                                amountText = amountText,
                                numbers = dispatchNumbers ?: emptyList(),
                                status = "LEDGER",
                                message = "仅记账，未派发网页点击",
                                updatedAt = System.currentTimeMillis()
                            )
                        )
                    } else {
                        com.caifenxi.app.service.AutoBetController.dispatchBetCommand(cmd)
                    }
                }
            } catch (e: Exception) {
                com.caifenxi.app.util.RuntimeLog.warn(
                    "HANG→DISPATCH",
                    "派发失败 lottery=$lotteryKey issue=$targetIssue placed=$placed error=${e.message}"
                )
            }
            // 二期/三期：写入/推进轮次锁，供下一期沿用同一预测
            if (stage >= 2) {
                val next = activeLeg + 1
                if (next < stage) {
                    val newLock = StageRoundLock(
                        picks = picks,
                        nextLeg = next,
                        stage = stage,
                        sourceKey = sourceKey
                    )
                    stageRoundLocks[lotteryKey] = newLock
                    persistStageLock(lotteryKey, newLock)
                } else {
                    // 本轮最后一腿已下完，无论中挂，下期重新开轮
                    stageRoundLocks.remove(lotteryKey)
                    persistStageLock(lotteryKey, null)
                }
            } else {
                stageRoundLocks.remove(lotteryKey)
                persistStageLock(lotteryKey, null)
            }
            return@withLock PlaceResult(placed, "已下 $placed 注 · 目标$targetIssue", pickDesc)
        }
        return@withLock PlaceResult(0, "分类与预测方向无交集", pickDesc)
    }

    /**
     * 计算本期下注金额（对齐工作台 [NovaPlanAnalytics.chartBacktest]）。
     *
     * 工作台二期/三期：
     * - 一次预测锁定，最多追 stage 期为一轮
     * - 轮内第 k 腿（k 从 0）：unitStake 从基数起，未中则 unitStake *= mult
     * - 任一期中 → 本轮中并结束；全挂 → 本轮挂；下一轮始终从基数重新开始
     * - 连错金额序列：二期 1,2,1,2…；三期 1,2,4,1,2,4…（mult=2）
     *
     * 一期：仍用「错了倍投期数」——期数=1 时连错为 1,2,1,2…（倍投一期后隔一期基数再触发）。
     */
    private fun calcAmount(
        baseAmount: Double,
        lastAmount: Double,
        lastHit: Boolean?,
        streak: Int,
        winMult: Double,
        lossMult: Double,
        winMultPeriods: Int,
        lossMultPeriods: Int,
        maxMult: Int,
        maxCap: Double,
        rollingStage: Int = 1,
        /** 非空时：二期/三期按轮内腿序号计金额（0=基数） */
        stageLegOverride: Int? = null
    ): Double {
        val stage = rollingStage.coerceIn(1, 3)
        // 二期/三期明确腿序号时，直接 base*mult^leg（与工作台 unitStake 一致）
        if (stage >= 2 && stageLegOverride != null) {
            val mult = lossMult
            if (mult <= 1.0 || stageLegOverride <= 0) return baseAmount
            var stake = baseAmount
            var i = 0
            while (i < stageLegOverride) {
                stake *= mult
                i++
            }
            return stake.coerceAtMost(maxCap).coerceAtLeast(baseAmount)
        }
        if (lastHit == null || streak <= 0) return baseAmount
        val seed = if (lastAmount > 0) lastAmount else baseAmount
        if (!lastHit) {
            val mult = lossMult
            if (mult <= 1.0) return baseAmount
            if (stage >= 2) {
                // 无腿序号时回退：按连错 streak 映射到轮内腿
                val k = (streak - 1) % stage
                var stake = baseAmount
                var i = 0
                while (i < k) {
                    stake *= mult
                    i++
                }
                return stake.coerceAtMost(maxCap).coerceAtLeast(baseAmount)
            }
            // 一期：错了倍投期数（默认 1 → 12121212）
            val periods = lossMultPeriods.coerceAtLeast(0)
            if (periods <= 0) return baseAmount
            val posInCycle = (streak - 1) % (periods + 1)
            if (posInCycle >= periods) return baseAmount
            val next = if (seed > baseAmount * 1.001) seed * mult else baseAmount * mult
            return next.coerceAtMost(maxCap).coerceAtLeast(baseAmount)
        }
        val periods = winMultPeriods.coerceAtLeast(0)
        if (winMult <= 1.0 || periods <= 0 || streak > periods) return baseAmount
        return (seed * winMult).coerceAtMost(maxCap).coerceAtLeast(baseAmount)
    }

    /** 获取某分类「上一期」金额(同期货数合并取合计,用于倍投基数) */
    private suspend fun getLastAmount(lotteryKey: String, catName: String): Double {
        val settled = dao.getBets(lotteryKey)
            .filter { it.category == catName && it.status != "待开" }
        if (settled.isEmpty()) return 0.0
        val lastIssue = settled.maxByOrNull {
            it.issue.toLongOrNull() ?: Long.MIN_VALUE
        }?.issue ?: return 0.0
        return settled.filter { it.issue == lastIssue }.sumOf { it.amount }
    }

    /**
     * 获取最近连续相同结果的「期数」(按期号聚合,同一期多注只算一期)。
     */
    private suspend fun getRecentStreak(lotteryKey: String, catName: String, targetHit: Boolean): Int {
        val settled = dao.getBets(lotteryKey)
            .filter { it.category == catName && it.status != "待开" }
        if (settled.isEmpty()) return 0
        // 期号降序:同一期任一中 → 该期记中
        val byIssue = settled.groupBy { it.issue }
            .map { (issue, list) ->
                val issueNum = issue.toLongOrNull() ?: Long.MIN_VALUE
                val hit = list.any { it.status == "中" }
                issueNum to hit
            }
            .sortedByDescending { it.first }
        var streak = 0
        for ((_, hit) in byIssue) {
            if (hit != targetHit) break
            streak++
        }
        return streak
    }

    /**
     * 用一期开奖结果结算所有待开订单,并更新各分类连对/连错追踪。
     */
    suspend fun settleWithDraw(lotteryKey: String, draw: DrawRecord) {
        val pending = dao.getPendingBefore(lotteryKey, draw.issue)
            .plus(dao.getPendingBets(lotteryKey, draw.issue))
            .distinctBy { it.id }
        if (pending.isEmpty()) return

        val wallet = dao.getWallet(lotteryKey) ?: WalletEntity(lotteryKey = lotteryKey)
        var balance = wallet.balance
        var totalProfit = wallet.totalProfit
        var totalBet = wallet.totalBet
        var win = wallet.winCount
        var lose = wallet.loseCount

        val catStreaks = lastHitMap.getOrPut(lotteryKey) { mutableMapOf() }

        // 下单时已扣本金:赢则返还本金+盈利(amount*odds),输则不再加回
        val updated = pending.map { bet ->
            val hit = judge(bet.category, bet.betValue, draw)
            val profit = if (hit) bet.amount * (bet.odds - 1.0) else -bet.amount
            if (hit) {
                balance += bet.amount * bet.odds
            }
            totalProfit += profit
            totalBet += bet.amount
            if (hit) win++ else lose++

            bet.copy(
                status = if (hit) "中" else "未中",
                profit = profit,
                settledAt = System.currentTimeMillis()
            )
        }
        // 倍投方向按分类整体判定:组合/数字位置注为多候选单注(命中任一即对),
        // 大小/单双历史遗留多注也按「该分类本期任一命中即记对」兼容
        var anyHit = false
        pending.groupBy { it.category }.forEach { (cat, bets) ->
            val hit = bets.any { judge(it.category, it.betValue, draw) }
            catStreaks[cat] = hit
            if (hit) anyHit = true
        }
        // 工作台轮次：任一分类命中则结束本轮锁定，下期重新预测
        if (anyHit) {
            stageRoundLocks.remove(lotteryKey)
        }
        // 过关斩将：命中=过关进入下一关（到总关数则通关重置）；全未中=斩将重置
        val ggCfg = dao.getBotConfig(lotteryKey)
        if (ggCfg?.guoguanEnabled == true) {
            val curGate = getGuoGuanGate(lotteryKey)
            if (anyHit) {
                val nextGate = curGate + 1
                if (nextGate >= ggCfg.guoguanTotalGates) {
                    // 通关：重置回第0关
                    setGuoGuanGate(lotteryKey, 0)
                } else {
                    // 过关：进入下一关
                    setGuoGuanGate(lotteryKey, nextGate)
                }
            } else {
                // 斩将：重置回第0关
                setGuoGuanGate(lotteryKey, 0)
            }
        }
        dao.updateBets(updated)
        dao.upsertWallet(
            wallet.copy(
                balance = balance,
                totalProfit = totalProfit,
                totalBet = totalBet,
                winCount = win,
                loseCount = lose,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    /**
     * 从 DB 历史计算收益统计 + 对错统计。
     */
    suspend fun getBetStats(lotteryKey: String): BetStats {
        val wallet = dao.getWallet(lotteryKey)
        val bets = dao.getBets(lotteryKey)

        val initial = wallet?.initialBalance ?: DEFAULT_INITIAL
        val balance = wallet?.balance ?: initial
        val totalProfit = wallet?.totalProfit ?: 0.0
        val totalBet = wallet?.totalBet ?: 0.0
        val winCount = wallet?.winCount ?: 0
        val loseCount = wallet?.loseCount ?: 0

        val settled = bets.filter { it.status != "待开" }
        val totalSettled = settled.size

        // 本期(最新期)投入与盈亏 — 期号按数值取最大
        val latestIssue = bets.filter { it.status != "待开" }
            .maxByOrNull { it.issue.toLongOrNull() ?: Long.MIN_VALUE }?.issue ?: ""
        val currentBets = bets.filter { it.issue == latestIssue }
        val currentBetAmount = currentBets.sumOf { it.amount }
        val currentProfit = currentBets.sumOf { it.profit }

        // 按分类统计对错(从历史记录重算,不依赖内存 streak)
        val byCategory = BetCategory.entries.associate { cat ->
            cat.id to buildCatStats(cat.id, bets)
        }

        // 收益曲线:按期号聚合(同期货数合并),避免一注一个点导致曲线挤成一团/看似空白
        val issueOrder = settled
            .groupBy { it.issue }
            .map { (issue, list) ->
                val num = issue.toLongOrNull() ?: Long.MIN_VALUE
                val profit = list.sumOf { it.profit }
                val hit = list.any { it.status == "中" }
                Triple(num, issue, profit to hit)
            }
            .sortedBy { it.first }
        var running = 0.0
        var peak = 0.0
        var maxDD = 0.0
        var maxDDPct = 0.0
        val curve = mutableListOf<ProfitPoint>()
        issueOrder.forEachIndexed { idx, (_, issue, pair) ->
            val (profit, hit) = pair
            running += profit
            if (running > peak) peak = running
            val dd = peak - running
            val ddPct = if (peak > 0) dd / peak else 0.0
            if (dd > maxDD) maxDD = dd
            if (ddPct > maxDDPct) maxDDPct = ddPct
            curve.add(
                ProfitPoint(
                    issueIndex = idx,
                    issue = issue,
                    cumulativeProfit = running,
                    hit = hit,
                    drawdown = dd,
                    drawdownPct = ddPct
                )
            )
        }

        // 最长连对/连错(按期)
        var maxHitStreak = 0
        var maxMissStreak = 0
        var curHit = 0
        var curMiss = 0
        issueOrder.forEach { (_, _, pair) ->
            if (pair.second) {
                curHit++; curMiss = 0
                if (curHit > maxHitStreak) maxHitStreak = curHit
            } else {
                curMiss++; curHit = 0
                if (curMiss > maxMissStreak) maxMissStreak = curMiss
            }
        }

        return BetStats(
            initialBalance = initial,
            balance = balance,
            totalProfit = totalProfit,
            totalBet = totalBet,
            profitRate = if (initial > 0) totalProfit / initial else 0.0,
            totalSettled = totalSettled,
            winCount = winCount,
            loseCount = loseCount,
            winRate = if (totalSettled > 0) winCount.toDouble() / totalSettled else 0.0,
            currentBetAmount = currentBetAmount,
            currentProfit = currentProfit,
            byCategory = byCategory,
            profitCurve = curve,
            maxDrawdown = maxDD,
            maxDrawdownPct = maxDDPct,
            peakProfit = peak,
            maxHitStreak = maxHitStreak,
            maxMissStreak = maxMissStreak
        )
    }

    private fun buildCatStats(catName: String, allBets: List<BetEntity>): CatBetStats {
        val catBets = allBets.filter { it.category == catName && it.status != "待开" }
            .sortedBy { it.settledAt ?: Long.MAX_VALUE }

        val hit = catBets.count { it.status == "中" }
        val miss = catBets.size - hit
        val settled = catBets.size

        // 计算连对/连错
        var recent = 0
        var curStreak = 0
        var maxHit = 0
        var maxMiss = 0
        catBets.reversed().forEach { b ->
            val isHit = b.status == "中"
            if (curStreak >= 0) {
                if (isHit) { curStreak++; maxHit = maxOf(maxHit, curStreak) }
                else { curStreak = -1; maxMiss = maxOf(maxMiss, 1) }
            } else {
                if (!isHit) { curStreak--; maxMiss = maxOf(maxMiss, -curStreak) }
                else { curStreak = 1; maxHit = maxOf(maxHit, 1) }
            }
        }
        // recentStreak: 正=连对,负=连错
        recent = curStreak

        // 两期/三期滚动窗口率(与共识口径一致:窗口内至少 1 次中 = 对窗口)
        // 与 hit/miss 同样按注统计;内部按结算时序升序已保证。
        val results = catBets.map { if (it.status == "中") "对" else "错" }
        val (w2, w2Hit, w2Miss) = StreakCalc.windowRates(results, 2)
        val (w3, w3Hit, w3Miss) = StreakCalc.windowRates(results, 3)

        return CatBetStats(
            catName = BetCategory.fromId(catName)?.label ?: catName,
            settled = settled,
            hit = hit,
            miss = miss,
            winRate = if (settled > 0) hit.toDouble() / settled else 0.0,
            profit = catBets.sumOf { it.profit },
            recentStreak = recent,
            maxHitStreak = maxHit,
            maxMissStreak = maxMiss,
            twoWindows = w2,
            twoHitRate = if (w2 > 0) w2Hit.toDouble() / w2 else 0.0,
            twoMissRate = if (w2 > 0) w2Miss.toDouble() / w2 else 0.0,
            threeWindows = w3,
            threeHitRate = if (w3 > 0) w3Hit.toDouble() / w3 else 0.0,
            threeMissRate = if (w3 > 0) w3Miss.toDouble() / w3 else 0.0
        )
    }

    /** 判定一注是否命中。组合/数字位置注可含多候选(以 / 、 , 分隔),命中任一即中 */
    private fun judge(category: String, betValue: String, draw: DrawRecord): Boolean {
        val cands = betValue.split("/", "、", ",").map { it.trim() }.filter { it.isNotEmpty() }
        if (cands.isEmpty()) return false
        return when (BetCategory.fromId(category)) {
            BetCategory.DX -> cands.any { it == draw.dx }
            BetCategory.DS -> cands.any { it == draw.ds }
            BetCategory.COMBO -> cands.any { it == draw.combo }
            BetCategory.NUMBER -> cands.any { cand ->
                val parts = cand.split("=")
                when {
                    // 快乐8 任选：格式「任选号码=12」或纯数字，与开奖任一号码相同即中
                    parts.size == 2 && (parts[0] == "任选号码" || parts[0] == "号码池") -> {
                        val num = parts[1].toIntOrNull() ?: return@any false
                        draw.numbers.any { it == num }
                    }
                    parts.size == 1 -> {
                        val num = parts[0].toIntOrNull() ?: return@any false
                        draw.numbers.any { it == num }
                    }
                    parts.size == 2 -> {
                        val posIdx = PksPositions.NAMES.indexOf(parts[0])
                        if (posIdx < 0) {
                            // 未知位置名：回落为任选号码口径
                            val num = parts[1].toIntOrNull() ?: return@any false
                            draw.numbers.any { it == num }
                        } else {
                            val num = parts[1].toIntOrNull() ?: return@any false
                            draw.numberAt(posIdx) == num
                        }
                    }
                    else -> false
                }
            }
            null -> false
        }
    }

    suspend fun ensureWallet(lotteryKey: String, initialBalance: Double): WalletEntity {
        val existing = dao.getWallet(lotteryKey)
        if (existing != null) return existing
        val w = WalletEntity(lotteryKey = lotteryKey, initialBalance = initialBalance, balance = initialBalance)
        dao.upsertWallet(w)
        return w
    }

    /**
     * 从已结算订单回填各分类最近一次对错,供倍投在进程重启后仍正确延续。
     * 仅在该 lotteryKey 内存缓存为空时执行一次。
     */
    private suspend fun ensureLastHitFromDb(lotteryKey: String) {
        val map = lastHitMap.getOrPut(lotteryKey) { mutableMapOf() }
        if (map.isNotEmpty()) return
        val bets = dao.getBets(lotteryKey)
            .filter { it.status != "待开" }
            .sortedByDescending { it.settledAt ?: it.createdAt }
        for (bet in bets) {
            if (map.containsKey(bet.category)) continue
            map[bet.category] = bet.status == "中"
        }
    }

    /** 清空挂机订单和钱包统计,但保留 bot_config 策略。 */
    suspend fun resetBetOverview(lotteryKey: String, initialBalance: Double = DEFAULT_INITIAL) {
        dao.clearBets(lotteryKey)
        dao.upsertWallet(
            WalletEntity(
                lotteryKey = lotteryKey,
                initialBalance = initialBalance,
                balance = initialBalance,
                updatedAt = System.currentTimeMillis()
            )
        )
        lastHitMap.remove(lotteryKey)
        stageRoundLocks.remove(lotteryKey)
    }

    /**
     * 仅清空订单历史。待开单会把已扣本金退回钱包,避免「清历史吞掉待开本金」。
     */
    suspend fun clearBetsRefundPending(lotteryKey: String) {
        val all = dao.getBets(lotteryKey)
        val pendingAmount = all.filter { it.status == "待开" }.sumOf { it.amount }
        dao.clearBets(lotteryKey)
        lastHitMap.remove(lotteryKey)
        stageRoundLocks.remove(lotteryKey)
        if (pendingAmount > 0) {
            val wallet = dao.getWallet(lotteryKey) ?: return
            dao.upsertWallet(
                wallet.copy(
                    balance = wallet.balance + pendingAmount,
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
    }

    // ---- 来源解析 ----

    /** 反投：大小/单双/组合取反；数字（位置号码）保持不变 */
    private fun invertPicks(picks: Map<BetCategory, List<String>>): Map<BetCategory, List<String>> {
        if (picks.isEmpty()) return picks
        val out = mutableMapOf<BetCategory, List<String>>()
        for ((cat, values) in picks) {
            out[cat] = when (cat) {
                BetCategory.DX -> values.map { v ->
                    when (v.trim()) {
                        "大" -> "小"
                        "小" -> "大"
                        else -> v
                    }
                }
                BetCategory.DS -> values.map { v ->
                    when (v.trim()) {
                        "单" -> "双"
                        "双" -> "单"
                        else -> v
                    }
                }
                BetCategory.COMBO -> values.map { v ->
                    when (v.trim()) {
                        "大单" -> "小双"
                        "大双" -> "小单"
                        "小单" -> "大双"
                        "小双" -> "大单"
                        else -> v
                    }
                }
                BetCategory.NUMBER -> values // 号码不取反
            }
        }
        return out
    }

    /**
     * 解析各分类的下注候选值。
     * 返回 Map<分类, 候选列表>:同一分类可有多个候选(组合 TopN / 位置 TopN / 共识多候选),
     * 每个候选各下一注。空值候选会被忽略。
     */
    private fun resolvePicks(
        config: BotConfigEntity,
        prediction: PredictionSnapshot?,
        planPredictions: List<PlanPredictionRecord>,
        consensus: List<ModelConsensus>,
        history: List<DrawRecord> = emptyList()
    ): Map<BetCategory, List<String>> {
        return when (BetSourceType.fromId(config.sourceType)) {
            BetSourceType.COCKPIT, BetSourceType.ALGO -> resolveAlgo(config.numberPosition, prediction)
            BetSourceType.PLAN, BetSourceType.NOVA, BetSourceType.FAVORITE -> {
                val multi = listOf(config.sourceIdDx, config.sourceIdDs, config.sourceIdCombo)
                    .map { it.ifBlank { config.sourceId } }
                    .distinct()
                    .size > 1
                // 多计划 或 用户主动开启滚动：用图表同款现算
                // 收藏计划不再强制滚动，可直接跟随工作台/引擎已生成的计划预测
                if ((config.rollingPredict || multi) && history.size >= 6) {
                    resolveRollingMulti(config, history)
                } else {
                    resolvePlanMulti(config, planPredictions)
                }
            }
            BetSourceType.AUTO_BEST -> {
                val bestId = planPredictions
                    .filter { !it.settled }
                    .groupBy { it.planId }
                    .maxByOrNull { (_, records) -> records.maxOfOrNull { it.scoreAtPredict } ?: Double.NEGATIVE_INFINITY }
                    ?.key
                if (bestId.isNullOrBlank()) emptyMap() else resolvePlan(bestId, planPredictions)
            }
            // 计划引擎共识 / 新计划共识：解析逻辑相同，数据列表由调用方传入对应独立源
            BetSourceType.CONSENSUS, BetSourceType.NOVA_CONSENSUS -> resolveConsensus(consensus)
        }
    }

    private fun resolveAlgo(positionIndex: Int, prediction: PredictionSnapshot?): Map<BetCategory, List<String>> {
        if (prediction == null) return emptyMap()
        val map = mutableMapOf<BetCategory, MutableList<String>>()
        prediction.dx?.direction?.let { map.getOrPut(BetCategory.DX) { mutableListOf() }.add(it) }
        prediction.ds?.direction?.let { map.getOrPut(BetCategory.DS) { mutableListOf() }.add(it) }
        prediction.combo?.direction?.let { map.getOrPut(BetCategory.COMBO) { mutableListOf() }.add(it) }
        val pos = prediction.positions.getOrNull(positionIndex) ?: prediction.positions.firstOrNull()
        if (pos != null) {
            val name = pos.positionName
            if (name == "任选号码" || name == "号码池") {
                // 快乐8：TopN 全部作为任选候选（每号一注或合并一注由上层决定）
                pos.topNumbers.forEach { ns ->
                    map.getOrPut(BetCategory.NUMBER) { mutableListOf() }.add("任选号码=${ns.number}")
                }
            } else {
                pos.topNumbers.firstOrNull()?.number?.let {
                    map.getOrPut(BetCategory.NUMBER) { mutableListOf() }.add("${PksPositions.nameAt(pos.positionIndex)}=$it")
                }
            }
        }
        return map
    }

    /**
     * 计划模型来源:按计划类别解析多候选输出(以 / 、 , 分隔)。
     * - 大小/单双: 单候选
     * - 组合: 多候选「大单/大双」全下
     * - 位置-冠军/亚军/第3: 多候选号码 → 「位置=号码」全下
     * - 号码: 无位置信息无法下注,跳过
     */

    private fun resolvePlanMulti(
        config: BotConfigEntity,
        planPredictions: List<PlanPredictionRecord>
    ): Map<BetCategory, List<String>> {
        val dxId = config.sourceIdDx.ifBlank { config.sourceId }
        val dsId = config.sourceIdDs.ifBlank { config.sourceId }
        val comboId = config.sourceIdCombo.ifBlank { config.sourceId }
        if (dxId == dsId && dsId == comboId) {
            return resolvePlan(config.sourceId, planPredictions)
        }
        val map = mutableMapOf<BetCategory, MutableList<String>>()
        fun take(id: String, only: BetCategory) {
            if (id.isBlank()) return
            resolvePlan(id, planPredictions)[only]?.let { v ->
                map.getOrPut(only) { mutableListOf() }.addAll(v)
            }
        }
        take(dxId, BetCategory.DX)
        take(dsId, BetCategory.DS)
        take(comboId, BetCategory.COMBO)
        return map.mapValues { (_, v) -> v.distinct() }
    }

    private fun resolveRollingMulti(
        config: BotConfigEntity,
        history: List<DrawRecord>
    ): Map<BetCategory, List<String>> {
        val dxId = config.sourceIdDx.ifBlank { config.sourceId }
        val dsId = config.sourceIdDs.ifBlank { config.sourceId }
        val comboId = config.sourceIdCombo.ifBlank { config.sourceId }
        if (dxId == dsId && dsId == comboId) {
            return resolveRollingPlan(config, history)
        }
        val map = mutableMapOf<BetCategory, MutableList<String>>()
        fun take(id: String, only: BetCategory) {
            if (id.isBlank()) return
            val cfg = config.copy(sourceId = id)
            resolveRollingPlan(cfg, history)[only]?.let { v ->
                map.getOrPut(only) { mutableListOf() }.addAll(v)
            }
        }
        take(dxId, BetCategory.DX)
        take(dsId, BetCategory.DS)
        take(comboId, BetCategory.COMBO)
        return map.mapValues { (_, v) -> v.distinct() }
    }

    /**
     * 图表同款滚动现算：NovaPlanAnalytics.predict + 可选反投。
     * 方向与工作台「下一期」现算一致；一期/二期/三期口径由 config.rollingStage 决定轮次追号与倍投期数，
     * 不必开启滚动也能在挂机页切换口径并跟随工作台已有预测（非滚动走 resolvePlanMulti）。
     */
    private fun resolveRollingPlan(
        config: BotConfigEntity,
        history: List<DrawRecord>
    ): Map<BetCategory, List<String>> {
        val planId = config.sourceId
        // 按 lotteryKey 校验，拒绝跨彩种计划
        val type = LotteryConfig.findByKey(config.lotteryKey)?.type
        val plan = (
            if (type != null) {
                LotteryPlanPools.find(planId, type)
                    ?: LotteryPlanPools.findAny(planId)?.takeIf { LotteryPlanPools.belongsTo(it, type) }
            } else {
                LotteryPlanPools.findAny(planId)
            }
        ) ?: return emptyMap()
        val ordered = history.sortedWith(
            compareBy<DrawRecord> { it.issue.toLongOrNull() ?: Long.MIN_VALUE }.thenBy { it.issue }
        )
        val pred = NovaPlanAnalytics.predict(plan, ordered) ?: return emptyMap()
        val invert = config.betMode.equals("reverse", ignoreCase = true)
        val out = if (invert) NovaPlanAnalytics.invertPrediction(plan.playType, pred.output) else pred.output
        val parts = out.split("/", "、", ",").map { it.trim() }.filter { it.isNotEmpty() }
        val map = mutableMapOf<BetCategory, MutableList<String>>()
        when (plan.playType) {
            "名次大小" -> parts.firstOrNull { it == "大" || it == "小" }?.let {
                map[BetCategory.DX] = mutableListOf("名次大小:$it")
            }
            "名次单双" -> parts.firstOrNull { it == "单" || it == "双" }?.let {
                map[BetCategory.DS] = mutableListOf("名次单双:$it")
            }
            "大小", "和值大小", "球大小" -> parts.firstOrNull { it == "大" || it == "小" }?.let {
                map[BetCategory.DX] = mutableListOf(it)
            }
            "单双", "球单双" -> parts.firstOrNull { it == "单" || it == "双" }?.let {
                map[BetCategory.DS] = mutableListOf(it)
            }
            "龙虎" -> parts.firstOrNull { it == "龙" || it == "虎" }?.let {
                // 暂用组合槽承载龙虎（挂机分类勾选「组合」时生效）
                map[BetCategory.COMBO] = mutableListOf(it)
            }
            "组合" -> {
                val combos = parts.filter { it in listOf("大单", "大双", "小单", "小双") }.distinct()
                if (combos.isNotEmpty()) map[BetCategory.COMBO] = combos.toMutableList()
            }
            "位置", "数字", "定位", "三军", "鱼虾蟹" -> {
                val nums = parts.mapNotNull { it.toIntOrNull() }.distinct()
                if (nums.isNotEmpty()) {
                    val posName = when (plan.playType) {
                        "定位" -> "第${plan.positionIndex.coerceIn(0, 5) + 1}球"
                        "位置" -> PksPositions.nameAt(plan.positionIndex.coerceIn(0, 9))
                        "三军", "鱼虾蟹" -> "三军"
                        else -> PksPositions.nameAt(config.numberPosition.coerceIn(0, 9))
                    }
                    map[BetCategory.NUMBER] = nums.map { "$posName=$it" }.toMutableList()
                }
            }
            "长牌" -> {
                if (parts.isNotEmpty()) map[BetCategory.NUMBER] = parts.map { "长牌=$it" }.toMutableList()
            }
        }
        return map
    }

    private fun resolvePlan(planId: String, planPredictions: List<PlanPredictionRecord>): Map<BetCategory, List<String>> {
        // 精确匹配计划ID;每期随机计划会换 ID,找不到时兜底取任意未结算预测
        val matched = planPredictions.filter { it.planId == planId }
        val pool = when {
            matched.any { !it.settled } -> matched.filter { !it.settled }
            matched.isNotEmpty() -> matched
            planPredictions.any { !it.settled } -> planPredictions.filter { !it.settled }
            else -> planPredictions
        }
        if (pool.isEmpty()) return emptyMap()

        val map = mutableMapOf<BetCategory, MutableList<String>>()
        // Nova 精确计划：根据 playType/position 元数据解析，保证“新计划池 → 挂机”真正闭环。
        val nova = NovaPlanPool.find(planId)
        if (nova != null) {
            val rec = pool.firstOrNull { it.planId == planId } ?: pool.firstOrNull()
            if (rec != null) {
                val parts = rec.output.split("/", "、", ",").map { it.trim() }.filter { it.isNotEmpty() }
                when (nova.playType) {
                    "大小" -> parts.firstOrNull { it == "大" || it == "小" }?.let { map[BetCategory.DX] = mutableListOf(it) }
                    "单双" -> parts.firstOrNull { it == "单" || it == "双" }?.let { map[BetCategory.DS] = mutableListOf(it) }
                    "组合" -> parts.filter { it in listOf("大单", "大双", "小单", "小双") }.distinct().take(4).let { if (it.isNotEmpty()) map[BetCategory.COMBO] = it.toMutableList() }
                    "位置" -> {
                        val pos = nova.positionIndex.coerceIn(0, PksPositions.NAMES.lastIndex)
                        val name = PksPositions.nameAt(pos)
                        val nums = parts.mapNotNull { it.toIntOrNull() }.distinct()
                        if (nums.isNotEmpty()) map[BetCategory.NUMBER] = nums.map { "$name=$it" }.toMutableList()
                    }
                    "数字" -> {
                        // 数字计划没有固定位置；仅当挂机已选择位置时下注该位置的候选。
                        val pos = PksPositions.nameAt(0)
                        val nums = parts.mapNotNull { it.toIntOrNull() }.distinct()
                        if (nums.isNotEmpty()) map[BetCategory.NUMBER] = nums.map { "$pos=$it" }.toMutableList()
                    }
                    // v2.6.2: 直选单式（前三/中三/后三）——预测输出为3位数字组合（如"345"）
                    // 每组3位数作为一注，挂机时注数跟随计划预测的组合数量
                    "直选前三", "直选中三", "直选后三" -> {
                        val combos = parts.filter { it.length == 3 && it.all { c -> c.isDigit() } }
                        if (combos.isNotEmpty()) map[BetCategory.NUMBER] = combos.toMutableList()
                    }
                }
            }
            if (map.isNotEmpty()) return map
        }
        // 同一分类取一条(优先匹配 planId 的)
        val byCat = pool.groupBy { it.category.ifBlank { "大小" } }
        for ((cat, list) in byCat) {
            val rec = list.firstOrNull { it.planId == planId } ?: list.first()
            val parts = rec.output.split("/", "、", ",").map { it.trim() }.filter { it.isNotEmpty() }
            if (parts.isEmpty()) continue
            when (cat) {
                "大小" -> {
                    val dir = parts.firstOrNull { it == "大" || it == "小" }
                    if (dir != null) map[BetCategory.DX] = mutableListOf(dir)
                }
                "单双" -> {
                    val dir = parts.firstOrNull { it == "单" || it == "双" }
                    if (dir != null) map[BetCategory.DS] = mutableListOf(dir)
                }
                "组合" -> parts.forEach {
                    if (it in listOf("大单", "大双", "小单", "小双")) {
                        map.getOrPut(BetCategory.COMBO) { mutableListOf() }.add(it)
                    }
                }
                "位置-冠军", "位置-亚军", "位置-第3" -> {
                    val pos = when (cat) {
                        "位置-冠军" -> 0
                        "位置-亚军" -> 1
                        else -> 2
                    }
                    val name = PksPositions.nameAt(pos)
                    parts.forEach { num ->
                        num.toIntOrNull()?.let { map.getOrPut(BetCategory.NUMBER) { mutableListOf() }.add("$name=$it") }
                    }
                }
                else -> parts.forEach { p ->
                    when (p) {
                        in listOf("大单", "大双", "小单", "小双") -> map.getOrPut(BetCategory.COMBO) { mutableListOf() }.add(p)
                        in listOf("大", "小") -> map.getOrPut(BetCategory.DX) { mutableListOf() }.add(p)
                        in listOf("单", "双") -> map.getOrPut(BetCategory.DS) { mutableListOf() }.add(p)
                    }
                }
            }
        }
        return map
    }

    /**
     * 共识来源。
     * - 大小/单双:只取该分类一条共识的主方向(禁止同时下大+小 / 单+双,否则必中、倍投失效)
     * - 组合:可多候选合并一注,赔率按覆盖数递减
     * - 位置:多号码合并为数字注
     */
    private fun resolveConsensus(consensus: List<ModelConsensus>): Map<BetCategory, List<String>> {
        val map = mutableMapOf<BetCategory, MutableList<String>>()
        // 每个分类只处理第一条共识(已是加权领先方向)
        val byCat = consensus.groupBy { it.category }
        for ((cat, list) in byCat) {
            val c = list.first()
            val cands = c.leadingDirection.split("/", "、", ",")
                .map { it.trim() }.filter { it.isNotEmpty() }
            when (cat) {
                "大小" -> {
                    val dir = cands.firstOrNull { it == "大" || it == "小" } ?: continue
                    map[BetCategory.DX] = mutableListOf(dir)
                }
                "单双" -> {
                    val dir = cands.firstOrNull { it == "单" || it == "双" } ?: continue
                    map[BetCategory.DS] = mutableListOf(dir)
                }
                "组合" -> {
                    val vals = cands.filter { it in listOf("大单", "大双", "小单", "小双") }.distinct()
                    if (vals.isNotEmpty()) map[BetCategory.COMBO] = vals.toMutableList()
                }
                "位置-冠军" -> {
                    val vals = cands.mapNotNull { n -> n.toIntOrNull()?.let { "冠军=$it" } }.distinct()
                    if (vals.isNotEmpty()) map[BetCategory.NUMBER] = vals.toMutableList()
                }
                "位置-亚军" -> {
                    val vals = cands.mapNotNull { n -> n.toIntOrNull()?.let { "亚军=$it" } }.distinct()
                    if (vals.isNotEmpty()) {
                        map.getOrPut(BetCategory.NUMBER) { mutableListOf() }.addAll(vals)
                    }
                }
                "位置-第3" -> {
                    val vals = cands.mapNotNull { n -> n.toIntOrNull()?.let { "第3=$it" } }.distinct()
                    if (vals.isNotEmpty()) {
                        map.getOrPut(BetCategory.NUMBER) { mutableListOf() }.addAll(vals)
                    }
                }
            }
        }
        return map
    }
}
