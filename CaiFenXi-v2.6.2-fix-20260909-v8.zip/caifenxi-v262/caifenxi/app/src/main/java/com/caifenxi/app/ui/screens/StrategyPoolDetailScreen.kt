package com.caifenxi.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.positionDisplayName
import com.caifenxi.app.domain.model.positionIndexOf
import com.caifenxi.app.domain.strategy.PredictEngineV2
import com.caifenxi.app.domain.strategy.StrategyAnalytics
import com.caifenxi.app.domain.strategy.StrategyBacktestReport
import com.caifenxi.app.domain.strategy.StrategyDefinition
import com.caifenxi.app.domain.strategy.StrategyPool
import com.caifenxi.app.domain.strategy.StrategyPredictionRecord
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.theme.CaiTokens
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min

private enum class StrategyDetailTab(val label: String) {
    DETAIL("计划详情"),
    HISTORY("历史记录"),
    TREND("计划走势"),
    GUIDE("策略攻略")
}

@Composable
fun StrategyPoolDetailScreen(
    vm: MainViewModel,
    planId: String,
    onBack: () -> Unit
) {
    val plan = remember(planId) { StrategyPool.byId(planId) }
    if (plan == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("计划不存在", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                PrimaryButton("返回", onBack, ghost = true)
            }
        }
        return
    }

    val history = vm.history.value
    val lottery = vm.currentLottery.value
    val engine = vm.strategyEngine
    val scope = rememberCoroutineScope()

    val subscribedPlans = engine.subscribedPlans.collectAsState()
    val isSubscribed = planId in subscribedPlans.value

    var selectedStage by remember { mutableStateOf(1) }
    var backtestPeriods by remember { mutableStateOf(200) }
    var backtestStake by remember { mutableStateOf("10") }
    var running by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf(StrategyDetailTab.DETAIL) }
    var historyPage by remember { mutableStateOf(40) }
    var algoWindow by remember { mutableStateOf(0) }
    var winRateWindow by remember { mutableStateOf(20) }

    val reportKey = "${planId}_s${selectedStage}_w${algoWindow}_wr${winRateWindow}"
    val report = engine.backtestReports.collectAsState().value[reportKey]
    val currentPrediction = engine.currentPredictions.collectAsState().value[planId]
    val runtimeMap = engine.runtimeMap.collectAsState()
    val rt = runtimeMap.value[planId]
    val predictionHistory = remember(planId) { engine.getHistory(planId) }

    val latestDraw = vm.latest.value
    val countdown = vm.countdownText.value
    val nextIssue = vm.nextIssueText.value

    fun runBacktest() {
        val stake = backtestStake.toDoubleOrNull() ?: 10.0
        if (history.size < 6) return
        running = true
        scope.launch {
            withContext(Dispatchers.Default) {
                engine.runBacktest(plan, history, backtestPeriods, stake, selectedStage, false, algoWindow, winRateWindow)
                engine.predict(plan, history)
            }
            running = false
        }
    }

    // Auto-run backtest on first load
    LaunchedEffect(planId, selectedStage, algoWindow, winRateWindow, history.size) {
        if (history.size >= 6 && report == null && !running) {
            runBacktest()
        }
    }

    val stageLabel = when (selectedStage) { 2 -> "二期"; 3 -> "三期"; else -> "一期" }
    val pts = report?.points.orEmpty()
    val hits = report?.hits ?: 0
    val misses = report?.misses ?: 0
    val total = hits + misses
    val rate = if (total > 0) hits * 100.0 / total else 0.0

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = CaiTokens.ScreenHPadding, vertical = CaiTokens.S8),
        verticalArrangement = Arrangement.spacedBy(CaiTokens.S8),
        contentPadding = PaddingValues(bottom = CaiTokens.ScreenBottom)
    ) {
        // Header
        item {
            GlobalCard {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    PrimaryButton("<- 返回列表", onBack, ghost = true)
                    Spacer(Modifier.weight(1f))
                    Icon(
                        if (isSubscribed) Icons.Filled.Star else Icons.Filled.StarBorder,
                        contentDescription = "挂机订阅",
                        tint = if (isSubscribed) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.clickable {
                            if (isSubscribed) engine.unsubscribeFromBet(planId)
                            else engine.subscribeToBet(planId)
                        }
                    )
                }
                Text(plan.planName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                CaptionMuted(
                    "${lottery.name} · ${plan.track.label} · ${plan.playType} · 算法${plan.algorithm} · 窗口${plan.window}期 · 回测口径$stageLabel"
                )
            }
        }

        // Latest draw + next issue
        item {
            GlobalCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Column(Modifier.weight(1f)) {
                        CaptionMuted("最新开奖")
                        Text("第${latestDraw?.issue ?: "--"}期", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        val nums = latestDraw?.numbers.orEmpty()
                        if (nums.isNotEmpty()) {
                            Row(
                                Modifier.padding(top = 7.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                nums.take(10).forEach { n ->
                                    Surface(
                                        shape = MaterialTheme.shapes.extraLarge,
                                        color = MaterialTheme.colorScheme.errorContainer
                                    ) {
                                        Text(
                                            n.toString(),
                                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp
                                        )
                                    }
                                }
                            }
                        } else {
                            CaptionMuted("暂无开奖号码")
                        }
                        val dx = latestDraw?.dx
                        val ds = latestDraw?.ds
                        if (dx != null || ds != null) {
                            Text(
                                "大小: ${dx ?: "-"}  单双: ${ds ?: "-"}",
                                fontSize = 12.sp,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        CaptionMuted("下一期")
                        Text(
                            if (nextIssue.isNotBlank() && nextIssue != "-") "第${nextIssue}期" else "等待开奖",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            countdown,
                            modifier = Modifier.padding(top = 5.dp),
                            fontSize = 21.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = { vm.softRefreshLatest() }) {
                        Text("刷新开奖结果")
                    }
                }
                CaptionMuted(
                    if (latestDraw?.drawTime?.isNotBlank() == true)
                        "开奖时间 ${latestDraw.drawTime.take(19).replace('T', ' ')} · 数据实时同步中"
                    else "数据实时同步中"
                )
            }
        }

        // Stage selector + backtest controls
        item {
            GlobalCard {
                Text("回测口径（切换会重算胜率与历史）", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(1 to "一期", 2 to "二期", 3 to "三期").forEach { (s, lab) ->
                        FilterChip(
                            selected = selectedStage == s,
                            onClick = { selectedStage = s },
                            label = { Text(lab) }
                        )
                    }
                }
                CaptionMuted(
                    when (selectedStage) {
                        2 -> "二期轮口径：锁一次预测最多追2期；任一期中=本轮中，两期全挂=本轮挂。"
                        3 -> "三期轮口径：锁一次预测最多追3期；任一期中=本轮中，三期全挂=本轮挂。"
                        else -> "一期：每期独立预测、独立结算。"
                    }
                )
                Spacer(Modifier.height(6.dp))
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(100, 200, 500, 1000, 2000, 5000).forEach { n ->
                        FilterChip(
                            selected = backtestPeriods == n,
                            onClick = { backtestPeriods = n },
                            label = { Text("${n}期") }
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text("预测算法窗口", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(0 to "默认", 100 to "100期", 200 to "200期", 500 to "500期").forEach { (w, lab) ->
                        FilterChip(
                            selected = algoWindow == w,
                            onClick = { algoWindow = w },
                            label = { Text(lab) }
                        )
                    }
                }
                CaptionMuted("贝叶斯融合用最近N期做特征提取（越大越平滑，越小越敏感）")
                TextField(
                    value = backtestStake,
                    onValueChange = { backtestStake = it.filter { c -> c.isDigit() || c == '.' }.take(10) },
                    label = { Text("回测单注金额") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                )
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    PrimaryButton(
                        if (running) "回测中..." else "刷新回测",
                        { runBacktest() },
                        Modifier.weight(1f),
                        enabled = !running && history.size >= 6
                    )
                }
            }
        }

        // Prediction + streak panel
        item {
            GlobalCard(containerColor = MaterialTheme.colorScheme.secondaryContainer) {
                Text(
                    if (selectedStage == 1) "下一期预测" else "下一轮预测结果",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(6.dp))
                if (currentPrediction != null) {
                    Text(
                        currentPrediction.output,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    CaptionMuted("置信度 ${"%.0f".format(currentPrediction.confidence * 100)}%")
                    if (currentPrediction.detail.isNotBlank()) {
                        CaptionMuted(currentPrediction.detail)
                    }
                } else if (history.size >= 5) {
                    val fallback = remember(plan, history.size) {
                        PredictEngineV2.predict(plan, history)?.output
                    }
                    if (fallback != null) {
                        Text(
                            fallback,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        CaptionMuted("实时计算 · window=${plan.window}")
                    } else {
                        CaptionMuted("计算中...")
                    }
                } else {
                    CaptionMuted("历史数据不足")
                }

                // Streak panel
                Spacer(Modifier.height(8.dp))
                if (rt != null) {
                    GlobalCard {
                        Text(
                            "当前 连中${rt.consecutiveHit} / 连挂${rt.consecutiveMiss}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        CaptionMuted("连中/连挂=每期中挂")
                        Spacer(Modifier.height(6.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("历史最大连中：${rt.maxConsecutiveHit}次", fontSize = 13.sp)
                            Text("历史最大连挂：${rt.maxConsecutiveMiss}次", fontSize = 13.sp)
                        }
                        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("近10期胜率：${"%.0f".format(rt.recent10Rate * 100)}%", fontSize = 13.sp)
                            Text("近50期胜率：${"%.0f".format(rt.recent50Rate * 100)}%", fontSize = 13.sp)
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    if (running) "正在按【$stageLabel】重算..."
                    else if (report == null) "尚未回测"
                    else "【$stageLabel】中${hits} 挂${misses} · 胜率 ${"%.2f".format(rate)}%",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    StrategyDetailTab.entries.forEach { t ->
                        FilterChip(
                            selected = tab == t,
                            onClick = { tab = t },
                            label = { Text(t.label) }
                        )
                    }
                }
            }
        }

        // Tab content
        when (tab) {
            StrategyDetailTab.DETAIL -> {
                item { StrategyPlanDetailCard(plan, report, rt) }
                item {
                    StrategyHistoryCard(
                        plan, report, history, predictionHistory,
                        limit = historyPage.coerceAtMost(80),
                        stage = selectedStage,
                        pendingIssue = nextIssue,
                        pendingPrediction = currentPrediction?.output ?: ""
                    )
                }
                item {
                    if ((report?.points?.size ?: 0) > historyPage) {
                        PrimaryButton("加载更多历史", {
                            historyPage = (historyPage + 40).coerceAtMost(report?.points?.size ?: historyPage)
                        }, Modifier.fillMaxWidth(), ghost = true)
                    }
                }
            }
            StrategyDetailTab.HISTORY -> {
                item {
                    StrategyHistoryCard(
                        plan, report, history, predictionHistory,
                        limit = historyPage.coerceAtLeast(40),
                        stage = selectedStage,
                        pendingIssue = nextIssue,
                        pendingPrediction = currentPrediction?.output ?: ""
                    )
                }
                item {
                    PrimaryButton("加载更多历史", {
                        historyPage = (historyPage + 50).coerceAtMost(500)
                    }, Modifier.fillMaxWidth(), ghost = true)
                }
            }
            StrategyDetailTab.TREND -> {
                item { StrategyTrendCard(report, backtestPeriods, { backtestPeriods = it }, { runBacktest() }) }
            }
            StrategyDetailTab.GUIDE -> {
                item { StrategyGuideCard(plan) }
            }
        }

        // Bottom action buttons
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                PrimaryButton(
                    if (isSubscribed) "已添加挂机" else "添加到挂机",
                    {
                        if (isSubscribed) engine.unsubscribeFromBet(planId)
                        else engine.subscribeToBet(planId)
                    },
                    Modifier.weight(1f),
                    ghost = isSubscribed
                )
                PrimaryButton(
                    if (running) "回测中..." else "刷新回测",
                    { runBacktest() },
                    Modifier.weight(1f),
                    enabled = !running && history.size >= 6
                )
            }
            CaptionMuted("添加到挂机：在挂机页「策略池互通区」自动生成下注指令")
        }
    }
}

@Composable
private fun StrategyPlanDetailCard(
    plan: StrategyDefinition,
    report: StrategyBacktestReport?,
    rt: com.caifenxi.app.domain.strategy.StrategyRuntime?
) {
    GlobalCard {
        Text("计划详情", fontWeight = FontWeight.Bold)
        DetailRow("计划ID", plan.planId)
        DetailRow("计划名称", plan.planName)
        DetailRow("轨道", plan.track.label)
        DetailRow("玩法", plan.playType)
        DetailRow("算法", plan.algorithm)
        DetailRow("样本窗口", "${plan.window}期")
        DetailRow("执行周期", "${plan.cyclePeriods}期")
        DetailRow("基准胜率", "${"%.1f".format(plan.baselineValue * 100)}%")
        DetailRow("倍投倍数", "${plan.stageMult}倍")
        if (plan.positionIndex >= 0) {
            DetailRow("位置", positionDisplayName(lottery.type, plan.positionIndex))
        }
        if (plan.supportedTypes.isNotEmpty()) {
            DetailRow("适用彩种", plan.supportedTypes.joinToString("、") { it.name })
        }
        report?.let {
            HorizontalDivider(Modifier.padding(vertical = 6.dp))
            Text("最近回测", fontWeight = FontWeight.SemiBold)
            DetailRow("回测期数", "${it.total}期")
            DetailRow("命中", "${it.hits} / ${it.misses}")
            DetailRow("胜率", "${"%.2f".format(it.hitRate * 100)}%")
            DetailRow("Edge", "${"%.1f".format(it.edge * 100)}%")
            DetailRow("稳定性", "${"%.0f".format(it.stability * 100)}%")
            DetailRow("累计收益", fmtMoney(it.netProfit))
            DetailRow("最大回撤", fmtMoney(it.maxDrawdown))
            DetailRow("峰值", fmtMoney(it.peakProfit))
            DetailRow("谷值", fmtMoney(it.troughProfit))
            DetailRow("最大连中", "${it.maxHitStreak}次")
            DetailRow("最大连挂", "${it.maxMissStreak}次")
            DetailRow("当前连中", "${it.currentHitStreak}次")
            DetailRow("当前连挂", "${it.currentMissStreak}次")
        }
        rt?.let {
            HorizontalDivider(Modifier.padding(vertical = 6.dp))
            Text("运行时统计", fontWeight = FontWeight.SemiBold)
            DetailRow("样本量", "${rt.sampleCount}")
            DetailRow("命中率", rt.hitRatePercent)
            DetailRow("近10期胜率", "${"%.0f".format(rt.recent10Rate * 100)}%")
            DetailRow("近50期胜率", "${"%.0f".format(rt.recent50Rate * 100)}%")
        }
    }
}

@Composable
private fun StrategyHistoryCard(
    plan: StrategyDefinition,
    report: StrategyBacktestReport?,
    history: List<DrawRecord>,
    predictionHistory: List<StrategyPredictionRecord>,
    limit: Int,
    stage: Int,
    pendingIssue: String,
    pendingPrediction: String
) {
    val drawByIssue = remember(history) { history.associateBy { it.issue } }
    val pts = report?.points.orEmpty()

    GlobalCard {
        Text(
            "历史记录（按轮结算）· ${when (stage) { 2 -> "二期追号"; 3 -> "三期追号"; else -> "一期计划" }}",
            fontWeight = FontWeight.Bold
        )
        CaptionMuted("每轮期号连续展示；开奖后自动结算并生成下一期预测。")

        // Pending (next issue) prediction
        if (pendingIssue.isNotBlank() && pendingIssue != "-" && pendingPrediction.isNotBlank()) {
            Row(
                Modifier.fillMaxWidth().padding(vertical = 7.dp),
                verticalAlignment = Alignment.Top
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "${pendingIssue.takeLast(4)} (${plan.playType}(${pendingPrediction})",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text("待开奖", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text(
                    "待开奖",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            HorizontalDivider()
        }

        // Prediction history (from engine)
        if (predictionHistory.isNotEmpty()) {
            predictionHistory.takeLast(minOf(limit, predictionHistory.size)).reversed().forEach { rec ->
                val draw = drawByIssue[rec.targetIssue]
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "第${rec.targetIssue.takeLast(6)} ${rec.playType}(${rec.output})",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        if (draw != null) {
                            Text(
                                "开奖: ${draw.numbers.take(5).joinToString(",")}${if (draw.numbers.size > 5) "..." else ""}",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Text(
                        when {
                            !rec.settled -> "待定"
                            rec.hit == true -> "中"
                            else -> "挂"
                        },
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = when {
                            !rec.settled -> MaterialTheme.colorScheme.primary
                            rec.hit == true -> MaterialTheme.colorScheme.primary
                            else -> MaterialTheme.colorScheme.error
                        }
                    )
                }
            }
            HorizontalDivider()
        }

        if (pts.isEmpty()) {
            CaptionMuted(if (history.size < 6) "历史数据不足，无法回测" else "正在生成历史结算...")
            return@GlobalCard
        }

        // Backtest points history
        data class RoundRow(val points: List<com.caifenxi.app.domain.strategy.StrategyChartPoint>)
        val groups = mutableListOf<RoundRow>()
        var current = mutableListOf<com.caifenxi.app.domain.strategy.StrategyChartPoint>()
        pts.forEach { point ->
            current += point
            if (stage <= 1 || point.hit || current.size >= stage) {
                groups += RoundRow(current.toList())
                current = mutableListOf()
            }
        }
        if (current.isNotEmpty()) groups += RoundRow(current.toList())

        groups.takeLast(limit).asReversed().forEach { row ->
            val first = row.points.first()
            val hitIndex = row.points.indexOfFirst { it.hit }
            val plannedStage = stage.coerceAtLeast(1)
            val actualCount = row.points.size.coerceIn(1, plannedStage)

            val resultText = when {
                hitIndex >= 0 && plannedStage >= 2 -> "中(第${hitIndex + 1}把)"
                hitIndex >= 0 -> "中"
                row.points.size < plannedStage -> "待定"
                else -> "挂(${plannedStage}/${plannedStage})"
            }
            val resultColor = when {
                hitIndex >= 0 -> MaterialTheme.colorScheme.primary
                row.points.size < plannedStage -> MaterialTheme.colorScheme.primary
                else -> MaterialTheme.colorScheme.error
            }

            Row(
                Modifier.fillMaxWidth().padding(vertical = 5.dp),
                verticalAlignment = Alignment.Top
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "${first.issue.takeLast(4)} (${actualCount}/$plannedStage) ${plan.playType}(${first.prediction})",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    // Per-period detail
                    val detail = buildString {
                        repeat(actualCount) { offset ->
                            if (offset > 0) append("   ")
                            val issue = first.issue
                            val n = issue.toLongOrNull()
                            val actualIssue = if (n != null) (n + offset).toString().padStart(issue.length, '0') else issue
                            val point = row.points.firstOrNull { it.issue == actualIssue }
                            val draw = drawByIssue[actualIssue]
                            append(actualIssue.takeLast(4)).append(":")
                            when {
                                point != null && point.hit -> append("中")
                                point != null -> append("挂")
                                draw != null -> append("已开")
                                else -> append("待开")
                            }
                        }
                    }
                    Text(detail, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text(resultText, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = resultColor)
            }
            HorizontalDivider()
        }

        CaptionMuted(
            if (stage >= 2)
                "二期/三期：一轮从连续期号开始，任一期命中即结束并计中；全部计划期数均挂才计挂。"
            else
                "一期：每期独立预测、独立结算。"
        )
    }
}

@Composable
private fun StrategyTrendCard(
    report: StrategyBacktestReport?,
    periods: Int,
    onPeriodsChange: (Int) -> Unit,
    onRun: () -> Unit
) {
    GlobalCard {
        Text("计划走势", fontWeight = FontWeight.Bold)
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf(100, 200, 500, 1000, 2000, 5000).forEach { n ->
                FilterChip(
                    selected = periods == n,
                    onClick = { onPeriodsChange(n) },
                    label = { Text("${n}期") }
                )
            }
        }
        PrimaryButton("刷新走势", onRun, Modifier.fillMaxWidth(), ghost = true)
        if (report == null || report.points.size < 2) {
            CaptionMuted("暂无走势数据")
        } else {
            val points = report.points.takeLast(150)
            val lineColor = MaterialTheme.colorScheme.primary
            Canvas(Modifier.fillMaxWidth().height(180.dp).padding(top = 8.dp)) {
                val minV = points.minOf { it.cumulativeProfit }
                val maxV = points.maxOf { it.cumulativeProfit }
                val range = (maxV - minV).coerceAtLeast(1.0)
                val path = Path()
                points.forEachIndexed { i, p ->
                    val x = if (points.size == 1) 0f else size.width * i / (points.size - 1)
                    val y = size.height - ((p.cumulativeProfit - minV) / range * size.height).toFloat()
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawPath(path = path, color = lineColor, style = Stroke(width = 4f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(points.first().issue.takeLast(6), fontSize = 11.sp)
                Text(points.last().issue.takeLast(6), fontSize = 11.sp)
            }
            DetailRow("累计收益", fmtMoney(report.netProfit))
            DetailRow("最大回撤", fmtMoney(report.maxDrawdown))
            DetailRow("峰值", fmtMoney(report.peakProfit))
            DetailRow("谷值", fmtMoney(report.troughProfit))
        }
    }
}

@Composable
private fun StrategyGuideCard(plan: StrategyDefinition) {
    GlobalCard {
        Text("策略攻略", fontWeight = FontWeight.Bold)
        CaptionMuted("当前策略池计划的计算口径与设计原理。")
        DetailRow("计划类型", plan.playType)
        DetailRow("轨道", plan.track.label)
        DetailRow("计算算法", plan.algorithm)
        DetailRow("历史窗口", "最近 ${plan.window} 期")
        DetailRow("基准概率", "${"%.1f".format(plan.baselineValue * 100)}%")
        DetailRow("倍投倍数", "${plan.stageMult}倍")
        if (plan.positionIndex >= 0) {
            DetailRow("位置", "第${plan.positionIndex + 1}位")
        }
        Text("算法说明", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
        CaptionMuted(
            when (plan.algorithm) {
                "BAYES_FUSION" ->
                    "贝叶斯融合：收集频率/EWMA/马尔可夫/遗漏/趋势5个弱预测器，" +
                    "各自在最近窗口的实际命中率作为权重，加权融合后取概率最大方向。"
                "HEDGE_2" ->
                    "互补对冲：分别预测大小和单双，组合概率=PxP，" +
                    "选高置信度维度作为第一口，互补维度选第二口，形成2口对冲。"
                "EXCLUDE_1" ->
                    "排除最弱：计算4个组合（大单/大双/小单/小双）各自概率，" +
                    "排除概率最低的1个，选其余3个组合。"
                else -> plan.algorithm
            }
        )
        Text("回测规则", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
        CaptionMuted("采用 walk-forward：预测某一期时只使用该期之前的开奖数据；每期独立结算，避免信息泄漏。")
        CaptionMuted("数据完全独立于原有计划引擎，不修改原有 PredictEngine/NovaPlanAnalytics/PlanEngine 代码。")
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        Text(label, modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
        Text(value, modifier = Modifier.weight(1.7f), fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

private fun fmtMoney(v: Double): String = if (v >= 0) "+${"%.2f".format(v)}" else "${"%.2f".format(v)}"
