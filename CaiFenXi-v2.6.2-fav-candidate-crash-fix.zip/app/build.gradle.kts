import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.ksp)
}

android {
    namespace = "com.caifenxi.app"
    compileSdk = 35

    // KSP 配置（Room schema 路径）
    ksp {
        arg("room.schemaLocation", "$projectDir/schemas")
        arg("room.incremental", "true")
    }

    defaultConfig {
        applicationId = "com.caifenxi.app"
        // v2.6.2-fix(v47): 最低兼容提升至 Android 10 (API 29)，彻底放开 WebView 限制
        minSdk = 24
        targetSdk = 35
        versionCode = 51
        versionName = "2.5.3"

        // API Key injected from local.properties or environment variable,
        // never hardcoded in source code.
        val localProps = Properties()
        val localPropsFile = rootProject.file("local.properties")
        if (localPropsFile.exists()) {
            localProps.load(localPropsFile.inputStream())
        }
        buildConfigField(
            "String",
            "LOTTERY_API_KEY",
            "\"${localProps.getProperty("LOTTERY_API_KEY") ?: System.getenv("LOTTERY_API_KEY") ?: ""}\""
        )
    }

    signingConfigs {
        create("release") {
            val ks = rootProject.file("keystore/caifenxi-release.jks")
            if (ks.exists()) {
                // Signing credentials must come from local.properties or environment variables,
                // never hardcoded in build scripts.
                val localProps = Properties()
                val localPropsFile = rootProject.file("local.properties")
                if (localPropsFile.exists()) {
                    localProps.load(localPropsFile.inputStream())
                }
                storeFile = ks
                storePassword = localProps.getProperty("CAIFENXI_STORE_PASSWORD")
                    ?: System.getenv("CAIFENXI_STORE_PASSWORD") ?: ""
                keyAlias = localProps.getProperty("CAIFENXI_KEY_ALIAS")
                    ?: System.getenv("CAIFENXI_KEY_ALIAS") ?: "caifenxi"
                keyPassword = localProps.getProperty("CAIFENXI_KEY_PASSWORD")
                    ?: System.getenv("CAIFENXI_KEY_PASSWORD") ?: ""
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            signingConfig = signingConfigs.getByName("release")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.work.runtime)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons)
    implementation(libs.androidx.navigation.compose)

    implementation(libs.okhttp)
    implementation(libs.okhttp.logging)
    implementation(libs.kotlinx.serialization.json)

    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)

    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.androidx.security.crypto)

    // AI Vision dependencies
    implementation("org.jetbrains.kotlinx:kotlinx-datetime:0.6.0")

    debugImplementation(libs.androidx.compose.ui.tooling)
}
