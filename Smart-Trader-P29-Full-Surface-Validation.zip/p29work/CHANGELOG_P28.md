# Smart Trader P28 — 真实行情与发现/市场职责修复

## 本次不是界面方案，而是针对已安装 APK 实际表现的源码修复

### 1. 修复「发现」与「市场」完全相同
- `DiscoverScreen` 重写为发现/研究入口：
  - 高置信度分析报告
  - 报告后续行情反馈
  - 市场脉动统计
  - 自选观察
  - 强势/弱势异动
  - 高关注品种
  - 市场分类快捷入口
- `MarketScreen` 保留为完整市场扫描：
  - 全量列表
  - 搜索
  - 涨跌/关注度/价格排序
  - 上涨/下跌/活跃/自选过滤
  - 分页加载
- 两个页面不再复用同一 Composable。

### 2. 修复后端 crypto 市场 API 被其他市场拖垮
此前 `/api/v1/markets?market=crypto` 会先执行 `universe.all()`，意味着 SEC 美股、港股、大宗任一 provider 慢/失败，都可能让 crypto 市场接口整体失败。

现在按请求市场隔离：
- crypto → `universe.crypto()`
- us → `universe.us()`
- hk → `universe.hk()`
- commodities → `universe.commodities()`
- 未指定 market 才执行 `universe.all()`

并增加 crypto universe 空结果时保留已有有效缓存的保护。

### 3. 增加真实 Binance 公开行情直连兜底
Android 在真实手机上不能把 `10.0.2.2` 当作开发电脑地址使用；此前后端不可达时会静默保留旧的 10 个默认 Watchlist 品种，导致页面出现 `--` / `+0.00%` 的纸面数据。

现在：
- 后端市场 API 成功 → 使用后端动态市场数据。
- 后端不可达 → crypto 自动读取 Binance 公共 24h ticker。
- 后端返回大量 `--` → crypto 自动切换 Binance 直连。
- Binance 直连返回完整可交易 USDT 市场，而不是固定 10 个品种。
- 分页继续支持加载更多。

### 4. 不再静默掩盖数据失败
市场加载失败时写入 `errorMessage`；只有真实数据成功进入 `markets` 后才清理错误状态。

### 5. 保持分析-only
本次没有增加：
- 下单
- 模拟交易
- 账户连接
- 自动交易
- 交易执行

### 验证
- Backend pytest: **74 passed**
- Backend compileall: **PASS**
- 新增回归测试：crypto 市场接口不会因为 US/HK/commodities provider 失败而失败。
- Android 本地 Gradle 编译未执行成功：当前构建环境无法访问 `services.gradle.org` 下载 Gradle 8.9，因此不能声称 APK 编译通过；应使用 GitHub Actions 继续验证 Kotlin/AGP。
