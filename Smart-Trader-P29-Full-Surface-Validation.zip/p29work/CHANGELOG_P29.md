# Smart Trader P29 — 全量方案落地验收与 UI 可视化补齐

## 本次目标
把已经存在的后端能力真正映射到 Android UI，并建立可验收的“真实数据 / provider 状态 / 分析结果 / 报告目录 / 历史反馈”可视化链路。重点避免把设计文档、默认缓存或未配置数据源显示成已完成能力。

## 已落地
- 「发现」与「市场」保持独立页面：发现负责分析流/异动/观察入口，市场负责全量品种扫描。
- 分析页升级为真实分析驾驶舱：高置信分析流、7 个周期切换、32 类报告目录、报告域筛选。
- 数据与系统页升级：后端连接、Provider 健康、四大市场能力矩阵、市场覆盖统计、实时/非实时状态、产品边界。
- Android 新增读取 `/providers/health`、`/markets/coverage`、`/markets/data-status`、`/market-capabilities`。
- 能力状态遵循 truthful-data：未配置 provider 不显示为“实时可用”。
- WebSocket 初始订阅从固定 3 个币种改为当前市场列表最多 100 个品种，并支持运行中更新订阅。
- 增加 Android 真机/云端后端地址配置：数据与系统页可编辑 Backend URL、保存并重新检测，避免把 `10.0.2.2` 错当成真实手机可达地址。
- 详情页保留：K线/Volume、7周期、指标、超买超卖、结构/背离、双向开仓观察、持仓观察、历史报告反馈、32类报告、AI综合结论、多周期共振、加密衍生品、多交易所一致性。
- 产品继续保持 analysis-only：没有模拟成交、真实下单、交易账户连接。

## 验收结果
- Backend pytest: 74 passed.
- Python compileall: PASS.
- Android Gradle compile: 当前执行环境无法下载 Gradle 8.9（`services.gradle.org` DNS 失败），因此没有虚报 Android 编译成功；应由 GitHub Actions 进行最终 APK 编译验收。
