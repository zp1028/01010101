# P27 Changelog

- Fixed analysis feedback to compare historical reports against a fresh current price.
- Fixed `/analysis-feedback/{symbol}` to use a fresh market observation.
- Fixed home `/analysis-feed` feedback evaluation to use a fresh market observation.
- Added regression test proving a 2% move validates a frozen long report.
- Timeframe switching now refreshes the high-confidence analysis feed.
- Removed unused PortfolioDto/PositionDto from Android read-only client.

## P27.1 Android compile fix
- 修复 `AppState.timeframe` 属性 setter 与 `setTimeframe(tf)` 方法产生的 JVM signature clash。
- 将显式方法重命名为 `changeTimeframe(tf)`，并同步更新 UI 调用点。
- 保留 `timeframe` 属性作为 Compose 状态源，避免破坏现有状态读取。
