# P29 全量方案落地验收矩阵

| 能力 | 后端实现 | Android UI | 交互 | 数据真实性 |
|---|---|---|---|---|
| 加密全量发现 | Binance exchangeInfo / universe | 市场、发现、自选、搜索、分页 | 是 | 真实 provider；离线时明确缓存/不可用 |
| 美股 | SEC ticker/CIK + Yahoo-compatible candles | 市场分类、详情、报告入口、能力状态 | 是 | 行情能力按 provider 状态标识 |
| 港股 | 可配置 HK provider | 市场分类、详情、能力状态 | 是 | 未配置时明确 provider_required |
| 大宗商品 | curated/configurable futures universe + chart | 市场分类、详情、能力状态 | 是 | 非实时能力不冒充实时 |
| K线 | candles endpoint | K线 + volume + MA20/MA50 | 是 | 真实数据或明确不可用 |
| 7周期 | 5m/15m/30m/1h/4h/1d/1w | 发现、分析、详情 | 是 | 切换重新请求/计算 |
| 技术指标 | indicator engine | RSI/MACD/BB/趋势/超买超卖/结构/背离/信号 | 是 | 后端结果 |
| 多周期共振 | mtf endpoint | 详情共振矩阵 | 是 | 后端结果 |
| 双向情景 | advice endpoint | 多单/空单观察区间、失效/目标、理由 | 是 | 分析用途，不执行 |
| 持仓观察 | advice holding section | 详情页 | 是 | 分析用途 |
| AI综合报告 | unified report | 详情页 | 是 | 后端返回；质量标识 |
| 历史分析反馈 | frozen report + feedback | 发现 + 详情 | 是 | 后续价格单独评估，不修改历史报告 |
| 32类报告 | report registry/orchestrator | 详情报告中心 + 分析目录 | 是 | 当前品种/周期逐项检测 |
| 加密衍生品 | funding/OI/ratio/basis/liquidation | 详情 | 是 | public data / unavailable 显示 |
| 多交易所一致性 | Binance/OKX/Bybit adapter | 详情 | 是 | providerCount + per-provider status |
| 实时流 | backend WS | LIVE/WS状态、价格更新 | 是 | 当前列表最多100个订阅 |
| Provider健康 | providers/health | 数据与系统页 | 是 | 实时读取 |
| 市场覆盖 | markets/coverage | 数据与系统页 | 是 | 真实 universe counts |
| 数据能力 | market-capabilities | 数据与系统页 | 是 | truthful capability matrix |
| 模拟/纸面交易 | 不作为产品能力 | 无入口 | — | 明确排除 |
| 下单/账户连接 | 不作为产品能力 | 无入口 | — | 明确排除 |

## 未通过/环境限制
1. Android APK 最终编译必须在 GitHub Actions/可联网 Gradle 环境完成；当前沙箱无法解析 services.gradle.org。
2. 港股实时行情需要配置 `SMART_TRADER_HK_UNIVERSE_URL` 与 `SMART_TRADER_HK_QUOTE_URL`。
3. 美股实时同步行情需要配置 `SMART_TRADER_US_QUOTE_URL`；SEC 只负责发行人/财务数据，不应被标记为实时行情。
4. 大宗商品实时期货行情需要配置对应 quote provider。
5. “全部设计功能”不等于“所有市场 provider 都已配置”：UI 现在会把“已实现能力”和“数据源未配置”分开显示。
