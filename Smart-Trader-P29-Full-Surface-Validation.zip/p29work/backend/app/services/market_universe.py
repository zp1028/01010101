from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any

import httpx


@dataclass(frozen=True, slots=True)
class UniverseItem:
    symbol: str
    name: str
    market: str
    asset_type: str
    venue: str
    currency: str | None = None
    metadata: dict[str, Any] | None = None


class MarketUniverseService:
    """Analysis-only market universe.

    The service separates symbol discovery from realtime subscriptions. This is
    important for large universes: the app can display/search every instrument,
    while realtime streams are opened only for selected/detail/watchlist items.
    """

    COMMODITIES = (
        ("GC=F", "Gold Futures"), ("SI=F", "Silver Futures"),
        ("CL=F", "WTI Crude Oil Futures"), ("BZ=F", "Brent Crude Oil Futures"),
        ("NG=F", "Natural Gas Futures"), ("HG=F", "Copper Futures"),
        ("PL=F", "Platinum Futures"), ("PA=F", "Palladium Futures"),
        ("ZC=F", "Corn Futures"), ("ZS=F", "Soybean Futures"),
        ("ZW=F", "Wheat Futures"), ("KC=F", "Coffee Futures"),
        ("CC=F", "Cocoa Futures"), ("SB=F", "Sugar Futures"),
        ("CT=F", "Cotton Futures"),
    )

    def __init__(self) -> None:
        self._cache: dict[str, tuple[float, list[UniverseItem]]] = {}
        self._ttl = 3600.0

    async def crypto(self) -> list[UniverseItem]:
        cached = self._cached("crypto")
        if cached is not None:
            return cached
        urls = [("https://fapi.binance.com/fapi/v1/exchangeInfo", "futures"), ("https://api.binance.com/api/v3/exchangeInfo", "spot")]
        out: list[UniverseItem] = []
        seen: set[tuple[str, str]] = set()
        async with httpx.AsyncClient(timeout=20) as client:
            for url, market_type in urls:
                try:
                    r = await client.get(url); r.raise_for_status(); data = r.json()
                except Exception:
                    continue
                for item in data.get("symbols", []):
                    if item.get("status") != "TRADING": continue
                    if market_type == "futures" and item.get("contractType") not in {"PERPETUAL", "CURRENT_QUARTER", "NEXT_QUARTER"}: continue
                    key=(item.get("symbol", ""), market_type)
                    if not key[0] or key in seen: continue
                    seen.add(key)
                    out.append(UniverseItem(item["symbol"], item.get("pair", item["symbol"]), "crypto", "crypto", "binance", item.get("quoteAsset"), {"base":item.get("baseAsset"),"contract_type":item.get("contractType","spot"),"market_type":market_type}))
        # If an exchange is temporarily unavailable, keep the last good cache
        # instead of replacing a usable universe with an empty list.
        if not out:
            cached = self._cached("crypto")
            if cached is not None:
                return cached
        return self._put("crypto", out)

    async def us(self) -> list[UniverseItem]:
        cached = self._cached("us")
        if cached is not None:
            return cached
        # SEC's public company ticker master gives an exhaustive public US issuer
        # universe without inventing a hard-coded watchlist. Quote/realtime data
        # is resolved by the configured market-data provider later.
        url = "https://www.sec.gov/files/company_tickers.json"
        headers = {"User-Agent": "SmartTrader/1.0 analysis app contact=local"}
        async with httpx.AsyncClient(timeout=20, headers=headers) as client:
            r = await client.get(url)
            r.raise_for_status()
            data = r.json()
        out = [UniverseItem(
            symbol=v["ticker"], name=v["title"], market="us", asset_type="stock",
            venue="sec", currency="USD", metadata={"cik": str(v["cik_str"]).zfill(10)},
        ) for v in data.values() if v.get("ticker")]
        return self._put("us", out)

    async def hk(self) -> list[UniverseItem]:
        # HK symbol masters vary by vendor. Do not pretend a tiny static list is
        # the full HKEX universe. A production provider can supply a CSV/JSON
        # symbol master through SMART_TRADER_HK_UNIVERSE_URL.
        import os
        url = os.getenv("SMART_TRADER_HK_UNIVERSE_URL", "").strip()
        if not url:
            return []
        cached = self._cached("hk")
        if cached is not None:
            return cached
        async with httpx.AsyncClient(timeout=20) as client:
            r = await client.get(url)
            r.raise_for_status()
            data = r.json()
        out = []
        for x in data if isinstance(data, list) else data.get("items", []):
            symbol = str(x.get("symbol", "")).strip()
            if not symbol:
                continue
            out.append(UniverseItem(
                symbol=symbol, name=x.get("name", symbol), market="hk", asset_type="stock",
                venue=x.get("venue", "hkex"), currency=x.get("currency", "HKD"),
                metadata=x,
            ))
        return self._put("hk", out)

    async def commodities(self) -> list[UniverseItem]:
        """Use a configured futures master when available; otherwise retain the
        curated fallback and mark it as such. No claim of exhaustive coverage is made.
        """
        import os
        url = os.getenv("SMART_TRADER_COMMODITY_UNIVERSE_URL", "").strip()
        if not url:
            return [UniverseItem(s, n, "commodities", "future", "yahoo", "USD", {"universe_source": "curated_fallback"})
                    for s, n in self.COMMODITIES]
        cached = self._cached("commodities")
        if cached is not None:
            return cached
        async with httpx.AsyncClient(timeout=20) as client:
            r = await client.get(url); r.raise_for_status(); data = r.json()
        items = data if isinstance(data, list) else data.get("items", [])
        out = []
        for x in items:
            symbol = str(x.get("symbol", "")).strip()
            if not symbol: continue
            out.append(UniverseItem(symbol, x.get("name", symbol), "commodities", "future",
                                     x.get("venue", "futures"), x.get("currency", "USD"),
                                     {**x, "universe_source": "configured_provider"}))
        return self._put("commodities", out)

    def _cached(self, key: str) -> list[UniverseItem] | None:
        hit = self._cache.get(key)
        if hit and time.monotonic() - hit[0] < self._ttl:
            return hit[1]
        return None

    def _put(self, key: str, value: list[UniverseItem]) -> list[UniverseItem]:
        self._cache[key] = (time.monotonic(), value)
        return value

    async def all(self) -> list[UniverseItem]:
        groups = await __import__("asyncio").gather(self.crypto(), self.us(), self.hk(), self.commodities())
        return [x for g in groups for x in g]
