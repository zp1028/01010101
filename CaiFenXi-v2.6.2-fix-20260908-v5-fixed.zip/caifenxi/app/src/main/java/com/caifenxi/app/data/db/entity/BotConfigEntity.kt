package com.caifenxi.app.data.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

/**
 * 挂机策略配置(每彩种一条)。
 */
@Entity(tableName = "bot_config")
@Serializable
data class BotConfigEntity(
    @PrimaryKey val lotteryKey: String,
    val enabled: Boolean = false,          // 挂机开关
    val sourceType: String = "algo",       // cockpit / algo / plan / auto_best / consensus
    val sourceId: String = "experience",   // 算法 id / 计划 id / "consensus"
    val sourceIdDx: String = "",
    val sourceIdDs: String = "",
    val sourceIdCombo: String = "",
    val categories: String = "大小,单双",   // 逗号分隔:大小,单双,组合,数字
    val numberPosition: Int = 0,           // 数字下注位置(0=冠军 ... 9=第10)
    val amount: Double = 10.0,             // 单注金额
    val winMult: Double = 2.0,              // 命中后倍数(1.0=关闭，默认启用倍投)
    val lossMult: Double = 2.0,             // 未中后倍数(1.0=关闭，默认启用倍投)
    val winMultPeriods: Int = 1,            // 命中后连续倍投期数
    val lossMultPeriods: Int = 3,           // 未中后连续倍投期数（默认 3 期，避免只追 1 轮）
    val maxMult: Int = 1,                   // 最大倍数
    /**
     * 挂机投注方向：forward=正投 / reverse=反投。
     * 反投时大小/单双/组合取反，数字不取反。
     */
    val betMode: String = "forward",
    /** 是否用图表同款滚动现算（仅 plan/nova） */
    val rollingPredict: Boolean = false,
    /** 1/2/3 期口径 */
    val rollingStage: Int = 1,
    val execMode: String = "auto",
    val dispatchToWeb: Boolean = true,
    /** 过关斩将：启用后下注金额只受关数设置控制，不受倍投 winMult/lossMult 影响 */
    val guoguanEnabled: Boolean = false,
    /** 过关斩将基础注额 */
    val guoguanBaseStake: Double = 10.0,
    /** 过关斩将每关递增倍率 */
    val guoguanGateMult: Double = 2.0,
    /** 过关斩将总关卡数 */
    val guoguanTotalGates: Int = 3,
    val updatedAt: Long = System.currentTimeMillis()
)
