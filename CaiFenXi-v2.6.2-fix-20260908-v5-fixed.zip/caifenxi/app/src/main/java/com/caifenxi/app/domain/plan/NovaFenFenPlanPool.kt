package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.LotteryType
import com.caifenxi.app.domain.model.PlanDefinition

/** 谷歌分分彩 / 水管分分彩：和值两面、定位胆、定位大小单双与直选单式计划。 */
object NovaFenFenPlanPool {
    val ALL: List<PlanDefinition> get() = PlanPoolV2.all(LotteryType.GOOGLE_FF) + PlanPoolV2.all(LotteryType.SHUIGUAN_FF)
    val CANDIDATES: List<PlanDefinition> get() = PlanPoolV2.candidates(LotteryType.GOOGLE_FF) + PlanPoolV2.candidates(LotteryType.SHUIGUAN_FF)
    fun find(planId: String): PlanDefinition? = ALL.firstOrNull { it.planId == planId }
}
