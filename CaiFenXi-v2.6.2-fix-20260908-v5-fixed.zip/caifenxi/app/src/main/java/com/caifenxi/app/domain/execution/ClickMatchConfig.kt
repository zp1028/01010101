package com.caifenxi.app.domain.execution

import android.content.Context

/**
 * 网页点击识别配置：自定义玩法文字 + 可选点击区域（相对屏幕百分比）+ CSS Selector 精确标注。
 * 生产执行必须使用 selector 精确匹配；未完成标注时拒绝执行。
 */
object ClickMatchConfig {

    private const val PREFS = "click_match_config"

    data class Profile(
        /** 逻辑键 → 页面真实按钮文字 */
        val labelBig: String = "大",
        val labelSmall: String = "小",
        val labelOdd: String = "单",
        val labelEven: String = "双",
        /** 是否启用区域限制 */
        val regionEnabled: Boolean = false,
        /** 相对视口百分比 0~100 */
        val regionLeft: Int = 0,
        val regionTop: Int = 15,
        val regionRight: Int = 100,
        val regionBottom: Int = 90,
        /** CSS Selector 精确标注（生产执行只允许精确 selector；为空即禁止真实点击） */
        val selectorBig: String = "",
        val selectorSmall: String = "",
        val selectorOdd: String = "",
        val selectorEven: String = "",
        val selectorAmount: String = "",
        val selectorConfirm: String = "",
        val selectorBalance: String = "",
        /** 组合玩法按钮 selector */
        val selectorComboDaDan: String = "",
        val selectorComboDaShuang: String = "",
        val selectorComboXiaoDan: String = "",
        val selectorComboXiaoShuang: String = "",
        /** v2.6.2: 直选单式玩法 selector */
        val selectorDirectSelectInput: String = "",
        val selectorDirectSelectPaste: String = "",
        val selectorDirectSelectAmount: String = "",
        val selectorDirectSelectConfirm: String = "",
        /** 开关：大小单双标注未全部完成时仍允许执行下单 */
        val allowPartialMapping: Boolean = false,
        /** 开关：组合标注未全部完成时仍允许执行下单 */
        val allowPartialComboMapping: Boolean = false
    ) {
        fun mapLabel(logical: String): String = when (logical.trim()) {
            "大" -> labelBig.ifBlank { "大" }
            "小" -> labelSmall.ifBlank { "小" }
            "单" -> labelOdd.ifBlank { "单" }
            "双" -> labelEven.ifBlank { "双" }
            else -> logical
        }

        /** 返回逻辑键→selector 的映射表（供 JS 注入用） */
        fun selectorMap(): Map<String, String> = mapOf(
            "大" to selectorBig,
            "小" to selectorSmall,
            "单" to selectorOdd,
            "双" to selectorEven
        )

        /** 组合玩法 selector 映射表 */
        fun comboSelectorMap(): Map<String, String> = mapOf(
            "大单" to selectorComboDaDan,
            "大双" to selectorComboDaShuang,
            "小单" to selectorComboXiaoDan,
            "小双" to selectorComboXiaoShuang
        )

        /** 根据组合值获取对应 selector */
        fun selectorForCombo(combo: String): String = when (combo.trim()) {
            "大单" -> selectorComboDaDan
            "大双" -> selectorComboDaShuang
            "小单" -> selectorComboXiaoDan
            "小双" -> selectorComboXiaoShuang
            else -> ""
        }

        /** 是否至少存在一个标注（仅用于 UI 展示） */
        fun hasMapping(): Boolean = listOf(
            selectorBig, selectorSmall, selectorOdd, selectorEven,
            selectorAmount, selectorConfirm, selectorBalance,
            selectorComboDaDan, selectorComboDaShuang, selectorComboXiaoDan, selectorComboXiaoShuang,
            selectorDirectSelectInput, selectorDirectSelectPaste, selectorDirectSelectAmount, selectorDirectSelectConfirm
        ).any { it.isNotBlank() }

        /** 是否有组合玩法标注 */
        fun hasComboMapping(): Boolean = comboSelectorMap().values.any { it.isNotBlank() }

        /** 是否有直选单式玩法标注 */
        fun hasDirectSelectMapping(): Boolean = listOf(
            selectorDirectSelectInput, selectorDirectSelectPaste, selectorDirectSelectAmount, selectorDirectSelectConfirm
        ).any { it.isNotBlank() }

        /**
         * 真实网页执行所需的完整动作标注。
         * 余额 selector 仅用于校验，不是点击动作，因此不作为执行门槛。
         */
        fun isCompleteForExecution(): Boolean = executionValidationError() == null

        /**
         * 执行前严格校验标注：六个关键 selector 必须存在且互不重复。
         * 方向 selector 重复时会出现“大/小/单/双点成同一个按钮”的严重误点。
         */
        fun executionValidationError(): String? {
            val required = linkedMapOf(
                "大" to selectorBig,
                "小" to selectorSmall,
                "单" to selectorOdd,
                "双" to selectorEven,
                "金额" to selectorAmount,
                "确认" to selectorConfirm
            )
            // 开关开启时：跳过缺失检查，仅保留重复检查（避免点错按钮）
            if (!allowPartialMapping) {
                val blank = required.filterValues { it.isBlank() }.keys
                if (blank.isNotEmpty()) return "缺少精确标注：${blank.joinToString("/")}"
            }
            val duplicateGroups = required
                .filter { it.value.isNotBlank() }
                .entries.groupBy { it.value.trim() }.values.filter { it.size > 1 }
            if (duplicateGroups.isNotEmpty()) {
                val names = duplicateGroups.joinToString("；") { g -> g.joinToString("/") { it.key } }
                return "精确标注存在重复：$names"
            }
            // 组合标注检查：开关关闭时，有组合下注但 selector 不全则报错
            if (!allowPartialComboMapping) {
                val comboMissing = linkedMapOf(
                    "大单" to selectorComboDaDan,
                    "大双" to selectorComboDaShuang,
                    "小单" to selectorComboXiaoDan,
                    "小双" to selectorComboXiaoShuang
                ).filterValues { it.isBlank() }.keys
                // 仅当存在部分标注（至少1个有值）但不全时才报错
                val hasAnyCombo = comboSelectorMap().values.any { it.isNotBlank() }
                if (hasAnyCombo && comboMissing.isNotEmpty()) {
                    return "组合标注不完整：缺${comboMissing.joinToString("/")}"
                }
            }
            return null
        }
    }

    @Volatile
    private var cached: Profile? = null

    fun load(context: Context): Profile {
        cached?.let { return it }
        val sp = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return Profile(
            labelBig = sp.getString("label_big", "大") ?: "大",
            labelSmall = sp.getString("label_small", "小") ?: "小",
            labelOdd = sp.getString("label_odd", "单") ?: "单",
            labelEven = sp.getString("label_even", "双") ?: "双",
            regionEnabled = sp.getBoolean("region_enabled", false),
            regionLeft = sp.getInt("region_left", 0).coerceIn(0, 100),
            regionTop = sp.getInt("region_top", 15).coerceIn(0, 100),
            regionRight = sp.getInt("region_right", 100).coerceIn(0, 100),
            regionBottom = sp.getInt("region_bottom", 90).coerceIn(0, 100),
            selectorBig = sp.getString("selector_big", "") ?: "",
            selectorSmall = sp.getString("selector_small", "") ?: "",
            selectorOdd = sp.getString("selector_odd", "") ?: "",
            selectorEven = sp.getString("selector_even", "") ?: "",
            selectorAmount = sp.getString("selector_amount", "") ?: "",
            selectorConfirm = sp.getString("selector_confirm", "") ?: "",
            selectorBalance = sp.getString("selector_balance", "") ?: "",
            selectorComboDaDan = sp.getString("selector_combo_dadan", "") ?: "",
            selectorComboDaShuang = sp.getString("selector_combo_dashuang", "") ?: "",
            selectorComboXiaoDan = sp.getString("selector_combo_xiaodan", "") ?: "",
            selectorComboXiaoShuang = sp.getString("selector_combo_xiaoshuang", "") ?: "",
            selectorDirectSelectInput = sp.getString("selector_direct_select_input", "") ?: "",
            selectorDirectSelectPaste = sp.getString("selector_direct_select_paste", "") ?: "",
            selectorDirectSelectAmount = sp.getString("selector_direct_select_amount", "") ?: "",
            selectorDirectSelectConfirm = sp.getString("selector_direct_select_confirm", "") ?: "",
            allowPartialMapping = sp.getBoolean("allow_partial_mapping", false),
            allowPartialComboMapping = sp.getBoolean("allow_partial_combo_mapping", false)
        ).also { cached = it }
    }

    fun save(context: Context, profile: Profile) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("label_big", profile.labelBig.trim().ifBlank { "大" })
            .putString("label_small", profile.labelSmall.trim().ifBlank { "小" })
            .putString("label_odd", profile.labelOdd.trim().ifBlank { "单" })
            .putString("label_even", profile.labelEven.trim().ifBlank { "双" })
            .putBoolean("region_enabled", profile.regionEnabled)
            .putInt("region_left", profile.regionLeft.coerceIn(0, 100))
            .putInt("region_top", profile.regionTop.coerceIn(0, 100))
            .putInt("region_right", profile.regionRight.coerceIn(0, 100))
            .putInt("region_bottom", profile.regionBottom.coerceIn(0, 100))
            .putString("selector_big", profile.selectorBig.trim())
            .putString("selector_small", profile.selectorSmall.trim())
            .putString("selector_odd", profile.selectorOdd.trim())
            .putString("selector_even", profile.selectorEven.trim())
            .putString("selector_amount", profile.selectorAmount.trim())
            .putString("selector_confirm", profile.selectorConfirm.trim())
            .putString("selector_balance", profile.selectorBalance.trim())
            .putString("selector_combo_dadan", profile.selectorComboDaDan.trim())
            .putString("selector_combo_dashuang", profile.selectorComboDaShuang.trim())
            .putString("selector_combo_xiaodan", profile.selectorComboXiaoDan.trim())
            .putString("selector_combo_xiaoshuang", profile.selectorComboXiaoShuang.trim())
            .putString("selector_direct_select_input", profile.selectorDirectSelectInput.trim())
            .putString("selector_direct_select_paste", profile.selectorDirectSelectPaste.trim())
            .putString("selector_direct_select_amount", profile.selectorDirectSelectAmount.trim())
            .putString("selector_direct_select_confirm", profile.selectorDirectSelectConfirm.trim())
            .putBoolean("allow_partial_mapping", profile.allowPartialMapping)
            .putBoolean("allow_partial_combo_mapping", profile.allowPartialComboMapping)
            .apply()
        cached = profile
    }

    fun clearCache() {
        cached = null
    }
}
