package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.LotteryConfig
import com.caifenxi.app.domain.model.LotteryType
import com.caifenxi.app.domain.model.PlanDefinition

/**
 * 彩种 → 计划池 唯一入口，禁止跨彩种混用计划定义。
 */
object LotteryPlanPools {

    private val novaCache = java.util.concurrent.ConcurrentHashMap<LotteryType, List<PlanDefinition>>()
    private val legacyCache = java.util.concurrent.ConcurrentHashMap<LotteryType, List<PlanDefinition>>()
    private val appIndex = java.util.concurrent.ConcurrentHashMap<String, PlanDefinition>()

    private fun indexAppPlans(type: LotteryType) {
        (PlanAppStylePool.basic(type) + PlanAppStylePool.extreme(type)).forEach { appIndex.putIfAbsent(it.planId, it) }
    }

    fun novaPlansFor(type: LotteryType): List<PlanDefinition> = novaCache.getOrPut(type) {
        if (type == LotteryType.OTHER) return@getOrPut emptyList()
        val appCore = PlanAppStylePool.core(type)
        val matrix = when (type) {
            LotteryType.YDH -> NovaYdhPlanPool.ALL
            LotteryType.K3 -> NovaK3PlanPool.ALL
            LotteryType.LUCK20 -> NovaLuck20PlanPool.ALL
            LotteryType.PKS -> NovaPlanPool.ALL
            LotteryType.PC28 -> NovaPc28PlanPool.ALL
            LotteryType.GOOGLE_FF, LotteryType.SHUIGUAN_FF -> NovaFenFenPlanPool.ALL
            LotteryType.OTHER -> emptyList()
        }
        indexAppPlans(type)
        (appCore + matrix).distinctBy { it.planId }
    }

    fun novaPlansFor(config: LotteryConfig): List<PlanDefinition> = novaPlansFor(config.type)

    fun find(planId: String, type: LotteryType): PlanDefinition? {
        if (planId.isBlank()) return null
        val hit = findAny(planId) ?: return null
        return hit.takeIf { belongsTo(it, type) }
    }

    fun findAny(planId: String): PlanDefinition? {
        if (planId.isBlank()) return null
        if (planId.startsWith("APP-") || planId.startsWith("APPX-")) {
            appIndex[planId]?.let { return it }
            LotteryType.entries.forEach { ty ->
                indexAppPlans(ty)
                appIndex[planId]?.let { return it }
            }
        }
        return when {
            planId.startsWith("NOVA-YDH-") -> NovaYdhPlanPool.find(planId)
            planId.startsWith("NOVA-K3-") -> NovaK3PlanPool.find(planId)
            planId.startsWith("NOVA-L20-") -> NovaLuck20PlanPool.find(planId)
            planId.startsWith("NOVA-PC28-") -> NovaPc28PlanPool.find(planId)
            planId.startsWith("NOVA-FF-") -> NovaFenFenPlanPool.find(planId)
            planId.startsWith("NOVA-GEN-") -> null
            planId.startsWith("NOVA-") -> NovaPlanPool.find(planId)
            planId.startsWith("V2-") -> PlanPoolV2.find(planId)
            planId.startsWith("LEGACY-") -> PlanPoolV2.find(planId)
            else -> PlanPool.ALL.find { it.planId == planId }
        }
    }

    fun belongsTo(plan: PlanDefinition, type: LotteryType): Boolean {
        if (plan.supportedTypes.isNotEmpty()) return type in plan.supportedTypes
        if (PlanPool.ALL.any { it.planId == plan.planId }) return true
        val id = plan.planId
        return when (type) {
            LotteryType.YDH -> id.startsWith("NOVA-YDH-") || id.startsWith("NOVA-GEN-YDH") || id.startsWith("APP-YDH") || id.startsWith("APPX-YDH")
            LotteryType.K3 -> id.startsWith("NOVA-K3-") || id.startsWith("NOVA-GEN-K3") || id.startsWith("APP-K3") || id.startsWith("APPX-K3")
            LotteryType.LUCK20 -> id.startsWith("NOVA-L20-") || id.startsWith("NOVA-GEN-LUCK20") || id.startsWith("APP-LUCK20") || id.startsWith("APPX-LUCK20")
            LotteryType.PKS -> (id.startsWith("NOVA-") && !id.startsWith("NOVA-YDH-") && !id.startsWith("NOVA-K3-") && !id.startsWith("NOVA-L20-") && !id.startsWith("NOVA-GEN-YDH") && !id.startsWith("NOVA-GEN-K3") && !id.startsWith("NOVA-GEN-LUCK20")) || id.startsWith("APP-PKS") || id.startsWith("APPX-PKS") || PlanPool.ALL.any { it.planId == id }
            LotteryType.PC28 -> id.startsWith("NOVA-PC28-") || id.startsWith("NOVA-GEN-PC28") || id.startsWith("APP-PC28") || id.startsWith("APPX-PC28")
            LotteryType.GOOGLE_FF, LotteryType.SHUIGUAN_FF -> id.startsWith("NOVA-FF-") || id.startsWith("NOVA-V2-GOOGLE_FF") || id.startsWith("NOVA-V2-SHUIGUAN_FF") || id.startsWith("APP-GOOGLE_FF") || id.startsWith("APPX-GOOGLE_FF") || id.startsWith("APP-SHUIGUAN_FF") || id.startsWith("APPX-SHUIGUAN_FF")
            LotteryType.OTHER -> false
        }
    }

    /**
     * 原计划池是通用方向/号码计划池，不应只在 PKS/幸运20 显示。
     * DrawRecord 会先按当前彩种规则补全 dx/ds/combo，因此原计划可对所有已接入彩种回测。
     */
    fun legacyPlansFor(type: LotteryType): List<PlanDefinition> =
        legacyCache.getOrPut(type) {
            val classic = PlanPool.ALL.filter {
                (it.supportedTypes.isEmpty() || type in it.supportedTypes) &&
                    !it.planId.startsWith("LEGACY-")
            }
            indexAppPlans(type)
            (classic + PlanAppStylePool.basic(type)).distinctBy { it.planId }
        }

    fun defaultNovaId(type: LotteryType): String =
        novaPlansFor(type).firstOrNull()?.planId ?: ""
}
