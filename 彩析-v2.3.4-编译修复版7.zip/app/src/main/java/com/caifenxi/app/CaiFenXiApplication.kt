package com.caifenxi.app

import android.app.Application
import com.caifenxi.app.data.api.LotteryApiClient
import com.caifenxi.app.data.config.ConfigStore
import com.caifenxi.app.data.config.ConsensusStore
import com.caifenxi.app.data.config.LegacyJsonBackup
import com.caifenxi.app.data.config.LegacyJsonImporter
import com.caifenxi.app.data.config.ManualStore
import com.caifenxi.app.data.config.StatStore
import com.caifenxi.app.data.db.CaiDatabase
import com.caifenxi.app.data.db.dao.CustomPlanDao
import com.caifenxi.app.data.repository.DrawRepository
import com.caifenxi.app.domain.engine.BetEngine
import com.caifenxi.app.domain.execution.ExecutorManager
import com.caifenxi.app.service.AutoBetController
import com.caifenxi.app.domain.execution.BetScheduler
import com.caifenxi.app.data.repository.ExecutionRepositoryImpl
import com.caifenxi.app.service.WebViewExecutor
import com.caifenxi.app.domain.execution.ExecutionTaskManager
import com.caifenxi.app.domain.plan.PlanEngine
import com.caifenxi.app.service.AccessibilityExecutor
import com.caifenxi.app.service.SyncScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class CaiFenXiApplication : Application() {
    lateinit var database: CaiDatabase private set
    lateinit var configStore: ConfigStore private set
    lateinit var statStore: StatStore private set
    lateinit var manualStore: ManualStore private set
    lateinit var consensusStore: ConsensusStore private set
    lateinit var apiClient: LotteryApiClient private set
    lateinit var drawRepository: DrawRepository private set
    lateinit var betEngine: BetEngine private set
    /** 全局共享计划引擎:前台 MainViewModel/PlanViewModel 与后台 Worker 共用同一份战绩状态 */
    lateinit var planEngine: PlanEngine private set
    val customPlanDao: CustomPlanDao get() = database.customPlanDao()

    /** 统一执行任务管理器（cmdId/彩种/期号隔离 + 防重复 + 重试/恢复） */
    lateinit var executionTaskManager: ExecutionTaskManager private set
    /** 无障碍执行器（统一 Executor 接口封装，可用性随服务连接动态变化） */
    lateinit var accessibilityExecutor: AccessibilityExecutor private set

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        instance = this
        LegacyJsonBackup.backupOnce(this)
        database = CaiDatabase.getInstance(this)
        configStore = ConfigStore(this)
        statStore = StatStore(database.statDao())
        manualStore = ManualStore(database.manualMarkDao())
        consensusStore = ConsensusStore(database.consensusDao())
        apiClient = LotteryApiClient()
        drawRepository = DrawRepository(apiClient, database.drawDao(), configStore)
        betEngine = BetEngine(database.betDao())
        planEngine = PlanEngine()
        SyncScheduler.schedule(this)

        // 统一执行层：无障碍执行器注册进 ExecutorManager（可用性随服务连接动态判定）
        executionTaskManager = ExecutionTaskManager()
        accessibilityExecutor = AccessibilityExecutor(this)
        ExecutorManager.register(accessibilityExecutor)
        ExecutorManager.register(WebViewExecutor)
        ExecutorManager.setMode("auto")

        // 异步执行旧数据导入
        appScope.launch {
            try {
                LegacyJsonImporter.importOnce(this@CaiFenXiApplication, database)
            } catch (e: Exception) {
                android.util.Log.e("CaiFenXiApplication", "legacy import failed", e)
            }
        }

        // ====== V2.0 生产级执行系统初始化 ======
        val executionRepository = ExecutionRepositoryImpl(database)
        val webViewBetExecutor = com.caifenxi.app.service.WebViewBetExecutor()
        WebViewExecutor.bindShared(webViewBetExecutor)
        // UI 挂载 WebView 后通过 WebViewExecutor.attach 激活；调度器与 ExecutorManager 共用
        val betScheduler = BetScheduler(
            repository = executionRepository,
            webViewExecutor = webViewBetExecutor,
            accessibilityExecutor = accessibilityExecutor
        )
        AutoBetController.init(executionTaskManager, executionRepository, betScheduler)
        betScheduler.start()
        // 恢复崩溃前状态：加载 UNKNOWN 任务到内存（UI层会展示待核实面板）
        appScope.launch {
            val unknowns = executionRepository.findUnknowns()
            if (unknowns.isNotEmpty()) {
                android.util.Log.w("V2.0", "发现 ${unknowns.size} 个待核实订单，已暂停对应彩种执行")
            }
        }

    }

    companion object {
        lateinit var instance: CaiFenXiApplication private set
    }
}
