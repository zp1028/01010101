package com.caifenxi.app.domain.execution

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * 当期工单快照：给网页/挂机 UI 展示，并做「同期不重复点击」。
 */
data class ExecutionTicket(
    val cmdId: String = "",
    val lotteryKey: String = "",
    val issue: String = "",
    val planLabel: String = "",
    val stage: Int = 1,
    val leg: Int = 0,
    val dx: String? = null,
    val ds: String? = null,
    val amountText: String? = null,
    val status: String = "IDLE",
    val message: String = "",
    val balanceBefore: String = "",
    val balanceAfter: String = "",
    val updatedAt: Long = 0L
)

object ExecutionTicketStore {
    private val _ticket = MutableStateFlow(ExecutionTicket())
    val ticket: StateFlow<ExecutionTicket> = _ticket.asStateFlow()

    /** lotteryKey|issue 已成功点击过 */
    private val placedIssues = LinkedHashSet<String>()
    /** 已处理过的 cmdId */
    private val doneCmdIds = LinkedHashSet<String>()
    /** 正在真实执行的彩种/期号；同一期只允许一个真实执行会话。 */
    private val activeIssues = LinkedHashSet<String>()

    @Synchronized
    fun publish(ticket: ExecutionTicket) {
        _ticket.value = ticket
    }

    @Synchronized
    fun updateStatus(
        cmdId: String,
        status: String,
        message: String,
        balanceBefore: String = _ticket.value.balanceBefore,
        balanceAfter: String = _ticket.value.balanceAfter
    ) {
        val cur = _ticket.value
        if (cur.cmdId == cmdId || cmdId.isBlank()) {
            _ticket.value = cur.copy(
                status = status,
                message = message,
                balanceBefore = balanceBefore,
                balanceAfter = balanceAfter,
                updatedAt = System.currentTimeMillis()
            )
        }
        if (status == "SUCCESS" && cur.lotteryKey.isNotBlank() && cur.issue.isNotBlank()) {
            markPlaced(cur.lotteryKey, cur.issue)
        }
        // 仅终态记 done，PENDING/QUEUED/RUNNING 仍可重试/补点
        if (cmdId.isNotBlank() && status in TERMINAL) markCmdDone(cmdId)
    }

    private val TERMINAL = setOf("SUCCESS", "FAILED", "SKIPPED", "EXPIRED", "LEDGER", "CANCELLED")

    @Synchronized
    fun isIssuePlaced(lotteryKey: String, issue: String): Boolean =
        placedIssues.contains("$lotteryKey|$issue")

    @Synchronized
    fun isCmdDone(cmdId: String): Boolean = cmdId.isNotBlank() && doneCmdIds.contains(cmdId)

    @Synchronized
    fun claimIssue(lotteryKey: String, issue: String): Boolean {
        if (lotteryKey.isBlank() || issue.isBlank()) return false
        val key = "$lotteryKey|$issue"
        if (placedIssues.contains(key) || activeIssues.contains(key)) return false
        activeIssues.add(key)
        while (activeIssues.size > 40) activeIssues.remove(activeIssues.first())
        return true
    }

    @Synchronized
    fun releaseIssue(lotteryKey: String, issue: String) {
        if (lotteryKey.isBlank() || issue.isBlank()) return
        activeIssues.remove("$lotteryKey|$issue")
    }

    @Synchronized
    fun isIssueActive(lotteryKey: String, issue: String): Boolean =
        activeIssues.contains("$lotteryKey|$issue")

    @Synchronized
    fun markPlaced(lotteryKey: String, issue: String) {
        val key = "$lotteryKey|$issue"
        activeIssues.remove(key)
        placedIssues.add(key)
        while (placedIssues.size > 80) placedIssues.remove(placedIssues.first())
    }

    @Synchronized
    fun markCmdDone(cmdId: String) {
        if (cmdId.isBlank()) return
        doneCmdIds.add(cmdId)
        while (doneCmdIds.size > 120) doneCmdIds.remove(doneCmdIds.first())
    }

    fun stageLabel(stage: Int, leg: Int): String {
        val name = when (stage) {
            2 -> "二期"
            3 -> "三期"
            else -> "一期"
        }
        return if (stage >= 2) "$name L${leg + 1}" else name
    }
}
