Analysis dual-direction AI: long then short then verdict
