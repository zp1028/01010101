package com.caifenxi.app.service

import android.content.Context
import android.content.Intent
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import com.caifenxi.app.CaiFenXiApplication
import com.caifenxi.app.domain.model.BetSourceType
import com.caifenxi.app.domain.model.UserPrefs
import com.caifenxi.app.util.RuntimeLog
import kotlinx.coroutines.runBlocking

/**
 * 真实自动点击控制器。
 * - 读取内部预测（与悬浮窗同源逻辑）
 * - 按期号去重，避免同一期重复点击
 * - 通过无障碍服务执行点击
 * - 仅在点击成功后写入去重标记，失败可在挂起窗口内重试；超时后可再次自动提交
 */
object AutoBetController {

    // V2.0 执行系统（可选注入）
    @Volatile private var taskManager: com.caifenxi.app.domain.execution.ExecutionTaskManager? = null
    @Volatile private var repository: com.caifenxi.app.domain.execution.ExecutionRepository? = null
    @Volatile private var scheduler: com.caifenxi.app.domain.execution.BetScheduler? = null

    fun init(
        taskManager: com.caifenxi.app.domain.execution.ExecutionTaskManager,
        repository: com.caifenxi.app.domain.execution.ExecutionRepository,
        scheduler: com.caifenxi.app.domain.execution.BetScheduler
    ) {
        this.taskManager = taskManager
        this.repository = repository
        this.scheduler = scheduler
        RuntimeLog.info("AutoBet", "V2 执行系统已注入")
    }

    /** 挂机下单成功后派发 WebView/无障碍执行（去重 + 工单状态） */
    fun dispatchBetCommand(command: com.caifenxi.app.domain.execution.BetCommand) {
        val store = com.caifenxi.app.domain.execution.ExecutionTicketStore
        val dx = command.bets.firstOrNull { it.category == com.caifenxi.app.domain.execution.BetAction.CAT_DX }?.value
        val ds = command.bets.firstOrNull { it.category == com.caifenxi.app.domain.execution.BetAction.CAT_DS }?.value
        store.publish(
            com.caifenxi.app.domain.execution.ExecutionTicket(
                cmdId = command.cmdId,
                lotteryKey = command.lotteryKey,
                issue = command.issue,
                planLabel = command.source.ifBlank { "挂机" },
                stage = command.stage,
                leg = command.leg,
                dx = dx,
                ds = ds,
                amountText = command.amountText,
                status = "QUEUED",
                message = "已入队",
                updatedAt = System.currentTimeMillis()
            )
        )
        if (store.isCmdDone(command.cmdId)) {
            store.updateStatus(command.cmdId, "SKIPPED", "重复指令，已跳过")
            RuntimeLog.warn("AutoBet", "重复 cmdId=${command.cmdId} 跳过")
            return
        }
        if (store.isIssuePlaced(command.lotteryKey, command.issue)) {
            store.updateStatus(command.cmdId, "SKIPPED", "本期已成功点击，防重复")
            RuntimeLog.warn("AutoBet", "同期已下 ${command.lotteryKey}/${command.issue} 跳过")
            return
        }
        val mode = command.options["execMode"] ?: "auto"
        if (mode == "ledger") {
            store.updateStatus(command.cmdId, "LEDGER", "仅记账，未点投注站")
            RuntimeLog.info("AutoBet", "execMode=ledger 不派发执行器")
            return
        }
        when (mode) {
            "webview" -> com.caifenxi.app.domain.execution.ExecutorManager.setMode("webview")
            "accessibility" -> com.caifenxi.app.domain.execution.ExecutorManager.setMode("accessibility")
            else -> com.caifenxi.app.domain.execution.ExecutorManager.setMode("auto")
        }
        // 对账日志：挂机 → 执行（方向/金额与挂机页完全一致）
        RuntimeLog.info(
            "HANG→EXEC",
            "cmdId=${command.cmdId} lottery=${command.lotteryKey} issue=${command.issue} " +
                "stage=${command.stage} leg=${command.leg} " +
                "dx=${dx ?: "-"} ds=${ds ?: "-"} amount=${command.amountText ?: "-"} " +
                "plan=${command.source} mode=$mode"
        )
        val onResult: (com.caifenxi.app.domain.execution.ExecutionResult) -> Unit = { result ->
            val st = when {
                result.success -> "SUCCESS"
                result.errorType == com.caifenxi.app.domain.execution.ExecutionResult.DUPLICATE_COMMAND -> "SKIPPED"
                result.errorType == com.caifenxi.app.domain.execution.ExecutionResult.WEBVIEW_DISCONNECTED -> {
                    // 网页未连接：入队，待 WebView 就绪后自动补点（真正每期自动化）
                    com.caifenxi.app.domain.execution.PendingBetQueue.enqueue(command)
                    "PENDING"
                }
                else -> "FAILED"
            }
            if (st != "PENDING") {
                store.updateStatus(result.cmdId, st, result.message)
            }
            RuntimeLog.info("AutoBet", "执行回执 cmdId=${result.cmdId} success=${result.success} ${result.message}")
        }
        val sched = scheduler
        if (sched != null) {
            val task = com.caifenxi.app.domain.execution.ExecutionTask.fromCommand(command, source = command.source)
            sched.dispatch(task)
            return
        }
        val accepted = com.caifenxi.app.domain.execution.ExecutorManager.execute(command, onResult)
        if (!accepted) {
            // 当前无可用执行器（网页未开/无障碍未开）→ 排队，连接后自动补点
            com.caifenxi.app.domain.execution.PendingBetQueue.enqueue(command)
            RuntimeLog.warn("AutoBet", "无可用执行器，指令已排队 cmdId=${command.cmdId} 等待网页/无障碍就绪")
        }
    }


    private const val PREFS = "auto_bet_runtime"
    private const val KEY_LAST_ISSUE = "last_bet_issue"
    private const val KEY_LAST_LOTTERY = "last_bet_lottery"
    private const val KEY_LAST_HIT = "last_bet_hit"
    private const val KEY_CHASE_USED = "chase_used"
    /** 已连续使用倍投金额的期数（成功点击后 +1；中奖清零） */
    private const val KEY_CHASE_COUNT = "chase_count"
    /** 最近一次「成功点击」的预测（开奖后与实际大小单双比对；失败不写入） */
    private const val KEY_LAST_PRED_ISSUE = "last_pred_issue"
    private const val KEY_LAST_PRED_LOTTERY = "last_pred_lottery"
    private const val KEY_LAST_PRED_DX = "last_pred_dx"
    private const val KEY_LAST_PRED_DS = "last_pred_ds"
    /**
     * 进行中尚未成功的暂存：失败时丢弃，成功时再提交到正式 KEY。
     * chase：pending_chase_action = "set" | "clear" | ""
     */
    private const val KEY_PENDING_CHASE_ACTION = "pending_chase_action"
    private const val KEY_PENDING_PRED_ISSUE = "pending_pred_issue"
    private const val KEY_PENDING_PRED_LOTTERY = "pending_pred_lottery"
    private const val KEY_PENDING_PRED_DX = "pending_pred_dx"
    private const val KEY_PENDING_PRED_DS = "pending_pred_ds"
    /** 挂机实际下单结果（无障碍跟随挂机时只读这份，不读悬浮窗原预测来源） */
    private const val KEY_PLACED_LOTTERY = "placed_pred_lottery"
    private const val KEY_PLACED_ISSUE = "placed_pred_issue"
    private const val KEY_PLACED_DX = "placed_pred_dx"
    private const val KEY_PLACED_DS = "placed_pred_ds"
    private const val KEY_PLACED_COMBO = "placed_pred_combo"
    private const val KEY_PLACED_AT = "placed_pred_at"
    /** 进行中的期号（已提交但尚未成功），防止 READY 回调风暴重复提交 */
    private const val KEY_INFLIGHT_ISSUE = "inflight_bet_issue"
    private const val KEY_INFLIGHT_LOTTERY = "inflight_bet_lottery"
    private const val KEY_INFLIGHT_AT = "inflight_bet_at"
    private const val KEY_BOT_STAGE_PREFIX = "bot_stage_"
    /** 略大于无障碍服务挂起上限 45s，超时后允许同一期再次自动提交 */
    private const val INFLIGHT_TTL_MS = 50_000L

    /**
     * 供悬浮窗展示：上期对错 + 本期将点的金额数字。
     */
    data class AmountStrategyInfo(
        /** null=未知, true=对, false=错 */
        val lastHit: Boolean?,
        val lastHitLabel: String,
        val chaseUsed: Boolean,
        val nextAmountText: String?,
        val nextAmountKind: String,
        val lastPredIssue: String,
        val lastPredDx: String,
        val lastPredDs: String
    )

    /** 是否已开启系统无障碍服务 */
    fun isAccessibilityEnabled(context: Context): Boolean {
        val expected = context.packageName + "/" + AutoBetAccessibilityService::class.java.canonicalName
        val enabled = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabled)
        while (splitter.hasNext()) {
            val item = splitter.next()
            if (item.equals(expected, ignoreCase = true)) return true
            // 部分 ROM 用简写组件名
            if (item.contains(context.packageName, ignoreCase = true) &&
                item.contains("AutoBetAccessibilityService", ignoreCase = true)
            ) {
                return true
            }
        }
        return false
    }

    fun openAccessibilitySettings(context: Context) {
        try {
            context.startActivity(
                Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {
            try {
                context.startActivity(
                    Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) {
            }
        }
    }

    /**
     * 预测 READY 时调用。根据 UserPrefs 决定是否真实点击第三方页面。
     */
    fun onPredictionReady(context: Context, snap: FloatingSnapshot, force: Boolean = false) {
        val app = try {
            CaiFenXiApplication.instance
        } catch (_: Exception) {
            return
        }
        val prefs = app.configStore.loadPrefs()
        // force=true：悬浮窗「开始」手动触发，不依赖自动开关
        if (!force && !prefs.autoClickEnabled) return
        if (!force && snap.status != "READY") return
        if (force && snap.status != "READY" && snap.status != "CALCULATING") {
            // 手动时允许用最后一份快照
        } else if (!force && snap.status != "READY") return
        if (snap.targetIssue.isBlank() || snap.targetIssue == "-") return

        val sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val lastIssue = sp.getString(KEY_LAST_ISSUE, "")
        val lastLottery = sp.getString(KEY_LAST_LOTTERY, "")
        // 已成功执行过的期号：跳过（手动 force 时由 tryNow 先清标记）
        if (snap.targetIssue == lastIssue && snap.lotteryKey == lastLottery) {
            RuntimeLog.info("AutoBet", "期号 ${snap.targetIssue} 已成功点击过，跳过")
            return
        }

        // 进行中且未超时：避免 READY 风暴重复提交；超时后允许失败重试
        if (!force) {
            val inflightIssue = sp.getString(KEY_INFLIGHT_ISSUE, "")
            val inflightLottery = sp.getString(KEY_INFLIGHT_LOTTERY, "")
            val inflightAt = sp.getLong(KEY_INFLIGHT_AT, 0L)
            val inflightAlive = inflightAt > 0L &&
                System.currentTimeMillis() - inflightAt < INFLIGHT_TTL_MS
            if (inflightAlive &&
                snap.targetIssue == inflightIssue &&
                snap.lotteryKey == inflightLottery
            ) {
                RuntimeLog.info("AutoBet", "期号 ${snap.targetIssue} 正在执行/挂起中，跳过重复提交")
                return
            }
            if (!inflightAlive && inflightIssue?.isNotBlank() == true) {
                // 过期 inflight 清理，允许失败后重试；同时丢弃未成功的暂存
                clearPendingAttempt(context)
                clearInflight(context)
            }
        }

        if (!isAccessibilityEnabled(context)) {
            RuntimeLog.warn("AutoBet", "无障碍服务未开启，跳过自动点击（请到系统设置开启「彩析」）")
            return
        }
        val service = AutoBetAccessibilityService.instance
        if (service == null) {
            RuntimeLog.warn("AutoBet", "无障碍服务实例为空：开关已开但进程未连上，请关闭再打开一次服务")
            return
        }

        if (prefs.autoClickSimulateOnly) {
            RuntimeLog.info("AutoBet", "仅模拟模式，跳过真实点击")
            return
        }

        // 跟随挂机：自动触发时必须等下单缓存/待开注单，避免 READY 早到点了旧方向。
        // 手动 tryNow / force 仍允许用 Bot 配置回退。
        if (prefs.autoClickFollowBetSource && !force) {
            val placed = loadPlacedPicks(context, snap.lotteryKey, snap.targetIssue)
                ?: loadPlacedPicksFromDb(snap.lotteryKey, snap.targetIssue)
            if (placed == null) {
                RuntimeLog.info(
                    "AutoBet",
                    "跟随挂机：期号 ${snap.targetIssue} 尚无下单结果，等待挂机下单后再点"
                )
                return
            }
        }

        val (rawDx, rawDs) = resolvePrediction(prefs, snap)
        val reverse = isReverseBetMode(prefs)
        val dx = if (reverse) invertDx(rawDx) else rawDx
        val ds = if (reverse) invertDs(rawDs) else rawDs
        val postActions = com.caifenxi.app.domain.model.AutoClickPostActionsCodec.decode(prefs.autoClickPostActionsJson)
        val A = com.caifenxi.app.domain.model.AutoClickPostAction
        val hasPipelinePred = postActions.any {
            it.type == A.TYPE_PRED_DX || it.type == A.TYPE_PRED_DS || it.type == A.TYPE_PRED_DX_DS
        }
        // 以流水线动作为准：大小/单双可分别开关；无流水线项时回落旧开关
        val wantDx = if (hasPipelinePred) {
            postActions.any { it.enabled && (it.type == A.TYPE_PRED_DX || it.type == A.TYPE_PRED_DX_DS) }
        } else {
            prefs.autoClickDx && prefs.autoExecClickDxDs
        }
        val wantDs = if (hasPipelinePred) {
            postActions.any { it.enabled && (it.type == A.TYPE_PRED_DS || it.type == A.TYPE_PRED_DX_DS) }
        } else {
            prefs.autoClickDs && prefs.autoExecClickDxDs
        }
        val wantCombo = postActions.any { it.enabled && it.type == A.TYPE_COMBO }
        val wantNums = postActions.any { it.enabled && it.type == A.TYPE_PRED_NUMBERS }
        val wantText = postActions.any { it.enabled && it.type == A.TYPE_TEXT && it.text.isNotBlank() }
        val wantAmount = postActions.any { it.enabled && it.type == A.TYPE_BET_AMOUNT }
        val rawCombo = if (wantCombo) resolveCombo(snap, prefs) else null
        val combo = if (reverse) invertCombo(rawCombo) else rawCombo
        val predNumbers = if (wantNums) resolvePredNumbers(snap) else emptyList()

        val doDx = wantDx && !dx.isNullOrBlank()
        val doDs = wantDs && !ds.isNullOrBlank()
        // 金额只预览，不改 chase；成功后再提交倍投状态
        val amountDecision = resolveAmountDecision(context, prefs)
        val amountText = if (wantAmount || prefs.autoInputEnabled) amountDecision.text else null
        if (!doDx && !doDs && amountText.isNullOrBlank() && combo.isNullOrBlank() && predNumbers.isEmpty() && !wantText) {
            RuntimeLog.info("AutoBet", "无有效可点击目标，跳过（检查流水线是否开启大小/单双）")
            return
        }

        val modeLabel = if (reverse) "反投" else "正投"
        RuntimeLog.info(
            "AutoBet",
            "提交自动执行[$modeLabel] 期号=${snap.targetIssue} 大小=${if (doDx) dx else "-"} 单双=${if (doDs) ds else "-"} 金额=${amountText ?: "-"}(${amountDecision.kind}) 组合=${combo ?: "-"} 号码=$predNumbers"
        )

        markInflight(context, snap.targetIssue, snap.lotteryKey)
        // 仅暂存：失败丢弃，成功才写入正式预测与倍投状态
        stashPendingAttempt(
            context,
            issue = snap.targetIssue,
            lotteryKey = snap.lotteryKey,
            dx = if (doDx) dx else null,
            ds = if (doDs) ds else null
        )

        service.performBet(
            dx = if (doDx) dx else null,
            ds = if (doDs) ds else null,
            clickDelayMs = prefs.autoClickDelayMs.coerceIn(100L, 3000L),
            amountText = amountText,
            targetIssue = snap.targetIssue,
            lotteryKey = snap.lotteryKey,
            combo = combo,
            predNumbers = predNumbers
        )
    }

    private data class AmountDecision(
        val text: String?,
        val kind: String
    )

    /**
     * 解析本期要点击的金额。连错计数只由 [recordLastHit] 在开奖后维护，点击成功不再改写。
     *
     * - 跟随挂机 + 挂机二期/三期 → 工作台轮次（二期 12 12；三期 124 124）
     * - 否则 → 无障碍倍投期数的一期式 121212
     */
    private fun resolveAmountDecision(context: Context, prefs: UserPrefs): AmountDecision {
        if (!prefs.autoInputEnabled) return AmountDecision(null, "未启用")
        val sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val lastHit = sp.getString(KEY_LAST_HIT, null)
        val base = prefs.autoInputBaseAmount
        val multAmount = prefs.autoInputMultAmount
        val lossStreak = sp.getInt(KEY_CHASE_COUNT, 0).coerceAtLeast(0).let { c ->
            if (c == 0 && sp.getBoolean(KEY_CHASE_USED, false) && lastHit == "0") 1 else c
        }
        val stage = resolveWorkbenchStage(context, prefs)
        if (lastHit != "0") {
            return AmountDecision(
                formatAmount(base),
                if (stage >= 2) "工作台${stage}期·基数" else "复原"
            )
        }
        if (stage >= 2) {
            val leg = lossStreak % stage
            val amount = amountForWorkbenchLeg(base, multAmount, leg)
            val label = if (leg == 0) "工作台${stage}期·轮首" else "工作台${stage}期·第${leg + 1}腿"
            return AmountDecision(formatAmount(amount), label)
        }
        val chaseMax = prefs.autoInputChaseMax.coerceIn(1, 20)
        val pos = (lossStreak - 1).coerceAtLeast(0) % (chaseMax + 1)
        return if (pos < chaseMax) {
            AmountDecision(formatAmount(multAmount), "倍投(${pos + 1}/$chaseMax)")
        } else {
            AmountDecision(formatAmount(base), "复原(间隔)")
        }
    }

    /** 跟随挂机时用挂机 rollingStage；否则 1=一期口径 */
    private fun resolveWorkbenchStage(context: Context, prefs: UserPrefs): Int {
        if (!prefs.autoClickFollowBetSource) return 1
        val lotteryKey = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_LAST_PRED_LOTTERY, null)
            ?: context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_PLACED_LOTTERY, null)
            ?: return 1
        // 优先内存缓存的 bot 配置；后台可读库
        loadBotSource(context, lotteryKey) // 触达缓存
        return try {
            if (Looper.myLooper() == Looper.getMainLooper()) {
                // 主线程不查库：尝试从 DataSync 已写入的 cache 旁路 — 用 SharedPreferences 备份 stage
                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .getInt(KEY_BOT_STAGE_PREFIX + lotteryKey, 1).coerceIn(1, 3)
            } else {
                val st = runBlocking {
                    val cfg = CaiFenXiApplication.instance.database.betDao().getBotConfig(lotteryKey)
                    cfg?.rollingStage?.coerceIn(1, 3) ?: 1
                }
                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                    .putInt(KEY_BOT_STAGE_PREFIX + lotteryKey, st).apply()
                st
            }
        } catch (_: Exception) {
            1
        }
    }

    /** 工作台腿金额：leg0=基数，leg1=倍投数字，leg2=基数*(倍投/基数)^2 … */
    private fun amountForWorkbenchLeg(base: Double, multAmount: Double, leg: Int): Double {
        if (leg <= 0) return base
        val ratio = if (base > 1e-9) (multAmount / base).coerceAtLeast(1.0) else 2.0
        var a = base
        repeat(leg) { a *= ratio }
        return a
    }

    private fun formatAmount(v: Double): String {
        val r = (v * 100).toLong() / 100.0
        return if (r == r.toLong().toDouble()) r.toLong().toString() else "%.2f".format(r)
    }

    /** 执行开始时暂存；仅成功后 commitPendingAttempt */
    private fun stashPendingAttempt(
        context: Context,
        issue: String,
        lotteryKey: String,
        dx: String?,
        ds: String?
    ) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_PENDING_PRED_ISSUE, issue)
            .putString(KEY_PENDING_PRED_LOTTERY, lotteryKey)
            .putString(KEY_PENDING_PRED_DX, dx.orEmpty())
            .putString(KEY_PENDING_PRED_DS, ds.orEmpty())
            .remove(KEY_PENDING_CHASE_ACTION)
            .apply()
        RuntimeLog.info(
            "AutoBet",
            "暂存待提交预测 issue=$issue dx=${dx ?: "-"} ds=${ds ?: "-"}（成功后生效）"
        )
    }

    private fun clearPendingAttempt(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_PENDING_PRED_ISSUE)
            .remove(KEY_PENDING_PRED_LOTTERY)
            .remove(KEY_PENDING_PRED_DX)
            .remove(KEY_PENDING_PRED_DS)
            .remove(KEY_PENDING_CHASE_ACTION)
            .apply()
    }

    /** 流水线成功：提交有效点击预测（供开奖比对）；连错计数不在此改写 */
    private fun commitPendingAttempt(context: Context, issue: String, lotteryKey: String) {
        val sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val pendingIssue = sp.getString(KEY_PENDING_PRED_ISSUE, null)
        if (pendingIssue != null && pendingIssue != issue) {
            RuntimeLog.warn("AutoBet", "成功回调期号与暂存不一致 pending=$pendingIssue success=$issue，仍按成功期提交")
        }
        val predIssue = pendingIssue ?: issue
        val predLottery = sp.getString(KEY_PENDING_PRED_LOTTERY, null) ?: lotteryKey
        val predDx = sp.getString(KEY_PENDING_PRED_DX, "") ?: ""
        val predDs = sp.getString(KEY_PENDING_PRED_DS, "") ?: ""
        sp.edit()
            .putString(KEY_LAST_PRED_ISSUE, predIssue)
            .putString(KEY_LAST_PRED_LOTTERY, predLottery)
            .putString(KEY_LAST_PRED_DX, predDx)
            .putString(KEY_LAST_PRED_DS, predDs)
            .remove(KEY_PENDING_PRED_ISSUE)
            .remove(KEY_PENDING_PRED_LOTTERY)
            .remove(KEY_PENDING_PRED_DX)
            .remove(KEY_PENDING_PRED_DS)
            .remove(KEY_PENDING_CHASE_ACTION)
            .apply()
        RuntimeLog.info(
            "AutoBet",
            "已提交有效预测 issue=$predIssue dx=$predDx ds=$predDs"
        )
    }

    /** 外部在结算后调用：记录上一期对错，供下一期金额策略使用 */
    fun recordLastHit(context: Context, hit: Boolean) {
        val sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val ed = sp.edit().putString(KEY_LAST_HIT, if (hit) "1" else "0")
        if (hit) {
            ed.putInt(KEY_CHASE_COUNT, 0).putBoolean(KEY_CHASE_USED, false)
        } else {
            val cur = sp.getInt(KEY_CHASE_COUNT, 0).coerceAtLeast(0)
            ed.putInt(KEY_CHASE_COUNT, cur + 1).putBoolean(KEY_CHASE_USED, true)
        }
        ed.apply()
        RuntimeLog.info("AutoBet", "记录上期结果 hit=$hit lossStreak=${sp.getInt(KEY_CHASE_COUNT, 0)}")
    }

    /**
     * 用开奖结果与「最近一次无障碍点击的预测」比对，写入上期对错。
     * 优先于挂机注单结算：只要点过大小/单双就会判定，不依赖内部是否下过单。
     *
     * 判定规则：已点击的方向全部与开奖一致才算「对」；任一不符算「错」。
     * 若期号对不上或没有记录过预测，则不改动已有 hit 状态。
     */
    fun recordHitFromDraw(
        context: Context,
        lotteryKey: String,
        issue: String,
        actualDx: String?,
        actualDs: String?
    ) {
        val sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val predIssue = sp.getString(KEY_LAST_PRED_ISSUE, null) ?: return
        val predLottery = sp.getString(KEY_LAST_PRED_LOTTERY, null)
        if (predIssue != issue) return
        if (!predLottery.isNullOrBlank() && predLottery != lotteryKey) return

        val predDx = sp.getString(KEY_LAST_PRED_DX, "").orEmpty()
        val predDs = sp.getString(KEY_LAST_PRED_DS, "").orEmpty()
        var checked = false
        var ok = true
        if (predDx == "大" || predDx == "小") {
            checked = true
            if (actualDx.isNullOrBlank() || actualDx != predDx) ok = false
        }
        if (predDs == "单" || predDs == "双") {
            checked = true
            if (actualDs.isNullOrBlank() || actualDs != predDs) ok = false
        }
        if (!checked) {
            RuntimeLog.info("AutoBet", "开奖比对跳过：无有效点击方向 issue=$issue")
            return
        }
        recordLastHit(context, ok)
        RuntimeLog.info(
            "AutoBet",
            "开奖比对 issue=$issue pred=$predDx/$predDs actual=${actualDx ?: "-"}/${actualDs ?: "-"} => ${if (ok) "对" else "错"}"
        )
    }

    /** 读取当前金额策略状态（悬浮窗展示用，不改 chase 标记） */
    fun getAmountStrategyInfo(context: Context, prefs: UserPrefs): AmountStrategyInfo {
        val sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val hitRaw = sp.getString(KEY_LAST_HIT, null)
        val lastHit = when (hitRaw) {
            "1" -> true
            "0" -> false
            else -> null
        }
        val chaseCount = sp.getInt(KEY_CHASE_COUNT, -1).let { c ->
            if (c >= 0) c else if (sp.getBoolean(KEY_CHASE_USED, false)) 1 else 0
        }
        val chaseUsed = chaseCount > 0
        val decision = resolveAmountDecision(context, prefs)
        return AmountStrategyInfo(
            lastHit = lastHit,
            lastHitLabel = when (lastHit) {
                true -> "对"
                false -> "错"
                null -> "未知"
            },
            chaseUsed = chaseUsed,
            nextAmountText = decision.text,
            nextAmountKind = decision.kind,
            lastPredIssue = sp.getString(KEY_LAST_PRED_ISSUE, "") ?: "",
            lastPredDx = sp.getString(KEY_LAST_PRED_DX, "") ?: "",
            lastPredDs = sp.getString(KEY_LAST_PRED_DS, "") ?: ""
        )
    }

    /**
     * 挂起任务真正执行前刷新金额与倍投动作暂存。
     * 避免「提交时上期未结算 → 挂起期间开奖结算 → 仍按旧金额点击」。
     */
    fun refreshPendingAmountBeforeExecute(context: Context): String? {
        val prefs = try {
            CaiFenXiApplication.instance.configStore.loadPrefs()
        } catch (_: Exception) {
            return null
        }
        if (!prefs.autoInputEnabled) return null
        val decision = resolveAmountDecision(context, prefs)
        RuntimeLog.info(
            "AutoBet",
            "挂起执行前刷新金额=${decision.text ?: "-"} kind=${decision.kind}"
        )
        return decision.text
    }

    fun clearChaseState(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_CHASE_USED, false)
            .putInt(KEY_CHASE_COUNT, 0)
            .apply()
    }

    /**
     * 无障碍流水线执行成功后回调：
     * - 提交暂存的有效预测与倍投状态
     * - 写入「本期已成功」去重标记
     * - 清除 inflight
     * 之后同一期自动路径不再提交；手动 tryNow 可强制重试。
     */
    fun notifyBetSucceeded(context: Context, issue: String, lotteryKey: String) {
        if (issue.isBlank() || issue == "-") return
        commitPendingAttempt(context, issue, lotteryKey)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_LAST_ISSUE, issue)
            .putString(KEY_LAST_LOTTERY, lotteryKey)
            .remove(KEY_INFLIGHT_ISSUE)
            .remove(KEY_INFLIGHT_LOTTERY)
            .remove(KEY_INFLIGHT_AT)
            .apply()
        RuntimeLog.info("AutoBet", "执行成功，已记入去重 期号=$issue 彩种=$lotteryKey")
    }

    /**
     * 挂起超时或明确失败时回调：
     * - 清除 inflight，允许同一期再次自动提交
     * - **丢弃暂存预测与倍投动作**（不消耗 chase、不记为有效预测）
     * 不写入 LAST_ISSUE，因此不算「已成功」。
     */
    fun notifyBetFailedOrTimedOut(context: Context, issue: String?, lotteryKey: String?, reason: String?) {
        val sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val inflightIssue = sp.getString(KEY_INFLIGHT_ISSUE, "")
        if (!issue.isNullOrBlank() && inflightIssue != issue) {
            // 非当前 inflight，忽略（避免旧任务误清）
            return
        }
        clearPendingAttempt(context)
        clearInflight(context)
        RuntimeLog.info(
            "AutoBet",
            "执行未成功，已丢弃暂存预测/倍投并清除进行中标记 期号=${issue ?: "-"} reason=${reason ?: "-"}，允许重试"
        )
    }

    private fun markInflight(context: Context, issue: String, lotteryKey: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_INFLIGHT_ISSUE, issue)
            .putString(KEY_INFLIGHT_LOTTERY, lotteryKey)
            .putLong(KEY_INFLIGHT_AT, System.currentTimeMillis())
            .apply()
    }

    private fun clearInflight(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_INFLIGHT_ISSUE)
            .remove(KEY_INFLIGHT_LOTTERY)
            .remove(KEY_INFLIGHT_AT)
            .apply()
    }

    /** 是否反投模式 */
    fun isReverseBetMode(prefs: UserPrefs): Boolean =
        prefs.autoClickBetMode.equals("reverse", ignoreCase = true)

    fun betModeLabel(prefs: UserPrefs): String =
        if (isReverseBetMode(prefs)) "反投" else "正投"

    /** 大小取反：大↔小 */
    fun invertDx(dx: String?): String? = when (dx?.trim()) {
        "大" -> "小"
        "小" -> "大"
        else -> dx
    }

    /** 单双取反：单↔双 */
    fun invertDs(ds: String?): String? = when (ds?.trim()) {
        "单" -> "双"
        "双" -> "单"
        else -> ds
    }

    /**
     * 组合取反：大单↔小双、大双↔小单。
     * 即大小与单双同时取反。
     */
    fun invertCombo(combo: String?): String? = when (combo?.trim()) {
        "大单" -> "小双"
        "大双" -> "小单"
        "小单" -> "大双"
        "小双" -> "大单"
        else -> combo
    }

    /**
     * 解析实际要点击的方向（已按正投/反投处理）。
     * 面板展示与真实点击共用，避免显示与点击不一致。
     */
    fun resolveClickTargets(prefs: UserPrefs, snap: FloatingSnapshot): Triple<String?, String?, String?> {
        val (rawDx, rawDs) = resolvePrediction(prefs, snap)
        val rawCombo = resolveCombo(snap, prefs)
        return if (isReverseBetMode(prefs)) {
            Triple(invertDx(rawDx), invertDs(rawDs), invertCombo(rawCombo))
        } else {
            Triple(rawDx, rawDs, rawCombo)
        }
    }

    /**
     * 组合预测：跟随挂机时优先用实盘下单缓存，再按 Bot 来源，最后回退悬浮窗快照。
     */
    fun resolveCombo(snap: FloatingSnapshot, prefs: UserPrefs? = null): String? {
        if (prefs?.autoClickFollowBetSource == true) {
            try {
                val ctx = CaiFenXiApplication.instance
                val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                if (sp.getString(KEY_PLACED_LOTTERY, "") == snap.lotteryKey &&
                    sp.getString(KEY_PLACED_ISSUE, "") == snap.targetIssue
                ) {
                    val placedCombo = sp.getString(KEY_PLACED_COMBO, "")?.trim()
                    if (placedCombo in listOf("大单", "大双", "小单", "小双")) return placedCombo
                    // 也可能是多组合用 / 拼接，取第一个合法项
                    placedCombo?.split("/", "、", ",")?.map { it.trim() }
                        ?.firstOrNull { it in listOf("大单", "大双", "小单", "小双") }
                        ?.let { return it }
                }
            } catch (_: Exception) {
            }
            val bot = try { loadBotSource(CaiFenXiApplication.instance, snap.lotteryKey) } catch (_: Exception) { null }
            val type = bot?.let { BetSourceType.fromId(it.first) }
            val candidates = when (type) {
                BetSourceType.NOVA_CONSENSUS -> listOf(snap.novaConsensusCombo, snap.consensusCombo, snap.algoCombo)
                BetSourceType.CONSENSUS -> listOf(snap.consensusCombo, snap.novaConsensusCombo, snap.algoCombo)
                else -> listOf(snap.consensusCombo, snap.novaConsensusCombo, snap.algoCombo)
            }
            for (c in candidates) {
                val t = c?.trim()
                if (t in listOf("大单", "大双", "小单", "小双")) return t
            }
            return null
        }
        val candidates = listOf(snap.consensusCombo, snap.novaConsensusCombo, snap.algoCombo)
        for (c in candidates) {
            val t = c?.trim()
            if (t in listOf("大单", "大双", "小单", "小双")) return t
        }
        return null
    }

    fun resolvePredNumbers(snap: FloatingSnapshot): List<String> {
        return snap.predNumbers.orEmpty()
            .split(",", "、", "/", " ")
            .map { it.trim() }
            .filter { it.toIntOrNull() != null }
            .distinct()
            .take(20)
    }

    /** lotteryKey → (sourceType, sourceId)；由挂机保存/刷新时更新，避免主线程 runBlocking */
    @Volatile
    private var botSourceCache: Pair<String, Pair<String, String>>? = null

    fun updateBotSourceCache(lotteryKey: String, sourceType: String, sourceId: String) {
        if (lotteryKey.isBlank()) return
        botSourceCache = lotteryKey to (sourceType to sourceId)
    }

    /** 挂机保存/同步时写入工作台口径，供无障碍主线程读轮次 */
    fun updateBotStageCache(context: Context, lotteryKey: String, rollingStage: Int) {
        if (lotteryKey.isBlank()) return
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt(KEY_BOT_STAGE_PREFIX + lotteryKey, rollingStage.coerceIn(1, 3))
            .apply()
    }

    fun clearBotSourceCache(lotteryKey: String? = null) {
        val cur = botSourceCache
        if (lotteryKey == null || cur?.first == lotteryKey) botSourceCache = null
    }

    /**
     * 读取当前彩种挂机 Bot 配置的来源类型与 sourceId。
     * - 优先内存缓存
     * - 主线程绝不 runBlocking（会卡顿/ANR）
     * - 后台线程可同步查库并回填缓存
     */
    fun loadBotSource(context: Context, lotteryKey: String): Pair<String, String>? {
        if (lotteryKey.isBlank()) return null
        botSourceCache?.let { (k, v) -> if (k == lotteryKey) return v }
        // 主线程：只返回缓存，不阻塞
        if (Looper.myLooper() == Looper.getMainLooper()) {
            return null
        }
        return try {
            runBlocking {
                val cfg = CaiFenXiApplication.instance.database.betDao().getBotConfig(lotteryKey)
                if (cfg == null) null else {
                    val pair = cfg.sourceType to cfg.sourceId
                    botSourceCache = lotteryKey to pair
                    pair
                }
            }
        } catch (_: Exception) {
            null
        }
    }

    /** 当前无障碍将使用的来源说明（设置页展示） */
    fun describeClickSource(context: Context, prefs: UserPrefs, lotteryKey: String): String {
        if (prefs.autoClickFollowBetSource) {
            val src = loadBotSource(context, lotteryKey)
            if (src != null) {
                val type = BetSourceType.fromId(src.first)
                return "跟随挂机：${type.label}" + if (src.second.isNotBlank() && type in listOf(BetSourceType.PLAN, BetSourceType.NOVA, BetSourceType.FAVORITE)) "（${src.second}）" else ""
            }
            return "跟随挂机：暂无 Bot 配置，回退悬浮窗"
        }
        return when (prefs.floatingSource) {
            "plan" -> "悬浮窗·指定计划"
            "algo" -> "悬浮窗·算法/驾驶舱"
            else -> "悬浮窗·共识"
        }
    }

    /**
     * 挂机下单成功后写入：无障碍「跟随挂机」时只使用这里的方向，
     * 不再回退读悬浮窗算法/共识/计划快照中的「原预测来源」。
     */
    fun recordPlacedPicks(
        context: Context,
        lotteryKey: String,
        targetIssue: String,
        dx: String?,
        ds: String?,
        combo: String? = null
    ) {
        if (lotteryKey.isBlank() || targetIssue.isBlank()) return
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_PLACED_LOTTERY, lotteryKey)
            .putString(KEY_PLACED_ISSUE, targetIssue)
            .putString(KEY_PLACED_DX, dx.orEmpty())
            .putString(KEY_PLACED_DS, ds.orEmpty())
            .putString(KEY_PLACED_COMBO, combo.orEmpty())
            .putLong(KEY_PLACED_AT, System.currentTimeMillis())
            .apply()
        RuntimeLog.info(
            "AutoBet",
            "挂机下单结果已缓存 issue=$targetIssue dx=${dx ?: "-"} ds=${ds ?: "-"} combo=${combo ?: "-"}"
        )
    }

    /** 读取指定目标期的挂机实盘方向；期号不一致则返回 null */
    fun loadPlacedPicks(context: Context, lotteryKey: String, targetIssue: String): Pair<String?, String?>? {
        if (lotteryKey.isBlank() || targetIssue.isBlank()) return null
        val sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (sp.getString(KEY_PLACED_LOTTERY, "") != lotteryKey) return null
        if (sp.getString(KEY_PLACED_ISSUE, "") != targetIssue) return null
        val dx = sp.getString(KEY_PLACED_DX, "")?.takeIf { it == "大" || it == "小" }
        val ds = sp.getString(KEY_PLACED_DS, "")?.takeIf { it == "单" || it == "双" }
        if (dx == null && ds == null) return null
        return dx to ds
    }

    /**
     * 从数据库待开注单解析挂机真实方向（后台线程）；主线程不查库。
     */
    fun loadPlacedPicksFromDb(lotteryKey: String, targetIssue: String): Pair<String?, String?>? {
        if (Looper.myLooper() == Looper.getMainLooper()) return null
        if (lotteryKey.isBlank() || targetIssue.isBlank()) return null
        return try {
            runBlocking {
                val rows = CaiFenXiApplication.instance.database.betDao()
                    .getPendingBets(lotteryKey, targetIssue)
                if (rows.isEmpty()) return@runBlocking null
                val dx = rows.firstOrNull { it.category == "大小" && (it.betValue == "大" || it.betValue == "小") }?.betValue
                val ds = rows.firstOrNull { it.category == "单双" && (it.betValue == "单" || it.betValue == "双") }?.betValue
                if (dx == null && ds == null) null else dx to ds
            }
        } catch (_: Exception) {
            null
        }
    }

    fun resolvePrediction(prefs: UserPrefs, snap: FloatingSnapshot): Pair<String?, String?> {
        val consensusDx = snap.consensusDx?.takeIf { it == "大" || it == "小" }
        val consensusDs = snap.consensusDs?.takeIf { it == "单" || it == "双" }
        val algoDx = snap.algoDx?.takeIf { it == "大" || it == "小" }
        val algoDs = snap.algoDs?.takeIf { it == "单" || it == "双" }
        val novaDx = snap.novaConsensusDx?.takeIf { it == "大" || it == "小" }
        val novaDs = snap.novaConsensusDs?.takeIf { it == "单" || it == "双" }

        fun fromPlanIds(dxId: String, dsId: String): Pair<String?, String?> {
            val dxPlan = snap.plans.firstOrNull { it.planId == dxId && !it.dx.isNullOrBlank() }
            val dsPlan = snap.plans.firstOrNull { it.planId == dsId && !it.ds.isNullOrBlank() }
            var dx = dxPlan?.dx?.split("/", "、", ",")?.firstOrNull { it == "大" || it == "小" }
            var ds = dsPlan?.ds?.split("/", "、", ",")?.firstOrNull { it == "单" || it == "双" }
            if (dx == null) dx = consensusDx ?: algoDx
            if (ds == null) ds = consensusDs ?: algoDs
            return dx to ds
        }

        if (prefs.autoClickFollowBetSource) {
            val ctx = try { CaiFenXiApplication.instance } catch (_: Exception) { null }
            if (ctx != null) {
                // ① 挂机实盘下单缓存（最优先，与挂机页完全一致）
                val fromCache = loadPlacedPicks(ctx, snap.lotteryKey, snap.targetIssue)
                if (fromCache != null) {
                    RuntimeLog.info(
                        "AutoBet",
                        "跟随挂机·下单缓存 issue=${snap.targetIssue} dx=${fromCache.first ?: "-"} ds=${fromCache.second ?: "-"}"
                    )
                    return fromCache
                }
                // ② 数据库待开注单
                val fromDb = loadPlacedPicksFromDb(snap.lotteryKey, snap.targetIssue)
                if (fromDb != null) {
                    recordPlacedPicks(ctx, snap.lotteryKey, snap.targetIssue, fromDb.first, fromDb.second, null)
                    RuntimeLog.info(
                        "AutoBet",
                        "跟随挂机·待开注单 issue=${snap.targetIssue} dx=${fromDb.first ?: "-"} ds=${fromDb.second ?: "-"}"
                    )
                    return fromDb
                }
                // ③ 按挂机 Bot 配置来源解析（收藏/指定计划/共识等），不再误用悬浮窗来源
                val bot = loadBotSource(ctx, snap.lotteryKey)
                if (bot != null) {
                    val (srcType, srcId) = bot
                    val type = BetSourceType.fromId(srcType)
                    val resolved = when (type) {
                        BetSourceType.FAVORITE, BetSourceType.PLAN, BetSourceType.NOVA -> {
                            val id = srcId.ifBlank { prefs.floatingPlanId }
                            fromPlanIds(id, id)
                        }
                        BetSourceType.CONSENSUS -> (consensusDx ?: algoDx) to (consensusDs ?: algoDs)
                        BetSourceType.NOVA_CONSENSUS -> (novaDx ?: consensusDx ?: algoDx) to (novaDs ?: consensusDs ?: algoDs)
                        BetSourceType.COCKPIT, BetSourceType.ALGO -> (algoDx ?: consensusDx) to (algoDs ?: consensusDs)
                        BetSourceType.AUTO_BEST -> {
                            val best = snap.plans.firstOrNull { !it.dx.isNullOrBlank() || !it.ds.isNullOrBlank() }
                            val id = best?.planId.orEmpty().ifBlank { srcId }
                            fromPlanIds(id, id)
                        }
                    }
                    if (resolved.first != null || resolved.second != null) {
                        RuntimeLog.info(
                            "AutoBet",
                            "跟随挂机·Bot配置 type=${type.id} id=$srcId issue=${snap.targetIssue} dx=${resolved.first ?: "-"} ds=${resolved.second ?: "-"}"
                        )
                        return resolved
                    }
                }
            }
            RuntimeLog.warn(
                "AutoBet",
                "跟随挂机但目标期 ${snap.targetIssue} 暂无下单/Bot可解析结果，最后回退悬浮窗来源"
            )
        }

        val selectedDxId = prefs.floatingDxPlanId.ifBlank { prefs.floatingPlanId }
        val selectedDsId = prefs.floatingDsPlanId.ifBlank { prefs.floatingPlanId }
        val dxPlan = snap.plans.firstOrNull { it.planId == selectedDxId && !it.dx.isNullOrBlank() }
        val dsPlan = snap.plans.firstOrNull { it.planId == selectedDsId && !it.ds.isNullOrBlank() }

        var dx: String? = null
        var ds: String? = null

        when (prefs.floatingSource) {
            "plan" -> {
                dx = dxPlan?.dx?.split("/", "、", ",")?.firstOrNull { it == "大" || it == "小" }
                ds = dsPlan?.ds?.split("/", "、", ",")?.firstOrNull { it == "单" || it == "双" }
                if (dx == null) dx = consensusDx ?: algoDx
                if (ds == null) ds = consensusDs ?: algoDs
            }
            "algo" -> {
                dx = algoDx ?: consensusDx
                ds = algoDs ?: consensusDs
            }
            else -> {
                dx = consensusDx ?: algoDx
                ds = consensusDs ?: algoDs
            }
        }
        return dx to ds
    }

    /** 手动立即尝试一次（设置页/悬浮窗按钮用） */
    fun tryNow(context: Context) {
        val snap = FloatingOverlayStore.loadLastReady(context)
            ?: FloatingOverlayStore.load(context)
        if (snap == null) {
            RuntimeLog.warn("AutoBet", "当前无可用预测快照")
            return
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_LAST_ISSUE)
            .remove(KEY_LAST_LOTTERY)
            .remove(KEY_INFLIGHT_ISSUE)
            .remove(KEY_INFLIGHT_LOTTERY)
            .remove(KEY_INFLIGHT_AT)
            .apply()
        onPredictionReady(context, snap.copy(status = "READY"), force = true)
    }

    /**
     * 挂机下单成功后的链路衔接：
     * 若开启「跟随挂机」且本期尚未点击成功，则用刚写入的下单缓存再触发一次无障碍。
     * 解决「预测 READY 早于挂机下单 → 点了旧方向」的竞态。
     */
    fun onHangUpPlaced(context: Context, lotteryKey: String, targetIssue: String) {
        if (lotteryKey.isBlank() || targetIssue.isBlank()) return
        val prefs = try {
            CaiFenXiApplication.instance.configStore.loadPrefs()
        } catch (_: Exception) {
            return
        }
        if (!prefs.autoClickEnabled || !prefs.autoClickFollowBetSource) return
        val sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val lastIssue = sp.getString(KEY_LAST_ISSUE, "")
        val lastLottery = sp.getString(KEY_LAST_LOTTERY, "")
        // 本期已成功点过则不再重复
        if (targetIssue == lastIssue && lotteryKey == lastLottery) {
            RuntimeLog.info("AutoBet", "挂机下单后跳过：期号 $targetIssue 已点击成功")
            return
        }
        val snap = FloatingOverlayStore.loadLastReady(context)
            ?: FloatingOverlayStore.load(context)
        if (snap == null || snap.lotteryKey != lotteryKey) {
            RuntimeLog.info("AutoBet", "挂机下单后无匹配快照，等待下一轮 READY")
            return
        }
        // 清 inflight，允许用下单缓存重提；不清除成功标记
        sp.edit()
            .remove(KEY_INFLIGHT_ISSUE)
            .remove(KEY_INFLIGHT_LOTTERY)
            .remove(KEY_INFLIGHT_AT)
            .apply()
        RuntimeLog.info("AutoBet", "挂机下单完成 → 用下单缓存触发无障碍 issue=$targetIssue")
        onPredictionReady(context, snap.copy(targetIssue = targetIssue, status = "READY"), force = true)
    }
}
