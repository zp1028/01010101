package com.caifenxi.app.domain.execution

import com.caifenxi.app.util.RuntimeLog
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.ArrayDeque

/**
 * 网页/执行器尚未就绪时的挂机指令缓冲队列。
 * 挂机页每期派发 → 若执行器未就绪则入队 → WebView 就绪后 [flush] 自动补点。
 */
object PendingBetQueue {

    private val lock = Any()
    private val queue = ArrayDeque<BetCommand>()
    private const val MAX = 12

    private val _size = MutableStateFlow(0)
    val pendingSize: StateFlow<Int> = _size.asStateFlow()

    private val _lastMsg = MutableStateFlow("")
    val lastMessage: StateFlow<String> = _lastMsg.asStateFlow()

    @Volatile
    var lastFlushMsg: String = ""
        private set

    private fun publishSizeLocked() {
        _size.value = queue.size
    }

    fun enqueue(command: BetCommand) {
        if (command.isExpired) {
            RuntimeLog.warn("PendingBet", "指令已过期，不入队 cmdId=${command.cmdId}")
            return
        }
        if (ExecutionTicketStore.isIssuePlaced(command.lotteryKey, command.issue)) {
            RuntimeLog.info("PendingBet", "本期已成功，跳过入队 ${command.lotteryKey}/${command.issue}")
            return
        }
        synchronized(lock) {
            queue.removeAll {
                it.lotteryKey == command.lotteryKey && it.issue == command.issue
            }
            queue.addLast(command)
            while (queue.size > MAX) queue.removeFirst()
            publishSizeLocked()
        }
        val msg = "执行器未就绪，已排队等待网页连接后自动补点"
        ExecutionTicketStore.updateStatus(command.cmdId, "PENDING", msg)
        _lastMsg.value = msg
        RuntimeLog.info(
            "PendingBet",
            "已入队 cmdId=${command.cmdId} ${command.lotteryKey}/${command.issue} " +
                "金额=${command.amountText} 队列=${size()}"
        )
    }

    fun size(): Int = synchronized(lock) { queue.size }

    fun peekAll(): List<BetCommand> = synchronized(lock) { queue.toList() }

    fun flush(reason: String = "manual"): Int {
        val batch: List<BetCommand>
        synchronized(lock) {
            if (queue.isEmpty()) return 0
            batch = queue.toList()
            queue.clear()
            publishSizeLocked()
        }
        var accepted = 0
        val requeue = mutableListOf<BetCommand>()
        for (cmd in batch) {
            if (cmd.isExpired) {
                ExecutionTicketStore.updateStatus(cmd.cmdId, "EXPIRED", "排队期间指令过期")
                RuntimeLog.warn("PendingBet", "过期丢弃 cmdId=${cmd.cmdId}")
                continue
            }
            if (ExecutionTicketStore.isIssuePlaced(cmd.lotteryKey, cmd.issue)) {
                RuntimeLog.info("PendingBet", "本期已成功，丢弃排队 ${cmd.lotteryKey}/${cmd.issue}")
                continue
            }
            if (ExecutionTicketStore.isCmdDone(cmd.cmdId)) continue
            val ok = ExecutorManager.execute(cmd) { result ->
                val st = when {
                    result.success -> "SUCCESS"
                    result.errorType == ExecutionResult.DUPLICATE_COMMAND -> "SKIPPED"
                    result.errorType == ExecutionResult.WEBVIEW_DISCONNECTED -> {
                        enqueue(cmd)
                        "PENDING"
                    }
                    else -> "FAILED"
                }
                if (st != "PENDING") {
                    ExecutionTicketStore.updateStatus(result.cmdId, st, result.message)
                }
                RuntimeLog.info(
                    "PendingBet",
                    "补点回执 cmdId=${result.cmdId} success=${result.success} ${result.message}"
                )
            }
            if (ok) {
                accepted++
                ExecutionTicketStore.updateStatus(cmd.cmdId, "RUNNING", "排队补点执行中($reason)")
            } else {
                requeue.add(cmd)
            }
        }
        if (requeue.isNotEmpty()) {
            synchronized(lock) {
                requeue.forEach { queue.addLast(it) }
                while (queue.size > MAX) queue.removeFirst()
                publishSizeLocked()
            }
        }
        lastFlushMsg = when {
            accepted > 0 -> "已补点 $accepted 条 ($reason)"
            batch.isNotEmpty() -> "补点未受理，仍排队 ${size()} ($reason)"
            else -> ""
        }
        if (lastFlushMsg.isNotBlank()) {
            _lastMsg.value = lastFlushMsg
            RuntimeLog.info("PendingBet", lastFlushMsg)
        }
        return accepted
    }
}
