/* cfx_inject.js - Core DOM scoring & click logic for GenericSiteAdapter
 * Loaded from assets at runtime, injected via WebView.evaluateJavascript
 * This file contains all __cfx* helper functions and the main __caiFenXiRunCommand entry point
 */

function __cfxNorm(s){ return (s||'').replace(/\s+/g,'').trim(); }
function __cfxVisible(el){
  if(!el||el.disabled) return false;
  var st=window.getComputedStyle(el);
  if(st.display==='none'||st.visibility==='hidden'||parseFloat(st.opacity||'1')===0) return false;
  var r=el.getBoundingClientRect();
  return r.width>8&&r.height>8&&r.bottom>0&&r.top<innerHeight&&r.right>0&&r.left<innerWidth;
}
function __cfxBlob(el){
  var bits=[el.className&&String(el.className), el.id,
    el.getAttribute('data-type'), el.getAttribute('data-play'),
    el.getAttribute('data-name'), el.getAttribute('data-value'),
    el.getAttribute('aria-label'), el.name, el.getAttribute('title')];
  return bits.filter(Boolean).join(' ').toLowerCase();
}
function __cfxPath(el){
  var s='', cur=el, d=0;
  while(cur&&d<6){ s+=' '+__cfxBlob(cur); cur=cur.parentElement; d++; }
  return s.toLowerCase();
}
function __cfxOwnText(el){
  var t='';
  for(var i=0;i<el.childNodes.length;i++){
    var n=el.childNodes[i];
    if(n.nodeType===3) t+=n.nodeValue||'';
  }
  var own=__cfxNorm(t);
  if(own) return own;
  if(el.tagName&&el.tagName.toLowerCase()==='input') return __cfxNorm(el.value||el.getAttribute('value')||'');
  if(!el.children||el.children.length===0) return __cfxNorm(el.innerText||el.textContent||'');
  return '';
}
var __CFX_BET_HINTS=['bet','play','wager','order','touzhu','xz','chip','game-bet','betting','handicap','盘口','投注','下注','玩法','赔率','选号'];
var __CFX_NOISE=['history','record','trend','chart','help','rule','notice','news','draw','open','result','statistic','统计','历史','走势','说明','开奖','记录','规则','公告','新闻','教程','客服','关于'];
function __cfxInRegion(el){
  var R=window.__CFX_REGION;
  if(!R||!R.enabled) return true;
  var r=el.getBoundingClientRect();
  var cx=r.left+r.width/2, cy=r.top+r.height/2;
  var L=innerWidth*(R.left||0)/100, T=innerHeight*(R.top||0)/100;
  var Rt=innerWidth*(R.right||100)/100, B=innerHeight*(R.bottom||100)/100;
  return cx>=L&&cx<=Rt&&cy>=T&&cy<=B;
}
function __cfxScore(el, label){
  if(!__cfxVisible(el)) return -1e9;
  if(!__cfxInRegion(el)) return -1e9;
  var own=__cfxOwnText(el);
  var full=__cfxNorm(el.innerText||el.textContent||'');
  if(own!==label && full!==label){
    var ownHasLabel = own.indexOf(label)>=0 && own.length<=8;
    var labelHasOwn = own.length>0 && label.indexOf(own)>=0;
    if(!ownHasLabel && !labelHasOwn) return -1e9;
  }
  if(full.length>30 && full!==label) return -1e9;
  if(el.children && el.children.length>12) return -1e9;
  var rect=el.getBoundingClientRect();
  var blob=__cfxPath(el);
  var score=0;
  var tag=(el.tagName||'').toLowerCase();
  if(own===label || full===label) score+=50;
  if(tag==='button'||tag==='a') score+=40;
  if(el.getAttribute('role')==='button') score+=30;
  if(typeof el.onclick==='function'||el.hasAttribute('ng-click')||el.hasAttribute('@click')||el.hasAttribute('onclick')) score+=25;
  if(tag==='input'&&/button|submit/.test(el.type||'')) score+=35;
  if(tag==='div'||tag==='span'||tag==='li'||tag==='label'||tag==='p'||tag==='i'||tag==='em') score+=5;
  for(var i=0;i<__CFX_BET_HINTS.length;i++){ if(blob.indexOf(__CFX_BET_HINTS[i])>=0) score+=28; }
  for(var j=0;j<__CFX_NOISE.length;j++){ if(blob.indexOf(__CFX_NOISE[j])>=0) score-=80; }
  var area=rect.width*rect.height;
  if(rect.width>=24&&rect.width<=200&&rect.height>=22&&rect.height<=90) score+=30;
  if(area<180||area>60000) score-=30;
  var cy=rect.top+rect.height/2;
  if(cy>innerHeight*0.18&&cy<innerHeight*0.92) score+=15;
  if(cy<innerHeight*0.12) score-=40;
  if(cy>innerHeight*0.96) score-=20;
  var parent=el.parentElement;
  if(parent){
    var sib=__cfxNorm(parent.innerText||'');
    if(sib.length<=20){
      if((label==='大'||label==='小')&&sib.indexOf('大')>=0&&sib.indexOf('小')>=0) score+=35;
      if((label==='单'||label==='双')&&sib.indexOf('单')>=0&&sib.indexOf('双')>=0) score+=35;
    } else {
      score-=15;
    }
  }
  if(/active|selected|on|checked|current|choose/.test(blob)) score+=8;
  return score;
}
function __cfxFindBest(label){
  var want=__cfxNorm(label);
  var best=null, bestScore=20;
  // Round 1: high-priority elements only (button, a, role=button, input)
  var prioritySelector='button,a,[role=button],input[type=button],input[type=submit],label,li';
  var allNodes=[];
  try{
    allNodes=allNodes.concat(Array.prototype.slice.call(document.querySelectorAll(prioritySelector)));
  }catch(e){}
  // Round 2: if no hit, expand to all tags
  if(!best){
    var expandedSelector='button,a,[role=button],input[type=button],input[type=submit],label,li,span,div,p,i,em';
    try{
      allNodes=allNodes.concat(Array.prototype.slice.call(document.querySelectorAll(expandedSelector)));
    }catch(e){}
    try{
      var frames=document.querySelectorAll('iframe');
      for(var fi=0;fi<frames.length;fi++){
        try{
          var fd=frames[fi].contentDocument||frames[fi].contentWindow.document;
          if(fd){
            allNodes=allNodes.concat(Array.prototype.slice.call(fd.querySelectorAll(expandedSelector)));
          }
        }catch(e){ }
      }
    }catch(e){}
  }
  for(var i=0;i<allNodes.length;i++){
    var el=allNodes[i];
    if(el.closest && el.closest('header,nav,footer,aside')) continue;
    if(!__cfxInRegion(el)) continue;
    var own=__cfxOwnText(el);
    var full=__cfxNorm(el.innerText||el.textContent||'');
    if(want.length>=2){
      if(own!==want && full!==want && !(own.length>0 && want.indexOf(own)>=0) && !(full.length<=20 && full.indexOf(want)>=0)) continue;
      var sc=__cfxScore(el, want);
      if(own===want||full===want) sc+=40;
      if(sc>bestScore){ bestScore=sc; best=el; }
      continue;
    }
    var sc2=__cfxScore(el, want);
    if(sc2>bestScore){ bestScore=sc2; best=el; }
  }
  return best?{el:best,score:bestScore}:null;
}
function __cfxHighlight(el, ok){
  if(!el) return;
  var prev=el.style.outline;
  el.style.outline=ok?'3px solid #00c853':'3px solid #ff1744';
  setTimeout(function(){ el.style.outline=prev; }, 1200);
}
/* 跨 document 查询 selector（主文档 + 同源 iframe） */
function __cfxQuerySelector(sel){
  if(!sel) return null;
  try{
    var el=document.querySelector(sel);
    if(el) return el;
  }catch(e){}
  try{
    var frames=document.querySelectorAll('iframe');
    for(var i=0;i<frames.length;i++){
      try{
        var fd=frames[i].contentDocument||frames[i].contentWindow.document;
        if(fd){
          el=fd.querySelector(sel);
          if(el) return el;
        }
      }catch(e){}
    }
  }catch(e){}
  return null;
}
function __cfxClick(el){
  if(!el) return;
  try{ el.scrollIntoView({block:'center',inline:'center'}); }catch(e){}
  var r = el.getBoundingClientRect();
  var cx = Math.floor(r.left + r.width/2), cy = Math.floor(r.top + r.height/2);
  var o={bubbles:true,cancelable:true,view:window,clientX:cx,clientY:cy,screenX:cx,screenY:cy,button:0,buttons:1};
  try{
    if(typeof PointerEvent === 'function'){
      el.dispatchEvent(new PointerEvent('pointerover',Object.assign({},o,{pointerId:1,pointerType:'touch',isPrimary:true})));
      el.dispatchEvent(new PointerEvent('pointerdown',Object.assign({},o,{pointerId:1,pointerType:'touch',isPrimary:true})));
    }
  }catch(e){}
  try{
    if(typeof TouchEvent === 'function' && typeof Touch === 'function'){
      var touch = new Touch({identifier:1,target:el,clientX:cx,clientY:cy,screenX:cx,screenY:cy,pageX:cx,pageY:cy,radiusX:1,radiusY:1,force:1});
      el.dispatchEvent(new TouchEvent('touchstart',{bubbles:true,cancelable:true,touches:[touch],targetTouches:[touch],changedTouches:[touch]}));
      el.dispatchEvent(new TouchEvent('touchend',{bubbles:true,cancelable:true,touches:[],targetTouches:[],changedTouches:[touch]}));
    }
  }catch(e){}
  el.dispatchEvent(new MouseEvent('mouseover',o));
  el.dispatchEvent(new MouseEvent('mousedown',o));
  el.dispatchEvent(new MouseEvent('mouseup',o));
  el.dispatchEvent(new MouseEvent('click',o));
  try{
    if(typeof PointerEvent === 'function'){
      el.dispatchEvent(new PointerEvent('pointerup',Object.assign({},o,{pointerId:1,pointerType:'touch',isPrimary:true})));
    }
  }catch(e){}
  if(typeof el.click==='function') el.click();
  try{ el.focus && el.focus(); }catch(e){}
}
function __cfxFindConfirm(){
  var texts=['确认投注','立即下注','马上投注','确认下注','提交订单','立即投注','确认','确定','提交','下注','是的','同意','继续','我知道了','知道了','OK','Ok','ok','YES','Yes','验证通过','二次确认'];
  var nodes=document.querySelectorAll('button,a,[role=button],input[type=button],input[type=submit],div,span');
  /* 也搜索同源 iframe 内的确认按钮 */
  try{
    var frames=document.querySelectorAll('iframe');
    for(var fi=0;fi<frames.length;fi++){
      try{
        var fd=frames[fi].contentDocument||frames[fi].contentWindow.document;
        if(fd) nodes=Array.prototype.concat.call(nodes, fd.querySelectorAll('button,a,[role=button],input[type=button],input[type=submit],div,span'));
      }catch(e){}
    }
  }catch(e){}
  var best=null, bestScore=25;
  for(var i=0;i<nodes.length;i++){
    var el=nodes[i];
    if(!__cfxVisible(el)) continue;
    var text=__cfxNorm(el.innerText||el.value||el.getAttribute('aria-label')||'');
    if(!text||text.length>16) continue;
    var hit=-1;
    for(var t=0;t<texts.length;t++){
      if(text===texts[t]||text.indexOf(texts[t])>=0){ hit=t; break; }
    }
    if(hit<0) continue;
    var sc=40-Math.min(hit,15);
    var blob=__cfxPath(el);
    for(var h=0;h<__CFX_BET_HINTS.length;h++) if(blob.indexOf(__CFX_BET_HINTS[h])>=0) sc+=15;
    for(var n=0;n<__CFX_NOISE.length;n++) if(blob.indexOf(__CFX_NOISE[n])>=0) sc-=50;
    if(el.closest && (el.closest('.modal')||el.closest('[class*=dialog]')||el.closest('[class*=popup]')||el.closest('[class*=mask]')||el.closest('[class*=confirm]'))) sc+=25;
    var r=el.getBoundingClientRect();
    if(r.width>=48&&r.height>=28) sc+=12;
    if(sc>bestScore){ bestScore=sc; best=el; }
  }
  return best;
}
function __cfxInputAmount(amount, noClick){
  if(!amount) return {ok:true,message:'无金额'};
  var inputs=document.querySelectorAll('input[type=text],input[type=number],input:not([type]),textarea');
  /* 也搜索同源 iframe 内的输入框 */
  try{
    var frames=document.querySelectorAll('iframe');
    for(var fi=0;fi<frames.length;fi++){
      try{
        var fd=frames[fi].contentDocument||frames[fi].contentWindow.document;
        if(fd) inputs=Array.prototype.concat.call(inputs, fd.querySelectorAll('input[type=text],input[type=number],input:not([type]),textarea'));
      }catch(e){}
    }
  }catch(e){}
  var target=null, bestSc=0;
  for(var i=0;i<inputs.length;i++){
    var el=inputs[i];
    if(!__cfxVisible(el)) continue;
    var textParts=[__cfxPath(el), (el.placeholder||''), (el.getAttribute&&el.getAttribute('aria-label')||'')];
    /* 关联 <label for> 与父容器文本：不少站点金额框 wording 在 label/父级而不是 placeholder */
    try{
      if(el.id){
        var lab=document.querySelector('label[for="'+el.id+'"]');
        if(lab) textParts.push(lab.innerText||'');
      }
      if(el.closest){
        var wrap=el.closest('div,label,td,li,form');
        if(wrap && wrap.innerText) textParts.push(wrap.innerText.slice(0,40));
      }
    }catch(e){}
    var blob=textParts.join(' ').toLowerCase();
    var sc=0;
    /* 强正选：语义明确指向“金额”的输入框 */
    if(/(金额|下注额|投注额|额度|金额框|amount|money|本金|投入|每注|单注)/.test(blob)) sc+=50;
    if(/金额|额度|amount|money|bet|投注|下注|元/.test(blob)) sc+=25;
    /* 强排除：数量/倍数/注数/搜索类输入框，避免误填（注数1 联动总金额×10 的常见错位） */
    if(/(倍数|倍率|倍投|翻倍|注数|份数|数量|期数|份|count|times|multiple|quantity|share|search|user|pass|账号|密码|手机|验证码|追号|期号)/.test(blob)) sc-=80;
    /* 数字输入 & 语义加分 */
    if((el.type==='number'||el.inputMode==='decimal'||el.pattern==='[0-9.]*') && /(金额|元|额度|amount|money)/.test(blob)) sc+=20;
    if(__cfxInRegion(el)) sc+=10;
    if(sc>bestSc){ bestSc=sc; target=el; }
  }
  if(!target||bestSc<=0){
    var chip=__cfxFindBest(String(amount));
    if(chip && !noClick){ __cfxHighlight(chip.el,true); __cfxClick(chip.el); return {ok:true,message:'点筹码'+amount,ae:null}; }
    return {ok:chip?true:false,message:chip?('点筹码'+amount):'未找到金额框',ae:null};
  }
  /* 设置后回读校验：若站点把值改写为 100 等，如实上报实际值，便于用户调整 */
  var actual = __cfxSetInputValue(target, String(amount));
  var note = (actual===String(amount)) ? ('已填金额'+amount) : ('已填金额'+amount+'，页面显示为'+actual);
  return {ok:true,message:note,actual:actual,ae:target};
}
function __cfxSetInputValue(el, value){
  if(!el) return '';
  try{ el.focus(); }catch(e){}
  try{ el.scrollIntoView({block:'center',inline:'center'}); }catch(e){}
  var proto = el.tagName && el.tagName.toLowerCase()==='textarea' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
  function put(val){
    /* 不要先清空再写：空值会触发站点把金额兜底成默认档（1→10 / 10→100） */
    try{
      var desc = Object.getOwnPropertyDescriptor(proto, 'value');
      if(desc && desc.set) desc.set.call(el, val);
      else el.value = val;
    }catch(e){ el.value = val; }
    /* React 16+ 受控组件：同步 _valueTracker */
    try{
      var tracker = el._valueTracker;
      if(tracker && typeof tracker.setValue === 'function') tracker.setValue(val === '' ? ' ' : '');
    }catch(e){}
    try{ el.dispatchEvent(new InputEvent('input',{bubbles:true,data:val,inputType:'insertText'})); }catch(e){ el.dispatchEvent(new Event('input',{bubbles:true})); }
    try{ el.dispatchEvent(new Event('change',{bubbles:true})); }catch(e){}
    try{ el.dispatchEvent(new KeyboardEvent('keyup',{bubbles:true,key:'0'})); }catch(e){}
  }
  put(String(value));
  var actual = el.value;
  if(String(actual)!==String(value)){
    put(String(value));
    actual = el.value;
  }
  /* 第三次：若仍不符，用 execCommand 兼容旧站 */
  if(String(actual)!==String(value)){
    try{
      el.select && el.select();
      document.execCommand('insertText', false, String(value));
      actual = el.value;
    }catch(e){}
  }
  return String(actual||'');
}

function __cfxConfirmFingerprint(el){
  if(!el) return '';
  try{
    var r=el.getBoundingClientRect();
    var cls=typeof el.className==='string'?el.className:'';
    return (el.tagName||'')+'|'+(el.id||'')+'|'+cls+'|'+(el.innerText||el.value||'').slice(0,12)+'|'+Math.round(r.left)+','+Math.round(r.top);
  }catch(e){ return ''; }
}
/* 成功文案检测：出现这些文案视为确认已完成，停止循环 */
function __cfxHasSuccessText(){
  var t=document.body?(document.body.innerText||document.body.textContent||''):'';
  try{
    var frames=document.querySelectorAll('iframe');
    for(var fi=0;fi<frames.length;fi++){
      try{
        var fd=frames[fi].contentDocument||frames[fi].contentWindow.document;
        if(fd&&fd.body) t+=' '+(fd.body.innerText||fd.body.textContent||'');
      }catch(e){}
    }
  }catch(e){}
  var marks=['投注成功','下单成功','提交成功','出票成功','已成功提交','下单已成功','投注已提交','订单已提交','已受理','成功投注','下注成功','恭喜投注','等待开奖','投注完成','已下注'];
  for(var i=0;i<marks.length;i++){ if(t.indexOf(marks[i])>=0) return marks[i]; }
  return '';
}
/* 失败/余额不足等终止文案 */
function __cfxHasBlockText(){
  var t=document.body?(document.body.innerText||document.body.textContent||''):'';
  try{
    var frames=document.querySelectorAll('iframe');
    for(var fi=0;fi<frames.length;fi++){
      try{
        var fd=frames[fi].contentDocument||frames[fi].contentWindow.document;
        if(fd&&fd.body) t+=' '+(fd.body.innerText||fd.body.textContent||'');
      }catch(e){}
    }
  }catch(e){}
  var marks=['余额不足','下单失败','投注失败','提交失败','超出限额','不能超过','已达上限','请先登录','登录已过期','账户被锁定'];
  for(var i=0;i<marks.length;i++){ if(t.indexOf(marks[i])>=0) return marks[i]; }
  return '';
}
window.__caiFenXiRunCommand=function(CMD){
  var steps=[];
  try{
    window.__CFX_REGION = CMD.region || {enabled:false};
    if(!CMD||!CMD.bets||!CMD.bets.length){
      return {ok:false,message:'指令无注项',steps:steps};
    }
    for(var i=0;i<CMD.bets.length;i++){
      var bet=CMD.bets[i];
      var logical=bet.value||'';
      var label=bet.pageText|| (CMD.labelMap&&CMD.labelMap[logical]) || logical;
      if(!label) continue;
      /* ① selector 精确优先（用户标注过） */
      var selStr=CMD.selectors && CMD.selectors[logical];
      if(selStr){
        try{
          var selEl=__cfxQuerySelector(selStr);
          if(selEl){
            // 若标注到了文字节点父级，尝试可点击子/自身
            if(!__cfxVisible(selEl)){
              var cand = selEl.querySelector && selEl.querySelector('button,a,[role=button],input,label');
              if(cand && __cfxVisible(cand)) selEl = cand;
            }
            if(__cfxVisible(selEl) || (selEl.offsetParent !== null)){
              __cfxHighlight(selEl,true);
              if(!CMD.dryRun) __cfxClick(selEl);
              steps.push({step:'play:'+logical+'→selector',ok:true,method:'selector'});
              continue;
            }
          }
        }catch(e){}
      }
      /* ② 无 selector 或失配 → DOM 评分兜底 */
      var hit=__cfxFindBest(label);
      if(!hit){
        hit=__cfxFindBest(label.replace(/\s+/g,''));
      }
      if(!hit){
        var core=label.replace(/[^大小单双龙虎]/g,'');
        if(core && core!==label) hit=__cfxFindBest(core);
      }
      if(!hit){
        steps.push({step:'play:'+logical+'→'+label,ok:false});
        return {ok:false,message:'未找到玩法【'+label+'】',steps:steps};
      }
      __cfxHighlight(hit.el,true);
      if(!CMD.dryRun) __cfxClick(hit.el);
      steps.push({step:'play:'+logical+'→'+label,ok:true,score:hit.score});
    }
    return {ok:true,message:'bets_done',steps:steps};
  }catch(err){
    return {ok:false,message:String(err&&err.message||err),steps:steps};
  }
};
/* ===== 分阶段执行（供 Kotlin 侧 postDelayed 调用）===== */
window.__cfxPhase2Amount=function(CMD){
  var amtOk=false, amtMsg='', amtEl=null;
  if(CMD.selectors && CMD.selectors.selector_amount && CMD.amount){
    try{
      var amtEl2=__cfxQuerySelector(CMD.selectors.selector_amount);
      if(amtEl2){
        // 标注可能点到包装层，下钻到真实 input
        if(amtEl2.tagName && amtEl2.tagName.toLowerCase()!=='input' && amtEl2.tagName.toLowerCase()!=='textarea'){
          var inner = amtEl2.querySelector && amtEl2.querySelector('input,textarea');
          if(inner) amtEl2 = inner;
        }
        var actual=__cfxSetInputValue(amtEl2, String(CMD.amount));
        amtOk=true;
        amtMsg=(actual===String(CMD.amount)) ? ('selector已填金额'+CMD.amount) : ('selector已填金额'+CMD.amount+'，页面显示为'+actual);
        amtEl=amtEl2;
      }
    }catch(e){}
  }
  if(!amtOk){
    var amt=__cfxInputAmount(CMD.amount);
    amtOk=!!amt.ok; amtMsg=amt.message; amtEl=amt.ae||null;
  }
  return {ok:amtOk,message:amtMsg,ae:amtEl?__cfxPath(amtEl):null};
};
/* Phase2.5 金额复核：站点可能在 input 联动里异步改写金额（1→10 / 10→100），
   Kotlin 侧在填完金额后延迟复核，若页面值与期望不符则再次写入，返回最终实际值 */
window.__cfxPhase2Verify=function(CMD){
  if(!CMD.amount) return {ok:true,message:'无金额可复核'};
  try{
    var ae=null;
    if(CMD.selectors && CMD.selectors.selector_amount){
      ae=__cfxQuerySelector(CMD.selectors.selector_amount);
      if(ae && !__cfxVisible(ae)) ae=null;
    }
    if(!ae){
      var amt0=__cfxInputAmount(CMD.amount, true);
      ae=amt0.ae||null;
    }
    /* 无输入框金额框（筹码连击模式）→ 无需复核，放行 */
    if(!ae) return {ok:true,message:'筹码模式，跳过金额复核',ae:null};
    var cur=String(ae.value||'');
    if(cur!==String(CMD.amount)){
      var rw=__cfxSetInputValue(ae,String(CMD.amount));
      cur=String(ae.value||'');
      return {ok:(cur===String(CMD.amount)),message:('复核已重设：期望'+CMD.amount+'，页面显示为'+cur),actual:cur};
    }
    return {ok:true,message:('金额复核通过：'+cur),actual:cur};
  }catch(e){
    return {ok:false,message:'金额复核异常:'+(e&&e.message||e)};
  }
};
/* 自动清除站点残留的 modal 遮罩层（半透明黑屏卡死修复） */
function __cfxClearModalOverlay(){
  try{
    var all=document.querySelectorAll('*');
    var cleared=0;
    for(var i=0;i<all.length;i++){
      var el=all[i];
      if(!el || el===document || el===document.body) continue;
      var st=window.getComputedStyle(el);
      if(!st) continue;
      // 特征1: fixed/absolute 定位
      var pos=st.position;
      if(pos!=='fixed' && pos!=='absolute') continue;
      // 特征2: 覆盖大部分屏幕
      var r=el.getBoundingClientRect();
      var vw=window.innerWidth, vh=window.innerHeight;
      if(r.width<vw*0.7 || r.height<vh*0.7) continue;
      // 特征3: 半透明黑色背景
      var bg=st.backgroundColor||st.background||'';
      var isDarkOverlay=false;
      if(bg.indexOf('rgba')===0){
        var m=bg.match(/rgba?\((\d+),\s*(\d+),\s*(\d+),\s*([\d.]+)\)/);
        if(m){
          var r0=parseInt(m[1]), g0=parseInt(m[2]), b0=parseInt(m[3]), a0=parseFloat(m[4]||'1');
          if(r0<80 && g0<80 && b0<80 && a0>0.3 && a0<1.0) isDarkOverlay=true;
        }
      } else if(bg==='#000' || bg==='#000000' || bg.indexOf('rgb(0,0,0)')===0){
        var op=parseFloat(st.opacity||'1');
        if(op<1.0 && op>0.3) isDarkOverlay=true;
      }
      if(!isDarkOverlay) continue;
      // 特征4: z-index 较高
      var z=parseInt(st.zIndex||'0');
      if(z<10) continue;
      // 特征5: 子元素很少（纯遮罩层，不是内容容器）
      var childCount=el.children?el.children.length:0;
      if(childCount>3) continue;
      // 清除: 隐藏而非删除，避免破坏页面结构
      el.style.display='none';
      el.style.visibility='hidden';
      el.style.pointerEvents='none';
      cleared++;
    }
    return {cleared:cleared};
  }catch(e){
    return {cleared:0,error:e&&e.message||''};
  }
}

window.__cfxPhase3Confirm=function(CMD){
  var out={ok:false,finished:false,clicked:false,message:'',rounds:[]};
  var dryRun=!!CMD.dryRun;
  /* 0) 金额最终校验：Phase3 前站点异步改写已生效，此时校验最真实。
        若页面金额 ≠ 期望值：重写一次再读；仍不符则阻止确认，避免以错误金额下注 */
  if(CMD.amount){
    try{
      var ae=null;
      if(CMD.selectors && CMD.selectors.selector_amount){
        ae=__cfxQuerySelector(CMD.selectors.selector_amount);
        if(ae && !__cfxVisible(ae)) ae=null;
      }
      if(!ae){
        var amtRes=__cfxInputAmount(CMD.amount, true);
        ae=amtRes.ae||null;
      }
      if(ae){
        var cur=String(ae.value||'');
        if(cur!==String(CMD.amount)){
          var rew=__cfxSetInputValue(ae,String(CMD.amount));
          var cur2=String(ae.value||'');
          if(cur2!==String(CMD.amount)){
            out.ok=false; out.finished=true;
            out.message='金额被页面改写为'+cur2+'（期望'+CMD.amount+'），已阻止确认';
            return out;
          }
        }
      }
    }catch(e){
      out.message='金额校验异常:'+(e&&e.message||e);
    }
  }
  /* 1) 找确认按钮：selector 精确优先；评分兜底跳过已点过的 */
  var conf=null, fp='';
  if(CMD.selectors && CMD.selectors.selector_confirm){
    try{
      var selEl=__cfxQuerySelector(CMD.selectors.selector_confirm);
      if(selEl && (__cfxVisible(selEl) || selEl.offsetParent!==null || (selEl.getClientRects&&selEl.getClientRects().length))){
        fp=__cfxConfirmFingerprint(selEl);
        if(window.__CFX_CONFIRMED_FPS[fp]) fp='';
        else conf=selEl;
      }
    }catch(e){}
  }
  if(!conf){
    var cand=__cfxFindConfirm();
    if(cand){
      var fpC=__cfxConfirmFingerprint(cand);
      if(!window.__CFX_CONFIRMED_FPS[fpC]){ conf=cand; fp=fpC; }
    }
  }
  if(!conf){
    var doneText=__cfxHasSuccessText();
    var blockText=__cfxHasBlockText();
    if(doneText){
      out.ok=true; out.finished=true;
      out.message='完成：'+doneText;
    } else if(blockText){
      out.ok=false; out.finished=true;
      out.message='阻止：'+blockText;
    } else {
      out.finished=true;
      out.message='无确认按钮';
    }
    return out;
  }
  var txt=__cfxNorm(conf.innerText||conf.value||'');
  __cfxHighlight(conf,true);
  if(!dryRun) __cfxClick(conf);
  if(fp) window.__CFX_CONFIRMED_FPS[fp]=true;
  out.ok=true; out.clicked=true;
  out.message='已点击确认：'+txt;
  out.rounds.push({round:1,ok:true,text:txt});
  /* 清除可能残留的 modal 遮罩层（半透明黑屏修复） */
  var clr=__cfxClearModalOverlay();
  if(clr.cleared>0) out.message+='；已清除'+clr.cleared+'个遮罩层';
  /* 延迟再次清理：站点遮罩层可能异步出现 */
  setTimeout(function(){
    var clr2=__cfxClearModalOverlay();
    if(clr2.cleared>0){
      try{ console.log('[CFX] 延迟清除遮罩层: '+clr2.cleared); }catch(e){}
    }
  },900);
  return out;
};
