# Kline Alert — Android native project

This is a native Kotlin + Jetpack Compose app, not a WebView wrapper. The original Cloudflare/TypeScript/Python source remains in the parent repository as the migration reference.

## Build and verification

- Android Studio: open `android-native/` with JDK 17 and Android SDK 35.
- CLI: from `android-native/`, run `gradle --no-daemon testDebugUnitTest assembleDebug`.
- GitHub Actions: `.github/workflows/android-native-build.yml` installs SDK 35, runs unit tests, assembles a debug APK and uploads the APK/test reports.

The current editing environment has Java/Kotlin compiler but no Gradle executable, Gradle wrapper JAR, Android SDK or cached Android dependencies. The pure Kotlin analysis engine compiles and its smoke checks pass locally; a full Android APK build has **not** been run here. Do not treat the APK build as accepted until the CI workflow succeeds.

## Implemented in this migration increment

- Native Compose dashboard; no WebView.
- Binance public market universe discovery: all active spot quote pairs, plus USDT-margined perpetual contracts; stablecoin-base and leveraged-token suffixes are excluded.
- Symbols are sorted by reported 24-hour quote volume; for spot pairs with different quote assets this is an approximate prioritization, not a normalized cross-currency ranking. Bounded batches/concurrency and a shared request gate reduce request bursts. Full-market WebSocket monitoring starts after a manual full scan and is foreground-only.
- K-line history request uses 300 bars; signal evaluation ignores the currently open candle to reduce repainting.
- Timeframe selection: 15m, 30m, 1h, 4h.
- Foreground ticker WebSocket and timeframe-specific K-line WebSocket for the selected symbol; after a successful full-market scan, combined K-line WebSocket streams are opened in 100-symbol chunks for the discovered universe. Only closed-bar transitions trigger all-symbol re-analysis; on close/failure, guarded 2-second reconnect is scheduled while the same market/timeframe remains foregrounded.
- REST retry/backoff for transient HTTP 418/429/5xx responses, bounded to three attempts, plus a conservative shared 250ms request gate during scans.
- In-app new-signal, direction-change and invalidation banner; new/direction-change signals create local review records. WebSockets, reconnect attempts and active scans are stopped when the app leaves foreground.
- Partial scan failures are counted and surfaced instead of silently claiming a complete scan.
- SQLite-backed local cache for scan results, review records, and position records; no cloud database or account data. The Compose dashboard exposes a local positions view where a signal can be saved with reference entry/stop/target values and later removed. These are local tracking records, not imported exchange positions.
- Local review lifecycle: closed-candle outcome checks, conservative stop/target same-candle handling, and 72-hour expiry.
- Native `PositionEngine` port of the original position scoring framework: primary timeframe bias, multi-timeframe agreement, stop proximity, nearby key levels, PnL, and ATR risk flags.
- Eight named regime outcomes (`uptrend`, `pullback`, `rebound`, `downtrend`, `weakening`, `range`, `breakout`, `fakeout`) are represented by Chinese labels with confidence scoring based on the source priority rules; fixture-by-fixture numeric parity is not yet proven.
- Unit test source for supported intervals, indicator outputs, minimum-history guard, deterministic calculations, review outcomes (including stable identity per signal candle), and position assessment.
- Fixed SQLite schema initialization/migration so `review_records` is created on fresh installs and on upgrades from the previously shipped v2 schema.

## Important parity gaps (not yet release-ready)

The native engine now calculates EMA20/60/200, EMA crossover, MACD, KDJ, RSI14, ATR, Bollinger bands, ADX-based eight-state regime labels/confidence, 5/5 swing pivots clustered at 0.5%, EMA/Bollinger/Fibonacci level families, 0.8% cross-family confluence, and ATR-based reference stop/target. It is **not yet a proven line-by-line port** of every original rule. Exact fixture parity is still outstanding for indicator seeding/edge cases, full opportunity serialization/conclusions/sizing, all position-assessment edge cases, review lifecycle/statistics and source fixtures.

There is no background service or OS notification path by design. Local SQLite now stores scan results, review records, and position records, and the domain layer includes a position assessment engine. The UI still does not expose a full position-management workflow or review-statistics dashboard, and native level/regime output is not yet proven identical to the original engine. Real-time ticker/candle updates, signal checks and scans are intended to operate only while the app is foregrounded. Market access depends on Binance endpoint and WebSocket availability in the user's network; the spot REST path has a public data mirror fallback, but futures and WebSocket connectivity are not guaranteed everywhere.

### Local tracked-position live prices

Saved positions can subscribe to combined public Binance ticker streams while the app is foregrounded. The position cards show current price and direction-adjusted price movement from the saved reference entry. This is not account PnL (tracked size defaults to zero), does not import exchange positions, and never submits orders. Position ticker sockets are cancelled when the app leaves the foreground; reconnect is guarded while foregrounded.
