## v5.0 币安 U 本位全自动跟单（骨架 + P0/P1 通路）

- 完整方案见 `TRADE_SCHEME.md`。
- BinanceTradeClient / TradeBridge / trade_links / 交易页 UI / 监控挂钩。
- 默认跟单关闭；密钥本机存储。


## v4.9 盈亏口径修正（币安 U 本位）

- **P0 盈亏口径**：`LocalPosition.size` 明确为**起始保证金本金（USDT）**，数量 = 本金 × 杠杆 / 开仓价。
  - 未实现盈亏 USDT = 本金 × 杠杆 × 方向变动% / 100（例：本金1、50x、涨1% → **+0.50 USDT**）。
  - 收益率%（开仓保证金口径）= 杠杆 × 方向变动%（例：**+50%**）。
  - 修复原「方向变动百分点 × 50」把百分数当金额、放大约 100 倍的错误。
  - 统一持仓卡、工作台已平/浮盈、前台平仓提示、后台通知；`battlePnlSum` 改为累计 **USDT**。
  - 默认自动入仓仍本金 1 USDT × 杠杆 50；手动「按此执行」与自动一致。
- 止损/止盈/手续费/资金费/强平本轮不动。旧 `battlePnlSum` 历史累计若曾按错误公式展示，新会话起按 USDT 重计。
- （自动作战循环补位逻辑保持原样：空仓或刚平仓时再补，不在未满仓每轮强补。）

## v4.8 全量审计修复（功能完结后体检）

- **P0-1 双结算口径统一**：后台 `settleByPrices` 由「扫描现价近似判定」改为**优先拉真实 K 线调 `ReviewEngine.touch`**（区间高/低点触碰、同时触碰判 miss，与前台完全同口径）；K 线不可用（冷门/限流）才回退扫描现价，回退优先级与前台一致。修复同一记录前后台可能结论不一、污染胜率/学习权重/回测的问题。
- **P0-2 冷却持久化**：LocalStore DB v7→v8 新增 `battle_cooldowns` 表；VM 启动从 DB 恢复冷却；自动平仓（前台+后台）与手动删仓均写库。进程被杀/重启后冷却不丢，防同品种立即重入。
- **P0-3 双端平仓原子守卫**：新增 `reviewExists(id)`；VM/Service 的 `closeBattlePosition` 只有**首个写入方**才保存样本 + 计数 + 发通知，另一方仅删持仓——消除同 tick 并发平仓的统计/通知重复。
- **P1-1 关键路径失败可见**：自动入仓落库失败 →「⚠ 入仓落库失败」；自动平仓结算落库失败 →「⚠ 结算落库失败，请到诊断页检查样本」；其余读缓存静默降级（合理设计）。
- **P2-1 SQLite 并发**：`onCreate` 启用 WAL（前台 VM 与后台 Service 双连接并发，降低 SQLITE_BUSY）。
- **P2-2 测试补充**：BattleLoopEngineTest +6 边界（NaN/零值入仓、到价平仓、除零盈亏、冷却恰到期、新鲜度窗口边界、作战评分输入钳制）。
- **审计结论（无需改）**：限流重试（418/429/5xx + Retry-After + 指数退避 1s/2s/4s）、后台保活（前台通知 + START_STICKY + 断线重连）、AnalysisEngine 除零/NaN 防护、Double 展示口径——逐项核验已达标。
- 测试：**117/117**（kotlinc 2.0.21 全量编译 domain 16 文件 + 14 测试类，JUnit 4.13.2 全跑 OK）。交付：源码包 + 审计报告（Android 层需在有 SDK 环境 `assembleDebug` 复核）。

## v4.7 作战台新鲜度滚动榜（优中选优，不堵死）

- **作战台改「新鲜度滚动榜单」**：取消固定「主攻/候补/观察」3 卡，改为新鲜窗口内（15m→30分钟…）已确认/回踩确认信号按**作战评分**降序的榜单，最多展示 8 条；**过期自动下榜**（K 线时间超窗口即消失，哪怕分数高）——榜单持续滚动，不再被旧信号堵满；每条带 ⏱新鲜标记（刚刚确认 / N 分钟前）。
- **作战评分（优中选优，榜单与自动入仓共用）**：`BattleLoopEngine.battleScore` = 信号分×0.30 + 方向历史胜率×0.20 + 确认强度 progressAtr×0.15 + 波动健康×0.15 + **新鲜度×0.20**（≤5 分钟满分、按窗口线性衰减，`freshnessScore`）——旧高分不压新信号。
- **自动入仓收紧**：仅 **A/B 级**机会才自动入仓（C 级只展示不自动进）+ 已确认/回踩确认 + 分≥70 + 未持仓 + 未冷却 + 新鲜窗口内；每轮最多补 min(空闲坑位, 3) 个渐进建仓。
- **空位持续推荐**：坑位 > 0 时作战台持续推荐新信号（设 5 持仓 2 → 空 3 坑自动从榜首补位）；满仓才暂停推荐。
- **修 bug**：Kotlin 不以行首 `+` 续行——battleScore 原本换行书写导致只返回第一项（信号分×0.3），已用括号包裹修复（单测抓出）。
- 测试：111/111（BattleLoopEngineTest 21 项，新增新鲜度衰减、作战评分权重）。交付形态为源码包，未在本环境出 APK。

## v4.6 自动作战优化（4 项用户修改）

- **盈亏比改「止损 2 / 止盈 3」**：入仓定价改为止损距离 = 2×ATR、止盈距离 = 3×ATR（原 1×/2×）；`BattleLoopEngine` 新增 `DEFAULT_STOP_MULT=2.0` / `DEFAULT_TARGET_MULT=3.0`，EntryPlan 落 `stopMult`/`targetMult`；门控「距止损太近」按止损距离展示（默认最小止损 0.6% 价）。
- **持仓收益明细与统计**：本金固定 1、杠杆 50 倍——持仓卡新增「实际盈亏50x」= 方向变动% × 50；工作台统计区新增「已平实际盈亏 = 累计价格收益% × 50」与「当前浮盈 = Σ 方向变动% × 50」；自动入仓落库 leverage=50、size=1。
- **满仓后作战台不再推荐**：满仓时作战面板与工作台隐藏候补推荐，只显示「满仓暂停推荐」提示；`fillBattleSlots` 满仓清空候补队列；**新鲜度门槛**（`BattleLoopEngine.isFresh`，按周期 15m/30m/1h/4h → 30/60/120/480 分钟窗口）——平仓后只自动补入**新鲜**确认信号，防「落后信号顶上」。
- **后台常驻不断联**：`bg_monitor` 默认开启；`BackgroundMonitorService` 新增后台自动作战——60s 轮询全部 LIVE 持仓实时价（`repo.candles`）+ 扫描轮批量兜底 + K 线新收盘触发，止盈/止损/移动止盈与前台同引擎判定，平仓写 `auto|` 结算样本、删持仓、系统通知实际盈亏（×50）。
- **持久化**：SQLite v7 迁移——position_records 新增 stop_mult/target_mult（幂等 ALTER，默认 2.0/3.0）。
- 测试：109/109（BattleLoopEngineTest 19 项，新增自定义乘数、新鲜度窗口）。交付形态为源码包，未在本环境出 APK。

## v4.5 自动作战循环（Auto-Battle Loop）

- 新增 `BattleLoopEngine`：把「作战面板推荐 → 自动入仓 → 自动止盈止损平仓 → 循环等下一信号」闭环化（用户决策：按现价入 + 盈亏比默认 2:1 + 全自动 + 移动/固定止盈可切换）。
- **入仓**：已确认/回踩确认 + 综合分≥70 + 未持仓/未冷却的候补信号，按现价入场；止损=现价∓ATR（风险 R），止盈=现价±2R（盈亏比 2:1）；距止损太近（R<0.3% 价）或波动过大（R>5% 价）被门控拒绝，不追。
- **自动平仓**：每 500ms tick 轮询持仓实时价——防插针（交叉校验偏差>1.5% 拦截）、止损、固定止盈、移动止盈（从极值回撤 1.5×ATR 锁盈，且不劣于原始止损）四重判定；平仓即删除持仓（消失）+ 写 `auto|` 前缀 ReviewRecord 进胜率/学习/回测闭环。
- **循环**：坑位空出 → 候补队列按综合分自动顶上；同品种同方向平仓后 4h 冷却防反复进出；容量上限扩到 10（默认 10）。
- **UI**：工作台「自动作战 全自动开/关」+「止盈 固定/移动」切换 + 循环统计（入/平/胜/负/盈亏）+ 候补队列；持仓卡片显示距止损/止盈进度、移动止盈锚点、🤖自动徽标。
- **持久化**：SQLite v6 迁移——position_records 新增 status/trailing/best_price/risk_reward/atr/timeframe/evidence_score/close_price/close_reason/closed_at（幂等 ALTER）。
- 测试：107/107（新增 BattleLoopEngineTest 17 项：盈亏比定价/门控/四重平仓/移动止盈锚点/冷却/盈亏口径）。交付形态为源码包，未在本环境出 APK。

## v4.4 收尾版（回测校准框架 + 体验项）

- 新增 `BacktestAnalyzer`（#1#2#3）：把 v4.2 落库的回踩数据 + 证据分利用起来做三件事——①证据分分段胜率（<60 / 60-69 / 70-84 / ≥85，建议阈值=可靠分桶中胜率最高段下界，对照当前硬编码 85）；②回踩 vs 直接触发对比（验证 v4.1「回踩确认更优」假设）；③样本外滚动验证（时间 70% 训练 / 30% 验证，验证段胜率跌 >20pp → 提示疑似过拟合/市场漂移）。
- 设计原则：单桶样本 <15 或总样本 <40 明确标注「样本不足」，不硬给结论；只输出建议值，绝不自动改线上参数（避免噪声污染）。
- #7 样本量提示：学习权重样本 <20 标注「⚠样本不足」，回测分桶不足标注「（样本不足）」。
- #8 通知深链：触发通知 Intent 带 `deep_link_tab=latest` / `deep_link_symbol`，点击直达「最新机会」页并黄框高亮该品种 3 秒自动恢复。
- #9 待命单手动忽略：卡片右上角「✕」一键标记为过期（EXPIRED + 手动忽略）并落库，不等自动过期。
- #10 回测报告展示：诊断页「回测校准（真实样本）」区块 + 「生成/刷新回测校准报告」按钮，展示分段胜率/建议阈值/回踩对比/样本外验证结论。
- 测试：90/90 通过（新增 BacktestAnalyzerTest 10 项）。交付形态为源码包，未在本环境出 APK。

## 2026-10-12 — foreground cancellation / SQLite repair

- Propagate coroutine cancellation immediately from Binance REST retry and spot mirror fallback paths.
- Do not swallow cancellation when the optional 24-hour volume ranking endpoint fails.
- Make SQLite upgrade migration idempotently verify/create the scan cache table without deleting existing scan rows.
- Android Gradle build and APK assembly still require GitHub Actions or Android Studio; this environment cannot claim a full build passed.

## 2026-10-12 — full-market scan resilience

- Retry transient per-symbol REST/data failures once after the initial full-market pass, using smaller retry batches to avoid amplifying Binance rate-limit pressure. The final failure count now reports symbols that still fail on retry.
- Repair full-universe live monitoring for symbols whose initial K-line REST request failed: the first stream event triggers a 300-candle history backfill, with later-bar retries if the history remains too short and a per-symbol in-flight guard to avoid duplicate backfill requests.
- Changed full-universe WebSocket reconnection from a fixed 2-second loop to capped exponential backoff (2–30 seconds) while foregrounded.
- Full Android Gradle/JUnit/APK build remains unverified locally; CI and device validation are still required.

## 全市场机会筛选与结构增强
- 新增扫描周期多选，可在一次扫描任务中依次扫描 15m、30m、1h、4h 中所选周期，并按周期保存分析结果。
- 新增机会列表品种搜索与最低综合可信度筛选。
- 新增综合可信度分值，综合市场阶段、方向信号评分、支撑/承压位共振、成交量与风险收益比；不再仅显示市场阶段置信度。
- 每条机会新增最近 96 根已收盘 K 线的最高/最低点，并展示最近支撑、最近承压、支撑/承压共振数量和风险收益比。
- 注：综合可信度是规则模型的评分，不是统计校准过的真实胜率；需要历史回测后才能评估概率校准。
