# 构建 APK 准备说明（v5.0）

## 环境要求

| 项 | 版本 |
|----|------|
| JDK | **17**（勿用 21 作 AGP 8.7 主编译亦可，推荐 17） |
| Android SDK | **35**（`platforms;android-35`） |
| Build-Tools | 35.0.x |
| Android Studio | Hedgehog / Ladybug 或更新 |

## 一、用 Android Studio（推荐）

1. **File → Open** 选择本目录 `android-native/`（含 `settings.gradle.kts` 的那一层）。
2. 等待 Gradle Sync（首次会下载 Gradle 8.11.1 与依赖）。
3. 若提示 SDK：安装 API 35。
4. 菜单 **Build → Build Bundle(s) / APK(s) → Build APK(s)**。
5. 产物路径：
   - Debug：`app/build/outputs/apk/debug/app-debug.apk`  
     （包名带 `.debug` 后缀：`com.klinealert.nativeapp.debug`）
   - Release：`app/build/outputs/apk/release/app-release.apk`  
     （当前用 **debug 签名**，可直接安装调试；上架需换成自己的 keystore）

## 二、命令行

```bash
cd android-native

# 若无 local.properties，复制示例并改成你的 SDK 路径
cp local.properties.example local.properties
# 编辑 sdk.dir=...

# Debug APK
./gradlew assembleDebug

# Release APK（本工程已配置 debug 签名便于安装）
./gradlew assembleRelease
```

产物同上。

## 三、安装到手机

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
# 或
adb install -r app/build/outputs/apk/release/app-release.apk
```

首次安装需允许「未知来源」或通过 USB 调试安装。

## 四、本包已准备的文件

- `gradle/wrapper/`：`gradle-wrapper.jar` + `gradle-wrapper.properties`（Gradle **8.11.1**）
- `gradlew` / `gradlew.bat`
- `app/build.gradle.kts`：versionName **5.0.0** / versionCode **50**，debug/release
- `app/proguard-rules.pro`
- 启动图标 `res/drawable/ic_launcher*.xml`
- `local.properties.example`、`.gitignore`
- `AndroidManifest`：icon、软键盘 `adjustResize`

## 五、正式上架签名（可选）

1. 生成 keystore：
   ```bash
   keytool -genkey -v -keystore kline-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias kline
   ```
2. 在 `app/build.gradle.kts` 的 `android { }` 内增加 `signingConfigs { create("release") { ... } }`，  
   并将 `release { signingConfig = signingConfigs.getByName("release") }`。
3. **不要**把 jks 和密码提交到 Git。

## 六、常见问题

| 现象 | 处理 |
|------|------|
| SDK location not found | 配置 `local.properties` 的 `sdk.dir` |
| JDK version | 设置 Gradle JDK 为 17 |
| 依赖下载失败 | 检查网络 / 代理；可用国内镜像替换 `settings.gradle.kts` 仓库 |
| 安装冲突 | debug 包名为 `…nativeapp.debug`，与 release 可共存 |
| 通知/后台 | 需授予通知权限；后台监控为 specialUse FGS |

## 七、功能提醒（跟单）

- 默认跟单关闭；请先 **测试网** 验证 API。
- 仅跟随持仓监控 **5 分钟内** 新建仓；开仓后按监控价挂止盈止损条件单。
