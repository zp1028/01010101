## v2.5 性能与实时流修复（2026-10-12）
- 重组节流：tick 只写缓存，500ms 合并发射，重组 ~120/s → 2/s
- 机会实时流自动重连（onError 2s 延迟重连，四重守卫）
- 健康度降级评估：流中断时用最近扫描价评估并标注"基于 N 分钟前扫描价"
- 诊断页新增「机会实时流」状态行（连接数 / 最后行情秒数 / 中断告警）
## v2.6 机会确认状态机（2026-10-12）
- ConfirmationGate：分周期确认窗口（ATR 归一），四态判定（已确认/回踩确认/延候确认/未确认）
- tick 级驱动：朝方向走出阈值→确认；反向≥0.5×ATR→假启动；窗口到期走 0.3~阈值→延候（2×窗口再判）
- 机会行确认徽章（进度 X/Y×ATR + 反向幅度）；确认结果写入训练闭环 features
- A/B 级机会自动进入确认观察；未确认机会后续将淡出榜单（批2 持仓生命线以确认时刻为 0 点）
## v2.7 持仓生命线 + 回踩/反转判别器（2026-10-12）
- PullbackReversalJudge：价格行为/动能结构/量能位置/结构位四证据加权 → 🟢回踩/🟡分歧/🔴反转 三态+置信度（占优方占比，≥70 定性）
- LifecycleEngine 五段式生命线：持有·趋势健康/持有·回调观察/减仓·趋势衰竭/离场·目标达成/离场·反转失效
- 关键位推演卡：延续目标（波段 1.618×延伸∪记账止盈）/衰竭预警线（EMA20）/反转确认线（结构位），各带实时距离
- 持仓 Tab：按紧迫度排序（反转>衰竭>回调>达成>健康）；PosCard/SymbolOppRow 展开区显示生命线卡+证据明细
- 确认的机会（已确认/回踩确认）与持仓均启用生命线；全部复用现有指标数据，无新数据依赖
## v2.9 AI 智能增强（可选功能，2026-10-12）
- AiClient：OpenAI 兼容端点（DeepSeek/通义/Kimi/OpenAI/Ollama 通用），listModels/chat/test
- 诊断页 AI 配置：大模型链接 / API 密钥 / 模型名（手填或「获取模型」拉取列表点选）+「确定链接」连通测试；密钥只存本机
- AI 扫描研判：Top12 机会全局排序 + 矛盾/回避提示（机会榜卡片）
- AI 单机会解读：结构化数据包→固定模板（延续理由/衰竭信号/风险点/动作区间），禁喊单
- 未配置时 AI 功能全部隐藏，本地算法不受任何影响
- 持仓仓位倍数手动设置 1-200（数字校验+钳位）
## v3.0 SmartLevels 智能价位 + 波动自适应失效（2026-10-12）
- Analysis 新增 volExpansion（当前 ATR/近 20 根均值，波动扩张率）
- VolAdaptive.factor：V>1.3→1.6（放宽防假失效）/ >1.15→1.3 / <0.7→0.8（收紧）/ 其余 1.0
- SmartLevelsEngine：止损=结构位（前低/前高/支撑压力）外 0.5×ATR 与自适应缓冲取远者，风险钳位 2.5×ATR；
  T1=第一结构位前 0.3×ATR 防插针；T2=2×ATR 与次级结构位取近；T3=延续目标（1.618×延伸）与 3×ATR 取远者
- fuse() 应用 SmartLevels → 信号/计划/记账/持仓/生命线全链路共享同一套价位（功能互通收口）
- 确认状态机波动自适应：确认/失效阈值随 V 缩放；波动放大期假失效先降级「波动观察」（2 根K线恢复期，恢复即回到待确认）
- 计划文案更新 + SmartLevels 依据说明行（◈ 前缀）
## v3.1 胜率排行榜 + 精准榜收藏（2026-10-12）
- 精准榜卡片可收藏关注（★ 与机会榜/关注页共用同一 watchlist）
- 新增「胜率榜」Tab：品种维度聚合历史机会胜率（≥2 已结算样本入榜），显示胜率/命中/落空/最优方向/进度条
- 分页加载（每页 20，加载更多按钮）
- 点击卡片 → 该品种过往机会明细（每笔的命中/失败/跟踪中，复用历史行组件）
- 数据源：训练闭环自动结算（K线 touch/最新价 settle/24h expire），无需手动维护
- AI 配置确认：已有「获取模型」（网址+Key 拉取模型列表点选）+「确定链接」（最小对话测试），返回数据即配置成功
## v3.2 AI 推理模型兼容（2026-10-12）
- 修复：deepseek-flash/v4-pro 等推理模型返回 content 空、正文在 reasoning_content → 解析失败
- chat() 解析兼容：content 为空自动回退 reasoning_content；两者皆空给出明确结论提示
- max_tokens：测试 512，解读/研判 2000（给推理模型思考空间）；system 提示要求直接作答
## v3.3 工作台首页 + 作战面板 + 仓位容量守门（2026-10-12）
- 新一级「工作台」首页（默认打开页）：
  - 仓位容量条（1/2/3/5/8 可调，持久化），满仓自动切「监控模式」+ 候补队列 Top5
  - 作战面板决策漏斗：🎯主攻 / 🥈候补 / 👁观察 三卡，综合分=评分40%+品种历史胜率25%+确认状态20%+波动健康15%
  - 「按此执行」一键入持仓（SmartLevels 价位自动带入，满仓拦截）
  - 市场仪表：BTC 大盘方向 / 板块共振 / 时段胜率提醒 / 美股时段倒计时（自动夏令时/冬令时）
- addPosition 容量守门：满仓拦截并入候补
## v3.4 美股分页 + 确认排行榜（2026-10-12）
- 新增「美股」Tab：道指/纳指/标普 + 自选股实时报价（Stooq 免费 CSV，无需 Key），时段倒计时，自选持久化，失败静默降级
- 新增「确认榜」Tab：品种机会确认成功率排行（已确认/回踩确认/未确认聚合），来自记账 features 的 confirm 字段
- 验证 VM/主页面 workbench 联动：满仓拦截、候补队列、BattleCard、美股倒计时（DST 自动）
## v3.5（批C：后台监控 + 确认榜实时化 + 同质化去重）
1. **后台实时监控**：工作台市场仪表新增「后台实时监控」开关（前台服务 BackgroundMonitorService + K线流预警 + 通知分级）；开关状态持久化（prefs `bg_monitor`），App 启动自动恢复运行；退出 App 后预警仍在后台工作。
2. **确认榜改造**：置顶「当前已确认机会排行（实时）」——过滤当前机会流中确认状态为已确认/回踩确认的机会、排除已持仓，按确认进度（progressAtr×100 + score）实时排序；下方保留品种历史确认率聚合。
3. **机会榜同质化去重**：同方向+同市场阶段（regime）的联动品种只保留评分最高者（BTC/ETH 大盘始终保留）；机会榜统计卡提示「已合并 N 个联动信号」，解决"机会太多不知道入哪个"。
- 测试：36/36 通过；APK：kline-alert-v3.5.apk
## v3.6（机会三态 + 事件驱动结算 + 折叠去重 + 确认榜双源 + 搜索收藏）
1. **机会三态（PhaseGate）**：新引擎区分「⚡触发 / 🕐观察」。触发=价格落在入场区（±0.3×ATR）或确认状态机已确认（顺势确认型）；观察=价格未到入场区，显示「距触发 N%」。机会榜主列表只显示触发态机会，观察态折叠在「🕐 观察中 N 个」展开区（带收藏星标）——解决“当下价格全是假机会”问题。
2. **事件驱动结算 + 到期顺延**：结算只由价格事件驱动（触及止盈/止损立即判生死）；周期结束不再强行判输赢，跟踪期 72h→168h 顺延，超期仍未触发结算为「中性退出」（不计入胜率分母）。
3. **同质化信号软合并**：默认「宽松显示」全部品种（修复只显示4个的问题）；「严格合并」开关可切回只保留每组最强；合并数提示保留。
4. **确认榜双源**：新增「确认观察中 N 个」实时进度条区（progressAtr/thresholdAtr），已确认排行置顶不变，空态给出确认规则引导——页面不再空白。
5. **搜索收藏**：观察区行内含 ★ 收藏；关注页新增手动输入框直接添加币种；机会卡搜索结果行的 ★ 收藏保持可用。
- 测试：41/41 通过（新增 PhaseGateTest 5 项）；APK：kline-alert-v3.6.apk
## v3.7 批1（证据引擎 + 量价分类器 + 固定3R + 智能失效）
1. **四维证据引擎（EvidenceEngine）**：位置35%（支撑/压力±0.3×ATR=40、前低前高±0.5×ATR=30、布林+RSI=15、1×ATR接近=10）+ 信号30%（MACD新鲜度15/延续8/过久3、EMA9-21与KDJ各7、量价形态8）+ 结构20%（regime匹配、模式库、波动健康）+ 历史15%（周期×方向胜率+品种确认率）。总分≥50 才进机会榜；反向量价形态一票否决信号证据。
2. **量价形态分类器（VolumePriceClassifier）**：8形态——放量突破/放量上涨/放量下跌/放量滞涨/缩量回踩/缩量反抽/恐慌抛售/突破失败（量比+实体+结构位判定），Analysis 新增 volRatio/volumePattern 字段，接入分析主流程。
3. **固定3R止盈**（用户确认）：止损=SmartLevels 结构位不动；止盈=入场±3×止损距离，riskReward 恒3.0；T1/T2=1R/2R 减仓提醒。
4. **智能失效**：确认「未确认」且反向≥1.2×ATR → 提前结案 invalid（负样本半权重计入胜率分母），早于止损离场。
5. **UI**：机会卡新增「证据N」chip（≥70黄/≥50蓝/<50红）+「量价否决」红chip + 展开区四维明细（缺什么一目了然）。
- 测试：51/51 通过（新增 EvidenceTest 10 项）；APK：kline-alert-v3.7.apk；批2（权重自学习+榜单适配）待续
## v3.8（三重门锁待命单 + 最新机会分页）
1. **待命单（PendingSetup）**：机会从「状态快照」改为「价格到 X 才入场」的挂单——触发价（做多=支撑/EMA20 上方 0.2×ATR，做空镜像）、失效价、止损（做空缓冲 ×1.25 方向不对称）、固定 3R 止盈、按周期绑定的有效窗口（做空窗口 ×0.6）。
2. **三重门锁**：位置门（价格在结构位 ±0.5×ATR 内）+ 信号门（MACD/KDJ/EMA 刚交叉 ≤2 根 或 缩量回踩/放量突破等新鲜形态）+ 时间门（事件在最近 2 根K线内）。未全过则卡片显示「还差哪道门」（等价格到位/等信号触发/等新一轮K线）。
3. **tick 驱动（秒级）**：实时行情流每 500ms flush 时推进待命单——触及触发价→⚡可入场；破失效价/窗口到期→过期；触发后 2 根K线内出现反向量价形态→触发后反悔取消。
4. **新「最新机会」一级分页**：待命单按生成时间倒序（越靠前越新），已触发置顶；每单显示触发价/失效价/止损/3R止盈/距触发%/三门状态/剩余有效期/「生成于 N 分钟前」；含刷新按钮、关注、+仓位。
- 测试：60/60 通过（新增 PendingSetupTest 9 项）；APK：kline-alert-v3.8.apk
## v3.9（触发推送 + 二次入场 + 时间去重 + 持仓联动）
1. **触发即推送（SetupNotifier）**：待命单「待命→已触发」跃迁瞬间推送系统通知，带入场价/止损/3R止盈；分级——证据≥85 走重要渠道（响铃+震动），≥70 普通渠道，<70 静默只在 App 内显示；同品种 30 分钟冷却；夜间静音（23:00-08:00）可一键开关。
2. **新鲜度与时间去重**：同品种同方向 4 小时内只生成 1 次待命单（防反复进出被手续费磨死）；触发过的机会保留一次「回踩二次入场」机会（二次入场放行一次冷却）。
3. **持仓联动**：待命单卡片检测同品种持仓——无持仓显示「+仓位」、同向显示「+加仓(金字塔)」、反向显示「⚠ 与持仓方向冲突」。
4. **UI**：最新机会分页新增「触发推送分级说明 + 夜间静音开关」；底部提示补全机制说明。
- 测试：60/60 通过；APK：kline-alert-v3.9.apk
## v4.4 收尾版（回测校准框架 #1#2#3 + 体验项 #7-10）
1. **BacktestAnalyzer（新增）**：把 v4.2 落库的「回踩确认 + 证据分」真实样本利用起来——①证据分分段胜率：<60 / 60-69 / 70-84 / ≥85 分桶，建议阈值=可靠分桶中胜率最高段的下界（对照当前硬编码 85）；②回踩 vs 直接触发：对比 pullbackConfirmed=true/false 两组胜率，验证 v4.1「回踩确认更优」假设；③样本外滚动验证：按 alertedAt 前 70% 训练 / 后 30% 验证，验证段胜率跌 >20pp 提示疑似过拟合/市场漂移。
2. **诚实统计设计**：单桶样本 <15（MIN_BUCKET_SAMPLES）或总样本 <40（MIN_TOTAL_SAMPLES）明确标注「样本不足」，不硬给结论；invalid 按半权重 miss 计入分母（与胜率榜口径一致）；只输出建议值供人工确认，绝不自动改线上参数。
3. **#7 样本量提示**：诊断页学习权重样本 <20 标注「⚠样本不足」，回测分桶不足标注「（样本不足）」。
4. **#8 通知深链**：SetupNotifier 触发通知 Intent 带 deep_link_tab=latest / deep_link_symbol；MainActivity 读取后经 Dashboard LaunchedEffect 调 handleDeepLink 切 Tab 并高亮，黄框高亮 3 秒后 clearHighlight 自动恢复；onNewIntent 同步。
5. **#9 待命单手动忽略**：卡片右上角「✕」→ dismissSetup(key)，标记 EXPIRED + note「手动忽略」并落库（persistSetups），不等自动过期。
6. **#10 回测报告展示**：诊断页「回测校准（真实样本）」区块——样本状态 / 证据分段胜率+建议阈值 / 回踩对比结论 / 样本外验证结论；「生成/刷新回测校准报告」按钮调 loadBacktest（读 localStore.loadReviews 后 analyze）；setTab("diag") 进入诊断页时自动加载。
7. **数据链路**：ReviewRecord 新增 evidenceScore / pullbackConfirmed / armedAt / pullbackMs（v4.2 已落库），LocalStore 读写双向兼容（runCatching 容错旧表）。
- 测试：90/90 通过（新增 BacktestAnalyzerTest 10 项）；交付为源码包 kline-alert-android-src.zip，未在本环境出 APK（用户确认不需要）。
## v4.5 自动作战循环（Auto-Battle Loop）
1. **需求闭环（用户决策 2026-10-12）**：作战面板推荐信号自动加入持仓监控；持仓动态轮询、达止盈/止损自动平仓消失；平仓后等待下一作战推荐；最多同时 10 个持仓。决策点：按现价入 + 距止损不能太近 + 止损止盈统一盈亏比（默认 2:1）；全自动；支持移动止盈/固定止盈切换按钮。
2. **BattleLoopEngine（新增，domain 纯逻辑可单测）**：
   - `buildEntry`：entry=现价，risk=ATR，stop=entry∓risk，target=entry±rr×risk（默认 rr=2）；门控——riskPct<0.3%（距止损太近）/ >5%（波动过大）/ 价格或 ATR 无效 → reject 不入。
   - `evaluateClose`：四重判定——①交叉校验不过（防插针）→ 本 tick 不动；②止盈（到 target）；③止损（破 stop）；④移动止盈（trailing=true 时从 bestPrice 回撤 1.5×ATR 触发，trailStop 取 max/min 与原始 stop 合并，绝不扩大亏损）。
   - `updatedBest`：LONG 取最高 / SHORT 取最低的移动止盈锚点。
   - `inCooldown/cooldownRemainMs`：平仓后同品种同方向 4h 冷却。
3. **ViewModel 挂接**：500ms flush 内 `battleTick`——逐持仓用 positionPrices 实时价判定平仓（closeBattlePosition：删持仓 + 写 `auto|` 前缀 ReviewRecord 进胜率/学习/回测闭环 + 冷却 + 腾坑顶上 1 个）；`battleCandidates` 候补筛选（已确认/回踩确认 + 综合分≥70 + 未持仓 + 未冷却，按作战面板综合分降序）；`fillBattleSlots` 渐进补位（每轮 cap 3，in-flight 防重）；持仓价 tick 也触发 flush；空仓时自动顶上（循环自启动）。容量默认 10（选项扩至 1/2/3/5/8/10）；手动删除持仓同样进冷却。
4. **持久化（SQLite v6）**：position_records 新增 status/trailing/best_price/risk_reward/atr/timeframe/evidence_score/close_price/close_reason/closed_at；onCreate 同步建表；loadPositions runCatching 兜底旧行。
5. **UI**：工作台「仓位容量 + 自动作战全自动开/关 + 止盈固定/移动切换 + 循环统计（入/平/胜/负/盈亏）+ 候补队列」；持仓 Tab 头显示自动作战模式与统计；PosCard 加 🤖自动/移动止盈徽标 + 距止损/距止盈进度 + 移动止盈锚点。
6. **行为口径**：本地记账跟踪（不接交易所真实下单）；auto| 前缀结算样本计入胜率/学习/回测（与信号样本同口径，可事后区分）。
- 测试：107/107（新增 BattleLoopEngineTest 17 项：盈亏比定价/门控拒绝/四重平仓/移动止盈锚点与不劣于原止损/冷却/方向盈亏口径）。交付为源码包，未在本环境出 APK。
## v4.6 自动作战优化（用户 4 项修改 2026-10-12）
1. **盈亏比「止损 2 / 止盈 3」**：`BattleLoopEngine.buildEntry` 定价改为 stop=entry∓2×ATR、target=entry±3×ATR（`DEFAULT_STOP_MULT=2.0`/`DEFAULT_TARGET_MULT=3.0`，原 rr 参数移除）；EntryPlan 新增 stopMult/targetMult，riskReward=3/2=1.5；门控展示按止损距离（默认最小止损距离 0.6% 价、最大 10% 价）；自定义乘数可传参。
2. **收益明细与统计（本金 1 × 杠杆 50）**：autoEnterPosition 落库 leverage=50.0、size=1.0；持仓卡新增「实际盈亏50x」= 方向变动% × 50；工作台「已平实际盈亏」= battlePnlSum×50、「当前浮盈」= Σ move%×50；前台/后台平仓通知都带实际盈亏（×50）口径。
3. **满仓后作战台不再推荐**：满仓时作战面板/工作台隐藏候补与推荐，只显示「满仓暂停推荐」；`fillBattleSlots` 满仓清空 battleQueue；新增新鲜度门槛 `isFresh(candleTime, now, timeframe)`（15m→30min、30m→60min、1h→120min、4h→480min）——平仓后只自动补入新鲜确认信号，落后信号不进候补。
4. **后台常驻不断联**：`bg_monitor` 默认 true（init 默认开启）；`BackgroundMonitorService` 新增后台自动作战——`positionWatchLoop` 每 60s 用 repo.candles(limit=1) 轮询全部 LIVE 持仓现价，`settleBattlePositions` 每轮扫描价批量兜底，K 线新收盘单品种即时判定；与前台同一 `BattleLoopEngine.evaluateClose`（后台 crossCheckOk=true，无参考时不拦截）；平仓写 auto| 样本 + 删除持仓 + `battleClosedKeys` 冷却 + 系统通知「实际盈亏（本金1×50x）」。
5. **持久化（SQLite v7）**：position_records 新增 stop_mult REAL DEFAULT 2.0 / target_mult REAL DEFAULT 3.0；onCreate 同步建列；LocalPosition 新增 stopMult/targetMult（默认 2.0/3.0，旧行兼容）。
6. **防双端重复**：前台 ViewModel 与后台服务都可能触发平仓——写入用同一 auto| id（REPLACE 幂等）、删除按 id（二次无操作），互不破坏。
- 测试：109/109（BattleLoopEngineTest 19 项，新增自定义乘数、新鲜度窗口；kotlinc+junit 本地真实运行 OK）。交付为源码包，未在本环境出 APK。
## v4.7 作战台新鲜度滚动榜（优中选优，不堵死）
1. **作战台改「新鲜度滚动榜单」**：取消固定「主攻/候补/观察」3 卡，改为新鲜窗口内已确认/回踩确认信号按**作战评分**降序、最多展示 8 条的榜单；**过期自动下榜**（K 线时间超周期窗口即消失，哪怕分数高）——榜单持续滚动，旧信号不堵满；每条带 ⏱ 新鲜标记（刚刚确认 / N 分钟前，`freshBadge`）。
2. **作战评分 `BattleLoopEngine.battleScore`**：信号分×0.30 + 方向历史胜率×0.20 + 确认强度 progressAtr×0.15（≤2 ATR 归一）+ 波动健康×0.15 + **新鲜度×0.20**（`freshnessScore`：≤5 分钟满分、超窗口归 0、中间线性衰减）。榜单展示与自动入仓 `battleCandidates` 共用同一口径。
3. **自动入仓收紧（优中选优）**：仅 **A/B 级**（grade A/B，C 级只展示不自动进）+ 已确认/回踩确认 + 分≥70 + 未持仓 + 未冷却 + 新鲜窗口内；每轮最多补 min(空闲坑位, 3) 渐进建仓。
4. **空位持续推荐**：空闲坑位 = maxPositions − 当前持仓数；坑位 > 0 时作战台持续推荐（设 5 持仓 2 → 空 3 坑，每轮从榜首自动补位）；满仓才暂停推荐（沿用 v4.6）。
5. **修 bug（重要）**：Kotlin 不以行首 `+` 续行——battleScore 换行书写被解析成「return 第一项 + 若干独立废弃表达式」，导致评分恒等于信号分×0.3；已用括号包裹整个求和表达式修复；由新增单测「作战评分新鲜度权重」抓出并回归。
- 测试：111/111（BattleLoopEngineTest 21 项，新增新鲜度评分单调衰减、作战评分新鲜度权重）。交付为源码包，未在本环境出 APK。

## v4.8 全量审计修复（功能完结后体检 2026-10-12）
1. **P0-1 双结算口径统一**：后台 `settleByPrices` 由「扫描现价近似判定」改为优先拉真实 K 线调 `ReviewEngine.touch`（区间高/低点触碰、同时触碰判 miss，与前台完全同口径）；K 线不可用（冷门/限流）才回退扫描现价，回退优先级与前台一致（hit&&miss→miss → hit → miss → 超期 neutral）。函数改 suspend。
2. **P0-2 冷却持久化**：LocalStore DB v7→v8 新增 `battle_cooldowns`（PRIMARY KEY symbol+direction）；VM init `loadCooldowns()` 恢复内存；自动平仓（前台 VM + 后台 Service）与手动删仓均 `saveCooldown` 写库。`oppConfirm`/`autoEnterInFlight` 仍为会话态（重启由重新扫描重建，属设计取舍）。
3. **P0-3 双端平仓原子守卫**：LocalStore 新增 `reviewExists(id)`；VM/Service `closeBattlePosition` 改为只有首个写入方才保存样本 + 计数 + 发通知，另一方仅删持仓清状态。
4. **P1-1 关键路径失败可见**：`autoEnterPosition` 落库失败 →「⚠ 入仓落库失败」；`closeBattlePosition` 结算/删除失败 →「⚠ 结算落库失败，请到诊断页检查样本」。
5. **P1/P2 核查通过（未改）**：Binance 限流（418/429/5xx + Retry-After + 指数退避 1s/2s/4s + 并发 6 批）；后台保活（前台通知 + START_STICKY + 断线重连 + 扫描退避）；AnalysisEngine 除零/NaN（KDJ/RSI/ATR/volBase/ADX 全部有保护）；Double 展示口径统一。
6. **P2-2 测试补充**：BattleLoopEngineTest +6 边界（NaN/零值入仓拒绝、到价平仓、除零盈亏、冷却恰到期、新鲜度窗口边界、作战评分输入钳制）→ 27 项；全量 117/117 通过（kotlinc 2.0.21 编译 domain 16 文件 + 14 测试类 OK，仅 2 处历史无害 dead-code 警告未动）。
- 遗留（需有 SDK 环境）：Android 层整包 `assembleDebug` 复核；MainActivity 1662 行拆分（P1#9）与依赖弃用检查（P2#12）留待可构建环境。
