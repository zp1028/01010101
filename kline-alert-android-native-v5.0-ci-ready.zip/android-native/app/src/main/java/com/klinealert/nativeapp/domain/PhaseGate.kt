package com.klinealert.nativeapp.domain

/**
 * 机会三态（Phase Gate）：把「状态描述」升级为「交易机会」。
 *
 * - ⚡ 触发（TRIGGERED）：价格已回到入场区（触及触发价 ±0.3×ATR 容差），
 *   或确认状态机已走出「已确认/回踩确认」（顺势确认型，允许追确认）。
 *   只有触发态机会才进入机会榜主列表。
 * - 🕐 观察（WATCHING）：评分达标但价格还没到位——做多等回踩到入场区、做空等反抽到入场区。
 *   显示距触发价百分比，折叠在观察区，不与可交易机会混排。
 * - ❌ 失效：由既有信号失效机制处理（反向收盘破位、阶段转为假突破），从榜单移除。
 *
 * 触发价 = SmartLevels 入场价（结构位回踩/反抽位），做空做多镜像。
 */
data class OppPhase(
    val phase: String,          // "触发" | "观察"
    val triggerPrice: Double,   // 触发价（入场区）
    val distPct: Double,        // 当前价距触发价百分比（观察态用于等待进度；触发态为 0）
    val reason: String          // 触发原因说明
)

object PhaseGate {
    const val TRIGGERED = "触发"
    const val WATCHING = "观察"

    fun evaluate(sop: SymbolOpportunity, livePrice: Double?, confirm: com.klinealert.nativeapp.domain.Confirmation? = null): OppPhase {
        val a = sop.rep
        val long = sop.direction == "LONG"
        val atr = a.atr.takeIf { it != null && it > 0 } ?: (a.price * 0.01)
        val entry = a.entry.takeIf { it > 0 } ?: a.price
        // 入场区容差 0.3×ATR：贴到入场区附近即算触发，不必分毫不差
        val tol = 0.3 * atr
        val price = livePrice?.takeIf { it > 0 } ?: a.price
        // 顺势确认型触发：确认状态机已验证行情真实走出
        if (confirm != null && (confirm.status == "已确认" || confirm.status == "回踩确认")) {
            return OppPhase(TRIGGERED, entry, 0.0, if (confirm.status == "回踩确认") "回踩确认·顺势" else "快速确认·顺势")
        }
        // 触发 = 价格落在入场区（±0.3×ATR）内；区外无论哪一侧都是观察态
        val inZone = kotlin.math.abs(price - entry) <= tol
        return if (inZone) {
            OppPhase(TRIGGERED, entry, 0.0, if (long) "回调至入场区" else "反抽至入场区")
        } else {
            val dist = (price - entry) / price * 100
            OppPhase(WATCHING, entry, dist, if (long) "等回踩入场区" else "等反抽入场区")
        }
    }
}
