package com.klinealert.nativeapp.domain

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Source-aligned native analysis. The original TypeScript engine remains the parity oracle. */
data class Candle(val openTime: Long, val open: Double, val high: Double, val low: Double, val close: Double, val volume: Double, val closeTime: Long)
data class Analysis(
    val symbol: String, val market: String, val timeframe: String, val price: Double, val changePct: Double,
    val rsi14: Double?, val ema20: Double?, val ema50: Double?, val direction: String, val score: Int,
    val reason: String, val candleTime: Long, val atr: Double = 0.0, val atrPct: Double = 0.0,
    val macdHist: Double? = null, val kdjK: Double? = null, val kdjD: Double? = null,
    val support: Double? = null, val resistance: Double? = null, val entry: Double = price,
    val stop: Double = price, val target: Double = price, val riskReward: Double = 0.0,
    val regime: String = "区间震荡", val regimeConfidence: Double = 50.0,
    val confidence: Int = 0, val swingHigh: Double? = null, val swingLow: Double? = null,
    val supportConfluence: Int = 1, val resistanceConfluence: Int = 1,
    val supportLabel: String = "", val resistanceLabel: String = "",
    val adx: Double = 0.0, val states: List<IndicatorState> = emptyList(),
    val patterns: List<String> = emptyList(),
    val volExpansion: Double = 1.0,
    val volRatio: Double = 1.0,            // 当根量比（量/20根均量）
    val volumePattern: String = ""         // 量价形态（VolumePriceClassifier 8 形态之一）
)

data class IndicatorSnapshot(
    val price: Double, val ema20: Double, val ema60: Double, val ema200: Double,
    val emaFast: Double, val emaSlow: Double, val emaCross: String?, val emaBarsAgo: Int?,
    val macdDif: Double, val macdDea: Double, val macdHist: Double, val macdCross: String?, val macdBarsAgo: Int?,
    val k: Double, val d: Double, val j: Double, val kdjCross: String?, val kdjBarsAgo: Int?,
    val rsi: Double, val rsiRising: Boolean, val atr: Double, val atrPct: Double,
    val bollUpper: Double, val bollMid: Double, val bollLower: Double,
    val support: Double?, val resistance: Double?, val regime: String, val volumeRatio: Double,
    val supportStrength: Double = 1.0, val resistanceStrength: Double = 1.0,
    val supportConfluence: Int = 1, val resistanceConfluence: Int = 1,
    val regimeConfidence: Double = 50.0,
    val supportLabel: String = "", val resistanceLabel: String = "",
    val adx: Double = 0.0, val adxRising: Boolean = false,
    val obvDivergence: String = "", val volStreak: String = "",
    val states: List<IndicatorState> = emptyList()
)

object AnalysisEngine {
    val supportedTimeframes = listOf("15m", "30m", "1h", "4h")
    private const val MIN_CANDLES = 220
    private const val NEAR_PCT = 0.008
    private const val MIN_ATR_PCT = 0.15
    private const val MIN_SCORE = 50
    private const val CROSS_LOOKBACK = 3

    fun analyze(symbol: String, market: String, timeframe: String, candles: List<Candle>): Analysis? {
        if (timeframe !in supportedTimeframes) return null
        val sorted = candles.sortedBy { it.openTime }.distinctBy { it.openTime }
        if (sorted.size < MIN_CANDLES) return null
        // Match the original engine: indicators/signals are calculated on closed candles only.
        val closed = if (sorted.size > 1) sorted.dropLast(1) else sorted
        if (closed.size < MIN_CANDLES) return null
        val snap = snapshot(closed) ?: return null
        val price = snap.price
        if (price <= 0 || snap.atrPct < MIN_ATR_PCT) return null
        val nearSupport = snap.support?.takeIf { abs(price - it) / price <= NEAR_PCT }
        val nearResistance = snap.resistance?.takeIf { abs(price - it) / price <= NEAR_PCT }
        val bullCrosses = listOf(snap.macdCross to snap.macdBarsAgo, snap.emaCross to snap.emaBarsAgo, snap.kdjCross to snap.kdjBarsAgo)
            .count { it.first == "golden" && (it.second ?: Int.MAX_VALUE) <= CROSS_LOOKBACK }
        val bearCrosses = listOf(snap.macdCross to snap.macdBarsAgo, snap.emaCross to snap.emaBarsAgo, snap.kdjCross to snap.kdjBarsAgo)
            .count { it.first == "dead" && (it.second ?: Int.MAX_VALUE) <= CROSS_LOOKBACK }
        val trendUp = price > snap.ema200
        val rsiOversold = snap.rsi <= 35.0 && snap.rsiRising
        val rsiOverbought = snap.rsi >= 65.0 && !snap.rsiRising
        // Preserve the source engine's weighted level model: 25 + strength*5,
        // with a six-point bonus when independent level families converge.
        var bull = (if (nearSupport != null) 25 + snap.supportStrength * 5 + (if (snap.supportConfluence >= 3) 6 else 0) else 0.0) +
            bullCrosses * 18 + (if (rsiOversold) 10 else 0) + (if (trendUp) 8 else 0) +
            (if (snap.volumeRatio >= 1.5) 7 else 0) - (if (snap.rsi >= 70) 8 else 0)
        var bear = (if (nearResistance != null) 25 + snap.resistanceStrength * 5 + (if (snap.resistanceConfluence >= 3) 6 else 0) else 0.0) +
            bearCrosses * 18 + (if (rsiOverbought) 10 else 0) + (if (!trendUp) 8 else 0) +
            (if (snap.volumeRatio >= 1.5) 7 else 0) - (if (snap.rsi <= 30) 8 else 0)
        // ---- M2 模式库探测器（在方向判定前修正得分） ----
        val patternNotes = mutableListOf<String>()
        // 负向排除：量价背离
        if (snap.obvDivergence == "顶背离") { bull -= 10; patternNotes += "⚠ 量价顶背离（价涨量缩，上攻动能存疑）" }
        if (snap.obvDivergence == "底背离") { bear -= 10; patternNotes += "⚠ 量价底背离（价跌量增，抛压反而释放）" }
        // 顺势模式：放量突破
        if (snap.regime == "突破承压线" && snap.volumeRatio >= 1.5) { bull += 10; patternNotes += "✓ 放量突破关键位（${snap.volumeRatio.fmt(1)}×量）" }
        if (snap.regime == "下跌延续" && snap.volumeRatio >= 1.5) { bear += 6; patternNotes += "✓ 放量下跌延续（${snap.volumeRatio.fmt(1)}×量）" }
        // 反向模式：假突破回落
        if (snap.regime == "假突破") { bear += 8; patternNotes += "✓ 上破失败（假突破回落模型）" }
        // 趋势回调入场模型：趋势方向上的关键位回调
        if (snap.regime == "上涨回调" && trendUp && nearSupport != null) { bull += 8; patternNotes += "✓ 趋势回调至关键位（顺势回调入场模型）" }
        if (snap.regime == "反弹" && !trendUp && nearResistance != null) { bear += 8; patternNotes += "✓ 空头趋势反抽至承压位（顺势反抽模型）" }
        // 趋势衰竭警告：强趋势但 ADX 已回落
        if (snap.adx > 45 && !snap.adxRising) { bull -= 6; bear -= 6; patternNotes += "⚠ ADX ${snap.adx.fmt(1)} 高位衰竭，追单风险" }
        val direction = if (bull >= bear) "LONG" else "SHORT"
        val score = max(bull, bear).toInt().coerceIn(0, 100)
        if (score < MIN_SCORE) return null
        val atr = snap.atr.takeIf { it > 0 } ?: price * 0.01
        val entry = price
        val stop: Double
        val target: Double
        val reasons = mutableListOf<String>()
        if (direction == "LONG") {
            nearSupport?.let {
                val pct = (it - price) / price * 100
                reasons += "价格临近支撑位 ${snap.supportLabel} @ ${fmt(it)}（位在价格${if (pct >= 0) "上方" else "下方"} ${abs(pct).fmt(2)}%）"
            }
            if (nearSupport != null && snap.supportConfluence >= 3) reasons += "支撑位多源共振（${snap.supportConfluence} 类来源）"
            if (bullCrosses > 0) reasons += "${bullCrosses} 项指标在 ${CROSS_LOOKBACK} 根K线内金叉"
            if (rsiOversold) reasons += "RSI14 ${snap.rsi.fmt(1)} 超卖回升"
            if (snap.volumeRatio >= 1.5) reasons += "成交量放大 ${snap.volumeRatio.fmt(1)}×"
            if (trendUp) reasons += "价格位于 EMA200 上方"
            stop = min(price - 1.5 * atr, (nearSupport?.minus(0.5 * atr) ?: Double.POSITIVE_INFINITY))
            target = max(price + 1.5 * atr, snap.resistance ?: Double.NEGATIVE_INFINITY)
        } else {
            nearResistance?.let {
                val pct = (it - price) / price * 100
                reasons += "价格临近承压位 ${snap.resistanceLabel} @ ${fmt(it)}（位在价格${if (pct >= 0) "上方" else "下方"} ${abs(pct).fmt(2)}%）"
            }
            if (nearResistance != null && snap.resistanceConfluence >= 3) reasons += "承压位多源共振（${snap.resistanceConfluence} 类来源）"
            if (bearCrosses > 0) reasons += "${bearCrosses} 项指标在 ${CROSS_LOOKBACK} 根K线内死叉"
            if (rsiOverbought) reasons += "RSI14 ${snap.rsi.fmt(1)} 高位走弱"
            if (snap.volumeRatio >= 1.5) reasons += "成交量放大 ${snap.volumeRatio.fmt(1)}×"
            if (!trendUp) reasons += "价格位于 EMA200 下方"
            stop = max(price + 1.5 * atr, (nearResistance?.plus(0.5 * atr) ?: Double.NEGATIVE_INFINITY))
            target = min(price - 1.5 * atr, snap.support ?: Double.POSITIVE_INFINITY)
        }
        val rr = abs(target - entry) / max(abs(entry - stop), 1e-12)
        if (reasons.isEmpty()) reasons += "多指标综合评分达到阈值；等待关键位或交叉信号进一步确认"
        reasons += patternNotes
        // 指标状态机摘要：当前状态与延续范围（含此前已发生、延续中的信号）
        val keyStates = listOf("MACD", "ADX", "量能", "EMA200", "RSI")
            .mapNotNull { name -> snap.states.firstOrNull { it.name == name } }
        if (keyStates.isNotEmpty()) reasons += keyStates.joinToString("；") { it.compact() }
        reasons += "市场阶段：${snap.regime}；ATR ${(snap.atrPct).fmt(2)}%"
        val levelConfluence = if (direction == "LONG") snap.supportConfluence else snap.resistanceConfluence
        val confluenceComponent = (levelConfluence.coerceIn(1, 5) - 1) * 25.0
        val volumeComponent = (snap.volumeRatio / 2.0).coerceIn(0.0, 1.0) * 100.0
        val rrComponent = (rr / 2.0).coerceIn(0.0, 1.0) * 100.0
        val confidence = (snap.regimeConfidence * 0.30 + score * 0.30 + confluenceComponent * 0.20 + volumeComponent * 0.10 + rrComponent * 0.10).toInt().coerceIn(0, 100)
        val swingBars = closed.takeLast(96)
        val swingHigh = swingBars.maxOfOrNull { it.high }
        val swingLow = swingBars.minOfOrNull { it.low }
        return Analysis(symbol, market, timeframe, price, (price / closed[max(0, closed.lastIndex - 4)].close - 1) * 100,
            snap.rsi, snap.ema20, snap.ema60, direction, score, reasons.joinToString("；"), closed.last().closeTime,
            atr, snap.atrPct, snap.macdHist, snap.k, snap.d, snap.support, snap.resistance, entry, stop, target, rr, snap.regime, snap.regimeConfidence,
            confidence, swingHigh, swingLow, snap.supportConfluence, snap.resistanceConfluence,
            snap.supportLabel, snap.resistanceLabel, snap.adx, snap.states,
            patternNotes.filter { it.startsWith("✓") }.map { it.removePrefix("✓ ").substringBefore("（") },
            volExpansion(closed, snap.atr),
            snap.volumeRatio,
            VolumePriceClassifier.classify(closed, snap.volumeRatio, snap.atr, snap.support, snap.resistance, snap.ema20).first)
    }

    /** 波动扩张率：当前 ATR / 近 20 根 ATR 均值。>1.3=波动放大期，<0.7=收缩期。 */
    fun volExpansion(candles: List<Candle>, currentAtr: Double): Double {
        if (candles.size < 21 || currentAtr <= 0) return 1.0
        val h = candles.map { it.high }; val l = candles.map { it.low }; val c = candles.map { it.close }
        val atrs = atrSeries(h, l, c, 14)
        val recent = atrs.takeLast(20).filter { it.isFinite() && it > 0 }
        if (recent.isEmpty()) return 1.0
        return (currentAtr / recent.average()).coerceIn(0.5, 3.0)
    }

    fun snapshot(candles: List<Candle>): IndicatorSnapshot? {
        if (candles.size < 60) return null
        val c = candles.map { it.close }; val h = candles.map { it.high }; val l = candles.map { it.low }; val v = candles.map { it.volume }
        if (c.any { !it.isFinite() } || c.any { it <= 0.0 }) return null
        val e20s = emaSeries(c, 20); val e60s = emaSeries(c, 60); val e200s = emaSeries(c, 200)
        val ef = emaSeries(c, 9); val es = emaSeries(c, 21)
        val (dif, dea, hist) = macd(c); val (ks, ds, js) = kdj(h, l, c)
        val rsi = rsiSeries(c, 14); val atrs = atrSeries(h, l, c, 14)
        val (mid, upper, lower) = bollinger(c, 20, 2.0)
        val idx = c.lastIndex
        val nativeLevels = buildLevels(candles, e20s[idx], e60s[idx], e200s[idx], upper[idx], lower[idx], mid[idx])
        val price = c[idx]
        val supportLevel = nativeLevels.filter { it.price < price }.minByOrNull { abs(it.price - price) }
        val resistanceLevel = nativeLevels.filter { it.price >= price }.minByOrNull { abs(it.price - price) }
        val support = supportLevel?.price
        val resistance = resistanceLevel?.price
        val supportStrength = supportLevel?.strength ?: 1.0
        val resistanceStrength = resistanceLevel?.strength ?: 1.0
        val supportConfluence = supportLevel?.confluence ?: 1
        val resistanceConfluence = resistanceLevel?.confluence ?: 1
        val supportLabel = supportLevel?.label ?: ""
        val resistanceLabel = resistanceLevel?.label ?: ""
        val volBase = v.takeLast(20).average().let { if (it <= 0) 1.0 else it }
        val adxArr = adxSeries(h, l, c, 14)
        val adx = adxArr.getOrNull(idx)?.takeIf { it.isFinite() } ?: 0.0
        val adxRef = adxArr.getOrNull(max(0, idx - 5))?.takeIf { it.isFinite() } ?: adx
        val adxRising = adx > adxRef
        val (obvDiv, _) = obvDivergence(c, v)
        val volRatio = v.last() / volBase
        val volUpStreak = run { var n = 0; for (i in idx downTo max(1, idx - 9)) { if (v[i] > volBase * 1.5) n++ else break }; n }
        val volDownStreak = run { var n = 0; for (i in idx downTo max(1, idx - 9)) { if (v[i] < volBase * 0.6) n++ else break }; n }
        val volStreak = when {
            volUpStreak >= 2 -> "连续${volUpStreak}根放量"
            volDownStreak >= 2 -> "连续${volDownStreak}根缩量"
            else -> "量能平稳"
        }
        val regime = classifyRegime(h, l, c, e20s, e60s, e200s, adx, v, upper, lower, mid)

        // ---- 指标状态机：报告"当前状态 + 延续范围" ----
        val states = mutableListOf<IndicatorState>()
        val macdMom = when {
            idx > 0 && hist[idx].isFinite() && hist[idx - 1].isFinite() ->
                if (hist[idx] >= 0 && abs(hist[idx]) >= abs(hist[idx - 1])) "红柱扩大" 
                else if (hist[idx] >= 0) "红柱收敛" 
                else if (abs(hist[idx]) >= abs(hist[idx - 1])) "绿柱扩大" else "绿柱收敛"
            else -> ""
        }
        crossState("MACD", dif, dea, idx, macdMom)?.let { states += it }
        crossState("EMA9/21", ef, es, idx)?.let { states += it }
        val kdjZone = when { ks[idx] >= 80 -> "超买区"; ks[idx] <= 20 -> "超卖区"; else -> "中性区" }
        crossState("KDJ", ks, ds, idx, kdjZone)?.let { states += it }
        val above20 = streak(c, e20s, above = true, idx)
        val below20 = streak(c, e20s, above = false, idx)
        if (above20 >= 2) states += IndicatorState("EMA20", "价格上方运行", "价格在 EMA20 上方已连续 ${above20} 根，短期多头结构延续中")
        else if (below20 >= 2) states += IndicatorState("EMA20", "价格下方运行", "价格在 EMA20 下方已连续 ${below20} 根，短期空头结构延续中")
        val above200 = streak(c, e200s, above = true, idx)
        val below200 = streak(c, e200s, above = false, idx)
        if (above200 >= 2) states += IndicatorState("EMA200", "牛市结构", "价格在 EMA200 上方已持续 ${above200} 根，中期多头趋势延续")
        else if (below200 >= 2) states += IndicatorState("EMA200", "熊市结构", "价格在 EMA200 下方已持续 ${below200} 根，中期空头趋势延续")
        val rsiUp = consecutiveRising(rsi, idx)
        val rsiZone = when {
            rsi[idx] >= 70 -> "超买"; rsi[idx] >= 55 -> "中性偏强"; rsi[idx] > 45 -> "中性"
            rsi[idx] > 30 -> "中性偏弱"; else -> "超卖"
        }
        states += IndicatorState("RSI", rsiZone,
            "RSI ${rsi[idx].fmt(1)}" + if (rsiUp >= 2) "，已连续 ${rsiUp} 根回升，动能延续" else "，动能未形成连续回升")
        val adxState = when {
            adx < 20 -> "无趋势（震荡）"
            adx < 40 -> "趋势进行中"
            else -> "强趋势"
        }
        states += IndicatorState("ADX", adxState,
            "ADX ${adx.fmt(1)}" + (if (adxRising) "，仍在增强" else "，已开始衰竭") + if (adx >= 45 && !adxRising) "，趋势末端风险" else "")
        states += IndicatorState("量能", "放量${volRatio.fmt(1)}×", volStreak + 
            (if (obvDiv == "顶背离") "；OBV 顶背离：价格上行但 OBV 走低，上攻动能存疑" 
             else if (obvDiv == "底背离") "；OBV 底背离：价格下行但 OBV 走高，下跌动能衰竭" else "；量价配合正常"))
        val bwNow = if (mid[idx].isFinite() && mid[idx] != 0.0) (upper[idx] - lower[idx]) / mid[idx] * 100 else 0.0
        val bwRefIdx = max(0, idx - 20)
        val bwRef = if (mid[bwRefIdx].isFinite() && mid[bwRefIdx] != 0.0) (upper[bwRefIdx] - lower[bwRefIdx]) / mid[bwRefIdx] * 100 else bwNow
        val bollPos = when {
            c[idx] >= upper[idx] * 0.995 -> "贴上轨"
            c[idx] <= lower[idx] * 1.005 -> "贴下轨"
            c[idx] > mid[idx] -> "中轨上方"
            else -> "中轨下方"
        }
        states += IndicatorState("布林", bollPos,
            "带宽 ${bwNow.fmt(2)}%" + if (bwNow < bwRef * 0.7) "，显著收敛（挤压，变盘临近）" else if (bwNow > bwRef * 1.4) "，显著扩张（趋势展开）" else "，带宽平稳")

        return IndicatorSnapshot(c[idx], e20s[idx], e60s[idx], e200s[idx], ef[idx], es[idx], lastCross(ef, es)?.second, lastCross(ef, es)?.first,
            dif[idx], dea[idx], hist[idx], lastCross(dif, dea)?.second, lastCross(dif, dea)?.first,
            ks[idx], ds[idx], js[idx], lastCross(ks, ds)?.second, lastCross(ks, ds)?.first,
            rsi[idx], rsi.size > 1 && rsi[idx] > rsi[idx-1], atrs[idx], atrs[idx] / c[idx] * 100,
            upper[idx], mid[idx], lower[idx], support, resistance, regime.label, volRatio,
            supportStrength, resistanceStrength, supportConfluence, resistanceConfluence, regime.confidence,
            supportLabel, resistanceLabel, adx, adxRising, obvDiv, volStreak, states)
    }

    private data class RegimeResult(val label: String, val confidence: Double)

    /** Eight-state regime classifier aligned to src/engine/regime.ts priority rules. */
    private fun classifyRegime(
        high: List<Double>, low: List<Double>, close: List<Double>,
        ema20: DoubleArray, ema60: DoubleArray, ema200: DoubleArray,
        adx: Double, volume: List<Double>, bollUpper: DoubleArray, bollLower: DoubleArray, bollMid: DoubleArray
    ): RegimeResult {
        val n = close.size
        if (n == 0) return RegimeResult("区间震荡", 20.0)
        val price = close.last()
        val avgVol = volume.takeLast(20).average().takeIf { it > 0.0 } ?: 1.0
        val volRatio = volume.last() / avgVol
        val slope20 = if (n >= 6 && ema20[n - 6].isFinite() && ema20[n - 1].isFinite() && ema20[n - 6] != 0.0)
            (ema20[n - 1] - ema20[n - 6]) / abs(ema20[n - 6]) * 100.0 / 5.0 else 0.0
        val bw = if (bollMid.last().isFinite() && bollMid.last() != 0.0)
            (bollUpper.last() - bollLower.last()) / bollMid.last() * 100.0 else 0.0
        val lookback = 60
        val bars = 3
        var breakoutDirection = ""
        var breakoutHeld = false
        if (n >= lookback + bars + 1) {
            val refStart = n - lookback - bars
            val refEnd = n - bars
            val upRef = (refStart until refEnd).maxOf { high[it] }
            val downRef = (refStart until refEnd).minOf { low[it] }
            val recent = (n - bars until n).map { close[it] }
            val segMax = recent.maxOrNull() ?: price
            val segMin = recent.minOrNull() ?: price
            if (segMax > upRef) {
                breakoutDirection = "up"; breakoutHeld = price >= upRef
            } else if (segMin < downRef) {
                breakoutDirection = "down"; breakoutHeld = price <= downRef
            }
        }
        val above200 = ema200.last().isFinite() && price > ema200.last()
        val bullAlign = ema20.last().isFinite() && ema60.last().isFinite() && ema20.last() > ema60.last()
        val bearAlign = ema20.last().isFinite() && ema60.last().isFinite() && ema20.last() < ema60.last()
        val recentAbove20 = (max(0, n - 8) until n).any { ema20[it].isFinite() && close[it] > ema20[it] }
        var confidence: Double
        val phase = when {
            breakoutDirection == "up" && breakoutHeld -> { confidence = 60 + min(volRatio, 3.0) * 8 + min(adx, 40.0) * 0.3; "突破承压线" }
            breakoutDirection == "up" && !breakoutHeld -> { confidence = 58 + min(volRatio, 3.0) * 6 + min(abs(slope20) * 5, 12.0); "假突破" }
            breakoutDirection == "down" && breakoutHeld -> { confidence = 55 + min(volRatio, 3.0) * 6 + min(adx, 40.0) * 0.3; "下跌延续" }
            breakoutDirection == "down" && !breakoutHeld -> { confidence = 55 + min(volRatio, 3.0) * 6 + min(adx, 40.0) * 0.3; "反弹" }
            adx < 20 -> { confidence = 45 + (20 - adx) + max(0.0, 3 - bw / 5) * 4; "区间震荡" }
            bullAlign && above200 -> { confidence = 45 + min(adx, 50.0) * 0.7 + min(abs(slope20) * 10, 15.0); if (price >= ema20.last()) "上涨延续" else "上涨回调" }
            bearAlign && !above200 -> {
                confidence = 45 + min(adx, 50.0) * 0.7 + min(abs(slope20) * 10, 15.0)
                when { price > ema20.last() -> "反弹"; recentAbove20 -> "反抽转弱"; else -> "下跌延续" }
            }
            else -> { confidence = 42 + min(adx, 40.0) * 0.5; when { price > ema20.last() && !above200 -> "反弹"; price < ema20.last() && above200 -> "上涨回调"; else -> "区间震荡" } }
        }
        val structure = swingStructure(high, low)
        if (phase == "上涨延续" && structure == "up") confidence += 8
        if (phase == "下跌延续" && structure == "down") confidence += 8
        if (phase == "假突破" && structure == "down") confidence += 6
        return RegimeResult(phase, confidence.coerceIn(20.0, 99.0))
    }

    private fun swingStructure(high: List<Double>, low: List<Double>): String {
        val n = high.size
        val left = 3; val right = 3
        val start = max(left, n - 90)
        if (start >= n - right) return "mixed"
        val pivHigh = mutableListOf<Double>(); val pivLow = mutableListOf<Double>()
        for (i in start until n - right) {
            val window = (i - left..i + right)
            if (window.all { high[it] <= high[i] } && (high[i] > high[i - 1] || high[i] > high[i + 1])) pivHigh += high[i]
            if (window.all { low[it] >= low[i] } && (low[i] < low[i - 1] || low[i] < low[i + 1])) pivLow += low[i]
        }
        if (pivHigh.size >= 2 && pivLow.size >= 2) {
            if (pivHigh.last() > pivHigh[pivHigh.lastIndex - 1] && pivLow.last() > pivLow[pivLow.lastIndex - 1]) return "up"
            if (pivHigh.last() < pivHigh[pivHigh.lastIndex - 1] && pivLow.last() < pivLow[pivLow.lastIndex - 1]) return "down"
        }
        return "mixed"
    }

    private fun emaSeries(x: List<Double>, p: Int): DoubleArray {
        val out = DoubleArray(x.size) { Double.NaN }; if (x.size < p) return out
        var value = x.take(p).average(); out[p-1] = value; val a = 2.0 / (p + 1.0)
        for (i in p until x.size) { value = x[i] * a + value * (1-a); out[i] = value }; return out
    }
    private fun rsiSeries(c: List<Double>, p: Int): DoubleArray {
        val out = DoubleArray(c.size) { Double.NaN }; if (c.size <= p) return out
        var gain = 0.0; var loss = 0.0
        for (i in 1..p) { val d = c[i]-c[i-1]; gain += max(0.0,d); loss += max(0.0,-d) }
        gain /= p; loss /= p; out[p] = if (loss == 0.0) 100.0 else 100-100/(1+gain/loss)
        for (i in p+1 until c.size) { val d=c[i]-c[i-1]; gain=(gain*(p-1)+max(0.0,d))/p; loss=(loss*(p-1)+max(0.0,-d))/p; out[i]=if(loss==0.0)100.0 else 100-100/(1+gain/loss) }; return out
    }
    private fun macd(c: List<Double>): Triple<DoubleArray,DoubleArray,DoubleArray> {
        val f=emaSeries(c,12); val s=emaSeries(c,26); val dif=DoubleArray(c.size){f[it]-s[it]}; val first=25
        val seg=dif.drop(first); val deaSeg=emaSeries(seg,9); val dea=DoubleArray(c.size){Double.NaN}
        for(i in deaSeg.indices) dea[first+i]=deaSeg[i]
        val hist=DoubleArray(c.size){(dif[it]-dea[it])*2}; return Triple(dif,dea,hist)
    }
    private fun kdj(h: List<Double>, l: List<Double>, c: List<Double>): Triple<DoubleArray,DoubleArray,DoubleArray> {
        val k=DoubleArray(c.size){Double.NaN}; val d=DoubleArray(c.size){Double.NaN}; val j=DoubleArray(c.size){Double.NaN}; var pk=50.0; var pd=50.0
        for(i in 8 until c.size) { val hh=h.subList(i-8,i+1).maxOrNull()!!; val ll=l.subList(i-8,i+1).minOrNull()!!; val r=if(hh==ll)50.0 else (c[i]-ll)/(hh-ll)*100; pk=(pk*2+r)/3; pd=(pd*2+pk)/3; k[i]=pk; d[i]=pd; j[i]=3*pk-2*pd }; return Triple(k,d,j)
    }
    private fun atrSeries(h: List<Double>, l: List<Double>, c: List<Double>, p: Int): DoubleArray {
        val tr=DoubleArray(c.size); for(i in c.indices) tr[i]=if(i==0) h[i]-l[i] else max(h[i]-l[i], max(abs(h[i]-c[i-1]),abs(l[i]-c[i-1])))
        val out=DoubleArray(c.size){Double.NaN}; if(c.size<p)return out; var x=tr.take(p).average(); out[p-1]=x
        for(i in p until c.size){x=(x*(p-1)+tr[i])/p;out[i]=x}; return out
    }
    private fun bollinger(c: List<Double>, p: Int, mult: Double): Triple<DoubleArray,DoubleArray,DoubleArray> {
        val m=DoubleArray(c.size){Double.NaN}; val u=m.copyOf(); val lo=m.copyOf()
        for(i in p-1 until c.size){val w=c.subList(i-p+1,i+1);val avg=w.average();val sd=sqrt(w.sumOf{(it-avg)*(it-avg)}/p);m[i]=avg;u[i]=avg+mult*sd;lo[i]=avg-mult*sd};return Triple(m,u,lo)
    }
    private fun lastCross(a: DoubleArray,b: DoubleArray): Pair<Int,String>? {
        for(i in a.lastIndex downTo 1) if(a[i].isFinite()&&b[i].isFinite()&&a[i-1].isFinite()&&b[i-1].isFinite()) {
            if(a[i]>b[i]&&a[i-1]<=b[i-1]) return (a.lastIndex-i) to "golden"
            if(a[i]<b[i]&&a[i-1]>=b[i-1]) return (a.lastIndex-i) to "dead"
        };return null
    }
    private data class NativeLevel(
        val price: Double, val kind: String, val strength: Double,
        val role: String, val confluence: Int = 1, val label: String = ""
    )

    /** Port of src/engine/levels.ts: swing clustering + MA/Bollinger/Fibonacci confluence. */
    private fun buildLevels(
        candles: List<Candle>, ema20: Double, ema60: Double, ema200: Double,
        bollUpper: Double, bollLower: Double, bollMid: Double
    ): List<NativeLevel> {
        if (candles.isEmpty()) return emptyList()
        val n = candles.size
        val price = candles.last().close
        val highs = candles.map { it.high }
        val lows = candles.map { it.low }
        data class Pivot(val index: Int, val price: Double, val side: String)
        val pivots = mutableListOf<Pivot>()
        val left = 5; val right = 5; val lookback = 220
        val start = max(left, n - lookback)
        if (start < n - right) {
            for (i in start until n - right) {
                val window = (i - left..i + right)
                val isHigh = window.all { highs[it] <= highs[i] } && (highs[i] > highs[i - 1] || highs[i] > highs[i + 1])
                val isLow = window.all { lows[it] >= lows[i] } && (lows[i] < lows[i - 1] || lows[i] < lows[i + 1])
                if (isHigh) pivots += Pivot(i, highs[i], "high")
                if (isLow) pivots += Pivot(i, lows[i], "low")
            }
        }
        val sortedPivots = pivots.sortedBy { it.price }
        val clusters = mutableListOf<MutableList<Pivot>>()
        for (pivot in sortedPivots) {
            val last = clusters.lastOrNull()
            if (last == null || abs(pivot.price - last.last().price) / last.last().price > 0.005) clusters += mutableListOf(pivot)
            else last += pivot
        }
        val levels = mutableListOf<NativeLevel>()
        for (cluster in clusters) {
            val levelPrice = cluster.map { it.price }.average()
            val barsAgo = cluster.minOf { n - 1 - it.index }
            val recency = max(0.0, 1.0 - barsAgo.toDouble() / max(n, 1))
            val strength = min(5.0, 1.0 + (cluster.size - 1) * 0.8 + recency)
            levels += NativeLevel(levelPrice, "swing", strength, if (cluster.first().side == "high") "resistance" else "support",
                label = "摆动${if (cluster.first().side == "high") "高" else "低"}×${cluster.size}")
        }
        listOf(20 to ema20, 60 to ema60, 200 to ema200).forEach { (period, value) ->
            if (value.isFinite() && value != 0.0) levels += NativeLevel(value, "ma", 2.0, if (value >= price) "resistance" else "support", label = "EMA$period")
        }
        if (bollUpper.isFinite()) levels += NativeLevel(bollUpper, "boll", 2.0, if (bollUpper >= price) "resistance" else "support", label = "布林上轨")
        if (bollLower.isFinite()) levels += NativeLevel(bollLower, "boll", 2.0, if (bollLower >= price) "resistance" else "support", label = "布林下轨")
        if (bollMid.isFinite() && bollMid != 0.0) levels += NativeLevel(bollMid, "boll", 1.5, if (bollMid >= price) "resistance" else "support", label = "布林中轨")

        val fibLookback = 150
        val fibStart = max(0, highs.size - fibLookback)
        var hiIndex = fibStart; var loIndex = fibStart
        for (i in fibStart until highs.size) {
            if (highs[i] > highs[hiIndex]) hiIndex = i
            if (lows[i] < lows[loIndex]) loIndex = i
        }
        val hi = highs[hiIndex]; val lo = lows[loIndex]; val range = hi - lo
        if (range > 0.0) {
            val uptrend = loIndex > hiIndex
            listOf(0.236, 0.382, 0.5, 0.618, 0.786).forEach { ratio ->
                val levelPrice = if (uptrend) hi - range * ratio else lo + range * ratio
                levels += NativeLevel(levelPrice, "fib", 2.0, if (levelPrice >= price) "resistance" else "support",
                    label = "Fib 回撤 ${((if (uptrend) (hi - levelPrice) / range else (levelPrice - lo) / range) * 100).fmt(0)}%")
            }
        }
        val valid = levels.filter { it.price > 0.0 && it.price.isFinite() }.map { level ->
            val kinds = validKinds(level, levels, 0.008)
            level.copy(role = if (level.price >= price) "resistance" else "support", confluence = kinds.size,
                strength = min(6.0, level.strength + (kinds.size - 1) * 0.7))
        }
        return valid
    }

    private fun validKinds(level: NativeLevel, all: List<NativeLevel>, nearPct: Double): Set<String> {
        val kinds = mutableSetOf(level.kind)
        all.forEach { other ->
            if (other !== level && abs(level.price - other.price) / level.price <= nearPct) kinds += other.kind
        }
        return kinds
    }

    private fun wilderSmooth(values: DoubleArray, period: Int): DoubleArray {
        val out = DoubleArray(values.size) { Double.NaN }
        if (values.size < period) return out
        out[period - 1] = values.take(period).average()
        for (i in period until values.size) out[i] = (out[i - 1] * (period - 1) + values[i]) / period
        return out
    }

    /** Wilder ADX series matching src/engine/indicators.ts rather than a simple average of recent DX. */
    private fun adxSeries(h: List<Double>, l: List<Double>, c: List<Double>, period: Int): DoubleArray {
        val n = c.size
        if (n < period * 2) return DoubleArray(n) { 0.0 }
        val tr = DoubleArray(n)
        val plusDm = DoubleArray(n)
        val minusDm = DoubleArray(n)
        for (i in 0 until n) {
            if (i == 0) { tr[i] = h[i] - l[i]; continue }
            val up = h[i] - h[i - 1]
            val down = l[i - 1] - l[i]
            plusDm[i] = if (up > down && up > 0) up else 0.0
            minusDm[i] = if (down > up && down > 0) down else 0.0
            tr[i] = max(h[i] - l[i], max(abs(h[i] - c[i - 1]), abs(l[i] - c[i - 1])))
        }
        val atrSmooth = wilderSmooth(tr.drop(1).toDoubleArray(), period)
        val plusSmooth = wilderSmooth(plusDm.drop(1).toDoubleArray(), period)
        val minusSmooth = wilderSmooth(minusDm.drop(1).toDoubleArray(), period)
        val dx = DoubleArray(n) { Double.NaN }
        for (i in atrSmooth.indices) {
            val atr = atrSmooth[i]
            if (atr > 0.0) {
                val plus = 100.0 * plusSmooth[i] / atr
                val minus = 100.0 * minusSmooth[i] / atr
                val denominator = plus + minus
                if (denominator > 0.0) dx[i + 1] = 100.0 * abs(plus - minus) / denominator
            }
        }
        val first = dx.indexOfFirst { !it.isNaN() }
        if (first < 0) return DoubleArray(n) { 0.0 }
        val adx = wilderSmooth(dx.drop(first).toDoubleArray(), period)
        return adx
    }

    private fun adxValue(h: List<Double>, l: List<Double>, c: List<Double>, period: Int): Double =
        adxSeries(h, l, c, period).lastOrNull()?.takeIf { it.isFinite() } ?: 0.0

    /* ---------------- 指标状态机（M1） ---------------- */

    /** 交叉状态：报告最近一次金叉/死叉发生位置 + 当前多头/空头延续状态。 */
    private fun crossState(name: String, a: DoubleArray, b: DoubleArray, idx: Int, momentum: String = ""): IndicatorState? {
        var crossIdx = -1; var isGolden = false
        for (i in idx downTo 1) {
            if (!(a[i].isFinite() && b[i].isFinite() && a[i - 1].isFinite() && b[i - 1].isFinite())) continue
            if (a[i] > b[i] && a[i - 1] <= b[i - 1]) { crossIdx = i; isGolden = true; break }
            if (a[i] < b[i] && a[i - 1] >= b[i - 1]) { crossIdx = i; isGolden = false; break }
        }
        if (crossIdx < 0) return null
        val barsAgo = idx - crossIdx
        val bull = a[idx] > b[idx]
        val state = if (bull) "多头延续" else "空头延续"
        val crossName = if (isGolden) "金叉" else "死叉"
        val detail = buildString {
            append(if (barsAgo == 0) "刚发生$crossName" else "$crossName 发生于 ${barsAgo} 根K线前")
            append("，当前${state}")
            if (momentum.isNotEmpty()) append("，$momentum")
            if (bull && barsAgo > 30) append("，注意延续时间已较长")
        }
        return IndicatorState(name, state, detail)
    }

    /** 连续满足条件的K线根数（从最后一根收盘K线往回数）。 */
    private fun streak(close: List<Double>, series: DoubleArray, above: Boolean, idx: Int): Int {
        var n = 0
        for (i in idx downTo 0) {
            if (!series[i].isFinite()) break
            val ok = if (above) close[i] > series[i] else close[i] < series[i]
            if (ok) n++ else break
        }
        return n
    }

    private fun consecutiveRising(series: DoubleArray, idx: Int): Int {
        var n = 0
        for (i in idx downTo 1) {
            if (series[i].isFinite() && series[i - 1].isFinite() && series[i] > series[i - 1]) n++ else break
        }
        return n
    }

    /** OBV 量价背离：价涨量缩=顶背离，价跌量增=底背离（近10根窗口）。 */
    private fun obvDivergence(close: List<Double>, volume: List<Double>): Pair<String, DoubleArray> {
        val obv = DoubleArray(close.size)
        for (i in 1 until close.size) {
            obv[i] = obv[i - 1] + when {
                close[i] > close[i - 1] -> volume[i]
                close[i] < close[i - 1] -> -volume[i]
                else -> 0.0
            }
        }
        val n = close.size
        if (n < 12) return "" to obv
        val priceChg = close[n - 1] / close[n - 11] - 1.0
        val obvChg = obv[n - 1] - obv[n - 11]
        val div = when {
            priceChg > 0.02 && obvChg < 0 -> "顶背离"
            priceChg < -0.02 && obvChg > 0 -> "底背离"
            else -> ""
        }
        return div to obv
    }
    private fun fmt(v: Double) = if(v >= 1) String.format(java.util.Locale.US, "%.4f", v) else String.format(java.util.Locale.US, "%.8f", v)
    private fun Double.fmt(d: Int) = String.format(java.util.Locale.US, "%.$d f".replace(" ", ""), this)
}
