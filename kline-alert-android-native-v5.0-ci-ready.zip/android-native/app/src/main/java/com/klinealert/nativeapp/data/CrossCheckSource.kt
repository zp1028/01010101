package com.klinealert.nativeapp.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * 交易所交叉校验（v4.3）：用独立交易所（Gate.io）的现货价作为参考，
 * 校验 Binance 实时 tick 是否合理，防止单源插针/数据异常误触发待命单。
 *
 * 设计原则：
 *  - **绝不阻断主流程**：参考源不可达 → 返回 null（不判定），主流程照常。
 *  - **一次请求全市场**：Gate 的 /spot/tickers 单次返回全部现货价，缓存 N 秒复用。
 *  - **容差可配**：偏差超过 tolPct 视为不一致（疑似插针）。
 *
 * 说明：这是「价格合理性」校验，不是价格预测；只在触发边界做一致性确认。
 */
class CrossCheckSource {
    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    /** Gate 现货参考价缓存：Binance 符号（BTCUSDT） → 参考价 */
    @Volatile private var refPrices: Map<String, Double> = emptyMap()
    @Volatile private var fetchedAt: Long = 0L
    /** 上次抓取是否成功（用于 UI 展示参考源健康度） */
    @Volatile var lastOk: Boolean = false
        private set
    @Volatile var lastError: String = ""
        private set

    companion object {
        /** 参考价缓存有效期：30 秒（交叉校验不需要毫秒级实时） */
        const val REF_TTL_MS = 30_000L
        /** 默认一致性容差：0.8%（跨交易所正常价差通常 <0.3%，插针往往 >2%） */
        const val DEFAULT_TOL_PCT = 0.8
    }

    /** Binance 符号 → Gate 交易对：BTCUSDT → BTC_USDT；已带下划线则原样返回。 */
    internal fun toGatePair(symbol: String): String {
        val s = symbol.uppercase()
        return if (s.contains("_")) s else {
            // 常见计价币按长度倒序匹配，避免 USDT 被 USDC 抢先
            for (q in listOf("USDT", "USDC", "BUSD", "BTC", "ETH", "USD")) {
                if (s.endsWith(q) && s.length > q.length) return s.dropLast(q.length) + "_" + q
            }
            s
        }
    }

    /**
     * 刷新参考价缓存（幂等，未过期直接返回）。失败不抛异常，仅记录错误。
     */
    suspend fun refresh(force: Boolean = false): Boolean = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        if (!force && refPrices.isNotEmpty() && now - fetchedAt < REF_TTL_MS) return@withContext true
        runCatching {
            val req = Request.Builder()
                .url("https://api.gateio.ws/api/v4/spot/tickers")
                .header("Accept", "application/json")
                .build()
            val body = client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) error("HTTP ${resp.code}")
                resp.body?.string() ?: error("empty body")
            }
            val arr = JSONArray(body)
            val map = HashMap<String, Double>(arr.length().coerceAtMost(4000))
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val pair = o.optString("currency_pair")
                val last = o.optString("last").toDoubleOrNull() ?: continue
                if (pair.isNotEmpty() && last > 0) {
                    // Gate 对 → Binance 符号（BTC_USDT → BTCUSDT）
                    map[pair.replace("_", "")] = last
                }
            }
            if (map.isEmpty()) error("no tickers parsed")
            refPrices = map
            fetchedAt = now
            lastOk = true
            lastError = ""
            true
        }.getOrElse { e ->
            lastOk = false
            lastError = e.message ?: "crosscheck failed"
            false
        }
    }

    /** 参考价；无数据返回 null。 */
    fun referencePrice(symbol: String): Double? = refPrices[symbol.uppercase()]

    /**
     * 一致性判定：Binance 价 vs 参考价偏差是否在容差内。
     * @return true=一致；false=偏差过大（疑似插针）；null=无参考数据（不判定）
     */
    fun isConsistent(symbol: String, price: Double, tolPct: Double = DEFAULT_TOL_PCT): Boolean? {
        if (price <= 0) return null
        val ref = referencePrice(symbol) ?: return null
        if (ref <= 0) return null
        val devPct = kotlin.math.abs(price - ref) / ref * 100.0
        return devPct <= tolPct
    }

    /** 偏差百分比（用于日志/诊断）；无参考返回 null。 */
    fun deviationPct(symbol: String, price: Double): Double? {
        val ref = referencePrice(symbol) ?: return null
        if (ref <= 0) return null
        return kotlin.math.abs(price - ref) / ref * 100.0
    }

    /** 参考源状态：是否可用 + 缓存条数 + 上次错误。 */
    fun status(): Triple<Boolean, Int, String> = Triple(lastOk && refPrices.isNotEmpty(), refPrices.size, lastError)

    /** 参考源是否可用（尚未加载完成时返回 false，不拦截主流程）。 */
    fun available(): Boolean = refPrices.isNotEmpty()

    /** 单测注入：手动设置参考价缓存（避免测试依赖网络）。 */
    internal fun injectForTest(prices: Map<String, Double>) {
        refPrices = prices
        fetchedAt = System.currentTimeMillis()
        lastOk = prices.isNotEmpty()
    }

    /**
     * 是否应拦截本次 tick：仅当该 tick 会引发状态跃迁（PENDING→ARMED 或 ARMED→TRIGGERED）
     * 且价格与参考源不一致时返回 true。无参考数据、或不会跃迁 → false（放行）。
     */
    fun shouldBlock(s: com.klinealert.nativeapp.domain.PendingSetup, price: Double): Boolean {
        if (price <= 0) return false
        val long = s.direction == "LONG"
        val advances = when (s.status) {
            com.klinealert.nativeapp.domain.PendingSetup.PENDING ->
                if (long) price <= s.triggerPrice else price >= s.triggerPrice
            com.klinealert.nativeapp.domain.PendingSetup.ARMED -> {
                val tol = 0.5 * s.atr
                kotlin.math.abs(price - s.triggerPrice) <= tol
            }
            else -> false
        }
        if (!advances) return false
        return isConsistent(s.symbol, price) == false
    }
}
