package com.klinealert.nativeapp.domain

/**
 * v4.4 回测校准分析器：把 v4.2 落库的「回踩确认 + 证据分」真实样本利用起来，
 * 用数据回答三个此前只能拍脑袋的问题：
 *
 *  1. **证据分阈值是否合理**：按证据分分段统计胜率，检验 85/70/50 的分界。
 *  2. **回踩确认是否优于直接触发**：对比 pullbackConfirmed=true/false 两组的胜率（v4.1 假设验证）。
 *  3. **样本外滚动验证**：按时间切分「训练段/验证段」，避免全样本调参的过拟合。
 *
 * 设计原则：
 *  - **诚实统计**：样本不足时明确标注「样本不足」，不硬给结论。
 *  - **不自动改参数**：输出建议值供人工确认，避免用噪声数据反向污染线上。
 *  - 胜率口径与训练闭环一致：只算 hit/miss，invalid 按半权重 miss，neutral 不计入分母。
 */
object BacktestAnalyzer {

    /** 单个分桶的统计结果。 */
    data class Bucket(val label: String, val samples: Int, val hits: Int, val rate: Double) {
        val reliable: Boolean get() = samples >= MIN_BUCKET_SAMPLES
    }

    /** 证据分分段统计。 */
    data class ScoreBandReport(
        val bands: List<Bucket>,          // 各分数段
        val baseline: Double,             // 整体基线胜率
        val suggestedThreshold: Int,      // 建议的高价值阈值（最佳胜率段的下界）
        val samples: Int
    )

    /** 回踩对比统计。 */
    data class PullbackReport(
        val pullback: Bucket,             // 经过回踩确认入场
        val direct: Bucket,               // 直接触发（未经历 ARMED）
        val pullbackBetter: Boolean,      // 回踩组胜率是否显著更高
        val samples: Int
    )

    /** 样本外滚动验证结果。 */
    data class WalkForwardReport(
        val trainSamples: Int, val trainRate: Double,
        val testSamples: Int, val testRate: Double,
        val degradation: Double,          // 训练→验证的胜率跌幅（越小越稳）
        val overfit: Boolean              // 跌幅 > 20 个百分点视为疑似过拟合
    )

    /** 综合回测报告。 */
    data class Report(
        val scoreBands: ScoreBandReport?,
        val pullback: PullbackReport?,
        val walkForward: WalkForwardReport?,
        val totalSettled: Int,
        val note: String
    )

    const val MIN_BUCKET_SAMPLES = 15      // 单个分桶最小样本
    const val MIN_TOTAL_SAMPLES = 40       // 出报告的最小总样本
    private const val OVERFIT_GAP = 0.20   // 训练验证胜率差 >20pp 视为过拟合

    /** 只保留有结算结论的样本；invalid 按半权重 miss 计入（与胜率榜口径一致）。 */
    private fun settled(records: List<ReviewRecord>): List<ReviewRecord> =
        records.filter { it.verdict == "hit" || it.verdict == "miss" || it.verdict == "invalid" }

    private fun weighted(records: List<ReviewRecord>): Pair<Int, Double> {
        // 返回 (有效样本数〔四舍五入〕, 胜率)，invalid 计 0.5 个 miss
        var hits = 0.0
        var denom = 0.0
        records.forEach { r ->
            when (r.verdict) {
                "hit" -> { hits += 1.0; denom += 1.0 }
                "miss" -> { denom += 1.0 }
                "invalid" -> { denom += 0.5 }
            }
        }
        if (denom <= 0.0) return 0 to 0.0
        return Math.round(denom).toInt() to (hits / denom)
    }

    private fun bucketOf(label: String, records: List<ReviewRecord>): Bucket {
        val (n, rate) = weighted(records)
        val hits = records.count { it.verdict == "hit" }
        return Bucket(label, n, hits, rate)
    }

    /**
     * #1 证据分分段胜率：按 <60 / 60-70 / 70-85 / ≥85 分段。
     * 建议阈值取「可靠（样本足）且胜率最高」段的下界。
     */
    fun scoreBands(records: List<ReviewRecord>): ScoreBandReport? {
        val s = settled(records)
        if (s.size < MIN_TOTAL_SAMPLES) return null
        val ranges = listOf(
            "<60" to (0..59),
            "60-69" to (60..69),
            "70-84" to (70..84),
            "≥85" to (85..Int.MAX_VALUE)
        )
        val bands = ranges.map { (label, rg) ->
            bucketOf(label, s.filter { it.evidenceScore in rg || (it.evidenceScore == 0 && label == "<60") })
        }
        val (_, baseline) = weighted(s)
        // 建议阈值：在可靠分桶里挑胜率最高的，取其下界分数
        val best = bands.filter { it.reliable }.maxByOrNull { it.rate }
        val suggested = when (best?.label) {
            "≥85" -> 85; "70-84" -> 70; "60-69" -> 60; else -> 50
        }
        return ScoreBandReport(bands, baseline, suggested, s.size)
    }

    /**
     * #2 回踩 vs 直接触发：对比 pullbackConfirmed 两组。
     * 只有当两组样本都达到最小样本量时才给结论。
     */
    fun pullbackCompare(records: List<ReviewRecord>): PullbackReport? {
        val s = settled(records)
        if (s.size < MIN_TOTAL_SAMPLES) return null
        val pb = bucketOf("回踩确认入场", s.filter { it.pullbackConfirmed })
        val direct = bucketOf("直接触发", s.filter { !it.pullbackConfirmed })
        if (!pb.reliable && !direct.reliable) return null
        return PullbackReport(
            pullback = pb, direct = direct,
            pullbackBetter = pb.reliable && direct.reliable && pb.rate > direct.rate,
            samples = s.size
        )
    }

    /**
     * #3 样本外滚动验证：按 alertedAt 升序，前 70% 训练、后 30% 验证。
     * 若训练段远好于验证段（跌幅 >20pp），提示可能过拟合/市场状态漂移。
     */
    fun walkForward(records: List<ReviewRecord>): WalkForwardReport? {
        val s = settled(records).sortedBy { it.alertedAt }
        if (s.size < MIN_TOTAL_SAMPLES) return null
        val cut = (s.size * 0.7).toInt().coerceIn(1, s.size - 1)
        val train = s.subList(0, cut)
        val test = s.subList(cut, s.size)
        val (tn, tr) = weighted(train)
        val (vn, vr) = weighted(test)
        val deg = tr - vr
        return WalkForwardReport(tn, tr, vn, vr, deg, deg > OVERFIT_GAP)
    }

    /** 生成完整报告。 */
    fun analyze(records: List<ReviewRecord>): Report {
        val s = settled(records)
        val note = when {
            s.isEmpty() -> "暂无结算样本：扫描并等待信号触发/失效后自动积累"
            s.size < MIN_TOTAL_SAMPLES -> "样本积累中（${s.size}/$MIN_TOTAL_SAMPLES）：到量后自动给出校准建议"
            else -> "样本可用（${s.size} 个）；建议值供参考，请勿在样本量不足时强改阈值"
        }
        return Report(
            scoreBands = scoreBands(records),
            pullback = pullbackCompare(records),
            walkForward = walkForward(records),
            totalSettled = s.size,
            note = note
        )
    }
}
