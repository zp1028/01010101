package com.klinealert.nativeapp.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.klinealert.nativeapp.MainActivity
import com.klinealert.nativeapp.R
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/**
 * 待命单触发通知器（v3.9）：分级 + 冷却 + 夜间静音。
 *
 * 分级：
 *  - 证据分 ≥85 → 高优先渠道（响铃+悬浮）
 *  - ≥70 → 普通渠道
 *  - <70 → 静默（仅 App 内显示，不推送）
 * 冷却：同品种 30 分钟内不重复推送
 * 夜间：可配置免打扰时段（如 23:00-08:00），期间只记录不推送
 */
object SetupNotifier {
    private const val CHANNEL_SETUP_ALERT = "kline_setup_alert"
    private const val CHANNEL_SETUP_HIGH = "kline_setup_high"
    private val seq = AtomicInteger(2000)
    private val lastNotifyAt = ConcurrentHashMap<String, Long>()

    private fun ensureChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL_SETUP_ALERT) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL_SETUP_ALERT, "机会触发提醒", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "价格到达待命单触发价时提醒"
            })
        }
        if (nm.getNotificationChannel(CHANNEL_SETUP_HIGH) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL_SETUP_HIGH, "高价值机会（重要）", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "证据分 ≥85 的机会触发，重要提醒"
                enableVibration(true)
            })
        }
    }

    private fun quietNow(quietStart: Int, quietEnd: Int): Boolean {
        val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        return if (quietStart <= quietEnd) h in quietStart until quietEnd
        else h >= quietStart || h < quietEnd  // 跨零点
    }

    /**
     * 待命单触发推送。返回 true=已推送，false=被静默/冷却/权限拦截。
     */
    fun notifyTriggered(
        ctx: Context, symbol: String, direction: String, timeframe: String,
        triggerPrice: Double, stop: Double, target: Double, evidenceScore: Int,
        quietStart: Int = 23, quietEnd: Int = 8, quietEnabled: Boolean = true
    ): Boolean {
        // 分级：<70 不推送（只在 App 内显示）
        if (evidenceScore < 70) return false
        val now = System.currentTimeMillis()
        val last = lastNotifyAt[symbol] ?: 0L
        if (now - last < 30 * 60_000L) return false      // 冷却 30 分钟
        if (quietEnabled && quietNow(quietStart, quietEnd)) return false  // 夜间静音
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return false
        ensureChannels(ctx)
        lastNotifyAt[symbol] = now
        val high = evidenceScore >= 85
        val dirTxt = if (direction == "LONG") "做多" else "做空"
        val fmt = { v: Double -> if (v >= 1) String.format(java.util.Locale.US, "%.4f", v) else String.format(java.util.Locale.US, "%.8f", v) }
        val title = "⚡ $symbol $dirTxt 回踩确认（证据 $evidenceScore）"
        val text = "入场 ${fmt(triggerPrice)} · 止损 ${fmt(stop)} · 3R止盈 ${fmt(target)} · $timeframe"
        val intent = PendingIntent.getActivity(
            ctx, seq.incrementAndGet(),
            // v4.4 深链：点击通知直达「最新机会」页并高亮该品种
            Intent(ctx, MainActivity::class.java).apply {
                setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                putExtra("deep_link_tab", "latest")
                putExtra("deep_link_symbol", symbol)
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(ctx, if (high) CHANNEL_SETUP_HIGH else CHANNEL_SETUP_ALERT)
            .setSmallIcon(R.drawable.ic_monitor)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText("$text\n回踩确认已通过：价格回到触发价附近且未破失效位。挂限价单，勿市价追高；窗口内有效"))
            .setAutoCancel(true)
            .setContentIntent(intent)
            .build()
        return runCatching {
            (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(seq.incrementAndGet(), n)
            true
        }.getOrDefault(false)
    }

    /** 夜间静音期间错过的机会汇总（早上一条回顾） */
    fun notifyMissedSummary(ctx: Context, count: Int, symbols: List<String>) {
        if (count <= 0) return
        ensureChannels(ctx)
        val title = "🌙 夜间错过的 $count 个机会"
        val text = symbols.take(6).joinToString("、") + if (symbols.size > 6) " 等" else ""
        val intent = PendingIntent.getActivity(
            ctx, seq.incrementAndGet(),
            Intent(ctx, MainActivity::class.java).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(ctx, CHANNEL_SETUP_ALERT)
            .setSmallIcon(R.drawable.ic_monitor)
            .setContentTitle(title).setContentText(text)
            .setAutoCancel(true).setContentIntent(intent).build()
        runCatching { (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(seq.incrementAndGet(), n) }
    }
}
