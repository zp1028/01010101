package com.klinealert.nativeapp.domain

/**
 * SmartLevels：智能止损止盈（结构位优先 + 波动自适应）
 *
 * 止损：入场价逆方向 max(缓冲, 结构位) —— 缓冲 = 1.5×ATR×波动自适应系数，
 *       结构位取前低/前高/支撑压力/EMA20 中最近的有效位再留 0.5×ATR。
 *       总风险超过 2.5×ATR 时钳位（波动过大品种提示降级）。
 * 止盈：T1 = 第一个结构位前 0.3×ATR（提前止盈防插针）；T2 = 2×ATR 与次级结构位取近；
 *       T3 = 延续目标（波段 1.618× 延伸）与 3×ATR 取远者——与生命线推演卡同源。
 */
import kotlin.math.max
import kotlin.math.min

object VolAdaptive {
    /** 波动自适应系数：波动放大期给更大空间（防假失效），收缩期收紧（横盘小破位更可疑）。 */
    fun factor(volExpansion: Double): Double = when {
        volExpansion > 1.3 -> 1.6
        volExpansion > 1.15 -> 1.3
        volExpansion < 0.7 -> 0.8
        else -> 1.0
    }
}

data class SmartLevels(
    val entry: Double,
    val stop: Double,
    val t1: Double,
    val t2: Double,
    val t3: Double,
    val riskAtr: Double,     // 止损距离（ATR 倍）
    val notes: List<String>
)

object SmartLevelsEngine {

    fun build(a: Analysis, direction: String): SmartLevels {
        val long = direction == "LONG"
        val sign = if (long) 1.0 else -1.0
        val atr = a.atr.takeIf { it > 0 } ?: a.price * 0.01
        val vf = VolAdaptive.factor(a.volExpansion)
        val notes = mutableListOf<String>()
        if (vf > 1.0) notes.add("波动放大期（V=${fmt(a.volExpansion)}）：缓冲放宽至 ${fmt(1.5 * vf)}×ATR，防波动假失效")
        else if (vf < 1.0) notes.add("波动收缩期（V=${fmt(a.volExpansion)}）：缓冲收紧至 ${fmt(1.5 * vf)}×ATR")

        val entry = a.price
        if (entry <= 0) return SmartLevels(entry, a.stop, a.target, a.target, a.target, 1.5, listOf("数据不足，沿用基础价位"))

        // ---- 止损：结构位优先 + 自适应缓冲 ----
        val struct = if (long)
            listOfNotNull(a.swingLow, a.support).filter { it > 0 && it < entry }
        else
            listOfNotNull(a.swingHigh, a.resistance).filter { it > 0 && it > entry }
        val structStop = if (long) struct.maxOrNull() else struct.minOrNull()
        val buf = entry - sign * 1.5 * atr * vf
        val structSide = structStop?.let { it - sign * 0.5 * atr }
        var stop = if (long) min(buf, structSide ?: buf) else max(buf, structSide ?: buf)
        var riskAtr = (entry - stop) * sign / atr
        if (riskAtr > 2.5) {
            stop = entry - sign * 2.5 * atr
            riskAtr = 2.5
            notes.add("结构位过远：止损钳位 2.5×ATR（该品种当前波动大，建议降低仓位）")
        }
        if (riskAtr < 1.0) {
            stop = entry - sign * 1.0 * atr
            riskAtr = 1.0
        }
        if (structStop != null) notes.add("止损锚定结构位 ${fmt(structStop)} 外 0.5×ATR")

        // ---- 止盈：结构密度 + 延续目标 ----
        val targets = if (long)
            listOfNotNull(a.resistance, a.swingHigh).filter { it > entry }.sorted()
        else
            listOfNotNull(a.support, a.swingLow).filter { it > 0 && it < entry }.sortedDescending()
        val pushLow = a.swingLow ?: entry
        val pushHigh = a.swingHigh ?: entry
        val ext = if (long) pushHigh + (pushHigh - pushLow) * 0.618 else pushLow - (pushHigh - pushLow) * 0.618

        var t1 = targets.firstOrNull()?.let { it - sign * 0.3 * atr } ?: entry + sign * 1.0 * atr
        if ((t1 - entry) * sign <= 0.2 * atr) t1 = entry + sign * 1.0 * atr
        val t2raw = minOf(targets.getOrElse(1) { Double.POSITIVE_INFINITY * sign }, entry + sign * 2.0 * atr) * (if (long) 1.0 else 1.0)
        var t2 = if (long) t2raw else t2raw
        if ((t2 - t1) * sign < 0.3 * atr) t2 = t1 + sign * 1.0 * atr
        var t3 = if (long) maxOf(ext, entry + 3.0 * atr) else minOf(ext, entry - 3.0 * atr)
        if ((t3 - t2) * sign < 0.3 * atr) t3 = t2 + sign * 1.0 * atr
        if (targets.isNotEmpty()) notes.add("T1 提前于第一结构位 ${fmt(targets.first())} 0.3×ATR，防插针")

        val rr = ((t2 - entry) * sign / ((entry - stop) * sign)).takeIf { it > 0 } ?: 1.5
        if (rr < 1.5) notes.add("盈亏比 ${fmt(rr)} <1.5：T 区间被结构位压缩，建议等待更好入场")
        return SmartLevels(entry, stop, t1, t2, t3, riskAtr, notes)
    }

    private fun fmt(d: Double): String =
        String.format(java.util.Locale.US, if (d >= 1) "%.4f" else "%.8f", d)
}
