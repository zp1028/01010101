package com.klinealert.nativeapp.domain

/**
 * ML-1 统计校准器（预置框架）：
 * 用已结算信号按「触发模式×方向」分桶统计真实胜率，
 * 与整体基线胜率的偏差映射为评分加减分（±8 分封顶，防过拟合）。
 * 样本 <20 的分桶自动跳过——数据积累到位后无需发版即自动生效。
 *
 * 这一步把引擎里拍脑袋的加减分逐步替换为实测校准值；
 * 样本 ≥300 后可平滑升级为逻辑回归（输出仍可解释）。
 */
data class PatternStat(val key: String, val samples: Int, val rate: Double, val bonus: Int)

object Calibrator {
    private const val MIN_SAMPLES = 20
    private const val MAX_BONUS = 8

    fun patternStats(records: List<ReviewRecord>): List<PatternStat> {
        val settled = records.filter { it.verdict == "hit" || it.verdict == "miss" }
        if (settled.isEmpty()) return emptyList()
        val baseline = settled.count { it.verdict == "hit" }.toDouble() / settled.size
        data class Acc(var n: Int = 0, var h: Int = 0)
        val acc = HashMap<String, Acc>()
        settled.forEach { r ->
            patternsOf(r).forEach { p ->
                acc.getOrPut("$p|${r.direction}") { Acc() }.let {
                    it.n++; if (r.verdict == "hit") it.h++
                }
            }
        }
        val out = mutableListOf<PatternStat>()
        acc.forEach { (k, v) ->
            if (v.n >= MIN_SAMPLES) {
                val rate = v.h.toDouble() / v.n
                val bonus = ((rate - baseline) * 15).toInt().coerceIn(-MAX_BONUS, MAX_BONUS)
                out += PatternStat(k, v.n, rate, bonus)
            }
        }
        return out.sortedByDescending { it.samples }
    }

    fun bonusMap(stats: List<PatternStat>): Map<String, Int> = stats.associate { it.key to it.bonus }

    /** 从 features JSON 提取模式列表（手写解析，避免单测环境 org.json 依赖）。 */
    fun patternsOf(r: ReviewRecord): List<String> = runCatching {
        Regex("\"patterns\":\\[([^]]*)]").find(r.features)?.groupValues?.getOrNull(1)
            ?.split(",")?.map { it.trim().trim('"') }?.filter { it.isNotBlank() }
    }.getOrNull() ?: emptyList()
}
