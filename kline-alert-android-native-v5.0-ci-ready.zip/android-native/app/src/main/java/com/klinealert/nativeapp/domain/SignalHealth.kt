package com.klinealert.nativeapp.domain

/**
 * 实时信号健康度：基于每秒 tick 的轻量评估，不重算指标、不翻转信号。
 *
 * 设计原则（智能分析而非随意变动）：
 * - 信号方向/评分只在收盘 K 线上重算（防频繁跳变/ repaint）
 * - tick 级只回答一个问题：当前这笔机会是「持续 / 观察 / 反转风险 / 破位 / 达标」
 * - 触及止损只在 tick 层标记「破位预警」，等收盘 K 线确认后才真正移除卡片（防插针误杀）
 */
data class SignalHealth(val status: String, val detail: String) {
    val color: String get() = when {
        status.contains("持续") || status.contains("止盈") -> "GOOD"
        status.contains("风险") || status.contains("观察") || status.contains("预警") -> "WARN"
        else -> "NEUTRAL"
    }
}

object SignalHealthMonitor {

    fun evaluate(sop: SymbolOpportunity, livePrice: Double?, staleMs: Long = -1L): SignalHealth {
        if (livePrice == null || livePrice <= 0) {
            // 实时流中断的降级评估：用最近扫描价 + 数据年龄，不再无意义地永远等待
            if (staleMs >= 0) {
                val inner = evaluateInternal(sop, sop.price)
                val ageMin = String.format(java.util.Locale.US, "%.0f", staleMs / 60_000.0)
                return SignalHealth(inner.status, inner.detail + "（基于 $ageMin 分钟前扫描价，实时流中断）")
            }
            return SignalHealth("等待实时价", "连接实时行情后自动评估")
        }
        return evaluateInternal(sop, livePrice)
    }

    private fun evaluateInternal(sop: SymbolOpportunity, livePrice: Double): SignalHealth {
        val a = sop.rep
        val long = sop.direction == "LONG"
        val risk = kotlin.math.abs(a.entry - a.stop).takeIf { it > 0 } ?: a.atr.takeIf { it > 0 } ?: a.price * 0.01
        val adverse = if (long) (a.entry - livePrice) / risk else (livePrice - a.entry) / risk
        val hitStop = if (long) livePrice <= a.stop else livePrice >= a.stop
        val hitTarget = if (long) livePrice >= a.target else livePrice <= a.target
        return when {
            hitStop -> SignalHealth("破位预警", "实时价已触及止损位，等收盘K线确认失效（插针不误杀）")
            hitTarget -> SignalHealth("已达止盈区", "实时价已进入止盈区间，可考虑分批了结")
            adverse >= 0.7 -> SignalHealth("反转风险", "回撤已达风险区 ${pct(adverse)}，关注是否企稳或等待收盘确认")
            adverse >= 0.5 -> SignalHealth("回调观察", "回撤 ${pct(adverse)}，信号结构未破坏，继续持有观察")
            else -> SignalHealth("机会持续", "运行于入场与风险区之间，结构不变，无需重扫")
        }
    }

    private fun pct(v: Double) = String.format(java.util.Locale.US, "%.0f%%", v * 100)
}

/**
 * 实时健康度 2.0（有状态版，由 ViewModel 按 tick 驱动）：
 * - MFE/MAE 极值跟踪：用「累计最大不利偏移」而非瞬时值判定，插针/瞬时波动不再误判
 * - 迟滞去抖：状态变化需连续 3 个 tick（约 3 秒）确认，杜绝来回跳变
 * - 收盘确认原则不变：真正失效仍由收盘 K 线决定
 */
class HealthTracker {
    var current: SignalHealth = SignalHealth("等待实时价", "连接实时行情后自动评估")
        private set
    var mfe = 0.0; private set   // 最大有利偏移（风险单位）
    var mae = 0.0; private set   // 最大不利偏移（风险单位）
    private var pendingStatus = ""
    private var pendingCount = 0

    fun update(sop: SymbolOpportunity, livePrice: Double?): SignalHealth {
        if (livePrice == null || livePrice <= 0) return current
        val a = sop.rep
        val long = sop.direction == "LONG"
        val risk = kotlin.math.abs(a.entry - a.stop).takeIf { it > 0 } ?: a.atr.takeIf { it > 0 } ?: a.price * 0.01
        val adverseNow = (if (long) (a.entry - livePrice) else (livePrice - a.entry)) / risk
        val favNow = (if (long) (livePrice - a.entry) else (a.entry - livePrice)) / risk
        if (adverseNow > mae) mae = adverseNow
        if (favNow > mfe) mfe = favNow

        val hitStop = if (long) livePrice <= a.stop else livePrice >= a.stop
        val hitTarget = if (long) livePrice >= a.target else livePrice <= a.target
        val raw = when {
            hitStop -> "破位预警"
            hitTarget -> "已达止盈区"
            adverseNow >= 0.7 -> "反转风险"
            adverseNow >= 0.5 || mae >= 0.7 -> "回调观察"
            else -> "机会持续"
        }
        val detail = when (raw) {
            "破位预警" -> "实时价触及止损位，等收盘K线确认失效（插针不误杀）"
            "已达止盈区" -> "进入止盈区间，可考虑分批了结；历史最大回撤 ${pct(mae)}"
            "反转风险" -> "瞬时回撤 ${pct(adverseNow)}（历史最大 ${pct(mae)}），关注企稳"
            "回调观察" -> "累计最大回撤 ${pct(mae)}（最大浮盈 ${pct(mfe)}），结构未破坏"
            else -> "运行健康；最大浮盈 ${pct(mfe)}，最大回撤 ${pct(mae)}"
        }
        // 迟滞去抖：与当前状态不同时，需连续 3 tick 确认才切换
        if (raw == current.status) {
            pendingCount = 0
            current = SignalHealth(raw, detail) // 同状态刷新 detail（MFE/MAE 持续更新）
        } else if (raw == pendingStatus) {
            pendingCount++
            if (pendingCount >= 3) {
                current = SignalHealth(raw, detail)
                pendingCount = 0
            }
        } else {
            pendingStatus = raw
            pendingCount = 1
        }
        return current
    }

    private fun pct(v: Double) = String.format(java.util.Locale.US, "%.0f%%", v * 100)
}
