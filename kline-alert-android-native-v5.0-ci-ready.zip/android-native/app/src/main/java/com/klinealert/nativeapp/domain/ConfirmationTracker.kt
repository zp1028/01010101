package com.klinealert.nativeapp.domain

/**
 * 机会确认状态机（Confirmation Gate）
 *
 * 信号发出后不直接算数，先经过一个观察窗口验证「行情是否朝信号方向真实走出」。
 * 四种结果：
 *  - 已确认（快速确认）：窗口内走出要求幅度且未明显反向 → 生命线开始，最高价值样本
 *  - 回踩确认：先小幅反向（≥0.3×ATR 但 <0.5×ATR）再走出阈值 → 确认且入场点更优
 *  - 延候确认：窗口结束时走了 0.3~阈值之间 → 延长一倍窗口再判
 *  - 未确认：反向走出 ≥0.5×ATR（破位/假启动）或窗口到期仍未走出 0.3×ATR → 从榜单淡化，记负样本
 *
 * 所有阈值按 ATR 归一（不同波动率品种同一标尺）。
 * tick 级判定用极值；反向判定沿用迟滞思想（取反向最大值，单针插针若未破 0.5×ATR 不触发）。
 */
data class Confirmation(
    val key: String,
    val symbol: String,
    val market: String,
    val direction: String,
    val repTimeframe: String,
    val entryPrice: Double,
    val atr: Double,
    val windowBars: Int,
    val thresholdAtr: Double,
    val startedAt: Long,
    val startCandleTime: Long,
    val status: String = "待确认",   // 待确认/已确认/回踩确认/延候确认/未确认
    val progressAtr: Double = 0.0,   // 朝方向最大走出（ATR 倍）
    val reverseMaxAtr: Double = 0.0, // 反方向最大走出（ATR 倍）
    val barsElapsed: Double = 0.0,   // 按 candleTime 推算的已过窗口根数
    val resolvedAt: Long = 0L,
    val resolvedPrice: Double = 0.0,
    val volExpansion: Double = 1.0,   // 波动扩张率（ATR/近20根均值）
    val volObservedAt: Double = -1.0  // 进入「波动观察」时的窗口进度
) {
    val resolved: Boolean get() = status == "已确认" || status == "回踩确认" || status == "未确认"
    val pending: Boolean get() = !resolved && status != "延候确认" && status != "波动观察"

    /** 进度文案：确认线与当前距离 */
    fun progressText(): String {
        val need = if (status == "延候确认") thresholdAtr else thresholdAtr
        return String.format(java.util.Locale.US, "%.1f/%.1f×ATR", progressAtr, need)
    }
}

object ConfirmationGate {
    /** 周期 → (窗口根数, 确认阈值 ATR 倍数) */
    val tfConfig = mapOf(
        "5m" to (5 to 0.5),
        "15m" to (4 to 0.5),
        "30m" to (3 to 0.7),
        "1h" to (3 to 0.7),
        "4h" to (2 to 1.0)
    )

    private val tfMillis = mapOf(
        "5m" to 5 * 60_000L, "15m" to 15 * 60_000L, "30m" to 30 * 60_000L,
        "1h" to 60 * 60_000L, "4h" to 4 * 60 * 60_000L
    )

    val keyOf = { market: String, symbol: String, direction: String -> "$market|$symbol|$direction" }

    fun start(sop: SymbolOpportunity, now: Long = System.currentTimeMillis()): Confirmation? {
        val cfg = tfConfig[sop.rep.timeframe] ?: return null
        val atr = sop.rep.atr
        if (atr == null || atr <= 0 || sop.price <= 0) return null
        return Confirmation(
            key = keyOf(sop.market, sop.symbol, sop.direction),
            symbol = sop.symbol, market = sop.market, direction = sop.direction,
            repTimeframe = sop.rep.timeframe,
            entryPrice = sop.price, atr = atr,
            windowBars = cfg.first, thresholdAtr = cfg.second,
            startedAt = now, startCandleTime = sop.rep.candleTime,
            volExpansion = sop.rep.volExpansion
        )
    }

    /** tick 驱动：更新进度、判定确认/失败。返回更新后的对象（无变化返回原对象）。 */
    fun onTick(c: Confirmation, price: Double, now: Long = System.currentTimeMillis()): Confirmation {
        if (c.resolved || price <= 0 || c.atr <= 0) return c
        // 波动自适应：波动放大期阈值放宽（防假失效），收缩期收紧
        val vf = VolAdaptive.factor(c.volExpansion)
        val confirmThr = c.thresholdAtr * vf
        val failThr = 0.5 * vf
        val sign = if (c.direction == "LONG") 1.0 else -1.0
        val moveAtr = (price - c.entryPrice) * sign / c.atr
        var nc = c
        if (moveAtr > c.progressAtr) nc = nc.copy(progressAtr = moveAtr)
        if (-moveAtr > c.reverseMaxAtr) nc = nc.copy(reverseMaxAtr = -moveAtr)
        // 窗口进度按代表周期K线时间推算
        val tf = tfMillis[c.repTimeframe] ?: (15 * 60_000L)
        val bars = ((now - c.startCandleTime).coerceAtLeast(0)).toDouble() / tf
        nc = nc.copy(barsElapsed = bars)
        // 波动观察恢复：曾因波动假失效进入观察，重新走出 → 回到待确认继续观察
        if (nc.status == "波动观察" && nc.progressAtr >= 0.2) {
            nc = nc.copy(status = "待确认", volObservedAt = -1.0)
        }
        // 波动观察超时（2 根K线内未恢复）→ 未确认
        if (nc.status == "波动观察" && nc.volObservedAt >= 0 && bars >= nc.volObservedAt + 2.0) {
            return nc.copy(status = "未确认", resolvedAt = now, resolvedPrice = price)
        }
        // ① 快速/回踩确认：走出自适应阈值
        if (nc.progressAtr >= confirmThr) {
            val retest = nc.reverseMaxAtr >= 0.3 && nc.reverseMaxAtr < 0.5
            return nc.copy(status = if (retest) "回踩确认" else "已确认", resolvedAt = now, resolvedPrice = price)
        }
        // ② 失败：反向走出自适应阈值。波动放大期先降级「波动观察」（给 2 根K线恢复期），收缩期直接判死
        if (nc.reverseMaxAtr >= failThr) {
            if (nc.volExpansion > 1.3 && nc.status != "波动观察") {
                return nc.copy(status = "波动观察", volObservedAt = bars)
            }
            if (nc.status == "波动观察") return nc  // 观察期内等恢复或超时
            return nc.copy(status = "未确认", resolvedAt = now, resolvedPrice = price)
        }
        // ③ 窗口判定
        if (nc.status == "待确认" && bars >= nc.windowBars) {
            if (nc.progressAtr >= 0.3) return nc.copy(status = "延候确认")
            return nc.copy(status = "未确认", resolvedAt = now, resolvedPrice = price)
        }
        // ④ 延候窗口（2×窗口）到期仍未达标
        if (nc.status == "延候确认" && bars >= nc.windowBars * 2.0) {
            return if (nc.progressAtr >= nc.thresholdAtr) {
                nc.copy(status = "已确认", resolvedAt = now, resolvedPrice = price)
            } else {
                nc.copy(status = "未确认", resolvedAt = now, resolvedPrice = price)
            }
        }
        return nc
    }

    /** UI 徽章文案 */
    fun badge(c: Confirmation): String = when (c.status) {
        "待确认" -> "⏳ 确认观察 ${c.progressText()}"
        "延候确认" -> "🕐 延候确认 ${c.progressText()}"
        "已确认" -> "✅ 已确认 +${String.format(java.util.Locale.US, "%.1f", c.progressAtr)}×ATR"
        "回踩确认" -> "🔁 回踩确认 +${String.format(java.util.Locale.US, "%.1f", c.progressAtr)}×ATR"
        "波动观察" -> "🌊 波动观察（防假失效·待恢复）"
        "未确认" -> "❌ 未确认（假启动）"
        else -> c.status
    }
}
