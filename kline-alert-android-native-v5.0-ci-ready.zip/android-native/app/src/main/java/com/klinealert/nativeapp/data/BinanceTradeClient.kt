package com.klinealert.nativeapp.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.util.concurrent.TimeUnit
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * 币安 U 本位合约签名 REST（主网 / 测试网）。
 * P0：账户与余额；P1+：下单、条件单、撤单。
 */
class BinanceTradeClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    data class Credentials(val apiKey: String, val secret: String, val testnet: Boolean)

    /** LOT_SIZE / PRICE_FILTER 缓存，按网络区分。 */
    data class SymbolFilter(
        val symbol: String,
        val qtyStep: Double,
        val minQty: Double,
        val priceTick: Double,
        val minNotional: Double
    )

    private val filterCache = java.util.concurrent.ConcurrentHashMap<String, SymbolFilter>()
    private var filterCacheAt = 0L

    suspend fun ensureFilters(testnet: Boolean) {
        if (filterCache.isNotEmpty() && System.currentTimeMillis() - filterCacheAt < 3_600_000L) return
        withContext(Dispatchers.IO) {
            val url = "${baseUrl(testnet)}/fapi/v1/exchangeInfo"
            val req = Request.Builder().url(url).get().build()
            client.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) return@withContext
                val arr = JSONObject(body).optJSONArray("symbols") ?: return@withContext
                for (i in 0 until arr.length()) {
                    val s = arr.getJSONObject(i)
                    if (s.optString("status") != "TRADING") continue
                    val sym = s.getString("symbol")
                    var step = 0.001
                    var minQ = 0.001
                    var tick = 0.01
                    var minN = 5.0
                    val filters = s.optJSONArray("filters") ?: continue
                    for (f in 0 until filters.length()) {
                        val fl = filters.getJSONObject(f)
                        when (fl.optString("filterType")) {
                            "LOT_SIZE" -> {
                                step = fl.optString("stepSize", "0.001").toDoubleOrNull() ?: step
                                minQ = fl.optString("minQty", "0.001").toDoubleOrNull() ?: minQ
                            }
                            "PRICE_FILTER" -> tick = fl.optString("tickSize", "0.01").toDoubleOrNull() ?: tick
                            "MIN_NOTIONAL" -> minN = fl.optString("notional", fl.optString("minNotional", "5")).toDoubleOrNull() ?: minN
                        }
                    }
                    filterCache[cacheKey(testnet, sym)] = SymbolFilter(sym, step, minQ, tick, minN)
                }
                filterCacheAt = System.currentTimeMillis()
            }
        }
    }

    fun filterOf(testnet: Boolean, symbol: String): SymbolFilter? = filterCache[cacheKey(testnet, symbol)]

    private fun cacheKey(testnet: Boolean, symbol: String) = "${if (testnet) "t" else "m"}|$symbol"

    fun roundStep(value: Double, step: Double): Double {
        if (step <= 0 || value <= 0) return 0.0
        val n = kotlin.math.floor(value / step + 1e-12) * step
        val decimals = stepDecimals(step)
        val factor = Math.pow(10.0, decimals.toDouble())
        return kotlin.math.floor(n * factor + 1e-9) / factor
    }

    private fun stepDecimals(step: Double): Int {
        val s = String.format(java.util.Locale.US, "%.12f", step).trimEnd('0')
        val i = s.indexOf('.')
        return if (i < 0) 0 else (s.length - i - 1).coerceAtMost(8)
    }

    fun formatByStep(value: Double, step: Double): String {
        val r = roundStep(value, step)
        if (r <= 0) return "0"
        val d = stepDecimals(step)
        return String.format(java.util.Locale.US, "%.${d}f", r)
    }

    private fun baseUrl(testnet: Boolean) =
        if (testnet) "https://testnet.binancefuture.com" else "https://fapi.binance.com"

    private fun sign(secret: String, payload: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret.toByteArray(StandardCharsets.UTF_8), "HmacSHA256"))
        return mac.doFinal(payload.toByteArray(StandardCharsets.UTF_8)).joinToString("") { "%02x".format(it) }
    }

    private suspend fun signedGet(creds: Credentials, path: String, params: Map<String, String> = emptyMap()): JSONObject =
        withContext(Dispatchers.IO) {
            val ts = System.currentTimeMillis().toString()
            val all = LinkedHashMap(params)
            all["timestamp"] = ts
            all["recvWindow"] = "5000"
            val q = all.entries.joinToString("&") { "${it.key}=${it.value}" }
            val sig = sign(creds.secret, q)
            val url = "${baseUrl(creds.testnet)}$path?$q&signature=$sig"
            val req = Request.Builder().url(url).header("X-MBX-APIKEY", creds.apiKey).get().build()
            client.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) throw IllegalStateException(parseErr(body, resp.code))
                if (body.isBlank()) JSONObject() else JSONObject(body)
            }
        }

    private suspend fun signedPost(creds: Credentials, path: String, params: Map<String, String>): JSONObject =
        withContext(Dispatchers.IO) {
            val ts = System.currentTimeMillis().toString()
            val all = LinkedHashMap(params)
            all["timestamp"] = ts
            all["recvWindow"] = "5000"
            val q = all.entries.joinToString("&") { "${it.key}=${it.value}" }
            val sig = sign(creds.secret, q)
            val form = FormBody.Builder()
            all.forEach { (k, v) -> form.add(k, v) }
            form.add("signature", sig)
            val req = Request.Builder()
                .url("${baseUrl(creds.testnet)}$path")
                .header("X-MBX-APIKEY", creds.apiKey)
                .post(form.build())
                .build()
            client.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) throw IllegalStateException(parseErr(body, resp.code))
                if (body.isBlank()) JSONObject() else JSONObject(body)
            }
        }

    private fun parseErr(body: String, code: Int): String {
        return try {
            val j = JSONObject(body)
            "HTTP $code · ${j.optInt("code")} ${j.optString("msg")}"
        } catch (_: Exception) {
            "HTTP $code · ${body.take(200)}"
        }
    }

    /** 服务器时间（校时可选）。 */
    suspend fun serverTime(testnet: Boolean): Long = withContext(Dispatchers.IO) {
        val url = "${baseUrl(testnet)}/fapi/v1/time"
        val req = Request.Builder().url(url).get().build()
        client.newCall(req).execute().use { resp ->
            val body = resp.body?.string().orEmpty()
            JSONObject(body).optLong("serverTime", System.currentTimeMillis())
        }
    }

    /**
     * 账户余额与权益。
     * availableBalance / totalWalletBalance / totalUnrealizedProfit
     */
    suspend fun account(creds: Credentials): JSONObject = signedGet(creds, "/fapi/v2/account")

    suspend fun balanceUsdt(creds: Credentials): Triple<Double, Double, Double> {
        val acc = account(creds)
        val available = acc.optString("availableBalance", "0").toDoubleOrNull() ?: 0.0
        val wallet = acc.optString("totalWalletBalance", "0").toDoubleOrNull()
            ?: acc.optString("totalMarginBalance", "0").toDoubleOrNull() ?: 0.0
        val upnl = acc.optString("totalUnrealizedProfit", "0").toDoubleOrNull() ?: 0.0
        return Triple(available, wallet, upnl)
    }

    /** 单向/双向：true=对冲双向。 */
    suspend fun isDualSidePosition(creds: Credentials): Boolean {
        val j = signedGet(creds, "/fapi/v1/positionSide/dual")
        return j.optBoolean("dualSidePosition", false)
    }

    /** 品种杠杆档位上限（接口可能返回对象或数组）。 */
    suspend fun maxLeverage(creds: Credentials, symbol: String): Int = withContext(Dispatchers.IO) {
        try {
            val ts = System.currentTimeMillis().toString()
            val q = "symbol=$symbol&timestamp=$ts&recvWindow=5000"
            val sig = sign(creds.secret, q)
            val url = "${baseUrl(creds.testnet)}/fapi/v1/leverageBracket?$q&signature=$sig"
            val req = Request.Builder().url(url).header("X-MBX-APIKEY", creds.apiKey).get().build()
            client.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) return@withContext 20
                var max = 20
                fun scanBrackets(brackets: JSONArray?) {
                    if (brackets == null) return
                    for (b in 0 until brackets.length()) {
                        val iv = brackets.getJSONObject(b).optInt("initialLeverage", 0)
                        if (iv > max) max = iv
                    }
                }
                val t = body.trim()
                if (t.startsWith("[")) {
                    val arr = JSONArray(t)
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        if (o.optString("symbol").isEmpty() || o.optString("symbol") == symbol)
                            scanBrackets(o.optJSONArray("brackets"))
                    }
                } else {
                    scanBrackets(JSONObject(t).optJSONArray("brackets"))
                }
                max
            }
        } catch (_: Exception) {
            20
        }
    }

    suspend fun setLeverage(creds: Credentials, symbol: String, leverage: Int): JSONObject =
        signedPost(creds, "/fapi/v1/leverage", mapOf("symbol" to symbol, "leverage" to leverage.toString()))

    /**
     * 市价开仓。
     * positionSide: BOTH（单向）或 LONG/SHORT（双向）
     */
    suspend fun marketOpen(
        creds: Credentials,
        symbol: String,
        side: String,
        quantity: String,
        positionSide: String,
        clientOrderId: String
    ): JSONObject = signedPost(
        creds, "/fapi/v1/order",
        mapOf(
            "symbol" to symbol,
            "side" to side,
            "type" to "MARKET",
            "quantity" to quantity,
            "positionSide" to positionSide,
            "newClientOrderId" to clientOrderId
        )
    )

    /** 止损市价（reduceOnly 或 closePosition）。 */
    suspend fun stopMarketClose(
        creds: Credentials,
        symbol: String,
        side: String,
        stopPrice: String,
        positionSide: String,
        clientOrderId: String
    ): JSONObject = signedPost(
        creds, "/fapi/v1/order",
        mapOf(
            "symbol" to symbol,
            "side" to side,
            "type" to "STOP_MARKET",
            "stopPrice" to stopPrice,
            "closePosition" to "true",
            "positionSide" to positionSide,
            "newClientOrderId" to clientOrderId
        )
    )

    suspend fun takeProfitMarketClose(
        creds: Credentials,
        symbol: String,
        side: String,
        stopPrice: String,
        positionSide: String,
        clientOrderId: String
    ): JSONObject = signedPost(
        creds, "/fapi/v1/order",
        mapOf(
            "symbol" to symbol,
            "side" to side,
            "type" to "TAKE_PROFIT_MARKET",
            "stopPrice" to stopPrice,
            "closePosition" to "true",
            "positionSide" to positionSide,
            "newClientOrderId" to clientOrderId
        )
    )

    suspend fun marketClose(
        creds: Credentials,
        symbol: String,
        side: String,
        quantity: String,
        positionSide: String,
        clientOrderId: String
    ): JSONObject = signedPost(
        creds, "/fapi/v1/order",
        mapOf(
            "symbol" to symbol,
            "side" to side,
            "type" to "MARKET",
            "quantity" to quantity,
            "positionSide" to positionSide,
            "reduceOnly" to "true",
            "newClientOrderId" to clientOrderId
        )
    )

    suspend fun cancelOrder(creds: Credentials, symbol: String, orderId: Long): JSONObject =
        signedDelete(creds, "/fapi/v1/order", mapOf("symbol" to symbol, "orderId" to orderId.toString()))

    private suspend fun signedDelete(creds: Credentials, path: String, params: Map<String, String>): JSONObject =
        withContext(Dispatchers.IO) {
            val ts = System.currentTimeMillis().toString()
            val all = LinkedHashMap(params)
            all["timestamp"] = ts
            all["recvWindow"] = "5000"
            val q = all.entries.joinToString("&") { "${it.key}=${it.value}" }
            val sig = sign(creds.secret, q)
            val url = "${baseUrl(creds.testnet)}$path?$q&signature=$sig"
            val req = Request.Builder().url(url).header("X-MBX-APIKEY", creds.apiKey).delete().build()
            client.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) throw IllegalStateException(parseErr(body, resp.code))
                if (body.isBlank()) JSONObject() else JSONObject(body)
            }
        }

    suspend fun positionRisk(creds: Credentials, symbol: String? = null): JSONArray = withContext(Dispatchers.IO) {
        val params = if (symbol != null) mapOf("symbol" to symbol) else emptyMap()
        val ts = System.currentTimeMillis().toString()
        val all = LinkedHashMap(params)
        all["timestamp"] = ts
        all["recvWindow"] = "5000"
        val q = all.entries.joinToString("&") { "${it.key}=${it.value}" }
        val sig = sign(creds.secret, q)
        val url = "${baseUrl(creds.testnet)}/fapi/v2/positionRisk?$q&signature=$sig"
        val req = Request.Builder().url(url).header("X-MBX-APIKEY", creds.apiKey).get().build()
        client.newCall(req).execute().use { resp ->
            val body = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) throw IllegalStateException(parseErr(body, resp.code))
            JSONArray(body)
        }
    }
}
