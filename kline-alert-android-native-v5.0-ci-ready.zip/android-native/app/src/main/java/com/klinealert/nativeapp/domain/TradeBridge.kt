package com.klinealert.nativeapp.domain

import com.klinealert.nativeapp.data.BinanceTradeClient
import com.klinealert.nativeapp.data.LocalStore
import com.klinealert.nativeapp.domain.TradeModels.TradeConfig
import com.klinealert.nativeapp.domain.TradeModels.TradeLink
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.min

/**
 * 跟单桥：本地持仓事件 → 币安下单。
 * 去重：localPositionId 占坑 + clientOrderId 幂等 + 品种方向冷却。
 */
class TradeBridge(
    private val store: LocalStore,
    private val client: BinanceTradeClient = BinanceTradeClient()
) {
    private val openInFlight = ConcurrentHashMap.newKeySet<String>()
    private val closeInFlight = ConcurrentHashMap.newKeySet<String>()
    private val symbolDirCooldown = ConcurrentHashMap<String, Long>()

    data class OpenRequest(
        val localPositionId: String,
        val symbol: String,
        val direction: String,
        val entry: Double,
        val stop: Double,
        val target: Double,
        val source: String,
        val note: String = "",
        val localCreatedAt: Long = System.currentTimeMillis()
    )

    sealed class Result {
        data class Ok(val link: TradeLink, val message: String) : Result()
        data class Skip(val reason: String) : Result()
        data class Err(val reason: String) : Result()
    }

    fun activeOpenCount(): Int =
        store.loadTradeLinks(TradeModels.STATUS_OPEN, 100).size +
            store.loadTradeLinks(TradeModels.STATUS_PENDING_OPEN, 100).size +
            store.loadTradeLinks(TradeModels.STATUS_CLOSING, 50).size

    /**
     * 尝试开仓。返回 Skip 表示去重/风控拒绝（非错误）。
     */
    suspend fun tryOpen(
        creds: BinanceTradeClient.Credentials,
        cfg: TradeConfig,
        req: OpenRequest,
        dualSide: Boolean
    ): Result {
        val id = req.localPositionId
        if (!openInFlight.add(id)) return Result.Skip("OPEN_SKIP_INFLIGHT")
        try {
            if (!cfg.enabled) return Result.Skip("OPEN_SKIP_DISABLED")
            store.loadTradeLink(id)?.let {
                return Result.Skip("OPEN_SKIP_EXISTS status=${it.status}")
            }
            if (activeOpenCount() >= cfg.maxFollowSlots)
                return Result.Skip("OPEN_SKIP_MAX_SLOTS")
            val sd = "${req.symbol}|${req.direction}"
            val cdUntil = symbolDirCooldown[sd] ?: 0L
            if (System.currentTimeMillis() < cdUntil)
                return Result.Skip("OPEN_SKIP_COOLDOWN")
            if (cfg.onlyAutoBattle && !req.source.contains("自动") && req.source != "auto")
                return Result.Skip("OPEN_SKIP_NOT_AUTO")
            // 仅跟随新建后 maxFollowAgeMs 内的仓，避免过时价位入场
            val age = System.currentTimeMillis() - req.localCreatedAt
            if (cfg.maxFollowAgeMs > 0 && age > cfg.maxFollowAgeMs)
                return Result.Skip("OPEN_SKIP_STALE age=${age / 1000}s > ${cfg.maxFollowAgeMs / 1000}s")

            val clientOid = TradeModels.clientOrderIdFor(id, "o")
            val pending = TradeLink(
                localPositionId = id, symbol = req.symbol, direction = req.direction,
                marginUsdt = cfg.marginUsdt, leverage = 0.0, status = TradeModels.STATUS_PENDING_OPEN,
                stopPrice = req.stop, targetPrice = req.target, clientOrderId = clientOid,
                source = req.source, openedAt = System.currentTimeMillis(), updatedAt = System.currentTimeMillis()
            )
            if (!store.tryInsertTradeLink(pending))
                return Result.Skip("OPEN_SKIP_EXISTS_RACE")

            val dayStart = java.util.Calendar.getInstance().apply {
                set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0)
                set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
            }.timeInMillis
            val dayClosed = store.loadTradeLinks(TradeModels.STATUS_CLOSED, 500).filter { it.closedAt >= dayStart }
            val dayPnl = dayClosed.sumOf { it.realizedPnlNet }
            if (dayPnl <= -kotlin.math.abs(cfg.dailyMaxLossUsdt))
                return fail(pending, "日亏损熔断：今日已实现 ${"%.2f".format(dayPnl)}U")
            if (dayClosed.size >= cfg.dailyMaxOpens)
                return fail(pending, "日开仓次数熔断：${dayClosed.size}/${cfg.dailyMaxOpens}")

            val (available, _, _) = client.balanceUsdt(creds)
            if (available < cfg.marginUsdt * 1.02)
                return fail(pending, "余额不足：可用 ${"%.2f".format(available)} < 本金 ${cfg.marginUsdt}")

            runCatching { client.ensureFilters(creds.testnet) }
            var lev = if (cfg.useMaxLeverage) {
                runCatching { client.maxLeverage(creds, req.symbol) }.getOrDefault(20)
            } else cfg.maxLeverageCap
            lev = min(lev, cfg.maxLeverageCap).coerceAtLeast(1)
            runCatching { client.setLeverage(creds, req.symbol, lev) }

            val px = req.entry.takeIf { it > 0 } ?: return fail(pending, "无效开仓价")
            val filt = client.filterOf(creds.testnet, req.symbol)
            val qtyRaw = TradeModels.quantity(cfg.marginUsdt, lev.toDouble(), px)
            val qtyStr = if (filt != null) client.formatByStep(qtyRaw, filt.qtyStep) else formatQty(qtyRaw)
            val qtyNum = qtyStr.toDoubleOrNull() ?: 0.0
            if (qtyStr == "0" || qtyNum <= 0)
                return fail(pending, "数量过小 qty=$qtyRaw")
            if (filt != null && qtyNum < filt.minQty)
                return fail(pending, "低于 minQty ${filt.minQty}")
            if (filt != null && qtyNum * px < filt.minNotional)
                return fail(pending, "低于最小名义 ${filt.minNotional}")

            val side = if (req.direction.equals("SHORT", true)) "SELL" else "BUY"
            val posSide = when {
                dualSide && req.direction.equals("SHORT", true) -> "SHORT"
                dualSide -> "LONG"
                else -> "BOTH"
            }
            val order = try {
                client.marketOpen(creds, req.symbol, side, qtyStr, posSide, clientOid)
            } catch (e: Exception) {
                return fail(pending, e.message ?: "开仓失败")
            }
            val avg = order.optString("avgPrice", "0").toDoubleOrNull()?.takeIf { it > 0 }
                ?: order.optString("price", "0").toDoubleOrNull() ?: px
            val execQty = order.optString("executedQty", qtyStr).toDoubleOrNull() ?: qtyRaw
            val orderId = order.optLong("orderId", 0L)
            val commission = order.optString("commission", "0").toDoubleOrNull() ?: 0.0

            // 挂止盈止损：严格使用监控页 stop/target（与盈亏比一致），tick 圆整后挂单；失败重试 1 次
            val closeSide = if (side == "BUY") "SELL" else "BUY"
            val tick = filt?.priceTick ?: 0.01
            var stopOid = 0L
            var tpOid = 0L
            val protectErrs = mutableListOf<String>()
            val stopPx = if (req.stop > 0) client.formatByStep(req.stop, tick) else "0"
            val tpPx = if (req.target > 0) client.formatByStep(req.target, tick) else "0"
            suspend fun placeSl(): Long {
                if (req.stop <= 0 || stopPx == "0") return 0L
                repeat(2) { attempt ->
                    try {
                        val j = client.stopMarketClose(
                            creds, req.symbol, closeSide, stopPx, posSide,
                            TradeModels.clientOrderIdFor(id, if (attempt == 0) "s" else "s1")
                        )
                        val oid = j.optLong("orderId", 0L)
                        if (oid > 0) return oid
                    } catch (e: Exception) {
                        if (attempt == 1) protectErrs += "止损挂单失败: ${e.message}"
                    }
                }
                return 0L
            }
            suspend fun placeTp(): Long {
                if (req.target <= 0 || tpPx == "0") return 0L
                repeat(2) { attempt ->
                    try {
                        val j = client.takeProfitMarketClose(
                            creds, req.symbol, closeSide, tpPx, posSide,
                            TradeModels.clientOrderIdFor(id, if (attempt == 0) "t" else "t1")
                        )
                        val oid = j.optLong("orderId", 0L)
                        if (oid > 0) return oid
                    } catch (e: Exception) {
                        if (attempt == 1) protectErrs += "止盈挂单失败: ${e.message}"
                    }
                }
                return 0L
            }
            stopOid = placeSl()
            tpOid = placeTp()
            val needSl = req.stop > 0
            val needTp = req.target > 0
            val protectOk = (!needSl || stopOid > 0) && (!needTp || tpOid > 0)
            val open = pending.copy(
                status = TradeModels.STATUS_OPEN,
                leverage = lev.toDouble(),
                qty = execQty,
                avgEntry = avg,
                entryOrderId = orderId,
                stopOrderId = stopOid,
                tpOrderId = tpOid,
                commissionOpen = commission,
                stopPrice = req.stop,
                targetPrice = req.target,
                lastError = if (protectOk) "" else protectErrs.joinToString("; ").ifBlank { "止盈止损未完全挂上" },
                updatedAt = System.currentTimeMillis()
            )
            store.saveTradeLink(open)
            val msg = buildString {
                append("市价开仓成功 qty=$execQty lev=${lev}x")
                append(" · SL=${if (stopOid > 0) stopPx else "未挂"}")
                append(" · TP=${if (tpOid > 0) tpPx else "未挂"}")
                if (!protectOk) append(" ⚠保护单异常")
            }
            return Result.Ok(open, msg)
        } finally {
            openInFlight.remove(id)
        }
    }

    suspend fun tryClose(
        creds: BinanceTradeClient.Credentials,
        cfg: TradeConfig,
        localPositionId: String,
        reason: String,
        dualSide: Boolean
    ): Result {
        if (!closeInFlight.add(localPositionId)) return Result.Skip("CLOSE_SKIP_INFLIGHT")
        try {
            val link = store.loadTradeLink(localPositionId)
                ?: return Result.Skip("CLOSE_SKIP_NO_LINK")
            if (link.status != TradeModels.STATUS_OPEN)
                return Result.Skip("CLOSE_SKIP_NOT_OPEN status=${link.status}")
            val closing = link.copy(status = TradeModels.STATUS_CLOSING, updatedAt = System.currentTimeMillis())
            if (!store.updateTradeLinkIfStatus(closing, TradeModels.STATUS_OPEN))
                return Result.Skip("CLOSE_SKIP_RACE")

            // 撤条件单
            if (link.stopOrderId > 0) runCatching { client.cancelOrder(creds, link.symbol, link.stopOrderId) }
            if (link.tpOrderId > 0) runCatching { client.cancelOrder(creds, link.symbol, link.tpOrderId) }

            val side = if (link.direction.equals("SHORT", true)) "BUY" else "SELL"
            val posSide = when {
                dualSide && link.direction.equals("SHORT", true) -> "SHORT"
                dualSide -> "LONG"
                else -> "BOTH"
            }
            val qtyStr = formatQty(link.qty)
            val exitPx: Double
            val feeClose: Double
            if (link.qty > 0) {
                val order = try {
                    client.marketClose(
                        creds, link.symbol, side, qtyStr, posSide,
                        TradeModels.clientOrderIdFor(localPositionId, "c")
                    )
                } catch (e: Exception) {
                    // 可能已在交易所被条件单平掉
                    val flat = link.copy(
                        status = TradeModels.STATUS_CLOSED, closeReason = reason,
                        closedAt = System.currentTimeMillis(), lastError = e.message ?: "",
                        updatedAt = System.currentTimeMillis()
                    )
                    store.saveTradeLink(flat)
                    symbolDirCooldown["${link.symbol}|${link.direction}"] =
                        System.currentTimeMillis() + cfg.symbolDirCooldownMs
                    return Result.Ok(flat, "平仓异常（可能已平）：${e.message}")
                }
                exitPx = order.optString("avgPrice", "0").toDoubleOrNull()?.takeIf { it > 0 }
                    ?: order.optString("price", "0").toDoubleOrNull() ?: link.markPrice
                feeClose = order.optString("commission", "0").toDoubleOrNull() ?: 0.0
            } else {
                exitPx = link.markPrice
                feeClose = 0.0
            }
            val net = TradeModels.netPnl(link.qty, link.direction, link.avgEntry, exitPx, link.commissionOpen, feeClose)
            val closed = link.copy(
                status = TradeModels.STATUS_CLOSED,
                avgExit = exitPx,
                commissionClose = feeClose,
                realizedPnlNet = net,
                closeReason = reason,
                closedAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )
            store.saveTradeLink(closed)
            symbolDirCooldown["${link.symbol}|${link.direction}"] =
                System.currentTimeMillis() + cfg.symbolDirCooldownMs
            return Result.Ok(closed, "已平仓 净盈亏 ${"%.2f".format(net)}U")
        } finally {
            closeInFlight.remove(localPositionId)
        }
    }

    /** 同步保护价（监控 stop/target 变更）。 */
    suspend fun syncProtective(
        creds: BinanceTradeClient.Credentials,
        localPositionId: String,
        stop: Double,
        target: Double,
        dualSide: Boolean
    ): Result {
        val link = store.loadTradeLink(localPositionId) ?: return Result.Skip("NO_LINK")
        if (link.status != TradeModels.STATUS_OPEN) return Result.Skip("NOT_OPEN")
        if (link.stopOrderId > 0) runCatching { client.cancelOrder(creds, link.symbol, link.stopOrderId) }
        if (link.tpOrderId > 0) runCatching { client.cancelOrder(creds, link.symbol, link.tpOrderId) }
        val closeSide = if (link.direction.equals("SHORT", true)) "BUY" else "SELL"
        val posSide = when {
            dualSide && link.direction.equals("SHORT", true) -> "SHORT"
            dualSide -> "LONG"
            else -> "BOTH"
        }
        var stopOid = 0L
        var tpOid = 0L
        if (stop > 0) {
            runCatching {
                stopOid = client.stopMarketClose(
                    creds, link.symbol, closeSide, formatPrice(stop), posSide,
                    TradeModels.clientOrderIdFor(localPositionId, "s2")
                ).optLong("orderId", 0L)
            }
        }
        if (target > 0) {
            runCatching {
                tpOid = client.takeProfitMarketClose(
                    creds, link.symbol, closeSide, formatPrice(target), posSide,
                    TradeModels.clientOrderIdFor(localPositionId, "t2")
                ).optLong("orderId", 0L)
            }
        }
        val u = link.copy(
            stopPrice = stop, targetPrice = target, stopOrderId = stopOid, tpOrderId = tpOid,
            updatedAt = System.currentTimeMillis()
        )
        store.saveTradeLink(u)
        return Result.Ok(u, "保护单已更新")
    }

    private fun fail(pending: TradeLink, msg: String): Result {
        val f = pending.copy(status = TradeModels.STATUS_FAILED, lastError = msg, updatedAt = System.currentTimeMillis())
        store.saveTradeLink(f)
        return Result.Err(msg)
    }

    private fun formatQty(q: Double): String {
        if (q <= 0) return "0"
        return String.format(java.util.Locale.US, "%.3f", q).trimEnd('0').trimEnd('.')
    }

    private fun formatPrice(p: Double): String =
        String.format(java.util.Locale.US, "%.6f", p).trimEnd('0').trimEnd('.')

    /**
     * 对账：OPEN 但交易所无仓 → CLOSED(external)；刷新标记价与未实现盈亏。
     */
    suspend fun reconcileAndRefreshMarks(creds: BinanceTradeClient.Credentials): List<String> {
        val notes = mutableListOf<String>()
        val opens = store.loadTradeLinks(TradeModels.STATUS_OPEN, 100)
        if (opens.isEmpty()) return notes
        val risks = runCatching { client.positionRisk(creds) }.getOrNull() ?: return notes
        val bySym = mutableMapOf<String, org.json.JSONObject>()
        for (i in 0 until risks.length()) {
            val o = risks.getJSONObject(i)
            val amt = o.optString("positionAmt", "0").toDoubleOrNull() ?: 0.0
            if (kotlin.math.abs(amt) > 0) bySym[o.optString("symbol")] = o
        }
        for (link in opens) {
            val o = bySym[link.symbol]
            if (o == null) {
                val closed = link.copy(
                    status = TradeModels.STATUS_CLOSED,
                    closeReason = TradeModels.CLOSE_EXTERNAL,
                    closedAt = System.currentTimeMillis(),
                    updatedAt = System.currentTimeMillis(),
                    lastError = "对账：交易所无持仓"
                )
                store.saveTradeLink(closed)
                notes += "${link.symbol} 外部已平 → CLOSED"
                symbolDirCooldown["${link.symbol}|${link.direction}"] =
                    System.currentTimeMillis() + 60_000L
            } else {
                val mark = o.optString("markPrice", "0").toDoubleOrNull() ?: 0.0
                val upnl = o.optString("unRealizedProfit", "0").toDoubleOrNull() ?: 0.0
                val amt = kotlin.math.abs(o.optString("positionAmt", "0").toDoubleOrNull() ?: 0.0)
                store.saveTradeLink(
                    link.copy(
                        markPrice = mark, unrealizedPnl = upnl,
                        qty = if (amt > 0) amt else link.qty,
                        updatedAt = System.currentTimeMillis()
                    )
                )
            }
        }
        return notes
    }
}
