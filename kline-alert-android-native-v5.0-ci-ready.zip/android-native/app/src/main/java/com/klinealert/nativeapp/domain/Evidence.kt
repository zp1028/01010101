package com.klinealert.nativeapp.domain

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * 量价形态分类器（v3.7）：8 种形态，ATR/量比归一，纯函数。
 * 返回 (形态名, 说明)。形态同时驱动证据打分、一票否决与持仓量价失效。
 */
object VolumePriceClassifier {

    val POSITIVE_LONG = setOf("放量突破", "放量上涨", "缩量回踩", "缩量反抽", "恐慌抛售")
    val POSITIVE_SHORT = setOf("放量突破", "放量下跌", "缩量回踩", "缩量反抽", "恐慌抛售")
    /** 看涨形态 / 看跌形态（相对方向） */
    fun bullish(pattern: String) = pattern in setOf("放量上涨", "缩量回踩", "恐慌抛售", "放量突破")
    fun bearish(pattern: String) = pattern in setOf("放量下跌", "缩量反抽", "放量突破")

    fun classify(candles: List<Candle>, volRatio: Double, atr: Double, support: Double?, resistance: Double?, ema20: Double?): Pair<String, String> {
        if (candles.size < 2 || atr <= 0) return "" to ""
        val last = candles.last()
        val prev = candles[candles.size - 2]
        val body = abs(last.close - last.open)
        val lowerWick = min(last.open, last.close) - last.low
        val recentLows = candles.takeLast(30).minOf { it.low }
        val recentHighs = candles.takeLast(30).maxOf { it.high }
        // 1. 放量突破：量比≥1.8 + 收盘破结构位
        if (volRatio >= 1.8) {
            val brokeRes = resistance != null && last.close >= resistance
            val brokeSup = support != null && last.close <= support
            if (brokeRes) return "放量突破" to "量比 ${volRatio.fmt(1)}× 放量突破压力位"
            if (brokeSup) return "放量突破" to "量比 ${volRatio.fmt(1)}× 放量跌破支撑位"
            // 2/3. 放量大阳/大阴
            if (body >= 0.8 * atr) return if (last.close > last.open) "放量上涨" to "量比 ${volRatio.fmt(1)}× 大阳线（实体 ${body.fmt(1)} ≥0.8×ATR）" else "放量下跌" to "量比 ${volRatio.fmt(1)}× 大阴线（实体 ${body.fmt(1)} ≥0.8×ATR）"
            // 4. 放量滞涨
            if (body < 0.3 * atr) return "放量滞涨" to "量比 ${volRatio.fmt(1)}× 但实体极小（高位出货/低位吸筹待分方向）"
        }
        // 7. 恐慌抛售：量比≥2.5 + 长下影 + 阶段新低
        if (volRatio >= 2.5 && lowerWick >= body * 2 && last.low <= recentLows * 1.001)
            return "恐慌抛售" to "量比 ${volRatio.fmt(1)}× 长下影探至阶段新低（底部信号，等确认）"
        // 8. 突破失败：前一根刚破位、本根收回
        if (resistance != null && prev.close > resistance && last.close < resistance && volRatio >= 1.2)
            return "突破失败" to "上破压力位后 1 根内收回（假突破，反方向证据）"
        if (support != null && prev.close < support && last.close > support && volRatio >= 1.2)
            return "突破失败" to "下破支撑位后 1 根内收回（假突破，反方向证据）"
        // 5/6. 缩量回踩/反抽：量比≤0.6 + 触及关键位但收盘守住
        if (volRatio <= 0.6) {
            val touchedSup = support != null && last.low <= support * 1.002 || (ema20 != null && last.low <= ema20 * 1.002)
            val touchedRes = resistance != null && last.high >= resistance * 0.998 || (ema20 != null && last.high >= ema20 * 0.998)
            if (touchedSup && last.close > (support ?: ema20 ?: 0.0)) return "缩量回踩" to "量比 ${volRatio.fmt(1)}× 缩量回踩支撑/EMA20 未破（回调无抛压）"
            if (touchedRes && last.close < (resistance ?: ema20 ?: Double.MAX_VALUE)) return "缩量反抽" to "量比 ${volRatio.fmt(1)}× 缩量反抽压力/EMA20 未过（反抽无承接）"
        }
        return "" to ""
    }

    private fun Double.fmt(n: Int) = String.format(java.util.Locale.US, "%.${n}f", this)
}

/**
 * 四维证据引擎（v3.7）：位置35% + 信号30% + 结构20% + 历史15%。
 * 全部输入来自现有 Analysis 状态机/模式库/胜率/确认率数据。
 */
object EvidenceEngine {

    data class Evidence(val score: Int, val position: Int, val signal: Int, val structure: Int, val history: Int, val veto: Boolean, val detail: List<String>)

    /** ① 位置证据（满分 100，权重 0.35） */
    fun position(a: Analysis, livePrice: Double?): Int {
        val price = livePrice?.takeIf { it > 0 } ?: a.price
        val atr = a.atr.takeIf { it > 0 } ?: a.price * 0.01
        var s = 0
        a.support?.let { if (abs(price - it) <= 0.3 * atr) s = max(s, 40) }
        a.resistance?.let { if (abs(price - it) <= 0.3 * atr) s = max(s, 40) }
        a.swingLow?.let { if (abs(price - it) <= 0.5 * atr) s = max(s, 30) }
        a.swingHigh?.let { if (abs(price - it) <= 0.5 * atr) s = max(s, 30) }
        if (s == 0) {
            val nearSup = a.support?.let { abs(price - it) <= atr } ?: false
            val nearRes = a.resistance?.let { abs(price - it) <= atr } ?: false
            if (nearSup || nearRes) s = 10
        }
        return s
    }

    /** ② 信号证据（指标 22 分 + 量价形态 8 分，满分 100；反向否决返回 veto） */
    fun signal(a: Analysis): Pair<Int, Boolean> {
        var s = 0
        a.states.firstOrNull { it.name == "MACD" }?.let { st ->
            val barsAgo = Regex("(\\d+) 根K线前").find(st.detail)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 0
            val dirMatch = if (a.direction == "LONG") st.state.contains("多头") else st.state.contains("空头")
            if (dirMatch) s += when { barsAgo <= 2 -> 15; barsAgo <= 30 -> 8; else -> 3 }
        }
        val ema = a.states.firstOrNull { it.name == "EMA9/21" }
        val kdj = a.states.firstOrNull { it.name == "KDJ" }
        val dirKey = if (a.direction == "LONG") "多头" else "空头"
        if (ema?.state?.contains(dirKey) == true) s += 7
        if (kdj?.state?.contains(dirKey) == true) s += 7
        // 量价形态 8 分：顺方向形态满分，反方向否决
        var veto = false
        when (a.volumePattern) {
            "放量突破", "放量上涨", "缩量回踩", "缩量反抽", "恐慌抛售" -> if ((a.direction == "LONG" && VolumePriceClassifier.bullish(a.volumePattern)) || (a.direction == "SHORT" && VolumePriceClassifier.bearish(a.volumePattern))) s += 8
            "放量下跌", "放量滞涨", "突破失败" -> {
                val adverse = (a.direction == "LONG" && (a.volumePattern == "放量下跌" || a.volumePattern == "突破失败")) ||
                    (a.direction == "SHORT" && a.volumePattern == "突破失败" && false)
                if (adverse) veto = true
            }
        }
        // 一票否决：15m 逆向加速的信号证据归零由上层处理（这里处理量价反方向）
        return (s.coerceAtMost(22 + 8).coerceIn(0, 30).let { (it / 30.0 * 100).toInt() }) to veto
    }

    /** ③ 结构证据（regime 匹配 + 模式库 + 波动健康，满分 100） */
    fun structure(a: Analysis, direction: String): Int {
        var s = 50
        val long = direction == "LONG"
        val regimeBull = a.regime.contains("牛") || a.regime.contains("上涨") || a.regime == "突破承压线"
        val regimeBear = a.regime.contains("熊") || a.regime.contains("下跌") || a.regime.contains("反弹")
        if ((long && regimeBull) || (!long && regimeBear)) s += 20
        else if ((long && regimeBear) || (!long && regimeBull)) s -= 20
        if (a.patterns.isNotEmpty()) s += 12
        val adxState = a.states.firstOrNull { it.name == "ADX" }?.detail ?: ""
        val bollState = a.states.firstOrNull { it.name == "布林" }?.detail ?: ""
        if (adxState.contains("衰竭") && bollState.contains("显著扩张")) s -= 25
        if (bollState.contains("显著收敛")) s += 12
        return s.coerceIn(0, 100)
    }

    /** ④ 历史证据（周期×方向胜率 70 + 品种确认率 30，满分 100；无样本 50） */
    fun history(winRate: Pair<Int, Double>?, confirmRate: Double?): Int {
        var s = 50
        if (winRate != null && winRate.first >= 8) s = 50 + ((winRate.second - 0.5) * 140).toInt().coerceIn(-50, 50)
        if (confirmRate != null) s += ((confirmRate - 0.5) * 60).toInt().coerceIn(-15, 30)
        return s.coerceIn(0, 100)
    }

    /**
     * 总分：位置35 + 信号30 + 结构20 + 历史15（各项已归一到 0-100）。
     * veto（反向量价形态）时信号证据清零。
     */
    fun evaluate(sop: SymbolOpportunity, livePrice: Double?, winRate: Pair<Int, Double>?, confirmRate: Double?): Evidence {
        val a = sop.rep
        val (sigRaw, veto) = signal(a)
        val pos = position(a, livePrice)
        val sig = if (veto) 0 else sigRaw
        val str = structure(a, sop.direction)
        val his = history(winRate, confirmRate)
        val total = (pos * 0.35 + sig * 0.30 + str * 0.20 + his * 0.15).toInt()
        val detail = buildList {
            add("位置 ${pos}（${when { pos >= 40 -> "在关键位上"; pos >= 10 -> "接近中"; else -> "远离关键位" }}）")
            if (veto) add("信号 0（⚠ 反向量价形态：${a.volumePattern}）") else add("信号 ${sig}（${if (a.volumePattern.isNotBlank()) a.volumePattern else "指标${if (sig >= 50) "达标" else "未齐"}"}）")
            add("结构 ${str}（${a.regime}${if (a.patterns.isNotEmpty()) "·" + a.patterns.first() else ""}）")
            add("历史 ${his}（${winRate?.let { "胜率${(it.second * 100).toInt()}%·${it.first}样本" } ?: "样本积累中"}）")
        }
        return Evidence(total, pos, sig, str, his, veto, detail)
    }
}
