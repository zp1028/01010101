package com.klinealert.nativeapp.domain

/**
 * 指标状态机条目：不只报告"刚发生"，还报告"当前状态与延续范围"。
 * 例：MACD「多头延续」——金叉发生于 5 根K线前，红柱扩大，多头动能延续中。
 */
data class IndicatorState(val name: String, val state: String, val detail: String) {
    fun compact(): String = "$name $state（$detail）"
}
