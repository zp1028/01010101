package com.klinealert.nativeapp.domain

/**
 * v4.6 自动作战循环引擎（Auto-Battle Loop）：把「作战面板推荐 → 自动入仓 → 自动止盈止损平仓 → 循环等下一信号」闭环化。
 *
 * 用户决策（2026-10-12 更新）：
 *  - 盈亏比：**止损距离 = 2×ATR，止盈距离 = 3×ATR**（即止损 2 / 止盈 3）。
 *  - 信号按**现价**入场；入场前校验「距止损位不能太近」，太近不入。
 *  - **全自动**：主攻信号自动入仓、自动平仓；**满仓后作战台不再推荐**，平仓后只补**新鲜**确认信号（防落后信号顶上）。
 *  - 持仓本金默认 1 USDT、杠杆 50 倍（LocalPosition.size = 本金 marginUsdt）。
 *    方向变动 1% → 未实现盈亏 = 1 × 50 × 0.01 = **+0.50 USDT**；收益率（开仓保证金口径）= **+50%**。
 *    切勿把「方向变动百分点」直接 × 杠杆当 USDT（会放大 100 倍）。
 *  - **移动止盈/固定止盈可切换**：固定=到价即平；移动=从极值回撤 trailStep 才平（利润奔跑）。
 *
 * 安全设计：
 *  - 防插针：平仓 tick 需交叉校验通过（crossCheckOk=false → 不动作，下一 tick 复核）。
 *  - 冷却：平仓后同品种同方向 cooldownHours 内不自动重入（防手续费磨死）。
 *  - 门控不入：风险距离 R=ATR <0.3% 价（止损太近易被扫）/ >5% 价（波动过大）→ 拒绝。
 *  - 移动止盈永不比原始止损差（trailStop 与原始 stop 取更优）。
 */
object BattleLoopEngine {

    const val DEFAULT_MAX_POSITIONS = 10          // 自动作战循环最多同时持仓数
    const val DEFAULT_STOP_MULT = 2.0             // 止损距离 = 2×ATR（用户决策：止损是 2）
    const val DEFAULT_TARGET_MULT = 3.0           // 止盈距离 = 3×ATR（用户决策：止盈是 3）
    const val DEFAULT_COOLDOWN_HOURS = 4.0        // 平仓后同品种同方向冷却（小时）
    const val DEFAULT_TRAIL_ATR = 1.5             // 移动止盈：从极值回撤 1.5×ATR 触发
    const val DEFAULT_MARGIN_USDT = 1.0           // 自动入仓默认本金（USDT）
    const val DEFAULT_LEVERAGE = 50.0             // 自动入仓默认杠杆
    const val MIN_ENTRY_SCORE = 70                // 自动入仓最低综合分
    const val MIN_RISK_PCT = 0.003                // 最小风险距离（价格 0.3%）
    const val MAX_RISK_PCT = 0.05                 // 最大风险距离（价格 5%）
    const val CLOSE_CROSSCHECK_TOL_PCT = 1.5      // 平仓前交叉校验容差（%）

    const val CLOSE_TAKE_PROFIT = "take_profit"
    const val CLOSE_STOP_LOSS = "stop_loss"
    const val CLOSE_TRAIL_STOP = "trail_stop"

    /** 新鲜度窗口：按信号周期给「自动顶上」设定新鲜门槛，防止落后信号补位。 */
    val FRESH_WINDOWS_MS = mapOf(
        "15m" to 30 * 60_000L,
        "30m" to 60 * 60_000L,
        "1h" to 120 * 60_000L,
        "4h" to 480 * 60_000L
    )

    fun freshWindowMs(timeframe: String): Long = FRESH_WINDOWS_MS[timeframe] ?: 60 * 60_000L

    /** 信号是否新鲜：K 线时间在周期对应的窗口内（旧信号不自动补位）。 */
    fun isFresh(candleTime: Long, now: Long, timeframe: String): Boolean =
        candleTime > 0 && now - candleTime <= freshWindowMs(timeframe)

    /**
     * 新鲜度评分（0..100）：≤5 分钟满分；超过窗口归 0；中间线性衰减。
     * 用于「优中选优」——越新的信号越优先，旧高分不压新信号。
     */
    fun freshnessScore(candleTime: Long, now: Long, timeframe: String): Double {
        if (candleTime <= 0) return 0.0
        val age = now - candleTime
        if (age <= 5 * 60_000L) return 100.0
        val win = freshWindowMs(timeframe)
        if (age >= win) return 0.0
        return (1.0 - (age - 5 * 60_000L).toDouble() / (win - 5 * 60_000L).toDouble()) * 100.0
    }

    /**
     * 作战评分（0..100，优中选优）：信号分×0.30 + 方向历史胜率×0.20 + 确认强度×0.15
     * + 波动健康×0.15 + 新鲜度×0.20。作战台榜单与自动入仓共用同一口径。
     */
    fun battleScore(
        score: Int, winRate: Double, progressAtr: Double,
        volExpansion: Double, candleTime: Long, now: Long, timeframe: String
    ): Double {
        val volHealth = 1.0 - kotlin.math.abs(volExpansion - 1.0).coerceIn(0.0, 1.0)
        val confirmStrength = (progressAtr / 2.0).coerceIn(0.0, 1.0)   // 已走出 ATR 倍数（≤2 归一）
        val freshness = freshnessScore(candleTime, now, timeframe)
        // 注意：Kotlin 不以行首 + 续行，整个表达式必须用括号包裹，否则只返回第一项
        return (score.coerceIn(0, 100) * 0.30
            + winRate.coerceIn(0.0, 100.0) * 0.20
            + confirmStrength * 100.0 * 0.15
            + volHealth * 100.0 * 0.15
            + freshness * 0.20)
    }

    /** 入仓计划：按现价入场，止损 2×ATR / 止盈 3×ATR。reject 非空 = 被门控拒绝（不入）。 */
    data class EntryPlan(
        val symbol: String,
        val market: String,
        val direction: String,
        val timeframe: String,
        val entry: Double,          // 现价
        val stop: Double,
        val target: Double,
        val stopMult: Double,       // 止损距离乘数（默认 2）
        val targetMult: Double,     // 止盈距离乘数（默认 3）
        val riskPct: Double,        // 风险距离（1×ATR）占价格百分比
        val evidenceScore: Int,
        val reject: String = ""     // 拒绝原因（非空表示不可入）
    ) {
        val ok: Boolean get() = reject.isEmpty()
        val riskReward: Double get() = if (stopMult > 0) targetMult / stopMult else 0.0   // 3/2 = 1.5
    }

    /** 平仓决策。 */
    data class CloseDecision(
        val action: String,         // CLOSE_TAKE_PROFIT / CLOSE_STOP_LOSS / CLOSE_TRAIL_STOP
        val closePrice: Double,
        val pnlPct: Double,         // 方向化盈亏（价格收益率）
        val reason: String
    )

    /** 方向化涨跌幅（与 PositionEngine 口径一致）。 */
    fun movePct(entry: Double, price: Double, direction: String): Double =
        if (entry <= 0 || price <= 0) 0.0
        else {
            val m = (price - entry) / entry * 100.0
            if (direction.equals("SHORT", ignoreCase = true)) -m else m
        }

    /** 入仓门控 + 定价（止损 2×ATR / 止盈 3×ATR）。不满足「距止损不能太近 / 波动可控」返回 reject 非空的计划。 */
    fun buildEntry(
        symbol: String, market: String, direction: String, timeframe: String,
        price: Double, atr: Double, evidenceScore: Int,
        stopMult: Double = DEFAULT_STOP_MULT, targetMult: Double = DEFAULT_TARGET_MULT
    ): EntryPlan {
        val d = if (direction.equals("SHORT", ignoreCase = true)) "SHORT" else "LONG"
        if (price <= 0 || !price.isFinite() || atr <= 0 || !atr.isFinite())
            return EntryPlan(symbol, market, d, timeframe, price, 0.0, 0.0, stopMult, targetMult, 0.0, evidenceScore, reject = "价格/ATR 无效，跳过")
        val risk = atr
        val riskPct = risk / price
        if (riskPct < MIN_RISK_PCT)
            return EntryPlan(symbol, market, d, timeframe, price, 0.0, 0.0, stopMult, targetMult, riskPct, evidenceScore,
                reject = "距止损太近（止损=${String.format(java.util.Locale.US, "%.2f", stopMult * riskPct * 100)}% < ${String.format(java.util.Locale.US, "%.1f", stopMult * MIN_RISK_PCT * 100)}%），不追")
        if (riskPct > MAX_RISK_PCT)
            return EntryPlan(symbol, market, d, timeframe, price, 0.0, 0.0, stopMult, targetMult, riskPct, evidenceScore,
                reject = "波动过大（止损=${String.format(java.util.Locale.US, "%.2f", stopMult * riskPct * 100)}% > ${String.format(java.util.Locale.US, "%.1f", stopMult * MAX_RISK_PCT * 100)}%），不入")
        val stop = if (d == "LONG") price - stopMult * risk else price + stopMult * risk
        val target = if (d == "LONG") price + targetMult * risk else price - targetMult * risk
        return EntryPlan(symbol, market, d, timeframe, price, stop, target, stopMult, targetMult, riskPct, evidenceScore)
    }

    /** 移动止盈锚点：LONG 取最高价，SHORT 取最低价。 */
    fun updatedBest(direction: String, best: Double, price: Double): Double =
        if (price <= 0) best
        else if (direction.equals("SHORT", ignoreCase = true)) if (best <= 0) price else minOf(best, price)
        else if (best <= 0) price else maxOf(best, price)

    /**
     * 平仓判定（每 tick 调用）。crossCheckOk=false → 防插针不动作（等下一 tick 复核）。
     * trailing=true 时用 bestPrice + trailStep 判移动止盈；trailStop 永不比原始 stop 差。
     */
    fun evaluateClose(
        direction: String, entry: Double, stop: Double, target: Double,
        price: Double, crossCheckOk: Boolean,
        trailing: Boolean = false, bestPrice: Double = 0.0, trailStep: Double = 0.0
    ): CloseDecision? {
        if (price <= 0 || !price.isFinite()) return null
        if (!crossCheckOk) return null                                  // 防插针：参考价偏差过大 → 本次不动
        val d = if (direction.equals("SHORT", ignoreCase = true)) "SHORT" else "LONG"
        val long = d == "LONG"
        val pnl = movePct(entry, price, d)
        if (long && price >= target) return CloseDecision(CLOSE_TAKE_PROFIT, price, pnl, "止盈 ${target}")
        if (!long && price <= target) return CloseDecision(CLOSE_TAKE_PROFIT, price, pnl, "止盈 ${target}")
        if (long && price <= stop) return CloseDecision(CLOSE_STOP_LOSS, price, pnl, "止损 ${stop}")
        if (!long && price >= stop) return CloseDecision(CLOSE_STOP_LOSS, price, pnl, "止损 ${stop}")
        if (trailing && trailStep > 0 && bestPrice > 0) {
            // 从极值回撤 trailStep：LONG 由高往低、SHORT 由低往高；且不劣于原始止损
            val trailStop = if (long) maxOf(stop, bestPrice - trailStep) else minOf(stop, bestPrice + trailStep)
            val hit = if (long) price <= trailStop else price >= trailStop
            if (hit) return CloseDecision(
                CLOSE_TRAIL_STOP, price, pnl,
                "移动止盈（极值 ${String.format(java.util.Locale.US, "%.4f", bestPrice)} 回撤 ${String.format(java.util.Locale.US, "%.4f", trailStep)}）"
            )
        }
        return null
    }

    /** 冷却判定：key = "symbol|direction"；closeAt<=0 视为无冷却。 */
    fun inCooldown(key: String, closeAt: Long, now: Long, cooldownHours: Double = DEFAULT_COOLDOWN_HOURS): Boolean {
        if (closeAt <= 0 || key.isBlank()) return false
        return now - closeAt < (cooldownHours * 3_600_000L).toLong()
    }

    fun cooldownRemainMs(key: String, closeAt: Long, now: Long, cooldownHours: Double = DEFAULT_COOLDOWN_HOURS): Long {
        val remain = closeAt + (cooldownHours * 3_600_000L).toLong() - now
        return if (remain > 0) remain else 0L
    }
}
