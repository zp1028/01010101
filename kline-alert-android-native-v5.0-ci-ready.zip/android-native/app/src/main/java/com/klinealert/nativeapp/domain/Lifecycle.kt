package com.klinealert.nativeapp.domain

import kotlin.math.abs

/**
 * 回踩/反转判别器（Pullback vs Reversal Discriminator）
 *
 * 趋势中的反向波动：是「上车前的回踩」还是「行情走完」？
 * 四类证据加权打分（价格行为/动能结构/量能/位置），输出三态 + 置信度：
 *  - 🟢 回踩：趋势内的正常回调，缩量、动能仅减速、位置贴近均线/结构位
 *  - 🟡 分歧：证据互相矛盾，明确给出「等什么」的两条触发线
 *  - 🔴 反转：动能换向 + 放量破位 + 跌破关键结构
 * 判别过程带迟滞思想：置信度需 ≥70 才定性，否则留在分歧态等收盘确认。
 */
data class PullbackVerdict(
    val status: String,        // 回踩 / 分歧 / 反转
    val confidence: Int,       // 0-100
    val evidence: List<String>,// 四类证据明细（含过/不过理由）
    val watchLine: Double?,    // 回踩确认线（回踩位：EMA20/结构位）
    val watchLabel: String,
    val reversalLine: Double?, // 反转确认线（结构位，收盘破位=反转）
    val reversalLabel: String,
    val reversalAtr: Double    // 当前回撤深度（ATR 倍）
) {
    val dot: String get() = if (status == "回踩") "🟢" else if (status == "反转") "🔴" else "🟡"
}

object PullbackReversalJudge {

    /**
     * @param rep 代表周期分析（EMA/ADX/MACD/RSI/结构位等全部来自现有引擎，无新数据依赖）
     * @param reverseAtr 反向波动深度（ATR 倍）：做多=（entry-price）/atr，做空反之
     */
    fun judge(direction: String, price: Double, entry: Double, rep: Analysis, reverseAtr: Double, confirm: Confirmation? = null): PullbackVerdict {
        val atr = rep.atr.takeIf { it > 0 } ?: (price * 0.01)
        val long = direction == "LONG"
        val ev = mutableListOf<String>()
        var pb = 0 // 回踩分
        var rv = 0 // 反转分

        // ① 位置证据：回撤深度
        val depth = abs(price - entry) / atr
        when {
            depth < 1.0 -> { pb += 3; ev.add("回撤 ${fmt(depth)}×ATR（浅，回踩特征）") }
            depth < 1.8 -> { pb += 1; ev.add("回撤 ${fmt(depth)}×ATR（中性）") }
            depth < 2.5 -> { rv += 1; ev.add("回撤 ${fmt(depth)}×ATR（偏深，警惕）") }
            else -> { rv += 3; ev.add("回撤 ${fmt(depth)}×ATR（过深，非正常回踩）") }
        }

        // ② 位置证据：贴近均线/结构位（回踩高发位）
        val ema20 = rep.ema20
        if (ema20 != null && ema20 > 0) {
            val nearEma = abs(price - ema20) / atr < 0.8
            val rightSide = if (long) price > ema20 else price < ema20
            if (nearEma && rightSide) { pb += 2; ev.add("贴 ${if (long) "EMA20 上方" else "EMA20 下方"}回踩（高发回踩位）") }
            else if (!rightSide) { rv += 2; ev.add("已收盘穿越 EMA20（均线失守）") }
        }

        // ③ 动能证据：ADX 与 MACD
        if (rep.adx >= 25) { pb += 2; ev.add("ADX ${rep.adx.toInt()} 仍处强趋势（回调而非转势）") }
        else if (rep.adx in 20.0..25.0) { ev.add("ADX ${rep.adx.toInt()} 中性") }
        else { rv += 2; ev.add("ADX ${rep.adx.toInt()} 弱（趋势动能衰竭）") }
        val hist = rep.macdHist
        if (hist != null) {
            val histRight = if (long) hist > 0 else hist < 0
            if (histRight) { pb += 2; ev.add("MACD 动能未换向（仅减速）") }
            else { rv += 3; ev.add("MACD 动能已换向") }
        }

        // ④ 动能证据：RSI 极值
        rep.rsi14?.let { r ->
            if (long && r > 45 && r < 70) { pb += 1; ev.add("RSI ${r.toInt()} 未超卖（回调正常）") }
            else if (long && r < 35) { rv += 2; ev.add("RSI ${r.toInt()} 超卖（破位风险）") }
            if (!long && r < 55 && r > 30) { pb += 1; ev.add("RSI ${r.toInt()} 未超买（回调正常）") }
            else if (!long && r > 65) { rv += 2; ev.add("RSI ${r.toInt()} 超买（破位风险）") }
        }

        // ⑤ 结构位证据：反转确认线是否被破
        val reversalLine = if (long) rep.swingLow ?: rep.support else rep.swingHigh ?: rep.resistance
        val reversalLabel = if (long) "前低/支撑" else "前高/压力"
        if (reversalLine != null && reversalLine > 0) {
            val broken = if (long) price < reversalLine else price > reversalLine
            if (broken) { rv += 3; ev.add("已跌破 $reversalLabel（结构破位）") }
            else { pb += 1; ev.add("$reversalLabel 完好（结构未破）") }
        }

        // 时间衰减：回撤太久不恢复，回踩概率下降（确认窗口已过 2× 仍未创新高）
        if (confirm != null && confirm.barsElapsed > confirm.windowBars * 1.5 && confirm.progressAtr < confirm.thresholdAtr) {
            rv += 1; ev.add("回调时间过长（>${fmt(confirm.barsElapsed)} 根，未恢复）")
        }

        val total = pb + rv
        val pbPct = if (total == 0) 50 else pb * 100 / total
        // 置信度 = 占优一方的得分占比（回踩强→回踩置信度；反转强→反转置信度）
        val confidence = if (total == 0) 50 else (maxOf(pb, rv) * 100 / total).coerceIn(5, 95)
        val status = when {
            pbPct >= 70 -> "回踩"
            pbPct <= 30 -> "反转"
            else -> "分歧"
        }
        val watchLine = ema20
        return PullbackVerdict(status, confidence, ev, watchLine, "EMA20 回踩线", reversalLine, reversalLabel, depth)
    }

    private fun fmt(d: Double) = String.format(java.util.Locale.US, "%.1f", d)
}

/**
 * 机会/持仓生命线：五段式阶段 + 关键位推演卡。
 * 确认时刻 = 生命线 0 点（Confirmation.resolvedAt / startedAt）。
 */
data class Lifecycle(
    val phase: String,      // 持有·趋势健康 / 持有·回调观察 / 减仓·趋势衰竭 / 离场·目标达成 / 离场·反转失效 / 观察·未确认
    val phaseColor: String, // GOOD/WARN/BAD
    val verdict: PullbackVerdict?,
    val lines: List<String> // 推演卡：延续目标/衰竭线/反转线 + 当前距离
)

object LifecycleEngine {

    /** @param entry 机会入场价（未持仓=信号价；持仓=持仓入场价），target/stop 可为 0 表示未知 */
    fun evaluate(
        direction: String, entry: Double, stop: Double, target: Double,
        price: Double, rep: Analysis, confirm: Confirmation? = null,
        isPosition: Boolean = false
    ): Lifecycle {
        val atr = rep.atr.takeIf { it > 0 } ?: (price * 0.01)
        val long = direction == "LONG"
        val sign = if (long) 1.0 else -1.0
        val movedAtr = (price - entry) * sign / atr

        // 反向波动 = 相对入场最高有利点的回撤（未持仓时用信号价做锚）
        val peak = if (long) maxOf(entry, price, rep.swingHigh ?: entry) else minOf(entry, price, rep.swingLow ?: entry)
        val reverseAtr = (peak - price) * sign / atr
        val verdict = PullbackReversalJudge.judge(direction, price, entry, rep, reverseAtr, confirm)

        // 延续目标：最近推动波段 1.618× 延伸 ∪ 记账止盈
        val pushLow = rep.swingLow ?: entry
        val pushHigh = rep.swingHigh ?: entry
        val ext = if (long) pushHigh + (pushHigh - pushLow) * 0.618 else pushLow - (pushHigh - pushLow) * 0.618
        val goal = if (target > 0 && isPosition) {
            if (long) maxOf(ext, target) else minOf(ext, target)
        } else ext
        val fatigue = rep.ema20 ?: entry // 衰竭预警线 = EMA20
        val reversal = verdict.reversalLine

        val dGoal = (goal - price) * sign / price * 100
        val dFat = (fatigue - price) * sign / price * 100
        val dRev = reversal?.let { (it - price) * sign / price * 100 }

        val lines = mutableListOf<String>()
        lines.add("延续目标区 ${fmt(goal)}（距 ${fmt(dGoal)}%）")
        lines.add("衰竭预警线 ${fmt(fatigue)}（${if (long) "跌破" else "升破"}距 ${fmt(dFat)}% · 延续逻辑失效）")
        if (reversal != null) lines.add("反转确认线 ${fmt(reversal)}（收盘${if (long) "破" else "破"}位=反转${dRev?.let { "，距 ${fmt(it)}%" } ?: ""}）")

        val phase: String
        val color: String
        when {
            verdict.status == "反转" && verdict.confidence >= 70 -> { phase = if (isPosition) "离场·反转失效" else "观察·反转风险"; color = "BAD" }
            movedAtr > 0 && target > 0 && ((long && price >= target * 0.98) || (!long && price <= target * 0.98)) -> { phase = "离场·目标达成"; color = "GOOD" }
            verdict.status == "分歧" || reverseAtr > 1.5 -> { phase = if (isPosition) "持有·回调观察" else "观察·回调等待"; color = "WARN" }
            rep.adx < 20 && (rep.macdHist?.let { if (long) it < 0 else it > 0 } == true) -> { phase = "减仓·趋势衰竭"; color = "WARN" }
            else -> { phase = if (isPosition) "持有·趋势健康" else "观察·机会持续"; color = "GOOD" }
        }
        return Lifecycle(phase, color, verdict, lines)
    }

    /** 持仓紧迫度排序：反转失效 > 衰竭/回调 > 达成 > 健康 */
    fun urgency(l: Lifecycle): Int = when (l.phase) {
        "离场·反转失效" -> 0
        "减仓·趋势衰竭" -> 1
        "持有·回调观察" -> 2
        "离场·目标达成" -> 3
        else -> 4
    }

    private fun fmt(d: Double): String =
        String.format(java.util.Locale.US, if (abs(d) >= 100) "%.1f" else "%.2f", d)
}
