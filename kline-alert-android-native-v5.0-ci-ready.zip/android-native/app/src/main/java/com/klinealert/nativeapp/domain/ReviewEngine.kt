package com.klinealert.nativeapp.domain

import org.json.JSONObject

/** Local-only outcome tracking ported from src/engine/review.ts. */
data class ReviewRecord(
    val id: String,
    val symbol: String,
    val market: String,
    val timeframe: String,
    val direction: String,
    val entry: Double,
    val stop: Double,
    val target: Double,
    val score: Int,
    val alertedAt: Long,
    val verdict: String = "open",
    val verdictAt: Long = 0L,
    val hitPrice: Double = 0.0,
    val barsUsed: Int = 0,
    /** 触发模式与关键指标快照（JSON），供模式级胜率学习。 */
    val features: String = "",
    /** v4.2 回踩确认落库：待命单进入 ARMED 的时刻（0=未经历待命单路径） */
    val armedAt: Long = 0L,
    /** v4.2 回踩确认落库：是否经过「等回踩确认」才入场（false=直接触发/未走待命单） */
    val pullbackConfirmed: Boolean = false,
    /** v4.2 回踩确认落库：从 ARMED 到确认入场的耗时（毫秒），用于评估回踩窗口是否合理 */
    val pullbackMs: Long = 0L,
    /** v4.2 证据分快照（结算时用于分数段胜率校准） */
    val evidenceScore: Int = 0
)

data class ReviewOutcome(val verdict: String, val hitPrice: Double, val barsUsed: Int)

object ReviewEngine {
    /**
     * 到期顺延：结算只由价格事件驱动（盘中触及止盈/止损立即判生死），周期结束不强行判输赢。
     * 记录最长跟踪 7 天（168h，原 72h「周期到期一刀切」已改为顺延观察）；
     * 超期仍未触发 → 结算为 neutral「中性退出」，胜率统计只算 hit/miss，中性样本不进分母。
     */
    const val DEFAULT_MAX_AGE_HOURS = 168L

    fun create(a: Analysis, nowMillis: Long = System.currentTimeMillis()): ReviewRecord {
        // Anchor both identity and lifecycle to the analyzed closed candle. Repeated callbacks
        // for the same signal candle therefore upsert one record instead of duplicating feedback.
        val signalTime = a.candleTime.takeIf { it > 0L } ?: nowMillis
        val id = "${a.market}|${a.symbol}|${a.timeframe}|${a.direction}|$signalTime"
        // Hand-built JSON: org.json is unavailable in plain JVM unit tests.
        val patternsJson = a.patterns.joinToString(",") { "\"${it.replace("\"", "'")}\"" }
        val rsiStr = a.rsi14?.let { String.format(java.util.Locale.US, "%.2f", it) } ?: "null"
        val features = "{\"patterns\":[$patternsJson],\"rsi\":$rsiStr," +
            "\"adx\":${a.adx},\"atrPct\":${a.atrPct},\"regime\":\"${a.regime}\"," +
            "\"score\":${a.score},\"confidence\":${a.confidence}}"
        return ReviewRecord(id, a.symbol, a.market, a.timeframe, a.direction, a.entry, a.stop, a.target, a.score, signalTime, features = features)
    }

    /** The same candle touching stop and target is conservatively classified as a miss. */
    fun touch(candlesAfterAlert: List<Candle>, record: ReviewRecord): ReviewOutcome {
        candlesAfterAlert.forEachIndexed { index, candle ->
            val hit = if (record.direction == "LONG") candle.high >= record.target else candle.low <= record.target
            val miss = if (record.direction == "LONG") candle.low <= record.stop else candle.high >= record.stop
            if (hit && miss) return ReviewOutcome("miss", record.stop, index + 1)
            if (hit) return ReviewOutcome("hit", record.target, index + 1)
            if (miss) return ReviewOutcome("miss", record.stop, index + 1)
        }
        return ReviewOutcome("open", 0.0, candlesAfterAlert.size)
    }

    fun expire(record: ReviewRecord, nowMillis: Long = System.currentTimeMillis(), maxAgeHours: Long = DEFAULT_MAX_AGE_HOURS): ReviewRecord {
        if (record.verdict != "open" || nowMillis - record.alertedAt <= maxAgeHours * 3_600_000L) return record
        return record.copy(verdict = "neutral", verdictAt = nowMillis)
    }

    /**
     * 智能失效（v3.7）：结构性死亡提前结案，不等到止损。
     * 条件：确认状态机「未确认」（假启动）且反向走出 ≥1.2×ATR → 行情性质已变。
     * invalid 为负样本，学习/胜率统计中按半权重 miss 计。
     */
    fun smartInvalidate(record: ReviewRecord, confirm: Confirmation?, nowMillis: Long = System.currentTimeMillis()): ReviewRecord {
        if (record.verdict != "open" || confirm == null) return record
        if (confirm.status == "未确认" && confirm.reverseMaxAtr >= 1.2)
            return record.copy(verdict = "invalid", verdictAt = nowMillis, hitPrice = confirm.resolvedPrice)
        return record
    }

    fun settle(record: ReviewRecord, outcome: ReviewOutcome, nowMillis: Long = System.currentTimeMillis()): ReviewRecord =
        if (record.verdict != "open" || outcome.verdict == "open") record
        else record.copy(verdict = outcome.verdict, verdictAt = nowMillis, hitPrice = outcome.hitPrice, barsUsed = outcome.barsUsed)
}
