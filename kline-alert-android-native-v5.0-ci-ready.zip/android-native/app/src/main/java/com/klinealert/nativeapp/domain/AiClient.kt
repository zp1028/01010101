package com.klinealert.nativeapp.domain

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * AI 大模型客户端（OpenAI 兼容协议）。
 *
 * 支持 DeepSeek / 通义千问 / Kimi / OpenAI / 本地 Ollama 等任何兼容端点：
 *  - listModels：GET {baseUrl}/models  获取可用模型列表（"获取模型"按钮）
 *  - test：一次最小对话验证连通性与鉴权（"确定链接"按钮）
 *  - chat：POST {baseUrl}/chat/completions
 *
 * API Key 只存本地 SharedPreferences，请求直连用户填写的端点，不经过任何第三方。
 */
object AiClient {

    data class Config(val baseUrl: String, val apiKey: String, val model: String) {
        val configured: Boolean get() = baseUrl.isNotBlank() && apiKey.isNotBlank() && model.isNotBlank()
        fun trimmed(): Config = copy(
            baseUrl = baseUrl.trim().trimEnd('/'),
            apiKey = apiKey.trim(),
            model = model.trim()
        )
    }

    val defaultConfig = Config("https://api.deepseek.com/v1", "", "deepseek-chat")

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val jsonType = "application/json; charset=utf-8".toMediaType()

    private fun auth(key: String) = "Bearer $key"

    /** 获取模型列表 */
    suspend fun listModels(cfg: Config): Result<List<String>> = withContext(Dispatchers.IO) {
        runCatching {
            val c = cfg.trimmed()
            require(c.baseUrl.isNotBlank() && c.apiKey.isNotBlank()) { "请先填写大模型链接与密钥" }
            val req = Request.Builder().url("${c.baseUrl}/models")
                .header("Authorization", auth(c.apiKey)).get().build()
            client.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                require(resp.isSuccessful) { "HTTP ${resp.code}：${body.take(180)}" }
                val arr = JSONObject(body).optJSONArray("data") ?: JSONArray()
                (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.optString("id")?.takeIf { id -> id.isNotBlank() } }
            }
        }.recoverCatching { e -> throw IllegalStateException(e.message ?: "获取模型失败", e) }
    }

    /** 连接测试：一次最小对话 */
    suspend fun test(cfg: Config): Result<String> = chat(cfg, "你是连通性测试助手。直接给出答案，不要长篇思考。", "只回复：连接正常", maxTokens = 512)

    /** 对话补全 */
    suspend fun chat(cfg: Config, system: String, user: String, maxTokens: Int = 1200, temperature: Double = 0.4): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                val c = cfg.trimmed()
                require(c.configured) { "AI 未配置完整（链接/密钥/模型）" }
                val payload = JSONObject().apply {
                    put("model", c.model)
                    put("temperature", temperature)
                    put("max_tokens", maxTokens)
                    put("messages", JSONArray()
                        .put(JSONObject().put("role", "system").put("content", system))
                        .put(JSONObject().put("role", "user").put("content", user)))
                }
                val req = Request.Builder().url("${c.baseUrl}/chat/completions")
                    .header("Authorization", auth(c.apiKey))
                    .post(payload.toString().toRequestBody(jsonType))
                    .build()
                client.newCall(req).execute().use { resp ->
                    val body = resp.body?.string().orEmpty()
                    require(resp.isSuccessful) { "HTTP ${resp.code}：${body.take(200)}" }
                    val msg = JSONObject(body).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")
                        ?: throw IllegalStateException("响应结构异常：${body.take(160)}")
                    val content = msg.optString("content").trim()
                    if (content.isNotBlank()) return@use content
                    // 推理模型兼容：正文在 reasoning_content（思考过程）里
                    val reasoning = msg.optString("reasoning_content").trim()
                    if (reasoning.isNotBlank()) return@use reasoning
                    throw IllegalStateException("模型未返回正文（疑似推理模型思考超限），请换非推理模型或稍后重试：${body.take(160)}")
                }
            }.recoverCatching { e ->
                throw IllegalStateException(
                    when {
                        e.message?.contains("401") == true -> "鉴权失败：密钥无效（401）"
                        e.message?.contains("404") == true -> "链接或模型不存在（404）：检查链接是否含 /v1、模型名是否正确"
                        e.message?.contains("429") == true -> "调用过于频繁或额度不足（429）"
                        else -> e.message ?: "AI 请求失败"
                    }, e)
            }
        }
}
