package com.klinealert.nativeapp.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** 机会三态（Phase Gate）测试：触发/观察判定与确认型触发。 */
class PhaseGateTest {

    private fun sop(price: Double, direction: String, entry: Double, atr: Double): SymbolOpportunity {
        val a = Analysis(
            symbol = "TESTUSDT", market = "SPOT", timeframe = "15m", price = price, changePct = 0.0,
            rsi14 = null, ema20 = null, ema50 = null, direction = direction, score = 70, confidence = 70,
            reason = "", candleTime = 0L, entry = entry, atr = atr
        )
        return SymbolOpportunity(
            symbol = "TESTUSDT", market = "SPOT", direction = direction, score = 70, confidence = 70,
            price = price, changePct = 0.0, perTimeframe = mapOf("15m" to a), rep = a,
            resonanceCount = 0, oppositeCount = 0
        )
    }

    @Test
    fun `做多 价格回到入场区即触发`() {
        // entry=100，ATR=1 → 容差 0.3；价格 100.2 ≤ 100.3 → 触发
        val ph = PhaseGate.evaluate(sop(100.2, "LONG", entry = 100.0, atr = 1.0), 100.2)
        assertEquals(PhaseGate.TRIGGERED, ph.phase)
        assertEquals("回调至入场区", ph.reason)
    }

    @Test
    fun `做多 价格远离入场区为观察态且显示距离`() {
        val ph = PhaseGate.evaluate(sop(105.0, "LONG", entry = 100.0, atr = 1.0), 105.0)
        assertEquals(PhaseGate.WATCHING, ph.phase)
        assertTrue(ph.distPct > 4.0)
        assertEquals("等回踩入场区", ph.reason)
    }

    @Test
    fun `做空 镜像判定`() {
        // SHORT：入场区 entry=100，容差 0.3；价格 99.8 ≥ 99.7 → 触发（反抽到位）
        assertEquals(PhaseGate.TRIGGERED, PhaseGate.evaluate(sop(99.8, "SHORT", entry = 100.0, atr = 1.0), 99.8).phase)
        // 价格 105 远在上方 → 观察
        val ph = PhaseGate.evaluate(sop(105.0, "SHORT", entry = 100.0, atr = 1.0), 105.0)
        assertEquals(PhaseGate.WATCHING, ph.phase)
        assertEquals("等反抽入场区", ph.reason)
    }

    @Test
    fun `确认状态机已确认则直接触发（顺势确认型）`() {
        val c = Confirmation(
            key = "SPOT|TESTUSDT|LONG", symbol = "TESTUSDT", market = "SPOT", direction = "LONG",
            repTimeframe = "15m", entryPrice = 100.0, atr = 1.0, windowBars = 4, thresholdAtr = 0.5,
            startedAt = 0L, startCandleTime = 0L, status = "已确认", progressAtr = 0.8
        )
        val ph = PhaseGate.evaluate(sop(105.0, "LONG", entry = 100.0, atr = 1.0), 105.0, c)
        assertEquals(PhaseGate.TRIGGERED, ph.phase)
    }

    @Test
    fun `无实时价回退用机会价判定`() {
        val ph = PhaseGate.evaluate(sop(105.0, "LONG", entry = 100.0, atr = 1.0), null)
        assertEquals(PhaseGate.WATCHING, ph.phase)
    }
}
