package com.klinealert.nativeapp.domain

import org.junit.Assert.assertEquals
import org.junit.Test

class VolAdaptiveConfirmationTest {

    private fun sop(price: Double, atrVal: Double = 10.0, vol: Double = 1.0): SymbolOpportunity {
        val a = Analysis("BTCUSDT", "SPOT", "15m", price, 0.0, null, null, null, "LONG", 80,
            "test", System.currentTimeMillis(), atr = atrVal, atrPct = 1.0, confidence = 75, volExpansion = vol)
        return SymbolOpportunity("BTCUSDT", "SPOT", "LONG", 80, 75, price, 0.0,
            mapOf("15m" to a), a, 1, 0, grade = "A")
    }

    @Test fun highVolatilitySoftObserveInsteadOfFail() {
        val now = System.currentTimeMillis()
        // V=1.5 → failThr = 0.5×1.6 = 0.8×ATR；反向 0.6×ATR 在放宽阈值内不应触发任何失效
        val c = ConfirmationGate.start(sop(100.0, 10.0, vol = 1.5), now)!!
        val nc = ConfirmationGate.onTick(c, 94.0, now) // 反向 0.6×ATR（旧规则会直接判死）
        assertEquals("待确认", nc.status)
        // 反向 0.85×ATR（≥0.8 放宽阈值）→ 进入波动观察而非直接判死
        val nc2 = ConfirmationGate.onTick(c, 91.5, now)
        assertEquals("波动观察", nc2.status)
    }

    @Test fun normalVolatilityFailsAtHalfAtr() {
        val now = System.currentTimeMillis()
        val c = ConfirmationGate.start(sop(100.0, 10.0, vol = 1.0), now)!!
        val nc = ConfirmationGate.onTick(c, 94.5, now) // 反向 0.55×ATR
        assertEquals("未确认", nc.status)
    }

    @Test fun volObserveRecoversOnRebound() {
        val now = System.currentTimeMillis()
        val c = ConfirmationGate.start(sop(100.0, 10.0, vol = 1.5), now)!!
        val observed = ConfirmationGate.onTick(c, 91.5, now)  // 波动观察
        val recovered = ConfirmationGate.onTick(observed, 108.5, now) // 反弹走出 0.85×ATR → 确认
        assertEquals("已确认", recovered.status)
    }
}
