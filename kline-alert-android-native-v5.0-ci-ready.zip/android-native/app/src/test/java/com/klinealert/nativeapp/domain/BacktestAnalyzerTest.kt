package com.klinealert.nativeapp.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** v4.4 回测校准分析器：分段胜率 / 回踩对比 / 样本外验证。 */
class BacktestAnalyzerTest {

    private var seq = 0L
    private fun rec(
        verdict: String, evidence: Int = 0, pullback: Boolean = false, at: Long = ++seq * 1000L
    ) = ReviewRecord(
        id = "id$at", symbol = "BTCUSDT", market = "SPOT", timeframe = "15m", direction = "LONG",
        entry = 100.0, stop = 96.0, target = 112.0, score = 70, alertedAt = at,
        verdict = verdict, evidenceScore = evidence, pullbackConfirmed = pullback
    )

    // ── 分段胜率
    @Test fun `样本不足时返回null`() {
        assertNull(BacktestAnalyzer.scoreBands(List(10) { rec("hit", 90) }))
    }

    @Test fun `证据分段统计正确`() {
        val rows = mutableListOf<ReviewRecord>()
        repeat(20) { rows += rec("hit", 90) }     // ≥85 全胜
        repeat(20) { rows += rec("miss", 90) }    // ≥85 与上方合并
        repeat(20) { rows += rec("miss", 65) }    // 60-69 全负
        val r = BacktestAnalyzer.scoreBands(rows)!!
        val high = r.bands.first { it.label == "≥85" }
        assertEquals(40, high.samples)
        assertEquals(0.5, high.rate, 1e-9)
        val mid = r.bands.first { it.label == "60-69" }
        assertEquals(0.0, mid.rate, 1e-9)
    }

    @Test fun `建议阈值取可靠分桶中胜率最高段`() {
        val rows = mutableListOf<ReviewRecord>()
        repeat(20) { rows += rec("hit", 90) }    // ≥85 胜率 100%
        repeat(20) { rows += rec("miss", 65) }   // 60-69 胜率 0%
        val r = BacktestAnalyzer.scoreBands(rows)!!
        assertEquals(85, r.suggestedThreshold)
    }

    // ── 回踩对比
    @Test fun `回踩组胜率更高时判为更优`() {
        val rows = mutableListOf<ReviewRecord>()
        repeat(20) { rows += rec("hit", pullback = true) }    // 回踩 100% 胜
        repeat(20) { rows += rec("miss", pullback = false) }  // 直接 0% 胜
        val r = BacktestAnalyzer.pullbackCompare(rows)!!
        assertTrue(r.pullbackBetter)
        assertTrue(r.pullback.rate > r.direct.rate)
    }

    @Test fun `回踩组样本不足不作为结论`() {
        val rows = mutableListOf<ReviewRecord>()
        repeat(40) { rows += rec("hit", pullback = false) }   // 直接组样本足
        repeat(3) { rows += rec("hit", pullback = true) }     // 回踩组样本不足
        val r = BacktestAnalyzer.pullbackCompare(rows)!!
        assertFalse(r.pullback.reliable)
        assertFalse(r.pullbackBetter)   // 不因小样本断言更优
    }

    // ── 样本外验证
    @Test fun `训练验证胜率跌幅大判为过拟合`() {
        val rows = mutableListOf<ReviewRecord>()
        repeat(28) { rows += rec("hit", at = it + 1L) }        // 前 70% 全胜
        repeat(12) { rows += rec("miss", at = it + 1000L) }    // 后 30% 全负
        val r = BacktestAnalyzer.walkForward(rows)!!
        assertTrue(r.trainRate > r.testRate)
        assertTrue(r.overfit)
    }

    @Test fun `训练验证一致时不判过拟合`() {
        val rows = mutableListOf<ReviewRecord>()
        repeat(40) { rows += rec(if (it % 2 == 0) "hit" else "miss", at = it + 1L) }
        val r = BacktestAnalyzer.walkForward(rows)!!
        assertFalse(r.overfit)
    }

    // ── invalid 半权重
    @Test fun `invalid 按半权重 miss 计入分母`() {
        val rows = mutableListOf<ReviewRecord>()
        repeat(20) { rows += rec("hit", 90) }
        repeat(20) { rows += rec("invalid", 90) }   // 半权重 → 分母 20+10=30，胜率 20/30
        val r = BacktestAnalyzer.scoreBands(rows)!!
        val high = r.bands.first { it.label == "≥85" }
        assertEquals(30, high.samples)
        assertEquals(20.0 / 30.0, high.rate, 1e-9)
    }

    // ── 综合
    @Test fun `综合报告在样本足够时给出全部三段`() {
        val rows = mutableListOf<ReviewRecord>()
        repeat(60) { rows += rec(if (it < 40) "hit" else "miss", 90, pullback = it % 2 == 0, at = it + 1L) }
        val rep = BacktestAnalyzer.analyze(rows)
        assertNotNull(rep.scoreBands)
        assertNotNull(rep.walkForward)
        assertEquals(60, rep.totalSettled)
    }

    @Test fun `空样本给出积累提示`() {
        val rep = BacktestAnalyzer.analyze(emptyList())
        assertEquals(0, rep.totalSettled)
        assertNull(rep.scoreBands)
        assertTrue(rep.note.contains("暂无结算样本"))
    }
}
