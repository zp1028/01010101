package com.klinealert.nativeapp.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PositionEngineTest {
    private fun pos(direction: String = "LONG") = PositionInput(
        id = "p1", symbol = "BTCUSDT", market = "SPOT", direction = direction,
        entry = 100.0, leverage = 3.0, size = 1.0,
        stop = if (direction == "LONG") 98.0 else 102.0,
        target = if (direction == "LONG") 110.0 else 90.0
    )

    @Test fun favorablePrimaryTrendScoresContinuation() {
        val result = PositionEngine.assess(pos(), listOf(
            TimeframeContext("1h", 104.0, "bull", "uptrend", "上涨延续", 80.0, 2.0),
            TimeframeContext("4h", 104.0, "bull", "uptrend", "上涨延续", 75.0, 2.0),
            TimeframeContext("15m", 104.0, "bull", "uptrend", "上涨延续", 70.0, 2.0)
        ))
        assertNotNull(result)
        assertEquals("continuation", result!!.status)
        assertEquals(4.0, result.pnlPct, 0.001)
        assertEquals(12.0, result.leveragedPnlPct, 0.001)
    }

    @Test fun opposingPrimaryTrendRaisesReversalRisk() {
        val result = PositionEngine.assess(pos(), listOf(
            TimeframeContext("1h", 99.0, "bear", "downtrend", "下跌延续", 85.0, 6.0),
            TimeframeContext("4h", 99.0, "bear", "downtrend", "下跌延续", 80.0, 6.0),
            TimeframeContext("15m", 99.0, "bear", "downtrend", "下跌延续", 80.0, 6.0)
        ))
        assertNotNull(result)
        assertEquals("reversal", result!!.status)
        assertTrue(result.riskFlags.isNotEmpty())
    }

    @Test fun directionalMoveUsesOppositeSignForShortPositions() {
        assertEquals(5.0, PositionEngine.directionalMovePct(100.0, 105.0, "LONG"), 0.001)
        assertEquals(-5.0, PositionEngine.directionalMovePct(100.0, 105.0, "SHORT"), 0.001)
        assertEquals(5.0, PositionEngine.directionalMovePct(100.0, 95.0, "SHORT"), 0.001)
    }

    @Test fun invalidReferenceEntryDoesNotProduceInfiniteMove() {
        assertEquals(0.0, PositionEngine.directionalMovePct(0.0, 105.0, "LONG"), 0.0)
    }

    @Test fun emptyContextReturnsNull() {
        assertEquals(null, PositionEngine.assess(pos(), emptyList()))
    }
}
