package com.klinealert.nativeapp.data

import com.klinealert.nativeapp.domain.PendingSetup
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** v4.3 交易所交叉校验：符号转换 + 一致性判定 + 跃迁拦截决策（纯逻辑，不依赖网络）。 */
class CrossCheckTest {

    private fun source(vararg pairs: Pair<String, Double>): CrossCheckSource =
        CrossCheckSource().also { it.injectForTest(mapOf(*pairs)) }

    private fun setup(
        status: String = PendingSetup.PENDING,
        direction: String = "LONG",
        trigger: Double = 100.0,
        atr: Double = 1.0
    ) = PendingSetup(
        key = "SPOT|BTCUSDT|$direction", symbol = "BTCUSDT", market = "SPOT",
        direction = direction, timeframe = "15m", triggerPrice = trigger, invalidPrice = 96.0,
        stop = 96.0, target3R = 112.0, atr = atr, score = 70, evidenceScore = 80,
        gatePosition = true, gateSignal = true, gateTime = true, missingGate = "",
        createdAt = 0L, triggerWindowMs = 3_600_000L, expireAt = Long.MAX_VALUE, status = status
    )

    @Test fun `符号转换 USDT`() {
        assertEquals("BTC_USDT", CrossCheckSource().toGatePair("BTCUSDT"))
        assertEquals("ETH_USDT", CrossCheckSource().toGatePair("ethusdt"))
    }

    @Test fun `符号转换 已带下划线原样`() {
        assertEquals("BTC_USDT", CrossCheckSource().toGatePair("BTC_USDT"))
    }

    @Test fun `成交价一致判定为true`() {
        val s = source("BTCUSDT" to 100.0)
        assertEquals(true, s.isConsistent("BTCUSDT", 100.3))  // 偏差 0.3% < 0.8%
    }

    @Test fun `偏差过大判定为false`() {
        val s = source("BTCUSDT" to 100.0)
        assertEquals(false, s.isConsistent("BTCUSDT", 105.0))  // 偏差 5% > 0.8%
    }

    @Test fun `无参考数据返回null不判定`() {
        val s = source("ETHUSDT" to 50.0)
        assertNull(s.isConsistent("BTCUSDT", 100.0))
    }

    @Test fun `未加载参考价时不拦截`() {
        val s = CrossCheckSource()  // 未注入
        assertFalse(s.available())
        assertFalse(s.shouldBlock(setup(), 99.0))  // 无数据 → 放行
    }

    @Test fun `待命单到价且一致不拦截`() {
        val s = source("BTCUSDT" to 100.0)
        // 触发价 100，现价 99.9 会跃迁，且与参考价一致 → 不拦截
        assertFalse(s.shouldBlock(setup(), 99.9))
    }

    @Test fun `待命单到价但偏差过大拦截`() {
        val s = source("BTCUSDT" to 100.0)
        // 现价 97 会跃迁（<=触发价 100），但相对参考价 100 偏差 3% → 拦截（疑似插针）
        assertTrue(s.shouldBlock(setup(), 97.0))
    }

    @Test fun `不会跃迁的tick不拦截`() {
        val s = source("BTCUSDT" to 100.0)
        // LONG 触发价 100，现价 105 远未到价 → 即使偏差大也不拦截（不影响未跃迁的 tick）
        assertFalse(s.shouldBlock(setup(), 110.0))
    }

    @Test fun `ARMED 回踩确认时偏差过大拦截`() {
        // 参考价 95，触发价 100：现价 100 落在回踩容差内（会跃迁），但相对参考价偏差 5% → 拦截
        val s = source("BTCUSDT" to 95.0)
        assertTrue(s.shouldBlock(setup(status = PendingSetup.ARMED), 100.0))
    }

    @Test fun `做空到价且一致不拦截`() {
        val s = source("BTCUSDT" to 100.0)
        // SHORT 触发价 100，现价 100.1 会跃迁，偏差 0.1% → 不拦截
        assertFalse(s.shouldBlock(setup(direction = "SHORT"), 100.1))
    }
}
