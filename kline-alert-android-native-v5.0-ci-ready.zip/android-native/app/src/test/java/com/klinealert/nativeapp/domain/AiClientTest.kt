package com.klinealert.nativeapp.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AiClientTest {

    @Test fun configTrimRemovesTrailingSlash() {
        val c = AiClient.Config("https://api.deepseek.com/v1///", "  sk-abc ", " deepseek-chat ").trimmed()
        assertEquals("https://api.deepseek.com/v1", c.baseUrl)
        assertEquals("sk-abc", c.apiKey)
        assertEquals("deepseek-chat", c.model)
    }

    @Test fun unconfiguredWhenFieldsBlank() {
        assertFalse(AiClient.Config("https://x", "", "m").configured)
        assertFalse(AiClient.Config("", "k", "m").configured)
        assertFalse(AiClient.Config("https://x", "k", "").configured)
        assertTrue(AiClient.Config("https://x", "k", "m").configured)
    }
}
