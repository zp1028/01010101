package com.klinealert.nativeapp.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ConfirmationGateTest {

    private fun sop(price: Double, atrVal: Double = 10.0, tf: String = "15m", dir: String = "LONG", candleTime: Long = System.currentTimeMillis()): SymbolOpportunity {
        val a = Analysis("BTCUSDT", "SPOT", tf, price, 0.0, null, null, null, dir, 80,
            "test", candleTime, atr = atrVal, atrPct = 1.0, confidence = 75)
        return SymbolOpportunity("BTCUSDT", "SPOT", dir, 80, 75, price, 0.0,
            mapOf(tf to a), a, 1, 0, grade = "A")
    }

    @Test fun startRequiresAtr() {
        val c = ConfirmationGate.start(sop(100.0, atrVal = 0.0))
        assertTrue(c == null)
        assertNotNull(ConfirmationGate.start(sop(100.0)))
    }

    @Test fun fastConfirmWhenMoveExceedsThreshold() {
        val now = System.currentTimeMillis()
        val c = ConfirmationGate.start(sop(100.0, atrVal = 10.0), now)!! // 阈值 0.5×ATR = 5
        val nc = ConfirmationGate.onTick(c, 106.0, now)
        assertEquals("已确认", nc.status)
    }

    @Test fun retestConfirmAfterSmallReverse() {
        val now = System.currentTimeMillis()
        val c = ConfirmationGate.start(sop(100.0, atrVal = 10.0), now)!!
        val after = ConfirmationGate.onTick(c, 97.0, now)   // 反向 0.3×ATR
        val done = ConfirmationGate.onTick(after, 106.0, now)
        assertEquals("回踩确认", done.status)
    }

    @Test fun failOnReverseHalfAtr() {
        val now = System.currentTimeMillis()
        val c = ConfirmationGate.start(sop(100.0, atrVal = 10.0, dir = "SHORT"), now)!!
        // SHORT：价格涨 5.1 → 反向 0.51×ATR
        val nc = ConfirmationGate.onTick(c, 105.2, now)
        assertEquals("未确认", nc.status)
    }

    @Test fun slowWindowExpiresToUnconfirmed() {
        val now = System.currentTimeMillis()
        val start = now - 5 * 15 * 60_000L // 已过 5 根 15m（窗口 4 根）
        val c = ConfirmationGate.start(sop(100.0, atrVal = 10.0, candleTime = start), start)!!.let {
            ConfirmationGate.onTick(it, 101.0, now) // 只走 0.1×ATR
        }
        assertEquals("未确认", c.status)
    }

    @Test fun extendedWindowKeepsPending() {
        val now = System.currentTimeMillis()
        val start = now - 4 * 15 * 60_000L // 恰好窗口到期
        val c = ConfirmationGate.start(sop(100.0, atrVal = 10.0, candleTime = start), start)!!.let {
            ConfirmationGate.onTick(it, 103.5, now) // 0.35×ATR → 延候
        }
        assertEquals("延候确认", c.status)
        assertFalse(c.resolved)
        // 延候期内达标 → 已确认
        val done = ConfirmationGate.onTick(c, 106.0, now)
        assertEquals("已确认", done.status)
    }
}
