package com.klinealert.nativeapp.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class ReviewEngineTest {
    private fun record(direction: String = "LONG") = ReviewRecord(
        id = "test", symbol = "BTCUSDT", market = "SPOT", timeframe = "15m", direction = direction,
        entry = 100.0, stop = if (direction == "LONG") 95.0 else 105.0,
        target = if (direction == "LONG") 110.0 else 90.0, score = 75, alertedAt = 1_000L
    )

    @Test fun targetTouchIsHitForLongAndShort() {
        val long = ReviewEngine.touch(listOf(Candle(1, 100.0, 111.0, 99.0, 108.0, 1.0, 2)), record())
        val short = ReviewEngine.touch(listOf(Candle(1, 100.0, 101.0, 89.0, 92.0, 1.0, 2)), record("SHORT"))
        assertEquals("hit", long.verdict)
        assertEquals("hit", short.verdict)
    }

    @Test fun sameCandleTouchingStopAndTargetIsConservativeMiss() {
        val outcome = ReviewEngine.touch(listOf(Candle(1, 100.0, 111.0, 94.0, 100.0, 1.0, 2)), record())
        assertEquals("miss", outcome.verdict)
        assertEquals(95.0, outcome.hitPrice, 0.0)
    }

    @Test fun newReviewUsesAnalyzedCandleTimeAsItsAnchor() {
        val analysis = Analysis(
            symbol = "BTCUSDT", market = "SPOT", timeframe = "15m", price = 100.0,
            changePct = 0.0, rsi14 = 50.0, ema20 = 99.0, ema50 = 98.0,
            direction = "LONG", score = 70, reason = "test", candleTime = 12345L,
            stop = 95.0, target = 110.0
        )
        assertEquals(12345L, ReviewEngine.create(analysis, nowMillis = 99999L).alertedAt)
    }

    @Test fun repeatedCallbackForSameSignalCandleHasStableReviewId() {
        val analysis = Analysis(
            symbol = "BTCUSDT", market = "SPOT", timeframe = "15m", price = 100.0,
            changePct = 0.0, rsi14 = 50.0, ema20 = 99.0, ema50 = 98.0,
            direction = "LONG", score = 70, reason = "test", candleTime = 12345L,
            stop = 95.0, target = 110.0
        )
        val first = ReviewEngine.create(analysis, nowMillis = 99999L)
        val repeated = ReviewEngine.create(analysis, nowMillis = 199999L)
        assertEquals(first.id, repeated.id)
    }

    @Test fun staleOpenReviewExpiresWithoutMarketRequest() {
        val original = record()
        // v3.6：到期顺延（72h→168h），超期仍未触发才结算为中性退出（不计入胜率分母）
        val stillOpen = ReviewEngine.expire(original, nowMillis = 1_000L + 73L * 3_600_000L)
        assertEquals("open", stillOpen.verdict)
        val expired = ReviewEngine.expire(original, nowMillis = 1_000L + 169L * 3_600_000L)
        assertEquals("neutral", expired.verdict)
        assertNotEquals(original.verdict, expired.verdict)
    }

    // ── v4.2 回踩确认落库字段
    @Test fun pullbackFieldsDefaultToEmpty() {
        val r = record()
        assertEquals(0L, r.armedAt)
        assertEquals(false, r.pullbackConfirmed)
        assertEquals(0L, r.pullbackMs)
        assertEquals(0, r.evidenceScore)
    }

    @Test fun pullbackFieldsCarryThroughCopy() {
        val r = record().copy(armedAt = 5000L, pullbackConfirmed = true, pullbackMs = 3000L, evidenceScore = 91)
        assertEquals(5000L, r.armedAt)
        assertEquals(true, r.pullbackConfirmed)
        assertEquals(3000L, r.pullbackMs)
        assertEquals(91, r.evidenceScore)
    }

    @Test fun settleKeepsPullbackMetadata() {
        // 结算不应丢失回踩元数据（供分数段/回踩胜率校准）
        val r = record().copy(armedAt = 5000L, pullbackConfirmed = true, pullbackMs = 3000L, evidenceScore = 88)
        val settled = ReviewEngine.settle(r, ReviewOutcome("hit", r.target, 3))
        assertEquals("hit", settled.verdict)
        assertEquals(5000L, settled.armedAt)
        assertEquals(true, settled.pullbackConfirmed)
        assertEquals(3000L, settled.pullbackMs)
        assertEquals(88, settled.evidenceScore)
    }
}
