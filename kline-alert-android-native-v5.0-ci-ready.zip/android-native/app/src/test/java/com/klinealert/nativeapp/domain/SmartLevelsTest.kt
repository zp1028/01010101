package com.klinealert.nativeapp.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SmartLevelsTest {

    private fun analysis(price: Double, atr: Double, vol: Double = 1.0, swingLow: Double, swingHigh: Double,
                         support: Double?, resistance: Double?, ema20: Double) = Analysis(
        "BTCUSDT", "SPOT", "15m", price, 0.0, 55.0, ema20, ema20, "LONG", 80,
        "test", System.currentTimeMillis(), atr = atr, atrPct = 1.0,
        support = support, resistance = resistance, swingLow = swingLow, swingHigh = swingHigh, volExpansion = vol)

    @Test fun volFactorScales() {
        assertEquals(1.6, VolAdaptive.factor(1.5), 0.001)
        assertEquals(1.0, VolAdaptive.factor(1.0), 0.001)
        assertEquals(0.8, VolAdaptive.factor(0.6), 0.001)
    }

    @Test fun stopAnchorsToNearestStructureWithBuffer() {
        // 做多：前低 97，入场 100，ATR 2 → 结构位外 0.5ATR = 96；缓冲 1.5×2=3 → 97；取更远者 96
        val a = analysis(100.0, atr = 2.0, swingLow = 97.0, swingHigh = 104.0, support = 96.8, resistance = 103.0, ema20 = 99.0)
        val sl = SmartLevelsEngine.build(a, "LONG")
        assertEquals(96.0, sl.stop, 0.001) // swingLow 97 - 0.5×ATR
        assertTrue(sl.riskAtr > 1.0)
        assertTrue(sl.notes.any { it.contains("结构位") })
    }

    @Test fun highVolatilityWidensBuffer() {
        val a = analysis(100.0, atr = 2.0, vol = 1.5, swingLow = 97.5, swingHigh = 104.0, support = null, resistance = 103.0, ema20 = 99.0)
        val sl = SmartLevelsEngine.build(a, "LONG")
        // 缓冲 1.5×2×1.6=4.8 → 95.2（比结构位侧 96.5 更远，取缓冲）；正常波动时此例会是 97
        assertEquals(95.2, sl.stop, 0.001)
        assertTrue(sl.stop < SmartLevelsEngine.build(a.copy(volExpansion = 1.0), "LONG").stop)
        assertTrue(sl.notes.any { it.contains("波动放大期") })
    }

    @Test fun riskCappedAtTwoPointFiveAtr() {
        // 结构位极远 → 钳位 2.5×ATR
        val a = analysis(100.0, atr = 1.0, swingLow = 90.0, swingHigh = 120.0, support = null, resistance = 103.0, ema20 = 99.5)
        val sl = SmartLevelsEngine.build(a, "LONG")
        assertEquals(97.5, sl.stop, 0.001)
        assertTrue(sl.notes.any { it.contains("钳位") })
    }

    @Test fun t1PlacedBeforeFirstResistance() {
        // 压力 103，ATR 1 → T1 = 102.7（提前 0.3ATR 防插针）
        val a = analysis(100.0, atr = 1.0, swingLow = 98.0, swingHigh = 104.0, support = null, resistance = 103.0, ema20 = 99.0)
        val sl = SmartLevelsEngine.build(a, "LONG")
        assertEquals(102.7, sl.t1, 0.001)
        assertTrue(sl.t2 > sl.t1 && sl.t3 > sl.t2)
    }

    @Test fun shortSideMirrorsLogic() {
        val a = analysis(100.0, atr = 1.0, swingLow = 96.0, swingHigh = 103.0, support = 97.0, resistance = 103.5, ema20 = 101.0)
            .copy(direction = "SHORT")
        val sl = SmartLevelsEngine.build(a, "SHORT")
        assertTrue(sl.stop > 100.0)
        assertTrue(sl.t1 < 100.0 && sl.t2 < sl.t1 && sl.t3 < sl.t2)
    }
}
