package com.klinealert.nativeapp.domain

import org.junit.Assert.*
import org.junit.Test
import kotlin.math.sin

class AnalysisEngineTest {
    private fun candles(count: Int = 300): List<Candle> = (0 until count).map { i ->
        val close = 100.0 + i * 0.08 + sin(i / 5.0) * 1.7
        Candle(i * 900_000L, close - 0.1, close + 0.8, close - 0.9, close, 1000.0 + (i % 17) * 100.0, (i + 1) * 900_000L - 1)
    }

    @Test fun timeframeContractIsExactlyRequestedFourIntervals() {
        assertEquals(listOf("15m", "30m", "1h", "4h"), AnalysisEngine.supportedTimeframes)
    }

    @Test fun snapshotCalculatesAllCoreIndicators() {
        val s = AnalysisEngine.snapshot(candles())
        assertNotNull(s)
        assertTrue(s!!.price > 0)
        assertTrue(s.ema20.isFinite())
        assertTrue(s.ema60.isFinite())
        assertTrue(s.ema200.isFinite())
        assertTrue(s.rsi in 0.0..100.0)
        assertTrue(s.atr > 0)
        assertTrue(s.atrPct > 0)
        assertTrue(s.bollUpper >= s.bollMid)
        assertTrue(s.bollMid >= s.bollLower)
        assertTrue(s.regimeConfidence in 20.0..99.0)
        assertTrue(s.regime in listOf("上涨延续", "上涨回调", "反弹", "下跌延续", "反抽转弱", "区间震荡", "突破承压线", "假突破"))
        assertNotNull(s.support)
        assertTrue(s.support!! < s.price)
        s.resistance?.let { assertTrue(it >= s.price) }
    }

    @Test fun analyzerRejectsInsufficientHistoryAndUnknownTimeframe() {
        assertNull(AnalysisEngine.analyze("BTCUSDT", "SPOT", "15m", candles(100)))
        assertNull(AnalysisEngine.analyze("BTCUSDT", "SPOT", "5m", candles()))
    }

    @Test fun opportunityIncludesConfidenceAndCurrentTimeframeExtremeLevels() {
        val input = candles()
        val analysis = AnalysisEngine.analyze("BTCUSDT", "SPOT", "15m", input)
        assertNotNull(analysis)
        val a = analysis!!
        assertTrue(a.confidence in 0..100)
        assertNotNull(a.swingHigh)
        assertNotNull(a.swingLow)
        assertTrue(a.swingHigh!! >= a.swingLow!!)
        assertTrue(a.swingHigh!! >= a.price || a.swingLow!! <= a.price)
        assertTrue(a.supportConfluence >= 1)
        assertTrue(a.resistanceConfluence >= 1)
    }

    @Test fun snapshotIsDeterministicForSameCandleSeries() {
        val input = candles()
        val first = AnalysisEngine.snapshot(input)
        val second = AnalysisEngine.snapshot(input)
        assertNotNull(first)
        assertNotNull(second)
        assertEquals(first!!.price, second!!.price, 0.0)
        assertEquals(first.rsi, second.rsi, 0.0)
        assertEquals(first.macdHist, second.macdHist, 0.0)
    }
}
