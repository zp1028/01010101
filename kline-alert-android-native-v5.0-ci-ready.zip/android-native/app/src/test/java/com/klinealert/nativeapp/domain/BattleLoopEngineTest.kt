package com.klinealert.nativeapp.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** v4.5 自动作战循环：盈亏比入仓门控 / 平仓判定 / 移动止盈 / 冷却。 */
class BattleLoopEngineTest {

    private val e = BattleLoopEngine

    // ── 入仓计划：按现价 + 止损 2×ATR / 止盈 3×ATR ──
    @Test fun `LONG 入仓按止损2止盈3定价`() {
        val p = e.buildEntry("BTCUSDT", "SPOT", "LONG", "15m", price = 100.0, atr = 1.5, evidenceScore = 88)
        assertTrue(p.ok)
        assertEquals(100.0, p.entry, 1e-9)
        assertEquals(97.0, p.stop, 1e-9)      // 止损 = 2×R = 2×1.5
        assertEquals(104.5, p.target, 1e-9)   // 止盈 = 3×R = 3×1.5
        assertEquals(1.5, p.riskReward, 1e-9) // 3/2
        assertEquals(2.0, p.stopMult, 1e-9)
        assertEquals(3.0, p.targetMult, 1e-9)
        assertEquals(0.015, p.riskPct, 1e-9)
    }

    @Test fun `SHORT 入仓镜像定价`() {
        val p = e.buildEntry("ETHUSDT", "SPOT", "SHORT", "1h", price = 200.0, atr = 2.0, evidenceScore = 75)
        assertTrue(p.ok)
        assertEquals(204.0, p.stop, 1e-9)
        assertEquals(194.0, p.target, 1e-9)
    }

    @Test fun `自定义乘数`() {
        val p = e.buildEntry("BTCUSDT", "SPOT", "LONG", "15m", price = 100.0, atr = 1.0, evidenceScore = 80,
            stopMult = 3.0, targetMult = 5.0)
        assertTrue(p.ok)
        assertEquals(97.0, p.stop, 1e-9)
        assertEquals(105.0, p.target, 1e-9)
    }

    @Test fun `距止损太近被拒绝`() {
        // ATR/价格 = 0.2% < 0.3% → 止损离现价太近，不追
        val p = e.buildEntry("BTCUSDT", "SPOT", "LONG", "15m", price = 100.0, atr = 0.2, evidenceScore = 80)
        assertFalse(p.ok)
        assertTrue(p.reject.contains("太近"))
    }

    @Test fun `波动过大被拒绝`() {
        val p = e.buildEntry("BTCUSDT", "SPOT", "LONG", "15m", price = 100.0, atr = 6.0, evidenceScore = 80)
        assertFalse(p.ok)
        assertTrue(p.reject.contains("波动过大"))
    }

    @Test fun `价格或ATR无效被拒绝`() {
        assertFalse(e.buildEntry("X", "SPOT", "LONG", "15m", 0.0, 1.0, 80).ok)
        assertFalse(e.buildEntry("X", "SPOT", "LONG", "15m", 100.0, 0.0, 80).ok)
    }

    // ── 平仓判定（固定止盈） ──
    @Test fun `LONG 触止盈平仓`() {
        val d = e.evaluateClose("LONG", entry = 100.0, stop = 98.5, target = 103.0, price = 103.2, crossCheckOk = true)
        assertNotNull(d)
        assertEquals(BattleLoopEngine.CLOSE_TAKE_PROFIT, d!!.action)
    }

    @Test fun `LONG 触止损平仓`() {
        val d = e.evaluateClose("LONG", 100.0, 98.5, 103.0, 98.4, crossCheckOk = true)
        assertNotNull(d)
        assertEquals(BattleLoopEngine.CLOSE_STOP_LOSS, d!!.action)
    }

    @Test fun `SHORT 双向平仓`() {
        val tp = e.evaluateClose("SHORT", 200.0, 202.0, 196.0, 195.9, crossCheckOk = true)
        assertEquals(BattleLoopEngine.CLOSE_TAKE_PROFIT, tp!!.action)
        val sl = e.evaluateClose("SHORT", 200.0, 202.0, 196.0, 202.1, crossCheckOk = true)
        assertEquals(BattleLoopEngine.CLOSE_STOP_LOSS, sl!!.action)
    }

    @Test fun `未到价不平仓`() {
        assertNull(e.evaluateClose("LONG", 100.0, 98.5, 103.0, 101.0, crossCheckOk = true))
    }

    @Test fun `交叉校验不过拦截平仓`() {
        // 防插针：参考价偏差过大 → 本 tick 不动，等复核
        assertNull(e.evaluateClose("LONG", 100.0, 98.5, 103.0, 103.2, crossCheckOk = false))
    }

    // ── 移动止盈 ──
    @Test fun `移动止盈从极值回撤触发`() {
        // LONG target 远高于极值（趋势仍在跑），价格从极值 110 回撤 1.5 → 108.5 触发；现价 108
        val d = e.evaluateClose("LONG", 100.0, 98.5, target = 120.0, price = 108.0, crossCheckOk = true,
            trailing = true, bestPrice = 110.0, trailStep = 1.5)
        assertNotNull(d)
        assertEquals(BattleLoopEngine.CLOSE_TRAIL_STOP, d!!.action)
    }

    @Test fun `移动止盈未达回撤不平`() {
        val d = e.evaluateClose("LONG", 100.0, 98.5, target = 120.0, price = 109.0, crossCheckOk = true,
            trailing = true, bestPrice = 110.0, trailStep = 1.5)
        assertNull(d)   // 109 > 108.5，继续持有
    }

    @Test fun `移动止盈不劣于原始止损`() {
        // 极值只小幅上移（101），回撤 1.5 → 99.5；但原始止损 98.5，取 max → 99.5（仍锁住不亏）
        val d = e.evaluateClose("LONG", 100.0, 98.5, target = 120.0, price = 99.4, crossCheckOk = true,
            trailing = true, bestPrice = 101.0, trailStep = 1.5)
        assertNotNull(d)
        assertEquals(BattleLoopEngine.CLOSE_TRAIL_STOP, d!!.action)
    }

    @Test fun `锚点 LONG 取最高 SHORT 取最低`() {
        assertEquals(110.0, e.updatedBest("LONG", 100.0, 110.0), 1e-9)
        assertEquals(110.0, e.updatedBest("LONG", 110.0, 105.0), 1e-9)
        assertEquals(95.0, e.updatedBest("SHORT", 100.0, 95.0), 1e-9)
        assertEquals(95.0, e.updatedBest("SHORT", 95.0, 98.0), 1e-9)
        assertEquals(99.5, e.updatedBest("LONG", 0.0, 99.5), 1e-9)   // 首次锚点
    }

    // ── 冷却 ──
    @Test fun `冷却期内不重入`() {
        val now = 1_700_000_000_000L   // 真实毫秒时间戳
        assertTrue(e.inCooldown("BTCUSDT|LONG", closeAt = now - 3_600_000L, now = now, cooldownHours = 4.0))
        assertFalse(e.inCooldown("BTCUSDT|LONG", closeAt = now - 4 * 3_600_000L - 1, now = now, cooldownHours = 4.0))
        assertFalse(e.inCooldown("BTCUSDT|LONG", 0L, now))   // 无冷却记录放行
    }

    @Test fun `冷却剩余时间`() {
        val now = 1_700_000_000_000L
        val remain = e.cooldownRemainMs("BTCUSDT|LONG", closeAt = now - 3_600_000L, now = now, cooldownHours = 4.0)
        assertEquals(3 * 3_600_000L, remain)
    }

    // ── 盈亏口径 ──
    @Test fun `方向化盈亏 LONG 与 SHORT 镜像`() {
        assertEquals(2.0, e.movePct(100.0, 102.0, "LONG"), 1e-9)
        assertEquals(-2.0, e.movePct(100.0, 102.0, "SHORT"), 1e-9)
    }

    // ── 新鲜度窗口（v4.6 满仓后只补新鲜信号） ──
    @Test fun `新鲜度窗口按周期`() {
        val now = 1_700_000_000_000L
        assertTrue(e.isFresh(now - 20 * 60_000L, now, "15m"))   // 20min < 30min 窗口
        assertFalse(e.isFresh(now - 31 * 60_000L, now, "15m"))  // 过期
        assertFalse(e.isFresh(now - 121 * 60_000L, now, "1h"))  // 1h 窗口 120min
        assertTrue(e.isFresh(now - 6 * 60_000L, now, "4h"))     // 4h 窗口 480min
        assertFalse(e.isFresh(0L, now, "15m"))                  // 无 K 线时间
    }

    // ── 作战评分与新鲜度（v4.7 优中选优） ──
    @Test fun `新鲜度评分单调衰减`() {
        val now = 1_700_000_000_000L
        assertEquals(100.0, e.freshnessScore(now - 60_000L, now, "15m"), 1e-9)      // 1min 满分
        assertEquals(100.0, e.freshnessScore(now - 5 * 60_000L, now, "15m"), 1e-9)  // 恰 5min 满分
        assertEquals(0.0, e.freshnessScore(now - 30 * 60_000L, now, "15m"), 1e-9)   // 超窗口归零
        assertTrue(e.freshnessScore(now - 10 * 60_000L, now, "15m") < 100.0)        // 中间衰减
        assertEquals(0.0, e.freshnessScore(0L, now, "15m"), 1e-9)
    }

    @Test fun `作战评分新鲜度权重`() {
        val now = 1_700_000_000_000L
        val fresh = e.battleScore(80, 50.0, 1.0, 1.0, now - 60_000L, now, "15m")
        val stale = e.battleScore(80, 50.0, 1.0, 1.0, now - 29 * 60_000L, now, "15m")
        assertTrue(fresh > stale)                          // 同分同胜率，新的更优
        val oldHigh = e.battleScore(95, 50.0, 1.0, 1.0, now - 25 * 60_000L, now, "15m")
        assertTrue(fresh >= oldHigh)                       // 95 分旧信号不压 80 分新信号
    }

    // ── v4.8 审计：边界与除零防护 ──
    @Test fun `入仓拒绝 NaN 与零值价格ATR`() {
        val p1 = e.buildEntry("S", "SPOT", "LONG", "15m", Double.NaN, 0.001, 80)
        assertFalse(p1.ok); assertTrue(p1.reject.contains("无效"))
        val p2 = e.buildEntry("S", "SPOT", "LONG", "15m", 100.0, Double.NaN, 80)
        assertFalse(p2.ok)
        val p3 = e.buildEntry("S", "SPOT", "LONG", "15m", 100.0, 0.0, 80)
        assertFalse(p3.ok)
        val p4 = e.buildEntry("S", "SPOT", "LONG", "15m", 0.0, 0.001, 80)
        assertFalse(p4.ok)
    }

    @Test fun `平仓判定价格边界与非法输入`() {
        // 价格恰好等于止盈/止损位：按到价处理
        assertEquals(e.CLOSE_TAKE_PROFIT, e.evaluateClose("LONG", 100.0, 99.0, 101.0, 101.0, true)?.action)
        assertEquals(e.CLOSE_STOP_LOSS, e.evaluateClose("LONG", 100.0, 99.0, 101.0, 99.0, true)?.action)
        // 非法价格：不动
        assertNull(e.evaluateClose("LONG", 100.0, 99.0, 101.0, Double.NaN, true))
        assertNull(e.evaluateClose("LONG", 100.0, 99.0, 101.0, 0.0, true))
        assertNull(e.evaluateClose("LONG", 100.0, 99.0, 101.0, -1.0, true))
        // 交叉校验不过：不动（防插针）
        assertNull(e.evaluateClose("LONG", 100.0, 99.0, 101.0, 120.0, false))
    }

    @Test fun `方向化盈亏除零与镜像`() {
        assertEquals(0.0, e.movePct(0.0, 100.0, "LONG"), 1e-9)
        assertEquals(0.0, e.movePct(100.0, 0.0, "LONG"), 1e-9)
        assertEquals(0.0, e.movePct(100.0, -5.0, "LONG"), 1e-9)
        assertEquals(50.0, e.movePct(100.0, 150.0, "LONG"), 1e-9)
        assertEquals(-50.0, e.movePct(100.0, 150.0, "SHORT"), 1e-9)
    }

    @Test fun `冷却边界恰到期归零`() {
        val now = 1_700_000_000_000L
        val closeAt = now - (4 * 3_600_000L)   // 恰满 4h
        assertFalse(e.inCooldown("S|LONG", closeAt, now))
        assertEquals(0L, e.cooldownRemainMs("S|LONG", closeAt, now))
        assertTrue(e.inCooldown("S|LONG", closeAt + 1, now))
        // 无冷却/非法 key 视为无冷却
        assertFalse(e.inCooldown("S|LONG", 0L, now))
        assertFalse(e.inCooldown("", 1L, now))
    }

    @Test fun `新鲜度评分窗口边界`() {
        val now = 1_700_000_000_000L
        assertEquals(0.0, e.freshnessScore(now - 30 * 60_000L, now, "15m"), 1e-9)  // 恰在窗口边缘
        assertTrue(e.freshnessScore(now - 29 * 60_000L, now, "15m") > 0.0)          // 窗口内极小正值
        assertEquals(0.0, e.freshnessScore(now - 31 * 60_000L, now, "15m"), 1e-9)  // 超窗口
        assertEquals(100.0, e.freshnessScore(now - 5 * 60_000L, now, "1h"), 1e-9)
    }

    @Test fun `作战评分输入钳制`() {
        val now = 1_700_000_000_000L
        // 分数/胜率超界钳制；波动极值不产生 NaN
        val s = e.battleScore(150, 200.0, 99.0, 999.0, now - 60_000L, now, "15m")
        assertTrue(s.isFinite())
        assertTrue(s <= 100.0)
        val s2 = e.battleScore(-10, -5.0, -1.0, -1.0, now - 60_000L, now, "15m")
        assertTrue(s2.isFinite())
    }
}
