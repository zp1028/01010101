package com.klinealert.nativeapp.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LifecycleTest {

    private fun rep(price: Double, atrVal: Double, adx: Double, macdHist: Double, rsi: Double,
                    ema20: Double, swingLow: Double, swingHigh: Double): Analysis =
        Analysis("BTCUSDT", "SPOT", "15m", price, 0.0, rsi, ema20, ema20 * 0.98, "LONG", 80,
            "test", System.currentTimeMillis(), atr = atrVal, atrPct = 1.0, macdHist = macdHist,
            adx = adx, swingLow = swingLow, swingHigh = swingHigh, confidence = 75)

    @Test fun healthyTrendPullbackJudgedAsPullback() {
        // 强趋势 + 回撤浅 + 动能未换向 + 结构完好 → 回踩
        val a = rep(price = 99.0, atrVal = 10.0, adx = 30.0, macdHist = 0.5, rsi = 55.0,
            ema20 = 98.0, swingLow = 92.0, swingHigh = 105.0)
        val v = PullbackReversalJudge.judge("LONG", 99.0, 100.0, a, 0.2)
        assertEquals("回踩", v.status)
        assertTrue(v.confidence >= 70)
    }

    @Test fun momentumFlipWithBreakJudgedAsReversal() {
        // 动能换向 + 破前低 + 深回撤 → 反转
        val a = rep(price = 88.0, atrVal = 10.0, adx = 15.0, macdHist = -0.6, rsi = 30.0,
            ema20 = 95.0, swingLow = 92.0, swingHigh = 105.0)
        val v = PullbackReversalJudge.judge("LONG", 88.0, 100.0, a, 2.8)
        assertEquals("反转", v.status)
        assertTrue(v.confidence >= 70)
    }

    @Test fun mixedEvidenceStaysDisagreement() {
        // 部分证据冲突 → 分歧
        val a = rep(price = 96.0, atrVal = 10.0, adx = 26.0, macdHist = -0.2, rsi = 48.0,
            ema20 = 97.0, swingLow = 90.0, swingHigh = 105.0)
        val v = PullbackReversalJudge.judge("LONG", 96.0, 100.0, a, 1.2)
        assertEquals("分歧", v.status)
        assertTrue(v.evidence.isNotEmpty())
    }

    @Test fun lifecyclePhasesForPosition() {
        val a = rep(price = 99.5, atrVal = 10.0, adx = 30.0, macdHist = 0.5, rsi = 55.0,
            ema20 = 98.0, swingLow = 92.0, swingHigh = 105.0)
        val healthy = LifecycleEngine.evaluate("LONG", 98.0, 92.0, 110.0, 99.5, a, isPosition = true)
        assertEquals("持有·趋势健康", healthy.phase)
        val reversal = LifecycleEngine.evaluate("LONG", 98.0, 92.0, 110.0, 85.0,
            a.copy(price = 85.0, macdHist = -0.6, rsi14 = 30.0), isPosition = true)
        assertEquals("离场·反转失效", reversal.phase)
        // 紧迫度：反转 < 健康（数字小的排前面）
        assertTrue(LifecycleEngine.urgency(reversal) < LifecycleEngine.urgency(healthy))
    }
}
