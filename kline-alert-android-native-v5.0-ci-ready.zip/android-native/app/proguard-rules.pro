# Keep domain models used via reflection / JSON if any
-keep class com.klinealert.nativeapp.domain.** { *; }
-keep class com.klinealert.nativeapp.data.** { *; }

# OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**
-keepnames class okhttp3.internal.publicsuffix.PublicSuffixDatabase
