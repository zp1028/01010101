# P37 Change Log

- Hardened `report_truth` against false-positive availability from `{available:false}` provider payloads.
- Treat `provider_required`, `pending_provider`, and `unavailable` evidence states as missing.
- Added regression tests for unavailable provider objects.
- Contextual News/Macro/OnChain agents now use explicit unavailable state instead of synthetic neutral 0.5 scores when data is absent.
- No simulated market values or synthetic probabilities were added.
