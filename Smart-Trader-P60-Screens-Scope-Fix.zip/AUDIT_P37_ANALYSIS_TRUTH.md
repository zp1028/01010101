# P37 Analysis Truth Audit

## Scope
P37 continues from P36 and focuses on the final truth-gate boundary between provider evidence and report availability.

## Fixed
- Provider evidence objects with `available=false` no longer pass report truth checks merely because the object is non-empty.
- Provider states `unavailable`, `pending_provider`, and `provider_required` are treated as missing evidence.
- Unknown/unmapped report source requirements remain blocked instead of being treated as optional.
- News, macro, and on-chain contextual agents no longer emit a neutral `0.5` score when their data is absent. They emit `score=None`, `stance=unavailable`, and confidence `0.0`.

## Truth rule
A report is available only when its declared evidence paths contain usable provider/analysis data for the exact requested instrument and timeframe. Missing enrichment is surfaced rather than substituted.

## Validation
- Backend tests: 89 passed.
- Python compileall: PASS.
- ZIP integrity: PASS.
- Android Gradle build is not claimed here; the environment cannot resolve the Gradle distribution host.
