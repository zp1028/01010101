# P38 Analysis Truth Audit

## Verified

- Market data timestamp is separated from analysis generation timestamp.
- Report truth gate rejects unavailable/pending/provider-required evidence.
- Unknown report source requirements are rejected rather than silently accepted.
- Probability remains hidden unless walk-forward status is calibrated.
- MACD signal intensity no longer contains a fixed confidence-like constant.
- No simulation/order/account-execution surface was introduced.

## Remaining external dependency

The application still depends on configured external providers for US/HK/commodity/news/macro/on-chain/enrichment domains. When a required provider is absent, the report is marked unavailable/pending_provider rather than fabricated.
