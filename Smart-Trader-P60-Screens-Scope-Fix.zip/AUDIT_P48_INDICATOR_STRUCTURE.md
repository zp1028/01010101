# P48 Truth Audit

## Data path
Current timeframe -> current candles -> local RSI/MACD visualization.
Backend indicator report -> provider-backed timeframe candles -> full indicator analysis.

## Anti-fake checks
- No fixed BTC/ETH price series added.
- No fixed RSI/MACD values added.
- No hard-coded probability added.
- UI labels explicitly state that the plots are recalculated from current timeframe candles.
- RSI 30/70 are indicator thresholds, not directional predictions.

## Scope
Read-only market research and analysis. No account, wallet, simulation, order or execution path added.
