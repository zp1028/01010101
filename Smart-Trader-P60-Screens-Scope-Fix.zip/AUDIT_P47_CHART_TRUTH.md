# P47 Chart Truth Audit
- Candle chart consumes `CandleDto` from the existing live market-data path.
- MA20/MA50 are computed from returned closes.
- Support/resistance use min/max of the recent returned candle window (up to 60 candles).
- Volume bars are normalized against returned visible-window volume.
- No hard-coded price series or market levels were introduced.
