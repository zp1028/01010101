# P44 Audit — Binance-style Market Terminal

## 数据链
`Binance USDⓈ-M exchangeInfo → 24h ticker / premiumIndex / bookTicker / depth / trades / klines → TerminalSnapshot → Android Terminal Card`

## 数据真实性
- 合约分类继续来自 `exchangeInfo`。
- 价格、24H、成交量来自 ticker。
- Mark/Index/Funding 来自 premiumIndex。
- Bid/Ask 来自 bookTicker。
- Depth 来自 depth。
- 最近成交来自 trades。
- K线来自 klines。
- freshness 根据 provider 时间戳与当前服务器时间计算。

## 边界
- P44 只实现 Binance USDⓈ-M terminal layer。
- 美股、港股、大宗仍按各自 provider 能力，不伪装成 Binance 实时数据。
- 分析引擎仍是独立层；P44 不改变概率/AI/策略的 truth 规则。
- Android 编译需要可访问 Gradle 8.9 的构建环境才能最终确认。
