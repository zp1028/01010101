# P36 Analysis Truth Audit

## Findings addressed

### Probability
The probability engine is now an expanding walk-forward empirical model. OOS predictions are generated sequentially using only prior samples. Current probability is withheld when same-condition historical support is insufficient.

### Report truth gates
Every report source requirement must map to a concrete evidence path. An unmapped requirement is treated as missing rather than silently passing. Reports with missing provider evidence are marked `pending_provider`.

### Commodities
No static commodity universe is used. Without a configured futures universe provider the commodity universe is empty and the capability matrix says `provider_required`.

## Intentional numeric parameters
Technical thresholds such as RSI 30/70 and indicator periods remain explicit analysis methodology parameters. They are not presented as probabilities or historical performance. Risk/backtest defaults are configuration values and are not market facts.

## Remaining external-provider boundary
US historical/intraday chart data currently uses the public Yahoo-compatible chart endpoint; synchronized realtime quote capability remains explicitly separate. HK and commodity realtime/universe coverage remains provider-dependent. The application must show these capability states rather than fabricate coverage.

## Build boundary
Backend validation passes. Android compile requires CI/network access to Gradle distribution; local verification is blocked by DNS/network access to `services.gradle.org`.
