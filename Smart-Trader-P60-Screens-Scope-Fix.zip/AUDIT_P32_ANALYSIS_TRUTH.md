# P32 Analysis Truth Audit

## Removed from core report path
- Fixed bull/base/bear probabilities (0.55/0.40/0.30/0.35/0.25).
- Fixed technical evidence confidence values used as if they were predictive probabilities.
- Fixed contextual confidence values in the core evidence chain.

## New rule
A probability is displayed only when persisted historical analysis feedback contains completed `validated` / `invalidated` outcomes. Otherwise probability is `null` and the report explicitly states that calibration is unavailable.

## Important distinction
Indicator thresholds (for example RSI oversold/overbought) remain deterministic analytical rules. They are not presented as empirical probabilities. Risk/entry parameters remain strategy parameters and are not historical success probabilities.

## Not claimed
This does not magically create an ML model. The current system is a deterministic quantitative analysis engine with empirical outcome calibration. A future ML model must be trained and validated separately before being labeled as an ML probability model.
