# P46 — Binance-style Terminal UI integration

## Scope
- Reworked the crypto detail terminal presentation around real USDⓈ-M terminal data already provided by P44/P45.
- Added dense market-header metrics for Last, 24H change, Mark, Index, Funding, Mid, Spread and quote volume.
- Split live order-book and trade-tape presentation into compact terminal panels.
- Added explicit LIVE/STALE and freshness indicators.
- Kept the surface read-only: no order, account, wallet or execution controls were introduced.
- Reused only provider-backed values from `TerminalSnapshotDto`; no fixed market values were added.

## Analysis boundary
The terminal remains the market-facts layer. `SmartAnalysisCard`, indicators, multi-timeframe analysis, unified reports and risk/holding observations remain downstream consumers of live data.
