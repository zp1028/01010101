# Smart Trader P49 — Market Structure + Multi-Timeframe Resonance Visualization

## Scope
P49 continues from P48 and adds a read-only market-structure contract and Android presentation. It does not add accounts, wallets, orders, execution, or simulated market data.

## Backend
- Added `market-structure-v1` service.
- Current-timeframe OHLCV is used to derive local pivot highs/lows.
- Pivots are labeled HH/LH and HL/LL where comparisons are available.
- Dynamic support/resistance are derived from the recent real candle window.
- Breakout is explicitly marked as a **testing** state before candle close; it is not presented as confirmed.
- Added `GET /api/v1/analysis/{symbol}/structure`.
- Added regression coverage for the structure contract.

## Android
- Added `MarketStructureDto` and real API retrieval.
- Detail refresh now retrieves market structure alongside indicators and MTF analysis.
- Added a market-structure card showing trend, support/resistance, pivot labels, breakout-test state and close-confirmation rule.
- Existing 5m/15m/30m/1h/4h/1d/1w timeframe refresh behavior is preserved.

## Truth rules
- No fixed BTC price, support, resistance, pivots, breakout or MTF values.
- No simulated candles.
- Intrabar structure is observational; confirmation requires the relevant candle close.
- Analysis remains read-only.
