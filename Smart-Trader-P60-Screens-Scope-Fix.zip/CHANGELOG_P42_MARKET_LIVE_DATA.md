# P42 — Market Live Data Recovery

## 现象
安装后的「市场」页显示 0 个当前载入品种，导致整个市场列表为空。

## 根因
1. Android 构建没有提供 `SMART_TRADER_BACKEND_URL` 时，`ApiConfig.baseUrl` 为空。
2. 市场页原流程仍先请求后端 `/api/v1/markets`，空后端配置下无法形成有效 URL。
3. 原设备直连只依赖 Binance `api.binance.com`。在部分网络/地区该公共端点不可达时，没有第二真实数据源。
4. 因此没有生成任何列表；并非因为市场 universe 被硬编码成 10 个品种。

## 实际修复
- 后端 URL 为空时，crypto 市场直接走真实公开行情 provider，不再请求无效后端 URL。
- Binance 仍是第一直连源。
- Binance 不可达时增加 CoinGecko public market feed 作为真实 provider fallback。
- CoinGecko 品种来自接口响应，不在 APK 中写死币种列表。
- 后端可达但 crypto provider 返回空时，同样触发真实 provider fallback。
- 非 crypto 市场在没有后端/专用 provider 时清空旧列表并显示明确数据源状态，避免把旧数据误认为当前市场。
- 空列表 UI 显示真实错误/数据源状态，并明确不会用模拟数据填充。

## 验证
- Backend: `PYTHONPATH=. pytest -q` → 93 passed.
- Python compileall: PASS.
- Android Gradle compile was attempted, but this environment cannot resolve `services.gradle.org`; therefore no Android compile success is claimed here.
