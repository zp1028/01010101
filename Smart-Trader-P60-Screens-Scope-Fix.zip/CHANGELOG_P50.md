# P50 — 实时多空条件情景引擎

## 本版目标
把技术指标、市场结构、多周期状态统一成可解释的 Bull / Base / Bear 条件情景；不输出未经历史校准的伪概率，不提供交易执行。

## 实际源码变更
- 新增 `backend/app/services/scenario_engine.py`
- 新增 `backend/app/api/v1/scenarios.py`
- 新增只读接口：`GET /api/v1/analysis/{symbol}/scenarios`
- Android 新增 Scenario DTO、轮询刷新和“实时多空情景”可视化卡片。
- 修复市场结构参考边界：突破参考使用已完成K线，不把当前未收盘K线自身作为阻力/支撑边界。
- 场景包含：触发条件、观察区、失效条件、路径、证据、校准概率字段。

## 真实性规则
- `probability` 只有历史校准系统能够提供时才允许进入；当前情景引擎明确返回 `null`。
- 未收盘突破只标记为测试；对应周期收盘后才进入确认逻辑。
- 所有价格/指标均来自当前请求的真实K线计算。
- 没有新增模拟、下单、账户连接、钱包或交易执行功能。

## 验证
- Backend：`99 passed in 7.25s`
- Python `compileall`：PASS
- Android Debug Kotlin：本环境无法完成，因为 Gradle 8.9 wrapper 需要访问 `services.gradle.org`，当前网络无法解析该域名；因此没有声称 Android 编译成功。
