# Smart Trader P44 — Binance-style USDⓈ-M Market Terminal Layer

## 本版目标
在 P43.1 的真实 Binance USDⓈ-M 市场发现与行情层之上，增加“专业市场终端”数据底座。该层只读取公开市场数据，不加入账户、钱包、订单、下单或执行功能。

## 已落地
- 全量 USDⓈ-M 合约继续由 Binance `exchangeInfo` 动态发现，不使用固定币种名单。
- 新增 `/api/v1/terminal/crypto/{symbol}` 只读终端快照接口。
- 单次终端快照并行读取：24h ticker、bookTicker、depth、recent trades、premiumIndex、K线。
- 统一输出：Last/24H、Mark、Index、Funding、Bid/Ask、盘口深度、最近成交、K线和数据新鲜度。
- 所有终端数据保留 Binance 原始时间字段的归一化结果，并计算 Quote/Mark/Book 年龄。
- Android 详情页增加 USDⓈ-M 市场终端卡片，展示盘口、最近成交、Mark/Index/Funding 和 freshness。
- 周期仍使用 5m/15m/30m/1h/4h/1d/1w；切换周期会重新请求终端K线和分析。
- 终端层与分析层分离：行情事实不会被 AI/分析结果覆盖。
- 保持 analysis-only：没有交易账户、钱包、订单、下单、执行 API。

## Truth / Anti-mock
- 没有新增固定价格、固定涨跌、固定盘口或固定分析数字。
- Provider 不可用时返回错误/缺失状态，不生成假行情。
- UI 的 LIVE/STALE 由真实数据时间计算。

## 验证
- Backend pytest: **96 passed**
- Python compileall: **PASS**
- Android Gradle compile: **未完成**。当前执行环境无法访问 `services.gradle.org` 下载 Gradle 8.9，失败原因为 `UnknownHostException`；因此本版不宣称 Android 编译通过。
