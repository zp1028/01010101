# Smart Trader P38 — Analysis Truth / Provenance Closure

## Changes

1. Report `data_timestamp` now points to the actual latest market candle close timestamp (`last_close_time`) instead of the report generation clock.
2. Report responses expose `analysis_generated_at` separately, so UI can distinguish market-data time from analysis computation time.
3. MACD signal `strength` is no longer a fixed 0.55. It is derived from observed `abs(macd_hist) / ATR`, capped to [0,1], and explicitly labelled as signal intensity rather than probability.
4. Volume-spike signal strength remains data-derived from the observed volume ratio and now carries its calculation basis.
5. Existing provider/report truth gates remain strict: unavailable/provider-required/pending data cannot satisfy a report requirement.

## Validation

- Backend pytest: 89 passed
- Python compileall: PASS
- ZIP integrity: PASS
- Android Gradle compilation was not claimed in this environment because the Gradle distribution endpoint is unavailable from the execution environment.
