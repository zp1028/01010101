from fastapi import APIRouter, HTTPException, Query

from app.services.market_universe import MarketUniverseService
from app.services.market_coverage import MarketCoverageService
from app.services.market_data_status import MarketDataStatusService
from app.core.config import settings
import httpx
import time
from app.services.binance_usdm_market_data import BinanceUsdMMarketData

router = APIRouter(tags=["markets"])
universe = MarketUniverseService()
coverage = MarketCoverageService(universe)
data_status = MarketDataStatusService()
_usdm = BinanceUsdMMarketData(settings.binance_rest_url, ttl=settings.binance_market_data_ttl_seconds)

async def _crypto_quotes() -> dict[str, dict[str, float]]:
    return await _usdm.quotes()


def _binance():
    from app.main import binance
    return binance


@router.get("/markets")
async def markets(
    market: str | None = Query(None, description="crypto/us/hk/commodities"),
    q: str | None = Query(None, description="symbol/name search"),
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0, le=1000000),
    sort: str = Query("symbol", description="symbol|name"),
):
    # Do not make one market depend on every other provider. A crypto request
    # must still work when SEC/HK providers are slow or unavailable.
    market_key = market.lower() if market else None
    if market_key == "crypto":
        items = await universe.crypto()
    elif market_key == "us":
        items = await universe.us()
    elif market_key == "hk":
        items = await universe.hk()
    elif market_key == "commodities":
        items = await universe.commodities()
    else:
        items = await universe.all()
    if q:
        needle = q.lower()
        items = [x for x in items if needle in x.symbol.lower() or needle in x.name.lower()]
    items = sorted(items, key=lambda x: (x.name.lower(), x.symbol.lower()) if sort == "name" else x.symbol.lower())
    total = len(items)
    page = items[offset:offset + limit]
    try:
        quotes = await _crypto_quotes() if market_key in (None, "crypto") else {}
    except Exception:
        # Preserve the discovered universe and expose quote_status instead of
        # manufacturing prices or failing the entire market page.
        quotes = {}
    rows = []
    for x in page:
        row = x.__dict__.copy() if hasattr(x, "__dict__") else {
            "symbol": x.symbol, "name": x.name, "market": x.market,
            "asset_type": x.asset_type, "venue": x.venue, "currency": x.currency,
            "metadata": x.metadata or {},
        }
        q = quotes.get(str(x.symbol).upper().replace("/", ""))
        if q:
            row.update(q)
            row["quote_status"] = "live"
            meta = row.get("metadata") or {}
            row["contract_type"] = q.get("contract_type") or meta.get("contract_type", "")
            row["market_data_type"] = q.get("market_data_type") or ""
        else:
            row["quote_status"] = "provider_unavailable"
        rows.append(row)
    return {
        "analysis_only": True,
        "count": len(page),
        "total": total,
        "offset": offset,
        "limit": limit,
        "has_more": offset + limit < total,
        "markets": rows,
    }


@router.get("/markets/coverage")
async def market_coverage():
    return await coverage.snapshot()


@router.get("/markets/data-status")
async def market_data_status():
    return data_status.snapshot()


@router.get("/markets/{symbol}")
async def market(symbol: str):
    items = await universe.all()
    raw = symbol.upper().replace("/", "")
    found = next((x for x in items if x.symbol.upper().replace("/", "") == raw or x.symbol.upper() == symbol.upper()), None)
    if not found:
        # Crypto detail can still be opened when it is currently subscribed.
        binance = _binance()
        if symbol.lower() in binance.subscriptions:
            return {"symbol": symbol.upper(), "market": "crypto", "analysis_only": True}
        raise HTTPException(404, "instrument not found in current universe")
    return {
        "analysis_only": True,
        "symbol": found.symbol,
        "name": found.name,
        "market": found.market,
        "asset_type": found.asset_type,
        "venue": found.venue,
        "currency": found.currency,
        "metadata": found.metadata or {},
    }
