from __future__ import annotations

import time
from typing import Any

import httpx


class BinanceUsdMTerminalService:
    """Read-only Binance USDⓈ-M terminal snapshot.

    This is deliberately a market-data adapter: no account, order or execution
    endpoint is exposed. Each snapshot carries source timestamps so the UI can
    distinguish fresh market facts from analytical output.
    """

    def __init__(self, base_url: str = "https://fapi.binance.com", timeout: float = 8.0):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    async def snapshot(self, symbol: str, interval: str = "15m", depth_limit: int = 20, trade_limit: int = 20) -> dict[str, Any]:
        raw = symbol.replace("/", "").replace("-", "").upper()
        if not raw:
            raise ValueError("symbol is required")
        allowed = {"1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "8h", "12h", "1d", "3d", "1w"}
        if interval not in allowed:
            raise ValueError("unsupported interval")
        depth_limit = max(5, min(depth_limit, 100))
        trade_limit = max(5, min(trade_limit, 100))
        endpoints = {
            "ticker": f"/fapi/v1/ticker/24hr?symbol={raw}",
            "book": f"/fapi/v1/ticker/bookTicker?symbol={raw}",
            "depth": f"/fapi/v1/depth?symbol={raw}&limit={depth_limit}",
            "trades": f"/fapi/v1/trades?symbol={raw}&limit={trade_limit}",
            "premium": f"/fapi/v1/premiumIndex?symbol={raw}",
            "klines": f"/fapi/v1/klines?symbol={raw}&interval={interval}&limit=180",
        }
        async with httpx.AsyncClient(base_url=self.base_url, timeout=self.timeout) as client:
            responses = await self._gather(client, endpoints)

        ticker = self._json(responses["ticker"], {})
        book = self._json(responses["book"], {})
        depth = self._json(responses["depth"], {})
        trades = self._json(responses["trades"], [])
        premium = self._json(responses["premium"], {})
        klines = self._json(responses["klines"], [])
        if not isinstance(ticker, dict) or not ticker.get("symbol"):
            raise RuntimeError("Binance USD-M ticker unavailable")

        now = int(time.time() * 1000)
        return {
            "analysis_only": True,
            "symbol": raw,
            "provider": "Binance USD-M Futures",
            "market_data_type": "USD-M",
            "server_time": now,
            "quote": {
                "last_price": self._float(ticker.get("lastPrice")),
                "price_change": self._float(ticker.get("priceChange")),
                "change_pct": self._float(ticker.get("priceChangePercent")),
                "high_24h": self._float(ticker.get("highPrice")),
                "low_24h": self._float(ticker.get("lowPrice")),
                "volume": self._float(ticker.get("volume")),
                "quote_volume": self._float(ticker.get("quoteVolume")),
                "trades": int(ticker.get("count", 0) or 0),
                "data_time": ticker.get("closeTime"),
            },
            "mark": {
                "mark_price": self._float(premium.get("markPrice")),
                "index_price": self._float(premium.get("indexPrice")),
                "funding_rate": self._float(premium.get("lastFundingRate")),
                "next_funding_time": premium.get("nextFundingTime"),
                "data_time": premium.get("time"),
            },
            "book": {
                "bid": self._float(book.get("bidPrice")),
                "bid_size": self._float(book.get("bidQty")),
                "ask": self._float(book.get("askPrice")),
                "ask_size": self._float(book.get("askQty")),
                "data_time": book.get("time"),
            },
            "depth": {
                "last_update_id": depth.get("lastUpdateId") if isinstance(depth, dict) else None,
                "bids": self._levels(depth.get("bids", []) if isinstance(depth, dict) else []),
                "asks": self._levels(depth.get("asks", []) if isinstance(depth, dict) else []),
            },
            "trades": self._trades(trades),
            "candles": self._candles(klines),
            "freshness": {
                "quote_ms": self._age(now, ticker.get("closeTime")),
                "mark_ms": self._age(now, premium.get("time")),
                "book_ms": self._age(now, book.get("time")),
                "status": "live" if self._age(now, ticker.get("closeTime")) is not None and self._age(now, ticker.get("closeTime")) < 15000 else "stale",
            },
        }

    async def _gather(self, client: httpx.AsyncClient, endpoints: dict[str, str]) -> dict[str, Any]:
        import asyncio
        tasks = {name: client.get(path) for name, path in endpoints.items()}
        values = await asyncio.gather(*tasks.values(), return_exceptions=True)
        return dict(zip(tasks.keys(), values))

    @staticmethod
    def _json(response: Any, fallback: Any) -> Any:
        if isinstance(response, Exception):
            return fallback
        try:
            response.raise_for_status()
            return response.json()
        except Exception:
            return fallback

    @staticmethod
    def _float(value: Any) -> float | None:
        try:
            return float(value) if value is not None else None
        except (TypeError, ValueError):
            return None

    @classmethod
    def _levels(cls, rows: Any) -> list[dict[str, float]]:
        out = []
        for row in rows if isinstance(rows, list) else []:
            if not isinstance(row, list) or len(row) < 2:
                continue
            price, qty = cls._float(row[0]), cls._float(row[1])
            if price is not None and qty is not None:
                out.append({"price": price, "qty": qty})
        return out

    @classmethod
    def _trades(cls, rows: Any) -> list[dict[str, Any]]:
        out = []
        for row in rows if isinstance(rows, list) else []:
            if not isinstance(row, dict):
                continue
            out.append({"id": row.get("id"), "price": cls._float(row.get("price")), "qty": cls._float(row.get("qty")), "buyer_maker": row.get("isBuyerMaker"), "time": row.get("time")})
        return out

    @classmethod
    def _candles(cls, rows: Any) -> list[dict[str, Any]]:
        out = []
        for row in rows if isinstance(rows, list) else []:
            if not isinstance(row, list) or len(row) < 7:
                continue
            out.append({"open_time": row[0], "open": cls._float(row[1]), "high": cls._float(row[2]), "low": cls._float(row[3]), "close": cls._float(row[4]), "volume": cls._float(row[5]), "close_time": row[6]})
        return out

    @staticmethod
    def _age(now: int, ts: Any) -> int | None:
        try:
            return max(0, now - int(ts)) if ts is not None else None
        except (TypeError, ValueError):
            return None
