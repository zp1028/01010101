import pytest

from app.services.binance_usdm_market_data import BinanceUsdMMarketData


@pytest.mark.asyncio
async def test_usdm_quotes_normalize_ticker_mark_and_book(monkeypatch):
    class Resp:
        def __init__(self, data): self.data = data
        def raise_for_status(self): pass
        def json(self): return self.data

    class Client:
        def __init__(self, *a, **k): pass
        async def __aenter__(self): return self
        async def __aexit__(self, *a): return False
        async def get(self, url, **kwargs):
            if url.endswith('/exchangeInfo'):
                return Resp({'symbols':[{'symbol':'BTCUSDT','pair':'BTCUSDT','status':'TRADING','contractType':'PERPETUAL','quoteAsset':'USDT','baseAsset':'BTC'}]})
            if url.endswith('/ticker/24hr'):
                return Resp([{'symbol':'BTCUSDT','lastPrice':'100','prevClosePrice':'99','priceChangePercent':'1.01','volume':'10','quoteVolume':'1000','count':12,'closeTime':123}])
            if url.endswith('/premiumIndex'):
                return Resp([{'symbol':'BTCUSDT','markPrice':'100.1','indexPrice':'100.0','lastFundingRate':'0.0001','nextFundingTime':456,'time':123}])
            if url.endswith('/ticker/bookTicker'):
                return Resp([{'symbol':'BTCUSDT','bidPrice':'99.9','bidQty':'2','askPrice':'100.1','askQty':'3','time':123}])
            return Resp([])

    monkeypatch.setattr('app.services.binance_usdm_market_data.httpx.AsyncClient', Client)
    data = await BinanceUsdMMarketData().quotes()
    row = data['BTCUSDT']
    assert row['market_data_type'] == 'USD-M'
    assert row['price'] == 100.0
    assert row['mark_price'] == 100.1
    assert row['funding_rate'] == 0.0001
    assert row['bid'] == 99.9
    assert row['ask'] == 100.1


@pytest.mark.asyncio
async def test_usdm_adapter_does_not_accept_spot_or_non_usd_margin(monkeypatch):
    class Resp:
        def __init__(self, data): self.data = data
        def raise_for_status(self): pass
        def json(self): return self.data
    class Client:
        def __init__(self,*a,**k): pass
        async def __aenter__(self): return self
        async def __aexit__(self,*a): return False
        async def get(self,url,**kwargs):
            if url.endswith('/exchangeInfo'):
                return Resp({'symbols':[
                    {'symbol':'BTCUSDT','status':'TRADING','contractType':'PERPETUAL','quoteAsset':'USDT'},
                    {'symbol':'BTCUSD','status':'TRADING','contractType':'PERPETUAL','quoteAsset':'USD'}
                ]})
            if url.endswith('/ticker/24hr'):
                return Resp([
                    {'symbol':'BTCUSDT','lastPrice':'100','prevClosePrice':'99','priceChangePercent':'1','volume':'1'},
                    {'symbol':'BTCUSD','lastPrice':'100','prevClosePrice':'99','priceChangePercent':'1','volume':'1'}
                ])
            return Resp([])
    monkeypatch.setattr('app.services.binance_usdm_market_data.httpx.AsyncClient', Client)
    data = await BinanceUsdMMarketData().quotes()
    assert set(data) == {'BTCUSDT'}
