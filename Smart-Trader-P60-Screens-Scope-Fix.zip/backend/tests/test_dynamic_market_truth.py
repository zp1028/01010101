import os

import pytest

from app.core.config import Settings
from app.services.market_universe import MarketUniverseService, UniverseItem


def test_default_symbol_configuration_is_not_hard_coded():
    settings = Settings(_env_file=None)
    assert settings.symbols == []


@pytest.mark.asyncio
async def test_crypto_universe_uses_provider_symbols(monkeypatch):
    service = MarketUniverseService()

    class FakeResponse:
        def __init__(self, payload):
            self.payload = payload
        def raise_for_status(self):
            return None
        def json(self):
            return self.payload

    class FakeClient:
        def __init__(self, *args, **kwargs):
            pass
        async def __aenter__(self):
            return self
        async def __aexit__(self, *args):
            return False
        async def get(self, url):
            if "fapi" in url:
                return FakeResponse({"symbols": [{
                    "symbol": "LIVEUSDT", "pair": "LIVEUSDT", "status": "TRADING",
                    "contractType": "PERPETUAL", "quoteAsset": "USDT", "baseAsset": "LIVE"
                }]})
            return FakeResponse({"symbols": [{
                "symbol": "NEWUSDT", "pair": "NEWUSDT", "status": "TRADING",
                "quoteAsset": "USDT", "baseAsset": "NEW"
            }]})

    monkeypatch.setattr("app.services.market_universe.httpx.AsyncClient", FakeClient)
    items = await service.crypto()
    symbols = {x.symbol for x in items}
    assert symbols == {"LIVEUSDT"}
    assert "BTCUSDT" not in symbols
    assert "NEWUSDT" not in symbols
