from app.services.holding_observation import build_holding_observation


def test_market_only_observation_is_read_only():
    out = build_holding_observation(price=105, support=100, resistance=110, trend="bullish", rsi=72, macd_hist=1.2, adx=30)
    assert out["analysis_only"] is True
    assert out["read_only"] is True
    assert out["side"] is None
    assert out["unrealized_change_pct"] is None
    assert out["context_source"] == "market_only"
    assert out["risk_level"] == "正常观察"


def test_long_user_context_pnl_and_risk_nodes():
    out = build_holding_observation(price=99, support=100, resistance=110, trend="bearish", rsi=45, macd_hist=-1, adx=28, side="long", entry_price=100)
    assert out["unrealized_change_pct"] == -1.0
    assert out["risk_level"] == "高风险节点"
    assert any("支撑" in x for x in out["watchpoints"])
