import json
from pathlib import Path

from app.ai.calibration import load_calibration, scenario_probabilities
from app.ai.models import Scenario


def test_no_completed_feedback_does_not_fabricate_probability(tmp_path: Path):
    path = tmp_path / "feedback.json"
    path.write_text("{}", encoding="utf-8")
    cal = load_calibration(path)
    values = scenario_probabilities(directional_score=0.9, calibration=cal)
    assert values[:3] == (None, None, None)
    assert values[3]["calibrated"] is False


def test_probability_comes_from_completed_feedback(tmp_path: Path):
    path = tmp_path / "feedback.json"
    rows = {
        "a": {"direction": "long", "feedback": {"state": "validated"}},
        "b": {"direction": "long", "feedback": {"state": "invalidated"}},
        "c": {"direction": "short", "feedback": {"state": "validated"}},
        "d": {"direction": "short", "feedback": {"state": "invalidated"}},
    }
    path.write_text(json.dumps(rows), encoding="utf-8")
    cal = load_calibration(path)
    pb, pbase, ps, meta = scenario_probabilities(directional_score=0.8, calibration=cal)
    assert cal.long_rate == 0.5
    assert cal.short_rate == 0.5
    assert meta["long_samples"] == 2
    assert meta["short_samples"] == 2
    assert pb is None and pbase is None and ps is None
    assert meta["historical_long_validation_rate"] == 0.5
    assert meta["historical_short_validation_rate"] == 0.5


def test_scenario_schema_allows_unknown_probability():
    s = Scenario(name="bull", thesis="insufficient history", probability=None)
    assert s.probability is None
