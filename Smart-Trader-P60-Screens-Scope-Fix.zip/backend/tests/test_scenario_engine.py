import pytest
from app.services.scenario_engine import ScenarioEngine

@pytest.mark.asyncio
async def test_scenario_engine_is_conditional_and_read_only(monkeypatch):
    bars=[{"open":100,"high":101+i*0.1,"low":99-i*0.05,"close":100+i*0.05,"volume":1000,"timestamp":i,"close_time":i} for i in range(100)]
    async def fake_fetch(symbol, market, interval, limit): return bars
    monkeypatch.setattr("app.services.scenario_engine.fetch_market_klines", fake_fetch)
    monkeypatch.setattr("app.services.market_structure.fetch_market_klines", fake_fetch)
    monkeypatch.setattr("app.services.mtf_analysis.fetch_market_klines", fake_fetch)
    out=await ScenarioEngine().build("BTCUSDT","crypto","15m",100)
    assert out["data_contract"] == "scenario-analysis-v1"
    assert out["analysis_only"] is True and out["read_only"] is True
    assert len(out["scenarios"]) == 3
    assert all(x["probability"] is None for x in out["scenarios"])
    assert "收盘确认" in out["closed_candle_rule"]
