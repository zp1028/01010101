import pytest

from app.api.v1 import markets as markets_api
from app.services.market_universe import UniverseItem


@pytest.mark.asyncio
async def test_crypto_markets_does_not_require_other_market_providers(monkeypatch):
    crypto = [UniverseItem("BTCUSDT", "BTC", "crypto", "crypto", "binance", "USDT", {})]

    async def crypto_only():
        return crypto

    async def fail_other():
        raise AssertionError("non-crypto provider must not be called for crypto market")

    monkeypatch.setattr(markets_api.universe, "crypto", crypto_only)
    monkeypatch.setattr(markets_api.universe, "us", fail_other)
    monkeypatch.setattr(markets_api.universe, "hk", fail_other)
    monkeypatch.setattr(markets_api.universe, "commodities", fail_other)
    monkeypatch.setattr(markets_api, "_crypto_quotes", lambda: _quotes())

    result = await markets_api.markets(market="crypto", q=None, limit=250, offset=0, sort="symbol")
    assert result["total"] == 1
    assert result["markets"][0]["symbol"] == "BTCUSDT"
    assert result["markets"][0]["price"] == 100000.0
    assert result["markets"][0]["quote_status"] == "live"


async def _quotes():
    return {"BTCUSDT": {"price": 100000.0, "change_pct": 1.25, "volume": 123.0}}
