import pytest
from app.services.risk_map import RiskMapService

@pytest.mark.asyncio
async def test_risk_map_is_read_only_and_unifies_timeframes(monkeypatch):
    async def fake_build(self, symbol, market, timeframe, limit=200):
        base = {"5m":100,"15m":101,"30m":102,"1h":103,"4h":104,"1d":105,"1w":106}[timeframe]
        return {"available":True,"timeframe":timeframe,"last_price":base,"support":base-2,"resistance":base+2,"trend":"混合/震荡结构"}
    monkeypatch.setattr("app.services.risk_map.MarketStructureService.build", fake_build)
    out=await RiskMapService().build("BTCUSDT","crypto","15m")
    assert out["data_contract"]=="risk-map-v1"
    assert out["analysis_only"] and out["read_only"]
    assert set(out["timeframes"])=={"5m","15m","30m","1h","4h","1d","1w"}
    assert out["current_timeframe"]=="15m"
