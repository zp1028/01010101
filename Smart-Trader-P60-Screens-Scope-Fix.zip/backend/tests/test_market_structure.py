import pytest
from app.services.market_structure import MarketStructureService

@pytest.mark.asyncio
async def test_structure_contract(monkeypatch):
    bars=[]
    vals=[10,11,10.5,12,11,13,12,14,13,15,14,16,15,17,16,18,17,19,18,20,19,21,20,22,21,23,22,24,23,25,24,26,25,27,26,28,27,29,28,30]
    for i,v in enumerate(vals): bars.append({'open':v-0.2,'high':v+0.4,'low':v-0.4,'close':v,'volume':100,'timestamp':i})
    async def fake(symbol, market, interval, limit): return bars
    monkeypatch.setattr('app.services.market_structure.fetch_market_klines', fake)
    out=await MarketStructureService().build('BTCUSDT','crypto','15m',40)
    assert out['data_contract']=='market-structure-v1'
    assert out['analysis_only'] and out['read_only']
    assert out['available'] is True
    assert 'support' in out and 'resistance' in out
    assert isinstance(out['pivots'], list)
