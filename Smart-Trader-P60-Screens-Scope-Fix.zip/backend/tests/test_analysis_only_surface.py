from fastapi.testclient import TestClient

from app.main import app


def test_public_surface_is_analysis_only():
    paths = set(app.openapi().get("paths", {}))
    assert not any("/risk/account" in p for p in paths)
    assert not any("/order" in p or "/execution" in p or "/trading" in p for p in paths)
    assert not any("/wallet" in p for p in paths)


def test_health_version_matches_application():
    client = TestClient(app)
    assert client.get("/health").json()["version"] == app.version


def test_capabilities_declare_execution_disabled():
    client = TestClient(app)
    data = client.get("/api/v1/market-capabilities").json()
    assert data["execution"] == {"orders": False, "account_connection": False, "paper_trading": False}
