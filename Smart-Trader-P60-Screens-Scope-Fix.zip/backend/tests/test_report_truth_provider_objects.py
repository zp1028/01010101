from types import SimpleNamespace
from app.services.report_truth import truth


def test_unavailable_provider_object_does_not_pass_truth_gate():
    definition = SimpleNamespace(key="funding_basis", source_requirements=("funding",))
    base = {"market_enrichment": {"binance_derivatives": {"available": False, "reason": "timeout"}}}
    result = truth(definition, base, {"configured": True})
    assert result["status"] == "pending_provider"
    assert "market_enrichment.binance_derivatives.funding" in result["missing"]


def test_provider_required_status_does_not_pass_truth_gate():
    definition = SimpleNamespace(key="news_sentiment", source_requirements=("news",))
    base = {"market_enrichment": {"news": {"status": "provider_required"}}}
    result = truth(definition, base, {"configured": True})
    assert result["status"] == "pending_provider"
