from app.services.report_truth import truth
from app.services.report_registry import REGISTRY


def test_probability_never_available_without_calibration():
    d = REGISTRY["probability"]
    base = {"probability": {"status": "insufficient_history", "long": None, "short": None}}
    result = truth(d, base, {"configured": True})
    assert result["status"] == "pending_provider"
    assert "probability.status=calibrated" in result["missing"]


def test_news_requires_real_news_evidence():
    d = REGISTRY["news_sentiment"]
    result = truth(d, {"market_enrichment": {}}, {"configured": True})
    assert result["status"] == "pending_provider"
    assert "market_enrichment.news" in result["missing"]


def test_technical_can_be_available_from_real_snapshot():
    d = REGISTRY["technical"]
    base = {"evidence": {"technical": {"last_price": 100.0, "trend_label": "bullish", "sma_20": 99.0}}}
    # Paths are rooted at the report, so supply the same keys used by the truth layer.
    result = truth(d, base, {"configured": True})
    assert result["status"] == "available"


def test_unmapped_report_source_is_never_marked_available():
    d = REGISTRY["preopen_intraday"]
    result = truth(d, {"summary": "text"}, {"configured": True})
    assert result["status"] == "pending_provider"
    assert "session_context" in result["missing"]
