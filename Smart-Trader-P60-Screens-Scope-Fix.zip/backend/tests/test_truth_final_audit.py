from pathlib import Path
import ast

from app.services.report_registry import REPORTS
from app.services.report_truth import SOURCE_KEYS


def test_all_32_reports_have_mapped_source_requirements():
    assert len(REPORTS) == 32
    for row in REPORTS:
        requirements = row[-1]
        for req in requirements:
            assert req in SOURCE_KEYS, f"unmapped report source requirement: {row[1]} -> {req}"


def test_report_registry_has_no_duplicate_ids_or_keys():
    ids = [row[0] for row in REPORTS]
    keys = [row[1] for row in REPORTS]
    assert len(ids) == len(set(ids)) == 32
    assert len(keys) == len(set(keys)) == 32


def test_advice_uses_explicit_non_probability_score_type():
    text = Path("app/ai/advice.py").read_text(encoding="utf-8")
    assert 'score_type: str = "rule_evidence_score"' in text
    assert 'conviction += 0.' not in text


def test_no_fake_probability_defaults_in_calibration_module():
    text = Path("app/ai/calibration.py").read_text(encoding="utf-8")
    assert "return None, None, None" in text
    assert "0.55" not in text
    assert "0.60" not in text
    assert "0.70" not in text
