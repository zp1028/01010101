import pytest
from app.services.binance_terminal import BinanceUsdMTerminalService


@pytest.mark.asyncio
async def test_terminal_snapshot_normalizes_payload(monkeypatch):
    class Resp:
        def __init__(self, value): self.value=value
        def raise_for_status(self): pass
        def json(self): return self.value
    class Client:
        def __init__(self,*a,**k): pass
        async def __aenter__(self): return self
        async def __aexit__(self,*a): pass
        async def get(self, path):
            if "24hr" in path: return Resp({"symbol":"BTCUSDT","lastPrice":"100","priceChangePercent":"2","highPrice":"105","lowPrice":"95","volume":"10","quoteVolume":"1000","count":9,"closeTime":1000000})
            if "bookTicker" in path: return Resp({"bidPrice":"99.9","bidQty":"2","askPrice":"100.1","askQty":"3","time":1000001})
            if "depth" in path: return Resp({"lastUpdateId":7,"bids":[["99","2"]],"asks":[["101","4"]]})
            if "trades" in path: return Resp([{"id":1,"price":"100","qty":".5","isBuyerMaker":True,"time":1000002}])
            if "premiumIndex" in path: return Resp({"markPrice":"100.2","indexPrice":"100","lastFundingRate":"0.0001","nextFundingTime":1005000,"time":1000003})
            return Resp([[1000,"99","101","98","100","5",1999]])
    monkeypatch.setattr("app.services.binance_terminal.httpx.AsyncClient", Client)
    out = await BinanceUsdMTerminalService().snapshot("BTC/USDT", "15m")
    assert out["analysis_only"] is True
    assert out["symbol"] == "BTCUSDT"
    assert out["quote"]["last_price"] == 100.0
    assert out["mark"]["funding_rate"] == 0.0001
    assert out["book"]["ask"] == 100.1
    assert out["depth"]["bids"][0]["qty"] == 2.0
    assert out["trades"][0]["buyer_maker"] is True
    assert len(out["candles"]) == 1
