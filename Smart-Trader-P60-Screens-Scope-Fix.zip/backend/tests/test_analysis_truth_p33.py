from app.ai.calibration import Calibration, scenario_probabilities
from app.services.analysis_feedback import AnalysisFeedbackService

def test_scenario_probabilities_never_fabricate_mutually_exclusive_distribution():
    c = Calibration(0.8, 0.4, 20, 20, "persisted_feedback")
    bull, base, bear, meta = scenario_probabilities(directional_score=0.9, calibration=c)
    assert bull is None and base is None and bear is None
    assert meta["historical_long_validation_rate"] == 0.8
    assert meta["historical_short_validation_rate"] == 0.4

def test_feedback_confidence_is_not_rule_generated():
    report = {"indicator_report": {"trend_strength": "强趋势", "trend_sma": "bullish"}, "structure": {"state": "上升结构"}}
    assert AnalysisFeedbackService._confidence(report) == 0.0
