import asyncio

from app.services.terminal_analysis import TerminalAnalysisService


def test_terminal_analysis_is_single_read_only_contract(monkeypatch):
    service = TerminalAnalysisService()

    async def terminal(symbol, timeframe, depth_limit, trade_limit):
        return {
            "analysis_only": True,
            "symbol": "BTCUSDT",
            "freshness": {"status": "live"},
            "quote": {"last_price": 100.0},
        }

    async def analysis(symbol, market, timeframe, limit):
        return {
            "symbol": "BTC/USDT",
            "timeframe": timeframe,
            "summary": "当前处于可计算的趋势状态",
            "indicator_report": {"rsi_14": 61.0},
        }

    monkeypatch.setattr(service.terminal, "snapshot", terminal)
    monkeypatch.setattr(service.analysis, "build", analysis)
    out = asyncio.run(service.build("BTC/USDT", "1h"))
    assert out["contract"] == "terminal-analysis-v1"
    assert out["analysis_only"] is True
    assert out["read_only"] is True
    assert out["terminal"]["quote"]["last_price"] == 100.0
    assert out["analysis"]["indicator_report"]["rsi_14"] == 61.0
    assert out["integration"]["closed_candle_required"] is True
    assert "order" not in out
