from app.quant.probability import research_probability

def _bars(n=180):
    out=[]; price=100.0
    for i in range(n):
        drift=0.012 if (i//20)%2==0 else -0.010
        price*=1+drift
        out.append({'open_time':i*60000,'close_time':i*60000+59000,'open':price/(1+drift),'high':price*1.002,'low':price*0.998,'close':price,'volume':1000+(i%7)*100})
    return out

def test_probability_requires_real_history():
    r=research_probability(_bars(50)); assert r.status=='insufficient_history'; assert r.long_probability is None

def test_probability_walk_forward_oos():
    r=research_probability(_bars()); assert r.method=='expanding_walk_forward'; assert r.train_samples>0; assert r.calibration_samples>0; assert r.oos_samples>0; assert r.brier_long is not None and r.brier_short is not None
