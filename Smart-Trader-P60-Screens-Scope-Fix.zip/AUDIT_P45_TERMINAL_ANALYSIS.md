# P45 Audit — Terminal + Analysis Truth

## 数据边界
1. Terminal 层只接受 provider market snapshot。
2. Analysis 层按用户选择的 timeframe 重新拉取/计算 K 线指标。
3. 未收盘 K 线只作为 live observation；结构性突破/跌破要求周期收盘确认。
4. 缺失 provider 数据不使用固定值替代。
5. 分析评分/情景评分不是预测概率。

## UI 边界
详情页现在形成：
`K线 → USDⓈ-M Terminal → Smart Analysis → 数据能力 → 衍生品结构 → 多交易所 → 完整报告 → 指标 → 多空情景 → 报告中心 → MTF`

## 执行边界
P45 新增契约没有 account/order/wallet/execution 字段；产品仍为只读市场研究与情景分析。

## 测试
97 个 backend tests 全部通过。
Android 编译因当前环境无法下载 Gradle 8.9 未验证成功。
