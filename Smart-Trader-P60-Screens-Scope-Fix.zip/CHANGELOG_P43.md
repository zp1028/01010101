# P43 — Binance USDⓈ-M + Data Layer Optimization

## Core change
- Crypto market discovery is now **Binance USDⓈ-M Futures only**. Spot exchangeInfo is no longer merged into the crypto universe.
- Quote source is Binance USDⓈ-M Futures REST: 24h ticker + bookTicker + mark price/funding.
- Instrument detail crypto candles now use Binance USDⓈ-M Futures klines instead of Spot klines.
- WebSocket subscriptions now include `markPrice@1s`; funding events are normalized into the EventBus.

## Data-layer rules
- Provider payloads stay below the normalization boundary.
- Market rows expose source, USD-M type, quote currency, data timestamps and quote freshness state.
- No fixed crypto watchlist or synthetic price is introduced.
- Provider failure preserves a last-known cache only when it exists; it never manufactures a new price.
- US/HK/commodity feeds remain separate providers because Binance USDⓈ-M is a crypto derivatives market, not a universal stock/commodity quote feed.

## Verification
- Backend tests cover USD-M normalization and USD-M-only filtering.
- Android APK compilation still depends on the external Gradle distribution being reachable in CI.
- Android direct market fallback and candle fallback now use Binance USDⓈ-M Futures (`fapi.binance.com`) rather than Spot/CoinGecko.


## P43.1 — Binance USD-M 分类修复

- Binance USD-M 行情分类不再从 `ticker/24hr` 读取不存在的 `quoteAsset`。
- 新增 `exchangeInfo` → symbol metadata 映射，以真实 `quoteAsset`、`contractType`、`status` 判定可用 U 本位合约。
- 仅接受 `USDT/USDC` + `PERPETUAL/CURRENT_QUARTER/NEXT_QUARTER` + `TRADING`。
- 后端统一输出 `contract_type`、`market_data_type`、`base_asset`、`pair`。
- Android 无后端直连 fallback 同样先拉 `exchangeInfo` 再解析 ticker，避免误把 Spot/COIN-M 当作 USD-M。
- 市场列表 UI 显示 `USD-M · PERPETUAL` 等真实分类。
- 回归测试：95 passed。
