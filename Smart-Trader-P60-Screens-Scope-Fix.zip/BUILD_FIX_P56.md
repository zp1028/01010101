# Smart Trader P56 — Android assembleDebug 编译修复

## 本次 CI 错误
1. `RestClient.kt` 的风险地图/多空情景解析调用了不存在的 `get(url)`，同时缺少 `org.json.JSONArray` 导入。
2. `Screens.kt` 缺少 `Modifier.clip` 与 `RoundedCornerShape` 导入。
3. `SmartAnalysisCard` 是普通 `@Composable`，内部错误使用 LazyColumn 专属的 `item {}`。
4. `DetailScreen` 在 LazyColumn 中直接调用 `SmartAnalysisCard(state)`，缺少 `item {}` 包装。

## 修复
- 增加 JSON `JSONArray` 导入。
- 为无类实例上下文的两个解析请求增加真实 OkHttp GET helper，并保留 HTTP 非 2xx 错误传播。
- 增加 Compose `clip` / `RoundedCornerShape` imports。
- 移除 `SmartAnalysisCard` 内部错误的 `item {}`，保留普通 Compose 布局。
- 在 `DetailScreen` 中使用 `item { SmartAnalysisCard(state) }`。

## 数据真实性
本次没有加入模拟行情、固定价格、假分析或静态测试数据；修复只处理 Kotlin/Compose 编译与真实 HTTP JSON 解析路径。

## 验证
本地环境尝试执行 `./gradlew :app:compileDebugKotlin --no-daemon`，但 Gradle 8.9 distribution 无法从 `services.gradle.org` 下载，因 DNS/网络环境 `UnknownHostException` 中断。因此不能声称本地 APK 已成功构建。

目标：将此包直接作为 GitHub Actions `assembleDebug` 的下一版源码输入，继续暴露剩余真实编译错误。
