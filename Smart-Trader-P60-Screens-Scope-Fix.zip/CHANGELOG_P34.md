# Smart Trader P34 — Walk-forward probability truth

## Core change
Added a transparent empirical probability research engine. Scenario probabilities are now only exposed when historical bar samples are available and a train/calibration/OOS walk-forward process produces measurable out-of-sample Brier scores.

## No fake probability
- No fixed Bull/Base/Bear percentages.
- No fixed predictive confidence used as probability.
- Insufficient history => probability is `null` with explicit status.
- Historical feedback rates remain conditional statistics, not mutually exclusive scenario probabilities.

## Method
- Features at each historical point use only bars available at that point.
- Future bars are used only for the outcome label.
- Train 70% / calibration 15% / OOS 15% of generated samples.
- Transparent score from trend, MACD histogram, RSI and Bollinger position.
- Quantile-bin empirical probability with Laplace smoothing.
- Calibration-bin selection does not use OOS outcomes.
- Current probability is generated from historical data preceding the current observation.
- Brier scores are reported on independent OOS samples.

## Test
Backend: 83 passed.
Python compileall: required before release packaging.
Android APK build is not claimed here unless CI actually compiles it.
