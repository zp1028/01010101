# Smart Trader P48 — Professional Indicator & Structure Layer

## Changes
- Added a real-time indicator visualization layer to the instrument detail screen.
- RSI(14) series and MACD histogram are recalculated from the currently loaded timeframe candles; no fixed/demo series are used.
- Added explicit 30/50/70 RSI reference levels and human-readable interpretation.
- Added MACD histogram zero line and current momentum interpretation.
- Kept backend indicator engine as the source for full indicator reports (RSI, MACD, ADX, Bollinger, DMI, MFI, CCI, structure and divergence).
- Timeframe changes continue to trigger a fresh candle/indicator calculation.
- No order, account, wallet, simulation or execution behavior was introduced.

## Validation
- Backend test suite executed after P48 changes.
- Python compileall executed after P48 changes.
- Android Gradle compilation was attempted separately; success is not claimed when the environment cannot download the configured Gradle distribution.
