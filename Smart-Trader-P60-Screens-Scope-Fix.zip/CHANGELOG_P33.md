# P33 Changelog

- Removed hard-coded predictive confidence from AnalysisFeedbackService.
- Added explicit `confidence_status=uncalibrated`.
- Removed pseudo Bull/Base/Bear probability conversion from separate long/short validation rates.
- Missing analysis confidence no longer defaults to 0.3.
- Added truth regression tests for probability and feedback confidence.
- Kept deterministic indicator thresholds as transparent analysis rules, not probabilities.
