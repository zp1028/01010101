# P51 Audit — Holding Observation

## Scope
实时持仓观察、结构风险节点、用户提供持仓上下文。

## Truth checks
1. 默认不读取账户/交易所持仓。
2. 默认 `side=null`、`entry_price=null`，仅输出市场风险观察。
3. 只有用户显式提供方向和参考入场价才计算参考变动百分比。
4. 支撑/阻力距离来自当前分析周期结构，不是固定常数。
5. 风险节点由当前价格与结构边界、RSI、MACD 条件动态生成。
6. 结构失效仍要求周期收盘确认。
7. API 标记 `analysis_only=true`、`read_only=true`。

## Validation
- Backend pytest: 101 passed.
- Python compileall: PASS.
- Android Gradle build: 本轮未宣称通过；此前环境存在 Gradle 8.9 下载/DNS 限制。
