# P33 Analysis Truth Audit

## Core rule
Predictive probability and predictive confidence are never synthesized from fixed percentages or indicator heuristics.

## Changes
- Historical feedback confidence no longer uses fixed trend values such as 0.78/0.66/0.52.
- Until a calibrated predictive model exists, historical report confidence is `0` with `confidence_status=uncalibrated`; UI must render it as 未校准 rather than 0% prediction accuracy.
- Long/short validation rates remain conditional historical statistics. They are not converted into mutually-exclusive Bull/Base/Bear probabilities. Scenario probability fields therefore remain null until a properly trained/calibrated model exists.
- Missing sentiment/news/macro/on-chain inputs remain explicitly unavailable and do not become neutral predictive evidence.
- Advice without a real analysis object no longer starts from a fabricated 0.3 confidence.

## Still legitimate deterministic parameters
RSI 30/70, oscillator thresholds, Bollinger bands, MA periods and structural rules are analysis definitions. They are not market data and must be labelled as rule-based indicators, not probabilities.

## Remaining work
A true probability model still requires point-in-time feature snapshots, outcome labels, train/validation separation, walk-forward evaluation, calibration (e.g. reliability/Brier metrics), and per-market/timeframe conditioning before probabilities can be displayed.
