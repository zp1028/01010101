package com.smarttrader.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlin.math.max
import kotlin.math.min
import com.smarttrader.app.ui.components.*
import com.smarttrader.app.ui.theme.*
import com.smarttrader.app.viewmodel.AppState
import com.smarttrader.app.network.ApiConfig

@Composable
fun DiscoverScreen(state: AppState) {
    val topGainers = state.markets.sortedByDescending { it.changePct }.take(5)
    val topLosers = state.markets.sortedBy { it.changePct }.take(5)
    val active = state.markets.sortedByDescending { it.attention }.take(5)
    val favorites = state.markets.filter { it.symbol in state.favorites }.take(6)
    val feed = state.analysisFeed?.items.orEmpty()
    val tabs = listOf("crypto" to "加密", "us" to "美股", "hk" to "港股", "commodities" to "大宗")

    LazyColumn(
        Modifier.fillMaxSize().background(Bg),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("发现", style = MaterialTheme.typography.displaySmall, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                    Text("实时行情 → 信号 → 分析报告", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                }
                TagChip(
                    if (state.live) "LIVE" else if (state.backendOnline) "ONLINE" else "行情直连",
                    if (state.live) Bull else if (state.backendOnline) Accent else Warn,
                )
            }
        }

        item {
            AppCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("高置信度分析", style = MaterialTheme.typography.titleMedium, color = Accent, fontWeight = FontWeight.SemiBold)
                        Text("${state.timeframe} · 历史报告冻结，后续行情单独反馈", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    }
                    TagChip("${feed.size} 条", Accent)
                }
                Spacer(Modifier.height(8.dp))
                if (feed.isEmpty()) {
                    Text(
                        if (state.backendOnline) "正在等待分析引擎产生有效报告…" else "后端分析暂不可用；行情列表仍可直接读取公开市场数据。",
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodySmall,
                    )
                } else {
                    feed.take(4).forEach { item ->
                        Row(
                            Modifier.fillMaxWidth().clickable { state.openDetail(item.symbol, item.market) }.padding(vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(item.symbol, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                                Text(item.summary, color = TextSecondary, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                                if (item.feedbackSummary.isNotBlank()) Text("反馈：${item.feedbackSummary}", color = TextMuted, style = MaterialTheme.typography.labelSmall, maxLines = 2)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                TagChip("${(item.confidence * 100).toInt()}%", if (item.confidence >= .75) Bull else Accent)
                                Spacer(Modifier.height(3.dp))
                                TagChip(
                                    when (item.direction) { "long" -> "多头"; "short" -> "空头"; else -> "观察" },
                                    when (item.direction) { "long" -> Bull; "short" -> Bear; else -> Neutral },
                                )
                            }
                        }
                        HorizontalDivider(color = Border.copy(alpha = .45f))
                    }
                }
            }
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("已载入", state.markets.size.toString(), "当前市场页", Modifier.weight(1f))
                StatCard("上涨", state.markets.count { it.changePct > 0 }.toString(), "24H", Modifier.weight(1f))
                StatCard("下跌", state.markets.count { it.changePct < 0 }.toString(), "24H", Modifier.weight(1f))
            }
        }

        item {
            AppCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("市场分类", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    Text("切换后进入完整市场扫描", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    tabs.forEach { (key, label) ->
                        FilterChip(selected = state.marketCategory == key, onClick = { state.loadUniverse(key, null) }, label = { Text(label) })
                    }
                }
            }
        }

        if (favorites.isNotEmpty()) {
            item {
                AppCard {
                    Text("自选观察", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    Spacer(Modifier.height(6.dp))
                    favorites.forEach { m ->
                        CompactMarketRow(m) { state.openDetail(m.symbol, m.assetClass) }
                    }
                }
            }
        }

        item {
            AppCard {
                Text("强势异动", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                Spacer(Modifier.height(6.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    topGainers.take(4).forEach { m ->
                        MiniMarketCard(m, "强势") { state.openDetail(m.symbol, m.assetClass) }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("弱势观察", style = MaterialTheme.typography.labelLarge, color = TextMuted)
                topLosers.take(4).forEach { m ->
                    CompactMarketRow(m) { state.openDetail(m.symbol, m.assetClass) }
                }
            }
        }

        item {
            AppCard {
                Text("高关注品种", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                Spacer(Modifier.height(6.dp))
                active.forEach { m ->
                    CompactMarketRow(m) { state.openDetail(m.symbol, m.assetClass) }
                }
                Text("完整品种搜索、排序、分页请进入「市场」", color = TextMuted, style = MaterialTheme.typography.labelSmall)
            }
        }

        item {
            if (state.errorMessage != null) {
                AppCard {
                    Text("数据状态", color = Warn, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(4.dp))
                    Text(state.errorMessage.orEmpty(), color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
fun MarketScreen(state: AppState) {
    var query by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(state.marketSearch) }
    val filtered = state.markets
        .filter { query.isBlank() || it.symbol.contains(query, true) || it.name.contains(query, true) }
        .filter { when (state.marketFilter) { "gainers" -> it.changePct > 0.0; "losers" -> it.changePct < 0.0; "active" -> it.attention >= 0.35; "favorites" -> it.symbol in state.favorites; else -> true } }
        .sortedWith(compareByDescending<com.smarttrader.app.data.MarketItem> {
            when (state.marketSort) { "attention" -> it.attention; "price" -> it.price.replace(",", "").toDoubleOrNull() ?: 0.0; else -> it.changePct }
        })

    Column(Modifier.fillMaxSize().background(Bg)) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("市场", style = MaterialTheme.typography.headlineLarge, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                    Text("完整市场扫描 · 只读分析 · ${state.markets.size} 个当前载入品种", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                }
                TagChip(if (state.backendOnline) "ONLINE" else "MARKET LIVE", if (state.backendOnline) Accent else Bull)
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("crypto" to "加密", "us" to "美股", "hk" to "港股", "commodities" to "大宗").forEach { (key, label) ->
                    FilterChip(selected = state.marketCategory == key, onClick = { query = ""; state.loadUniverse(key, null) }, label = { Text(label) })
                }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it; state.loadUniverse(state.marketCategory, it.ifBlank { null }) },
                modifier = Modifier.fillMaxWidth(), singleLine = true,
                placeholder = { Text("搜索全部品种 / 公司名称") }, label = { Text("市场搜索") },
            )
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("change" to "涨跌幅", "attention" to "关注度", "price" to "价格").forEach { (k, l) ->
                    FilterChip(selected = state.marketSort == k, onClick = { state.marketSort = k }, label = { Text(l) })
                }
                listOf("all" to "全部", "gainers" to "上涨", "losers" to "下跌", "active" to "活跃", "favorites" to "自选").forEach { (k, l) ->
                    FilterChip(selected = state.marketFilter == k, onClick = { state.marketFilter = k }, label = { Text(l) })
                }
            }
        }
        Row(Modifier.fillMaxWidth().background(SurfaceAlt).padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("品种 / 市场", color = TextMuted, style = MaterialTheme.typography.labelSmall)
            Text("最新 / 24H", color = TextMuted, style = MaterialTheme.typography.labelSmall)
        }
        LazyColumn(contentPadding = PaddingValues(bottom = 92.dp)) {
            items(filtered) { m ->
                Row(Modifier.fillMaxWidth().clickable { state.openDetail(m.symbol, m.assetClass) }.padding(horizontal = 12.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { state.toggleFavorite(m.symbol) }) {
                        Icon(if (m.symbol in state.favorites) Icons.Outlined.Star else Icons.Outlined.StarBorder, contentDescription = "自选", tint = if (m.symbol in state.favorites) Accent else TextMuted)
                    }
                    Column(Modifier.weight(1f)) {
                        Text(m.symbol, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                        Text("${m.name} · ${m.venue.ifBlank { m.assetClass.uppercase() }}", color = TextMuted, style = MaterialTheme.typography.labelSmall)
                        if (m.marketDataType.isNotBlank() || m.contractType.isNotBlank()) {
                            Text(
                                listOfNotNull(
                                    m.marketDataType.takeIf { it.isNotBlank() },
                                    m.contractType.takeIf { it.isNotBlank() }
                                ).joinToString(" · "),
                                color = Accent,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(m.price, color = TextPrimary, fontWeight = FontWeight.Medium)
                        Text(if (m.quoteStatus == "live") "实时" else "${m.quoteStatus}", color = if (m.quoteStatus == "live") Bull else Warn, style = MaterialTheme.typography.labelSmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                            PctBadge(m.changePct)
                            if (m.currency.isNotBlank()) Text(m.currency, color = TextMuted, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                HorizontalDivider(color = Border.copy(alpha = .55f))
            }
            if (state.hasMoreMarkets) {
                item {
                    AppCard(Modifier.fillMaxWidth().clickable { state.loadMoreMarkets() }) {
                        Text(if (state.loadingMoreMarkets) "正在加载更多品种…" else "加载更多 · 当前 ${state.markets.size} 个", modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center, color = Accent)
                    }
                }
            }
            if (filtered.isEmpty()) {
                item {
                    AppCard {
                        Text("当前没有匹配的实时品种", color = TextSecondary)
                        Text(
                            if (state.errorMessage != null) state.errorMessage!! else "正在等待实时数据源返回品种。",
                            color = TextMuted, style = MaterialTheme.typography.labelSmall
                        )
                        Text("刷新不会生成模拟数据；只有真实 provider 返回后才会进入列表。", color = TextMuted, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatCard(title: String, value: String, note: String, modifier: Modifier = Modifier) {
    AppCard(modifier) {
        Text(title, color = TextMuted, style = MaterialTheme.typography.labelSmall)
        Spacer(Modifier.height(3.dp))
        Text(value, color = TextPrimary, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        Text(note, color = TextMuted, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun CompactMarketRow(m: com.smarttrader.app.data.MarketItem, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 7.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(m.symbol, color = TextPrimary, fontWeight = FontWeight.SemiBold)
            Text(m.name, color = TextMuted, style = MaterialTheme.typography.labelSmall)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(m.price, color = TextPrimary, fontWeight = FontWeight.Medium)
            PctBadge(m.changePct)
        }
    }
}

@Composable
private fun MiniMarketCard(m: com.smarttrader.app.data.MarketItem, label: String, onClick: () -> Unit) {
    AppCard(Modifier.width(145.dp).clickable(onClick = onClick)) {
        Text(label, color = Bull, style = MaterialTheme.typography.labelSmall)
        Spacer(Modifier.height(3.dp))
        Text(m.symbol, color = TextPrimary, fontWeight = FontWeight.SemiBold)
        Text(m.price, color = TextPrimary)
        PctBadge(m.changePct)
    }
}

private fun sma(values: List<Double>, period: Int): List<Double?> {
    if (period <= 0) return List(values.size) { null }
    return values.indices.map { index ->
        if (index + 1 < period) null else values.subList(index + 1 - period, index + 1).average()
    }
}


private fun emaSeries(values: List<Double>, period: Int): List<Double> {
    if (values.isEmpty()) return emptyList()
    val alpha = 2.0 / (period + 1.0)
    val out = ArrayList<Double>(values.size)
    var prev = values.first()
    out += prev
    for (i in 1 until values.size) {
        prev = alpha * values[i] + (1.0 - alpha) * prev
        out += prev
    }
    return out
}

private fun rsiSeries(values: List<Double>, period: Int = 14): List<Double> {
    if (values.size < period + 1) return emptyList()
    val out = MutableList(values.size) { Double.NaN }
    var gains = 0.0
    var losses = 0.0
    for (i in 1..period) {
        val d = values[i] - values[i - 1]
        if (d >= 0) gains += d else losses -= d
    }
    fun rsi(): Double = if (losses == 0.0) 100.0 else 100.0 - 100.0 / (1.0 + gains / losses)
    out[period] = rsi()
    for (i in period + 1 until values.size) {
        val d = values[i] - values[i - 1]
        val gain = max(d, 0.0)
        val loss = max(-d, 0.0)
        gains = (gains * (period - 1) + gain) / period
        losses = (losses * (period - 1) + loss) / period
        out[i] = rsi()
    }
    return out
}

private fun macdHistogramSeries(values: List<Double>): List<Double> {
    if (values.isEmpty()) return emptyList()
    val fast = emaSeries(values, 12)
    val slow = emaSeries(values, 26)
    val line = values.indices.map { fast[it] - slow[it] }
    val signal = emaSeries(line, 9)
    return line.indices.map { line[it] - signal[it] }
}

@Composable
private fun IndicatorAnalysisCharts(candles: List<com.smarttrader.app.network.CandleDto>, timeframe: String) {
    if (candles.size < 30) return
    val visible = candles.takeLast(120)
    val closes = visible.map { it.close }
    val rsi = rsiSeries(closes).mapIndexed { i, v -> if (v.isNaN()) null else v }
    val hist = macdHistogramSeries(closes)
    val lastRsi = rsi.lastOrNull { it != null }
    val lastHist = hist.lastOrNull()
    AppCard {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("指标分析 · $timeframe", color = TextPrimary, fontWeight = FontWeight.SemiBold)
                Text("RSI / MACD 由当前周期 K 线实时重算；未收盘数据仅作观察", color = TextMuted, style = MaterialTheme.typography.labelSmall)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                TagChip("RSI ${lastRsi?.let { "%.1f".format(it) } ?: "—"}", if ((lastRsi ?: 50.0) >= 70) Bear else if ((lastRsi ?: 50.0) <= 30) Bull else Neutral)
                TagChip("MACD ${lastHist?.let { if (it >= 0) "多" else "空" } ?: "—"}", if ((lastHist ?: 0.0) >= 0) Bull else Bear)
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("RSI(14)", color = TextMuted, style = MaterialTheme.typography.labelSmall)
        Canvas(Modifier.fillMaxWidth().height(110.dp)) {
            val valid = rsi
            fun y(v: Double) = size.height - (v / 100.0 * size.height).toFloat()
            listOf(30.0, 50.0, 70.0).forEach { level ->
                val yy = y(level)
                drawLine(TextMuted.copy(alpha = if (level == 50.0) .12f else .25f), Offset(0f, yy), Offset(size.width, yy), 1f)
            }
            val path = Path(); var started = false
            valid.forEachIndexed { i, v ->
                if (v == null) return@forEachIndexed
                val x = i * size.width / max(1, valid.size - 1)
                val yy = y(v)
                if (!started) { path.moveTo(x, yy); started = true } else path.lineTo(x, yy)
            }
            drawPath(path, Accent, style = Stroke(width = 2f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("30 超卖", color = Bull, style = MaterialTheme.typography.labelSmall)
            Text("50 中性", color = TextMuted, style = MaterialTheme.typography.labelSmall)
            Text("70 超买", color = Bear, style = MaterialTheme.typography.labelSmall)
        }
        Spacer(Modifier.height(10.dp))
        Text("MACD Histogram", color = TextMuted, style = MaterialTheme.typography.labelSmall)
        Canvas(Modifier.fillMaxWidth().height(100.dp)) {
            val maxAbs = hist.maxOfOrNull { kotlin.math.abs(it) }?.coerceAtLeast(1e-9) ?: 1.0
            val zero = size.height / 2f
            drawLine(TextMuted.copy(alpha = .2f), Offset(0f, zero), Offset(size.width, zero), 1f)
            hist.forEachIndexed { i, v ->
                val x = i * size.width / max(1, hist.size - 1)
                val barW = max(1f, size.width / hist.size * .7f)
                val h = (kotlin.math.abs(v) / maxAbs * (size.height * .45f)).toFloat()
                val top = if (v >= 0) zero - h else zero
                drawRect(if (v >= 0) Bull.copy(alpha = .65f) else Bear.copy(alpha = .65f), Offset(x - barW / 2f, top), androidx.compose.ui.geometry.Size(barW, h))
            }
        }
        Text(
            when {
                lastRsi != null && lastRsi > 70 -> "RSI 当前偏热：超买本身不等于反转，需要结合趋势、结构与 MACD 判断。"
                lastRsi != null && lastRsi < 30 -> "RSI 当前偏冷：超卖本身不等于反转，需要观察止跌结构与 MACD 是否修复。"
                lastHist != null && lastHist > 0 -> "MACD 柱当前为正，短线动能偏多；若柱体持续收缩，需要关注动能衰减。"
                lastHist != null -> "MACD 柱当前为负，短线动能偏空；若柱体持续收缩，需要关注空头动能减弱。"
                else -> "当前指标数据不足。"
            }, color = TextSecondary, style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun CandleChart(candles: List<com.smarttrader.app.network.CandleDto>) {
    if (candles.isEmpty()) { AppCard { EmptyHint("暂无K线数据；当前数据源未提供历史K线") }; return }
    val visible=candles.takeLast(160); val closes=visible.map{it.close}; val ma20=sma(closes,20); val ma50=sma(closes,50)
    val minP=visible.minOf{it.low}; val maxP=visible.maxOf{it.high}; val span=max(maxP-minP,maxP*0.0001); val maxVol=visible.maxOf{it.volume}.coerceAtLeast(1.0)
    val recent=visible.takeLast(min(60,visible.size)); val support=recent.minOf{it.low}; val resistance=recent.maxOf{it.high}; val last=visible.last(); val lastIsUp=last.close>=last.open
    AppCard {
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){ Column{Text("K线 / Volume / Structure",color=TextPrimary,fontWeight=FontWeight.SemiBold); Text("实时K线 · 指标与结构均由当前周期真实数据计算",color=TextMuted,style=MaterialTheme.typography.labelSmall)}; Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){TagChip("MA20",Accent);TagChip("MA50",Neutral);TagChip("S/R",Warn)} }
        Spacer(Modifier.height(8.dp))
        Canvas(Modifier.fillMaxWidth().height(320.dp)) {
            val dx=size.width/visible.size; val priceHeight=size.height*0.72f; val volTop=size.height*0.78f
            fun y(v:Double)=priceHeight-((v-minP)/span*priceHeight).toFloat()
            for(g in 1..4){val gy=priceHeight*g/5f;drawLine(TextMuted.copy(alpha=0.16f),Offset(0f,gy),Offset(size.width,gy),strokeWidth=1f)}
            drawLine(Warn.copy(alpha=0.65f),Offset(0f,y(resistance)),Offset(size.width,y(resistance)),strokeWidth=1.2f)
            drawLine(Bull.copy(alpha=0.65f),Offset(0f,y(support)),Offset(size.width,y(support)),strokeWidth=1.2f)
            visible.forEachIndexed{i,c->val x=i*dx+dx/2f;val up=c.close>=c.open;drawLine(if(up)Bull else Bear,Offset(x,y(c.high)),Offset(x,y(c.low)),strokeWidth=1.5f);val top=y(max(c.open,c.close));val bottom=y(min(c.open,c.close));val w=max(2f,dx*0.58f);drawRect(if(up)Bull else Bear,Offset(x-w/2,top),androidx.compose.ui.geometry.Size(w,max(2f,bottom-top)));val vh=((c.volume/maxVol)*(size.height-volTop)).toFloat();drawRect((if(up)Bull else Bear).copy(alpha=0.48f),Offset(x-w/2,size.height-vh),androidx.compose.ui.geometry.Size(w,vh))}
            fun drawMa(values:List<Double?>,tone:androidx.compose.ui.graphics.Color){val path=Path();var started=false;values.forEachIndexed{i,v->if(v==null)return@forEachIndexed;val x=i*dx+dx/2f;val py=y(v);if(!started){path.moveTo(x,py);started=true}else path.lineTo(x,py)};drawPath(path,tone,style=Stroke(width=2f))}
            drawMa(ma20,Accent);drawMa(ma50,TextMuted);val lx=visible.lastIndex*dx+dx/2f;drawLine(if(lastIsUp)Bull else Bear,Offset(lx,0f),Offset(lx,priceHeight),strokeWidth=1f)
        }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("支撑 ${"%.4f".format(support)}",color=Bull,style=MaterialTheme.typography.labelSmall);Text("最新 ${"%.4f".format(closes.last())}",color=TextPrimary,style=MaterialTheme.typography.labelSmall);Text("阻力 ${"%.4f".format(resistance)}",color=Bear,style=MaterialTheme.typography.labelSmall)}
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("MA20 ${ma20.lastOrNull()?.let{"%.4f".format(it)} ?: "—"}",color=Accent,style=MaterialTheme.typography.labelSmall);Text("MA50 ${ma50.lastOrNull()?.let{"%.4f".format(it)} ?: "—"}",color=TextMuted,style=MaterialTheme.typography.labelSmall);Text(if(lastIsUp)"最新K线 多头" else "最新K线 空头",color=if(lastIsUp)Bull else Bear,style=MaterialTheme.typography.labelSmall)}
    }
}

@Composable
private fun BinanceTerminalCard(t: com.smarttrader.app.network.TerminalSnapshotDto) {
    val live = t.freshness.status == "live"
    val last = t.quote.lastPrice
    val spread = if (t.book.ask != null && t.book.bid != null) t.book.ask!! - t.book.bid!! else null
    val mid = if (t.book.ask != null && t.book.bid != null) (t.book.ask!! + t.book.bid!!) / 2.0 else null
    AppCard {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("USDⓈ-M MARKET", style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                Text("${t.symbol} · ${t.provider.uppercase()} · ${t.marketDataType}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
            }
            TagChip(if (live) "LIVE" else "STALE", if (live) Bull else Warn)
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TerminalMetric("Last", last?.let { "%.4f".format(it) } ?: "—", Modifier.weight(1f))
            TerminalMetric("24H", t.quote.changePct?.let { "%+.2f%%".format(it) } ?: "—", Modifier.weight(1f), t.quote.changePct?.let { if (it >= 0) Bull else Bear } ?: TextPrimary)
            TerminalMetric("Mark", t.mark.markPrice?.let { "%.4f".format(it) } ?: "—", Modifier.weight(1f))
            TerminalMetric("Index", t.mark.indexPrice?.let { "%.4f".format(it) } ?: "—", Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TerminalMetric("Funding", t.mark.fundingRate?.let { "%.5f%%".format(it * 100) } ?: "—", Modifier.weight(1f))
            TerminalMetric("Mid", mid?.let { "%.4f".format(it) } ?: "—", Modifier.weight(1f))
            TerminalMetric("Spread", spread?.let { "%.5f".format(it) } ?: "—", Modifier.weight(1f))
            TerminalMetric("24H Vol", t.quote.quoteVolume?.let { "%.2f".format(it) } ?: "—", Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            TerminalOrderBook(t, Modifier.weight(1.2f))
            TerminalTradeTape(t, Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        Text("数据新鲜度  Quote ${t.freshness.quoteMs ?: -1}ms · Mark ${t.freshness.markMs ?: -1}ms · Book ${t.freshness.bookMs ?: -1}ms · Server ${t.serverTime}", color = TextMuted, style = MaterialTheme.typography.labelSmall)
        Text("只读市场终端：盘口、成交、Funding、Mark/Index 仅用于分析，不提供订单、账户、钱包或执行。", color = TextMuted, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun TerminalMetric(label: String, value: String, modifier: Modifier = Modifier, valueColor: androidx.compose.ui.graphics.Color = TextPrimary) {
    Column(modifier.clip(RoundedCornerShape(8.dp)).background(SurfaceAlt).padding(horizontal = 8.dp, vertical = 7.dp)) {
        Text(label, color = TextMuted, style = MaterialTheme.typography.labelSmall)
        Spacer(Modifier.height(2.dp))
        Text(value, color = valueColor, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun TerminalOrderBook(t: com.smarttrader.app.network.TerminalSnapshotDto, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text("ORDER BOOK", color = Accent, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Bid", color = Bull, style = MaterialTheme.typography.labelSmall)
            Text("Ask", color = Bear, style = MaterialTheme.typography.labelSmall)
        }
        val rows = max(t.depthBids.size, t.depthAsks.size).coerceAtMost(6)
        for (i in 0 until rows) {
            val bid = t.depthBids.getOrNull(i)
            val ask = t.depthAsks.getOrNull(i)
            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(bid?.let { "%.4f  %.3f".format(it.price, it.qty) } ?: "—", color = Bull, style = MaterialTheme.typography.labelSmall)
                Text(ask?.let { "%.4f  %.3f".format(it.price, it.qty) } ?: "—", color = Bear, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun TerminalTradeTape(t: com.smarttrader.app.network.TerminalSnapshotDto, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text("TRADES", color = Accent, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Price", color = TextMuted, style = MaterialTheme.typography.labelSmall)
            Text("Qty", color = TextMuted, style = MaterialTheme.typography.labelSmall)
            Text("Side", color = TextMuted, style = MaterialTheme.typography.labelSmall)
        }
        t.trades.take(6).forEach { tr ->
            val sell = tr.buyerMaker == true
            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(tr.price?.let { "%.4f".format(it) } ?: "—", color = if (sell) Bear else Bull, style = MaterialTheme.typography.labelSmall)
                Text(tr.qty?.let { "%.4f".format(it) } ?: "—", color = TextSecondary, style = MaterialTheme.typography.labelSmall)
                Text(if (sell) "SELL" else "BUY", color = if (sell) Bear else Bull, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun SmartAnalysisCard(state: AppState) {
    val ind = state.indicator ?: return
    AppCard {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Smart Analysis", style = MaterialTheme.typography.titleMedium, color = Accent, fontWeight = FontWeight.SemiBold)
                Text("行情事实 → 指标 → 结构 → 多周期 → 情景", style = MaterialTheme.typography.labelSmall, color = TextMuted)
            }
            TagChip(ind.timeframe, Accent)
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TagChip("趋势 ${ind.trendLabel}", if (ind.trendLabel == "上涨") Bull else if (ind.trendLabel == "下跌") Bear else Neutral)
            TagChip("强度 ${ind.trendStrength}", Neutral)
            TagChip("超买 ${ind.overboughtCount}", if (ind.overboughtCount > 0) Bear else Neutral)
            TagChip("超卖 ${ind.oversoldCount}", if (ind.oversoldCount > 0) Bull else Neutral)
        }
        Spacer(Modifier.height(8.dp))
        Text(ind.narrative.ifBlank { ind.summary }, color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(7.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("RSI ${ind.rsi ?: "—"}", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
            Text("MACD ${ind.macdHist ?: "—"}", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
            Text("BB ${ind.bbPct ?: "—"}", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
            Text("背离 ${ind.divergence.ifBlank { "无" }}", color = TextSecondary, style = MaterialTheme.typography.bodySmall, maxLines = 1)
        }
        if (ind.structureNote.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Text("结构：${ind.structureNote}", color = TextPrimary, style = MaterialTheme.typography.bodySmall)
        }
        state.scenarioAnalysis?.let { sa ->
            AppCard {
                    Text("实时多空情景", style = MaterialTheme.typography.titleMedium, color = Accent)
                    Spacer(Modifier.height(6.dp))
                    Text("${sa.timeframe} · ${sa.trend} · ${sa.mtfResonance} · 当前价 ${sa.lastPrice?.let { "%.6f".format(it) } ?: "—"}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    Spacer(Modifier.height(8.dp))
                    sa.scenarios.forEach { sc ->
                        val tone = when (sc.name) { "bull" -> Bull; "bear" -> Bear; else -> Neutral }
                        AppCard {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text(sc.label, style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                                TagChip(if (sc.status == "active_observation") "观察中" else "条件情景", tone)
                            }
                            Spacer(Modifier.height(4.dp))
                            Text("触发：${sc.trigger}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                            Text("观察区：${sc.observationZone}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                            Text("失效：${sc.invalidation}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                            Text("路径：${sc.targets}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                            sc.reasons.take(3).forEach { Text("· $it", style = MaterialTheme.typography.labelSmall, color = TextMuted) }
                            Text("概率：${sc.probability?.let { "%.1f%%".format(it * 100) } ?: "未校准"}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        }
                        Spacer(Modifier.height(6.dp))
                    }
                    sa.holdingObservation?.let { ho ->
                        Spacer(Modifier.height(8.dp))
                        AppCard {
                            Text("持仓观察 / 风险节点", style = MaterialTheme.typography.titleSmall, color = Accent)
                            Spacer(Modifier.height(4.dp))
                            Text("${ho.riskLevel} · ${if (ho.contextSource == "user_supplied") "用户提供上下文" else "仅市场状态"}", style = MaterialTheme.typography.bodySmall, color = if (ho.riskLevel.contains("高风险")) Bear else TextSecondary)
                            ho.unrealizedChangePct?.let { Text("参考持仓变动 ${"%.2f".format(it)}%", style = MaterialTheme.typography.bodySmall, color = if (it >= 0) Bull else Bear) }
                            ho.supportDistancePct?.let { Text("距支撑 ${"%.2f".format(it)}%", style = MaterialTheme.typography.labelSmall, color = TextMuted) }
                            ho.resistanceDistancePct?.let { Text("距阻力 ${"%.2f".format(it)}%", style = MaterialTheme.typography.labelSmall, color = TextMuted) }
                            ho.watchpoints.take(3).forEach { Text("· $it", style = MaterialTheme.typography.labelSmall, color = TextSecondary) }
                            Text("失效观察：${ho.invalidation}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        }
                    }
                    Text(sa.closedCandleRule, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Text(sa.probabilityRule, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                }
        }

        state.riskMap?.let { rm ->
            AppCard {
                    Text("多周期实时风险地图", style = MaterialTheme.typography.titleMedium, color = Accent)
                    Spacer(Modifier.height(6.dp))
                    Text("${rm.currentTimeframe} · 当前价 ${rm.lastPrice?.let { "%.6f".format(it) } ?: "—"}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TagChip("最近支撑 ${rm.nearestSupport?.let { "%.6f".format(it) } ?: "—"}", Bull)
                        TagChip("最近阻力 ${rm.nearestResistance?.let { "%.6f".format(it) } ?: "—"}", Bear)
                    }
                    Spacer(Modifier.height(8.dp))
                    rm.levels.toSortedMap(compareBy { listOf("5m","15m","30m","1h","4h","1d","1w").indexOf(it).let { i -> if (i < 0) 99 else i } }).forEach { (tf, level) ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(tf, style = MaterialTheme.typography.labelMedium, color = TextPrimary)
                            Text(level.trend, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text("S ${level.support?.let { "%.4f".format(it) } ?: "—"} · R ${level.resistance?.let { "%.4f".format(it) } ?: "—"}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        }
                    }
                    Spacer(Modifier.height(5.dp))
                    Text(rm.rule, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                }
            }

        state.multiTimeframe?.let { mtf ->
            Spacer(Modifier.height(7.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("多周期 ${mtf.resonance}", color = Accent, fontWeight = FontWeight.Medium)
                Text("当前 ${mtf.currentTimeframe}", color = TextMuted, style = MaterialTheme.typography.labelSmall)
            }
            Text(mtf.resonanceNote, color = TextSecondary, style = MaterialTheme.typography.labelSmall, maxLines = 3)
        }
        state.unifiedReport?.let { report ->
            Spacer(Modifier.height(7.dp))
            Text("综合结论", color = Accent, style = MaterialTheme.typography.labelLarge)
            Text(report.summary, color = TextPrimary, style = MaterialTheme.typography.bodySmall, maxLines = 4)
            if (report.longSummary.isNotBlank()) Text("多头情景：${report.longSummary}", color = Bull, style = MaterialTheme.typography.labelSmall, maxLines = 2)
            if (report.shortSummary.isNotBlank()) Text("空头情景：${report.shortSummary}", color = Bear, style = MaterialTheme.typography.labelSmall, maxLines = 2)
            if (report.holdingSummary.isNotBlank()) Text("持仓观察：${report.holdingSummary}", color = TextSecondary, style = MaterialTheme.typography.labelSmall, maxLines = 2)
            Text("数据 ${report.dataTimestamp.ifBlank { "—" }} · 分析 ${report.generatedAt}", color = TextMuted, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
fun DetailScreen(state: AppState) {
    val sym = state.selectedSymbol ?: return
    LazyColumn(
        Modifier.fillMaxSize().background(Bg).padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 88.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { state.closeDetail() }) {
                    Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "返回", tint = TextPrimary)
                }
                Column(Modifier.weight(1f)) {
                    Text(sym, style = MaterialTheme.typography.headlineMedium, color = TextPrimary)
                    Text(state.connectionStatus, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                }
                IconButton(onClick = { state.toggleFavorite(sym) }) {
                    Icon(if (sym in state.favorites) Icons.Outlined.Star else Icons.Outlined.StarBorder, contentDescription = "自选", tint = if (sym in state.favorites) Accent else TextMuted)
                }
            }
            Spacer(Modifier.height(8.dp))
            state.markets.firstOrNull { it.symbol == sym }?.let { m ->
                AppCard {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column { Text(m.price, color = TextPrimary, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold); Text("${m.name} · ${m.venue.ifBlank { m.assetClass }}", color = TextMuted, style = MaterialTheme.typography.labelSmall) }
                        Column(horizontalAlignment = Alignment.End) { PctBadge(m.changePct); Text("${m.currency.ifBlank { "市场价" }} · 只读", color = TextMuted, style = MaterialTheme.typography.labelSmall) }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("周期", style = MaterialTheme.typography.labelLarge, color = TextMuted)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AppState.timeframes.forEach { tf ->
                    val selected = state.timeframe == tf
                    FilterChip(
                        selected = selected,
                        onClick = { state.changeTimeframe(tf) },
                        label = { Text(tf) },
                    )
                }
            }
            if (state.detailLoading) {
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(Modifier.fillMaxWidth(), color = Accent)
            }
            state.errorMessage?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, color = Bear, style = MaterialTheme.typography.bodyMedium)
            }
        }

        item { CandleChart(state.candles) }
        item { IndicatorAnalysisCharts(state.candles, state.timeframe) }

        if (state.marketCategory == "crypto") {
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("MARKET TERMINAL", color = TextPrimary, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                        Text("市场事实层 · 实时盘口与成交", color = TextMuted, style = MaterialTheme.typography.labelSmall)
                    }
                    TagChip("READ ONLY", Accent)
                }
            }
            state.terminalSnapshot?.let { item { BinanceTerminalCard(it) } }
        }

        item { SmartAnalysisCard(state) }

        state.instrumentAnalysisSnapshot?.let { data ->
            item {
                AppCard {
                    Text("数据能力 · ${data.market.uppercase()}", style = MaterialTheme.typography.titleSmall, color = Accent)
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TagChip(if (data.snapshotAvailable) "行情可用" else "行情不可用", if (data.snapshotAvailable) Bull else Bear)
                        TagChip(data.capabilityStatus, if (data.capabilityStatus == "available") Bull else Warn)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("Provider ${data.provider} · ${data.timeframe} · 只读分析", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Spacer(Modifier.height(4.dp))
                    Text("数据质量 ${data.quality} · ${if (data.realtime) "实时" else "非实时"}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    if (data.missing.isNotEmpty()) {
                        Text("缺失能力：${data.missing.joinToString("、")}", style = MaterialTheme.typography.labelSmall, color = Warn)
                    }
                }
            }
        }

        if (state.marketCategory == "crypto") {
            state.derivatives?.let { d ->
                item {
                    AppCard {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("合约市场结构", style = MaterialTheme.typography.titleMedium, color = Accent)
                            TagChip(if (d.available) "PUBLIC DATA" else "不可用", if (d.available) Bull else Warn)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("Funding ${d.fundingRate?.let { "%.4f%%".format(it*100) } ?: "—"}   OI ${d.openInterest?.let { "%.2f".format(it) } ?: "—"}", color = TextPrimary)
                        Spacer(Modifier.height(5.dp))
                        Text("Mark ${d.markPrice?.let { "%.4f".format(it) } ?: "—"} · Index ${d.indexPrice?.let { "%.4f".format(it) } ?: "—"}", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(5.dp))
                        Text("多空账户比 ${d.longShortRatio?.let { "%.3f".format(it) } ?: "—"} · Taker 买卖比 ${d.buySellRatio?.let { "%.3f".format(it) } ?: "—"}", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(5.dp))
                        Text("基差率 ${d.basisRate?.let { "%.4f%%".format(it*100) } ?: "—"} · 最近强平价 ${d.liquidationPrice?.let { "%.4f".format(it) } ?: "—"}", color = TextMuted, style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(6.dp))
                        Text("以上均为公开市场数据，只用于判断拥挤度、杠杆情绪与价格结构，不代表交易执行。", color = TextMuted, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            state.multiExchange?.let { ex ->
                item {
                    AppCard {
                        Text("多交易所一致性", style = MaterialTheme.typography.titleMedium, color = Accent)
                        Spacer(Modifier.height(6.dp))
                        Text("可用 ${ex.providerCount}/3 · 共识价格 ${ex.markPriceMean?.let { "%.4f".format(it) } ?: "—"}", color = TextPrimary)
                        Text("Funding均值 ${ex.fundingRateMean?.let { "%.5f".format(it) } ?: "—"} · OI均值 ${ex.openInterestMean?.let { "%.2f".format(it) } ?: "—"}", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                        Text("价格离散 ${ex.markSpreadPct?.let { "%.4f%%".format(it) } ?: "—"} · Funding离散 ${ex.fundingSpread?.let { "%.6f".format(it) } ?: "—"}", color = TextMuted, style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(8.dp))
                        ex.providers.forEach { row ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(row.provider.uppercase(), color = if (row.available) TextPrimary else TextMuted, fontWeight = FontWeight.Medium)
                                Text(if (row.available) "${row.markPrice?.let { "%.4f".format(it) } ?: "—"} · F ${row.fundingRate?.let { "%.5f".format(it) } ?: "—"}" else "不可用", color = if (row.available) TextSecondary else Warn, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }

        state.unifiedReport?.let { report ->
            item {
                AppCard {
                    Text("实时分析结论 · ${report.timeframe}", style = MaterialTheme.typography.titleMedium, color = Accent)
                    Spacer(Modifier.height(6.dp))
                    Text(report.summary.ifBlank { "当前暂无一句话结论" }, style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
                    if (report.narrative.isNotBlank()) {
                        Spacer(Modifier.height(6.dp))
                        Text(report.narrative, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("多头情景", style = MaterialTheme.typography.labelLarge, color = Bull)
                    Text(report.longSummary, style = MaterialTheme.typography.bodySmall, color = TextPrimary)
                    Spacer(Modifier.height(5.dp))
                    Text("空头情景", style = MaterialTheme.typography.labelLarge, color = Bear)
                    Text(report.shortSummary, style = MaterialTheme.typography.bodySmall, color = TextPrimary)
                    Spacer(Modifier.height(5.dp))
                    Text("持仓观察", style = MaterialTheme.typography.labelLarge, color = Accent)
                    Text(report.holdingSummary, style = MaterialTheme.typography.bodySmall, color = TextPrimary)
                    if (report.riskNotes.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        report.riskNotes.take(4).forEach { Text("· $it", style = MaterialTheme.typography.bodySmall, color = TextMuted) }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("行情数据时间 ${report.dataTimestamp.ifBlank { "—" }} · 分析生成 ${report.generatedAt} · 数据质量 ${report.dataQuality}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                }
            }
        }

        state.analysisFeedback?.let { fb ->
            item {
                AppCard {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("历史分析反馈", style = MaterialTheme.typography.titleMedium, color = Accent)
                        TagChip(when (fb.currentState) { "validated" -> "阶段验证"; "invalidated" -> "已失效"; "tracking" -> "继续跟踪"; else -> "等待反馈" }, when (fb.currentState) { "validated" -> Bull; "invalidated" -> Bear; "tracking" -> Accent; else -> Neutral })
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(fb.currentSummary, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                    Spacer(Modifier.height(8.dp))
                    fb.history.take(5).forEach { h ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("${h.reportId} · ${h.direction} · ${(h.confidence * 100).toInt()}%", color = TextPrimary, style = MaterialTheme.typography.bodySmall)
                                Text(h.feedbackSummary, color = TextMuted, style = MaterialTheme.typography.labelSmall, maxLines = 2)
                            }
                            TagChip(when(h.feedbackState){"validated"->"验证";"invalidated"->"失效";"tracking"->"跟踪";else->"等待"}, when(h.feedbackState){"validated"->Bull;"invalidated"->Bear;"tracking"->Accent;else->Neutral})
                        }
                    }
                    Text("历史报告为冻结快照，当前周期切换后会重新生成独立分析与反馈链。", color = TextMuted, style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        state.indicator?.let { ind ->
            item {
                AppCard {
                    Text("指标 · ${ind.timeframe}", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Text(ind.summary, style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
                    Spacer(Modifier.height(8.dp))
                    Text(ind.narrative, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TagChip("趋势 ${ind.trendLabel}", if (ind.trendLabel == "上涨") Bull else if (ind.trendLabel == "下跌") Bear else Neutral)
                        TagChip("强度 ${ind.trendStrength}", Neutral)
                        TagChip("超买 ${ind.overboughtCount}", if (ind.overboughtCount > 0) Bear else Neutral)
                        TagChip("超卖 ${ind.oversoldCount}", if (ind.oversoldCount > 0) Bull else Neutral)
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("价格 ${ind.lastPrice ?: "—"}  RSI ${ind.rsi ?: "—"}  MACD柱 ${ind.macdHist ?: "—"}", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                    Spacer(Modifier.height(6.dp))
                    Text("趋势 ${ind.trendSma ?: "—"}  布林位置 ${ind.bbPct ?: "—"}", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                    Spacer(Modifier.height(8.dp))
                    Text("完整指标", style = MaterialTheme.typography.labelLarge, color = Accent)
                    ind.details.forEach { Text("· $it", style = MaterialTheme.typography.bodySmall, color = TextSecondary) }
                    if (ind.structureNote.isNotBlank()) {
                        Spacer(Modifier.height(6.dp))
                        Text("行情结构：${ind.structureNote}", style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                    }
                    if (ind.divergence.isNotBlank()) Text("背离：${ind.divergence}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    ind.oscillators.forEach {
                        Spacer(Modifier.height(4.dp))
                        Text("· $it", style = MaterialTheme.typography.bodyMedium, color = TextMuted)
                    }
                    if (ind.signals.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        Text("信号", style = MaterialTheme.typography.labelLarge, color = Accent)
                        ind.signals.forEach {
                            Text("· $it", style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                        }
                    }
                }
            }
        }

        state.advice?.let { a ->
            item {
                AppCard {
                    Text("入场 / 开仓双向建议", style = MaterialTheme.typography.titleMedium, color = Accent)
                    Spacer(Modifier.height(6.dp))
                    Text("同时展示多单与空单情景；系统不会执行交易。", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                    Spacer(Modifier.height(10.dp))
                    listOf("多单" to a.longPlan, "空单" to a.shortPlan).forEach { (label, plan) ->
                        val tone = if (label == "多单") Bull else Bear
                        TagChip("$label · 情景评分 ${(plan.conviction * 100).toInt()}%", tone)
                        Spacer(Modifier.height(6.dp))
                        Text("观察区间 ${plan.entryLow ?: "—"} ~ ${plan.entryHigh ?: "—"} · 参考 ${plan.entry ?: "—"}", style = MaterialTheme.typography.bodyLarge)
                        Text("止损参考 ${plan.stop ?: "—"} · 目标 ${plan.tp1 ?: "—"} / ${plan.tp2 ?: "—"}", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                        Text("风险回报 ${plan.rr ?: "—"} · 风险暴露参考 ${((plan.positionPct ?: 0.0) * 100).toInt()}%", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                        plan.rationale.take(4).forEach { reason ->
                            Spacer(Modifier.height(3.dp))
                            Text("· $reason", style = MaterialTheme.typography.bodySmall, color = TextPrimary)
                        }
                        Spacer(Modifier.height(10.dp))
                    }
                    TagChip("当前持仓观察：${a.positionAction}", Neutral)
                    Spacer(Modifier.height(6.dp))
                    Text(a.positionNote, style = MaterialTheme.typography.bodyMedium, color = TextMuted)
                    Text("综合偏向：${a.direction.uppercase()} · ${a.bias} · 情景评分为规则证据评分，不是预测概率", style = MaterialTheme.typography.bodySmall, color = Accent)
                    Spacer(Modifier.height(6.dp))
                    Text("分析每15秒刷新一次；多周期数据同步重新计算。", style = MaterialTheme.typography.labelMedium, color = TextMuted)
                    Text("分析模式：仅提供行情、技术指标、多空情景与开仓/持仓观察建议，不提供模拟或下单功能。", style = MaterialTheme.typography.labelMedium, color = TextMuted)
                }
            }
        }

        if (state.reportCatalog.isNotEmpty()) {
            item {
                Text("32 类报告中心", style = MaterialTheme.typography.titleMedium, color = Accent)
                Spacer(Modifier.height(4.dp))
                Text("以下状态属于当前品种 ${state.marketCategory} · ${state.timeframe} 的独立数据检查；打开报告后才加载该品种的完整正文。", style = MaterialTheme.typography.bodySmall, color = TextMuted)
            }
            items(state.reportCatalog) { r ->
                AppCard(Modifier.clickable { state.openReport(r.key) }) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${r.id}. ${r.name}", style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                            Text("${r.domain} · ${r.update}", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            TagChip(r.priority, if (r.priority == "P0") Bear else if (r.priority == "P1") Accent else Neutral)
                            Spacer(Modifier.height(4.dp))
                            TagChip(when (r.status) {
                                "available" -> "可生成"
                                "pending_provider" -> "等待数据源"
                                "unavailable" -> "不可用"
                                else -> "待检测"
                            }, when (r.status) {
                                "available" -> Bull
                                "pending_provider" -> Warn
                                "unavailable" -> Bear
                                else -> Neutral
                            })
                        }
                    }
                }
            }
        }

        state.selectedReport?.let { report ->
            item {
                AppCard {
                    Text("${report.name} · ${report.key}", style = MaterialTheme.typography.titleMedium, color = Accent)
                    Spacer(Modifier.height(6.dp))
                    TagChip(report.availability, if (report.availability == "available") Bull else Neutral)
                    Spacer(Modifier.height(6.dp))
                    Text(report.summary, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                    if (report.availabilityReason.isNotBlank()) Text(report.availabilityReason, style = MaterialTheme.typography.bodySmall, color = TextMuted)
                    report.content.take(12).forEach { Text("· $it", style = MaterialTheme.typography.bodySmall, color = TextSecondary) }
                    if (state.reportLoading) LinearProgressIndicator(Modifier.fillMaxWidth())
                    Spacer(Modifier.height(4.dp))
                    Text("行情数据时间 ${report.dataTimestamp.ifBlank { "—" }} · 分析生成 ${report.generatedAt} · 数据质量 ${report.dataQuality}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                }
            }
        }

        state.marketStructure?.let { structure ->
            item {
                AppCard {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("市场结构 · ${structure.timeframe}", style = MaterialTheme.typography.titleMedium, color = Accent)
                            Text("${structure.trend} · 支撑 ${structure.support?.let { "%.4f".format(it) } ?: "—"} · 阻力 ${structure.resistance?.let { "%.4f".format(it) } ?: "—"}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                        val breakoutTone = if (structure.breakout == "none") Neutral else Warn
                        TagChip(if (structure.breakout == "none") "无突破确认" else "突破测试", breakoutTone)
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        structure.pivots.takeLast(8).forEach { p -> TagChip(p.label, if (p.kind == "high") Bear else Bull) }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(structure.note, style = MaterialTheme.typography.bodySmall, color = TextMuted)
                    Text(structure.closedCandleRule, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                }
            }
        }

        state.scenarioAnalysis?.let { sa ->
            item {
                AppCard {
                    Text("实时多空情景", style = MaterialTheme.typography.titleMedium, color = Accent)
                    Spacer(Modifier.height(6.dp))
                    Text("${sa.timeframe} · ${sa.trend} · ${sa.mtfResonance} · 当前价 ${sa.lastPrice?.let { "%.6f".format(it) } ?: "—"}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    Spacer(Modifier.height(8.dp))
                    sa.scenarios.forEach { sc ->
                        val tone = when (sc.name) { "bull" -> Bull; "bear" -> Bear; else -> Neutral }
                        AppCard {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text(sc.label, style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                                TagChip(if (sc.status == "active_observation") "观察中" else "条件情景", tone)
                            }
                            Spacer(Modifier.height(4.dp))
                            Text("触发：${sc.trigger}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                            Text("观察区：${sc.observationZone}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                            Text("失效：${sc.invalidation}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                            Text("路径：${sc.targets}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                            sc.reasons.take(3).forEach { Text("· $it", style = MaterialTheme.typography.labelSmall, color = TextMuted) }
                            Text("概率：${sc.probability?.let { "%.1f%%".format(it * 100) } ?: "未校准"}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        }
                        Spacer(Modifier.height(6.dp))
                    }
                    sa.holdingObservation?.let { ho ->
                        Spacer(Modifier.height(8.dp))
                        AppCard {
                            Text("持仓观察 / 风险节点", style = MaterialTheme.typography.titleSmall, color = Accent)
                            Spacer(Modifier.height(4.dp))
                            Text("${ho.riskLevel} · ${if (ho.contextSource == "user_supplied") "用户提供上下文" else "仅市场状态"}", style = MaterialTheme.typography.bodySmall, color = if (ho.riskLevel.contains("高风险")) Bear else TextSecondary)
                            ho.unrealizedChangePct?.let { Text("参考持仓变动 ${"%.2f".format(it)}%", style = MaterialTheme.typography.bodySmall, color = if (it >= 0) Bull else Bear) }
                            ho.supportDistancePct?.let { Text("距支撑 ${"%.2f".format(it)}%", style = MaterialTheme.typography.labelSmall, color = TextMuted) }
                            ho.resistanceDistancePct?.let { Text("距阻力 ${"%.2f".format(it)}%", style = MaterialTheme.typography.labelSmall, color = TextMuted) }
                            ho.watchpoints.take(3).forEach { Text("· $it", style = MaterialTheme.typography.labelSmall, color = TextSecondary) }
                            Text("失效观察：${ho.invalidation}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        }
                    }
                    Text(sa.closedCandleRule, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Text(sa.probabilityRule, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                }
            }
        }
        state.riskMap?.let { rm ->
            item {
                AppCard {
                    Text("多周期实时风险地图", style = MaterialTheme.typography.titleMedium, color = Accent)
                    Spacer(Modifier.height(6.dp))
                    Text("${rm.currentTimeframe} · 当前价 ${rm.lastPrice?.let { "%.6f".format(it) } ?: "—"}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TagChip("最近支撑 ${rm.nearestSupport?.let { "%.6f".format(it) } ?: "—"}", Bull)
                        TagChip("最近阻力 ${rm.nearestResistance?.let { "%.6f".format(it) } ?: "—"}", Bear)
                    }
                    Spacer(Modifier.height(8.dp))
                    rm.levels.toSortedMap(compareBy { listOf("5m","15m","30m","1h","4h","1d","1w").indexOf(it).let { i -> if (i < 0) 99 else i } }).forEach { (tf, level) ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(tf, style = MaterialTheme.typography.labelMedium, color = TextPrimary)
                            Text(level.trend, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text("S ${level.support?.let { "%.4f".format(it) } ?: "—"} · R ${level.resistance?.let { "%.4f".format(it) } ?: "—"}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        }
                    }
                    Spacer(Modifier.height(5.dp))
                    Text(rm.rule, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                }
            }
        }
        state.multiTimeframe?.let { mtf ->
            item {
                AppCard {
                    Text("多周期共振", style = MaterialTheme.typography.titleMedium, color = Accent)
                    Spacer(Modifier.height(6.dp))
                    TagChip(mtf.resonance, if (mtf.resonance.contains("多") && !mtf.resonance.contains("空") ) Bull else if (mtf.resonance.contains("空")) Bear else Neutral)
                    Spacer(Modifier.height(6.dp))
                    Text(mtf.resonanceNote, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                    Spacer(Modifier.height(8.dp))
                    mtf.timeframes.toSortedMap(compareBy { AppState.timeframes.indexOf(it).let { i -> if (i < 0) 99 else i } }).forEach { (tf, r) ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(tf, style = MaterialTheme.typography.bodyMedium, color = if (tf == mtf.currentTimeframe) Accent else TextSecondary)
                            Text("${r.trendLabel} · ${r.trendStrength} · 超买${r.overboughtCount}/超卖${r.oversoldCount}", style = MaterialTheme.typography.bodySmall, color = TextPrimary)
                        }
                        Spacer(Modifier.height(4.dp))
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(mtf.realtimeNote, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                }
            }
        }

        if (!state.detailLoading && state.indicator == null && state.advice == null) {
            item {
                AppCard {
                    Text("未加载到数据", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(6.dp))
                    Text("1. 本机启动后端 uvicorn\n2. ApiConfig.baseUrl 指向可达地址\n3. 再点周期或返回重进", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                }
            }
        }
    }
}

@Composable
fun AnalysisScreen(state: AppState) {
    val domains = listOf("全部", "行情", "技术", "资金", "基本面", "事件", "风险", "研究", "复盘")
    val feed = state.analysisFeed?.items.orEmpty()
    val reports = state.reportCatalog.filter { state.analysisDomainFilter == "全部" || it.domain == state.analysisDomainFilter }
    val registered = reports.size

    LazyColumn(
        Modifier.fillMaxSize().background(Bg),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("分析", style = MaterialTheme.typography.displaySmall, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                    Text("真实行情 → 指标 → 结构 → 多空情景 → 历史反馈", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                }
                TagChip(if (state.backendOnline) "ENGINE ONLINE" else "DATA ONLY", if (state.backendOnline) Bull else Warn)
            }
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("高置信报告", feed.size.toString(), "${state.timeframe}", Modifier.weight(1f))
                StatCard("已注册", registered.toString(), "报告目录", Modifier.weight(1f))
                StatCard("当前周期", state.timeframe, "独立计算", Modifier.weight(1f))
            }
        }

        item {
            AppCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("当前高置信分析", color = Accent, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text("报告冻结后，反馈只读取后续真实行情，不修改历史报告", color = TextMuted, style = MaterialTheme.typography.labelSmall)
                    }
                    TagChip("${feed.size} 条", Accent)
                }
                Spacer(Modifier.height(8.dp))
                if (feed.isEmpty()) {
                    Text(if (state.backendOnline) "分析引擎当前没有返回有效报告。" else "分析后端不可达；市场数据仍可独立显示。", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                } else {
                    feed.take(6).forEach { item ->
                        Row(
                            Modifier.fillMaxWidth().clickable { state.openDetail(item.symbol, item.market) }.padding(vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(item.symbol, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                                Text(item.summary, color = TextSecondary, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                                if (item.feedbackSummary.isNotBlank()) Text("反馈：${item.feedbackSummary}", color = TextMuted, style = MaterialTheme.typography.labelSmall, maxLines = 2)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                TagChip("${(item.confidence * 100).toInt()}%", if (item.confidence >= .75) Bull else Accent)
                                Spacer(Modifier.height(3.dp))
                                TagChip(when (item.direction) { "long" -> "多头"; "short" -> "空头"; else -> "观察" }, when (item.direction) { "long" -> Bull; "short" -> Bear; else -> Neutral })
                            }
                        }
                        HorizontalDivider(color = Border.copy(alpha = .45f))
                    }
                }
            }
        }

        item {
            AppCard {
                Text("分析周期", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                Spacer(Modifier.height(7.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AppState.timeframes.forEach { tf ->
                        FilterChip(selected = state.timeframe == tf, onClick = { state.changeTimeframe(tf) }, label = { Text(tf) })
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text("切换周期会重新计算该周期的趋势、RSI、MACD、ADX、均线、超买超卖、结构与多空情景。", color = TextMuted, style = MaterialTheme.typography.labelSmall)
            }
        }

        item {
            AppCard {
                Text("32 类报告中心", style = MaterialTheme.typography.titleMedium, color = Accent)
                Spacer(Modifier.height(6.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    domains.forEach { domain ->
                        FilterChip(selected = state.analysisDomainFilter == domain, onClick = { state.analysisDomainFilter = domain }, label = { Text(domain) })
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("当前筛选 ${reports.size} 项 · 详情页会对当前品种/周期逐项检查数据源并显示可用、等待或不可用", color = TextMuted, style = MaterialTheme.typography.labelSmall)
            }
        }

        items(reports) { r ->
            AppCard(Modifier.clickable {
                // Report content is opened from a selected instrument. Keep this action explicit
                // instead of pretending a report exists without a symbol.
                state.markets.firstOrNull()?.let { state.openDetail(it.symbol, it.assetClass) }
            }) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${r.id}. ${r.name}", color = TextPrimary, fontWeight = FontWeight.SemiBold)
                        Text("${r.domain} · ${r.update} · ${r.key}", color = TextMuted, style = MaterialTheme.typography.labelSmall)
                    }
                    TagChip("已注册", Neutral)
                }
            }
        }
    }
}

@Composable
fun AccountScreen(state: AppState) {
    val context = androidx.compose.ui.platform.LocalContext.current
    LazyColumn(
        Modifier.fillMaxSize().background(Bg),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("数据与系统", style = MaterialTheme.typography.displaySmall, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                    Text("Smart Trader 全量落地验收状态", color = TextMuted, style = MaterialTheme.typography.bodySmall)
                }
                TagChip(if (state.backendOnline) "ONLINE" else "OFFLINE", if (state.backendOnline) Bull else Warn)
            }
        }

        item {
            AppCard {
                Text("连接状态", style = MaterialTheme.typography.titleMedium, color = Accent)
                Spacer(Modifier.height(7.dp))
                Text(state.connectionStatus, color = TextPrimary)
                Spacer(Modifier.height(4.dp))
                Text("后端地址（真机请填写局域网 IP 或云端 HTTPS）", color = TextMuted, style = MaterialTheme.typography.labelSmall)
                Spacer(Modifier.height(4.dp))
                OutlinedTextField(
                    value = state.backendUrlDraft,
                    onValueChange = state::updateBackendUrlDraft,
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Backend URL") },
                )
                Spacer(Modifier.height(6.dp))
                Text("当前：${ApiConfig.baseUrl}", color = TextMuted, style = MaterialTheme.typography.labelSmall)
                Text("数据刷新：${if (state.live) "WebSocket 实时流" else "REST / 本地最近缓存"}", color = TextMuted, style = MaterialTheme.typography.labelSmall)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { state.applyBackendUrl(context) }) { Text("保存并检测") }
                    OutlinedButton(onClick = { state.startLive() }) { Text("启动实时流") }
                    OutlinedButton(onClick = { state.stopLive() }) { Text("停止实时流") }
                }
            }
        }

        if (state.providerHealth.isNotEmpty()) {
            item {
                AppCard {
                    Text("Provider 健康", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    Spacer(Modifier.height(6.dp))
                    state.providerHealth.forEach { p ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(Modifier.weight(1f)) {
                                Text(p.name, color = TextPrimary)
                                if (p.message.isNotBlank()) Text(p.message, color = TextMuted, style = MaterialTheme.typography.labelSmall)
                            }
                            TagChip(if (p.available) "可用" else "不可用", if (p.available) Bull else Warn)
                        }
                    }
                }
            }
        }

        item {
            AppCard {
                Text("四大市场数据能力", style = MaterialTheme.typography.titleMedium, color = Accent)
                Spacer(Modifier.height(6.dp))
                val labels = mapOf("crypto" to "加密", "us" to "美股", "hk" to "港股", "commodities" to "大宗")
                state.marketCapabilities.forEach { c ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(labels[c.market] ?: c.market, color = TextPrimary, fontWeight = FontWeight.Medium)
                            Text("${c.provider} · ${if (c.available) "provider_ready" else "provider_required"}", color = TextMuted, style = MaterialTheme.typography.labelSmall)
                            if (c.missing.isNotEmpty()) Text("缺失：${c.missing.joinToString("、")}", color = Warn, style = MaterialTheme.typography.labelSmall)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            TagChip(if (c.available) "可用" else "部分/等待", if (c.available) Bull else Warn)
                            Text(if (c.realtime) "实时" else "非实时", color = TextMuted, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                if (state.marketCapabilities.isEmpty()) Text("等待后端返回能力矩阵…", color = TextMuted, style = MaterialTheme.typography.bodySmall)
            }
        }

        item {
            AppCard {
                Text("全量市场覆盖", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                Spacer(Modifier.height(6.dp))
                state.marketCoverage?.let { c ->
                    Text("当前发现 ${c.total} 个品种", color = TextPrimary, style = MaterialTheme.typography.bodyLarge)
                    c.markets.toSortedMap().forEach { (market, count) ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(market, color = TextSecondary)
                            Text(count.toString(), color = TextPrimary)
                        }
                    }
                } ?: Text("等待覆盖统计…", color = TextMuted)
            }
        }

        item {
            AppCard {
                Text("产品边界", style = MaterialTheme.typography.titleMedium, color = Accent)
                Spacer(Modifier.height(6.dp))
                Text("只读分析平台：行情、K线、指标、市场结构、多空情景、持仓观察、历史报告反馈、32类研究报告。", color = TextSecondary)
                Spacer(Modifier.height(4.dp))
                Text("不包含模拟盘、纸面成交、真实下单或交易账户连接。", color = TextMuted, style = MaterialTheme.typography.labelSmall)
                Spacer(Modifier.height(4.dp))
                Text("任何未配置的数据源必须显示为不可用/等待 provider，不使用零值或默认值伪装成真实行情。", color = TextMuted, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

