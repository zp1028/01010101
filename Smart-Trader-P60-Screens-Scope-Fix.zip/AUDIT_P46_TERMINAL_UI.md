# P46 Terminal UI audit

- Data source: existing `TerminalSnapshotDto` populated by P44/P45 provider-backed terminal endpoint.
- UI does not manufacture prices, depth levels, trades, funding, mark/index, volume, or freshness values.
- LIVE/STALE is derived from the provider freshness status.
- Bid/ask spread and midpoint are calculated from the received book values.
- 24H change is taken from the received quote change percentage.
- Order book and trade tape are read-only presentation layers.
- No account, wallet, order, execution, or simulation controls were added.
