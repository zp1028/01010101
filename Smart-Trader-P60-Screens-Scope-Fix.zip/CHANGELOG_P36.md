# Smart Trader P36 — Analysis Truth / Walk-Forward Hardening

## Core changes

1. Replaced the previous single train/calibration/OOS split in `quant/probability.py` with an expanding walk-forward evaluation.
   - Every OOS prediction only uses samples strictly before that prediction.
   - Calibration-window bin selection is also historical at each step.
   - Final displayed probability is fitted only from completed historical samples before the current decision point.
   - Method is now reported as `expanding_walk_forward`.

2. Hardened `report_truth.py`.
   - Unknown report source requirements can no longer silently pass as available.
   - Added explicit `session_context` requirement mapping for pre-open/intraday reports.
   - Missing evidence produces `pending_provider` instead of a generic technical report being treated as a substitute.

3. Removed commodity-universe wording implying a curated/static fallback.
   - Commodity discovery now requires a configured futures symbol-master provider.
   - Capability/status now reports `provider_required` until both universe and synchronized quote providers exist.

4. Kept analysis-only behavior.
   - No order placement or trading execution was added.
   - Realistic risk/backtest constants remain domain configuration, not market-data claims.

## Verification

- Backend tests: **87 passed**
- Python `compileall`: **PASS**
- Android Gradle compile: **NOT VERIFIED** because the environment cannot resolve `services.gradle.org` to download Gradle 8.9 (`UnknownHostException`).
