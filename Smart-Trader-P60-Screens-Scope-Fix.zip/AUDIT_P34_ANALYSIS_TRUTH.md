# P34 Analysis Truth Audit

| Analysis element | P34 state |
|---|---|
| Market prices | Provider-derived; unavailable data is not fabricated |
| Technical indicators | Deterministic calculations from supplied bars |
| Technical evidence confidence | Data/evidence completeness, not future success probability |
| Historical validation rate | Completed feedback only |
| Bull/Base/Bear probability | Only empirical walk-forward output; otherwise null |
| Probability training | Past feature snapshots only |
| Probability outcome | Future bars after each snapshot |
| Calibration | Separate calibration window |
| Final evaluation | Independent OOS window + Brier score |
| News/macro/on-chain | No real input => unavailable, no fabricated score |

## Important distinction
RSI thresholds, moving-average periods and other indicator parameters are explicit analysis rules. They are not presented as empirical probabilities. Predictive percentages are not allowed to come from those constants.
