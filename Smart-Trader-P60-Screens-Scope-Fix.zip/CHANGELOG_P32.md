# Smart Trader P32 — Analysis Truth / Probability Calibration

- Removed fixed bull/base/bear scenario percentages from AIOrchestrator.
- Scenario probability is now nullable and is only emitted when completed historical feedback exists.
- Added empirical calibration from persisted validated/invalidated analysis feedback.
- Technical evidence confidence now reflects observed indicator coverage rather than fixed 0.6/0.7 values.
- Money-flow/context evidence confidence reflects actual input availability.
- When no completed outcomes exist, the API explicitly reports that calibrated probability is unavailable instead of inventing a percentage.
