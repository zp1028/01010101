package com.caifenxi.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.data.config.LlmConfigStore
import com.caifenxi.app.domain.execution.ExecutorManager
import com.caifenxi.app.domain.execution.LlmClient
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import kotlinx.coroutines.launch
import kotlinx.coroutines.GlobalScope
import com.caifenxi.app.domain.execution.LlmPrompt
import com.caifenxi.app.domain.execution.LlmResponse
import com.caifenxi.app.ui.components.SectionTitle

/**
 * AI 大模型设置页面
 * 配置 LLM API 参数、选择模型、测试连接
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiSettingsScreen(
    onBack: () -> Unit = {}
) {
    val context = LocalContext.current
    var config by remember { mutableStateOf(LlmConfigStore.load(context)) }

    var providerExpanded by remember { mutableStateOf(false) }
    var modelExpanded by remember { mutableStateOf(false) }
    var testStatus by remember { mutableStateOf("") }
    var isTesting by remember { mutableStateOf(false) }

    val providers = LlmClient.LlmProvider.entries.toList()
    val models = when (config.provider) {
        LlmClient.LlmProvider.OPENAI -> listOf("gpt-4o-mini", "gpt-4o", "gpt-4-turbo")
        LlmClient.LlmProvider.ANTHROPIC -> listOf("claude-3-5-sonnet-20241022", "claude-3-opus-20240229")
        LlmClient.LlmProvider.GOOGLE -> listOf("gemini-1.5-pro", "gemini-1.5-flash")
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // 顶栏
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("← 返回") }
            Text(
                "🧠 AI 大模型设置",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(Modifier.height(16.dp))

        // 执行模式选择
        GlobalCard {
            SectionTitle("执行模式")
            val modes = listOf(
                "auto" to "自动（AI优先）",
                "ai_vision" to "仅AI视觉",
                "webview" to "仅内置网页",
                "accessibility" to "仅无障碍"
            )
            var selectedMode by remember { mutableStateOf(ExecutorManager.getMode()) }
            modes.forEach { (value, label) ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = selectedMode == value,
                        onClick = {
                            selectedMode = value
                            ExecutorManager.setMode(value)
                        }
                    )
                    Text(label, modifier = Modifier.padding(start = 8.dp))
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // LLM 提供商
        GlobalCard {
            SectionTitle("LLM 提供商")
            ExposedDropdownMenuBox(
                expanded = providerExpanded,
                onExpandedChange = { providerExpanded = it }
            ) {
                OutlinedTextField(
                    value = config.provider.name,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("提供商") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor()
                )
                ExposedDropdownMenu(
                    expanded = providerExpanded,
                    onDismissRequest = { providerExpanded = false }
                ) {
                    providers.forEach { provider ->
                        DropdownMenuItem(
                            text = { Text(provider.name) },
                            onClick = {
                                config = config.copy(provider = provider)
                                providerExpanded = false
                            }
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // API 配置
        GlobalCard {
            SectionTitle("API 配置")

            OutlinedTextField(
                value = config.baseUrl,
                onValueChange = { config = config.copy(baseUrl = it) },
                label = { Text("API Base URL") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(8.dp))

            OutlinedTextField(
                value = config.apiKey,
                onValueChange = { config = config.copy(apiKey = it) },
                label = { Text("API Key") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(8.dp))

            // 模型选择
            ExposedDropdownMenuBox(
                expanded = modelExpanded,
                onExpandedChange = { modelExpanded = it }
            ) {
                OutlinedTextField(
                    value = config.model,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("模型") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor()
                )
                ExposedDropdownMenu(
                    expanded = modelExpanded,
                    onDismissRequest = { modelExpanded = false }
                ) {
                    models.forEach { model ->
                        DropdownMenuItem(
                            text = { Text(model) },
                            onClick = {
                                config = config.copy(model = model)
                                modelExpanded = false
                            }
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // 高级参数
        GlobalCard {
            SectionTitle("高级参数")

            var temperature by remember { mutableStateOf(config.temperature.toFloat()) }
            Text("Temperature: ${String.format("%.1f", temperature)}")
            Slider(
                value = temperature,
                onValueChange = {
                    temperature = it
                    config = config.copy(temperature = it.toDouble())
                },
                valueRange = 0f..1f,
                steps = 9
            )

            Spacer(Modifier.height(8.dp))

            var maxTokens by remember { mutableStateOf(config.maxTokens) }
            Text("Max Tokens: $maxTokens")
            Slider(
                value = maxTokens.toFloat(),
                onValueChange = {
                    maxTokens = it.toInt()
                    config = config.copy(maxTokens = maxTokens)
                },
                valueRange = 128f..2048f,
                steps = 14
            )

            Spacer(Modifier.height(8.dp))

            // 图像质量
            var imageDetail by remember { mutableStateOf(config.imageDetail) }
            Row {
                listOf("low", "medium", "high").forEach { detail ->
                    FilterChip(
                        selected = imageDetail == detail,
                        onClick = {
                            imageDetail = detail
                            config = config.copy(imageDetail = detail)
                        },
                        label = { Text(detail.uppercase()) },
                        modifier = Modifier.padding(end = 8.dp)
                    )
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // 测试连接
        GlobalCard {
            SectionTitle("连接测试")
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                PrimaryButton(
                    text = if (isTesting) "测试中..." else "🧪 测试连接",
                    onClick = {
                        isTesting = true
                        testStatus = ""
                        // 简单的连通性测试
                        androidx.lifecycle.lifecycleScope.launch {
                            val client = LlmClient(config)
                            val result = client.chat(
                                LlmPrompt(
                                    system = "You are a test assistant. Reply with a single word: OK",
                                    userText = "Test",
                                    imageBase64 = ""
                                )
                            )
                            testStatus = when (result) {
                                is LlmResponse.Success -> "✅ 连接成功 (${result.durationMs}ms)"
                                is LlmResponse.Error -> "❌ 连接失败: ${result.message}"
                                else -> "❌ 未知错误"
                            }
                            isTesting = false
                        }
                    },
                    enabled = !isTesting && config.apiKey.isNotBlank()
                )
                if (testStatus.isNotBlank()) {
                    Text(
                        testStatus,
                        modifier = Modifier.padding(start = 12.dp),
                        fontSize = 14.sp
                    )
                }
            }
        }

        Spacer(Modifier.height(24.dp))

        // 保存按钮
        PrimaryButton(
            text = "💾 保存配置",
            onClick = {
                LlmConfigStore.save(context, config)
                // 重新注册 AI 执行器以应用新配置
                val app = context.applicationContext as? com.caifenxi.app.CaiFenXiApplication
                app?.registerAiVisionExecutor()
                testStatus = "✅ 配置已保存"
            },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(8.dp))

        Text(
            "提示：AI视觉模式需要无障碍服务已连接，且设备需联网。",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
