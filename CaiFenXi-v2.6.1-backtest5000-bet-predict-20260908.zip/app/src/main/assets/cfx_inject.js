/* cfx_inject.js - Core DOM scoring & click logic for GenericSiteAdapter
 * Loaded from assets at runtime, injected via WebView.evaluateJavascript
 * This file contains all __cfx* helper functions and the main __caiFenXiRunCommand entry point
 */

function __cfxNorm(s){ return (s||'').replace(/\s+/g,'').trim(); }
function __cfxVisible(el){
  if(!el||el.disabled) return false;
  var st=window.getComputedStyle(el);
  if(st.display==='none'||st.visibility==='hidden'||parseFloat(st.opacity||'1')===0) return false;
  var r=el.getBoundingClientRect();
  return r.width>8&&r.height>8&&r.bottom>0&&r.top<innerHeight&&r.right>0&&r.left<innerWidth;
}
function __cfxBlob(el){
  var bits=[el.className&&String(el.className), el.id,
    el.getAttribute('data-type'), el.getAttribute('data-play'),
    el.getAttribute('data-name'), el.getAttribute('data-value'),
    el.getAttribute('aria-label'), el.name, el.getAttribute('title')];
  return bits.filter(Boolean).join(' ').toLowerCase();
}
function __cfxPath(el){
  var s='', cur=el, d=0;
  while(cur&&d<6){ s+=' '+__cfxBlob(cur); cur=cur.parentElement; d++; }
  return s.toLowerCase();
}
function __cfxOwnText(el){
  var t='';
  for(var i=0;i<el.childNodes.length;i++){
    var n=el.childNodes[i];
    if(n.nodeType===3) t+=n.nodeValue||'';
  }
  var own=__cfxNorm(t);
  if(own) return own;
  if(el.tagName&&el.tagName.toLowerCase()==='input') return __cfxNorm(el.value||el.getAttribute('value')||'');
  if(!el.children||el.children.length===0) return __cfxNorm(el.innerText||el.textContent||'');
  return '';
}
var __CFX_BET_HINTS=['bet','play','wager','order','touzhu','xz','chip','game-bet','betting','handicap','盘口','投注','下注','玩法','赔率','选号'];
var __CFX_NOISE=['history','record','trend','chart','help','rule','notice','news','draw','open','result','statistic','统计','历史','走势','说明','开奖','记录','规则','公告','新闻','教程','客服','关于'];
function __cfxInRegion(el){
  var R=window.__CFX_REGION;
  if(!R||!R.enabled) return true;
  var r=el.getBoundingClientRect();
  var cx=r.left+r.width/2, cy=r.top+r.height/2;
  var L=innerWidth*(R.left||0)/100, T=innerHeight*(R.top||0)/100;
  var Rt=innerWidth*(R.right||100)/100, B=innerHeight*(R.bottom||100)/100;
  return cx>=L&&cx<=Rt&&cy>=T&&cy<=B;
}
function __cfxScore(el, label){
  if(!__cfxVisible(el)) return -1e9;
  if(!__cfxInRegion(el)) return -1e9;
  var own=__cfxOwnText(el);
  var full=__cfxNorm(el.innerText||el.textContent||'');
  if(own!==label && full!==label){
    var ownHasLabel = own.indexOf(label)>=0 && own.length<=8;
    var labelHasOwn = own.length>0 && label.indexOf(own)>=0;
    if(!ownHasLabel && !labelHasOwn) return -1e9;
  }
  if(full.length>30 && full!==label) return -1e9;
  if(el.children && el.children.length>12) return -1e9;
  var rect=el.getBoundingClientRect();
  var blob=__cfxPath(el);
  var score=0;
  var tag=(el.tagName||'').toLowerCase();
  if(own===label || full===label) score+=50;
  if(tag==='button'||tag==='a') score+=40;
  if(el.getAttribute('role')==='button') score+=30;
  if(typeof el.onclick==='function'||el.hasAttribute('ng-click')||el.hasAttribute('@click')||el.hasAttribute('onclick')) score+=25;
  if(tag==='input'&&/button|submit/.test(el.type||'')) score+=35;
  if(tag==='div'||tag==='span'||tag==='li'||tag==='label'||tag==='p'||tag==='i'||tag==='em') score+=5;
  for(var i=0;i<__CFX_BET_HINTS.length;i++){ if(blob.indexOf(__CFX_BET_HINTS[i])>=0) score+=28; }
  for(var j=0;j<__CFX_NOISE.length;j++){ if(blob.indexOf(__CFX_NOISE[j])>=0) score-=80; }
  var area=rect.width*rect.height;
  if(rect.width>=24&&rect.width<=200&&rect.height>=22&&rect.height<=90) score+=30;
  if(area<180||area>60000) score-=30;
  var cy=rect.top+rect.height/2;
  if(cy>innerHeight*0.18&&cy<innerHeight*0.92) score+=15;
  if(cy<innerHeight*0.12) score-=40;
  if(cy>innerHeight*0.96) score-=20;
  var parent=el.parentElement;
  if(parent){
    var sib=__cfxNorm(parent.innerText||'');
    if(sib.length<=20){
      if((label==='大'||label==='小')&&sib.indexOf('大')>=0&&sib.indexOf('小')>=0) score+=35;
      if((label==='单'||label==='双')&&sib.indexOf('单')>=0&&sib.indexOf('双')>=0) score+=35;
    } else {
      score-=15;
    }
  }
  if(/active|selected|on|checked|current|choose/.test(blob)) score+=8;
  return score;
}
function __cfxFindBest(label){
  var want=__cfxNorm(label);
  var best=null, bestScore=20;
  // Round 1: high-priority elements only (button, a, role=button, input)
  var prioritySelector='button,a,[role=button],input[type=button],input[type=submit],label,li';
  var allNodes=[];
  try{
    allNodes=allNodes.concat(Array.prototype.slice.call(document.querySelectorAll(prioritySelector)));
  }catch(e){}
  // Round 2: if no hit, expand to all tags
  if(!best){
    var expandedSelector='button,a,[role=button],input[type=button],input[type=submit],label,li,span,div,p,i,em';
    try{
      allNodes=allNodes.concat(Array.prototype.slice.call(document.querySelectorAll(expandedSelector)));
    }catch(e){}
    try{
      var frames=document.querySelectorAll('iframe');
      for(var fi=0;fi<frames.length;fi++){
        try{
          var fd=frames[fi].contentDocument||frames[fi].contentWindow.document;
          if(fd){
            allNodes=allNodes.concat(Array.prototype.slice.call(fd.querySelectorAll(expandedSelector)));
          }
        }catch(e){ }
      }
    }catch(e){}
  }
  for(var i=0;i<allNodes.length;i++){
    var el=allNodes[i];
    if(el.closest && el.closest('header,nav,footer,aside')) continue;
    if(!__cfxInRegion(el)) continue;
    var own=__cfxOwnText(el);
    var full=__cfxNorm(el.innerText||el.textContent||'');
    if(want.length>=2){
      if(own!==want && full!==want && !(own.length>0 && want.indexOf(own)>=0) && !(full.length<=20 && full.indexOf(want)>=0)) continue;
      var sc=__cfxScore(el, want);
      if(own===want||full===want) sc+=40;
      if(sc>bestScore){ bestScore=sc; best=el; }
      continue;
    }
    var sc2=__cfxScore(el, want);
    if(sc2>bestScore){ bestScore=sc2; best=el; }
  }
  return best?{el:best,score:bestScore}:null;
}
function __cfxHighlight(el, ok){
  if(!el) return;
  var prev=el.style.outline;
  el.style.outline=ok?'3px solid #00c853':'3px solid #ff1744';
  setTimeout(function(){ el.style.outline=prev; }, 1200);
}
/* 跨 document 查询 selector（主文档 + 同源 iframe）
 * 改造：selector 匹配多个时，用 expectedText 做二次过滤，选文字最匹配的那个。
 */
function __cfxQuerySelector(sel, expectedText){
  if(!sel) return null;
  expectedText = __cfxNorm(expectedText || '');
  // 1. 主文档
  try{
    var list = document.querySelectorAll(sel);
    if(list.length === 1) return list[0];
    if(list.length > 1 && expectedText) return __cfxPickByTextMatch(list, expectedText);
  }catch(e){}
  // 2. 同源 iframe
  try{
    var frames = document.querySelectorAll('iframe');
    for(var fi=0; fi<frames.length; fi++){
      try{
        var fd = frames[fi].contentDocument || frames[fi].contentWindow.document;
        if(fd){
          list = fd.querySelectorAll(sel);
          if(list.length === 1) return list[0];
          if(list.length > 1 && expectedText) return __cfxPickByTextMatch(list, expectedText);
        }
      }catch(e){}
    }
  }catch(e){}
  return null;
}

/* 从 NodeList 中选文字最匹配 expectedText 的可见元素 */
function __cfxPickByTextMatch(list, expectedText){
  var best = null, bestScore = -1;
  for(var i=0; i<list.length; i++){
    var el = list[i];
    if(!__cfxVisible(el)) continue;
    var own = __cfxOwnText(el);
    var full = __cfxNorm(el.innerText || el.textContent || '');
    var score = 0;
    if(own === expectedText) score += 100;
    if(own.indexOf(expectedText) >= 0 && own.length <= 4) score += 80;
    if(full === expectedText) score += 60;
    if(full.indexOf(expectedText) >= 0 && full.length <= 20) score += 40;
    var blob = __cfxPath(el);
    if(/history|record|trend|chart|rule|历史|走势|记录|规则/.test(blob)) score -= 50;
    var tag = (el.tagName || '').toLowerCase();
    if(tag === 'button' || tag === 'a' || el.getAttribute('role') === 'button') score += 30;
    if(score > bestScore){ bestScore = score; best = el; }
  }
  return bestScore >= 10 ? best : null;
}

function __cfxResolveInput(el){
  if(!el) return null;
  try{
    var tag=(el.tagName||'').toLowerCase();
    if(tag==='input'||tag==='textarea') return el;
    // v2.5.3: 递归查找嵌套的 input/textarea/contenteditable，支持多层包装
    var inner=el.querySelector && el.querySelector('input,textarea,[contenteditable="true"]');
    if(inner) return inner;
    // 再试一次 broad search：有些站点用深层嵌套 div 模拟输入框
    var all=el.querySelectorAll && el.querySelectorAll('input,textarea,[contenteditable="true"]');
    if(all && all.length>0){
      for(var ai=0;ai<all.length;ai++){
        var ael=all[ai];
        if(__cfxVisible(ael)) return ael;
      }
      return all[0];
    }
    return null;
  }catch(e){ return null; }
}

function __cfxClick(el){
  if(!el) return false;
  try{
    el.scrollIntoView({block:'center',inline:'center'});
  }catch(e){}
  try{
    // 精确 selector 只允许一次原生 click。旧版同时派发 pointer/touch/mouse + click，
    // 某些站点会把一次测试当成多次操作，导致“乱点击/重复触发”。
    if(typeof el.click==='function'){
      el.click();
      try{ el.focus && el.focus(); }catch(e){}
      return true;
    }
  }catch(e){}
  return false;
}
function __cfxFindConfirm(){
  var texts=['确认投注','立即下注','马上投注','确认下注','提交订单','立即投注','确认','确定','提交','下注','是的','同意','继续','我知道了','知道了','OK','Ok','ok','YES','Yes','验证通过','二次确认'];
  var nodes=document.querySelectorAll('button,a,[role=button],input[type=button],input[type=submit],div,span');
  /* 也搜索同源 iframe 内的确认按钮 */
  try{
    var frames=document.querySelectorAll('iframe');
    for(var fi=0;fi<frames.length;fi++){
      try{
        var fd=frames[fi].contentDocument||frames[fi].contentWindow.document;
        if(fd) nodes=Array.prototype.concat.call(nodes, fd.querySelectorAll('button,a,[role=button],input[type=button],input[type=submit],div,span'));
      }catch(e){}
    }
  }catch(e){}
  var best=null, bestScore=25;
  for(var i=0;i<nodes.length;i++){
    var el=nodes[i];
    if(!__cfxVisible(el)) continue;
    var text=__cfxNorm(el.innerText||el.value||el.getAttribute('aria-label')||'');
    if(!text||text.length>16) continue;
    var hit=-1;
    for(var t=0;t<texts.length;t++){
      if(text===texts[t]||text.indexOf(texts[t])>=0){ hit=t; break; }
    }
    if(hit<0) continue;
    var sc=40-Math.min(hit,15);
    var blob=__cfxPath(el);
    for(var h=0;h<__CFX_BET_HINTS.length;h++) if(blob.indexOf(__CFX_BET_HINTS[h])>=0) sc+=15;
    for(var n=0;n<__CFX_NOISE.length;n++) if(blob.indexOf(__CFX_NOISE[n])>=0) sc-=50;
    if(el.closest && (el.closest('.modal')||el.closest('[class*=dialog]')||el.closest('[class*=popup]')||el.closest('[class*=mask]')||el.closest('[class*=confirm]'))) sc+=25;
    var r=el.getBoundingClientRect();
    if(r.width>=48&&r.height>=28) sc+=12;
    if(sc>bestScore){ bestScore=sc; best=el; }
  }
  return best;
}
function __cfxInputAmount(amount, noClick){
  if(!amount) return {ok:true,message:'无金额'};
  var inputs=document.querySelectorAll('input[type=text],input[type=number],input:not([type]),textarea');
  /* 也搜索同源 iframe 内的输入框 */
  try{
    var frames=document.querySelectorAll('iframe');
    for(var fi=0;fi<frames.length;fi++){
      try{
        var fd=frames[fi].contentDocument||frames[fi].contentWindow.document;
        if(fd) inputs=Array.prototype.concat.call(inputs, fd.querySelectorAll('input[type=text],input[type=number],input:not([type]),textarea'));
      }catch(e){}
    }
  }catch(e){}
  var target=null, bestSc=0;
  for(var i=0;i<inputs.length;i++){
    var el=inputs[i];
    if(!__cfxVisible(el)) continue;
    var textParts=[__cfxPath(el), (el.placeholder||''), (el.getAttribute&&el.getAttribute('aria-label')||'')];
    /* 关联 <label for> 与父容器文本：不少站点金额框 wording 在 label/父级而不是 placeholder */
    try{
      if(el.id){
        var lab=document.querySelector('label[for="'+el.id+'"]');
        if(lab) textParts.push(lab.innerText||'');
      }
      if(el.closest){
        var wrap=el.closest('div,label,td,li,form');
        if(wrap && wrap.innerText) textParts.push(wrap.innerText.slice(0,40));
      }
    }catch(e){}
    var blob=textParts.join(' ').toLowerCase();
    var sc=0;
    /* 强正选：语义明确指向“金额”的输入框 */
    if(/(金额|下注额|投注额|额度|金额框|amount|money|本金|投入|每注|单注)/.test(blob)) sc+=50;
    if(/金额|额度|amount|money|bet|投注|下注|元/.test(blob)) sc+=25;
    /* 强排除：数量/倍数/注数/搜索类输入框，避免误填（注数1 联动总金额×10 的常见错位） */
    if(/(倍数|倍率|倍投|翻倍|注数|份数|数量|期数|份|count|times|multiple|quantity|share|search|user|pass|账号|密码|手机|验证码|追号|期号)/.test(blob)) sc-=80;
    /* 数字输入 & 语义加分 */
    if((el.type==='number'||el.inputMode==='decimal'||el.pattern==='[0-9.]*') && /(金额|元|额度|amount|money)/.test(blob)) sc+=20;
    if(__cfxInRegion(el)) sc+=10;
    if(sc>bestSc){ bestSc=sc; target=el; }
  }
  if(!target||bestSc<=0){
    var chip=__cfxFindBest(String(amount));
    if(chip && !noClick){ __cfxHighlight(chip.el,true); __cfxClick(chip.el); return {ok:true,message:'点筹码'+amount,ae:null}; }
    return {ok:chip?true:false,message:chip?('点筹码'+amount):'未找到金额框',ae:null};
  }
  /* 设置后回读校验：若站点把值改写为 100 等，如实上报实际值，便于用户调整 */
  var actual = __cfxSetInputValue(target, String(amount));
  var note = (actual===String(amount)) ? ('已填金额'+amount) : ('已填金额'+amount+'，页面显示为'+actual);
  return {ok:true,message:note,actual:actual,ae:target};
}
function __cfxSetInputValue(el, value){
  if(!el) return '';
  try{ el.focus(); }catch(e){}
  try{ el.scrollIntoView({block:'center',inline:'center'}); }catch(e){}
  // v2.5.3: 支持 contenteditable 元素（React/Vue 受控组件用 div 模拟输入框）
  var tag = el.tagName ? el.tagName.toLowerCase() : '';
  var isContentEditable = el.getAttribute && el.getAttribute('contenteditable') === 'true';
  if (isContentEditable || tag === 'div' || tag === 'span' || tag === 'p') {
    try {
      el.innerText = String(value);
      el.textContent = String(value);
      el.dispatchEvent(new InputEvent('input',{bubbles:true,data:String(value),inputType:'insertText'}));
      el.dispatchEvent(new Event('change',{bubbles:true}));
      return String(el.innerText || el.textContent || '');
    } catch(e) {}
  }
  var proto = tag==='textarea' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
  function put(val){
    /* 不要先清空再写：空值会触发站点把金额兜底成默认档（1→10 / 10→100） */
    try{
      var desc = Object.getOwnPropertyDescriptor(proto, 'value');
      if(desc && desc.set) desc.set.call(el, val);
      else el.value = val;
    }catch(e){ el.value = val; }
    /* React 16+ 受控组件：同步 _valueTracker */
    try{
      var tracker = el._valueTracker;
      if(tracker && typeof tracker.setValue === 'function') tracker.setValue(val === '' ? ' ' : '');
    }catch(e){}
    try{ el.dispatchEvent(new InputEvent('input',{bubbles:true,data:val,inputType:'insertText'})); }catch(e){ el.dispatchEvent(new Event('input',{bubbles:true})); }
    try{ el.dispatchEvent(new Event('change',{bubbles:true})); }catch(e){}
    try{ el.dispatchEvent(new KeyboardEvent('keyup',{bubbles:true,key:'0'})); }catch(e){}
  }
  put(String(value));
  var actual = el.value;
  if(String(actual)!==String(value)){
    put(String(value));
    actual = el.value;
  }
  /* 第三次：若仍不符，用 execCommand 兼容旧站 */
  if(String(actual)!==String(value)){
    try{
      el.select && el.select();
      document.execCommand('insertText', false, String(value));
      actual = el.value;
    }catch(e){}
  }
  return String(actual||'');
}

function __cfxConfirmFingerprint(el){
  if(!el) return '';
  try{
    var r=el.getBoundingClientRect();
    var cls=typeof el.className==='string'?el.className:'';
    return (el.tagName||'')+'|'+(el.id||'')+'|'+cls+'|'+(el.innerText||el.value||'').slice(0,12)+'|'+Math.round(r.left)+','+Math.round(r.top);
  }catch(e){ return ''; }
}
/* 成功文案检测：出现这些文案视为确认已完成，停止循环 */
function __cfxHasSuccessText(){
  var t=document.body?(document.body.innerText||document.body.textContent||''):'';
  try{
    var frames=document.querySelectorAll('iframe');
    for(var fi=0;fi<frames.length;fi++){
      try{
        var fd=frames[fi].contentDocument||frames[fi].contentWindow.document;
        if(fd&&fd.body) t+=' '+(fd.body.innerText||fd.body.textContent||'');
      }catch(e){}
    }
  }catch(e){}
  var marks=['投注成功','下单成功','提交成功','出票成功','已成功提交','下单已成功','投注已提交','订单已提交','已受理','成功投注','下注成功','恭喜投注','等待开奖','投注完成','已下注'];
  for(var i=0;i<marks.length;i++){ if(t.indexOf(marks[i])>=0) return marks[i]; }
  return '';
}
/* 失败/余额不足等终止文案 */
function __cfxHasBlockText(){
  var t=document.body?(document.body.innerText||document.body.textContent||''):'';
  try{
    var frames=document.querySelectorAll('iframe');
    for(var fi=0;fi<frames.length;fi++){
      try{
        var fd=frames[fi].contentDocument||frames[fi].contentWindow.document;
        if(fd&&fd.body) t+=' '+(fd.body.innerText||fd.body.textContent||'');
      }catch(e){}
    }
  }catch(e){}
  var marks=['余额不足','下单失败','投注失败','提交失败','超出限额','不能超过','已达上限','请先登录','登录已过期','账户被锁定'];
  for(var i=0;i<marks.length;i++){ if(t.indexOf(marks[i])>=0) return marks[i]; }
  return '';
}
window.__caiFenXiRunCommand=function(CMD){
  var steps=[];
  try{
    window.__CFX_REGION = CMD.region || {enabled:false};
    if(!CMD||!CMD.bets||!CMD.bets.length){
      return {ok:false,message:'指令无注项',steps:steps};
    }
    for(var i=0;i<CMD.bets.length;i++){
      var bet=CMD.bets[i];
      var logical=bet.value||'';
      var label=bet.pageText|| (CMD.labelMap&&CMD.labelMap[logical]) || logical;
      if(!label) continue;
      /* ① selector 精确优先（用户标注过），匹配多个时用 label 文字消歧 */
      var selStr=CMD.selectors && CMD.selectors[logical];
      if(selStr){
        try{
          var selEl=__cfxQuerySelector(selStr, label);
          if(selEl){
            // 若标注到了文字节点父级，尝试可点击子/自身
            if(!__cfxVisible(selEl)){
              var cand = selEl.querySelector && selEl.querySelector('button,a,[role=button],input,label');
              if(cand && __cfxVisible(cand)) selEl = cand;
            }
            if(__cfxVisible(selEl) || (selEl.offsetParent !== null)){
              __cfxHighlight(selEl,true);
              if(!CMD.dryRun) __cfxClick(selEl);
              steps.push({step:'play:'+logical+'→selector',ok:true,method:'selector'});
              continue;
            }
          }
        }catch(e){}
      }
      /* ② 生产执行禁止 DOM 评分兜底：没有精确标注就绝不点击。 */
      steps.push({step:'play:'+logical+'→'+label,ok:false,reason:'selector_required'});
      return {ok:false,message:'玩法【'+label+'】未完成精确标注，已阻止点击',steps:steps};
    }
    return {ok:true,message:'bets_done',steps:steps};
  }catch(err){
    return {ok:false,message:String(err&&err.message||err),steps:steps};
  }
};
/* ===== 分阶段执行（供 Kotlin 侧 postDelayed 调用）===== */
window.__cfxPhase2Amount=function(CMD){
  var amtOk=false, amtMsg='', amtEl=null;
  if(CMD.selectors && CMD.selectors.selector_amount && CMD.amount){
    try{
      var amtEl2=__cfxQuerySelector(CMD.selectors.selector_amount);
      if(amtEl2){
        // 标注可能点到包装层，下钻到真实 input
        amtEl2=__cfxResolveInput(amtEl2);
        if(!amtEl2) throw new Error('金额标注不是输入框');
        var actual=__cfxSetInputValue(amtEl2, String(CMD.amount));
        amtOk=true;
        amtMsg=(actual===String(CMD.amount)) ? ('selector已填金额'+CMD.amount) : ('selector已填金额'+CMD.amount+'，页面显示为'+actual);
        amtEl=amtEl2;
      }
    }catch(e){}
  }
  if(!amtOk){
    return {ok:false,message:'金额输入框 selector 未标注 — 请在执行台「标注模式」中点击金额输入框元素完成标注',ae:null};
  }
  return {ok:amtOk,message:amtMsg,ae:amtEl?__cfxPath(amtEl):null};
};
/* Phase2.5 金额复核：站点可能在 input 联动里异步改写金额（1→10 / 10→100），
   Kotlin 侧在填完金额后延迟复核，若页面值与期望不符则再次写入，返回最终实际值 */
window.__cfxPhase2Verify=function(CMD){
  if(!CMD.amount) return {ok:true,message:'无金额可复核'};
  try{
    var ae=null;
    if(CMD.selectors && CMD.selectors.selector_amount){
      ae=__cfxQuerySelector(CMD.selectors.selector_amount);
      ae=__cfxResolveInput(ae);
      if(ae && !__cfxVisible(ae)) ae=null;
    }
    if(!ae){
      return {ok:false,message:'金额输入框 selector 标注缺失/失效 — 请在执行台「标注模式」重新点击金额输入框，或检查 selector 是否因页面结构变化而失效'};
    }
    var cur=String(ae.value||'');
    if(cur!==String(CMD.amount)){
      var rw=__cfxSetInputValue(ae,String(CMD.amount));
      cur=String(ae.value||'');
      return {ok:(cur===String(CMD.amount)),message:('复核已重设：期望'+CMD.amount+'，页面显示为'+cur),actual:cur};
    }
    return {ok:true,message:('金额复核通过：'+cur),actual:cur};
  }catch(e){
    return {ok:false,message:'金额复核异常:'+(e&&e.message||e)};
  }
};
/* 自动清除站点残留的 modal 遮罩层（半透明黑屏卡死修复） */
function __cfxClearModalOverlay(){
  try{
    var all=document.querySelectorAll('*');
    var cleared=0;
    for(var i=0;i<all.length;i++){
      var el=all[i];
      if(!el || el===document || el===document.body) continue;
      var st=window.getComputedStyle(el);
      if(!st) continue;
      // 特征1: fixed/absolute 定位
      var pos=st.position;
      if(pos!=='fixed' && pos!=='absolute') continue;
      // 特征2: 覆盖大部分屏幕
      var r=el.getBoundingClientRect();
      var vw=window.innerWidth, vh=window.innerHeight;
      if(r.width<vw*0.7 || r.height<vh*0.7) continue;
      // 特征3: 半透明黑色背景
      var bg=st.backgroundColor||st.background||'';
      var isDarkOverlay=false;
      if(bg.indexOf('rgba')===0){
        var m=bg.match(/rgba?\((\d+),\s*(\d+),\s*(\d+),\s*([\d.]+)\)/);
        if(m){
          var r0=parseInt(m[1]), g0=parseInt(m[2]), b0=parseInt(m[3]), a0=parseFloat(m[4]||'1');
          if(r0<80 && g0<80 && b0<80 && a0>0.3 && a0<1.0) isDarkOverlay=true;
        }
      } else if(bg==='#000' || bg==='#000000' || bg.indexOf('rgb(0,0,0)')===0){
        var op=parseFloat(st.opacity||'1');
        if(op<1.0 && op>0.3) isDarkOverlay=true;
      }
      if(!isDarkOverlay) continue;
      // 特征4: z-index 较高
      var z=parseInt(st.zIndex||'0');
      if(z<10) continue;
      // 特征5: 子元素很少（纯遮罩层，不是内容容器）
      var childCount=el.children?el.children.length:0;
      if(childCount>3) continue;
      // 清除: 隐藏而非删除，避免破坏页面结构
      el.style.display='none';
      el.style.visibility='hidden';
      el.style.pointerEvents='none';
      cleared++;
    }
    return {cleared:cleared};
  }catch(e){
    return {cleared:0,error:e&&e.message||''};
  }
}

/* ===== 实时遮罩拦截守卫（MutationObserver + rAF 双重拦截）=====
 * 在点击确认前启动，确保遮罩元素在浏览器绘制前被隐藏，用户完全看不到闪烁。
 * 原理：MutationObserver 回调在浏览器 paint 前同步触发，
 *   在回调中设置 display:none 可阻止该帧绘制遮罩；
 *   rAF 每帧扫描捕获已有元素 style/class 变化（display:none→block）。
 */
window.__CFX_OVERLAY_OBSERVER = null;
window.__CFX_OVERLAY_RAF = null;
window.__CFX_OVERLAY_TIMER = null;

/* 检查单个元素是否符合遮罩特征，符合则立即隐藏（不破坏页面结构） */
function __cfxCheckAndHideOverlay(el){
  if(!el || el === document || el === document.body) return false;
  try{
    var st = window.getComputedStyle(el);
    if(!st) return false;
    var pos = st.position;
    if(pos !== 'fixed' && pos !== 'absolute') return false;
    var r = el.getBoundingClientRect();
    var vw = window.innerWidth, vh = window.innerHeight;
    if(r.width < vw*0.7 || r.height < vh*0.7) return false;
    var bg = st.backgroundColor || st.background || '';
    var isDarkOverlay = false;
    if(bg.indexOf('rgba') === 0){
      var m = bg.match(/rgba?\((\d+),\s*(\d+),\s*(\d+),\s*([\d.]+)\)/);
      if(m){
        var r0 = parseInt(m[1]), g0 = parseInt(m[2]), b0 = parseInt(m[3]), a0 = parseFloat(m[4] || '1');
        if(r0 < 80 && g0 < 80 && b0 < 80 && a0 > 0.3 && a0 < 1.0) isDarkOverlay = true;
      }
    } else if(bg === '#000' || bg === '#000000' || bg.indexOf('rgb(0,0,0)') === 0){
      var op = parseFloat(st.opacity || '1');
      if(op < 1.0 && op > 0.3) isDarkOverlay = true;
    }
    if(!isDarkOverlay) return false;
    var z = parseInt(st.zIndex || '0');
    if(z < 10) return false;
    var childCount = el.children ? el.children.length : 0;
    if(childCount > 3) return false;
    el.style.display = 'none';
    el.style.visibility = 'hidden';
    el.style.pointerEvents = 'none';
    return true;
  }catch(e){ return false; }
}

/* 启动遮罩拦截守卫 */
window.__cfxStartOverlayGuard = function(timeout){
  __cfxStopOverlayGuard();
  __cfxClearModalOverlay();
  try{
    var observer = new MutationObserver(function(mutations){
      for(var mi = 0; mi < mutations.length; mi++){
        var added = mutations[mi].addedNodes;
        for(var ai = 0; ai < added.length; ai++){
          var node = added[ai];
          if(!node || node.nodeType !== 1) continue;
          __cfxCheckAndHideOverlay(node);
          if(node.querySelectorAll){
            try{
              var children = node.querySelectorAll('*');
              for(var ci = 0; ci < children.length; ci++){
                __cfxCheckAndHideOverlay(children[ci]);
              }
            }catch(e){}
          }
        }
      }
    });
    observer.observe(document.documentElement || document.body, {
      childList: true,
      subtree: true
    });
    window.__CFX_OVERLAY_OBSERVER = observer;
  }catch(e){}
  var startTime = Date.now();
  var duration = timeout || 6000;
  function rafScan(){
    try{
      var candidates = document.querySelectorAll(
        '[class*="mask"],[class*="overlay"],[class*="modal"],[class*="dialog"],[class*="popup"],[class*="shadow"]'
      );
      for(var i = 0; i < candidates.length; i++){
        __cfxCheckAndHideOverlay(candidates[i]);
      }
      if(document.body){
        var bc = document.body.children;
        for(var bi = 0; bi < bc.length; bi++){
          __cfxCheckAndHideOverlay(bc[bi]);
        }
      }
    }catch(e){}
    if(Date.now() - startTime < duration){
      window.__CFX_OVERLAY_RAF = requestAnimationFrame(rafScan);
    } else {
      __cfxStopOverlayGuard();
    }
  }
  window.__CFX_OVERLAY_RAF = requestAnimationFrame(rafScan);
  window.__CFX_OVERLAY_TIMER = setTimeout(function(){
    __cfxStopOverlayGuard();
  }, duration);
};

/* 停止遮罩拦截守卫 */
window.__cfxStopOverlayGuard = function(){
  if(window.__CFX_OVERLAY_OBSERVER){
    try{ window.__CFX_OVERLAY_OBSERVER.disconnect(); }catch(e){}
    window.__CFX_OVERLAY_OBSERVER = null;
  }
  if(window.__CFX_OVERLAY_RAF){
    try{ cancelAnimationFrame(window.__CFX_OVERLAY_RAF); }catch(e){}
    window.__CFX_OVERLAY_RAF = null;
  }
  if(window.__CFX_OVERLAY_TIMER){
    try{ clearTimeout(window.__CFX_OVERLAY_TIMER); }catch(e){}
    window.__CFX_OVERLAY_TIMER = null;
  }
  try{ __cfxClearModalOverlay(); }catch(e){}
};

window.__cfxPhase3Confirm=function(CMD){
  var out={ok:false,finished:false,clicked:false,message:'',rounds:[]};
  var dryRun=!!CMD.dryRun;
  /* 0) 金额最终校验：Phase3 前站点异步改写已生效，此时校验最真实。
        若页面金额 ≠ 期望值：重写一次再读；仍不符则阻止确认，避免以错误金额下注 */
  if(CMD.amount){
    try{
      var ae=null;
      if(CMD.selectors && CMD.selectors.selector_amount){
        ae=__cfxResolveInput(__cfxQuerySelector(CMD.selectors.selector_amount));
        if(ae && !__cfxVisible(ae)) ae=null;
      }
      if(!ae){
        out.ok=false; out.finished=true;
        out.message='金额输入框 selector 标注缺失/失效 — 请在执行台「标注模式」重新点击金额输入框，或检查 selector 是否因页面结构变化而失效';
        return out;
      }
      if(ae){
        var cur=String(ae.value||'');
        if(cur!==String(CMD.amount)){
          var rew=__cfxSetInputValue(ae,String(CMD.amount));
          var cur2=String(ae.value||'');
          if(cur2!==String(CMD.amount)){
            out.ok=false; out.finished=true;
            out.message='金额被页面改写为'+cur2+'（期望'+CMD.amount+'），已阻止确认';
            return out;
          }
        }
      }
    }catch(e){
      out.message='金额校验异常:'+(e&&e.message||e);
    }
  }
  /* 1) 找确认按钮：selector 精确优先；评分兜底跳过已点过的 */
  var conf=null, fp='';
  if(CMD.selectors && CMD.selectors.selector_confirm){
    try{
      var selEl=__cfxQuerySelector(CMD.selectors.selector_confirm);
      if(selEl && (__cfxVisible(selEl) || selEl.offsetParent!==null || (selEl.getClientRects&&selEl.getClientRects().length))){
        fp=__cfxConfirmFingerprint(selEl);
        if(window.__CFX_CONFIRMED_FPS[fp]) fp='';
        else conf=selEl;
      }
    }catch(e){}
  }
  if(!conf){
    /* selector 未标注/失效时仍检查页面成功/阻止文案，避免遗漏已实际完成的投注 */
    var doneText=__cfxHasSuccessText();
    var blockText=__cfxHasBlockText();
    if(doneText){
      out.ok=true; out.finished=true;
      out.message='完成：'+doneText;
    } else if(blockText){
      out.ok=false; out.finished=true;
      out.message='阻止：'+blockText;
    } else {
      out.ok=false; out.finished=true;
      out.message='确认按钮 selector 未标注/失效 — 请在执行台「标注模式」中点击确认按钮完成标注';
    }
    return out;
  }
  var txt=__cfxNorm(conf.innerText||conf.value||'');
  __cfxHighlight(conf,true);
  /* ★ 在点击确认前启动实时遮罩拦截守卫，确保遮罩在 paint 前被隐藏，用户看不到闪烁 */
  if(!dryRun){
    try{ window.__cfxStartOverlayGuard(6000); }catch(e){}
  }
  if(!dryRun) __cfxClick(conf);
  if(fp) window.__CFX_CONFIRMED_FPS[fp]=true;
  out.ok=true;
  out.clicked=true;
  out.message='已点击确认：'+txt;
  out.rounds.push({round:1,ok:true,text:txt});
  /* 守卫已在点击前启动，这里做一次即时清理（捕获同步出现的遮罩），
     守卫的 MutationObserver + rAF 会持续拦截异步出现的遮罩 */
  var clr=__cfxClearModalOverlay();
  if(clr.cleared>0) out.message+='；即时清除'+clr.cleared+'个遮罩层';
  /* 不再用 setTimeout 延迟清理：守卫的 rAF 每帧扫描 + MutationObserver 同步拦截已覆盖 */
  return out;
};
