package com.caifenxi.app.domain.strategy

import com.caifenxi.app.domain.execution.BetCommand
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.LotteryConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * 策略引擎：独立于原有 PlanEngine，管理策略池的生命周期、预测记录、careerStats。
 *
 * 职责：
 * - 生成预测并记录历史
 * - 结算预测对错
 * - 维护 careerStats（命中率、连中连挂、权重）
 * - 提供 BetCommand 转换接口（挂机互通用）
 */
class StrategyEngine {

    /** 所有计划的运行时状态 */
    private val _runtimeMap = MutableStateFlow<Map<String, StrategyRuntime>>(emptyMap())
    val runtimeMap: StateFlow<Map<String, StrategyRuntime>> = _runtimeMap

    /** 预测历史记录（按计划ID分组） */
    private val historyMap = mutableMapOf<String, MutableList<StrategyPredictionRecord>>()

    /** 当前预测结果（最新一期） */
    private val _currentPredictions = MutableStateFlow<Map<String, StrategyPrediction>>(emptyMap())
    val currentPredictions: StateFlow<Map<String, StrategyPrediction>> = _currentPredictions

    /** 已添加到挂机的计划ID集合 */
    private val _subscribedPlans = MutableStateFlow<Set<String>>(emptySet())
    val subscribedPlans: StateFlow<Set<String>> = _subscribedPlans

    /** 回测结果缓存 */
    private val _backtestReports = MutableStateFlow<Map<String, StrategyBacktestReport>>(emptyMap())
    val backtestReports: StateFlow<Map<String, StrategyBacktestReport>> = _backtestReports

    /**
     * 为指定计划生成预测
     */
    fun predict(plan: StrategyDefinition, history: List<DrawRecord>): StrategyPrediction? {
        if (history.size < 5) return null
        val prediction = PredictEngineV2.predict(plan, history) ?: return null
        _currentPredictions.value = _currentPredictions.value + (plan.planId to prediction)

        // 记录预测历史
        val targetIssue = history.lastOrNull()?.nextIssue ?: ""
        val cutoffIssue = history.lastOrNull()?.issue ?: ""
        val record = StrategyPredictionRecord(
            planId = plan.planId,
            lotteryKey = history.lastOrNull()?.lotteryKey.orEmpty(),
            targetIssue = targetIssue,
            cutoffIssue = cutoffIssue,
            output = prediction.output,
            track = plan.track,
            playType = plan.playType,
            createdAt = System.currentTimeMillis()
        )
        val hist = historyMap.getOrPut(plan.planId) { mutableListOf() }
        // 同计划同期号替换未结算记录
        hist.removeAll { it.planId == plan.planId && it.targetIssue == targetIssue && !it.settled }
        hist.add(record)
        return prediction
    }

    /**
     * 批量预测所有计划（或指定轨道）
     */
    fun predictAll(plans: List<StrategyDefinition>, history: List<DrawRecord>) {
        plans.forEach { plan ->
            predict(plan, history)
        }
    }

    /**
     * 结算某期预测
     */
    fun settle(plan: StrategyDefinition, actual: DrawRecord) {
        val hist = historyMap[plan.planId] ?: return
        val unsettled = hist.filter { !it.settled && it.targetIssue == actual.issue }
        for (rec in unsettled) {
            val hit = PredictEngineV2.evaluate(plan, rec.output, actual)
            val idx = hist.indexOf(rec)
            if (idx >= 0) {
                hist[idx] = rec.copy(settled = true, hit = hit, settledAt = System.currentTimeMillis())
            }
            updateRuntime(plan.planId, hit)
        }
    }

    /** 更新运行时状态 */
    private fun updateRuntime(planId: String, hit: Boolean) {
        val current = _runtimeMap.value[planId] ?: StrategyRuntime(planId)
        val newRt = current.copy(
            sampleCount = current.sampleCount + 1,
            hitCount = current.hitCount + if (hit) 1 else 0,
            consecutiveHit = if (hit) current.consecutiveHit + 1 else 0,
            consecutiveMiss = if (hit) 0 else current.consecutiveMiss + 1,
            maxConsecutiveHit = maxOf(current.maxConsecutiveHit, if (hit) current.consecutiveHit + 1 else current.maxConsecutiveHit),
            maxConsecutiveMiss = maxOf(current.maxConsecutiveMiss, if (!hit) current.consecutiveMiss + 1 else current.maxConsecutiveMiss)
        )
        _runtimeMap.value = _runtimeMap.value + (planId to newRt)
    }

    /**
     * 运行回测并缓存结果
     */
    fun runBacktest(
        plan: StrategyDefinition,
        history: List<DrawRecord>,
        periods: Int,
        stake: Double,
        stage: Int,
        invert: Boolean = false,
        algoWindow: Int = 0,
        winRateWindow: Int = 20
    ): StrategyBacktestReport {
        val report = StrategyAnalytics.chartBacktest(plan, history, periods, stake, stage, invert, algoWindow, winRateWindow)
        val key = "${plan.planId}_s${stage}"
        _backtestReports.value = _backtestReports.value + (key to report)
        // 同步运行时状态
        _runtimeMap.value = _runtimeMap.value + (plan.planId to StrategyRuntime(
            planId = plan.planId,
            sampleCount = report.total,
            hitCount = report.hits,
            consecutiveMiss = report.currentMissStreak,
            consecutiveHit = report.currentHitStreak,
            maxConsecutiveMiss = report.maxMissStreak,
            maxConsecutiveHit = report.maxHitStreak,
            recent10Rate = if (report.points.isNotEmpty()) report.points.takeLast(10).count { it.hit }.toDouble() / minOf(10, report.points.size) else 0.0,
            recent50Rate = if (report.points.isNotEmpty()) report.points.takeLast(50).count { it.hit }.toDouble() / minOf(50, report.points.size) else 0.0,
            weight = 1.0
        ))
        return report
    }

    /**
     * 将策略池计划转换为 BetCommand（挂机互通用）
     */
    fun toBetCommand(
        plan: StrategyDefinition,
        lotteryKey: String,
        issue: String,
        amount: Double,
        stage: Int = 1,
        leg: Int = 0
    ): BetCommand? {
        val prediction = _currentPredictions.value[plan.planId] ?: return null
        return StrategyAnalytics.toBetCommand(plan, prediction, lotteryKey, issue, amount, stage, leg)
    }

    /**
     * 订阅计划到挂机页（添加到挂机下注列表）
     */
    fun subscribeToBet(planId: String) {
        _subscribedPlans.value = _subscribedPlans.value + planId
    }

    /** 取消订阅 */
    fun unsubscribeFromBet(planId: String) {
        _subscribedPlans.value = _subscribedPlans.value - planId
    }

    /** 获取已订阅计划的 BetCommand 列表（供挂机页拉取） */
    fun getBetCommands(
        history: List<DrawRecord>,
        lotteryKey: String,
        issue: String,
        amount: Double,
        stage: Int
    ): List<Pair<StrategyDefinition, BetCommand>> {
        val lotType = LotteryConfig.findByKey(lotteryKey)?.type
        return _subscribedPlans.value.flatMap { planId ->
            val plan = StrategyPool.byId(planId) ?: return@flatMap emptyList()
            if (plan.supportedTypes.isNotEmpty() && lotType != null && lotType !in plan.supportedTypes) return@flatMap emptyList()
            // 确保有最新预测——直接从缓存取，不重算
            if (_currentPredictions.value[planId] == null) predict(plan, history)
            val prediction = _currentPredictions.value[planId] ?: return@flatMap emptyList()
            // 二期/三期：同一预测方向生成多腿 BetCommand
            val legs = stage.coerceIn(1, 3)
            (0 until legs).map { leg ->
                plan to StrategyAnalytics.toBetCommand(plan, prediction, lotteryKey, issue, amount, stage, leg)
            }
        }
    }

    /**
     * 获取已订阅计划的预测方向（含二期三期多腿），直接从缓存取，不重算。
     * 返回：planId -> (plan, prediction, stage, 各腿方向列表)
     */
    fun getSubscribedPredictions(
        history: List<DrawRecord>,
        lotteryKey: String,
        stage: Int
    ): List<Triple<StrategyDefinition, StrategyPrediction, Int>> {
        val lotType = LotteryConfig.findByKey(lotteryKey)?.type
        return _subscribedPlans.value.mapNotNull { planId ->
            val plan = StrategyPool.byId(planId) ?: return@mapNotNull null
            if (plan.supportedTypes.isNotEmpty() && lotType != null && lotType !in plan.supportedTypes) return@mapNotNull null
            // 确保有预测——如果没有则生成一次
            if (_currentPredictions.value[planId] == null) predict(plan, history)
            val pred = _currentPredictions.value[planId] ?: return@mapNotNull null
            Triple(plan, pred, stage.coerceIn(1, 3))
        }
    }

    /** 获取计划历史记录 */
    fun getHistory(planId: String): List<StrategyPredictionRecord> =
        historyMap[planId]?.toList() ?: emptyList()

    /** 获取回测报告 */
    fun getBacktestReport(planId: String, stage: Int): StrategyBacktestReport? =
        _backtestReports.value["${planId}_s${stage}"]
}
