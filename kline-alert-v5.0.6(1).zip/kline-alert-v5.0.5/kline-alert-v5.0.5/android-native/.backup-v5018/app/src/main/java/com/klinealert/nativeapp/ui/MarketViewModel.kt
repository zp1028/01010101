package com.klinealert.nativeapp.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.klinealert.nativeapp.data.LocalStore
import com.klinealert.nativeapp.data.MarketRepository
import com.klinealert.nativeapp.service.BackgroundMonitorService
import com.klinealert.nativeapp.service.SetupNotifier
import com.klinealert.nativeapp.domain.Analysis
import com.klinealert.nativeapp.domain.AnalysisEngine
import com.klinealert.nativeapp.domain.Candle
import com.klinealert.nativeapp.domain.ReviewEngine
import com.klinealert.nativeapp.domain.ReviewRecord
import com.klinealert.nativeapp.domain.OpportunityFusion
import com.klinealert.nativeapp.domain.SymbolOpportunity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.WebSocket
import java.util.concurrent.ConcurrentHashMap

 /** 美股/指数实时报价（Stooq 免费源，延迟行情） */
 data class UsQuote(val symbol: String, val name: String, val price: Double, val chgPct: Double)

 /** 品种机会确认结果聚合（来自训练闭环 features） */
 data class ConfirmStat(
     val symbol: String, val total: Int, val confirmed: Int, val retest: Int,
     val unconfirmed: Int, val unknown: Int, val rate: Double
 )

 /** 品种维度的历史机会胜率聚合（训练闭环结算数据） */
 data class SymbolWinStat(
     val symbol: String, val market: String, val total: Int, val hits: Int, val misses: Int,
     val rate: Double, val bestDir: String, val bestDirRate: Double, val openCount: Int
 )

 /** 诊断页运行日志（内存环形缓冲，不落盘）。 */
data class RuntimeLogEntry(
    val at: Long,
    val level: String,  // INFO / WARN / ERROR
    val tag: String,
    val message: String
)

data class MarketUiState(
    val market: String = "SPOT", val timeframe: String = "15m", val symbol: String = "",
    val instruments: Int = 0, val livePrice: Double? = null, val changePct: Double? = null,
    val scanning: Boolean = false, val progress: Int = 0, val total: Int = 0,
    val scanTimeframes: Set<String> = setOf("15m"), val searchQuery: String = "", val minConfidence: Int = 0,
    val status: String = "就绪", val results: List<Analysis> = emptyList(), val error: String? = null,
    val alertMessage: String? = null, val reviewSummary: String = "反馈：加载中",
    val positions: List<LocalStore.LocalPosition> = emptyList(), val showPositions: Boolean = false,
    val positionPrices: Map<String, Double> = emptyMap(),
    val tab: String = "home", val history: List<ReviewRecord> = emptyList(),
    val oppPrices: Map<String, Pair<Double, Double>> = emptyMap(),
    val symbolOps: List<SymbolOpportunity> = emptyList(),
    val watchlist: Set<String> = emptySet(),
    val winStats: List<String> = emptyList(),
    val tfWinRates: Map<String, Pair<Int, Double>> = emptyMap(),
    val learnedWeights: Map<String, Double> = emptyMap(),
    val oppHealth: Map<String, com.klinealert.nativeapp.domain.SignalHealth> = emptyMap(),
    val oppStreamSockets: Int = 0,
    val lastTickAt: Long = 0L,
    val patternStats: List<com.klinealert.nativeapp.domain.PatternStat> = emptyList(),
    val oppConfirm: Map<String, com.klinealert.nativeapp.domain.Confirmation> = emptyMap(),
    val powerSave: Boolean = false,
    // AI（可选功能：未配置时全部能力优雅隐藏，本地算法照常运行）
    val aiConfigured: Boolean = false,
    val aiBaseUrl: String = "",
    val aiKey: String = "",
    val aiModel: String = "",
    val aiModels: List<String> = emptyList(),
    val aiTestMsg: String? = null,
    val aiBusy: String? = null,          // "config" | "brief" | "market|symbol"
    val aiInsights: Map<String, String> = emptyMap(),
    val aiBrief: String? = null,
    // 胜率排行榜（按品种聚合的本地结算胜率）
    val maxPositions: Int = 3,
    val usQuotes: List<UsQuote> = emptyList(),
    val usWatch: Set<String> = emptySet(),
    val confirmRank: List<ConfirmStat> = emptyList(),
    val winRank: List<SymbolWinStat> = emptyList(),
    val winRankPage: Int = 1,
    val winDetail: Pair<String, List<ReviewRecord>>? = null,
    // 同质化信号：宽松显示（全部展示，默认）或严格合并（同方向同阶段只留最强）
    val strictMerge: Boolean = false,
    // v3.7 四维证据分：key = "market|symbol"
    val evidence: Map<String, com.klinealert.nativeapp.domain.EvidenceEngine.Evidence> = emptyMap(),
    // v3.8 待命单：key = "market|symbol|direction"
    val setups: Map<String, com.klinealert.nativeapp.domain.PendingSetup> = emptyMap(),
    // v4.0 AI 复核结果：key = 待命单 key
    val setupReviews: Map<String, String> = emptyMap(),
    val aiReviewing: String? = null,
    /** v4.3 交叉校验参考源状态：可用 / 参考价条数 / 上次错误 */
    val crossCheckOk: Boolean = false, val crossCheckCount: Int = 0, val crossCheckError: String = "",
    /** v4.4 通知深链高亮品种（点击通知进入后高亮对应卡片，自动清除） */
    val highlightSymbol: String? = null,
    /** v4.4 回测校准报告（诊断页展示） */
    val backtest: com.klinealert.nativeapp.domain.BacktestAnalyzer.Report? = null,
    /** v4.5 自动作战循环：全自动入仓/平仓/候补顶上，上限 maxPositions */
    val autoBattle: Boolean = true,        // 自动作战总开关（用户确认全自动 → 默认开）
    val trailingEnabled: Boolean = false,  // 移动止盈/固定止盈切换（默认固定 3R 式到价平）
    /** v5.0.9 全局止盈止损乘数：止损距离 = stopMult×ATR/风险距离，止盈距离 = targetMult×风险距离；
     *  盈亏比 = targetMult/stopMult。仅影响新机会/新入仓，已在仓价格不动。 */
    val stopMult: Double = com.klinealert.nativeapp.domain.BattleLoopEngine.DEFAULT_STOP_MULT,
    val targetMult: Double = com.klinealert.nativeapp.domain.BattleLoopEngine.DEFAULT_TARGET_MULT,
    val battleQueue: List<String> = emptyList(),  // 候补队列展示（"SYMBOL 方向 分"）
    val battleEntered: Int = 0,            // 自动入仓累计（本会话）
    val battleClosed: Int = 0,             // 自动平仓累计（本会话）
    val battleWins: Int = 0,               // 自动止盈胜（本会话）
    val battleLosses: Int = 0,             // 自动止损负（本会话）
    val battlePnlSum: Double = 0.0,        // 自动平仓累计 USDT（与 battleHistory 同步，可跨会话从库重算）
    /** 自动作战已平仓明细（id 以 auto| 开头的 review），按平仓时间倒序 */
    val battleHistory: List<ReviewRecord> = emptyList(),
    val showBattleHistory: Boolean = false,
    /** v5.0.10 持仓品种资金费率（8h 结算费率，symbol → rate；0.0001 = 0.01%），15 分钟定时刷新 */
    val fundingRates: Map<String, Double> = emptyMap(),
    /** v5.0.11 持仓行情流已断开的品种（socket 断开，UI 标注"·已断开"；重连后首个 tick 清除） */
    val stalePositions: Set<String> = emptySet(),
    /** v5.0.14 满仓轮换开关（新信号显著更优时自动平最差换新，默认关） */
    val battleRotateEnabled: Boolean = false,
    /** v5.0.14 自动补位最小间隔（ms，默认 60s；空仓首次补位不受限） */
    val battleFillIntervalMs: Long = 60_000L,
    /** v5.0.15 价值区入场总开关：true=等价格回到支撑/压力价值区且止跌确认才给可开仓（默认开）；false=回退旧"现价"入场 */
    val valueZoneEntry: Boolean = true,
    /** v5.0.15 入场状态（key="$market|$symbol|$direction" → 入场决策），供三榜/战斗卡片展示 观察/到位/可开仓/失效 */
    val entryDecisions: Map<String, com.klinealert.nativeapp.domain.EntryDecision> = emptyMap(),
    /** v5.0.15 历史回放验证（价值区 vs 现价）运行状态与结果行 */
    val replayRunning: Boolean = false,
    val replayRows: List<com.klinealert.nativeapp.domain.ReplayRow> = emptyList(),
    /** v5.0.16 信号延续管理：到目标评估趋势，能延续则移动止损/目标并标「延续×n」，否则止盈结束 */
    val continuationEnabled: Boolean = true,
    // ── v5.0.17 目标分档（方案甲）全局参数 ──
    /** 分档模式：AUTO=按质量自动判 / FORCE_STEADY=全部稳健 / FORCE_AGGRESSIVE=全部进取 */
    val tierMode: String = com.klinealert.nativeapp.domain.TargetTier.MODE_AUTO,
    /** 稳健档目标 R（进取目标复用 targetMult，v5.0.17 起其语义即"目标盈亏比 R"） */
    val steadyR: Double = com.klinealert.nativeapp.domain.TargetTier.DEFAULT_STEADY_R,
    val breakEvenR: Double = com.klinealert.nativeapp.domain.TargetTier.DEFAULT_BREAK_EVEN_R,
    val tierMinScore: Int = com.klinealert.nativeapp.domain.TargetTier.DEFAULT_MIN_SCORE,
    val tierMomentumVol: Double = com.klinealert.nativeapp.domain.TargetTier.DEFAULT_MOMENTUM_VOL,
    val tierAdxStrong: Double = com.klinealert.nativeapp.domain.TargetTier.DEFAULT_ADX_STRONG,
    /** v5.0.17 统一平仓台账：所有平仓路径（手动/止盈/止损/保本/反转/轮换）都记账，工作台统计唯一来源 */
    val closedStats: com.klinealert.nativeapp.data.LocalStore.ClosedTradeStats? = null,
    val closedHistory: List<com.klinealert.nativeapp.data.LocalStore.ClosedTrade> = emptyList(),
    // ─── 币安跟单 ───
    val tradeConnected: Boolean = false,
    val tradePendingConfirm: Boolean = false,
    val tradeConfig: com.klinealert.nativeapp.domain.TradeModels.TradeConfig =
        com.klinealert.nativeapp.domain.TradeModels.TradeConfig(),
    val tradeAccount: com.klinealert.nativeapp.domain.TradeModels.AccountSnapshot =
        com.klinealert.nativeapp.domain.TradeModels.AccountSnapshot(),
    val tradeOpenLinks: List<com.klinealert.nativeapp.domain.TradeModels.TradeLink> = emptyList(),
    val tradeHistory: List<com.klinealert.nativeapp.domain.TradeModels.TradeLink> = emptyList(),
    val tradeStats: com.klinealert.nativeapp.domain.TradeModels.TradeStats =
        com.klinealert.nativeapp.domain.TradeModels.TradeStats(),
    val tradeLogs: List<com.klinealert.nativeapp.domain.TradeModels.TradeLog> = emptyList(),
    val tradeBusy: Boolean = false,
    val tradeMessage: String? = null,
    val tradeDualSide: Boolean = false,
    val tradeHistoryRange: String = "today",
    /** v5.0.12 今日跟单进度（日开仓次数/日亏损熔断可视化） */
    val tradeTodayOpens: Int = 0,
    val tradeTodayPnl: Double = 0.0,
    /** 诊断运行日志（新在前，最多约 200 条） */
    val runtimeLogs: List<RuntimeLogEntry> = emptyList()
)

class MarketViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = MarketRepository()
    private val localStore = LocalStore(application)
    private val tradeClient = com.klinealert.nativeapp.data.BinanceTradeClient()
    private val tradeBridge = com.klinealert.nativeapp.domain.TradeBridge(localStore, tradeClient)
    private var tradeCreds: com.klinealert.nativeapp.data.BinanceTradeClient.Credentials? = null
    private var tradeReconcileJob: Job? = null
    /** v4.3 交易所交叉校验参考源（Gate.io 现货价），用于防单源插针误触发 */
    private val crossCheck = com.klinealert.nativeapp.data.CrossCheckSource()
    private var crossCheckJob: Job? = null
    private val _state = MutableStateFlow(MarketUiState())
    val state: StateFlow<MarketUiState> = _state.asStateFlow()
    private var tickerSocket: WebSocket? = null
    private var klineSocket: WebSocket? = null
    /** v3.9 时间去重：同品种同方向 4 小时内只允许 1 次机会 */
    private val setupCooldown = java.util.concurrent.ConcurrentHashMap<String, Long>()
    /** v3.9 二次入场：首次触发后的记录（key → 触发信息） */
    private val secondEntryMark = java.util.concurrent.ConcurrentHashMap<String, Long>()
    /** v4.5 自动作战平仓冷却：key = "symbol|direction" → 平仓时刻（冷却期内不自动重入） */
    private val battleCooldowns = java.util.concurrent.ConcurrentHashMap<String, Long>()
    /** v5.0.14 自动补位防抖：上次补位时刻 */
    private var lastBattleFillAt = 0L
    /** v5.0.14 持仓入场综合分（positionId → battleScore），满仓轮换基准 */
    private val battleEntryScores = java.util.concurrent.ConcurrentHashMap<String, Double>()
    /** v5.0.15 入场评估用 K 线快照（key="$market|$timeframe|$symbol" → 最近 300 根），供价值区/结构判定 */
    private val entryCandles = java.util.concurrent.ConcurrentHashMap<String, List<Candle>>()
    /** v4.5 自动入仓 in-flight 防重：写库完成前不重复入同一品种 */
    private val autoEnterInFlight = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
    private var scanJob: Job? = null
    private var historyJob: Job? = null
    private var reconnectJob: Job? = null
    private var fundingJob: Job? = null
    /** v5.0.11 网络切换去抖：2s 内只重建一次实时流 */
    private var lastNetworkChangeAt = 0L
    /** ticker 与 kline 各自独立的代际计数：每次 startLive 递增，旧 socket 延迟到达的
     *  onClosed/onFailure 回调因代际不匹配被忽略，避免"幽灵重连"掐断新连接。
     *  独立计数比合并计数更细（v5.0.8 吸收 v5.0.7 思路）：ticker 流与 kline 流互不干扰。 */
    @Volatile private var tickerGeneration = 0L
    @Volatile private var klineGeneration = 0L
    /** ticker 重连退避计数（成功建连/收到首个 tick 后归零）。 */
    @Volatile private var reconnectAttempt = 0
    private val universeSockets = mutableListOf<WebSocket>()
    private var universeReconnectJob: Job? = null
    @Volatile private var universeReconnectAttempt: Int = 0
    private val positionTickerSockets = mutableListOf<WebSocket>()
    private var positionTickerReconnectJob: Job? = null
    @Volatile private var positionTickerGeneration: Long = 0L
    @Volatile private var lastScannedSymbols: List<String> = emptyList()
    @Volatile private var lastScannedMarket: String = ""
    @Volatile private var lastScannedTimeframe: String = ""
    @Volatile private var universeGeneration: Long = 0L
    @Volatile private var universeOwnsSelectedKline: Boolean = false
    private val lastUniverseOpenTimes = ConcurrentHashMap<String, Long>()
    private val alertCooldown = ConcurrentHashMap<String, Long>()
    private val universeBackfillsInFlight = ConcurrentHashMap.newKeySet<String>()
    @Volatile private var candleCache: List<Candle> = emptyList()
    @Volatile private var foreground = false

    init {
        loadCachedResults(_state.value.market, _state.value.timeframe)
        loadReviewSummary(_state.value.market)
        loadPositions(_state.value.market)
        loadPendingSetups()   // v4.2 恢复重启前的待命单（长周期机会不因重启丢失）
        _state.value = _state.value.copy(watchlist = loadWatchlistPrefs(), powerSave = settingsPrefs().getBoolean("power_save", false))
        loadAiPrefs()
        _state.value = _state.value.copy(maxPositions = settingsPrefs().getInt("max_positions", com.klinealert.nativeapp.domain.BattleLoopEngine.DEFAULT_MAX_POSITIONS))
        // v4.5 自动作战：全自动开关 + 移动/固定止盈切换（默认全自动开、固定止盈）
        _state.value = _state.value.copy(
            autoBattle = settingsPrefs().getBoolean("auto_battle", true),
            trailingEnabled = settingsPrefs().getBoolean("trailing_enabled", false),
            // v5.0.9 全局止盈止损乘数（持久化，重启不丢）
            stopMult = settingsPrefs().getFloat("stop_mult", com.klinealert.nativeapp.domain.BattleLoopEngine.DEFAULT_STOP_MULT.toFloat()).toDouble(),
            targetMult = settingsPrefs().getFloat("target_mult", com.klinealert.nativeapp.domain.BattleLoopEngine.DEFAULT_TARGET_MULT.toFloat()).toDouble(),
            // v5.0.14 满仓轮换开关 + 补位防抖间隔（持久化）
            battleRotateEnabled = settingsPrefs().getBoolean("battle_rotate", false),
            battleFillIntervalMs = settingsPrefs().getLong("battle_fill_interval", 60_000L),
            // v5.0.15 价值区入场开关（默认开，可回退到现价）
            valueZoneEntry = settingsPrefs().getBoolean("entry_value_zone", true),
            // v5.0.16 信号延续管理（默认开，可回退到固定/吊灯止盈）
            continuationEnabled = settingsPrefs().getBoolean("continuation_enabled", true),
            // v5.0.17 目标分档（方案甲）全局参数（持久化，重启不丢）
            tierMode = settingsPrefs().getString("tier_mode", com.klinealert.nativeapp.domain.TargetTier.MODE_AUTO)
                ?: com.klinealert.nativeapp.domain.TargetTier.MODE_AUTO,
            steadyR = settingsPrefs().getFloat("tier_steady_r", com.klinealert.nativeapp.domain.TargetTier.DEFAULT_STEADY_R.toFloat()).toDouble(),
            breakEvenR = settingsPrefs().getFloat("tier_breakeven_r", com.klinealert.nativeapp.domain.TargetTier.DEFAULT_BREAK_EVEN_R.toFloat()).toDouble(),
            tierMinScore = settingsPrefs().getInt("tier_min_score", com.klinealert.nativeapp.domain.TargetTier.DEFAULT_MIN_SCORE),
            tierMomentumVol = settingsPrefs().getFloat("tier_momentum_vol", com.klinealert.nativeapp.domain.TargetTier.DEFAULT_MOMENTUM_VOL.toFloat()).toDouble(),
            tierAdxStrong = settingsPrefs().getFloat("tier_adx_strong", com.klinealert.nativeapp.domain.TargetTier.DEFAULT_ADX_STRONG.toFloat()).toDouble()
        )
        refreshClosedLedger()   // v5.0.17 启动即加载平仓台账（工作台统计）
        // v4.8 审计：自动作战冷却从 DB 恢复（进程被杀/重启不丢，防同品种立即重入）
        runCatching { localStore.loadCooldowns() }.getOrDefault(emptyMap()).forEach { (k, v) -> battleCooldowns[k] = v }
        // 后台实时监控：上次开启过则随 App 启动自动恢复（前台服务 + K线流预警）
        if (settingsPrefs().getBoolean("bg_monitor", true)) {   // v4.6：默认常驻后台，退出不全部断联
            val s0 = _state.value
            runCatching {
                BackgroundMonitorService.start(getApplication(), s0.market, s0.scanTimeframes.filter { it in AnalysisEngine.supportedTimeframes }.ifEmpty { listOf(s0.timeframe) })
            } // 通知权限未授予等场景不阻断启动
        }
        settleBacklog()
        maybeDailyReport()
        startCrossCheck()   // v4.3 启动交叉校验参考价定时刷新
        startFundingRefresh()   // v5.0.10 持仓品种资金费率定时刷新
        loadTradePrefs()
        refreshTradeLinks()
    }

    // ═══════════════════════ 币安跟单 ═══════════════════════

    private fun tradePrefs() =
        getApplication<Application>().getSharedPreferences("binance_trade", android.content.Context.MODE_PRIVATE)

    private fun loadTradePrefs() {
        val p = tradePrefs()
        val cfg = com.klinealert.nativeapp.domain.TradeModels.TradeConfig(
            enabled = p.getBoolean("enabled", false),
            testnet = p.getBoolean("testnet", true),
            marginUsdt = p.getFloat("margin_usdt", 10f).toDouble(),
            maxLeverageCap = p.getInt("max_lev_cap", 20),
            useMaxLeverage = p.getBoolean("use_max_lev", true),
            maxFollowSlots = p.getInt("max_slots", 3),
            onlyAutoBattle = p.getBoolean("only_auto", true),
            slipProtectPct = p.getFloat("slip_pct", 0.5f).toDouble(),
            dailyMaxOpens = p.getInt("daily_max_opens", 20),
            dailyMaxLossUsdt = p.getFloat("daily_max_loss", 50f).toDouble(),
            symbolDirCooldownMs = p.getLong("sd_cooldown", 90_000L),
            maxFollowAgeMs = p.getLong("max_follow_age", 5 * 60_000L),
            minStopGapRatio = p.getFloat("stop_gap_ratio", 0.3f).toDouble(),
            rejectOnTightStop = p.getBoolean("reject_tight_stop", true)
        )
        val key = p.getString("api_key", "") ?: ""
        val sec = p.getString("api_secret", "") ?: ""
        val connected = p.getBoolean("connected", false) && key.isNotBlank() && sec.isNotBlank()
        if (connected) {
            tradeCreds = com.klinealert.nativeapp.data.BinanceTradeClient.Credentials(key, sec, cfg.testnet)
        }
        _state.value = _state.value.copy(tradeConfig = cfg, tradeConnected = connected)
        if (connected) {
            refreshTradeAccount()
            if (cfg.enabled) startTradeReconcileLoop()
        }
    }

    private fun persistTradeConfig(cfg: com.klinealert.nativeapp.domain.TradeModels.TradeConfig) {
        tradePrefs().edit()
            .putBoolean("enabled", cfg.enabled)
            .putBoolean("testnet", cfg.testnet)
            .putFloat("margin_usdt", cfg.marginUsdt.toFloat())
            .putInt("max_lev_cap", cfg.maxLeverageCap)
            .putBoolean("use_max_lev", cfg.useMaxLeverage)
            .putInt("max_slots", cfg.maxFollowSlots)
            .putBoolean("only_auto", cfg.onlyAutoBattle)
            .putFloat("slip_pct", cfg.slipProtectPct.toFloat())
            .putInt("daily_max_opens", cfg.dailyMaxOpens)
            .putFloat("daily_max_loss", cfg.dailyMaxLossUsdt.toFloat())
            .putLong("sd_cooldown", cfg.symbolDirCooldownMs)
            .putLong("max_follow_age", cfg.maxFollowAgeMs)
            .putFloat("stop_gap_ratio", cfg.minStopGapRatio.toFloat())
            .putBoolean("reject_tight_stop", cfg.rejectOnTightStop)
            .apply()
        _state.value = _state.value.copy(tradeConfig = cfg)
    }

    fun updateTradeConfig(cfg: com.klinealert.nativeapp.domain.TradeModels.TradeConfig) {
        persistTradeConfig(cfg)
    }

    fun setTradeFollowEnabled(on: Boolean) {
        if (on && !_state.value.tradeConnected) {
            _state.value = _state.value.copy(tradeMessage = "请先连接并确认 API 账户")
            return
        }
        persistTradeConfig(_state.value.tradeConfig.copy(enabled = on))
        _state.value = _state.value.copy(
            tradeMessage = if (on) "全自动跟单已开启：将跟随持仓监控市价开仓并挂同价止盈止损"
            else "跟单已关闭"
        )
        if (on) startTradeReconcileLoop() else stopTradeReconcileLoop()
    }

    private fun startTradeReconcileLoop() {
        if (tradeReconcileJob?.isActive == true) return
        tradeReconcileJob = viewModelScope.launch(Dispatchers.IO) {
            while (true) {
                kotlinx.coroutines.delay(20_000L)
                if (!_state.value.tradeConfig.enabled || !_state.value.tradeConnected) break
                val c = tradeCreds ?: break
                val notes = runCatching { tradeBridge.reconcileAndRefreshMarks(c, _state.value.tradeDualSide) }.getOrDefault(emptyList())
                notes.forEach { pushTradeLog("-", "对账", true, it) }
                withContext(Dispatchers.Main) {
                    refreshTradeLinks()
                    if (notes.isNotEmpty()) refreshTradeAccount()
                }
            }
        }
    }

    private fun stopTradeReconcileLoop() {
        tradeReconcileJob?.cancel()
        tradeReconcileJob = null
    }

    /** 步骤：验证 Key，进入确认页（不落库密钥直到 confirm）。 */
    fun tradeVerify(apiKey: String, secret: String, testnet: Boolean) {
        if (apiKey.isBlank() || secret.isBlank()) {
            _state.value = _state.value.copy(tradeMessage = "请填写 API Key 与 Secret")
            return
        }
        _state.value = _state.value.copy(tradeBusy = true, tradeMessage = "正在验证…")
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val creds = com.klinealert.nativeapp.data.BinanceTradeClient.Credentials(apiKey.trim(), secret.trim(), testnet)
                val (avail, wallet, upnl) = tradeClient.balanceUsdt(creds)
                val dual = runCatching { tradeClient.isDualSidePosition(creds) }.getOrDefault(false)
                val mask = apiKey.trim().takeLast(4).let { "****$it" }
                withContext(Dispatchers.Main) {
                    tradeCreds = creds
                    _state.value = _state.value.copy(
                        tradeBusy = false,
                        tradePendingConfirm = true,
                        tradeDualSide = dual,
                        tradeAccount = com.klinealert.nativeapp.domain.TradeModels.AccountSnapshot(
                            availableBalance = avail, walletBalance = wallet, totalUnrealized = upnl,
                            canTrade = true, positionMode = if (dual) "双向持仓" else "单向持仓",
                            accountIdMask = mask, fetchedAt = System.currentTimeMillis()
                        ),
                        tradeConfig = _state.value.tradeConfig.copy(testnet = testnet),
                        tradeMessage = "验证成功，请确认账户信息后启用"
                    )
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    tradeCreds = null
                    _state.value = _state.value.copy(
                        tradeBusy = false, tradePendingConfirm = false,
                        tradeMessage = "验证失败：${e.message}"
                    )
                }
            }
        }
    }

    /** 登入返回确认：写入密钥并标记已连接。 */
    fun tradeConfirmEnable() {
        val c = tradeCreds ?: return
        tradePrefs().edit()
            .putString("api_key", c.apiKey)
            .putString("api_secret", c.secret)
            .putBoolean("connected", true)
            .putBoolean("testnet", c.testnet)
            .apply()
        persistTradeConfig(_state.value.tradeConfig.copy(testnet = c.testnet))
        _state.value = _state.value.copy(
            tradeConnected = true, tradePendingConfirm = false,
            tradeMessage = "已启用 · 可用 ${_state.value.tradeAccount.availableBalance} USDT"
        )
        refreshTradeAccount()
        refreshTradeLinks()
    }

    fun tradeCancelConfirm() {
        tradeCreds = null
        _state.value = _state.value.copy(tradePendingConfirm = false, tradeMessage = "已取消连接")
    }

    fun tradeDisconnect() {
        setTradeFollowEnabled(false)
        tradeCreds = null
        tradePrefs().edit().putBoolean("connected", false).remove("api_key").remove("api_secret").apply()
        _state.value = _state.value.copy(
            tradeConnected = false, tradePendingConfirm = false,
            tradeAccount = com.klinealert.nativeapp.domain.TradeModels.AccountSnapshot(),
            tradeMessage = "已断开并清除本机密钥"
        )
    }

    fun refreshTradeAccount() {
        val c = tradeCreds ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val (avail, wallet, upnl) = tradeClient.balanceUsdt(c)
                val dual = runCatching { tradeClient.isDualSidePosition(c) }.getOrDefault(_state.value.tradeDualSide)
                withContext(Dispatchers.Main) {
                    _state.value = _state.value.copy(
                        tradeDualSide = dual,
                        tradeAccount = _state.value.tradeAccount.copy(
                            availableBalance = avail, walletBalance = wallet, totalUnrealized = upnl,
                            canTrade = true, fetchedAt = System.currentTimeMillis()
                        )
                    )
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    _state.value = _state.value.copy(tradeMessage = "刷新余额失败：${e.message}")
                }
            }
        }
    }

    fun refreshTradeLinks() {
        viewModelScope.launch(Dispatchers.IO) {
            val open = localStore.loadTradeLinks(com.klinealert.nativeapp.domain.TradeModels.STATUS_OPEN, 50) +
                localStore.loadTradeLinks(com.klinealert.nativeapp.domain.TradeModels.STATUS_PENDING_OPEN, 20) +
                localStore.loadTradeLinks(com.klinealert.nativeapp.domain.TradeModels.STATUS_CLOSING, 20)
            val closed = localStore.loadTradeLinks(com.klinealert.nativeapp.domain.TradeModels.STATUS_CLOSED, 200)
            val range = _state.value.tradeHistoryRange
            val now = System.currentTimeMillis()
            val filtered = when (range) {
                "today" -> {
                    val start = java.util.Calendar.getInstance().apply {
                        set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0)
                        set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
                    }.timeInMillis
                    closed.filter { it.closedAt >= start }
                }
                "7d" -> closed.filter { it.closedAt >= now - 7L * 86400_000 }
                "30d" -> closed.filter { it.closedAt >= now - 30L * 86400_000 }
                else -> closed
            }
            val stats = com.klinealert.nativeapp.domain.TradeModels.statsFrom(filtered, open.filter {
                it.status == com.klinealert.nativeapp.domain.TradeModels.STATUS_OPEN
            })
            // v5.0.12 今日进度：今日开仓数（OPEN+PENDING_OPEN+CLOSED 的 openedAt≥今日0点）与今日已实现盈亏
            val dayStart = java.util.Calendar.getInstance().apply {
                set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0)
                set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
            }.timeInMillis
            val todayOpened = (open + closed).count { it.openedAt >= dayStart }
            val todayPnl = closed.filter { it.closedAt >= dayStart }.sumOf { it.realizedPnlNet }
            withContext(Dispatchers.Main) {
                _state.value = _state.value.copy(
                    tradeOpenLinks = open.sortedByDescending { it.updatedAt },
                    tradeHistory = filtered.sortedByDescending { it.closedAt },
                    tradeStats = stats,
                    tradeTodayOpens = todayOpened,
                    tradeTodayPnl = todayPnl
                )
            }
        }
    }

    fun setTradeHistoryRange(r: String) {
        _state.value = _state.value.copy(tradeHistoryRange = r)
        refreshTradeLinks()
    }

    fun clearRuntimeLogs() {
        _state.value = _state.value.copy(runtimeLogs = emptyList())
    }

    /** 写入诊断运行日志（线程安全：仅在主线程或通过 withContext Main 调用更稳妥；此处允许任意线程写 StateFlow）。 */
    fun appendRuntimeLog(level: String, tag: String, message: String) {
        val msg = message.trim()
        if (msg.isEmpty()) return
        val entry = RuntimeLogEntry(System.currentTimeMillis(), level, tag, msg.take(400))
        // 去抖：与上一条完全相同则跳过
        val cur = _state.value.runtimeLogs
        if (cur.isNotEmpty() && cur[0].tag == tag && cur[0].message == entry.message && System.currentTimeMillis() - cur[0].at < 1500) return
        _state.value = _state.value.copy(runtimeLogs = (listOf(entry) + cur).take(200))
    }

    private fun pushTradeLog(symbol: String, action: String, ok: Boolean, detail: String) {
        val log = com.klinealert.nativeapp.domain.TradeModels.TradeLog(System.currentTimeMillis(), symbol, action, ok, detail)
        _state.value = _state.value.copy(tradeLogs = (listOf(log) + _state.value.tradeLogs).take(50))
        appendRuntimeLog(if (ok) "INFO" else "ERROR", "跟单", "$symbol $action · $detail")
    }

    /** 监控页新仓 → 尝试实盘开仓（去重在 Bridge 内）。 */
    fun onLocalPositionOpenedForTrade(p: LocalStore.LocalPosition) {
        val cfg = _state.value.tradeConfig
        if (!cfg.enabled || !_state.value.tradeConnected) return
        // 仅跟随合约相关仓（market 含 FUTURE / 或符号为 USDT 永续命名）
        val m = p.market.uppercase()
        if (m.contains("SPOT") && !m.contains("FUTURE")) {
            pushTradeLog(p.symbol, "开仓跳过", true, "OPEN_SKIP_SPOT")
            return
        }
        val creds = tradeCreds ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val req = com.klinealert.nativeapp.domain.TradeBridge.OpenRequest(
                localPositionId = p.id, symbol = p.symbol, direction = p.direction,
                entry = p.entry, stop = p.stop, target = p.target,
                source = if (p.note.contains("自动")) "auto" else p.note.ifBlank { "manual" },
                localCreatedAt = p.createdAt
            )
            when (val r = tradeBridge.tryOpen(creds, cfg, req, _state.value.tradeDualSide)) {
                is com.klinealert.nativeapp.domain.TradeBridge.Result.Ok -> {
                    pushTradeLog(p.symbol, "开仓", true, r.message)
                    withContext(Dispatchers.Main) {
                        _state.value = _state.value.copy(tradeMessage = "${p.symbol} ${r.message}")
                        refreshTradeLinks(); refreshTradeAccount()
                    }
                }
                is com.klinealert.nativeapp.domain.TradeBridge.Result.Skip -> {
                    pushTradeLog(p.symbol, "开仓跳过", true, r.reason)
                }
                is com.klinealert.nativeapp.domain.TradeBridge.Result.Err -> {
                    pushTradeLog(p.symbol, "开仓失败", false, r.reason)
                    withContext(Dispatchers.Main) {
                        _state.value = _state.value.copy(tradeMessage = "${p.symbol} 开仓失败：${r.reason}")
                        refreshTradeLinks()
                    }
                }
            }
        }
    }

    fun onLocalPositionClosedForTrade(localPositionId: String, reason: String) {
        if (!_state.value.tradeConfig.enabled || !_state.value.tradeConnected) return
        val creds = tradeCreds ?: return
        viewModelScope.launch(Dispatchers.IO) {
            when (val r = tradeBridge.tryClose(creds, _state.value.tradeConfig, localPositionId, reason, _state.value.tradeDualSide)) {
                is com.klinealert.nativeapp.domain.TradeBridge.Result.Ok -> {
                    pushTradeLog(r.link.symbol, "平仓", true, r.message)
                    withContext(Dispatchers.Main) {
                        _state.value = _state.value.copy(tradeMessage = r.message)
                        refreshTradeLinks(); refreshTradeAccount()
                    }
                }
                is com.klinealert.nativeapp.domain.TradeBridge.Result.Skip ->
                    pushTradeLog("-", "平仓跳过", true, r.reason)
                is com.klinealert.nativeapp.domain.TradeBridge.Result.Err ->
                    pushTradeLog("-", "平仓失败", false, r.reason)
            }
        }
    }

    /** v4.3 交叉校验：每 45 秒刷新一次独立交易所参考价（不阻断主流程，失败静默降级）。 */
    private fun startCrossCheck() {
        if (crossCheckJob?.isActive == true) return
        crossCheckJob = viewModelScope.launch(Dispatchers.IO) {
            while (true) {
                runCatching { crossCheck.refresh() }
                val (ok, cnt, err) = crossCheck.status()
                _state.value = _state.value.copy(crossCheckOk = ok, crossCheckCount = cnt, crossCheckError = err)
                kotlinx.coroutines.delay(45_000L)
            }
        }
    }

    /** v5.0.10 资金费率：每 15 分钟刷新一次持仓品种 8h 结算费率（失败静默，不阻断主流程）。 */
    private fun startFundingRefresh() {
        if (fundingJob?.isActive == true) return
        fundingJob = viewModelScope.launch(Dispatchers.IO) {
            while (true) {
                refreshFundingRates()
                kotlinx.coroutines.delay(15 * 60_000L)
            }
        }
    }

    /** 拉取当前持仓品种资金费率并更新 state；持仓为空时清空。 */
    private suspend fun refreshFundingRates() {
        val symbols = _state.value.positions.map { it.symbol }.distinct()
        if (symbols.isEmpty()) {
            _state.value = _state.value.copy(fundingRates = emptyMap())
            return
        }
        val rates = runCatching { repo.fundingRates(symbols) }.getOrDefault(emptyMap())
        _state.value = _state.value.copy(fundingRates = rates)
    }

    /** 启动补结算：未决超过 1h 的记录拉 K 线回填结算，避免长期不结算的样本污染胜率。 */
    private fun settleBacklog() {
        viewModelScope.launch(Dispatchers.IO) {
            val market = _state.value.market
            val open = runCatching { localStore.loadReviews(market, 1000) }.getOrDefault(emptyList())
                .filter { it.verdict == "open" && System.currentTimeMillis() - it.alertedAt > 3_600_000L }
                .take(40)
            val now = System.currentTimeMillis()
            open.forEach { rec ->
                val candles = runCatching { repo.candles(rec.symbol, rec.market, rec.timeframe, 300) }.getOrNull() ?: return@forEach
                val afterAlert = candles.filter { it.openTime > rec.alertedAt }
                if (afterAlert.isEmpty()) return@forEach
                val expired = ReviewEngine.expire(rec, now)
                val updated = if (expired.verdict != "open") expired
                else ReviewEngine.settle(rec, ReviewEngine.touch(afterAlert, rec), now)
                if (updated != rec) runCatching { localStore.updateReview(updated) }
            }
            if (open.isNotEmpty()) loadReviewSummary(market)
        }
    }

    private fun watchlistPrefs() = getApplication<Application>().getSharedPreferences("watchlist", android.content.Context.MODE_PRIVATE)
    private fun settingsPrefs() = getApplication<Application>().getSharedPreferences("settings", android.content.Context.MODE_PRIVATE)

    fun togglePowerSave() {
        val next = !_state.value.powerSave
        settingsPrefs().edit().putBoolean("power_save", next).apply()
        _state.value = _state.value.copy(powerSave = next, alertMessage = if (next) "省电模式开启：实时流缩减至 40 个品种" else "省电模式关闭：实时流恢复 120 个品种")
        if (foreground && lastScannedSymbols.isNotEmpty()) startOppTickers(lastScannedSymbols, _state.value.market, _state.value.timeframe)
    }
    private fun loadWatchlistPrefs(): Set<String> = watchlistPrefs().getStringSet("symbols", emptySet())?.toSet() ?: emptySet()

    // ------------------------------------------------------------------ //
    // AI 大模型（OpenAI 兼容端点，完全可选：未配置时功能隐藏，本地算法不受影响）
    // ------------------------------------------------------------------ //
    private var aiCfg = com.klinealert.nativeapp.domain.AiClient.defaultConfig

    private fun loadAiPrefs() {
        val p = settingsPrefs()
        aiCfg = com.klinealert.nativeapp.domain.AiClient.Config(
            p.getString("ai_base_url", com.klinealert.nativeapp.domain.AiClient.defaultConfig.baseUrl) ?: "",
            p.getString("ai_key", "") ?: "",
            p.getString("ai_model", "") ?: ""
        )
        _state.value = _state.value.copy(aiConfigured = aiCfg.configured, aiBaseUrl = aiCfg.baseUrl, aiKey = aiCfg.apiKey, aiModel = aiCfg.model)
    }

    fun saveAiConfig(baseUrl: String, key: String, model: String) {
        aiCfg = com.klinealert.nativeapp.domain.AiClient.Config(baseUrl, key, model)
        settingsPrefs().edit()
            .putString("ai_base_url", baseUrl).putString("ai_key", key).putString("ai_model", model)
            .apply()
        _state.value = _state.value.copy(
            aiConfigured = aiCfg.configured, aiBaseUrl = aiCfg.baseUrl, aiKey = aiCfg.apiKey, aiModel = aiCfg.model,
            aiTestMsg = if (aiCfg.configured) "已保存 AI 配置" else "配置未完整（需要链接+密钥+模型），AI 功能暂不启用"
        )
    }

    fun fetchAiModels() {
        _state.value = _state.value.copy(aiBusy = "config", aiTestMsg = "正在获取模型列表…")
        viewModelScope.launch {
            val r = com.klinealert.nativeapp.domain.AiClient.listModels(aiCfg)
            r.fold(onSuccess = { models ->
                _state.value = _state.value.copy(aiBusy = null, aiModels = models, aiTestMsg = "获取到 ${models.size} 个模型，点击选择")
            }, onFailure = { e ->
                _state.value = _state.value.copy(aiBusy = null, aiModels = emptyList(), aiTestMsg = "获取失败：${e.message}")
            })
        }
    }

    fun testAiConnection() {
        _state.value = _state.value.copy(aiBusy = "config", aiTestMsg = "正在测试连接…")
        viewModelScope.launch {
            val r = com.klinealert.nativeapp.domain.AiClient.test(aiCfg)
            r.fold(onSuccess = { reply ->
                _state.value = _state.value.copy(aiBusy = null, aiTestMsg = "✅ 连接成功：${reply.take(40)}", aiConfigured = aiCfg.configured)
            }, onFailure = { e ->
                _state.value = _state.value.copy(aiBusy = null, aiTestMsg = "❌ ${e.message}")
            })
        }
    }

    fun selectAiModel(model: String) {
        saveAiConfig(aiCfg.baseUrl, aiCfg.apiKey, model)
    }

    /** 单机会 AI 解读：把算法产出的结构化数据包交给模型做因果解读（禁止喊单） */
    /** v4.0：待命单触发后的 AI 复核（只解读、不喊单；未配置 AI 时静默跳过） */
    private fun aiReviewSetup(st: com.klinealert.nativeapp.domain.PendingSetup) {
        if (!aiCfg.configured) return
        if (_state.value.aiReviewing != null) return
        _state.value = _state.value.copy(aiReviewing = st.key)
        val sop = _state.value.symbolOps.firstOrNull { it.symbol == st.symbol && it.direction == st.direction }
        val prompt = buildString {
            append("【待命单已触发】品种 ${st.symbol}（${st.market}）方向 ${st.direction}，周期 ${st.timeframe}\n")
            append("触发价 ${st.triggerPrice}，失效价 ${st.invalidPrice}，止损 ${st.stop}，3R止盈 ${st.target3R}，证据分 ${st.evidenceScore}\n")
            append("三门：位置${if (st.gatePosition) "过" else "未过"} 信号${if (st.gateSignal) "过" else "未过"} 时间${if (st.gateTime) "过" else "未过"}；触发说明「${st.note}」\n")
            sop?.let { s ->
                val a = s.rep
                append("阶段「${a.regime}」量价形态「${a.volumePattern}」RSI ${a.rsi14?.toInt() ?: "-"} ADX ${a.adx.toInt()} ATR% ${String.format(java.util.Locale.US, "%.2f", a.atrPct)}\n")
                append("状态：${a.states.take(4).joinToString("；") { it.compact() }}\n")
                if (s.plan.isNotEmpty()) append("本地计划：${s.plan.joinToString(" | ")}\n")
            }
        }
        viewModelScope.launch {
            val r = com.klinealert.nativeapp.domain.AiClient.chat(
                aiCfg,
                "你是加密技术面复核员。对这笔已触发的机会做一次快速复核，严格输出模板：\n【结论】值得做 / 谨慎 / 放弃（三选一）\n【理由】≤80字\n【需盯的信号】≤50字\n规则：只解读数据不喊单；不确定就说谨慎；中文；总长 ≤180 字。",
                prompt, maxTokens = 1200
            )
            r.fold(
                onSuccess = { text -> _state.value = _state.value.copy(aiReviewing = null, setupReviews = _state.value.setupReviews + (st.key to text)) },
                onFailure = { e -> _state.value = _state.value.copy(aiReviewing = null, setupReviews = _state.value.setupReviews + (st.key to "AI 复核失败：${e.message ?: "未知错误"}")) }
            )
        }
    }

    fun aiExplain(sop: SymbolOpportunity) {
        if (!aiCfg.configured) {
            _state.value = _state.value.copy(aiTestMsg = "请先在诊断页配置 AI（链接/密钥/模型）")
            return
        }
        val key = "${sop.market}|${sop.symbol}"
        if (_state.value.aiBusy != null) return
        _state.value = _state.value.copy(aiBusy = key)
        val prompt = buildString {
            append("品种 ${sop.symbol}（${sop.market}）方向 ${sop.direction}，综合分 ${sop.score}，置信度 ${sop.confidence}，等级 ${sop.grade}，共振 ${sop.resonanceCount}，反向 ${sop.oppositeCount}\n")
            sop.perTimeframe.values.filterNotNull().forEach { a ->
                append("· ${a.timeframe}：${a.direction} 分${a.score} 信${a.confidence} 状态「${a.regime}」RSI ${a.rsi14?.toInt() ?: "-"} ADX ${a.adx.toInt()} ATR% ${String.format(java.util.Locale.US, "%.2f", a.atrPct)}")
                if (a.patterns.isNotEmpty()) append(" 模式:${a.patterns.joinToString("/")}")
                append(" 状态:${a.states.take(3).joinToString("；") { it.compact() }}\n")
            }
            append("代表周期 ${sop.rep.timeframe}；关键位 支撑${sop.rep.support} 压力${sop.rep.resistance}\n")
            if (sop.plan.isNotEmpty()) append("交易计划：${sop.plan.joinToString(" | ")}\n")
        }
        viewModelScope.launch {
            val r = com.klinealert.nativeapp.domain.AiClient.chat(
                aiCfg,
                "你是加密货币技术面分析解读员。基于给定的本地算法输出做综合解读，严格输出模板：\n【延续理由】…\n【衰竭信号】…\n【风险点】…\n【建议动作区间】…\n规则：只解读数据，不得新造买卖指令；不喊单；不预测具体价格；控制在 250 字内；中文。",
                prompt, maxTokens = 2000
            )
            r.fold(onSuccess = { text ->
                _state.value = _state.value.copy(aiBusy = null, aiInsights = _state.value.aiInsights + (key to text))
            }, onFailure = { e ->
                _state.value = _state.value.copy(aiBusy = null, aiTestMsg = "AI 解读失败：${e.message}")
            })
        }
    }

    /** AI 扫描研判：对当前扫描出的 Top 机会做全局排序与风险提示（辅助生成机会视角，不替代算法） */
    fun aiScanBrief() {
        if (!aiCfg.configured) {
            _state.value = _state.value.copy(aiTestMsg = "请先在诊断页配置 AI（链接/密钥/模型）")
            return
        }
        if (_state.value.aiBusy != null) return
        val ops = _state.value.symbolOps.take(12)
        if (ops.isEmpty()) {
            _state.value = _state.value.copy(aiTestMsg = "请先扫描出机会后再做 AI 研判")
            return
        }
        _state.value = _state.value.copy(aiBusy = "brief")
        val prompt = buildString {
            append("以下是本地算法全市场扫描后的 Top 机会（已含 14 项加权门槛与确认状态），请做全局研判：\n")
            ops.forEach { sop ->
                val c = confirmations["${sop.market}|${sop.symbol}|${sop.direction}"]
                append("· ${sop.symbol} ${sop.direction} 分${sop.score} 信${sop.confidence} ${sop.grade}级 共振${sop.resonanceCount} ${sop.rep.timeframe} ${sop.rep.regime} 确认:${c?.status ?: "无"}\n")
            }
        }
        viewModelScope.launch {
            val r = com.klinealert.nativeapp.domain.AiClient.chat(
                aiCfg,
                "你是加密货币交易机会研判助手。输入是本地量化算法筛选出的候选机会列表。输出：\n1) 最值得优先观察的 3 个（附一句理由，引用给定数据）\n2) 互相矛盾/需回避的品种与原因\n3) 一条整体市场感觉（仅基于给定信息）\n规则：不得创造列表之外的机会；不下单指令；200 字内；中文。",
                prompt, maxTokens = 2000
            )
            r.fold(onSuccess = { text ->
                _state.value = _state.value.copy(aiBusy = null, aiBrief = text)
            }, onFailure = { e ->
                _state.value = _state.value.copy(aiBusy = null, aiTestMsg = "AI 研判失败：${e.message}")
            })
        }
    }

    fun loadMoreWinRank() {
        _state.value = _state.value.copy(winRankPage = _state.value.winRankPage + 1)
    }

    fun openWinDetail(symbol: String) {
        val market = _state.value.market
        viewModelScope.launch(Dispatchers.IO) {
            val rows = runCatching { localStore.loadReviews(market, 1000) }.getOrDefault(emptyList())
                .filter { it.symbol == symbol }.sortedByDescending { it.alertedAt }
            withContext(Dispatchers.Main) { _state.value = _state.value.copy(winDetail = symbol to rows) }
        }
    }

    fun closeWinDetail() {
        _state.value = _state.value.copy(winDetail = null)
    }

    fun toggleWatch(symbol: String) {
        val next = _state.value.watchlist.toMutableSet()
        if (!next.add(symbol)) next.remove(symbol)
        watchlistPrefs().edit().putStringSet("symbols", next).apply()
        _state.value = _state.value.copy(watchlist = next)
        // 关注品种立即纳入实时行情流
        if (foreground) startOppTickers((next + lastScannedSymbols).toList(), _state.value.market, _state.value.timeframe)
    }

    private fun loadReviewSummary(market: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val counts = runCatching { localStore.reviewCounts(market) }.getOrDefault(emptyMap())
            val summary = "反馈：跟踪 ${counts["open"] ?: 0} · 命中 ${counts["hit"] ?: 0} · 落空 ${counts["miss"] ?: 0} · 平局 ${counts["neutral"] ?: 0}"
            // M4：按评分段 / 方向的本地信号胜率（已结算样本）
            val rows = runCatching { localStore.loadReviews(market, 1000) }.getOrDefault(emptyList())
            val settled = rows.filter { it.verdict == "hit" || it.verdict == "miss" }
            fun rate(list: List<ReviewRecord>): String {
                val hits = list.count { it.verdict == "hit" }
                return if (list.isEmpty()) "样本不足" else String.format(java.util.Locale.US, "%.0f%%（%d/%d）", hits * 100.0 / list.size, hits, list.size)
            }
            val bands = listOf("50-59" to 50, "60-69" to 60, "70-79" to 70, "80-100" to 80)
            val stats = mutableListOf<String>()
            stats += "整体胜率：${rate(settled)}"
            bands.forEach { (label, lo) ->
                val seg = settled.filter { it.score >= lo && (lo == 80 || it.score < lo + 10) }
                if (seg.isNotEmpty()) stats += "评分 $label：${rate(seg)}"
            }
            val longs = settled.filter { it.direction == "LONG" }
            val shorts = settled.filter { it.direction != "LONG" }
            if (longs.isNotEmpty()) stats += "做多胜率：${rate(longs)}"
            if (shorts.isNotEmpty()) stats += "做空胜率：${rate(shorts)}"
            // 时段胜率（GMT+8：亚盘 08-16 / 欧盘 16-24 / 美盘 00-08）
            val tz = java.util.TimeZone.getTimeZone("GMT+8")
            fun sessionOf(ts: Long): String {
                val cal = java.util.Calendar.getInstance(tz).apply { timeInMillis = ts }
                return when (cal.get(java.util.Calendar.HOUR_OF_DAY)) {
                    in 8..15 -> "亚盘"; in 16..23 -> "欧盘"; else -> "美盘"
                }
            }
            settled.groupBy { sessionOf(it.alertedAt) }.filter { it.value.size >= 5 }
                .forEach { (s, l) -> stats += "${s}时段胜率：${rate(l)}" }
            if (stats.size == 1) stats += "暂无已结算样本（信号触发后会自动 24h 回访结算）"
            val tfRates = com.klinealert.nativeapp.domain.LearnedWeights.winRates(rows)
            val learned = com.klinealert.nativeapp.domain.LearnedWeights.from(rows)
            val pStats = com.klinealert.nativeapp.domain.Calibrator.patternStats(rows)
            // 胜率排行榜：品种维度聚合（≥2 个已结算样本才入榜）
            val rank = rows.groupBy { it.symbol }.map { (sym, list) ->
                val sd = list.filter { it.verdict == "hit" || it.verdict == "miss" || it.verdict == "invalid" }
                val inv = list.count { it.verdict == "invalid" }
                val hits = sd.count { it.verdict == "hit" }
                val longs = sd.filter { it.direction == "LONG" }
                val shorts = sd.filter { it.direction == "SHORT" }
                fun r(l: List<ReviewRecord>) = if (l.isEmpty()) 0.0 else l.count { it.verdict == "hit" } * 100.0 / l.size
                val longR = r(longs); val shortR = r(shorts)
                val bestDir = when {
                    longs.isNotEmpty() && shorts.isEmpty() -> "LONG"
                    shorts.isNotEmpty() && longs.isEmpty() -> "SHORT"
                    longR >= shortR -> "LONG"
                    else -> "SHORT"
                }
                val bestRate = if (bestDir == "LONG") longR else shortR
                // invalid（结构性失效）按半权重 miss 计入胜率分母
                val denom = sd.size + inv * 0.5
                SymbolWinStat(sym, market, sd.size, hits, sd.size - hits,
                    if (denom <= 0) 0.0 else hits * 100.0 / denom, bestDir, bestRate, list.count { it.verdict == "open" })
            }.filter { it.total >= 2 }.sortedWith(compareByDescending<SymbolWinStat> { it.rate }.thenByDescending { it.total })
            // 确认排行榜：features 中 confirm 字段聚合（已确认/回踩确认=确认成功）
            val confirmRankRows = rows.groupBy { it.symbol }.map { (sym, list) ->
                var cf = 0; var rt = 0; var fail = 0; var unknown = 0
                list.forEach { rec ->
                    val m = Regex("\"confirm\":\"([^\"]+)\"").find(rec.features)?.groupValues?.get(1)
                    when (m) {
                        "已确认" -> cf++
                        "回踩确认" -> rt++
                        "未确认" -> fail++
                        else -> unknown++
                    }
                }
                val judged = cf + rt + fail
                ConfirmStat(sym, list.size, cf, rt, fail, unknown,
                    if (judged == 0) 0.0 else (cf + rt) * 100.0 / judged)
            }.filter { it.confirmed + it.retest + it.unconfirmed >= 2 }
                .sortedWith(compareByDescending<ConfirmStat> { it.rate }.thenByDescending { it.confirmed })
            // 自动作战已平明细：id 以 auto| 开头且已结算
            val eng = com.klinealert.nativeapp.domain.BattleLoopEngine
            val battleRows = rows
                .filter { it.id.startsWith("auto|") && (it.verdict == "hit" || it.verdict == "miss") }
                .sortedByDescending { it.verdictAt.takeIf { t -> t > 0 } ?: it.alertedAt }
            val histPnl = battleRows.sumOf { r ->
                val move = com.klinealert.nativeapp.domain.PositionEngine.directionalMovePct(
                    r.entry, if (r.hitPrice > 0) r.hitPrice else r.entry, r.direction
                )
                com.klinealert.nativeapp.domain.PositionEngine.pnlUsdt(eng.DEFAULT_MARGIN_USDT, eng.DEFAULT_LEVERAGE, move)
            }
            withContext(Dispatchers.Main) {
                if (_state.value.market == market) _state.value = _state.value.copy(
                    reviewSummary = summary, winStats = stats, tfWinRates = tfRates,
                    learnedWeights = learned, patternStats = pStats, winRank = rank, winRankPage = 1,
                    confirmRank = confirmRankRows,
                    battleHistory = battleRows,
                    battlePnlSum = histPnl,
                    battleClosed = battleRows.size,
                    battleWins = battleRows.count { it.verdict == "hit" },
                    battleLosses = battleRows.count { it.verdict == "miss" }
                )
            }
        }
    }

    fun toggleBattleHistory() {
        _state.value = _state.value.copy(showBattleHistory = !_state.value.showBattleHistory)
    }

    private fun loadPositions(market: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val rows = runCatching { localStore.loadPositions(market) }.getOrDefault(emptyList())
            withContext(Dispatchers.Main) {
                if (_state.value.market == market) {
                    _state.value = _state.value.copy(positions = rows, positionPrices = _state.value.positionPrices.filterKeys { key -> rows.any { it.symbol == key } })
                    if (foreground) startPositionTickerWatch(market, rows.map { it.symbol })
                }
            }
        }
    }

    fun togglePositions() { _state.value = _state.value.copy(showPositions = !_state.value.showPositions) }

    /** 迷你K线数据源：优先当前扫描周期缓存，其次任一已有缓存的周期（60 根）。 */
    fun miniSeries(symbol: String, market: String): List<com.klinealert.nativeapp.domain.Candle> {
        val tfs = listOf(_state.value.timeframe) + AnalysisEngine.supportedTimeframes
        tfs.distinct().forEach { tf ->
            val c = repo.cachedCandles(symbol, market, tf)
            if (c.size >= 60) return c.takeLast(60)
        }
        return emptyList()
    }

    /** 持仓手动编辑：保存止损/止盈/数量/杠杆/备注。 */
    fun updatePosition(p: LocalStore.LocalPosition) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { localStore.savePosition(p.copy(updatedAt = System.currentTimeMillis())) }
            val rows = runCatching { localStore.loadPositions(p.market) }.getOrDefault(emptyList())
            withContext(Dispatchers.Main) {
                if (_state.value.market == p.market) {
                    _state.value = _state.value.copy(positions = rows, alertMessage = "${p.symbol} 持仓已更新")
                    if (foreground) startPositionTickerWatch(p.market, rows.map { it.symbol })
                }
                onLocalProtectiveChangedForTrade(p)
            }
        }
    }

    private fun usWatchPrefs() = getApplication<Application>().getSharedPreferences("us_watch", android.content.Context.MODE_PRIVATE)

    /** 美股/指数报价：Stooq 免费 CSV（无需 Key）。失败时静默降级为空。 */
    fun loadUsQuotes() {
        viewModelScope.launch(Dispatchers.IO) {
            val watch = usWatchPrefs().getStringSet("symbols", null)?.toSet()
                ?: setOf("AAPL", "NVDA", "TSLA", "MSFT")
            _state.value = _state.value.copy(usWatch = watch)
            val indices = "^DJI,^NDQ,^SPX"
            val stocks = watch.joinToString(",")
            val url = "https://stooq.com/q/l/?s=$indices,$stocks&f=sd2t2ohlcv&h&e=csv"
            val quotes = runCatching {
                val req = okhttp3.Request.Builder().url(url).header("User-Agent", "KlineAlertAndroid/1.0").build()
                okhttp3.OkHttpClient.Builder().connectTimeout(8, java.util.concurrent.TimeUnit.SECONDS)
                    .readTimeout(10, java.util.concurrent.TimeUnit.SECONDS).build()
                    .newCall(req).execute().use { resp ->
                        val body = resp.body?.string().orEmpty()
                        require(resp.isSuccessful && body.contains("Symbol")) { "HTTP ${resp.code}" }
                        body.lineSequence().drop(1).filter { it.isNotBlank() }.map { line ->
                            val c = line.split(",")
                            val price = c.getOrNull(3)?.toDoubleOrNull() ?: 0.0
                            val open = c.getOrNull(4)?.toDoubleOrNull() ?: 0.0
                            val chg = if (open > 0) (price - open) / open * 100 else 0.0
                            UsQuote(c.getOrElse(0) { "?" }, c.getOrElse(0) { "?" }, price, chg)
                        }.toList()
                    }
            }.getOrDefault(emptyList())
            withContext(Dispatchers.Main) { _state.value = _state.value.copy(usQuotes = quotes) }
        }
    }

    fun toggleUsWatch(symbol: String) {
        val next = usWatchPrefs().getStringSet("symbols", null)?.toSet() ?: setOf("AAPL", "NVDA", "TSLA", "MSFT")
        val mutable = next.toMutableSet()
        if (!mutable.add(symbol)) mutable.remove(symbol)
        usWatchPrefs().edit().putStringSet("symbols", mutable).apply()
        _state.value = _state.value.copy(usWatch = mutable)
        loadUsQuotes()
    }

    fun setMaxPositions(n: Int) {
        val v = n.coerceIn(1, 20)
        settingsPrefs().edit().putInt("max_positions", v).apply()
        _state.value = _state.value.copy(maxPositions = v, alertMessage = "最大同时持仓数已设为 $v")
    }

    /** v5.0.17 全局止损倍数（×ATR 决定风险距离 R）：持久化 + 仅新机会生效。目标盈亏比由 targetMult 独立设定。 */
    fun setStopMult(v: Double) {
        val nv = v.coerceIn(0.5, 5.0)
        settingsPrefs().edit().putFloat("stop_mult", nv.toFloat()).apply()
        _state.value = _state.value.copy(stopMult = nv,
            alertMessage = "止损已设为 ${fmtMult(nv)}×ATR（风险距离）· 目标盈亏比不随止损变（稳健 ${fmtMult(_state.value.steadyR)}R / 进取 ${fmtMult(_state.value.targetMult)}R），仅新机会生效")
    }

    /** v5.0.17 进取目标盈亏比 R（目标距离 = R×风险距离，统一口径）：持久化 + 仅新机会生效。 */
    fun setTargetMult(v: Double) {
        val nv = v.coerceIn(1.0, 10.0)
        settingsPrefs().edit().putFloat("target_mult", nv.toFloat()).apply()
        _state.value = _state.value.copy(targetMult = nv,
            alertMessage = "进取目标已设为盈亏比 ${fmtMult(nv)}R · 稳健 ${fmtMult(_state.value.steadyR)}R · 止损 ${fmtMult(_state.value.stopMult)}×ATR（仅新机会生效）")
    }

    // ── v5.0.17 目标分档（方案甲）全局设置 ──

    /** 从当前全局参数构造分档判定配置（进取 R = targetMult）。 */
    private fun tierCfg(): com.klinealert.nativeapp.domain.TargetTier.TierConfig =
        com.klinealert.nativeapp.domain.TargetTier.TierConfig(
            mode = _state.value.tierMode,
            steadyR = _state.value.steadyR,
            aggrR = _state.value.targetMult,
            breakEvenR = _state.value.breakEvenR,
            minScore = _state.value.tierMinScore,
            momentumVol = _state.value.tierMomentumVol,
            adxStrong = _state.value.tierAdxStrong
        )

    fun setTierMode(mode: String) {
        val m = when (mode) {
            com.klinealert.nativeapp.domain.TargetTier.MODE_FORCE_STEADY -> com.klinealert.nativeapp.domain.TargetTier.MODE_FORCE_STEADY
            com.klinealert.nativeapp.domain.TargetTier.MODE_FORCE_AGGRESSIVE -> com.klinealert.nativeapp.domain.TargetTier.MODE_FORCE_AGGRESSIVE
            else -> com.klinealert.nativeapp.domain.TargetTier.MODE_AUTO
        }
        settingsPrefs().edit().putString("tier_mode", m).apply()
        val txt = when (m) {
            com.klinealert.nativeapp.domain.TargetTier.MODE_FORCE_STEADY -> "全部稳健（到 ${fmtMult(_state.value.steadyR)}R 落袋）"
            com.klinealert.nativeapp.domain.TargetTier.MODE_FORCE_AGGRESSIVE -> "全部进取（到 ${fmtMult(_state.value.breakEvenR)}R 保本，冲 ${fmtMult(_state.value.targetMult)}R）"
            else -> "自动分档（按信号质量判稳健/进取）"
        }
        _state.value = _state.value.copy(tierMode = m, alertMessage = "分档模式：$txt（仅新机会生效）")
    }

    fun setSteadyR(v: Double) {
        val nv = v.coerceIn(1.0, 6.0)
        settingsPrefs().edit().putFloat("tier_steady_r", nv.toFloat()).apply()
        _state.value = _state.value.copy(steadyR = nv,
            alertMessage = "稳健档目标已设为 ${fmtMult(nv)}R · 进取 ${fmtMult(_state.value.targetMult)}R（仅新机会生效）")
    }

    fun setBreakEvenR(v: Double) {
        val nv = v.coerceIn(1.0, 6.0)
        settingsPrefs().edit().putFloat("tier_breakeven_r", nv.toFloat()).apply()
        _state.value = _state.value.copy(breakEvenR = nv,
            alertMessage = "进取档保本触发线已设为 ${fmtMult(nv)}R（到该盈亏比先把止损移到保本）")
    }

    fun setTierMinScore(v: Int) {
        val nv = v.coerceIn(50, 95)
        settingsPrefs().edit().putInt("tier_min_score", nv).apply()
        _state.value = _state.value.copy(tierMinScore = nv,
            alertMessage = "进取档最低质量分已设为 $nv（4 条件全满足才走进取 ${fmtMult(_state.value.targetMult)}R）")
    }

    private fun fmtMult(v: Double): String =
        if (v % 1.0 == 0.0) v.toInt().toString() else String.format(java.util.Locale.US, "%.1f", v)

    fun addPosition(a: Analysis) {
        if (_state.value.positions.size >= _state.value.maxPositions) {
            _state.value = _state.value.copy(alertMessage = "⚠ 仓位容量已满（${_state.value.positions.size}/${_state.value.maxPositions}）：机会已进入候补队列，先管理现有持仓或调大容量")
            return
        }
        // v5.0.10 单品种上限：同品种已有持仓则拒绝（自动作战候选已按 symbol 排重，此处堵住手动路径）
        if (_state.value.positions.any { it.symbol == a.symbol }) {
            _state.value = _state.value.copy(alertMessage = "⚠ ${a.symbol} 已有持仓（单品种最多 1 仓）：先平掉旧仓再建新仓")
            return
        }
        val now = System.currentTimeMillis()
        val eng = com.klinealert.nativeapp.domain.BattleLoopEngine
        val st = _state.value
        // v5.0.17 手动加入同样读全局止损倍数 + 统一 R 口径（修复之前手动用 a.stop/a.target 落默认 2/3 的漏网）
        val long = a.direction != "SHORT"
        val atr = a.atr.takeIf { it > 0 } ?: (kotlin.math.abs(a.entry - a.stop).takeIf { it > 0 } ?: a.entry * 0.01)
        val stopMult = st.stopMult
        val stop = if (a.stop > 0 && kotlin.math.abs(a.entry - a.stop) > 0) a.stop
        else if (long) a.entry - stopMult * atr else a.entry + stopMult * atr
        // 分档判定（与自动同一分类器；手动时用信号快照，结构缺失时按规则降级）
        val candles = entryCandles["${a.market}|${a.timeframe}|${a.symbol}"]
        val closed = candles?.dropLast(1)
        val an = runCatching {
            closed?.takeIf { it.size >= 35 }?.let { com.klinealert.nativeapp.domain.AnalysisEngine.analyze(a.symbol, a.market, a.timeframe, it) }
        }.getOrNull() ?: a
        val structure = runCatching { com.klinealert.nativeapp.domain.StructureEngine.evaluate(closed!!, atr) }.getOrNull()
        val tr = com.klinealert.nativeapp.domain.TargetTier.classify(a.direction, a.entry, stop, a.score, tierCfg(), an, structure)
        val target = com.klinealert.nativeapp.domain.TargetTier.targetFor(long, a.entry, stop, tr.targetR, atr)
        val tierTag = if (tr.tier == com.klinealert.nativeapp.domain.TargetTier.AGGRESSIVE)
            "进取${fmtMult(tr.targetR)}R" else "稳健${fmtMult(tr.targetR)}R"
        val position = LocalStore.LocalPosition(
            id = "${a.market}|${a.symbol}|${a.timeframe}|$now", market = a.market, symbol = a.symbol,
            direction = a.direction, entry = a.entry,
            leverage = eng.DEFAULT_LEVERAGE, size = eng.DEFAULT_MARGIN_USDT,
            stop = stop, target = target,
            note = "手动加入·$tierTag（止损${fmtMult(stopMult)}×ATR / 目标${fmtMult(tr.targetR)}R，本金${eng.DEFAULT_MARGIN_USDT.toInt()}×${eng.DEFAULT_LEVERAGE.toInt()}x）",
            createdAt = now, updatedAt = now,
            riskReward = tr.targetR, atr = atr, timeframe = a.timeframe, evidenceScore = a.score,
            stopMult = stopMult, targetMult = tr.targetR, tier = tr.tier, breakEvenDone = false
        )
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { localStore.savePosition(position) }
            val rows = runCatching { localStore.loadPositions(a.market) }.getOrDefault(emptyList())
            withContext(Dispatchers.Main) {
                if (_state.value.market == a.market) {
                    _state.value = _state.value.copy(positions = rows, showPositions = true,
                        alertMessage = "${a.symbol} 已加入本地持仓跟踪（$tierTag）")
                    if (foreground) startPositionTickerWatch(a.market, rows.map { it.symbol })
                    onLocalPositionOpenedForTrade(position)
                }
            }
            refreshFundingRates()   // v5.0.10 持仓变化后即时刷新资金费率
        }
    }

    fun removePosition(id: String) {
        val market = _state.value.market
        val p = _state.value.positions.firstOrNull { it.id == id }
        val now = System.currentTimeMillis()
        val closePrice = p?.let { _state.value.positionPrices[it.symbol] ?: it.entry }
        battleEntryScores.remove(id)   // v5.0.14 手动平仓清理轮换基准
        viewModelScope.launch(Dispatchers.IO) {
            // v5.0.17 手动平仓同样写入统一台账（之前这条路径工作台统计永远为空）
            if (p != null && closePrice != null) {
                recordClosedTradeBlocking(p, closePrice, LocalStore.ClosedTrade.R_MANUAL, LocalStore.ClosedTrade.S_MANUAL, now)
            }
            runCatching { localStore.deletePosition(id) }
            p?.let { onLocalPositionClosedForTrade(it.id, com.klinealert.nativeapp.domain.TradeModels.CLOSE_MANUAL) }
            refreshClosedLedger()
            val rows = runCatching { localStore.loadPositions(market) }.getOrDefault(emptyList())
            withContext(Dispatchers.Main) {
                if (_state.value.market == market) {
                    _state.value = _state.value.copy(positions = rows, positionPrices = _state.value.positionPrices.filterKeys { key -> rows.any { it.symbol == key } })
                    if (foreground) startPositionTickerWatch(market, rows.map { it.symbol })
                }
            }
            refreshFundingRates()   // v5.0.10 持仓变化后即时刷新资金费率
        }
        // v4.5 手动平仓同样进入自动作战冷却，避免自动循环立刻重入同一品种（v4.8 审计：冷却落库，重启不丢）
        if (p != null) {
            battleCooldowns["${p.symbol}|${p.direction}"] = now
            runCatching { localStore.saveCooldown(p.symbol, p.direction, now) }
        }
    }

    // ─────────────────────────── v5.0.17 统一平仓台账 ───────────────────────────

    /** 从库加载台账统计 + 明细到工作台（IO 读 → Main 写）。 */
    fun refreshClosedLedger() {
        val market = _state.value.market
        viewModelScope.launch(Dispatchers.IO) {
            val stats = runCatching { localStore.closedTradeStats(market) }.getOrNull()
            val hist = runCatching { localStore.loadClosedTrades(market, 200) }.getOrDefault(emptyList())
            withContext(Dispatchers.Main) {
                if (_state.value.market == market) {
                    _state.value = _state.value.copy(closedStats = stats, closedHistory = hist)
                }
            }
        }
    }

    /**
     * 统一平仓记账（在 IO 协程内调用，幂等按 position.id 去重）：
     * 实际 R = 方向×(平仓-入场)/风险距离；USDT 盈亏按本金×杠杆；win=R>0.05（保本单不算胜，保守口径）。
     * reason 见 [LocalStore.ClosedTrade] 的 R_*；source 见 S_*。
     */
    private fun recordClosedTradeBlocking(
        p: LocalStore.LocalPosition, closePrice: Double, reason: String, source: String, now: Long
    ) {
        val id = "closed|${p.id}"
        if (runCatching { localStore.closedTradeExists(id) }.getOrDefault(false)) return
        // v5.0.17 R 必须按"开仓时"的原始风险距离归一化（此时 p.stop 可能已移到保本/结构位，不能用）
        val long = p.direction != "SHORT"
        val origRisk = (p.atr * p.stopMult).takeIf { it > 0 }
            ?: com.klinealert.nativeapp.domain.TargetTier.riskDistance(p.entry, p.stop, p.atr)
        val move = if (long) closePrice - p.entry else p.entry - closePrice
        val r = if (origRisk > 0) move / origRisk else 0.0
        val dir = if (long) 1.0 else -1.0
        val pnlPct = (closePrice - p.entry) / p.entry * 100.0 * dir
        val usdt = com.klinealert.nativeapp.domain.PositionEngine.pnlUsdt(p.size, p.leverage, pnlPct)
        val tfMs = runCatching { timeframeMs(p.timeframe) }.getOrDefault(0L)
        val bars = if (tfMs > 0 && p.createdAt > 0) ((now - p.createdAt) / tfMs).toInt().coerceAtLeast(0) else 0
        val win = r > 0.05
        val t = LocalStore.ClosedTrade(
            id = id, market = p.market, symbol = p.symbol, direction = p.direction,
            timeframe = p.timeframe, tier = p.tier,
            entry = p.entry, stop = p.stop, target = p.target, closePrice = closePrice,
            leverage = p.leverage, margin = p.size, realizedR = r, realizedPnlUsdt = usdt,
            win = win, reason = reason, source = source, trailCount = p.trailCount,
            openedAt = p.createdAt, closedAt = now, barsHeld = bars
        )
        runCatching { localStore.saveClosedTrade(t) }
    }

    // ─────────────────────────── v4.5 自动作战循环 ───────────────────────────

    fun setAutoBattle(enabled: Boolean) {
        settingsPrefs().edit().putBoolean("auto_battle", enabled).apply()
        _state.value = _state.value.copy(
            autoBattle = enabled,
            alertMessage = if (enabled) "自动作战已开启：信号自动入仓，止盈/止损自动平仓，上限 ${_state.value.maxPositions} 个；平仓后候补自动顶上" else "自动作战已关闭（手动模式）"
        )
        if (enabled) fillBattleSlots(System.currentTimeMillis(), cap = 3)
    }

    fun setTrailingEnabled(v: Boolean) {
        settingsPrefs().edit().putBoolean("trailing_enabled", v).apply()
        _state.value = _state.value.copy(
            trailingEnabled = v,
            alertMessage = if (v) "移动止盈已开启：从极值回撤 ${com.klinealert.nativeapp.domain.BattleLoopEngine.DEFAULT_TRAIL_ATR}×ATR 锁盈平仓，利润奔跑" else "已切回固定止盈：到止盈/止损价即平"
        )
    }

    /** v5.0.14 满仓轮换开关：新信号综合分显著高于最差持仓时自动平旧换新（默认关）。 */
    fun setBattleRotate(v: Boolean) {
        settingsPrefs().edit().putBoolean("battle_rotate", v).apply()
        _state.value = _state.value.copy(
            battleRotateEnabled = v,
            alertMessage = if (v) "满仓轮换已开启：新信号综合分 > 最差持仓 ×1.2（且差≥8分）时自动平旧换新" else "满仓轮换已关闭：满仓后只等平仓腾位"
        )
        if (v) fillBattleSlots(System.currentTimeMillis(), cap = 1)
    }

    /** v5.0.14 补位防抖间隔（信号→自动入仓的最小间隔，防高频开仓）。 */
    fun setBattleFillInterval(ms: Long) {
        settingsPrefs().edit().putLong("battle_fill_interval", ms).apply()
        _state.value = _state.value.copy(battleFillIntervalMs = ms)
    }

    /** v5.0.15 价值区入场开关：开启后只在价格回到支撑/压力价值区且止跌确认时才自动开仓；关闭则回退现价入场。 */
    fun setValueZoneEntry(v: Boolean) {
        settingsPrefs().edit().putBoolean("entry_value_zone", v).apply()
        _state.value = _state.value.copy(
            valueZoneEntry = v,
            alertMessage = if (v) "价值区入场已开启：等价格回踩支撑/压力 + 止跌确认才开仓，不再追现价"
            else "价值区入场已关闭：回退为信号确认后按现价开仓"
        )
        if (v) fillBattleSlots(System.currentTimeMillis(), cap = 1)
    }

    /** v5.0.16 信号延续管理开关：开启后到目标评估趋势，能延续则移动止损/目标并标「延续×n」，否则止盈；关闭回退固定/吊灯止盈。 */
    fun setContinuation(v: Boolean) {
        settingsPrefs().edit().putBoolean("continuation_enabled", v).apply()
        _state.value = _state.value.copy(
            continuationEnabled = v,
            alertMessage = if (v) "信号延续已开启：到止盈先判断趋势，能延续则止损上移保本/结构位、目标上移（延续×n），否则止盈落袋"
            else "信号延续已关闭：回退为固定 3ATR 止盈 / 吊灯移动止盈"
        )
    }

    /** v5.0.16 周期 → 毫秒（用于时间止损把墙钟时间换算成 K 线数）。 */
    private fun timeframeMs(tf: String): Long = when (tf) {
        "5m" -> 5 * 60_000L; "15m" -> 15 * 60_000L; "30m" -> 30 * 60_000L
        "1h" -> 60 * 60_000L; "4h" -> 4 * 60 * 60_000L; else -> 15 * 60_000L
    }

    /**
     * v5.0.15 入场闸门：对一个融合机会跑统一事件管道，给出"此刻此价能不能开"。
     * 价值区模式下返回 EntryDecision（READY 才放行）；关闭时返回 null（不施加门槛，走旧逻辑）。
     */
    private fun entryGate(sop: SymbolOpportunity, livePrice: Double): com.klinealert.nativeapp.domain.EntryDecision? {
        if (!_state.value.valueZoneEntry) return null
        val cfg = com.klinealert.nativeapp.domain.EntryConfig(
            stopMult = _state.value.stopMult,
            targetMult = _state.value.targetMult,
            tierCfg = tierCfg()
        )
        val candles = entryCandles["${sop.market}|${sop.rep.timeframe}|${sop.symbol}"]
        val closed = candles?.dropLast(1)
        val latest = candles?.lastOrNull()
        return runCatching {
            com.klinealert.nativeapp.domain.SignalPipeline
                .evaluateAnalysis(sop.rep, closed, livePrice, latest, sop.direction, cfg)
                .decision
        }.getOrNull()
    }

    /**
     * v5.0.15 历史回放验证：对当前 A/B 级机会拉真实 K 线（各代表周期近 bars 根），并排跑"价值区 vs 现价"。
     * 逐品种在后台线程计算，结果写入 state.replayRows；失败/样本不足诚实标注。
     */
    fun runReplayBatch(maxSymbols: Int = 6, bars: Int = 500) {
        if (_state.value.replayRunning) return
        val ops = _state.value.symbolOps.filter { it.grade == "A" || it.grade == "B" }.take(maxSymbols)
        if (ops.isEmpty()) {
            _state.value = _state.value.copy(alertMessage = "暂无可回测的 A/B 级机会，先扫描出机会后再做回测验证")
            return
        }
        val cfg = com.klinealert.nativeapp.domain.EntryConfig(
            stopMult = _state.value.stopMult, targetMult = _state.value.targetMult, tierCfg = tierCfg()
        )
        val warmup = com.klinealert.nativeapp.domain.ReplayEngine.WARMUP
        _state.value = _state.value.copy(
            replayRunning = true, replayRows = emptyList(),
            alertMessage = "回测验证中：拉取 ${ops.size} 个品种近 $bars 根真实 K 线（价值区 vs 现价）…"
        )
        viewModelScope.launch(Dispatchers.IO) {
            val rows = ops.map { sop ->
                val cs = runCatching { repo.candles(sop.symbol, sop.market, sop.rep.timeframe, bars) }.getOrNull()
                val report = cs?.takeIf { it.size >= warmup + 30 }?.let {
                    runCatching {
                        withContext(Dispatchers.Default) {
                            com.klinealert.nativeapp.domain.ReplayEngine.run(
                                sop.symbol, sop.market, sop.rep.timeframe, it, cfg
                            )
                        }
                    }.getOrNull()
                }
                if (report != null) {
                    com.klinealert.nativeapp.domain.ReplayRow.of(sop.symbol, sop.market, sop.rep.timeframe, report)
                } else {
                    com.klinealert.nativeapp.domain.ReplayRow(
                        sop.symbol, sop.market, sop.rep.timeframe, cs?.size ?: 0,
                        0, 0.0, 0.0, 0.0, 0, 0.0, 0.0, 0.0,
                        0, 0.0, 0.0, 0.0, 0,
                        if (cs == null) "K 线拉取失败（网络受限）" else "样本不足（K 线 < ${warmup + 30} 根）"
                    )
                }
            }
            withContext(Dispatchers.Main) {
                val ok = rows.count { it.note.startsWith("样本不足").not() && it.note.contains("失败").not() }
                _state.value = _state.value.copy(
                    replayRunning = false, replayRows = rows,
                    alertMessage = "回测完成：$ok/${rows.size} 个品种有效，价值区总 R 合计 ${String.format(java.util.Locale.US, "%+.1f", rows.sumOf { it.valueTotalR })} vs 现价 ${String.format(java.util.Locale.US, "%+.1f", rows.sumOf { it.marketTotalR })}"
                )
            }
        }
    }

    /**
     * v5.0.17 统一分档建仓（自动/手动/轮换共用）：
     * 1) buildEntry 用统一 R 口径算止损/入场（目标先用进取 R）；
     * 2) 取结构/指标，TargetTier 判稳健 2R / 进取 3R；
     * 3) 按档位重算目标价（目标距离 = 目标R × 实际风险），plan 携带 tier。
     * 门控不过返回 null。
     */
    private fun buildTieredPlan(
        sop: SymbolOpportunity, price: Double, evidenceScore: Int,
        manualOverride: String? = null
    ): com.klinealert.nativeapp.domain.BattleLoopEngine.EntryPlan? {
        val base = com.klinealert.nativeapp.domain.BattleLoopEngine.buildEntry(
            sop.symbol, sop.market, sop.direction, sop.rep.timeframe, price, sop.rep.atr, evidenceScore,
            _state.value.stopMult, _state.value.targetMult
        )
        if (!base.ok) return null
        // 判档所需的结构/指标快照（与 entryGate 同一批 K 线）
        val candles = entryCandles["${sop.market}|${sop.rep.timeframe}|${sop.symbol}"]
        val closed = candles?.dropLast(1)
        val a = runCatching {
            closed?.takeIf { it.size >= 35 }?.let {
                com.klinealert.nativeapp.domain.AnalysisEngine.analyze(sop.symbol, sop.market, sop.rep.timeframe, it)
            }
        }.getOrNull()
        val structure = runCatching {
            a?.let { com.klinealert.nativeapp.domain.StructureEngine.evaluate(closed!!, it.atr) }
        }.getOrNull()
        val long = sop.direction != "SHORT"
        val tr = com.klinealert.nativeapp.domain.TargetTier.classify(
            sop.direction, base.entry, base.stop, evidenceScore, tierCfg(), a, structure, manualOverride
        )
        val target = com.klinealert.nativeapp.domain.TargetTier.targetFor(
            long, base.entry, base.stop, tr.targetR, sop.rep.atr
        )
        return base.copy(
            targetMult = tr.targetR, target = target, tier = tr.tier
        )
    }

    /** 自动入仓：v5.0.17 起统一分档（稳健 2R 落袋 / 进取 2R 保本冲 3R）；size=本金 USDT，默认 1×50。 */
    private fun autoEnterPosition(sop: SymbolOpportunity, plan: com.klinealert.nativeapp.domain.BattleLoopEngine.EntryPlan, battleScore: Double,
                                  dec: com.klinealert.nativeapp.domain.EntryDecision? = null) {
        val now = System.currentTimeMillis()
        val eng = com.klinealert.nativeapp.domain.BattleLoopEngine
        val enterNote = dec?.let { "价值区入·${it.zoneLabel}·${entryStateLabel(it)}" } ?: "按现价入"
        val tierTag = if (plan.tier == com.klinealert.nativeapp.domain.TargetTier.AGGRESSIVE) "进取${fmtMult(plan.targetMult)}R" else "稳健${fmtMult(plan.targetMult)}R"
        val pos = LocalStore.LocalPosition(
            id = "${plan.market}|${plan.symbol}|${plan.direction}|$now", market = plan.market, symbol = plan.symbol,
            direction = plan.direction, entry = plan.entry,
            leverage = eng.DEFAULT_LEVERAGE, size = eng.DEFAULT_MARGIN_USDT,
            stop = plan.stop, target = plan.target,
            note = "自动作战·${plan.timeframe}$enterNote·$tierTag（止损${plan.stopMult.toInt()}×ATR / 目标${fmtMult(plan.targetMult)}R，本金${eng.DEFAULT_MARGIN_USDT.toInt()}×${eng.DEFAULT_LEVERAGE.toInt()}x）",
            createdAt = now, updatedAt = now,
            trailing = _state.value.trailingEnabled, riskReward = plan.riskReward,
            atr = kotlin.math.abs(plan.entry - plan.stop) / plan.stopMult, timeframe = plan.timeframe,
            evidenceScore = plan.evidenceScore, stopMult = plan.stopMult, targetMult = plan.targetMult,
            tier = plan.tier, breakEvenDone = false
        )
        autoEnterInFlight.add("${plan.symbol}|${plan.direction}")
        battleEntryScores[pos.id] = battleScore   // v5.0.14 轮换基准
        viewModelScope.launch(Dispatchers.IO) {
            val saveOk = runCatching { localStore.savePosition(pos) }.isSuccess
            val rows = runCatching { localStore.loadPositions(plan.market) }.getOrDefault(emptyList())
            withContext(Dispatchers.Main) {
                autoEnterInFlight.remove("${plan.symbol}|${plan.direction}")
                if (_state.value.market == plan.market) {
                    _state.value = _state.value.copy(
                        positions = rows,
                        positionPrices = _state.value.positionPrices.filterKeys { key -> rows.any { it.symbol == key } },
                        battleEntered = _state.value.battleEntered + 1,
                        alertMessage = "${plan.symbol} ${if (plan.direction == "LONG") "多" else "空"}自动入仓 @ ${String.format(java.util.Locale.US, "%.4f", plan.entry)}（$tierTag｜止损${plan.stopMult.toInt()}×ATR ${String.format(java.util.Locale.US, "%.4f", plan.stop)} / 目标 ${String.format(java.util.Locale.US, "%.4f", plan.target)}）"
                            + if (saveOk) "" else "（⚠ 入仓落库失败，持仓可能不持久）"
                    )
                    if (foreground) startPositionTickerWatch(plan.market, rows.map { it.symbol })
                    if (saveOk) onLocalPositionOpenedForTrade(pos)
                }
            }
        }
    }

    /** v5.0.15 入场四态中文标签。 */
    private fun entryStateLabel(d: com.klinealert.nativeapp.domain.EntryDecision): String = when (d.state) {
        com.klinealert.nativeapp.domain.EntryDecision.READY -> "可开仓"
        com.klinealert.nativeapp.domain.EntryDecision.IN_ZONE -> "已到位"
        com.klinealert.nativeapp.domain.EntryDecision.WATCHING -> "等回踩"
        else -> "已失效"
    }

    /**
     * 候补候选（优中选优）。
     * 基础门控：A/B 级 + 已确认/回踩确认 + 综合分≥70 + 未持仓 + 不在冷却 + 新鲜窗口。
     * v5.0.15 价值区闸门（开启时）：再叠加 SignalPipeline = READY（回到支撑/压力价值区且止跌确认、RR≥1.5），
     * 未到可开仓（观察/到位/失效）一律不自动开。返回三元组携带入场决策（含支撑价）。
     */
    private fun battleCandidates(now: Long): List<Triple<SymbolOpportunity, Double, com.klinealert.nativeapp.domain.EntryDecision?>> {
        val held = _state.value.positions.map { it.symbol }.toSet()
        val engine = com.klinealert.nativeapp.domain.BattleLoopEngine
        val decisions = mutableMapOf<String, com.klinealert.nativeapp.domain.EntryDecision>()
        val queue = _state.value.symbolOps
            .filter { !held.contains(it.symbol) }
            .mapNotNull { sop ->
                val c = _state.value.oppConfirm["${sop.market}|${sop.symbol}|${sop.direction}"]
                if (c == null || (c.status != "已确认" && c.status != "回踩确认")) return@mapNotNull null
                // 仅 A/B 级机会才自动入仓（C 级只展示、不自动进）
                if (sop.grade != "A" && sop.grade != "B") return@mapNotNull null
                // 新鲜度门槛：K 线时间在周期对应窗口内，防「落后信号」在平仓后补位
                if (!engine.isFresh(sop.rep.candleTime, now, sop.rep.timeframe)) return@mapNotNull null
                val key = "${sop.symbol}|${sop.direction}"
                if (engine.inCooldown(key, battleCooldowns[key] ?: 0L, now)) return@mapNotNull null
                if (sop.score < engine.MIN_ENTRY_SCORE) return@mapNotNull null
                // v5.0.15 价值区闸门：READY 才放行（关闭时 entryGate 返回 null，不施加门槛）
                val livePrice = _state.value.oppPrices[sop.symbol]?.first ?: sop.price
                val dec = entryGate(sop, livePrice)
                if (dec != null) {
                    decisions["${sop.market}|${sop.symbol}|${sop.direction}"] = dec
                    if (!dec.ready) return@mapNotNull null
                }
                val wr = _state.value.winRank.firstOrNull { it.symbol == sop.symbol }?.rate ?: 40.0
                val battleScore = engine.battleScore(
                    sop.score, wr, c.progressAtr, sop.rep.volExpansion,
                    sop.rep.candleTime, now, sop.rep.timeframe
                )
                Triple(sop, battleScore, dec)
            }
            .sortedByDescending { it.second }
        if (decisions.isNotEmpty()) {
            _state.value = _state.value.copy(entryDecisions = _state.value.entryDecisions + decisions)
        }
        return queue
    }

    /** v5.0.15 入场价：价值区模式用支撑/压力价（READY），回退模式用实时价。 */
    private fun entryPriceOf(sop: SymbolOpportunity, dec: com.klinealert.nativeapp.domain.EntryDecision?): Double {
        val live = _state.value.oppPrices[sop.symbol]?.first ?: sop.price
        return dec?.entry ?: live
    }

    /** 候补顶上：有坑位即按综合分自动补位（每轮最多 cap 个）；v5.0.14 满仓时可轮换最差持仓。 */
    private fun fillBattleSlots(now: Long, cap: Int) {
        if (!_state.value.autoBattle) return
        val queue = battleCandidates(now)
        // 满仓：v5.0.14 开满仓轮换时尝试换掉最差持仓；否则清空候补（等平仓腾位）
        if (_state.value.positions.size >= _state.value.maxPositions) {
            if (_state.value.battleRotateEnabled && _state.value.maxPositions > 0) {
                val best = queue.firstOrNull()
                val rotatable = _state.value.positions
                    .filter { battleEntryScores.containsKey(it.id) }   // 只轮换自动仓，不碰手动仓
                    .minByOrNull { battleEntryScores[it.id] ?: it.evidenceScore.toDouble() }
                if (best != null && rotatable != null) {
                    val worstScore = battleEntryScores[rotatable.id] ?: rotatable.evidenceScore.toDouble()
                    if (com.klinealert.nativeapp.domain.BattleLoopEngine.shouldRotate(best.second, worstScore)) {
                        val tag = best.third?.let { "·${entryStateLabel(it)}" } ?: ""
                        _state.value = _state.value.copy(
                            battleQueue = listOf("轮换 ${best.first.symbol} ${best.first.direction} ${best.second.toInt()}分$tag > ${rotatable.symbol} ${worstScore.toInt()}分")
                        )
                        rotateOutPosition(rotatable, now)
                        val price = entryPriceOf(best.first, best.third)
                        val ev = _state.value.evidence["${best.first.market}|${best.first.symbol}"]?.score ?: best.first.score
                        val plan = buildTieredPlan(best.first, price, ev)
                        if (plan != null) autoEnterPosition(best.first, plan, best.second, best.third)
                        return
                    }
                }
            }
            _state.value = _state.value.copy(battleQueue = emptyList())
            return
        }
        _state.value = _state.value.copy(battleQueue = queue.take(5).map { t ->
            val tag = t.third?.let { "·${entryStateLabel(it)}@${String.format(java.util.Locale.US, "%.4f", it.entry)}" } ?: ""
            "${t.first.symbol} ${t.first.direction} ${t.second.toInt()}分$tag"
        })
        var entered = 0
        for ((sop, score, dec) in queue) {
            if (_state.value.positions.size >= _state.value.maxPositions) break
            if (entered >= cap) break
            if (autoEnterInFlight.contains("${sop.symbol}|${sop.direction}")) continue   // 写库防重
            val price = entryPriceOf(sop, dec)
            val ev = _state.value.evidence["${sop.market}|${sop.symbol}"]?.score ?: sop.score
            val plan = buildTieredPlan(sop, price, ev)   // v5.0.17 统一 R 口径 + 稳健/进取分档
            if (plan == null) continue   // 门控不过（距止损太近/波动过大）→ 跳过，等下一轮
            autoEnterPosition(sop, plan, score, dec)
            entered++
        }
    }

    /** v5.0.14 满仓轮换淘汰：写 miss 样本 → 删除持仓 → 冷却落库 → 跟单同步平仓；不算止盈/止损胜负。 */
    private fun rotateOutPosition(p: LocalStore.LocalPosition, now: Long) {
        val rec = com.klinealert.nativeapp.domain.ReviewRecord(
            id = "auto|${p.market}|${p.symbol}|${p.direction}|${p.createdAt}",
            symbol = p.symbol, market = p.market, timeframe = p.timeframe.ifBlank { "auto" },
            direction = p.direction, entry = p.entry, stop = p.stop, target = p.target,
            score = p.evidenceScore, alertedAt = p.createdAt,
            verdict = "miss", verdictAt = now, hitPrice = _state.value.positionPrices[p.symbol] ?: p.entry,
            evidenceScore = p.evidenceScore
        )
        battleCooldowns["${p.symbol}|${p.direction}"] = now
        battleEntryScores.remove(p.id)
        viewModelScope.launch(Dispatchers.IO) {
            val firstWriter = !runCatching { localStore.reviewExists(rec.id) }.getOrDefault(false)
            if (firstWriter) runCatching { localStore.saveReview(rec) }
            // v5.0.17 轮换也记台账（按当前价结算实际 R，标记为轮换）
            val rotPx = _state.value.positionPrices[p.symbol] ?: p.entry
            if (firstWriter) recordClosedTradeBlocking(p, rotPx, LocalStore.ClosedTrade.R_ROTATE, LocalStore.ClosedTrade.S_ROTATION, now)
            val delOk = runCatching { localStore.deletePosition(p.id) }.isSuccess
            runCatching { localStore.saveCooldown(p.symbol, p.direction, now) }
            refreshClosedLedger()
            val rows = runCatching { localStore.loadPositions(p.market) }.getOrDefault(emptyList())
            withContext(Dispatchers.Main) {
                if (_state.value.market == p.market) {
                    val px = _state.value.positionPrices[p.symbol] ?: p.entry
                    val usdt = com.klinealert.nativeapp.domain.PositionEngine.pnlUsdt(p.size, p.leverage,
                        if (p.direction == "LONG") (px - p.entry) / p.entry * 100.0 else (p.entry - px) / p.entry * 100.0)
                    _state.value = _state.value.copy(
                        positions = rows,
                        positionPrices = _state.value.positionPrices.filterKeys { key -> rows.any { it.symbol == key } },
                        battleClosed = _state.value.battleClosed + (if (firstWriter) 1 else 0),
                        battleHistory = if (firstWriter) listOf(rec) + _state.value.battleHistory.filter { it.id != rec.id } else _state.value.battleHistory,
                        alertMessage = "${p.symbol} 满仓轮换淘汰 @ ${String.format(java.util.Locale.US, "%.4f", px)}（盈亏 ${String.format(java.util.Locale.US, "%+.2f", usdt)}U）"
                            + if (delOk) "" else "（⚠ 删除持仓失败）"
                    )
                    if (foreground) startPositionTickerWatch(p.market, rows.map { it.symbol })
                    onLocalPositionClosedForTrade(p.id, com.klinealert.nativeapp.domain.TradeModels.CLOSE_MANUAL)
                }
            }
            refreshFundingRates()
        }
    }

    /** 自动平仓：写结算样本（auto| 前缀）→ 删除持仓（消失）→ 冷却落库 → 空坑自动顶上。 */
    private fun closeBattlePosition(p: LocalStore.LocalPosition, d: com.klinealert.nativeapp.domain.BattleLoopEngine.CloseDecision, now: Long) {
        val hit = d.action == com.klinealert.nativeapp.domain.BattleLoopEngine.CLOSE_TAKE_PROFIT ||
            d.action == com.klinealert.nativeapp.domain.BattleLoopEngine.CLOSE_TRAIL_STOP
        // v5.0.17 平仓台账原因映射（供工作台统计）
        val ledgerReason = when {
            d.reason.contains("反转") -> LocalStore.ClosedTrade.R_REVERSE
            d.reason.contains("时间") -> LocalStore.ClosedTrade.R_TIMEOUT
            d.action == com.klinealert.nativeapp.domain.BattleLoopEngine.CLOSE_TAKE_PROFIT -> LocalStore.ClosedTrade.R_TARGET
            d.action == com.klinealert.nativeapp.domain.BattleLoopEngine.CLOSE_TRAIL_STOP -> LocalStore.ClosedTrade.R_BREAKEVEN
            else -> LocalStore.ClosedTrade.R_STOP
        }
        val rec = com.klinealert.nativeapp.domain.ReviewRecord(
            id = "auto|${p.market}|${p.symbol}|${p.direction}|${p.createdAt}",
            symbol = p.symbol, market = p.market, timeframe = p.timeframe.ifBlank { "auto" },
            direction = p.direction, entry = p.entry, stop = p.stop, target = p.target,
            score = p.evidenceScore, alertedAt = p.createdAt,
            verdict = if (hit) "hit" else "miss", verdictAt = now, hitPrice = d.closePrice,
            evidenceScore = p.evidenceScore
        )
        battleCooldowns["${p.symbol}|${p.direction}"] = now
        battleEntryScores.remove(p.id)   // v5.0.14 平仓后清理轮换基准
        viewModelScope.launch(Dispatchers.IO) {
            // v4.8 审计：双端平仓原子守卫——只有首个写入方计入统计/通知（后台服务可能同 tick 先平）
            val firstWriter = !runCatching { localStore.reviewExists(rec.id) }.getOrDefault(false)
            val saveOk = if (firstWriter) runCatching { localStore.saveReview(rec) }.isSuccess else true
            // v5.0.17 统一平仓台账（幂等，前台自动路径；后台同 tick 由台账 id 去重）
            recordClosedTradeBlocking(p, d.closePrice, ledgerReason, LocalStore.ClosedTrade.S_AUTO, now)
            val delOk = runCatching { localStore.deletePosition(p.id) }.isSuccess
            runCatching { localStore.saveCooldown(p.symbol, p.direction, now) }   // 冷却落库（重启不丢）
            refreshClosedLedger()
            val rows = runCatching { localStore.loadPositions(p.market) }.getOrDefault(emptyList())
            withContext(Dispatchers.Main) {
                if (_state.value.market == p.market) {
                    val usdt = com.klinealert.nativeapp.domain.PositionEngine.pnlUsdt(p.size, p.leverage, d.pnlPct)
                    val yld = com.klinealert.nativeapp.domain.PositionEngine.yieldPct(p.leverage, d.pnlPct)
                    val hist = if (firstWriter) listOf(rec) + _state.value.battleHistory.filter { it.id != rec.id }
                    else _state.value.battleHistory
                    _state.value = _state.value.copy(
                        positions = rows,
                        positionPrices = _state.value.positionPrices.filterKeys { key -> rows.any { it.symbol == key } },
                        battleClosed = _state.value.battleClosed + (if (firstWriter) 1 else 0),
                        battleWins = _state.value.battleWins + (if (firstWriter && hit) 1 else 0),
                        battleLosses = _state.value.battleLosses + (if (firstWriter && !hit) 1 else 0),
                        battlePnlSum = _state.value.battlePnlSum + (if (firstWriter) usdt else 0.0),
                        battleHistory = hist,
                        alertMessage = "${p.symbol} ${if (hit) "✅止盈" else "⛔止损"} ${d.reason}（价格 ${String.format(java.util.Locale.US, "%+.2f", d.pnlPct)}% · 盈亏 ${String.format(java.util.Locale.US, "%+.2f", usdt)} USDT · 收益 ${String.format(java.util.Locale.US, "%+.1f", yld)}%，本金${p.size}×${p.leverage.toInt()}x）"
                            + if (saveOk && delOk) "" else "（⚠ 结算落库失败，请到诊断页检查样本）"
                    )
                    if (foreground) startPositionTickerWatch(p.market, rows.map { it.symbol })
                    if (firstWriter) onLocalPositionClosedForTrade(
                        p.id,
                        if (hit) com.klinealert.nativeapp.domain.TradeModels.CLOSE_TP
                        else com.klinealert.nativeapp.domain.TradeModels.CLOSE_SL
                    )
                    fillBattleSlots(System.currentTimeMillis(), cap = 1)   // 腾出的坑位立即顶上 1 个
                }
            }
            refreshFundingRates()   // v5.0.10 持仓变化后即时刷新资金费率
        }
    }

    /** v5.0.16 单持仓出场动作：close 非空=平仓；raised 非空=移动止损/目标；evaluated=true 但两者皆空=评估过且持有。 */
    private data class ExitAction(
        val close: com.klinealert.nativeapp.domain.BattleLoopEngine.CloseDecision?,
        val raised: LocalStore.LocalPosition?,
        val evaluated: Boolean = false
    )

    /**
     * v5.0.16 出场状态机闸门：跑 [ExitStateMachine] 判定延续/结束。
     * 返回 null = 数据不足或未通过防插针，调用方应回退旧 evaluateClose（保证止损永不失效）。
     */
    private fun exitGate(p: LocalStore.LocalPosition, price: Double, crossOk: Boolean, now: Long): ExitAction? {
        if (!_state.value.continuationEnabled || !crossOk) return null
        val tf = p.timeframe.ifBlank { _state.value.timeframe }
        val key = "${p.market}|$tf|${p.symbol}"
        val hist = entryCandles[key] ?: repo.cachedCandles(p.symbol, p.market, tf)
        if (hist.size < 35) return null
        val closed = hist.dropLast(1)
        val latest = closed.lastOrNull() ?: return null
        val a = runCatching {
            com.klinealert.nativeapp.domain.AnalysisEngine.analyze(p.symbol, p.market, tf, closed)
        }.getOrNull() ?: return null
        if (a.atr <= 0) return null
        val structure = runCatching { com.klinealert.nativeapp.domain.StructureEngine.evaluate(closed, a.atr) }.getOrNull()
        val anchor = if (p.lastRaiseAt > 0) p.lastRaiseAt else p.createdAt
        val tfMs = timeframeMs(tf)
        val barsSince = if (tfMs > 0 && anchor > 0) ((now - anchor) / tfMs).toInt().coerceAtLeast(0) else 0
        val cfg = com.klinealert.nativeapp.domain.ExitStateMachine.ExitConfig(
            continuationEnabled = true, stopMult = p.stopMult, targetMult = p.targetMult,
            tier = p.tier, breakEvenR = _state.value.breakEvenR
        )
        val d = com.klinealert.nativeapp.domain.ExitStateMachine.evaluate(
            p.direction, p.entry, p.stop, p.target, price, a, structure, latest,
            p.trailCount, barsSince, p.bestPrice, p.breakEvenDone, cfg
        )
        val eng = com.klinealert.nativeapp.domain.BattleLoopEngine
        return when {
            d.isRaise -> {
                val nb = eng.updatedBest(p.direction, p.bestPrice, price)
                val raised = p.copy(
                    stop = d.newStop, target = d.newTarget, trailCount = d.trailCount,
                    stage = d.stage, lastRaiseAt = now, bestPrice = nb, updatedAt = now,
                    breakEvenDone = p.breakEvenDone || d.breakEvenDone
                )
                ExitAction(null, raised, evaluated = true)
            }
            d.isExit -> {
                val pnl = eng.movePct(p.entry, price, p.direction)
                val type = when (d.action) {
                    com.klinealert.nativeapp.domain.ExitStateMachine.ACTION_EXIT_STOP ->
                        // v5.0.17 已保本/已延续后被扫 → 保本/移动止损（R≥0），否则初始止损 -1R
                        if (p.breakEvenDone || p.trailCount > 0) eng.CLOSE_TRAIL_STOP else eng.CLOSE_STOP_LOSS
                    com.klinealert.nativeapp.domain.ExitStateMachine.ACTION_EXIT_TARGET -> eng.CLOSE_TAKE_PROFIT
                    // 反转/时间止损：按实际盈亏判胜负（移动止盈胜 / 止损负）
                    else -> if (pnl >= 0) eng.CLOSE_TRAIL_STOP else eng.CLOSE_STOP_LOSS
                }
                ExitAction(com.klinealert.nativeapp.domain.BattleLoopEngine.CloseDecision(type, price, pnl, d.label), null, evaluated = true)
            }
            else -> ExitAction(null, null, evaluated = true)
        }
    }

    /** 每 tick 自动作战：平仓判定（防插针）→ 极值锚点更新 → 实时补位（防抖限频）。由 500ms flush 调用。 */
    private fun battleTick(now: Long) {
        val snapshot = _state.value.positions
        if (snapshot.isEmpty()) { fillBattleSlots(now, cap = 3); lastBattleFillAt = now; return }   // 空仓：立即自启动（不防抖）
        val engine = com.klinealert.nativeapp.domain.BattleLoopEngine
        val pxMap = _state.value.positionPrices
        val anchors = mutableMapOf<String, LocalStore.LocalPosition>()
        val raised = mutableListOf<LocalStore.LocalPosition>()
        var raiseMsg: String? = null
        for (p in snapshot) {
            val price = pxMap[p.symbol] ?: continue
            if (price <= 0 || !price.isFinite()) continue
            val dev = crossCheck.deviationPct(p.symbol, price)
            val crossOk = dev == null || dev <= engine.CLOSE_CROSSCHECK_TOL_PCT   // 无参考放行，偏差大拦截

            // 固定/吊灯旧平仓判定（延续关闭或数据不足时的兜底）
            val legacyClose: com.klinealert.nativeapp.domain.BattleLoopEngine.CloseDecision? = {
                val trailStep = if (p.atr > 0) engine.DEFAULT_TRAIL_ATR * p.atr else 0.0
                engine.evaluateClose(
                    p.direction, p.entry, p.stop, p.target, price, crossOk,
                    trailing = _state.value.trailingEnabled, bestPrice = p.bestPrice, trailStep = trailStep
                )
            }()
            val updateBest: () -> Unit = {
                if (crossOk) {
                    val nb = engine.updatedBest(p.direction, p.bestPrice, price)
                    if (nb != p.bestPrice) anchors[p.id] = p.copy(bestPrice = nb, updatedAt = now)
                }
            }

            if (_state.value.continuationEnabled) {
                val ex = exitGate(p, price, crossOk, now)
                when {
                    ex == null -> {
                        // 数据不足/未评估 → 旧逻辑兜底，保证止损永不失效
                        if (legacyClose != null) { closeBattlePosition(p, legacyClose, now); continue }
                        updateBest()
                    }
                    ex.close != null -> { closeBattlePosition(p, ex.close, now); continue }
                    ex.raised != null -> {
                        anchors[p.id] = ex.raised
                        raised += ex.raised
                        raiseMsg = "${p.symbol} ${if (p.direction == "LONG") "多" else "空"} 延续×${ex.raised.trailCount}：" +
                            "止损上移至 ${String.format(java.util.Locale.US, "%.4f", ex.raised.stop)}，目标 ${String.format(java.util.Locale.US, "%.4f", ex.raised.target)}"
                    }
                    else -> updateBest()   // 评估过且持有
                }
            } else {
                if (legacyClose != null) { closeBattlePosition(p, legacyClose, now); continue }
                updateBest()
            }
        }
        if (anchors.isNotEmpty()) {
            viewModelScope.launch(Dispatchers.IO) { anchors.values.forEach { runCatching { localStore.savePosition(it) } } }
            _state.value = _state.value.copy(
                positions = _state.value.positions.map { anchors[it.id] ?: it },
                alertMessage = raiseMsg ?: _state.value.alertMessage
            )
            // v5.0.16 移动止损/止盈：同步交易所保护单（撤旧挂新，全仓移动不改数量）
            raised.forEach { onLocalProtectiveChangedForTrade(it) }
        }
        // v5.0.14 实时补位：有坑位且有新鲜信号 → 自动入仓（防抖间隔限频，空仓首次不受限）
        if (now - lastBattleFillAt >= _state.value.battleFillIntervalMs) {
            lastBattleFillAt = now
            fillBattleSlots(now, cap = 1)
        }
    }

    private fun loadCachedResults(market: String, timeframe: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val cached = runCatching { localStore.loadAnalyses(market, timeframe) }.getOrDefault(emptyList())
            withContext(Dispatchers.Main) {
                if (_state.value.market == market && _state.value.timeframe == timeframe && _state.value.results.isEmpty() && cached.isNotEmpty()) {
                    _state.value = _state.value.copy(results = cached, status = "已恢复本地缓存 ${cached.size} 条结果")
                }
            }
        }
    }

    fun setMarket(value: String) {
        if (_state.value.market == value) return
        stopUniverseWatch(clearLast = true)
        universeReconnectAttempt = 0
        repo.clearCandleCache()
        _state.value = _state.value.copy(market = value, error = null, results = emptyList(), livePrice = null, alertMessage = null, positions = emptyList(), positionPrices = emptyMap(), showPositions = false, symbol = "", oppPrices = emptyMap())
        loadCachedResults(value, _state.value.timeframe)
        loadReviewSummary(value)
        loadPositions(value)
        if (foreground) startLive()
    }
    fun setTimeframe(value: String) {
        if (value !in AnalysisEngine.supportedTimeframes || _state.value.timeframe == value) return
        stopUniverseWatch(clearLast = true)
        universeReconnectAttempt = 0
        repo.clearCandleCache()
        _state.value = _state.value.copy(timeframe = value, error = null, alertMessage = null, results = emptyList(), symbol = "", oppPrices = emptyMap())
        loadCachedResults(_state.value.market, value)
        // A timeframe change must replace the old candle stream, not leave the previous interval attached.
        if (foreground) startLive()
    }
    fun setSymbol(value: String) {
        if (_state.value.symbol == value) return
        _state.value = _state.value.copy(symbol = value, livePrice = null, alertMessage = null)
        if (foreground) startLive()
    }

    fun stopLive() {
        foreground = false
        tickerGeneration += 1L   // 旧 socket 的延迟回调（onClosed/onFailure）立即失效
        klineGeneration += 1L
        reconnectJob?.cancel(); reconnectJob = null
        stopUniverseWatch(clearLast = false)
        tickerSocket?.close(1000, "app not foreground"); tickerSocket = null
        klineSocket?.close(1000, "app not foreground"); klineSocket = null
        historyJob?.cancel(); historyJob = null
        // NOTE: scanJob is deliberately NOT cancelled here — a full-market scan keeps running
        // in the background and its results are persisted to SQLite when it finishes.
        stopPositionTickerWatch()
        _state.value = _state.value.copy(status = "前台实时已暂停", scanning = _state.value.scanning, positionPrices = emptyMap(), stalePositions = emptySet())
    }

    /**
     * v5.0.11 网络切换/恢复主动重建实时流（MainActivity 的 NetworkCallback 触发）：
     * 2s 去抖；startLive 内部代际递增天然防幽灵；不打断正在进行的全市场扫描。
     */
    fun onNetworkChanged() {
        val now = System.currentTimeMillis()
        if (now - lastNetworkChangeAt < 2_000L) return
        lastNetworkChangeAt = now
        appendRuntimeLog("INFO", "网络", "检测到网络变化，重建实时流")
        if (!foreground) return   // 后台由 BackgroundMonitorService 负责
        startLive()
    }

    fun startLive() {
        reconnectJob?.cancel(); reconnectJob = null
        foreground = true
        val tickerGen = ++tickerGeneration
        val klineGen = ++klineGeneration
        startPositionTickerWatch(_state.value.market, _state.value.positions.map { it.symbol })
        tickerSocket?.cancel(); tickerSocket = null
        klineSocket?.cancel(); klineSocket = null
        historyJob?.cancel()
        val selection = _state.value
        candleCache = emptyList()
        if (selection.symbol.isBlank()) {
            // No followed symbol: the dashboard shows scan/live universe only.
            _state.value = _state.value.copy(status = "就绪 · 点击机会卡「查看实时」关注单个品种", error = null)
            if (lastScannedSymbols.isNotEmpty() && lastScannedMarket == selection.market && lastScannedTimeframe == selection.timeframe && universeSockets.isEmpty()) {
                startUniverseWatch(lastScannedSymbols, selection.market, selection.timeframe)
            }
            return
        }
        _state.value = _state.value.copy(status = "正在连接行情", error = null)
        tickerSocket = repo.watchTicker(selection.symbol, selection.market,
            onOpen = {
                // 建连成功即视为恢复，重置退避；首个 tick 也会重置（双保险）
                if (tickerGen == tickerGeneration && foreground) reconnectAttempt = 0
            },
            onPrice = { price ->
                if (tickerGen == tickerGeneration && foreground && isCurrent(selection.symbol, selection.market, selection.timeframe)) {
                    reconnectAttempt = 0
                    val liveStatus = if (lastScannedSymbols.isNotEmpty() && lastScannedMarket == selection.market && lastScannedTimeframe == selection.timeframe) "前台全市场实时监控：${lastScannedSymbols.size} 个品种" else "实时行情已连接"
                    _state.value = _state.value.copy(livePrice = price.price, changePct = price.changePct, status = liveStatus)
                }
            },
            onError = { message ->
                if (tickerGen != tickerGeneration) return@watchTicker // 旧代际 socket 的延迟回调，忽略
                if (message.contains("Canceled", ignoreCase = true)) return@watchTicker // deliberate cancel of a stale socket
                if (foreground && isCurrent(selection.symbol, selection.market, selection.timeframe)) {
                    appendRuntimeLog("WARN", "行情WS", message)
                    _state.value = _state.value.copy(status = "实时行情连接中断，准备重连", error = "行情 WebSocket：$message")
                    scheduleReconnect(selection.symbol, selection.market, selection.timeframe, tickerGen)
                }
            })
        historyJob = viewModelScope.launch {
            try {
                val history = repo.candles(selection.symbol, selection.market, selection.timeframe, 300)
                if (klineGen != klineGeneration || !foreground || !isCurrent(selection.symbol, selection.market, selection.timeframe)) return@launch
                candleCache = history
                val initial = AnalysisEngine.analyze(selection.symbol, selection.market, selection.timeframe, history)
                if (initial != null) upsertAnalysis(initial, notify = false)
                // The combined universe stream already carries this symbol; avoid double analysis/review writes.
                val selectedCoveredByUniverse = lastScannedSymbols.contains(selection.symbol) &&
                    lastScannedMarket == selection.market && lastScannedTimeframe == selection.timeframe && universeSockets.isNotEmpty()
                if (!selectedCoveredByUniverse) {
                    klineSocket = repo.watchKline(selection.symbol, selection.market, selection.timeframe,
                        onOpen = {
                            if (klineGen == klineGeneration && foreground) reconnectAttempt = 0
                        },
                        onCandle = { candle, _ ->
                            if (universeOwnsSelectedKline || klineGen != klineGeneration || !foreground || !isCurrent(selection.symbol, selection.market, selection.timeframe)) return@watchKline
                            val old = candleCache
                            val newBar = old.isNotEmpty() && candle.openTime > old.last().openTime
                            candleCache = (if (old.lastOrNull()?.openTime == candle.openTime) old.dropLast(1) + candle else old + candle).takeLast(300)
                            // Re-evaluate only when a new candle starts, so incomplete candles don't repaint signals.
                            if (newBar) {
                                viewModelScope.launch {
                                    val currentBars = candleCache.toList()
                                    refreshLocalReviews(selection.market, selection.symbol, selection.timeframe, currentBars.dropLast(1))
                                    val analysis = AnalysisEngine.analyze(selection.symbol, selection.market, selection.timeframe, currentBars)
                                    if (klineGen == klineGeneration && foreground && isCurrent(selection.symbol, selection.market, selection.timeframe)) {
                                        if (analysis != null) upsertAnalysis(analysis, notify = true)
                                        else invalidateTrackedSignal(selection.symbol, selection.market, selection.timeframe)
                                    }
                                }
                            }
                        }, onError = { message ->
                            if (klineGen != klineGeneration) return@watchKline
                            if (message.contains("Canceled", ignoreCase = true)) return@watchKline
                            if (!universeOwnsSelectedKline && foreground && isCurrent(selection.symbol, selection.market, selection.timeframe)) {
                                appendRuntimeLog("WARN", "K线WS", message)
                                _state.value = _state.value.copy(status = "K线连接中断，准备重连", error = "K线 WebSocket：$message")
                                scheduleReconnect(selection.symbol, selection.market, selection.timeframe, klineGen)
                            }
                        })
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                // Backgrounding the app or switching symbol/timeframe is not an error.
            } catch (e: Exception) {
                if (klineGen == klineGeneration && foreground && isCurrent(selection.symbol, selection.market, selection.timeframe)) {
                    _state.value = _state.value.copy(error = "行情/K线加载失败：${e.message ?: "网络错误"}", status = "连接失败")
                }
            }
        }
        if (lastScannedSymbols.isNotEmpty() && lastScannedMarket == selection.market && lastScannedTimeframe == selection.timeframe && universeSockets.isEmpty()) {
            startUniverseWatch(lastScannedSymbols, selection.market, selection.timeframe)
        }
    }

    private fun stopPositionTickerWatch() {
        positionTickerGeneration += 1L
        positionTickerReconnectJob?.cancel(); positionTickerReconnectJob = null
        positionTickerSockets.forEach { it.cancel() }
        positionTickerSockets.clear()
    }

    private fun startPositionTickerWatch(market: String, symbols: List<String>) {
        stopPositionTickerWatch()
        if (!foreground || _state.value.market != market || symbols.isEmpty()) return
        val generation = positionTickerGeneration
        val uniq = symbols.map { it.uppercase() }.distinct()
        appendRuntimeLog("INFO", "持仓行情", "订阅 ${uniq.size} 个：${uniq.take(5).joinToString()}${if (uniq.size > 5) "…" else ""} · $market")
        positionTickerSockets += repo.watchPositionTickers(uniq, market, onPrice = { symbol, price ->
            if (generation == positionTickerGeneration && foreground && _state.value.market == market) {
                val err = _state.value.error
                val clearPosErr = err != null && err.contains("持仓行情")
                _state.value = _state.value.copy(
                    positionPrices = _state.value.positionPrices + (symbol to price.price),
                    error = if (clearPosErr) null else err,
                    stalePositions = _state.value.stalePositions - symbol   // v5.0.11 首个 tick 清除断开标注
                )
                if (_state.value.autoBattle) scheduleFlush()
            }
        }, onError = { message ->
            if (generation == positionTickerGeneration && foreground && _state.value.market == market) {
                // 不清空 positionPrices，避免持仓页瞬间变成无报价；v5.0.11 标"已断开"（保留最后价）
                appendRuntimeLog("WARN", "持仓行情", message)
                _state.value = _state.value.copy(
                    error = "持仓行情暂时中断：$message",
                    stalePositions = _state.value.positions.map { it.symbol }.toSet()
                )
                if (positionTickerReconnectJob?.isActive != true) {
                    positionTickerReconnectJob = viewModelScope.launch {
                        appendRuntimeLog("INFO", "持仓行情", "2 秒后重连…")
                        kotlinx.coroutines.delay(2_000)
                        positionTickerReconnectJob = null
                        if (foreground && _state.value.market == market && _state.value.positions.isNotEmpty()) {
                            startPositionTickerWatch(market, _state.value.positions.map { it.symbol })
                        }
                    }
                }
            }
        })
    }

    private fun stopUniverseWatch(clearLast: Boolean) {
        universeGeneration += 1L // Ignore late callbacks from sockets being cancelled.
        universeOwnsSelectedKline = false
        universeReconnectJob?.cancel(); universeReconnectJob = null
        universeSockets.forEach { it.cancel() }
        universeSockets.clear()
        stopOppTickers()
        if (clearLast) {
            lastScannedSymbols = emptyList(); lastScannedMarket = ""; lastScannedTimeframe = ""
            lastUniverseOpenTimes.clear()
        }
    }

    private fun startUniverseWatch(symbols: List<String>, market: String, timeframe: String) {
        if (!foreground || symbols.isEmpty()) return
        stopUniverseWatch(clearLast = false)
        val generation = universeGeneration
        lastScannedSymbols = symbols.distinct()
        lastScannedMarket = market
        lastScannedTimeframe = timeframe
        universeOwnsSelectedKline = _state.value.market == market && _state.value.timeframe == timeframe && lastScannedSymbols.contains(_state.value.symbol)
        if (universeOwnsSelectedKline) {
            // The combined stream now owns this symbol too; avoid duplicate K-line callbacks/reviews.
            klineSocket?.cancel(); klineSocket = null
        }
        lastUniverseOpenTimes.clear()
        lastScannedSymbols.forEach { symbol ->
            repo.cachedCandles(symbol, market, timeframe).lastOrNull()?.let { candle ->
                lastUniverseOpenTimes["$market|$timeframe|$symbol"] = candle.openTime
            }
        }
        val sockets = repo.watchUniverseKlines(lastScannedSymbols, market, timeframe, onCandle = { symbol, candle, history ->
            if (generation != universeGeneration || !foreground || _state.value.market != market || _state.value.timeframe != timeframe) return@watchUniverseKlines
            // 收到真实行情数据 = 连接存活，重置退避计数（避免重连成功后仍按旧档位等待）
            if (universeReconnectAttempt != 0) universeReconnectAttempt = 0
            val key = "$market|$timeframe|$symbol"
            val previous = lastUniverseOpenTimes.put(key, candle.openTime)
            val newBar = previous != null && candle.openTime > previous
            // A symbol whose REST history failed during the scan starts with a one-candle
            // websocket cache. Backfill immediately and retry on later bars if history is short.
            if (history.size < 220) {
                if ((previous == null || newBar) && universeBackfillsInFlight.add(key)) {
                    viewModelScope.launch(Dispatchers.IO) {
                        try {
                            runCatching { repo.candles(symbol, market, timeframe, 300) }
                            val restored = repo.cachedCandles(symbol, market, timeframe)
                            if (restored.size >= 220 && foreground && generation == universeGeneration &&
                                _state.value.market == market && _state.value.timeframe == timeframe) {
                                entryCandles[key] = restored.takeLast(300)   // v5.0.15
                                val analysis = withContext(Dispatchers.Default) { AnalysisEngine.analyze(symbol, market, timeframe, restored) }
                                withContext(Dispatchers.Main) {
                                    if (foreground && generation == universeGeneration && _state.value.market == market && _state.value.timeframe == timeframe) {
                                        if (analysis != null) upsertAnalysis(analysis, notify = false)
                                    }
                                }
                            }
                        } finally {
                            universeBackfillsInFlight.remove(key)
                        }
                    }
                }
                return@watchUniverseKlines
            }
            if (!newBar) return@watchUniverseKlines
            viewModelScope.launch(Dispatchers.Default) {
                val closedBars = history.dropLast(1)
                entryCandles[key] = history.takeLast(300)   // v5.0.15 价值区/结构评估快照
                refreshLocalReviews(market, symbol, timeframe, closedBars)
                val analysis = AnalysisEngine.analyze(symbol, market, timeframe, history)
                withContext(Dispatchers.Main) {
                    if (foreground && _state.value.market == market && _state.value.timeframe == timeframe) {
                        if (analysis != null) upsertAnalysis(analysis, notify = true)
                        else invalidateTrackedSignal(symbol, market, timeframe)
                    }
                }
            }
        }, onError = { message ->
            if (message.contains("Canceled", ignoreCase = true)) return@watchUniverseKlines
            if (generation == universeGeneration && foreground && _state.value.market == market && _state.value.timeframe == timeframe) {
                appendRuntimeLog("WARN", "全市场WS", message)
                _state.value = _state.value.copy(status = "全市场实时连接中断，准备重连", error = message)
                scheduleUniverseReconnect(market, timeframe)
            }
        })
        universeSockets.addAll(sockets)
        startOppTickers(lastScannedSymbols, market, timeframe)
        appendRuntimeLog("INFO", "全市场WS", "已连接 · ${lastScannedSymbols.size}品种 · ${sockets.size}路 · $market/$timeframe")
        _state.value = _state.value.copy(status = "前台全市场实时监控：${lastScannedSymbols.size} 个品种")
    }

    // ------------------------------------------------------------------ //
    // 机会列表实时价格（@ticker 合并流，约 1s 推送；独立于 universe K线流）
    // ------------------------------------------------------------------ //
    private val oppTickerSockets = mutableListOf<WebSocket>()
    @Volatile private var oppTickerGeneration: Long = 0L
    private val healthTrackers = ConcurrentHashMap<String, com.klinealert.nativeapp.domain.HealthTracker>()
    private var oppReconnectJob: Job? = null

    // 节流合并：tick 只写内存缓存，500ms 合并发射一次，重组频率 ~120/s → 2/s
    private val pendingPrices = ConcurrentHashMap<String, Pair<Double, Double>>()
    private val pendingHealth = ConcurrentHashMap<String, com.klinealert.nativeapp.domain.SignalHealth>()
    // 机会确认状态机：确认窗口内验证行情是否朝信号方向真实走出
    private val confirmations = java.util.concurrent.ConcurrentHashMap<String, com.klinealert.nativeapp.domain.Confirmation>()
    private val confirmDirty = java.util.concurrent.ConcurrentHashMap<String, Boolean>() // 待落库的已判定确认

    /** 扫描/融合后注册新机会的确认观察（A/B 级才值得观察） */
    /** v3.7 四维证据分：每次机会列表更新后重算。读盘在 IO 线程（实时回调高频触发，禁止阻塞主线程） */
    private fun computeEvidence(ops: List<SymbolOpportunity>) {
        if (ops.isEmpty()) { _state.value = _state.value.copy(evidence = emptyMap()); return }
        val market = _state.value.market
        val confirm = _state.value.confirmRank.associate { it.symbol to it.rate }
        val live = _state.value.oppPrices
        viewModelScope.launch(Dispatchers.IO) {
            val rows = runCatching { localStore.loadReviews(market, 500) }.getOrDefault(emptyList())
            val wr = com.klinealert.nativeapp.domain.LearnedWeights.winRates(rows)
            val ev = ops.associate { sop ->
                val a = sop.rep
                "${sop.market}|${sop.symbol}" to com.klinealert.nativeapp.domain.EvidenceEngine.evaluate(
                    sop, live[sop.symbol]?.first, wr["${a.timeframe}|${sop.direction}"], confirm[sop.symbol])
            }
            _state.value = _state.value.copy(evidence = ev)
            refreshSetups(ops)
        }
    }

    /** v4.2 启动恢复：从本地库读回待命单；已过期/已破失效位的直接丢弃，其余保留继续推进。 */
    private fun loadPendingSetups() {
        viewModelScope.launch(Dispatchers.IO) {
            val now = System.currentTimeMillis()
            val restored = runCatching { localStore.loadPendingSetups() }.getOrDefault(emptyList())
                .filter { it.active && it.expireAt > now }   // 只恢复仍未到期的活跃单
            if (restored.isEmpty()) return@launch
            // 与内存态合并（内存优先，避免覆盖刚生成的）
            val merged = restored.associateBy { it.key } + _state.value.setups
            _state.value = _state.value.copy(setups = merged)
            // 恢复后立刻落库一次，清掉被过滤掉的过期单
            runCatching { localStore.savePendingSetups(merged.values.toList()) }
        }
    }

    /** v3.8 待命单：基于机会+证据重建（保留已有状态与触发时间），并推进 tick 判定 */
    private fun refreshSetups(ops: List<SymbolOpportunity>) {
        if (ops.isEmpty()) { _state.value = _state.value.copy(setups = emptyMap()); return }
        val now = System.currentTimeMillis()
        val prev = _state.value.setups
        val ev = _state.value.evidence
        val live = _state.value.oppPrices
        val confirm = _state.value.confirmRank.associate { it.symbol to it.rate }
        val wr = _state.value.tfWinRates
        val next = mutableMapOf<String, com.klinealert.nativeapp.domain.PendingSetup>()
        ops.forEach { sop ->
            val key = com.klinealert.nativeapp.domain.PendingSetupEngine.keyOf(sop.market, sop.symbol, sop.direction)
            val a = sop.rep
            val existing = prev[key]
            if (existing != null && existing.active) {
                // 已存在：tick 推进（用实时价 + 当前量价形态）
                val price = live[sop.symbol]?.first ?: sop.price
                next[key] = com.klinealert.nativeapp.domain.PendingSetupEngine.onTick(existing, price, now, a.volumePattern)
            } else {
                // 新建（仅证据分 ≥50 才建单，避免噪声）
                val e = ev["${sop.market}|${sop.symbol}"]
                if ((e?.score ?: sop.score) < 50) return@forEach
                // v3.9 时间去重：同品种同方向 4 小时内只生成 1 次（避免反复进出被手续费磨死）
                val cool = setupCooldown["${sop.symbol}|${sop.direction}"] ?: 0L
                val allowSecond = secondEntryMark.containsKey(key)   // 二次入场放行一次
                if (now - cool < 4 * 3_600_000L && !allowSecond) return@forEach
                com.klinealert.nativeapp.domain.PendingSetupEngine.build(
                    sop, live[sop.symbol]?.first, e, wr["${a.timeframe}|${sop.direction}"], confirm[sop.symbol], now,
                    _state.value.stopMult, _state.value.targetMult   // v5.0.9 全局止盈止损乘数
                )?.let {
                    next[key] = it
                    setupCooldown["${sop.symbol}|${sop.direction}"] = now
                    secondEntryMark.remove(key)
                }
            }
        }
        _state.value = _state.value.copy(setups = next)
        persistSetups(next.values.toList())
    }

    /** v4.2 待命单落库（异步，失败不阻断主流程）。 */
    private fun persistSetups(rows: List<com.klinealert.nativeapp.domain.PendingSetup>) {
        viewModelScope.launch(Dispatchers.IO) { runCatching { localStore.savePendingSetups(rows) } }
    }

    /**
     * v4.2 回踩/结算落库：待命单回踩确认（TRIGGERED）时，把该品种该方向的 open 记录补上
     * armedAt / pullbackConfirmed / pullbackMs / evidenceScore，供后续回测校准使用。
     * 若找不到对应 open 记录（该机会未进入 A/B 级记账），则跳过。
     */
    private fun persistPullbackOnTrigger(st: com.klinealert.nativeapp.domain.PendingSetup) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                val rec = localStore.loadReviews(st.market, 1000)
                    .firstOrNull { it.verdict == "open" && it.symbol == st.symbol && it.direction == st.direction }
                    ?: return@runCatching
                val pullMs = if (st.armedAt > 0 && st.triggeredAt > 0) st.triggeredAt - st.armedAt else 0L
                localStore.updateReview(rec.copy(
                    armedAt = st.armedAt,
                    pullbackConfirmed = st.armedAt > 0L,   // 经历 ARMED 才算回踩确认
                    pullbackMs = pullMs,
                    evidenceScore = st.evidenceScore
                ))
            }
        }
    }

    private fun registerConfirmations(ops: List<SymbolOpportunity>) {
        val now = System.currentTimeMillis()
        val currentKeys = ops.map { com.klinealert.nativeapp.domain.ConfirmationGate.keyOf(it.market, it.symbol, it.direction) }.toSet()
        // 清理已消失且已判定超过 30 分钟的旧确认
        confirmations.entries.removeIf { (k, c) ->
            (c.resolved && now - c.resolvedAt > 30 * 60_000L) || (!currentKeys.contains(k) && !c.resolved && now - c.startedAt > 2 * 60 * 60_000L)
        }
        ops.filter { it.grade == "A" || it.grade == "B" }.forEach { sop ->
            val key = com.klinealert.nativeapp.domain.ConfirmationGate.keyOf(sop.market, sop.symbol, sop.direction)
            if (!confirmations.containsKey(key)) {
                com.klinealert.nativeapp.domain.ConfirmationGate.start(sop, now)?.let { confirmations[key] = it }
            }
        }
    }

    /** 确认判定落库：把结果写入对应的 open 记账 features（训练闭环用） */
    private fun persistConfirmation(c: com.klinealert.nativeapp.domain.Confirmation) {
        if (!c.resolved) return
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                val records = localStore.loadReviews(c.market, 1000).filter { it.verdict == "open" && it.symbol == c.symbol && it.direction == c.direction }
                records.firstOrNull()?.let { rec ->
                    val feat = rec.features.replace("\"confirm\":\"[^\"]*\",".toRegex(), "")
                        .removeSuffix("}") + ",\"confirm\":\"${c.status}\"}"
                    // v3.7 智能失效：假启动且反向走出 ≥1.2×ATR → 提前结案为 invalid（负样本半权重）
                    localStore.updateReview(com.klinealert.nativeapp.domain.ReviewEngine.smartInvalidate(rec.copy(features = feat), c))
                }
            }
        }
    }
    @Volatile private var lastTickAt = 0L
    private var flushJob: Job? = null

    private fun scheduleFlush() {
        if (flushJob?.isActive == true) return
        flushJob = viewModelScope.launch {
            kotlinx.coroutines.delay(500)
            val p = pendingPrices.toMap(); val h = pendingHealth.toMap()
            pendingPrices.clear(); pendingHealth.clear()
            // v3.8 待命单 tick 驱动：价格触及触发价/失效价即时推进（不依赖扫描周期）
            if (_state.value.setups.isNotEmpty()) {
                val now = System.currentTimeMillis()
                val prevSetups = _state.value.setups
                val updated = prevSetups.mapValues { (k, st) ->
                    val rawPx = p[st.symbol]?.first ?: st.triggeredPrice
                    val pat = _state.value.symbolOps.firstOrNull { it.symbol == st.symbol && it.direction == st.direction }?.rep?.volumePattern ?: ""
                    // v4.3 交叉校验：若该 tick 会引发状态跃迁（到价/回踩确认），先用独立交易所参考价确认价格合理；
                    // 偏差过大（疑似插针/单源异常）→ 本次不推进，等下一 tick 复核。无参考数据时不拦截。
                    val px = if (rawPx > 0 && crossCheck.shouldBlock(st, rawPx)) st.triggeredPrice.takeIf { it > 0 } ?: rawPx else rawPx
                    if (px > 0) com.klinealert.nativeapp.domain.PendingSetupEngine.onTick(st, px, now, pat) else st
                }
                // v3.9/v4.1 状态跃迁：回踩确认（TRIGGERED）才推送通知；ARMED 仅为中间态
                updated.forEach { (k, st) ->
                    val before = prevSetups[k]
                    val nowTriggered = st.status == com.klinealert.nativeapp.domain.PendingSetup.TRIGGERED &&
                        before != null && before.status != com.klinealert.nativeapp.domain.PendingSetup.TRIGGERED
                    if (before != null && nowTriggered) {
                        val quietOn = settingsPrefs().getBoolean("quiet_enabled", true)
                        SetupNotifier.notifyTriggered(
                            getApplication(), st.symbol, st.direction, st.timeframe,
                            st.triggerPrice, st.stop, st.target3R, st.evidenceScore,
                            settingsPrefs().getInt("quiet_start", 23), settingsPrefs().getInt("quiet_end", 8), quietOn)
                        // 标记二次入场：触发后允许 4h 内出现一次回踩二次机会
                        secondEntryMark[k] = now
                        // v4.2 回踩/结算落库：把 armedAt/回踩耗时/证据分写入对应 open 记录，供事后校准
                        persistPullbackOnTrigger(st)
                        // v4.0 AI 复核：仅高价值（证据≥85）触发时自动送 AI 研判；未配置 AI 则跳过
                        if (st.evidenceScore >= 85) aiReviewSetup(st)
                    }
                }
                _state.value = _state.value.copy(setups = updated)
                persistSetups(updated.values.toList())   // v4.2 tick 推进后落库（重启可恢复）
            }
            // v4.5 自动作战循环：持仓止盈/止损/移动止盈判定 + 坑位候补顶上（全自动，防插针由引擎内交叉校验把关）
            if (_state.value.autoBattle) battleTick(System.currentTimeMillis())
            _state.value = _state.value.copy(
                oppPrices = _state.value.oppPrices + p,
                oppHealth = _state.value.oppHealth + h,
                oppConfirm = confirmations.toMap(),
                oppStreamSockets = synchronized(oppTickerSockets) { oppTickerSockets.size },
                lastTickAt = lastTickAt
            )
            // 判定结果落库（每轮 flush 最多处理一次，幂等）
            if (confirmDirty.isNotEmpty()) {
                confirmDirty.keys.forEach { k -> confirmations[k]?.let { persistConfirmation(it) } }
                confirmDirty.clear()
            }
        }
    }

    private fun stopOppTickers() {
        oppTickerGeneration += 1L
        oppReconnectJob?.cancel(); oppReconnectJob = null
        oppTickerSockets.forEach { runCatching { it.cancel() } }
        oppTickerSockets.clear()
    }

    private fun startOppTickers(symbols: List<String>, market: String, timeframe: String) {
        stopOppTickers()
        if (!foreground || symbols.isEmpty()) return
        val generation = oppTickerGeneration
        // 关注品种永远在实时流里，其次才是机会榜品种（省电模式缩减至 40）
        val watchList = (_state.value.watchlist + symbols.distinct()).take(if (_state.value.powerSave) 40 else 120)
        oppTickerSockets += repo.watchPositionTickers(watchList, market, onPrice = { symbol, lp ->
            if (generation == oppTickerGeneration && foreground && _state.value.market == market && _state.value.timeframe == timeframe) {
                lastTickAt = System.currentTimeMillis()
                pendingPrices[symbol] = lp.price to lp.changePct
                // 实时健康度 2.0：tick 驱动迟滞状态机（MFE/MAE + 3tick 去抖）
                val sop = _state.value.symbolOps.firstOrNull { it.symbol == symbol && it.market == market }
                if (sop != null) {
                    val h = healthTrackers.getOrPut(symbol) { com.klinealert.nativeapp.domain.HealthTracker() }.update(sop, lp.price)
                    pendingHealth[symbol] = h
                }
                // 机会确认状态机：tick 驱动确认判定
                val ck = com.klinealert.nativeapp.domain.ConfirmationGate.keyOf(market, symbol, sop?.direction ?: "")
                confirmations[ck]?.let { c ->
                    if (!c.resolved) {
                        val nc = com.klinealert.nativeapp.domain.ConfirmationGate.onTick(c, lp.price, lastTickAt)
                        if (nc != c) {
                            confirmations[ck] = nc
                            if (nc.resolved) { confirmDirty[ck] = true }
                        }
                    }
                }
                scheduleFlush()
            }
        }, onError = { message ->
            if (message.contains("Canceled", ignoreCase = true)) return@watchPositionTickers
            // 实时价流此前被静默吞掉导致健康度永远等待：现在加入自动重连
            if (generation == oppTickerGeneration && foreground && _state.value.market == market && _state.value.timeframe == timeframe) {
                if (oppReconnectJob?.isActive != true) {
                    oppReconnectJob = viewModelScope.launch {
                        kotlinx.coroutines.delay(2_000)
                        oppReconnectJob = null
                        if (foreground && _state.value.market == market && _state.value.timeframe == timeframe && lastScannedSymbols.isNotEmpty()) {
                            startOppTickers(lastScannedSymbols, market, timeframe)
                        }
                    }
                }
            }
        })
    }

    private fun scheduleUniverseReconnect(market: String, timeframe: String) {
        if (universeReconnectJob?.isActive == true) return
        universeReconnectJob = viewModelScope.launch {
            val attempt = (universeReconnectAttempt + 1).coerceAtMost(5)
            universeReconnectAttempt = attempt
            val waitMs = (2_000L shl (attempt - 1)).coerceAtMost(30_000L)
            appendRuntimeLog("INFO", "全市场WS", "准备重连 第${attempt}次 · ${waitMs / 1000}s 后 · ${lastScannedSymbols.size}品种")
            kotlinx.coroutines.delay(waitMs)
            universeReconnectJob = null
            if (foreground && _state.value.market == market && _state.value.timeframe == timeframe && lastScannedSymbols.isNotEmpty()) {
                appendRuntimeLog("INFO", "全市场WS", "开始重连…")
                startUniverseWatch(lastScannedSymbols, market, timeframe)
            }
        }
    }

    private fun scheduleReconnect(symbol: String, market: String, timeframe: String, generation: Long) {
        if (reconnectJob?.isActive == true) return
        reconnectJob = viewModelScope.launch {
            // 封顶指数退避（2s→4s→8s→16s→30s），主机不可达时不再每 2 秒无脑轰炸；
            // 建连成功（onOpen/首 tick）会把 reconnectAttempt 归零，退避从头开始。
            val attempt = (reconnectAttempt + 1).coerceAtMost(5)
            reconnectAttempt = attempt
            val waitMs = (2_000L shl (attempt - 1)).coerceAtMost(30_000L)
            appendRuntimeLog("INFO", "行情WS", "准备重连 第${attempt}次 · ${waitMs / 1000}s 后")
            kotlinx.coroutines.delay(waitMs)
            reconnectJob = null
            // 代际校验：重连等待期间若已切品种/周期/前后台（ticker/kline 代际都会递增），放弃本次重连
            if ((generation == tickerGeneration || generation == klineGeneration) && foreground && isCurrent(symbol, market, timeframe)) {
                appendRuntimeLog("INFO", "行情WS", "开始重连…")
                startLive()
            }
        }
    }

    private fun isCurrent(symbol: String, market: String, timeframe: String) =
        _state.value.symbol == symbol && _state.value.market == market && _state.value.timeframe == timeframe

    private fun upsertAnalysis(a: Analysis, notify: Boolean) {
        val old = _state.value.results.firstOrNull { it.symbol == a.symbol && it.market == a.market && it.timeframe == a.timeframe }
        // 同品种同方向 30 分钟冷却：抑制重复弹条
        val cdKey = "${a.market}|${a.symbol}|${a.direction}"
        val cdOk = notify && (alertCooldown[cdKey] ?: 0L).let { System.currentTimeMillis() - it > 30 * 60_000L }
        if (cdOk) alertCooldown[cdKey] = System.currentTimeMillis()
        val signalChanged = notify && cdOk && a.direction != "NEUTRAL" && (old == null || old.direction != a.direction)
        val alert = if (signalChanged) {
            if (old == null) "${a.symbol} ${a.timeframe} 出现新信号：${a.direction}（评分 ${a.score}）"
            else "${a.symbol} ${a.timeframe} 信号方向变化：${old.direction} → ${a.direction}（评分 ${a.score}）"
        } else _state.value.alertMessage
        val updated = listOf(a) + _state.value.results.filterNot { it.symbol == a.symbol && it.market == a.market && it.timeframe == a.timeframe }
        // 实时新K线到来时，把该周期更新合并回品种聚合卡，重算融合分（保持卡片实时）
        // 融合权重使用学习后的周期×方向权重（历史胜率越高权重越大）
        val learned = _state.value.learnedWeights
        val calib = com.klinealert.nativeapp.domain.Calibrator.bonusMap(_state.value.patternStats)
        val ops = _state.value.symbolOps
        val newOps = if (ops.isNotEmpty()) {
            val existing = ops.firstOrNull { it.symbol == a.symbol && it.market == a.market }
            if (existing != null) {
                val mergedPer = existing.perTimeframe + (a.timeframe to a)
                val fused = OpportunityFusion.fuse(a.symbol, a.market, mergedPer, learned, calib)
                if (fused != null) ops.map { if (it.symbol == a.symbol && it.market == a.market) fused else it }.sortedByDescending { it.score }
                else ops.filterNot { it.symbol == a.symbol && it.market == a.market } // 信号已失效，卡片移除
            } else {
                val fused = OpportunityFusion.fuse(a.symbol, a.market, mapOf(a.timeframe to a), learned, calib)
                if (fused != null) (listOf(fused) + ops).sortedByDescending { it.score } else ops
            }
        } else ops
        _state.value = _state.value.copy(results = updated, symbolOps = newOps, alertMessage = alert)
        computeEvidence(newOps)
        if (newOps.isNotEmpty()) {
            registerConfirmations(newOps)
            _state.value = _state.value.copy(oppConfirm = confirmations.toMap())
        }
        // 持仓反向预警：持仓品种出现相反方向信号时立即提示
        if (a.direction != "NEUTRAL") {
            val pos = _state.value.positions.firstOrNull { it.symbol == a.symbol && it.market == a.market }
            if (pos != null && pos.direction != a.direction) {
                _state.value = _state.value.copy(
                    alertMessage = "⚠ 持仓预警：${a.symbol}（你的${if (pos.direction == "LONG") "多单" else "空单"}）出现反向 ${a.direction} 信号（${a.timeframe}，评分 ${a.score}），注意风控"
                )
            }
        }
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { localStore.saveAnalyses(a.market, a.timeframe, updated) }
            // Store only actual foreground direction-change alerts for local outcome review.
            if (signalChanged) {
                runCatching { localStore.saveReview(ReviewEngine.create(a)) }
                loadReviewSummary(a.market)
                loadHistory(a.market)
            }
        }
    }

    /** Settle local review records only while the app is foregrounded and a new candle arrives. */
    private suspend fun refreshLocalReviews(market: String, symbol: String, timeframe: String, candles: List<Candle>) {
        withContext(Dispatchers.IO) {
            val records = runCatching { localStore.loadReviews(market, 500) }.getOrDefault(emptyList())
            val now = System.currentTimeMillis()
            records.asSequence()
                .filter { it.verdict == "open" && it.symbol == symbol && it.timeframe == timeframe }
                .forEach { record ->
                    val expired = ReviewEngine.expire(record, now)
                    val updated = if (expired.verdict != "open") expired else {
                        val afterAlert = candles.filter { it.openTime > record.alertedAt }
                        if (afterAlert.isEmpty()) record else ReviewEngine.settle(record, ReviewEngine.touch(afterAlert, record), now)
                    }
                    if (updated != record) runCatching { localStore.updateReview(updated) }
                }
        }
        loadReviewSummary(market)
    }

    private fun invalidateTrackedSignal(symbol: String, market: String, timeframe: String) {
        val old = _state.value.results.firstOrNull { it.symbol == symbol && it.market == market && it.timeframe == timeframe } ?: return
        _state.value = _state.value.copy(
            results = _state.value.results.filterNot { it.symbol == symbol && it.market == market && it.timeframe == timeframe },
            alertMessage = "$symbol $timeframe 原有${old.direction}信号已失效：最新收盘K线不再满足触发条件"
        )
    }

    fun dismissAlert() { _state.value = _state.value.copy(alertMessage = null) }

    /** 每日复盘：每天首次打开 App 时生成一次昨日/今日汇总提示。 */
    private fun maybeDailyReport() {
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).apply { timeZone = java.util.TimeZone.getTimeZone("GMT+8") }
        val today = fmt.format(java.util.Date())
        if (dailyReportDay == today) return
        dailyReportDay = today
        val market = _state.value.market
        viewModelScope.launch(Dispatchers.IO) {
            val rows = runCatching { localStore.loadReviews(market, 1000) }.getOrDefault(emptyList())
            val tz = java.util.TimeZone.getTimeZone("GMT+8")
            val dayStart = java.util.Calendar.getInstance(tz).apply {
                set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0)
            }.timeInMillis
            val todayRows = rows.filter { it.alertedAt >= dayStart }
            val hit = todayRows.count { it.verdict == "hit" }
            val miss = todayRows.count { it.verdict == "miss" }
            val open = todayRows.count { it.verdict == "open" }
            val settledToday = rows.filter { it.verdictAt >= dayStart && (it.verdict == "hit" || it.verdict == "miss") }
            val winRate = if (settledToday.isEmpty()) "—" else String.format(java.util.Locale.US, "%.0f%%", settledToday.count { it.verdict == "hit" } * 100.0 / settledToday.size)
            val msg = "📊 每日复盘：今日新信号 ${todayRows.size} 个（跟踪中 $open · 命中 $hit · 落空 $miss），今日结算胜率 $winRate，记账样本 ${rows.size} 条"
            withContext(Dispatchers.Main) { if (_state.value.alertMessage == null) _state.value = _state.value.copy(alertMessage = msg) }
        }
    }
    private var dailyReportDay = ""

    /** 导出记账 CSV：Android 10+ 存到下载目录；旧版本复制到剪贴板。结果经 alertMessage 提示。 */
    fun exportCsv() {
        viewModelScope.launch(Dispatchers.IO) {
            val market = _state.value.market
            val rows = runCatching { localStore.loadReviews(market, 5000) }.getOrDefault(emptyList())
            val csv = buildString {
                appendLine("market,symbol,timeframe,direction,entry,stop,target,score,alerted_at,verdict,verdict_at,hit_price,features")
                val iso = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US)
                rows.forEach { r ->
                    appendLine(listOf(r.market, r.symbol, r.timeframe, r.direction, r.entry, r.stop, r.target, r.score,
                        iso.format(java.util.Date(r.alertedAt)), r.verdict,
                        if (r.verdictAt > 0) iso.format(java.util.Date(r.verdictAt)) else "",
                        r.hitPrice, "\"${r.features.replace("\"", "'")}\"").joinToString(","))
                }
            }
            val app = getApplication<Application>()
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                val msg = runCatching {
                    val values = android.content.ContentValues().apply {
                        put(android.provider.MediaStore.Downloads.DISPLAY_NAME, "kline_reviews_${market}_${System.currentTimeMillis()}.csv")
                        put(android.provider.MediaStore.Downloads.MIME_TYPE, "text/csv")
                    }
                    val uri = app.contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)!!
                    app.contentResolver.openOutputStream(uri)!!.use { it.write(csv.toByteArray()) }
                    "已导出 ${rows.size} 条记账到下载目录"
                }.getOrElse { "导出失败：${it.message}，已改用剪贴板" }
                withContext(Dispatchers.Main) { _state.value = _state.value.copy(alertMessage = msg) }
            } else {
                withContext(Dispatchers.Main) { _state.value = _state.value.copy(alertMessage = "Android 10 以下暂不支持直接保存，已生成 ${rows.size} 条 CSV（后续版本支持剪贴板导出）") }
            }
        }
    }

    /** 手动调整某机会的盈亏比：止盈价 = 入场 ± rr×风险，并重算级别与交易计划。 */
    fun setRiskReward(symbol: String, market: String, rr: Double) {
        val ops = _state.value.symbolOps.toMutableList()
        val idx = ops.indexOfFirst { it.symbol == symbol && it.market == market }
        if (idx < 0) return
        val sop = ops[idx]
        val a = sop.rep
        val risk = kotlin.math.abs(a.entry - a.stop)
        if (risk <= 0) return
        val newTarget = if (a.direction == "LONG") a.entry + rr * risk else a.entry - rr * risk
        val base = sop.copy(rep = a.copy(target = newTarget, riskReward = rr))
        val grade = com.klinealert.nativeapp.domain.PrecisionRank.gradeOf(base, _state.value.tfWinRates)
        ops[idx] = base.copy(grade = grade, plan = com.klinealert.nativeapp.domain.PrecisionRank.buildPlan(base))
        _state.value = _state.value.copy(symbolOps = ops, alertMessage = "$symbol 盈亏比已调整为 ${String.format(java.util.Locale.US, "%.2f", rr)}，止盈与计划已重算")
        // 缺口4：手动盈亏比同步回写记账记录（结算按调整后的止盈）
        viewModelScope.launch(Dispatchers.IO) {
            val rows = runCatching { localStore.loadReviews(market, 1000) }.getOrDefault(emptyList())
            rows.filter { it.verdict == "open" && it.symbol == symbol && it.market == market && it.timeframe == a.timeframe }
                .forEach { runCatching { localStore.updateReview(it.copy(target = newTarget)) } }
        }
    }

    fun setSearchQuery(value: String) { _state.value = _state.value.copy(searchQuery = value) }
    fun setStrictMerge(value: Boolean) { _state.value = _state.value.copy(strictMerge = value) }

    /** v3.9 夜间静音开关（23:00-08:00 只记录不推送） */
    fun setQuietEnabled(value: Boolean) { settingsPrefs().edit().putBoolean("quiet_enabled", value).apply() }
    fun quietEnabled(): Boolean = settingsPrefs().getBoolean("quiet_enabled", true)
    fun setMinConfidence(value: Int) { _state.value = _state.value.copy(minConfidence = value.coerceIn(0, 100)) }
    fun toggleScanTimeframe(value: String) {
        if (value !in AnalysisEngine.supportedTimeframes) return
        val current = _state.value.scanTimeframes
        val next = if (value in current) current - value else current + value
        if (next.isNotEmpty()) _state.value = _state.value.copy(scanTimeframes = next)
    }

    /** Start/stop the background foreground-service monitor with the current market & scan timeframes. */
    fun setBackgroundMonitor(enable: Boolean) {
        val app = getApplication<Application>()
        val s = _state.value
        settingsPrefs().edit().putBoolean("bg_monitor", enable).apply()
        if (enable) BackgroundMonitorService.start(app, s.market, s.scanTimeframes.filter { it in AnalysisEngine.supportedTimeframes }.ifEmpty { listOf(s.timeframe) })
        else BackgroundMonitorService.stop(app)
    }

    fun setTab(value: String) {
        if (_state.value.tab == value) return
        _state.value = _state.value.copy(tab = value)
        if (value == "history") loadHistory(_state.value.market)
        if (value == "diag") loadBacktest()
        if (value == "trade") {
            refreshTradeLinks()
            if (_state.value.tradeConnected) refreshTradeAccount()
            if (_state.value.tradeConfig.enabled) startTradeReconcileLoop()
        }
    }

    /** 监控止盈止损变更时同步交易所条件单。 */
    fun onLocalProtectiveChangedForTrade(p: LocalStore.LocalPosition) {
        if (!_state.value.tradeConfig.enabled || !_state.value.tradeConnected) return
        val creds = tradeCreds ?: return
        viewModelScope.launch(Dispatchers.IO) {
            when (val r = tradeBridge.syncProtective(creds, p.id, p.stop, p.target, _state.value.tradeDualSide)) {
                is com.klinealert.nativeapp.domain.TradeBridge.Result.Ok -> {
                    pushTradeLog(p.symbol, "改保护单", true, r.message)
                    withContext(Dispatchers.Main) { refreshTradeLinks() }
                }
                is com.klinealert.nativeapp.domain.TradeBridge.Result.Skip -> Unit
                is com.klinealert.nativeapp.domain.TradeBridge.Result.Err ->
                    pushTradeLog(p.symbol, "改保护单失败", false, r.reason)
            }
        }
    }

    /** v4.4 通知深链：切到目标 Tab 并高亮品种（高亮在 UI 消费后清除）。 */
    fun handleDeepLink(tab: String?, symbol: String?) {
        if (!tab.isNullOrBlank()) setTab(tab)
        if (!symbol.isNullOrBlank()) _state.value = _state.value.copy(highlightSymbol = symbol)
    }

    /** v4.4 UI 消费高亮后清除，避免反复闪烁。 */
    fun clearHighlight() {
        if (_state.value.highlightSymbol != null) _state.value = _state.value.copy(highlightSymbol = null)
    }

    /** v4.4 生成回测校准报告（诊断页）。 */
    fun loadBacktest() {
        viewModelScope.launch(Dispatchers.IO) {
            val rows = runCatching { localStore.loadReviews(_state.value.market, 2000) }.getOrDefault(emptyList())
            val rep = com.klinealert.nativeapp.domain.BacktestAnalyzer.analyze(rows)
            _state.value = _state.value.copy(backtest = rep)
        }
    }

    /** v4.4 手动忽略待命单（标记为已过期并落库）。 */
    fun dismissSetup(key: String) {
        val cur = _state.value.setups[key] ?: return
        val next = _state.value.setups + (key to cur.copy(status = com.klinealert.nativeapp.domain.PendingSetup.EXPIRED, note = "手动忽略"))
        _state.value = _state.value.copy(setups = next)
        persistSetups(next.values.toList())
    }

    private fun loadHistory(market: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val rows = runCatching { localStore.loadReviews(market, 80) }.getOrDefault(emptyList())
            withContext(Dispatchers.Main) {
                if (_state.value.market == market) _state.value = _state.value.copy(history = rows)
            }
        }
    }

    fun scanAll() {
        if (scanJob?.isActive == true) return
        val s = _state.value
        val selectedTimeframes = s.scanTimeframes.filter { it in AnalysisEngine.supportedTimeframes }.ifEmpty { listOf(s.timeframe) }
        stopUniverseWatch(clearLast = true)
        universeReconnectAttempt = 0
        repo.clearCandleCache()
        scanJob = viewModelScope.launch {
            appendRuntimeLog("INFO", "扫描", "开始全市场扫描")
            _state.value = _state.value.copy(scanning = true, progress = 0, total = 0, error = null, status = "正在准备全市场扫描（品种统一 · ${selectedTimeframes.joinToString("/")}）")
            try {
                val outcome = repo.scanSymbols(s.market, selectedTimeframes, { done, total ->
                    _state.value = _state.value.copy(progress = done, total = total, instruments = total, status = "品种统一扫描 ${done}/$total · ${selectedTimeframes.joinToString("/")}")
                }, _state.value.learnedWeights, com.klinealert.nativeapp.domain.Calibrator.bonusMap(_state.value.patternStats))
                // 持久化各周期明细，供历史与回看使用
                withContext(Dispatchers.IO) {
                    val byTf = outcome.symbols.flatMap { sop -> sop.perTimeframe.values.map { it } }.groupBy { it.timeframe }
                    byTf.forEach { (tf, rows) -> runCatching { localStore.saveAnalyses(s.market, tf, rows) } }
                    // 训练闭环：A/B 级机会自动记账开单（同一信号K线由 id 唯一键去重）
                    outcome.symbols.filter { it.grade == "A" || it.grade == "B" }.forEach { sop ->
                        runCatching { localStore.saveReview(ReviewEngine.create(sop.rep)) }
                    }
                    // 训练闭环：用本轮扫描到的最新价结算旧的未决记录
                    val priceBySymbol = outcome.symbols.associate { it.symbol to it.price }
                    val open = runCatching { localStore.loadReviews(s.market, 1000) }.getOrDefault(emptyList()).filter { it.verdict == "open" }
                    open.forEach { rec ->
                        val price = priceBySymbol[rec.symbol] ?: return@forEach
                        val hit = if (rec.direction == "LONG") price >= rec.target else price <= rec.target
                        val miss = if (rec.direction == "LONG") price <= rec.stop else price >= rec.stop
                        val expired = ReviewEngine.expire(rec)
                        when {
                            hit && miss -> runCatching { localStore.updateReview(ReviewEngine.settle(rec, com.klinealert.nativeapp.domain.ReviewOutcome("miss", rec.stop, 0))) }
                            hit -> runCatching { localStore.updateReview(ReviewEngine.settle(rec, com.klinealert.nativeapp.domain.ReviewOutcome("hit", rec.target, 0))) }
                            miss -> runCatching { localStore.updateReview(ReviewEngine.settle(rec, com.klinealert.nativeapp.domain.ReviewOutcome("miss", rec.stop, 0))) }
                            expired != rec -> runCatching { localStore.updateReview(expired) }
                        }
                    }
                }
                val flattened = outcome.symbols.flatMap { it.perTimeframe.values }
                _state.value = _state.value.copy(
                    symbolOps = outcome.symbols,
                    results = flattened.sortedByDescending { it.score },
                    scanning = false, instruments = outcome.universeSize,
                    status = "扫描完成：${outcome.symbols.size} 个品种机会 · ${selectedTimeframes.joinToString("/")} · ${outcome.failedSymbols} 个品种失败",
                    error = if (outcome.failedSymbols > 0) "有 ${outcome.failedSymbols} 个品种请求重试后仍失败；结果可能不完整。" else null
                )
                computeEvidence(outcome.symbols)
                registerConfirmations(outcome.symbols)
                _state.value = _state.value.copy(oppConfirm = confirmations.toMap())
                // Persist the completed universe even if the scan finishes while the app is backgrounded.
                // startUniverseWatch() intentionally returns when !foreground, so without this assignment
                // the next ON_START has no symbols to resubscribe after scanAll() cleared the previous set.
                if (outcome.universe.isNotEmpty()) {
                    lastScannedSymbols = outcome.universe.distinct()
                    lastScannedMarket = s.market
                    lastScannedTimeframe = s.timeframe
                }
                if (foreground && _state.value.market == s.market && _state.value.timeframe == s.timeframe && outcome.universe.isNotEmpty()) {
                    startUniverseWatch(outcome.universe, s.market, s.timeframe)
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.value = _state.value.copy(scanning = false, error = e.message ?: "扫描失败", status = "扫描失败")
            }
        }
    }
    override fun onCleared() {
        foreground = false
        tickerGeneration += 1L
        klineGeneration += 1L
        reconnectJob?.cancel(); reconnectJob = null
        stopUniverseWatch(clearLast = true)
        stopPositionTickerWatch()
        tickerSocket?.cancel(); klineSocket?.cancel(); scanJob?.cancel(); historyJob?.cancel()
        localStore.close()
        super.onCleared()
    }
}
