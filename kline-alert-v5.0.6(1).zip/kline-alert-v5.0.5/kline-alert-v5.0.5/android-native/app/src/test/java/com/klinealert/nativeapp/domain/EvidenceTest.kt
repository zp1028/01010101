package com.klinealert.nativeapp.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** v3.7 量价形态分类器 + 四维证据引擎测试 */
class EvidenceTest {

    private fun candle(open: Double, close: Double, high: Double, low: Double, vol: Double) =
        Candle(openTime = 0L, open = open, high = high, low = low, close = close, volume = vol, closeTime = 0L)

    /* ---------- VolumePriceClassifier ---------- */

    @Test fun `放量突破识别`() {
        val cs = listOf(candle(99.0, 99.5, 99.8, 98.9, 100.0), candle(99.5, 101.5, 101.6, 99.4, 200.0))
        val (p, _) = VolumePriceClassifier.classify(cs, volRatio = 2.0, atr = 1.0, support = 98.0, resistance = 101.0, ema20 = null)
        assertEquals("放量突破", p)
    }

    @Test fun `放量下跌识别`() {
        val cs = listOf(candle(101.0, 100.5, 101.2, 100.3, 100.0), candle(100.5, 98.5, 100.6, 98.4, 250.0))
        val (p, _) = VolumePriceClassifier.classify(cs, volRatio = 2.5, atr = 1.0, support = 97.0, resistance = 103.0, ema20 = null)
        assertEquals("放量下跌", p)
    }

    @Test fun `缩量回踩识别`() {
        val cs = listOf(candle(100.0, 100.2, 100.4, 99.6, 100.0), candle(100.2, 100.1, 100.3, 99.3, 40.0))
        val (p, _) = VolumePriceClassifier.classify(cs, volRatio = 0.4, atr = 1.0, support = 99.35, resistance = 102.0, ema20 = null)
        assertEquals("缩量回踩", p)
    }

    @Test fun `突破失败识别`() {
        // 前一根收盘破压力 101，本根收回
        val cs = listOf(candle(100.0, 101.3, 101.5, 99.9, 180.0), candle(101.3, 100.4, 101.4, 100.2, 150.0))
        val (p, _) = VolumePriceClassifier.classify(cs, volRatio = 1.5, atr = 1.0, support = 98.0, resistance = 101.0, ema20 = null)
        assertEquals("突破失败", p)
    }

    @Test fun `量能平稳无形态`() {
        val cs = listOf(candle(100.0, 100.1, 100.2, 99.9, 100.0), candle(100.1, 100.2, 100.3, 100.0, 100.0))
        val (p, _) = VolumePriceClassifier.classify(cs, volRatio = 1.0, atr = 1.0, support = 99.5, resistance = 101.0, ema20 = null)
        assertEquals("", p)
    }

    /* ---------- EvidenceEngine ---------- */

    private fun sop(direction: String, entry: Double = 100.0, stop: Double = 97.0, price: Double = 100.0, volumePattern: String = ""): SymbolOpportunity {
        val a = Analysis(
            symbol = "TESTUSDT", market = "SPOT", timeframe = "15m", price = price, changePct = 0.0,
            rsi14 = 50.0, ema20 = 99.0, ema50 = 98.0, direction = direction, score = 70, confidence = 70,
            reason = "", candleTime = 0L, entry = entry, stop = stop, atr = 1.0,
            volumePattern = volumePattern
        )
        return SymbolOpportunity(
            symbol = "TESTUSDT", market = "SPOT", direction = direction, score = 70, confidence = 70,
            price = price, changePct = 0.0, perTimeframe = mapOf("15m" to a), rep = a,
            resonanceCount = 0, oppositeCount = 0
        )
    }

    @Test fun `反向量价形态触发否决`() {
        val (sig, veto) = EvidenceEngine.signal(sop("LONG", volumePattern = "放量下跌").rep)
        assertTrue(veto)
        val ev = EvidenceEngine.evaluate(sop("LONG", volumePattern = "放量下跌"), 100.0, null, null)
        assertEquals(0, ev.signal)
    }

    @Test fun `顺向量价形态加分不否决`() {
        val (_, veto) = EvidenceEngine.signal(sop("LONG", volumePattern = "缩量回踩").rep)
        assertTrue(!veto)
    }

    @Test fun `证据总分加权正确区间`() {
        val ev = EvidenceEngine.evaluate(sop("LONG"), 100.0, 20 to 0.6, 0.6)
        assertTrue(ev.score in 0..100)
        assertTrue(ev.detail.size == 4)
    }

    @Test fun `分档R口径止盈定价`() {
        // v5.0.17 统一 R 口径：riskReward = 本次所选档位的 R 倍数（稳健 2R / 进取 3R），
        // 目标 = entry ± riskReward × 实际风险距离（|entry-stop|）；不再写死 3R。
        val fused = OpportunityFusion.fuse("TESTUSDT", "SPOT", mapOf("15m" to sop("LONG").rep))!!
        val r = fused.rep.riskReward
        assertTrue(
            "R 倍数只能是稳健 ${TargetTier.DEFAULT_STEADY_R} 或进取 ${TargetTier.DEFAULT_AGGR_R}，实际 $r",
            r == TargetTier.DEFAULT_STEADY_R || r == TargetTier.DEFAULT_AGGR_R
        )
        val risk = fused.rep.entry - fused.rep.stop
        assertTrue("风险距离必须为正", risk > 0)
        assertEquals(fused.rep.entry + r * risk, fused.rep.target, 1e-6)
        assertEquals(
            if (r == TargetTier.DEFAULT_AGGR_R) TargetTier.AGGRESSIVE else TargetTier.STEADY,
            fused.tierHint
        )
    }

    @Test fun `智能失效条件判定`() {
        val rec = ReviewRecord(id = "k", symbol = "TESTUSDT", market = "SPOT", timeframe = "15m",
            direction = "LONG", entry = 100.0, stop = 97.0, target = 109.0, score = 70, alertedAt = 0L)
        val ok = Confirmation(key = "k", symbol = "TESTUSDT", market = "SPOT", direction = "LONG",
            repTimeframe = "15m", entryPrice = 100.0, atr = 1.0, windowBars = 4, thresholdAtr = 0.5,
            startedAt = 0L, startCandleTime = 0L, status = "未确认", reverseMaxAtr = 1.3, resolvedAt = 1L, resolvedPrice = 97.5)
        assertEquals("invalid", ReviewEngine.smartInvalidate(rec, ok).verdict)
        // 反向不足 1.2×ATR 不失效
        val weak = ok.copy(reverseMaxAtr = 0.8)
        assertEquals("open", ReviewEngine.smartInvalidate(rec, weak).verdict)
    }
}
