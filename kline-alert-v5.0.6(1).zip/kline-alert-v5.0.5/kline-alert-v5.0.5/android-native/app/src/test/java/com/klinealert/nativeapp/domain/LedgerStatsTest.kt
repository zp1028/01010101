package com.klinealert.nativeapp.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** v5.0.18 [LedgerStats] 工作台统计图表引擎测试：汇总口径、资金曲线、R 分布、两档与原因分组。 */
class LedgerStatsTest {

    private val S = LedgerStats

    private fun sample(
        tier: String,
        reason: String,
        r: Double,
        win: Boolean,
        usdt: Double,
        at: Long,
        symbol: String = "BTCUSDT"
    ) = LedgerStats.Sample(tier = tier, reason = reason, realizedR = r, win = win, pnlUsdt = usdt, closedAt = at, symbol = symbol)

    /** 3 稳健（2 胜 1 负）+ 1 进取（胜）：总 R = 2+2-1+3 = 6。 */
    private fun mixed() = listOf(
        sample(S.TIER_STEADY, S.R_TARGET, 2.0, true, 4.0, 100),
        sample(S.TIER_STEADY, S.R_TARGET, 2.0, true, 4.0, 200),
        sample(S.TIER_STEADY, S.R_STOP, -1.0, false, -2.0, 300),
        sample(S.TIER_AGGRESSIVE, S.R_TARGET, 3.0, true, 6.0, 400)
    )

    @Test fun `空台账返回空图表`() {
        val c = S.build(emptyList())
        assertTrue(c.empty)
        assertEquals(0, c.count)
        assertEquals(0.0, c.winRate, 1e-9)
        assertEquals(listOf(0.0), c.equity)
        assertEquals(2, c.tiers.size)
        assertEquals(S.R_BINS.size, c.rHistogram.size)
        assertTrue(c.reasons.isEmpty())
        assertEquals(0.0, c.steadyShare, 1e-9)
        assertEquals(0.0, c.maxDrawdownR, 1e-9)
    }

    @Test fun `汇总口径胜率总R期望盈亏比`() {
        val c = S.build(mixed())
        assertFalse(c.empty)
        assertEquals(4, c.count)
        assertEquals(3, c.wins)
        assertEquals(1, c.losses)
        assertEquals(0.75, c.winRate, 1e-9)
        assertEquals(6.0, c.totalR, 1e-9)
        assertEquals(1.5, c.avgR, 1e-9)
        assertEquals(1.5, c.expectancyR, 1e-9)
        assertEquals(12.0, c.totalPnlUsdt, 1e-9)
        assertEquals(7.0 / 3.0, c.avgWinR, 1e-9)
        assertEquals(-1.0, c.avgLossR, 1e-9)
        assertEquals(7.0 / 3.0, c.payoffRatio, 1e-9)
        assertEquals(3.0, c.bestR, 1e-9)
        assertEquals(-1.0, c.worstR, 1e-9)
    }

    @Test fun `两档分组与稳健占比`() {
        val c = S.build(mixed())
        val steady = c.tiers.first { it.key == S.TIER_STEADY }
        val aggr = c.tiers.first { it.key == S.TIER_AGGRESSIVE }
        assertEquals(3, steady.count)
        assertEquals(2, steady.wins)
        assertEquals(3.0, steady.totalR, 1e-9)
        assertEquals(2.0 / 3.0, steady.winRate, 1e-9)
        assertEquals(1.0, steady.avgR, 1e-9)
        assertEquals(1, aggr.count)
        assertEquals(1, aggr.wins)
        assertEquals(3.0, aggr.totalR, 1e-9)
        assertEquals(0.75, c.steadyShare, 1e-9)
        assertEquals("稳健", S.tierLabel(S.TIER_STEADY))
        assertEquals("进取", S.tierLabel(S.TIER_AGGRESSIVE))
    }

    @Test fun `平仓原因分组按固定顺序且剔除未知`() {
        val c = S.build(
            mixed() + listOf(
                sample(S.TIER_STEADY, S.R_ROTATE, 0.2, true, 0.4, 500),
                sample(S.TIER_STEADY, "SOMETHING_ELSE", 0.1, true, 0.2, 600)
            )
        )
        assertEquals(3, c.reasons.size)
        assertEquals(S.R_TARGET, c.reasons[0].key)
        assertEquals(3, c.reasons[0].count)
        assertEquals(7.0, c.reasons[0].totalR, 1e-9)
        assertEquals(S.R_STOP, c.reasons[1].key)
        assertEquals(1, c.reasons[1].count)
        assertEquals(S.R_ROTATE, c.reasons[2].key)
        assertEquals("满仓轮换", c.reasons[2].label)
        // 未知原因不计入原因分组，但仍计入总笔数与总 R
        assertEquals(6, c.count)
        assertEquals(6.3, c.totalR, 1e-9)
    }

    @Test fun `资金曲线按平仓时间升序累计`() {
        val c = S.build(listOf(
            sample(S.TIER_STEADY, S.R_TARGET, 1.0, true, 2.0, 300),
            sample(S.TIER_STEADY, S.R_STOP, -1.0, false, -2.0, 100),
            sample(S.TIER_STEADY, S.R_TARGET, 2.0, true, 4.0, 200)
        ))
        assertEquals(listOf(0.0, -1.0, 1.0, 2.0), c.equity)
        assertEquals(2.0, c.equity.last(), 1e-9)
        assertEquals(1.0, c.maxDrawdownR, 1e-9)
    }

    @Test fun `最大回撤取峰值到谷底最大跌幅`() {
        val c = S.build(listOf(
            sample(S.TIER_STEADY, S.R_TARGET, 2.0, true, 4.0, 1),
            sample(S.TIER_STEADY, S.R_TARGET, 1.0, true, 2.0, 2),
            sample(S.TIER_STEADY, S.R_STOP, -1.0, false, -2.0, 3),
            sample(S.TIER_STEADY, S.R_STOP, -1.0, false, -2.0, 4)
        ))
        assertEquals(listOf(0.0, 2.0, 3.0, 2.0, 1.0), c.equity)
        assertEquals(2.0, c.maxDrawdownR, 1e-9)
    }

    @Test fun `最大回撤纯函数边界`() {
        assertEquals(0.0, S.maxDrawdown(emptyList()), 1e-9)
        assertEquals(0.0, S.maxDrawdown(listOf(0.0)), 1e-9)
        assertEquals(0.0, S.maxDrawdown(listOf(0.0, 1.0, 2.0)), 1e-9)
        assertEquals(3.0, S.maxDrawdown(listOf(0.0, 3.0, 0.0)), 1e-9)
    }

    @Test fun `R分布固定区间边界归入上界`() {
        val c = S.build(listOf(-1.5, -1.0, -0.5, 0.0, 0.5, 1.0, 2.0, 3.0, 4.0).mapIndexed { i, r ->
            sample(S.TIER_STEADY, S.R_TARGET, r, r > 0, r, (i + 1).toLong())
        })
        val counts = c.rHistogram.associate { it.label to it.count }
        assertEquals(2, counts["≤-1R"])
        assertEquals(1, counts["-1~-0.5R"])
        assertEquals(1, counts["-0.5~0R"])
        assertEquals(1, counts["0~0.5R"])
        assertEquals(1, counts["0.5~1R"])
        assertEquals(1, counts["1~2R"])
        assertEquals(1, counts["2~3R"])
        assertEquals(1, counts["≥3R"])
        assertEquals(9, c.rHistogram.sumOf { it.count })
        assertEquals(9, c.count)
    }

    @Test fun `无亏损样本时盈亏比不可算返回0`() {
        val c = S.build(listOf(
            sample(S.TIER_AGGRESSIVE, S.R_TARGET, 3.0, true, 6.0, 1),
            sample(S.TIER_AGGRESSIVE, S.R_REVERSE, 1.2, true, 2.4, 2)
        ))
        assertEquals(0.0, c.payoffRatio, 1e-9)
        assertEquals(0.0, c.avgLossR, 1e-9)
        assertEquals(1.0, c.winRate, 1e-9)
        assertEquals(0.0, c.maxDrawdownR, 1e-9)
    }

    @Test fun `平仓原因中文标签`() {
        assertEquals("止盈", S.reasonLabel(S.R_TARGET))
        assertEquals("止损", S.reasonLabel(S.R_STOP))
        assertEquals("保本/移动止损", S.reasonLabel(S.R_BREAKEVEN))
        assertEquals("结构反转", S.reasonLabel(S.R_REVERSE))
        assertEquals("时间止损", S.reasonLabel(S.R_TIMEOUT))
        assertEquals("满仓轮换", S.reasonLabel(S.R_ROTATE))
        assertEquals("手动平仓", S.reasonLabel(S.R_MANUAL))
        assertEquals("未知", S.reasonLabel(""))
        assertEquals("CUSTOM", S.reasonLabel("CUSTOM"))
    }
}
