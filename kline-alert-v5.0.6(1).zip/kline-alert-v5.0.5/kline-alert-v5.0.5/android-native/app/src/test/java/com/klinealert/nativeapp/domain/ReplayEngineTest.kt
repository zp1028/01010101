package com.klinealert.nativeapp.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ReplayEngineTest {

    /** 上涨漂移 + 阶段浅回调 + 高斯影线（固定种子，可复现），贴近真实趋势形态。 */
    private fun trendCandles(n: Int): List<Candle> {
        val rnd = java.util.Random(7)
        val list = mutableListOf<Candle>()
        var p = 100.0
        for (i in 0 until n) {
            val pullback = if (i % 30 in 24..27) -0.55 else 0.0
            val delta = 0.18 + pullback + rnd.nextGaussian() * 0.28
            val open = p
            val close = p + delta
            val rng = kotlin.math.abs(delta) + 0.15 + rnd.nextDouble() * 0.35
            val high = maxOf(open, close) + rng * 0.6
            val low = minOf(open, close) - rng * 0.6
            list += Candle(i * 900000L, open, high, low, close, 100.0 + rnd.nextDouble() * 60, i * 900000L + 899999)
            p = close
        }
        return list
    }

    /** 前 openIndex 根（含开仓根，中性平盘），after 从开仓根下一根开始（Triple Barrier 判定起点）。 */
    private fun withAfter(openIndex: Int, after: List<Candle>): List<Candle> {
        val base = (0..openIndex).map {
            Candle(it.toLong(), 100.0, 100.3, 99.7, 100.0, 100.0, it.toLong())
        }
        val tail = after.mapIndexed { idx, c ->
            c.copy(openTime = (openIndex + 1 + idx).toLong(), closeTime = (openIndex + 1 + idx).toLong())
        }
        return base + tail
    }
    private fun bar(open: Double, close: Double, high: Double, low: Double) =
        Candle(0L, open, high, low, close, 100.0, 0L)

    // ---------- 双臂回放（管道接线 + 统计自洽） ----------

    @Test
    fun 双臂回放_统计自洽且价值区在趋势中更优() {
        val cs = trendCandles(400)
        val rep = ReplayEngine.run("T", "test", "15m", cs)
        assertEquals(400, rep.bars)
        // 统计自洽：totalR == 逐笔 rMultiple 之和
        assertEquals(rep.value.totalR, rep.value.trades.sumOf { it.rMultiple }, 1e-9)
        assertEquals(rep.market.totalR, rep.market.trades.sumOf { it.rMultiple }, 1e-9)
        assertTrue(rep.value.winRate in 0.0..1.0)
        // 两臂均应产生交易
        assertTrue("现价组应有交易", rep.market.trades.isNotEmpty())
        assertTrue("价值区组应有交易", rep.value.trades.isNotEmpty())
        // 强上涨趋势中，价值区逻辑不应亏损，且优于现价（固定种子可复现）
        assertTrue("价值区总R应>0，实际 ${rep.value.totalR}", rep.value.totalR > 0)
        assertTrue("价值区应优于现价：value=${rep.value.totalR} market=${rep.market.totalR}",
            rep.edgeR > 0)
        println("价值区：${rep.value.trades.size}笔 胜率${(rep.value.winRate * 100).toInt()}% 总R${"%.2f".format(rep.value.totalR)}；" +
            "现价：${rep.market.trades.size}笔 胜率${(rep.market.winRate * 100).toInt()}% 总R${"%.2f".format(rep.market.totalR)}；否决${rep.valueVetoed}")
    }

    @Test
    fun 样本不足_标注不可靠() {
        val rep = ReplayEngine.run("T", "test", "15m", trendCandles(100))
        assertTrue(rep.note.contains("样本不足"))
    }

    @Test
    fun ReplayRow映射_字段与报告一致() {
        val rep = ReplayEngine.run("T", "test", "15m", trendCandles(400))
        val row = ReplayRow.of("T", "test", "15m", rep)
        assertEquals(rep.value.trades.size, row.valueTrades)
        assertEquals(rep.market.trades.size, row.marketTrades)
        assertEquals(rep.bars, row.bars)
        assertEquals(rep.edgeR, row.edgeR, 1e-9)
        assertEquals(rep.winRateDelta, row.winRateDelta, 1e-9)
        assertEquals(rep.valueVetoed, row.vetoed)
    }

    // ---------- Triple Barrier 结算（确定性） ----------

    @Test
    fun 做多_触及止盈_TARGET且1点5R() {
        val cs = withAfter(10, listOf(bar(100.0, 102.0, 103.1, 99.9)))
        val t = ReplayEngine.resolve(cs, 10, 100.0, 1.0, true, 2.0, 3.0)
        assertEquals(ReplayTrade.TARGET, t.outcome)
        assertEquals(1.5, t.rMultiple, 1e-9)   // 止盈 3ATR / 风险 2ATR = 1.5R
    }

    @Test
    fun 做多_触及止损_STOP且亏1R() {
        val cs = withAfter(10, listOf(bar(100.0, 98.5, 100.5, 97.9)))
        val t = ReplayEngine.resolve(cs, 10, 100.0, 1.0, true, 2.0, 3.0)
        assertEquals(ReplayTrade.STOP, t.outcome)
        assertEquals(-1.0, t.rMultiple, 1e-9)
    }

    @Test
    fun 同根同时触止盈止损_保守判止损() {
        val cs = withAfter(10, listOf(bar(100.0, 100.5, 103.1, 97.9)))
        val t = ReplayEngine.resolve(cs, 10, 100.0, 1.0, true, 2.0, 3.0)
        assertEquals(ReplayTrade.STOP, t.outcome)
    }

    @Test
    fun 做空_触及止盈_TARGET() {
        val cs = withAfter(10, listOf(bar(100.0, 98.0, 100.5, 96.9)))
        val t = ReplayEngine.resolve(cs, 10, 100.0, 1.0, false, 2.0, 3.0)
        assertEquals(ReplayTrade.TARGET, t.outcome)
    }

    @Test
    fun 超时未触屏障_垂直屏障TIMEOUT按收盘结算() {
        // 16 根都在 98~103 之间徘徊，收在 100.5
        val after = (1..16).map { bar(100.0, 100.5, 100.9, 99.1) }
        val cs = withAfter(10, after)
        val t = ReplayEngine.resolve(cs, 10, 100.0, 1.0, true, 2.0, 3.0)
        assertEquals(ReplayTrade.TIMEOUT, t.outcome)
        assertEquals(16, t.barsHeld)
        assertEquals(0.25, t.rMultiple, 1e-9)   // (100.5-100)/2ATR = 0.25R
    }
}
