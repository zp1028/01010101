package com.klinealert.nativeapp.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** v3.8 待命单：三重门锁 + 触发/失效/过期/反悔 */
class PendingSetupTest {

    private fun sop(direction: String = "LONG", price: Double = 100.0, support: Double? = 99.5,
                    resistance: Double? = 102.0, stop: Double = 96.0, atr: Double = 1.0,
                    volumePattern: String = "", states: List<IndicatorState> = emptyList(),
                    candleTime: Long = System.currentTimeMillis()): SymbolOpportunity {
        val a = Analysis(
            symbol = "TESTUSDT", market = "SPOT", timeframe = "15m", price = price, changePct = 0.0,
            rsi14 = 50.0, ema20 = 100.0, ema50 = 99.0, direction = direction, score = 70, confidence = 70,
            reason = "", candleTime = candleTime, entry = price, stop = stop, atr = atr,
            support = support, resistance = resistance, volumePattern = volumePattern, states = states
        )
        return SymbolOpportunity(symbol = "TESTUSDT", market = "SPOT", direction = direction, score = 70,
            confidence = 70, price = price, changePct = 0.0, perTimeframe = mapOf("15m" to a), rep = a,
            resonanceCount = 0, oppositeCount = 0)
    }

    private val now = 1_700_000_000_000L

    @Test fun `做多触发价在支撑上方 02ATR`() {
        val st = PendingSetupEngine.build(sop(), 100.0, null, null, null, now)!!
        assertEquals(99.5 + 0.2 * 1.0, st.triggerPrice, 1e-6)
        assertTrue(st.target3R > st.triggerPrice)
    }

    @Test fun `做空触发价在压力下方 02ATR 且止损缓冲加宽`() {
        val s = sop(direction = "SHORT", support = null, resistance = 102.0, stop = 104.0)
        val st = PendingSetupEngine.build(s, 101.0, null, null, null, now)!!
        assertEquals(102.0 - 0.2, st.triggerPrice, 1e-6)
        // 做空止损被外推（缓冲更宽），距触发价 > 原始 2.0
        assertTrue(kotlin.math.abs(st.stop - st.triggerPrice) > 2.0)
        assertTrue(st.target3R < st.triggerPrice)
    }

    @Test fun `做空窗口比做多短`() {
        val l = PendingSetupEngine.windowOf("15m", "LONG", now)
        val s = PendingSetupEngine.windowOf("15m", "SHORT", now)
        assertTrue(s < l)
    }

    @Test fun `价格到位先进入等回踩确认`() {
        val st = PendingSetupEngine.build(sop(), 100.0, null, null, null, now)!!  // 触发价 99.7
        val armed = PendingSetupEngine.onTick(st, 99.6, now + 1000)
        assertEquals(PendingSetup.ARMED, armed.status)
        assertEquals(now + 1000, armed.armedAt)
    }

    @Test fun `等回踩确认后触发可入场`() {
        val st = PendingSetupEngine.build(sop(), 100.0, null, null, null, now)!!  // 触发价 99.7, ATR 1.0
        val armed = PendingSetupEngine.onTick(st, 99.6, now + 1000)
        assertEquals(PendingSetup.ARMED, armed.status)
        // 回踩到触发价 ±0.5×ATR = 99.2~100.2 内 → 确认可入场
        val trig = PendingSetupEngine.onTick(armed, 99.7, now + 2000)
        assertEquals(PendingSetup.TRIGGERED, trig.status)
    }

    @Test fun `等回踩期间顺势走远则作废避免追高`() {
        val st = PendingSetupEngine.build(sop(), 100.0, null, null, null, now)!!  // LONG 触发价 99.7, ATR 1.0
        val armed = PendingSetupEngine.onTick(st, 99.6, now + 1000)
        // 顺势向上冲出 >1.2×ATR（99.7+1.2=100.9 以上）→ 追高保护作废
        val gone = PendingSetupEngine.onTick(armed, 101.5, now + 2000)
        assertEquals(PendingSetup.EXPIRED, gone.status)
    }

    @Test fun `等回踩确认超时作废`() {
        val st = PendingSetupEngine.build(sop(), 100.0, null, null, null, now)!!  // 15m，回踩窗口 3 根 = 45min
        val armed = PendingSetupEngine.onTick(st, 99.6, now + 1000)
        val late = PendingSetupEngine.onTick(armed, 100.0, now + 60 * 60_000L)  // 1h 后，价格在容差内但已超时
        assertEquals(PendingSetup.EXPIRED, late.status)
    }

    @Test fun `等回踩期间破失效价作废`() {
        val st = PendingSetupEngine.build(sop(stop = 96.0), 100.0, null, null, null, now)!!
        val armed = PendingSetupEngine.onTick(st, 99.6, now + 1000)
        assertEquals(PendingSetup.ARMED, armed.status)
        val dead = PendingSetupEngine.onTick(armed, 95.0, now + 2000)
        assertEquals(PendingSetup.EXPIRED, dead.status)
    }

    @Test fun `未到位保持待命并给出缺哪道门`() {
        val st = PendingSetupEngine.build(sop(price = 100.0, support = 98.0), 100.0, null, null, null, now)!!
        // 价格 100 距触发价 98.2 = 1.8 > 0.5×ATR → 位置门未过
        assertFalse(st.gatePosition)
        assertEquals("等价格到位", st.missingGate)
        assertEquals(PendingSetup.PENDING, st.status)
    }

    @Test fun `破失效价作废`() {
        val st = PendingSetupEngine.build(sop(stop = 96.0), 100.0, null, null, null, now)!!
        val dead = PendingSetupEngine.onTick(st, 95.0, now + 1000)
        assertEquals(PendingSetup.EXPIRED, dead.status)
    }

    @Test fun `窗口到期过期`() {
        val st = PendingSetupEngine.build(sop(), 100.0, null, null, null, now)!!
        val late = PendingSetupEngine.onTick(st, 100.0, st.expireAt + 1)
        assertEquals(PendingSetup.EXPIRED, late.status)
    }

    @Test fun `触发后反悔机制`() {
        val st = PendingSetupEngine.build(sop(), 100.0, null, null, null, now)!!  // LONG 触发价 99.7
        val armed = PendingSetupEngine.onTick(st, 99.6, now + 1000)
        val trig = PendingSetupEngine.onTick(armed, 99.7, now + 2000)
        assertEquals(PendingSetup.TRIGGERED, trig.status)
        // 触发后 1 根K线内出现放量下跌 → 反悔
        val regret = PendingSetupEngine.onTick(trig, 99.5, now + 60_000, volumePattern = "放量下跌")
        assertEquals(PendingSetup.REGRET, regret.status)
    }

    @Test fun `新鲜指标交叉通过信号门`() {
        val states = listOf(IndicatorState("MACD", "多头延续", "金叉 发生于 1 根K线前，当前多头延续"))
        val st = PendingSetupEngine.build(sop(states = states), 100.0, null, null, null, now)!!
        assertTrue(st.gateSignal)
    }

    // ── v4.2 持久化：所有字段可 copy 往返（LocalStore 逐列存取依赖字段完整性）
    @Test fun `待命单全字段可完整往返用于持久化`() {
        val st = PendingSetupEngine.build(sop(), 100.0, null, null, null, now)!!
        val armed = PendingSetupEngine.onTick(st, 99.6, now + 1000)
        val trig = PendingSetupEngine.onTick(armed, 99.7, now + 2000)
        val restored = trig.copy()  // 模拟从数据库逐列重建后的对象
        assertEquals(trig.key, restored.key)
        assertEquals(trig.triggerPrice, restored.triggerPrice, 1e-9)
        assertEquals(trig.invalidPrice, restored.invalidPrice, 1e-9)
        assertEquals(trig.stop, restored.stop, 1e-9)
        assertEquals(trig.target3R, restored.target3R, 1e-9)
        assertEquals(trig.armedAt, restored.armedAt)
        assertEquals(trig.armedExtreme, restored.armedExtreme, 1e-9)
        assertEquals(PendingSetup.TRIGGERED, restored.status)
        assertTrue(trig.armedAt > 0L)   // 已记录 ARMED 时刻
    }

    @Test fun `ARMED 状态计入 active 可被恢复`() {
        val st = PendingSetupEngine.build(sop(), 100.0, null, null, null, now)!!
        val armed = PendingSetupEngine.onTick(st, 99.6, now + 1000)
        assertEquals(PendingSetup.ARMED, armed.status)
        assertTrue(armed.active)   // 启动恢复时 ARMED 单不应被丢弃
    }

    // ── v5.0.9 全局乘数：无显式止损时按乘数定价 ──
    @Test fun `默认乘数与自动作战一致`() {
        // sop(stop=0) → 走乘数：默认止损 2×ATR / 止盈 3×风险（原 1.5×ATR 已统一为 2×ATR）
        val st = PendingSetupEngine.build(sop(stop = 0.0), 100.0, null, null, null, now)!!
        val trigger = 99.5 + 0.2 * 1.0          // 99.7
        assertEquals(trigger - 2.0 * 1.0, st.stop, 1e-9)     // 97.7
        assertEquals(trigger + 3.0 * 2.0, st.target3R, 1e-9) // 105.7 = 3×风险(2.0)
    }

    @Test fun `自定义乘数改变止损止盈距离`() {
        val st = PendingSetupEngine.build(sop(stop = 0.0), 100.0, null, null, null, now,
            stopMult = 1.5, targetMult = 4.0)!!
        val trigger = 99.5 + 0.2 * 1.0           // 99.7
        assertEquals(trigger - 1.5 * 1.0, st.stop, 1e-9)     // 98.2
        val risk = 1.5                            // 距止损 1.5
        assertEquals(trigger + 4.0 * risk, st.target3R, 1e-9) // 105.7
    }

    @Test fun `做空乘数镜像定价`() {
        val s = sop(direction = "SHORT", support = null, resistance = 102.0, stop = 0.0)
        val st = PendingSetupEngine.build(s, 101.0, null, null, null, now, stopMult = 2.0, targetMult = 5.0)!!
        val trigger = 102.0 - 0.2               // 101.8
        val rawStop = trigger + 2.0 * 1.0       // 103.8
        val stopAdj = rawStop + kotlin.math.abs(rawStop - trigger) * 0.25   // 做空缓冲 ×1.25
        assertEquals(stopAdj, st.stop, 1e-9)
        val risk = stopAdj - trigger
        assertEquals(trigger - 5.0 * risk, st.target3R, 1e-9)
    }
}
