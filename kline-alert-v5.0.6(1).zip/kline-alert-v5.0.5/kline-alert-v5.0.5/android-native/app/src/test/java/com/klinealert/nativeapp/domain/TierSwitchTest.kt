package com.klinealert.nativeapp.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** v5.0.18 [TargetTier] UI 接入层测试：档位标签、单笔切档（目标重算）、参数校验与摘要。 */
class TierSwitchTest {

    private val T = TargetTier
    private val cfg = TargetTier.TierConfig()

    // ---- 标签 ----

    @Test fun `档位标签稳健2R与进取3R`() {
        assertEquals("稳健2R", T.label(T.STEADY, 2.0))
        assertEquals("进取3R", T.label(T.AGGRESSIVE, 3.0))
        assertEquals("稳健2.5R", T.label(T.STEADY, 2.5))
    }

    @Test fun `flip在两档之间切换`() {
        assertEquals(T.AGGRESSIVE, T.flip(T.STEADY))
        assertEquals(T.STEADY, T.flip(T.AGGRESSIVE))
        // 未知档位视为稳健 → 翻到进取
        assertEquals(T.AGGRESSIVE, T.flip("WEIRD"))
    }

    // ---- 单笔切档 ----

    @Test fun `稳健切进取按风险距离重算目标价`() {
        // 入场 100、止损 98、stopMult 2×ATR(1) → 风险 2 → 进取 3R = 106
        val sw = T.planSwitch(T.STEADY, "LONG", 100.0, 98.0, atr = 1.0, stopMult = 2.0, cfg = cfg)
        assertTrue(sw.allowed)
        assertEquals(T.AGGRESSIVE, sw.tier)
        assertEquals(3.0, sw.targetR, 1e-9)
        assertEquals(106.0, sw.target, 1e-9)
        assertEquals("进取3R", sw.label)
        assertFalse(sw.breakEvenDone)
    }

    @Test fun `进取切稳健做空镜像`() {
        // 空单：入场 100、止损 102 → 风险 2 → 稳健 2R = 96
        val sw = T.planSwitch(T.AGGRESSIVE, "SHORT", 100.0, 102.0, atr = 1.0, stopMult = 2.0, cfg = cfg)
        assertTrue(sw.allowed)
        assertEquals(T.STEADY, sw.tier)
        assertEquals(2.0, sw.targetR, 1e-9)
        assertEquals(96.0, sw.target, 1e-9)
        assertEquals("稳健2R", sw.label)
    }

    @Test fun `ATR缺失时回退入场到止损距离`() {
        val sw = T.planSwitch(T.STEADY, "LONG", 100.0, 98.0, atr = 0.0, stopMult = 2.0, cfg = cfg)
        assertTrue(sw.allowed)
        assertEquals(106.0, sw.target, 1e-9)
    }

    @Test fun `风险距离无效时拒绝切档`() {
        val sw = T.planSwitch(T.STEADY, "LONG", 100.0, 100.0, atr = 0.0, stopMult = 2.0, cfg = cfg)
        assertFalse(sw.allowed)
        assertTrue(sw.reason.contains("风险距离"))
        assertEquals(0.0, sw.target, 1e-9)
        assertEquals(T.AGGRESSIVE, sw.tier)
    }

    @Test fun `切进取重置保本标记`() {
        val sw = T.planSwitch(T.STEADY, "LONG", 100.0, 98.0, atr = 1.0, breakEvenDone = true, cfg = cfg)
        assertEquals(T.AGGRESSIVE, sw.tier)
        assertFalse(sw.breakEvenDone)
    }

    @Test fun `切稳健保留已发生的保本上移`() {
        val sw = T.planSwitch(T.AGGRESSIVE, "LONG", 100.0, 98.0, atr = 1.0, breakEvenDone = true, cfg = cfg)
        assertEquals(T.STEADY, sw.tier)
        assertTrue(sw.breakEvenDone)
    }

    @Test fun `自定义参数影响切档目标`() {
        val custom = TargetTier.TierConfig(steadyR = 2.5, aggrR = 4.0)
        val toAggr = T.planSwitch(T.STEADY, "LONG", 100.0, 98.0, atr = 1.0, cfg = custom)
        assertEquals(4.0, toAggr.targetR, 1e-9)
        assertEquals(108.0, toAggr.target, 1e-9)
        val toSteady = T.planSwitch(T.AGGRESSIVE, "LONG", 100.0, 98.0, atr = 1.0, cfg = custom)
        assertEquals(2.5, toSteady.targetR, 1e-9)
        assertEquals(105.0, toSteady.target, 1e-9)
    }

    // ---- 参数校验 ----

    @Test fun `sanitize夹紧越界参数`() {
        val bad = TargetTier.TierConfig(
            steadyR = 0.2, aggrR = 99.0, breakEvenR = -3.0,
            minScore = 5, momentumVol = 0.1, adxStrong = 999.0
        )
        val s = T.sanitize(bad)
        assertEquals(T.MIN_STEADY_R, s.steadyR, 1e-9)
        assertEquals(T.MAX_AGGR_R, s.aggrR, 1e-9)
        assertEquals(T.MIN_BREAK_EVEN_R, s.breakEvenR, 1e-9)
        assertEquals(T.MIN_SCORE_RANGE, s.minScore)
        assertEquals(T.MIN_MOMENTUM_VOL, s.momentumVol, 1e-9)
        assertEquals(T.MAX_ADX_STRONG, s.adxStrong, 1e-9)
    }

    @Test fun `sanitize不动合法参数`() {
        val ok = TargetTier.TierConfig(steadyR = 1.5, aggrR = 4.0, breakEvenR = 2.5, minScore = 80, momentumVol = 1.5, adxStrong = 26.0)
        assertEquals(ok, T.sanitize(ok))
    }

    @Test fun `warning提示稳健不小于进取`() {
        assertNull(T.warning(TargetTier.TierConfig()))
        assertNotNull(T.warning(TargetTier.TierConfig(steadyR = 3.0, aggrR = 3.0)))
        assertNotNull(T.warning(TargetTier.TierConfig(steadyR = 4.0, aggrR = 3.0)))
        // 保本线 ≥ 进取目标同样提醒
        assertNotNull(T.warning(TargetTier.TierConfig(steadyR = 1.0, aggrR = 2.0, breakEvenR = 2.0)))
    }

    @Test fun `summary包含模式与三组参数`() {
        val s = T.summary(TargetTier.TierConfig())
        assertTrue(s.contains("自动"))
        assertTrue(s.contains("稳健 2R"))
        assertTrue(s.contains("进取 3R"))
        assertTrue(s.contains("2R 保本"))
        assertEquals(true, T.summary(TargetTier.TierConfig(mode = T.MODE_FORCE_AGGRESSIVE)).contains("全部进取"))
    }
}
