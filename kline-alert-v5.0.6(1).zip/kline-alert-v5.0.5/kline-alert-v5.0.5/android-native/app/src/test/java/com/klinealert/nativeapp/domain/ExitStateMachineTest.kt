package com.klinealert.nativeapp.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** v5.0.16 [ExitStateMachine] 出场/持仓状态机测试：延续、阶梯移动止损、否决、时间止损、做空镜像。 */
class ExitStateMachineTest {

    private val E = ExitStateMachine
    // v5.0.17 起 ExitConfig 默认 tier=STEADY（2R 落袋），本类测的"到目标后延续"属进取档行为
    private val cfg = ExitStateMachine.ExitConfig(tier = TargetTier.AGGRESSIVE)

    // ---- helpers ----
    private fun ana(
        price: Double, atr: Double = 2.0, rsi14: Double? = 60.0,
        macdHist: Double? = 0.5, kdjK: Double? = 60.0, kdjD: Double? = 50.0,
        volRatio: Double = 1.0, support: Double? = null, resistance: Double? = null,
        direction: String = "LONG"
    ) = Analysis(
        symbol = "T", market = "test", timeframe = "15m", price = price, changePct = 0.0,
        rsi14 = rsi14, ema20 = price * 0.99, ema50 = price * 0.95, direction = direction,
        score = 80, reason = "", candleTime = 0L, atr = atr, atrPct = 0.02,
        macdHist = macdHist, kdjK = kdjK, kdjD = kdjD,
        support = support, resistance = resistance, volRatio = volRatio
    )

    private fun bar(o: Double, h: Double, l: Double, c: Double, vol: Double = 1000.0) =
        Candle(0L, o, h, l, c, vol, 900000L)

    private fun swing(p: Double, high: Boolean) =
        SwingPoint(0, p, if (high) SwingPoint.HIGH else SwingPoint.LOW)

    private fun struct(
        trend: String, recent: String, valid: String = StructureEvent.CONFIRMED,
        swings: List<SwingPoint> = emptyList(),
        lastLow: Double? = null, lastHigh: Double? = null
    ) = StructureState(
        trend = trend, swings = swings,
        lastSwingHigh = lastHigh?.let { swing(it, true) },
        lastSwingLow = lastLow?.let { swing(it, false) },
        event = StructureEvent(recent, 100.0, 0, 100.0, valid),
        recentEvent = StructureEvent(recent, 100.0, 0, 100.0, valid)
    )

    // 做多：entry100 / stop96(2ATR) / target106(3ATR)，atr=2
    private val longCfg = cfg

    // ---- 基础：未到目标 → HOLD ----
    @Test
    fun 未到目标_继续持有() {
        val d = E.evaluate(
            "LONG", 100.0, 96.0, 106.0, livePrice = 104.0,
            a = ana(104.0), structure = struct(StructureEngine.UP, StructureEvent.BOS_UP),
            latest = bar(103.0, 104.2, 102.9, 104.0), trailCount = 0, barsSinceTrail = 3,
            bestPrice = 104.2, cfg = longCfg
        )
        assertEquals(E.ACTION_HOLD, d.action)
    }

    // ---- 到目标 + 强势顺势结构 → 首次延续，止损上移（≥保本），目标上移 ----
    @Test
    fun 到目标_结构强势_首次延续_移动止损上移() {
        val s = struct(
            StructureEngine.UP, StructureEvent.BOS_UP,
            swings = listOf(swing(102.0, false), swing(112.0, true)),
            lastLow = 102.0, lastHigh = 112.0
        )
        // bestPrice=106.8 → 吊灯 106.8-3=103.8；结构位 102-0.4=101.6；保本 100.05 → 取 103.8
        val d = E.evaluate(
            "LONG", 100.0, 96.0, 106.0, livePrice = 106.5,
            a = ana(106.5, resistance = 120.0), structure = s,
            latest = bar(105.5, 106.8, 105.3, 106.5), trailCount = 0, barsSinceTrail = 10,
            bestPrice = 106.8, cfg = longCfg
        )
        assertEquals(E.ACTION_RAISE_STOP, d.action)
        assertEquals(1, d.trailCount)
        assertEquals(E.STAGE_TRAILING, d.stage)
        assertEquals(103.8, d.newStop, 1e-9)
        assertEquals(112.0, d.newTarget, 1e-9)
        assertTrue("首次移动必须保本", d.newStop > 100.0 * 1.0005)
        assertTrue("止损只上移", d.newStop > 96.0)
    }

    // ---- 首次延续兜底：吊灯/结构位都差时，至少保本位 ----
    @Test
    fun 首次延续_无更优保护位时锁保本() {
        val wideCfg = ExitStateMachine.ExitConfig(chandelierAtr = 10.0, tier = TargetTier.AGGRESSIVE)
        // lastSwingLow=95 → 94.6；吊灯 106-20=86；均低于保本 → 取保本 100.05
        val s = struct(
            StructureEngine.UP, StructureEvent.BOS_UP,
            swings = listOf(swing(112.0, true)), lastLow = 95.0, lastHigh = 112.0
        )
        val d = E.evaluate(
            "LONG", 100.0, 96.0, 106.0, livePrice = 106.0,
            a = ana(106.0, resistance = 120.0), structure = s,
            latest = bar(105.6, 106.2, 105.4, 106.0), trailCount = 0, barsSinceTrail = 10,
            bestPrice = 106.0, cfg = wideCfg
        )
        assertEquals(E.ACTION_RAISE_STOP, d.action)
        assertEquals(100.05, d.newStop, 1e-6)
    }

    // ---- 第二次延续：止损继续上移到结构位/吊灯，trailCount=2 ----
    @Test
    fun 第二次到目标_继续延续_止损再上移() {
        // 已延续1次：stop103.8 / target112；价格再到112
        val s = struct(
            StructureEngine.UP, StructureEvent.BOS_UP,
            swings = listOf(swing(108.0, false), swing(119.0, true)),
            lastLow = 108.0, lastHigh = 119.0
        )
        // bestPrice=113 → 吊灯 110；结构位 108-0.4=107.6 → 取吊灯 110
        val d = E.evaluate(
            "LONG", 100.0, 103.8, 112.0, livePrice = 112.5,
            a = ana(112.5, resistance = 130.0), structure = s,
            latest = bar(111.5, 113.0, 111.2, 112.5), trailCount = 1, barsSinceTrail = 6,
            bestPrice = 113.0, cfg = longCfg
        )
        assertEquals(E.ACTION_RAISE_STOP, d.action)
        assertEquals(2, d.trailCount)
        assertEquals(110.0, d.newStop, 1e-9)
        assertEquals(119.0, d.newTarget, 1e-9)
        assertTrue(d.newStop > 103.8)
    }

    // ---- 延续上限：第 4 次到目标不再上移目标，只收紧保护，次数不增 ----
    @Test
    fun 达延续上限_只收紧保护_次数不增() {
        val s = struct(
            StructureEngine.UP, StructureEvent.BOS_UP,
            swings = listOf(swing(118.0, false)), lastLow = 118.0
        )
        val d = E.evaluate(
            "LONG", 100.0, 110.0, 119.0, livePrice = 119.5,
            a = ana(119.5, resistance = 140.0), structure = s,
            latest = bar(118.8, 120.0, 118.6, 119.5), trailCount = 3, barsSinceTrail = 4,
            bestPrice = 120.0, cfg = longCfg
        )
        // 收紧：吊灯 120-3=117，结构位 118-0.4=117.6 → 取 117.6
        assertEquals(E.ACTION_RAISE_STOP, d.action)
        assertEquals(3, d.trailCount)
        assertEquals(117.6, d.newStop, 1e-9)
        assertEquals(119.0, d.newTarget, 1e-9) // 目标不变
    }

    // ---- 打破止损 → EXIT_STOP（最优先） ----
    @Test
    fun 打破止损_立即结束() {
        val d = E.evaluate(
            "LONG", 100.0, 96.0, 106.0, livePrice = 95.8,
            a = ana(95.8), structure = struct(StructureEngine.UP, StructureEvent.BOS_UP),
            latest = bar(97.0, 97.2, 95.6, 95.8), trailCount = 0, barsSinceTrail = 2,
            bestPrice = 99.0, cfg = longCfg
        )
        assertEquals(E.ACTION_EXIT_STOP, d.action)
        assertTrue(d.isExit)
    }

    // ---- 已延续后打破移动止损，标签带延续次数 ----
    @Test
    fun 延续后打破移动止损_带延续标记() {
        val d = E.evaluate(
            "LONG", 100.0, 103.8, 112.0, livePrice = 103.6,
            a = ana(103.6), structure = struct(StructureEngine.UP, StructureEvent.BOS_UP),
            latest = bar(105.0, 105.2, 103.5, 103.6), trailCount = 1, barsSinceTrail = 5,
            bestPrice = 112.0, cfg = longCfg
        )
        assertEquals(E.ACTION_EXIT_STOP, d.action)
        assertEquals(1, d.trailCount)
        assertTrue(d.label.contains("延续×1"))
    }

    // ---- 反向 CHoCH 确认 → EXIT_REVERSE（即使价格还在目标位） ----
    @Test
    fun 反向结构转变_提前结束() {
        val s = struct(StructureEngine.UP, StructureEvent.CHOCH_DOWN, swings = listOf(swing(112.0, true)), lastHigh = 112.0)
        val d = E.evaluate(
            "LONG", 100.0, 96.0, 106.0, livePrice = 106.2,
            a = ana(106.2), structure = s,
            latest = bar(106.4, 106.6, 105.8, 106.2), trailCount = 0, barsSinceTrail = 9,
            bestPrice = 106.6, cfg = longCfg
        )
        assertEquals(E.ACTION_EXIT_REVERSE, d.action)
    }

    // ---- 目标位放量长上影 → 否决，止盈结束 ----
    @Test
    fun 目标位放量长上影_止盈结束() {
        val s = struct(
            StructureEngine.UP, StructureEvent.BOS_UP,
            swings = listOf(swing(112.0, true)), lastLow = 102.0, lastHigh = 112.0
        )
        // 收盘站上 106，但放量 1.6 且上影 1.4（>0.5ATR=1.0）
        val d = E.evaluate(
            "LONG", 100.0, 96.0, 106.0, livePrice = 106.1,
            a = ana(106.1, volRatio = 1.6, resistance = 120.0), structure = s,
            latest = bar(106.0, 107.5, 105.8, 106.1), trailCount = 0, barsSinceTrail = 10,
            bestPrice = 107.5, cfg = longCfg
        )
        assertEquals(E.ACTION_EXIT_TARGET, d.action)
        assertTrue(d.reasons.any { it.contains("长上影") })
    }

    // ---- 强压力 + RSI 超买 → 否决，止盈结束 ----
    @Test
    fun 强压力加RSI超买_止盈结束() {
        val s = struct(
            StructureEngine.UP, StructureEvent.BOS_UP,
            swings = listOf(swing(112.0, true)), lastLow = 102.0, lastHigh = 112.0
        )
        val d = E.evaluate(
            "LONG", 100.0, 96.0, 106.0, livePrice = 106.1,
            a = ana(106.1, rsi14 = 78.0, resistance = 106.5), structure = s,
            latest = bar(105.5, 106.4, 105.3, 106.1), trailCount = 0, barsSinceTrail = 10,
            bestPrice = 106.4, cfg = longCfg
        )
        assertEquals(E.ACTION_EXIT_TARGET, d.action)
        assertTrue(d.reasons.any { it.contains("超买") })
    }

    // ---- 延续后超过 timeoutBars 无新进展 → EXIT_TIMEOUT ----
    @Test
    fun 延续后时间止损() {
        val d = E.evaluate(
            "LONG", 100.0, 103.8, 112.0, livePrice = 108.0,
            a = ana(108.0), structure = struct(StructureEngine.UP, StructureEvent.BOS_UP),
            latest = bar(108.0, 108.4, 107.8, 108.0), trailCount = 1, barsSinceTrail = 17,
            bestPrice = 109.0, cfg = longCfg
        )
        assertEquals(E.ACTION_EXIT_TIMEOUT, d.action)
        assertTrue(d.label.contains("时间止损"))
    }

    // ---- 做空镜像：强势下跌 → 首次延续，止损下移、目标下移 ----
    @Test
    fun 做空_到目标_结构强势_延续_止损下移() {
        val s = struct(
            StructureEngine.DOWN, StructureEvent.BOS_DOWN,
            swings = listOf(swing(98.0, true), swing(88.0, false)),
            lastLow = 88.0, lastHigh = 98.0
        )
        // entry100 / stop104 / target94；best=93.2 吊灯=93.2+3=96.2；结构位 98+0.4=98.4；保本99.95 → 取 96.2
        val d = E.evaluate(
            "SHORT", 100.0, 104.0, 94.0, livePrice = 93.5,
            a = ana(93.5, rsi14 = 40.0, macdHist = -0.5, kdjK = 40.0, kdjD = 50.0,
                support = 80.0, direction = "SHORT"),
            structure = s,
            latest = bar(94.5, 94.7, 93.2, 93.5), trailCount = 0, barsSinceTrail = 10,
            bestPrice = 93.2, cfg = longCfg
        )
        assertEquals(E.ACTION_RAISE_STOP, d.action)
        assertEquals(1, d.trailCount)
        assertEquals(96.2, d.newStop, 1e-9)
        assertEquals(88.0, d.newTarget, 1e-9)
        assertTrue("做空止损只下移", d.newStop < 104.0)
        assertTrue("首次移动必保本", d.newStop < 100.0 * 0.9995)
    }

    // ---- 开关关闭 → 不延续（交由旧固定止盈逻辑） ----
    @Test
    fun 延续关闭_到目标也不动() {
        val off = ExitStateMachine.ExitConfig(continuationEnabled = false)
        val d = E.evaluate(
            "LONG", 100.0, 96.0, 106.0, livePrice = 106.5,
            a = ana(106.5), structure = struct(StructureEngine.UP, StructureEvent.BOS_UP),
            latest = bar(105.5, 106.8, 105.3, 106.5), trailCount = 0, barsSinceTrail = 10,
            bestPrice = 106.8, cfg = off
        )
        assertEquals(E.ACTION_HOLD, d.action)
    }

    // ─────────────── v5.0.17 目标分档（方案甲） ───────────────

    // ---- 稳健档：到 2R 直接落袋，即使结构强势也不延续 ----
    @Test
    fun 稳健档_到目标直接落袋() {
        val steady = ExitStateMachine.ExitConfig(tier = TargetTier.STEADY)
        val s = struct(
            StructureEngine.UP, StructureEvent.BOS_UP,
            swings = listOf(swing(112.0, true)), lastLow = 102.0, lastHigh = 112.0
        )
        // entry100 / stop96 → 1R=4；稳健目标 108（2R）
        val d = E.evaluate(
            "LONG", 100.0, 96.0, 108.0, livePrice = 108.5,
            a = ana(108.5, resistance = 120.0), structure = s,
            latest = bar(107.0, 108.6, 106.9, 108.5), trailCount = 0, barsSinceTrail = 10,
            bestPrice = 108.6, cfg = steady
        )
        assertEquals(E.ACTION_EXIT_TARGET, d.action)
        assertEquals(0, d.trailCount)
        assertTrue("标签需标明稳健档", d.label.contains("稳健档"))
        assertTrue("标签需显示真实 R=2.0（不是写死的 3.0）", d.label.contains("2.0R"))
    }

    // ---- 进取档：到 2R 先锁保本（不落袋），再冲 3R ----
    @Test
    fun 进取档_到2R先锁保本() {
        val s = struct(
            StructureEngine.UP, StructureEvent.BOS_UP,
            swings = listOf(swing(120.0, true)), lastLow = 102.0, lastHigh = 120.0
        )
        // entry100 / stop96 → 1R=4；2R 保本线 = 108；进取目标 112（3R）
        val d = E.evaluate(
            "LONG", 100.0, 96.0, 112.0, livePrice = 108.5,
            a = ana(108.5, resistance = 130.0), structure = s,
            latest = bar(107.0, 108.6, 106.9, 108.5), trailCount = 0, barsSinceTrail = 5,
            bestPrice = 108.6, breakEvenDone = false, cfg = longCfg
        )
        assertEquals(E.ACTION_RAISE_STOP, d.action)
        assertEquals(E.STAGE_BREAKEVEN, d.stage)
        assertTrue("进取档到 2R 必须标记保本完成", d.breakEvenDone)
        assertEquals(100.05, d.newStop, 1e-6)   // 保本 + 0.05% 缓冲
        assertEquals(112.0, d.newTarget, 1e-9)  // 目标不变，继续冲 3R
        assertEquals(0, d.trailCount)           // 保本不算延续
    }

    // ---- 进取档已保本后不重复触发保本，按正常延续走 ----
    @Test
    fun 进取档_已保本不重复移保本() {
        val s = struct(
            StructureEngine.UP, StructureEvent.BOS_UP,
            swings = listOf(swing(120.0, true)), lastLow = 108.0, lastHigh = 120.0
        )
        // 已保本（breakEvenDone=true）且已到 3R 目标 112 → 走延续（trailCount 0→1）
        val d = E.evaluate(
            "LONG", 100.0, 100.05, 112.0, livePrice = 112.2,
            a = ana(112.2, resistance = 130.0), structure = s,
            latest = bar(111.5, 112.4, 111.2, 112.2), trailCount = 0, barsSinceTrail = 8,
            bestPrice = 112.4, breakEvenDone = true, cfg = longCfg
        )
        assertEquals(E.ACTION_RAISE_STOP, d.action)
        assertEquals(E.STAGE_TRAILING, d.stage)
        assertEquals(1, d.trailCount)
        assertTrue("止损不得回落到保本以下", d.newStop > 100.05)
    }
}
