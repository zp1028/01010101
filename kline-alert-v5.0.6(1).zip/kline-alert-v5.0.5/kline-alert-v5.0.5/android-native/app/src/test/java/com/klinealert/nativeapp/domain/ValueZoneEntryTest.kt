package com.klinealert.nativeapp.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ValueZoneEntryTest {

    private fun analysis(
        price: Double, atr: Double = 1.0, direction: String = "LONG",
        ema20: Double? = null, ema50: Double? = null,
        swingLow: Double? = null, swingHigh: Double? = null,
        support: Double? = null, resistance: Double? = null,
        volRatio: Double = 1.0, kdjK: Double? = 50.0, kdjD: Double? = 50.0,
        states: List<IndicatorState> = emptyList()
    ) = Analysis(
        symbol = "T", market = "test", timeframe = "15m", price = price, changePct = 0.0,
        rsi14 = 50.0, ema20 = ema20, ema50 = ema50, direction = direction, score = 70,
        reason = "", candleTime = 1000L, atr = atr, atrPct = atr / price * 100,
        kdjK = kdjK, kdjD = kdjD, support = support, resistance = resistance,
        swingLow = swingLow, swingHigh = swingHigh, states = states, volRatio = volRatio
    )

    private fun struct(recent: StructureEvent?, trend: String = StructureEngine.UP) =
        StructureState(trend, emptyList(), null, null,
            StructureEvent(StructureEvent.NONE, 0.0, 0, 0.0, StructureEvent.NONE), recent)

    private fun bosUpEvent(level: Double, valid: String = StructureEvent.CONFIRMED) =
        StructureEvent(StructureEvent.BOS_UP, level, 10, 110.0, valid)
    private fun chochDown(valid: String = StructureEvent.CONFIRMED) =
        StructureEvent(StructureEvent.CHOCH_DOWN, 105.0, 18, 104.0, valid)

    // ---------- ValueZone ----------

    @Test
    fun 做多_BOS破位回踩优先() {
        val a = analysis(price = 111.0, ema20 = 105.0, ema50 = 103.0, swingLow = 108.0)
        val z = ValueZoneEngine.build(a, struct(bosUpEvent(109.0)), "LONG")
        assertTrue("应给出价值区", z != null)
        assertEquals(ValueZone.SRC_BOS_RETEST, z!!.source)
        assertEquals(109.0, z.zonePrice, 1e-9)
    }

    @Test
    fun 做多_无BOS取最近支撑EMA20() {
        val a = analysis(price = 108.0, ema20 = 105.0, ema50 = 103.0, swingLow = 104.0, support = 104.0)
        val z = ValueZoneEngine.build(a, struct(null, StructureEngine.RANGE), "LONG")
        assertTrue(z != null)
        // 现价下方最高的支撑 = EMA20 105（回踩最先触及）
        assertEquals(105.0, z!!.zonePrice, 1e-9)
    }

    @Test
    fun 做空_取最近压力即现价上方最低者() {
        val a = analysis(price = 100.0, direction = "SHORT", ema20 = 103.0, ema50 = 105.0,
            swingHigh = 102.0, resistance = 102.0)
        val z = ValueZoneEngine.build(a, struct(null, StructureEngine.RANGE), "SHORT")
        assertTrue(z != null)
        assertEquals(102.0, z!!.zonePrice, 1e-9)
        assertTrue("做空价值区应在现价上方", z.zonePrice > 100.0)
    }

    @Test
    fun 支撑距离过远_不给价值区() {
        val a = analysis(price = 200.0, atr = 1.0, ema20 = 105.0, ema50 = 103.0)
        val z = ValueZoneEngine.build(a, null, "LONG")
        assertNull(z)
    }

    private fun longZone(price: Double = 105.0): ValueZone {
        // atr=1：zonePrice=105，±0.3，stop=103，target=108，rr=1.5
        val a = analysis(price = 105.0)
        return ValueZoneEngine.build(a, null, "LONG", livePrice = price)
            ?: ValueZone("LONG", 105.0, 105.3, 104.7, "test", ValueZone.SRC_EMA20, 105.0, 103.0, 108.0, 1.5, 0.0)
    }

    // ---------- EntryStateMachine ----------

    @Test
    fun 价在价值区外_观察等回踩() {
        val a = analysis(price = 108.0)
        val zone = longZone()
        val d = EntryStateMachine.evaluate(zone, a, null, 108.0)
        assertEquals(EntryDecision.WATCHING, d.state)
        assertTrue(d.missing.joinToString().contains("回落"))
    }

    @Test
    fun 区内且止跌阳线_可开仓() {
        val a = analysis(price = 105.0, volRatio = 0.9)
        val zone = longZone()
        val latest = Candle(1L, 104.8, 105.3, 104.7, 105.2, 90.0, 2L) // 止跌阳线
        val d = EntryStateMachine.evaluate(zone, a, null, 105.0, latest)
        assertEquals(EntryDecision.READY, d.state)
        assertTrue(d.triggers.any { it.contains("阳线") })
    }

    @Test
    fun 区内但MACD绿柱扩大且阴_到位不开() {
        val a = analysis(price = 105.0, volRatio = 1.0,
            states = listOf(IndicatorState("MACD", "空头延续", "绿柱扩大")))
        val zone = longZone()
        val latest = Candle(1L, 105.2, 105.3, 104.7, 104.9, 100.0, 2L) // 阴线
        val d = EntryStateMachine.evaluate(zone, a, null, 105.0, latest)
        assertEquals(EntryDecision.IN_ZONE, d.state)
    }

    @Test
    fun 跌破价值区下沿_失效() {
        val a = analysis(price = 104.0)
        val zone = longZone()
        val d = EntryStateMachine.evaluate(zone, a, null, 104.0)
        assertEquals(EntryDecision.DEAD, d.state)
        assertTrue(d.veto.contains("跌破"))
    }

    @Test
    fun 反向CHoCH确认_一票否决() {
        val a = analysis(price = 105.0)
        val zone = longZone()
        val d = EntryStateMachine.evaluate(zone, a, struct(chochDown()), 105.0)
        assertEquals(EntryDecision.DEAD, d.state)
        assertTrue(d.veto.contains("CHoCH"))
    }
}
