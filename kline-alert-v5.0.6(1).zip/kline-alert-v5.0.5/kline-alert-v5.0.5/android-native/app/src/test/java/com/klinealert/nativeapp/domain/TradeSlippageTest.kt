package com.klinealert.nativeapp.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

/** v5.0.12 滑点保护判据：成交价距止损 ≥ 止损距离×比例 才安全（不逼近/越过止损）。 */
class TradeSlippageTest {

    @Test fun `LONG滑点正常不拒绝`() {
        // entry 60000 / stop 59000：止损距离 1000 × 30% = 300
        // 成交价 59850（向上滑 150 点）：距止损 850 ≥ 300 → 安全
        assertNull(TradeModels.tightStopReason(60000.0, 59000.0, 59850.0, 0.3))
    }

    @Test fun `LONG成交价逼近止损拒绝`() {
        // 成交价 59150：距止损 150 < 300 → 拒绝
        assertNotNull(TradeModels.tightStopReason(60000.0, 59000.0, 59150.0, 0.3))
    }

    @Test fun `LONG成交价越过止损拒绝`() {
        // 成交价 58900（已低于止损 59000）：止损单失去意义 → 拒绝
        assertNotNull(TradeModels.tightStopReason(60000.0, 59000.0, 58900.0, 0.3))
    }

    @Test fun `SHORT滑点镜像判定`() {
        // entry 2000 / stop 2100（做空止损在上方）：止损距离 100 × 30% = 30
        // 成交 2030（向上滑向止损）：距止损 70 ≥ 30 → 安全
        assertNull(TradeModels.tightStopReason(2000.0, 2100.0, 2030.0, 0.3))
        // 成交 2080（逼近止损 2100）：距止损 20 < 30 → 拒绝
        assertNotNull(TradeModels.tightStopReason(2000.0, 2100.0, 2080.0, 0.3))
        // 成交 2110（越过止损）：拒绝
        assertNotNull(TradeModels.tightStopReason(2000.0, 2100.0, 2110.0, 0.3))
    }

    @Test fun `比例越高越严格`() {
        // entry 100 / stop 90：距离 10。成交 95 距止损 5。
        // 20% → 需 ≥2 → 安全；50% → 需 ≥5 → 恰好安全（5 ≥ 5）；60% → 需 ≥6 → 拒绝
        assertNull(TradeModels.tightStopReason(100.0, 90.0, 95.0, 0.2))
        assertNull(TradeModels.tightStopReason(100.0, 90.0, 95.0, 0.5))
        assertNotNull(TradeModels.tightStopReason(100.0, 90.0, 95.0, 0.6))
    }

    @Test fun `比例关闭或无止损不判`() {
        assertNull(TradeModels.tightStopReason(100.0, 90.0, 95.0, 0.0))   // 关闭保护
        assertNull(TradeModels.tightStopReason(100.0, 0.0, 95.0, 0.3))    // 无止损
        assertNull(TradeModels.tightStopReason(0.0, 90.0, 95.0, 0.3))     // 无效入场价
    }

    @Test fun `拒绝原因包含关键数值`() {
        val r = TradeModels.tightStopReason(60000.0, 59000.0, 59150.0, 0.3)
        assertNotNull(r)
        assertEquals(true, r!!.contains("滑点致止损过近"))
        assertEquals(true, r.contains("59150"))
    }
}
