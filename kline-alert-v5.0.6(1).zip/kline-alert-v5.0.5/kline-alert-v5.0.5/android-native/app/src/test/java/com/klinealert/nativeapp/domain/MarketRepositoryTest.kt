package com.klinealert.nativeapp.domain

import com.klinealert.nativeapp.data.MarketRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** v5.0.11 premiumIndex 解析：单/多 symbol 两形态 + markPrice/资金费率字段 + 非法项跳过。 */
class MarketRepositoryTest {

    @Test fun `多symbol数组形态解析`() {
        val raw = """[{"symbol":"BTCUSDT","markPrice":"100.5","lastFundingRate":"0.0001"},{"symbol":"ETHUSDT","markPrice":"2000.0","lastFundingRate":"-0.00005"}]"""
        val q = MarketRepository.parsePremiumIndex(raw)
        assertEquals(2, q.size)
        assertEquals(100.5, q["BTCUSDT"]!!.markPrice, 1e-9)
        assertEquals(0.0001, q["BTCUSDT"]!!.lastFundingRate, 1e-9)
        assertEquals(2000.0, q["ETHUSDT"]!!.markPrice, 1e-9)
        assertEquals(-0.00005, q["ETHUSDT"]!!.lastFundingRate, 1e-9)
    }

    @Test fun `单symbol对象形态解析`() {
        val raw = """{"symbol":"BTCUSDT","markPrice":"98.2","lastFundingRate":"0.0"}"""
        val q = MarketRepository.parsePremiumIndex(raw)
        assertEquals(1, q.size)
        assertEquals(98.2, q["BTCUSDT"]!!.markPrice, 1e-9)
        assertEquals(0.0, q["BTCUSDT"]!!.lastFundingRate, 1e-9)
    }

    @Test fun `字段缺失或非法跳过`() {
        val raw = """[{"symbol":"OK","markPrice":"abc","lastFundingRate":"0.1"},{"symbol":"","markPrice":"1","lastFundingRate":"0.1"},{"markPrice":"2","lastFundingRate":"0.1"}]"""
        val q = MarketRepository.parsePremiumIndex(raw)
        assertTrue(q.isEmpty())
    }

    @Test fun `空数组与缺markPrice跳过`() {
        assertTrue(MarketRepository.parsePremiumIndex("[]").isEmpty())
        assertTrue(MarketRepository.parsePremiumIndex("""{"symbol":"X","markPrice":"x"}""").isEmpty())
    }
}
