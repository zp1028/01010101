package com.klinealert.nativeapp.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class StructureEngineTest {

    private fun candle(i: Int, high: Double, low: Double, close: Double) =
        Candle(i.toLong() * 60000, close, high, low, close, 100.0, i.toLong() * 60000 + 59999)

    /**
     * 构造严格 HH/HL 上涨结构（20 根）：
     * swing low  idx2=100，swing high idx6=110，swing low idx10=105（HL），swing high idx14=115（HH）。
     */
    private fun upCandles(lastClose: Double, lastHigh: Double = 116.0, lastLow: Double = 113.0): List<Candle> {
        val lows = doubleArrayOf(101.0,101.0,100.0,101.0,102.0,104.0,106.0,104.0,106.0,106.0,
            105.0,106.0,106.0,108.0,110.0,108.0,110.0,111.0,112.0,lastLow)
        val highs = doubleArrayOf(103.0,103.0,102.0,103.0,105.0,108.0,110.0,108.0,108.0,107.0,
            107.0,108.0,108.0,112.0,115.0,112.0,112.0,113.0,114.0,lastHigh)
        val closes = DoubleArray(20) { (highs[it] + lows[it]) / 2 }
        closes[19] = lastClose
        return (0..19).map { candle(it, highs[it], lows[it], closes[it]) }
    }

    @Test
    fun swings_严格交替且识别HH_HL上涨结构() {
        val cs = upCandles(lastClose = 113.0)
        val high = DoubleArray(cs.size) { cs[it].high }
        val low = DoubleArray(cs.size) { cs[it].low }
        val sw = StructureEngine.swings(high, low)
        // 至少识别出 4 个交替 swing：low100 high110 low105 high115
        val lows = sw.filter { !it.isHigh }.map { it.price }
        val highs = sw.filter { it.isHigh }.map { it.price }
        assertTrue("应至少2个swing low，实际 ${sw}", lows.size >= 2)
        assertTrue("应至少2个swing high，实际 ${sw}", highs.size >= 2)
        // 最近两个 low 抬高、两个 high 抬高 → UP
        assertEquals(StructureEngine.UP, StructureEngine.trendOf(sw))
    }

    @Test
    fun 收盘破前高_BOS_UP_趋势延续() {
        val cs = upCandles(lastClose = 115.5) // > 最近 swing high 115
        val st = StructureEngine.evaluate(cs, 1.0)
        assertEquals(StructureEngine.UP, st.trend)
        assertEquals(StructureEvent.BOS_UP, st.event.type)
    }

    @Test
    fun 上涨中收盘破前低_CHOCH_DOWN_结构转变() {
        val cs = upCandles(lastClose = 104.0, lastHigh = 112.0, lastLow = 103.5) // < 最近 swing low 105
        val st = StructureEngine.evaluate(cs, 1.0)
        assertEquals(StructureEvent.CHOCH_DOWN, st.event.type)
    }

    @Test
    fun 突破站稳_CONFIRMED_真突破() {
        // level=110，atr=1，buffer=0.1；后续两根都收在 109.9 上方
        val r = StructureEngine.verifyBreak("LONG", 110.0, listOf(110.2, 110.8), 1.0)
        assertEquals(StructureEvent.CONFIRMED, r)
    }

    @Test
    fun 突破收回_FAILED_假突破() {
        // 一根收回到 109.9 以下 → 假突破
        val r = StructureEngine.verifyBreak("LONG", 110.0, listOf(109.4, 110.5), 1.0)
        assertEquals(StructureEvent.FAILED, r)
    }

    @Test
    fun 验证根数不足_PENDING() {
        val r = StructureEngine.verifyBreak("LONG", 110.0, listOf(110.2), 1.0)
        assertEquals(StructureEvent.PENDING, r)
    }

    @Test
    fun 做空镜像_跌破站稳确认() {
        val r = StructureEngine.verifyBreak("SHORT", 100.0, listOf(99.8, 99.5), 1.0)
        assertEquals(StructureEvent.CONFIRMED, r)
        val f = StructureEngine.verifyBreak("SHORT", 100.0, listOf(100.6, 99.5), 1.0)
        assertEquals(StructureEvent.FAILED, f)
    }

    @Test
    fun 量能门槛_1点5倍() {
        assertTrue(StructureEngine.volumeConfirmed(1.6))
        assertFalse(StructureEngine.volumeConfirmed(1.2))
    }
}
