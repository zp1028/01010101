package com.klinealert.nativeapp.domain

import com.klinealert.nativeapp.domain.TradeModels.TradeLink
import org.junit.Assert.assertEquals
import org.junit.Test

/** v5.0.13 收益率统计口径：已实现/已平仓本金、浮动/持仓本金、总收益率。 */
class TradeStatsTest {

    private fun link(margin: Double, realized: Double, status: String, open: Boolean): TradeLink = TradeLink(
        localPositionId = "id-$margin-$realized-$status-$open",
        symbol = "BTCUSDT", direction = "LONG", marginUsdt = margin, leverage = 20.0,
        qty = margin * 20 / 60000.0, status = status, realizedPnlNet = realized,
        unrealizedPnl = if (open) realized else 0.0
    )

    @Test fun `已实现收益率与浮动收益率`() {
        // 两笔已平：本金 10 + 20 = 30，已实现 +3 + (-2) = +1 → 3.33%
        // 一笔持仓：本金 50，浮盈 5 → 10%
        val closed = listOf(link(10.0, 3.0, TradeModels.STATUS_CLOSED, false), link(20.0, -2.0, TradeModels.STATUS_CLOSED, false))
        val open = listOf(link(50.0, 5.0, TradeModels.STATUS_OPEN, true))
        val st = TradeModels.statsFrom(closed, open)
        assertEquals(30.0, st.closedMarginUsdt, 1e-9)
        assertEquals(50.0, st.openMarginUsdt, 1e-9)
        assertEquals(1.0, st.realizedPnl, 1e-9)
        assertEquals(5.0, st.floatingPnl, 1e-9)
        assertEquals(1.0 / 30.0 * 100.0, st.realizedYieldPct, 1e-9)
        assertEquals(5.0 / 50.0 * 100.0, st.floatingYieldPct, 1e-9)
        assertEquals((1.0 + 5.0) / (30.0 + 50.0) * 100.0, st.totalYieldPct, 1e-9)
    }

    @Test fun `分母为零时收益率为0`() {
        val st = TradeModels.statsFrom(emptyList(), emptyList())
        assertEquals(0.0, st.realizedYieldPct, 1e-9)
        assertEquals(0.0, st.floatingYieldPct, 1e-9)
        assertEquals(0.0, st.totalYieldPct, 1e-9)
    }

    @Test fun `非CLOSED链接不计入已平仓本金`() {
        val pending = listOf(link(10.0, 0.0, TradeModels.STATUS_PENDING_OPEN, false))
        val st = TradeModels.statsFrom(pending, emptyList())
        assertEquals(0.0, st.closedMarginUsdt, 1e-9)
        assertEquals(0.0, st.realizedPnl, 1e-9)
    }
}
