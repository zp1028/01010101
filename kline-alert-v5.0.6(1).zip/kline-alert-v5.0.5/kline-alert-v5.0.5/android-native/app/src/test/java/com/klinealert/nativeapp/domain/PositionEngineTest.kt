package com.klinealert.nativeapp.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PositionEngineTest {
    private fun pos(direction: String = "LONG") = PositionInput(
        id = "p1", symbol = "BTCUSDT", market = "SPOT", direction = direction,
        entry = 100.0, leverage = 3.0, size = 1.0,
        stop = if (direction == "LONG") 98.0 else 102.0,
        target = if (direction == "LONG") 110.0 else 90.0
    )

    @Test fun favorablePrimaryTrendScoresContinuation() {
        val result = PositionEngine.assess(pos(), listOf(
            TimeframeContext("1h", 104.0, "bull", "uptrend", "上涨延续", 80.0, 2.0),
            TimeframeContext("4h", 104.0, "bull", "uptrend", "上涨延续", 75.0, 2.0),
            TimeframeContext("15m", 104.0, "bull", "uptrend", "上涨延续", 70.0, 2.0)
        ))
        assertNotNull(result)
        assertEquals("continuation", result!!.status)
        assertEquals(4.0, result.pnlPct, 0.001)
        assertEquals(12.0, result.leveragedPnlPct, 0.001)
    }

    @Test fun opposingPrimaryTrendRaisesReversalRisk() {
        val result = PositionEngine.assess(pos(), listOf(
            TimeframeContext("1h", 99.0, "bear", "downtrend", "下跌延续", 85.0, 6.0),
            TimeframeContext("4h", 99.0, "bear", "downtrend", "下跌延续", 80.0, 6.0),
            TimeframeContext("15m", 99.0, "bear", "downtrend", "下跌延续", 80.0, 6.0)
        ))
        assertNotNull(result)
        assertEquals("reversal", result!!.status)
        assertTrue(result.riskFlags.isNotEmpty())
    }

    @Test fun directionalMoveUsesOppositeSignForShortPositions() {
        assertEquals(5.0, PositionEngine.directionalMovePct(100.0, 105.0, "LONG"), 0.001)
        assertEquals(-5.0, PositionEngine.directionalMovePct(100.0, 105.0, "SHORT"), 0.001)
        assertEquals(5.0, PositionEngine.directionalMovePct(100.0, 95.0, "SHORT"), 0.001)
    }

    @Test fun invalidReferenceEntryDoesNotProduceInfiniteMove() {
        assertEquals(0.0, PositionEngine.directionalMovePct(0.0, 105.0, "LONG"), 0.0)
    }

    @Test fun emptyContextReturnsNull() {
        assertEquals(null, PositionEngine.assess(pos(), emptyList()))
    }

    // ── v5.0.10 预估强平价（USDT本位简化，含维持保证金率 0.5%） ──
    @Test fun `LONG 强平价在入场价下方`() {
        // entry 100, lev 50: 100 × (1 − 0.995/50) = 98.01
        val liq = PositionEngine.liquidationPrice(100.0, 50.0, "LONG")
        assertEquals(98.01, liq, 1e-9)
    }

    @Test fun `SHORT 强平价在入场价上方且镜像`() {
        val l = PositionEngine.liquidationPrice(100.0, 50.0, "LONG")
        val s = PositionEngine.liquidationPrice(100.0, 50.0, "SHORT")
        assertEquals(101.99, s, 1e-9)   // 100 + 1.99
        assertEquals(200.0 - l, s, 1e-9)   // 以 100 对称
        assertTrue(s > 100.0)
    }

    @Test fun `低杠杆强平价离入场价远`() {
        val liq = PositionEngine.liquidationPrice(100.0, 2.0, "LONG")
        assertEquals(100.0 * (1.0 - 0.995 / 2.0), liq, 1e-9)   // 50.25
    }

    @Test fun `非法输入返回零`() {
        assertEquals(0.0, PositionEngine.liquidationPrice(0.0, 50.0, "LONG"), 0.0)
        assertEquals(0.0, PositionEngine.liquidationPrice(100.0, 0.0, "LONG"), 0.0)
        assertEquals(0.0, PositionEngine.liquidationPrice(100.0, -5.0, "SHORT"), 0.0)
        assertEquals(0.0, PositionEngine.liquidationPrice(Double.NaN, 50.0, "LONG"), 0.0)
    }
}
