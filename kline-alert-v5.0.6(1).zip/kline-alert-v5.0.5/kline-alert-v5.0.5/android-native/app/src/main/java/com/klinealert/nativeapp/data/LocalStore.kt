package com.klinealert.nativeapp.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.klinealert.nativeapp.domain.Analysis
import com.klinealert.nativeapp.domain.PendingSetup
import com.klinealert.nativeapp.domain.ReviewRecord
import org.json.JSONObject

/** On-device cache. Trade API secrets are NOT stored here (prefs/Keystore); only trade link mappings. */
class LocalStore(context: Context) : SQLiteOpenHelper(context, "kline_alert_local.db", null, 11) {
    override fun onCreate(db: SQLiteDatabase) {
        createScanTable(db)
        createReviewTable(db)
        createPositionTable(db)
        createPendingSetupTable(db)
        createBattleCooldownTable(db)
        createTradeLinkTable(db)
        createClosedTradeTable(db)   // v5.0.17 统一平仓台账
        // v4.8 审计：WAL 模式提升读写并发（前台 VM 与后台 Service 各自持有连接，降低 SQLITE_BUSY）
        runCatching { db.enableWriteAheadLogging() }
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Explicit forward-only migrations. Existing scan results are never dropped.
        // Idempotently repair core tables as well as tables introduced in later schema versions.
        createScanTable(db)
        // Version 2 accidentally shipped without creating review_records in onCreate;
        // create it idempotently for every existing database version.
        createReviewTable(db)
        if (oldVersion < 3) createPositionTable(db)
        if (oldVersion < 4) runCatching { db.execSQL("ALTER TABLE review_records ADD COLUMN features TEXT NOT NULL DEFAULT ''") }
        // v5：待命单持久化 + 回踩确认落库
        if (oldVersion < 5) {
            createPendingSetupTable(db)
            runCatching { db.execSQL("ALTER TABLE review_records ADD COLUMN armed_at INTEGER NOT NULL DEFAULT 0") }
            runCatching { db.execSQL("ALTER TABLE review_records ADD COLUMN pullback_confirmed INTEGER NOT NULL DEFAULT 0") }
            runCatching { db.execSQL("ALTER TABLE review_records ADD COLUMN pullback_ms INTEGER NOT NULL DEFAULT 0") }
            runCatching { db.execSQL("ALTER TABLE review_records ADD COLUMN evidence_score INTEGER NOT NULL DEFAULT 0") }
        }
        // v6：自动作战循环（v4.5）持仓生命周期字段——状态/移动止盈锚点/盈亏比/入场ATR/来源信号/平仓记录
        if (oldVersion < 6) {
            runCatching { db.execSQL("ALTER TABLE position_records ADD COLUMN status TEXT NOT NULL DEFAULT 'LIVE'") }
            runCatching { db.execSQL("ALTER TABLE position_records ADD COLUMN trailing INTEGER NOT NULL DEFAULT 0") }
            runCatching { db.execSQL("ALTER TABLE position_records ADD COLUMN best_price REAL NOT NULL DEFAULT 0") }
            runCatching { db.execSQL("ALTER TABLE position_records ADD COLUMN risk_reward REAL NOT NULL DEFAULT 2.0") }
            runCatching { db.execSQL("ALTER TABLE position_records ADD COLUMN atr REAL NOT NULL DEFAULT 0") }
            runCatching { db.execSQL("ALTER TABLE position_records ADD COLUMN timeframe TEXT NOT NULL DEFAULT ''") }
            runCatching { db.execSQL("ALTER TABLE position_records ADD COLUMN evidence_score INTEGER NOT NULL DEFAULT 0") }
            runCatching { db.execSQL("ALTER TABLE position_records ADD COLUMN close_price REAL NOT NULL DEFAULT 0") }
            runCatching { db.execSQL("ALTER TABLE position_records ADD COLUMN close_reason TEXT NOT NULL DEFAULT ''") }
            runCatching { db.execSQL("ALTER TABLE position_records ADD COLUMN closed_at INTEGER NOT NULL DEFAULT 0") }
        }
        // v7：盈亏比改「止损 2 / 止盈 3」（v4.6）——止损/止盈距离乘数独立落库
        if (oldVersion < 7) {
            runCatching { db.execSQL("ALTER TABLE position_records ADD COLUMN stop_mult REAL NOT NULL DEFAULT 2.0") }
            runCatching { db.execSQL("ALTER TABLE position_records ADD COLUMN target_mult REAL NOT NULL DEFAULT 3.0") }
        }
        // v8：自动作战冷却持久化（v4.8 审计）——进程被杀/重启后冷却不丢，防同品种立即重入
        if (oldVersion < 8) createBattleCooldownTable(db)
        // v9：币安跟单映射 TradeLink
        if (oldVersion < 9) createTradeLinkTable(db)
        // v10：信号延续管理（v5.0.16）——延续次数、阶段、上次移动止损时刻
        if (oldVersion < 10) {
            runCatching { db.execSQL("ALTER TABLE position_records ADD COLUMN trail_count INTEGER NOT NULL DEFAULT 0") }
            runCatching { db.execSQL("ALTER TABLE position_records ADD COLUMN stage TEXT NOT NULL DEFAULT 'INITIAL'") }
            runCatching { db.execSQL("ALTER TABLE position_records ADD COLUMN last_raise_at INTEGER NOT NULL DEFAULT 0") }
        }
        // v11：目标分档（v5.0.17）+ 统一平仓台账
        if (oldVersion < 11) {
            runCatching { db.execSQL("ALTER TABLE position_records ADD COLUMN tier TEXT NOT NULL DEFAULT 'STEADY'") }
            runCatching { db.execSQL("ALTER TABLE position_records ADD COLUMN break_even_done INTEGER NOT NULL DEFAULT 0") }
            createClosedTradeTable(db)
        }
    }

    private fun createTradeLinkTable(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE IF NOT EXISTS trade_links (
            local_position_id TEXT PRIMARY KEY NOT NULL,
            symbol TEXT NOT NULL, direction TEXT NOT NULL,
            margin_usdt REAL NOT NULL, leverage REAL NOT NULL, qty REAL NOT NULL DEFAULT 0,
            status TEXT NOT NULL, entry_order_id INTEGER NOT NULL DEFAULT 0,
            avg_entry REAL NOT NULL DEFAULT 0, stop_order_id INTEGER NOT NULL DEFAULT 0,
            tp_order_id INTEGER NOT NULL DEFAULT 0, stop_price REAL NOT NULL DEFAULT 0,
            target_price REAL NOT NULL DEFAULT 0, mark_price REAL NOT NULL DEFAULT 0,
            unrealized_pnl REAL NOT NULL DEFAULT 0, commission_open REAL NOT NULL DEFAULT 0,
            commission_close REAL NOT NULL DEFAULT 0, realized_pnl_net REAL NOT NULL DEFAULT 0,
            close_reason TEXT NOT NULL DEFAULT '', avg_exit REAL NOT NULL DEFAULT 0,
            client_order_id TEXT NOT NULL DEFAULT '', last_error TEXT NOT NULL DEFAULT '',
            source TEXT NOT NULL DEFAULT 'auto', opened_at INTEGER NOT NULL DEFAULT 0,
            closed_at INTEGER NOT NULL DEFAULT 0, updated_at INTEGER NOT NULL DEFAULT 0
        )""".trimIndent())
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_trade_links_status ON trade_links(status, closed_at DESC)")
    }

    private fun createBattleCooldownTable(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE IF NOT EXISTS battle_cooldowns (
            symbol TEXT NOT NULL, direction TEXT NOT NULL,
            closed_at INTEGER NOT NULL, PRIMARY KEY (symbol, direction)
        )""".trimIndent())
    }

    private fun createPendingSetupTable(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE IF NOT EXISTS pending_setups (
            key TEXT PRIMARY KEY NOT NULL, symbol TEXT NOT NULL, market TEXT NOT NULL,
            direction TEXT NOT NULL, timeframe TEXT NOT NULL, trigger_price REAL NOT NULL,
            invalid_price REAL NOT NULL, stop REAL NOT NULL, target3r REAL NOT NULL,
            atr REAL NOT NULL, score INTEGER NOT NULL, evidence_score INTEGER NOT NULL,
            gate_position INTEGER NOT NULL, gate_signal INTEGER NOT NULL, gate_time INTEGER NOT NULL,
            missing_gate TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL,
            trigger_window_ms INTEGER NOT NULL, expire_at INTEGER NOT NULL, status TEXT NOT NULL,
            triggered_at INTEGER NOT NULL DEFAULT 0, triggered_price REAL NOT NULL DEFAULT 0,
            armed_at INTEGER NOT NULL DEFAULT 0, armed_extreme REAL NOT NULL DEFAULT 0,
            note TEXT NOT NULL DEFAULT ''
        )""".trimIndent())
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_pending_created ON pending_setups(created_at DESC)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_pending_status ON pending_setups(status)")
    }

    private fun createScanTable(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE IF NOT EXISTS scan_results (
            market TEXT NOT NULL, timeframe TEXT NOT NULL, symbol TEXT NOT NULL,
            score INTEGER NOT NULL, payload TEXT NOT NULL, saved_at INTEGER NOT NULL,
            PRIMARY KEY (market, timeframe, symbol)
        )""".trimIndent())
    }

    private fun createReviewTable(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE IF NOT EXISTS review_records (
            id TEXT PRIMARY KEY NOT NULL, market TEXT NOT NULL, symbol TEXT NOT NULL,
            timeframe TEXT NOT NULL, direction TEXT NOT NULL, entry REAL NOT NULL,
            stop REAL NOT NULL, target REAL NOT NULL, score INTEGER NOT NULL,
            alerted_at INTEGER NOT NULL, verdict TEXT NOT NULL, verdict_at INTEGER NOT NULL DEFAULT 0,
            hit_price REAL NOT NULL DEFAULT 0, bars_used INTEGER NOT NULL DEFAULT 0,
            features TEXT NOT NULL DEFAULT ''
        )""".trimIndent())
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_review_market_alerted ON review_records(market, alerted_at DESC)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_review_verdict ON review_records(verdict)")
    }

    private fun createPositionTable(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE IF NOT EXISTS position_records (
            id TEXT PRIMARY KEY NOT NULL, market TEXT NOT NULL, symbol TEXT NOT NULL,
            direction TEXT NOT NULL, entry REAL NOT NULL, leverage REAL NOT NULL,
            size REAL NOT NULL, stop REAL NOT NULL, target REAL NOT NULL,
            note TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL,
            status TEXT NOT NULL DEFAULT 'LIVE', trailing INTEGER NOT NULL DEFAULT 0,
            best_price REAL NOT NULL DEFAULT 0, risk_reward REAL NOT NULL DEFAULT 2.0,
            atr REAL NOT NULL DEFAULT 0, timeframe TEXT NOT NULL DEFAULT '',
            evidence_score INTEGER NOT NULL DEFAULT 0, close_price REAL NOT NULL DEFAULT 0,
            close_reason TEXT NOT NULL DEFAULT '', closed_at INTEGER NOT NULL DEFAULT 0,
            stop_mult REAL NOT NULL DEFAULT 2.0, target_mult REAL NOT NULL DEFAULT 3.0,
            trail_count INTEGER NOT NULL DEFAULT 0, stage TEXT NOT NULL DEFAULT 'INITIAL',
            last_raise_at INTEGER NOT NULL DEFAULT 0,
            tier TEXT NOT NULL DEFAULT 'STEADY', break_even_done INTEGER NOT NULL DEFAULT 0
        )""".trimIndent())
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_positions_market ON position_records(market, updated_at DESC)")
    }

    /** v5.0.17 统一平仓台账：手动/止盈/止损/移动保本/反向/轮换/分档，每平一笔都记账（工作台统计来源）。 */
    private fun createClosedTradeTable(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE IF NOT EXISTS closed_trades (
            id TEXT PRIMARY KEY NOT NULL,
            market TEXT NOT NULL, symbol TEXT NOT NULL, direction TEXT NOT NULL,
            timeframe TEXT NOT NULL DEFAULT '', tier TEXT NOT NULL DEFAULT 'STEADY',
            entry REAL NOT NULL, stop REAL NOT NULL DEFAULT 0, target REAL NOT NULL DEFAULT 0,
            close_price REAL NOT NULL, leverage REAL NOT NULL DEFAULT 0, margin REAL NOT NULL DEFAULT 0,
            realized_r REAL NOT NULL DEFAULT 0, realized_pnl_usdt REAL NOT NULL DEFAULT 0,
            win INTEGER NOT NULL DEFAULT 0, reason TEXT NOT NULL DEFAULT '',
            source TEXT NOT NULL DEFAULT 'auto', trail_count INTEGER NOT NULL DEFAULT 0,
            opened_at INTEGER NOT NULL DEFAULT 0, closed_at INTEGER NOT NULL DEFAULT 0,
            bars_held INTEGER NOT NULL DEFAULT 0
        )""".trimIndent())
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_closed_market_time ON closed_trades(market, closed_at DESC)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_closed_tier ON closed_trades(tier, closed_at DESC)")
    }

    fun saveAnalyses(market: String, timeframe: String, rows: List<Analysis>) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("scan_results", "market=? AND timeframe=?", arrayOf(market, timeframe))
            val now = System.currentTimeMillis()
            rows.filter { it.market == market && it.timeframe == timeframe }.forEach { a ->
                val values = ContentValues().apply {
                    put("market", market); put("timeframe", timeframe); put("symbol", a.symbol)
                    put("score", a.score); put("payload", encode(a)); put("saved_at", now)
                }
                db.insertWithOnConflict("scan_results", null, values, SQLiteDatabase.CONFLICT_REPLACE)
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun loadAnalyses(market: String, timeframe: String): List<Analysis> {
        val rows = mutableListOf<Analysis>()
        readableDatabase.query("scan_results", arrayOf("payload"), "market=? AND timeframe=?", arrayOf(market, timeframe), null, null, "score DESC").use { c ->
            while (c.moveToNext()) runCatching { decode(JSONObject(c.getString(0))) }.getOrNull()?.let(rows::add)
        }
        return rows
    }

    fun saveReview(record: ReviewRecord) {
        val values = ContentValues().apply {
            put("id", record.id); put("market", record.market); put("symbol", record.symbol)
            put("timeframe", record.timeframe); put("direction", record.direction); put("entry", record.entry)
            put("stop", record.stop); put("target", record.target); put("score", record.score)
            put("alerted_at", record.alertedAt); put("verdict", record.verdict); put("verdict_at", record.verdictAt)
            put("hit_price", record.hitPrice); put("bars_used", record.barsUsed); put("features", record.features)
            put("armed_at", record.armedAt)
            put("pullback_confirmed", if (record.pullbackConfirmed) 1 else 0)
            put("pullback_ms", record.pullbackMs)
            put("evidence_score", record.evidenceScore)
        }
        writableDatabase.insertWithOnConflict("review_records", null, values, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun loadReviews(market: String, limit: Int = 200): List<ReviewRecord> {
        val out = mutableListOf<ReviewRecord>()
        readableDatabase.query("review_records", null, "market=?", arrayOf(market), null, null, "alerted_at DESC", limit.toString()).use { c ->
            while (c.moveToNext()) out += ReviewRecord(
                id=c.getString(c.getColumnIndexOrThrow("id")), market=c.getString(c.getColumnIndexOrThrow("market")),
                symbol=c.getString(c.getColumnIndexOrThrow("symbol")), timeframe=c.getString(c.getColumnIndexOrThrow("timeframe")),
                direction=c.getString(c.getColumnIndexOrThrow("direction")), entry=c.getDouble(c.getColumnIndexOrThrow("entry")),
                stop=c.getDouble(c.getColumnIndexOrThrow("stop")), target=c.getDouble(c.getColumnIndexOrThrow("target")),
                score=c.getInt(c.getColumnIndexOrThrow("score")), alertedAt=c.getLong(c.getColumnIndexOrThrow("alerted_at")),
                verdict=c.getString(c.getColumnIndexOrThrow("verdict")), verdictAt=c.getLong(c.getColumnIndexOrThrow("verdict_at")),
                hitPrice=c.getDouble(c.getColumnIndexOrThrow("hit_price")), barsUsed=c.getInt(c.getColumnIndexOrThrow("bars_used")),
                features = runCatching { c.getString(c.getColumnIndexOrThrow("features")) }.getOrDefault(""),
                armedAt = runCatching { c.getLong(c.getColumnIndexOrThrow("armed_at")) }.getOrDefault(0L),
                pullbackConfirmed = runCatching { c.getInt(c.getColumnIndexOrThrow("pullback_confirmed")) != 0 }.getOrDefault(false),
                pullbackMs = runCatching { c.getLong(c.getColumnIndexOrThrow("pullback_ms")) }.getOrDefault(0L),
                evidenceScore = runCatching { c.getInt(c.getColumnIndexOrThrow("evidence_score")) }.getOrDefault(0)
            )
        }
        return out
    }

    // ── v4.2 待命单持久化：重启后恢复未结算的待命单（长周期机会不再因重启丢失）
    fun savePendingSetups(rows: List<PendingSetup>) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            // 全量替换：内存态即权威（含已过期/已反悔的结局，也保留供事后统计）
            db.delete("pending_setups", null, null)
            rows.forEach { s ->
                val v = ContentValues().apply {
                    put("key", s.key); put("symbol", s.symbol); put("market", s.market)
                    put("direction", s.direction); put("timeframe", s.timeframe)
                    put("trigger_price", s.triggerPrice); put("invalid_price", s.invalidPrice)
                    put("stop", s.stop); put("target3r", s.target3R); put("atr", s.atr)
                    put("score", s.score); put("evidence_score", s.evidenceScore)
                    put("gate_position", if (s.gatePosition) 1 else 0)
                    put("gate_signal", if (s.gateSignal) 1 else 0)
                    put("gate_time", if (s.gateTime) 1 else 0)
                    put("missing_gate", s.missingGate); put("created_at", s.createdAt)
                    put("trigger_window_ms", s.triggerWindowMs); put("expire_at", s.expireAt)
                    put("status", s.status); put("triggered_at", s.triggeredAt)
                    put("triggered_price", s.triggeredPrice); put("armed_at", s.armedAt)
                    put("armed_extreme", s.armedExtreme); put("note", s.note)
                }
                db.insertWithOnConflict("pending_setups", null, v, SQLiteDatabase.CONFLICT_REPLACE)
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun loadPendingSetups(): List<PendingSetup> {
        val out = mutableListOf<PendingSetup>()
        readableDatabase.query("pending_setups", null, null, null, null, null, "created_at DESC").use { c ->
            while (c.moveToNext()) runCatching {
                PendingSetup(
                    key = c.getString(c.getColumnIndexOrThrow("key")),
                    symbol = c.getString(c.getColumnIndexOrThrow("symbol")),
                    market = c.getString(c.getColumnIndexOrThrow("market")),
                    direction = c.getString(c.getColumnIndexOrThrow("direction")),
                    timeframe = c.getString(c.getColumnIndexOrThrow("timeframe")),
                    triggerPrice = c.getDouble(c.getColumnIndexOrThrow("trigger_price")),
                    invalidPrice = c.getDouble(c.getColumnIndexOrThrow("invalid_price")),
                    stop = c.getDouble(c.getColumnIndexOrThrow("stop")),
                    target3R = c.getDouble(c.getColumnIndexOrThrow("target3r")),
                    atr = c.getDouble(c.getColumnIndexOrThrow("atr")),
                    score = c.getInt(c.getColumnIndexOrThrow("score")),
                    evidenceScore = c.getInt(c.getColumnIndexOrThrow("evidence_score")),
                    gatePosition = c.getInt(c.getColumnIndexOrThrow("gate_position")) != 0,
                    gateSignal = c.getInt(c.getColumnIndexOrThrow("gate_signal")) != 0,
                    gateTime = c.getInt(c.getColumnIndexOrThrow("gate_time")) != 0,
                    missingGate = c.getString(c.getColumnIndexOrThrow("missing_gate")),
                    createdAt = c.getLong(c.getColumnIndexOrThrow("created_at")),
                    triggerWindowMs = c.getLong(c.getColumnIndexOrThrow("trigger_window_ms")),
                    expireAt = c.getLong(c.getColumnIndexOrThrow("expire_at")),
                    status = c.getString(c.getColumnIndexOrThrow("status")),
                    triggeredAt = c.getLong(c.getColumnIndexOrThrow("triggered_at")),
                    triggeredPrice = c.getDouble(c.getColumnIndexOrThrow("triggered_price")),
                    armedAt = c.getLong(c.getColumnIndexOrThrow("armed_at")),
                    armedExtreme = c.getDouble(c.getColumnIndexOrThrow("armed_extreme")),
                    note = c.getString(c.getColumnIndexOrThrow("note"))
                )
            }.getOrNull()?.let(out::add)
        }
        return out
    }

    fun updateReview(record: ReviewRecord) = saveReview(record)

    data class LocalPosition(
        val id: String, val market: String, val symbol: String, val direction: String,
        val entry: Double, val leverage: Double,
        /** 起始保证金本金（USDT）。数量 = size × leverage / entry。勿当币数量。 */
        val size: Double, val stop: Double,
        val target: Double, val note: String, val createdAt: Long, val updatedAt: Long,
        // v4.5 自动作战循环字段
        val status: String = "LIVE",          // LIVE=监控中；CLOSED=已平仓（保留痕迹）
        val trailing: Boolean = false,        // 移动止盈开关（false=固定止盈）
        val bestPrice: Double = 0.0,          // 移动止盈锚点（LONG 最高 / SHORT 最低）
        val riskReward: Double = 2.0,         // 盈亏比（止盈距离/风险距离）
        val atr: Double = 0.0,                // 入场时 ATR（移动止盈步长基准）
        val timeframe: String = "",           // 来源信号周期（结算 ReviewRecord 用）
        val evidenceScore: Int = 0,           // 来源信号证据分
        val closePrice: Double = 0.0,         // 平仓价
        val closeReason: String = "",         // 平仓原因（止盈/止损/移动止盈/手动）
        val closedAt: Long = 0L,              // 平仓时刻
        // v5.0.17 止损倍数 / 目标盈亏比（v5.0.17 起 targetMult 统一为"目标盈亏比 R"：目标距离/风险距离）
        val stopMult: Double = 2.0,           // 止损距离 = stopMult×ATR
        val targetMult: Double = 3.0,         // 目标盈亏比 R（稳健 2 / 进取 3）
        // v5.0.16 信号延续管理
        val trailCount: Int = 0,              // 延续次数（0=初始仓，显示「延续×n」）
        val stage: String = "INITIAL",        // INITIAL=初始仓 / BREAKEVEN=进取档已保本 / TRAILING=已锁结构位
        val lastRaiseAt: Long = 0,            // 上次移动止损时刻（时间止损锚点，0=开仓时刻）
        // v5.0.17 目标分档
        val tier: String = "STEADY",          // STEADY=稳健 2R 落袋 / AGGRESSIVE=进取 2R 保本冲 3R
        val breakEvenDone: Boolean = false    // 进取档是否已到 2R 移动保本
    )

    fun savePosition(position: LocalPosition) {
        val values = ContentValues().apply {
            put("id", position.id); put("market", position.market); put("symbol", position.symbol)
            put("direction", position.direction); put("entry", position.entry); put("leverage", position.leverage)
            put("size", position.size); put("stop", position.stop); put("target", position.target)
            put("note", position.note); put("created_at", position.createdAt); put("updated_at", position.updatedAt)
            put("status", position.status); put("trailing", if (position.trailing) 1 else 0)
            put("best_price", position.bestPrice); put("risk_reward", position.riskReward)
            put("atr", position.atr); put("timeframe", position.timeframe)
            put("evidence_score", position.evidenceScore); put("close_price", position.closePrice)
            put("close_reason", position.closeReason); put("closed_at", position.closedAt)
            put("stop_mult", position.stopMult); put("target_mult", position.targetMult)
            put("trail_count", position.trailCount); put("stage", position.stage)
            put("last_raise_at", position.lastRaiseAt)
            put("tier", position.tier); put("break_even_done", if (position.breakEvenDone) 1 else 0)
        }
        writableDatabase.insertWithOnConflict("position_records", null, values, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun loadPositions(market: String): List<LocalPosition> {
        val out = mutableListOf<LocalPosition>()
        readableDatabase.query("position_records", null, "market=?", arrayOf(market), null, null, "updated_at DESC").use { c ->
            while (c.moveToNext()) out += LocalPosition(
                c.getString(c.getColumnIndexOrThrow("id")), c.getString(c.getColumnIndexOrThrow("market")),
                c.getString(c.getColumnIndexOrThrow("symbol")), c.getString(c.getColumnIndexOrThrow("direction")),
                c.getDouble(c.getColumnIndexOrThrow("entry")), c.getDouble(c.getColumnIndexOrThrow("leverage")),
                c.getDouble(c.getColumnIndexOrThrow("size")), c.getDouble(c.getColumnIndexOrThrow("stop")),
                c.getDouble(c.getColumnIndexOrThrow("target")), c.getString(c.getColumnIndexOrThrow("note")),
                c.getLong(c.getColumnIndexOrThrow("created_at")), c.getLong(c.getColumnIndexOrThrow("updated_at")),
                // v4.5 字段（迁移后必存在；runCatching 兜底防脏数据）
                runCatching { c.getString(c.getColumnIndexOrThrow("status")) }.getOrDefault("LIVE"),
                runCatching { c.getInt(c.getColumnIndexOrThrow("trailing")) != 0 }.getOrDefault(false),
                runCatching { c.getDouble(c.getColumnIndexOrThrow("best_price")) }.getOrDefault(0.0),
                runCatching { c.getDouble(c.getColumnIndexOrThrow("risk_reward")) }.getOrDefault(2.0),
                runCatching { c.getDouble(c.getColumnIndexOrThrow("atr")) }.getOrDefault(0.0),
                runCatching { c.getString(c.getColumnIndexOrThrow("timeframe")) }.getOrDefault(""),
                runCatching { c.getInt(c.getColumnIndexOrThrow("evidence_score")) }.getOrDefault(0),
                runCatching { c.getDouble(c.getColumnIndexOrThrow("close_price")) }.getOrDefault(0.0),
                runCatching { c.getString(c.getColumnIndexOrThrow("close_reason")) }.getOrDefault(""),
                runCatching { c.getLong(c.getColumnIndexOrThrow("closed_at")) }.getOrDefault(0L),
                // v4.6 盈亏比乘数（迁移后必存在；runCatching 兜底）
                runCatching { c.getDouble(c.getColumnIndexOrThrow("stop_mult")) }.getOrDefault(2.0),
                runCatching { c.getDouble(c.getColumnIndexOrThrow("target_mult")) }.getOrDefault(3.0),
                // v5.0.16 延续管理（迁移后必存在；runCatching 兜底）
                runCatching { c.getInt(c.getColumnIndexOrThrow("trail_count")) }.getOrDefault(0),
                runCatching { c.getString(c.getColumnIndexOrThrow("stage")) }.getOrDefault("INITIAL"),
                runCatching { c.getLong(c.getColumnIndexOrThrow("last_raise_at")) }.getOrDefault(0L),
                // v5.0.17 目标分档
                runCatching { c.getString(c.getColumnIndexOrThrow("tier")) }.getOrDefault("STEADY"),
                runCatching { c.getInt(c.getColumnIndexOrThrow("break_even_done")) != 0 }.getOrDefault(false)
            )
        }
        return out
    }

    fun deletePosition(id: String) { writableDatabase.delete("position_records", "id=?", arrayOf(id)) }

    // ── v4.8 审计：自动作战冷却持久化（重启不丢）+ 平仓记录幂等检查 ──

    /** 记录自动平仓冷却时刻（同品种同方向一条，覆盖写）。 */
    fun saveCooldown(symbol: String, direction: String, closedAt: Long) {
        val values = ContentValues().apply {
            put("symbol", symbol); put("direction", direction); put("closed_at", closedAt)
        }
        writableDatabase.insertWithOnConflict("battle_cooldowns", null, values, SQLiteDatabase.CONFLICT_REPLACE)
    }

    /** 加载全部冷却（key = "symbol|direction" → closed_at）。 */
    fun loadCooldowns(): Map<String, Long> {
        val out = mutableMapOf<String, Long>()
        readableDatabase.query("battle_cooldowns", arrayOf("symbol", "direction", "closed_at"), null, null, null, null, null).use { c ->
            while (c.moveToNext()) out["${c.getString(0)}|${c.getString(1)}"] = c.getLong(2)
        }
        return out
    }

    /** 结算样本是否已存在（双端平仓原子守卫：只有首个写入方计数/通知）。 */
    fun reviewExists(id: String): Boolean {
        readableDatabase.rawQuery("SELECT 1 FROM review_records WHERE id=?", arrayOf(id)).use { c ->
            return c.moveToFirst()
        }
    }

    /** 最近一次自动平仓时刻（自动作战冷却的数据库真相源；0=从未自动平仓）。 */
    fun lastAutoClose(symbol: String, direction: String): Long {
        var t = 0L
        readableDatabase.rawQuery(
            "SELECT MAX(verdict_at) FROM review_records WHERE id LIKE 'auto|%' AND symbol=? AND direction=? AND verdict_at>0",
            arrayOf(symbol, direction)
        ).use { c -> if (c.moveToNext()) t = c.getLong(0) }
        return t
    }

    fun reviewCounts(market: String): Map<String, Int> {
        val counts = mutableMapOf("open" to 0, "hit" to 0, "miss" to 0, "neutral" to 0)
        readableDatabase.rawQuery("SELECT verdict, COUNT(*) FROM review_records WHERE market=? GROUP BY verdict", arrayOf(market)).use { c ->
            while (c.moveToNext()) counts[c.getString(0)] = c.getInt(1)
        }
        return counts
    }

    // ───────── v9 币安跟单 TradeLink ─────────

    fun tryInsertTradeLink(link: com.klinealert.nativeapp.domain.TradeModels.TradeLink): Boolean {
        val values = tradeLinkValues(link)
        return writableDatabase.insertWithOnConflict("trade_links", null, values, SQLiteDatabase.CONFLICT_IGNORE) != -1L
    }

    fun saveTradeLink(link: com.klinealert.nativeapp.domain.TradeModels.TradeLink) {
        writableDatabase.insertWithOnConflict("trade_links", null, tradeLinkValues(link), SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun loadTradeLinks(status: String? = null, limit: Int = 200): List<com.klinealert.nativeapp.domain.TradeModels.TradeLink> {
        val sql = if (status != null)
            "SELECT * FROM trade_links WHERE status=? ORDER BY updated_at DESC LIMIT ?"
        else
            "SELECT * FROM trade_links ORDER BY updated_at DESC LIMIT ?"
        val args = if (status != null) arrayOf(status, limit.toString()) else arrayOf(limit.toString())
        val out = mutableListOf<com.klinealert.nativeapp.domain.TradeModels.TradeLink>()
        readableDatabase.rawQuery(sql, args).use { c ->
            while (c.moveToNext()) out += readTradeLink(c)
        }
        return out
    }

    fun loadTradeLink(localPositionId: String): com.klinealert.nativeapp.domain.TradeModels.TradeLink? {
        readableDatabase.rawQuery("SELECT * FROM trade_links WHERE local_position_id=? LIMIT 1", arrayOf(localPositionId)).use { c ->
            if (c.moveToNext()) return readTradeLink(c)
        }
        return null
    }

    /** 仅当当前 status 匹配时更新（平仓/开仓原子守卫）。 */
    fun updateTradeLinkIfStatus(link: com.klinealert.nativeapp.domain.TradeModels.TradeLink, expectStatus: String): Boolean {
        val v = tradeLinkValues(link)
        val n = writableDatabase.update("trade_links", v, "local_position_id=? AND status=?", arrayOf(link.localPositionId, expectStatus))
        return n > 0
    }

    private fun tradeLinkValues(link: com.klinealert.nativeapp.domain.TradeModels.TradeLink) = ContentValues().apply {
        put("local_position_id", link.localPositionId); put("symbol", link.symbol); put("direction", link.direction)
        put("margin_usdt", link.marginUsdt); put("leverage", link.leverage); put("qty", link.qty)
        put("status", link.status); put("entry_order_id", link.entryOrderId); put("avg_entry", link.avgEntry)
        put("stop_order_id", link.stopOrderId); put("tp_order_id", link.tpOrderId)
        put("stop_price", link.stopPrice); put("target_price", link.targetPrice); put("mark_price", link.markPrice)
        put("unrealized_pnl", link.unrealizedPnl); put("commission_open", link.commissionOpen)
        put("commission_close", link.commissionClose); put("realized_pnl_net", link.realizedPnlNet)
        put("close_reason", link.closeReason); put("avg_exit", link.avgExit)
        put("client_order_id", link.clientOrderId); put("last_error", link.lastError)
        put("source", link.source); put("opened_at", link.openedAt); put("closed_at", link.closedAt)
        put("updated_at", link.updatedAt)
    }

    private fun readTradeLink(c: android.database.Cursor) = com.klinealert.nativeapp.domain.TradeModels.TradeLink(
        localPositionId = c.getString(c.getColumnIndexOrThrow("local_position_id")),
        symbol = c.getString(c.getColumnIndexOrThrow("symbol")),
        direction = c.getString(c.getColumnIndexOrThrow("direction")),
        marginUsdt = c.getDouble(c.getColumnIndexOrThrow("margin_usdt")),
        leverage = c.getDouble(c.getColumnIndexOrThrow("leverage")),
        qty = c.getDouble(c.getColumnIndexOrThrow("qty")),
        status = c.getString(c.getColumnIndexOrThrow("status")),
        entryOrderId = c.getLong(c.getColumnIndexOrThrow("entry_order_id")),
        avgEntry = c.getDouble(c.getColumnIndexOrThrow("avg_entry")),
        stopOrderId = c.getLong(c.getColumnIndexOrThrow("stop_order_id")),
        tpOrderId = c.getLong(c.getColumnIndexOrThrow("tp_order_id")),
        stopPrice = c.getDouble(c.getColumnIndexOrThrow("stop_price")),
        targetPrice = c.getDouble(c.getColumnIndexOrThrow("target_price")),
        markPrice = c.getDouble(c.getColumnIndexOrThrow("mark_price")),
        unrealizedPnl = c.getDouble(c.getColumnIndexOrThrow("unrealized_pnl")),
        commissionOpen = c.getDouble(c.getColumnIndexOrThrow("commission_open")),
        commissionClose = c.getDouble(c.getColumnIndexOrThrow("commission_close")),
        realizedPnlNet = c.getDouble(c.getColumnIndexOrThrow("realized_pnl_net")),
        closeReason = c.getString(c.getColumnIndexOrThrow("close_reason")),
        avgExit = c.getDouble(c.getColumnIndexOrThrow("avg_exit")),
        clientOrderId = c.getString(c.getColumnIndexOrThrow("client_order_id")),
        lastError = c.getString(c.getColumnIndexOrThrow("last_error")),
        source = c.getString(c.getColumnIndexOrThrow("source")),
        openedAt = c.getLong(c.getColumnIndexOrThrow("opened_at")),
        closedAt = c.getLong(c.getColumnIndexOrThrow("closed_at")),
        updatedAt = c.getLong(c.getColumnIndexOrThrow("updated_at"))
    )

    private fun encode(a: Analysis) = JSONObject().apply {
        put("symbol", a.symbol); put("market", a.market); put("timeframe", a.timeframe); put("price", a.price)
        put("changePct", a.changePct); putNullable("rsi14", a.rsi14); putNullable("ema20", a.ema20); putNullable("ema50", a.ema50)
        put("direction", a.direction); put("score", a.score); put("reason", a.reason); put("candleTime", a.candleTime)
        put("atr", a.atr); put("atrPct", a.atrPct); putNullable("macdHist", a.macdHist); putNullable("kdjK", a.kdjK); putNullable("kdjD", a.kdjD)
        putNullable("support", a.support); putNullable("resistance", a.resistance); put("entry", a.entry); put("stop", a.stop)
        put("target", a.target); put("riskReward", a.riskReward); put("regime", a.regime); put("regimeConfidence", a.regimeConfidence)
    }.toString()

    private fun decode(j: JSONObject) = Analysis(
        symbol = j.getString("symbol"), market = j.getString("market"), timeframe = j.getString("timeframe"),
        price = j.getDouble("price"), changePct = j.getDouble("changePct"), rsi14 = j.nullableDouble("rsi14"),
        ema20 = j.nullableDouble("ema20"), ema50 = j.nullableDouble("ema50"), direction = j.getString("direction"),
        score = j.getInt("score"), reason = j.optString("reason"), candleTime = j.optLong("candleTime"),
        atr = j.optDouble("atr", 0.0), atrPct = j.optDouble("atrPct", 0.0), macdHist = j.nullableDouble("macdHist"),
        kdjK = j.nullableDouble("kdjK"), kdjD = j.nullableDouble("kdjD"), support = j.nullableDouble("support"),
        resistance = j.nullableDouble("resistance"), entry = j.optDouble("entry", j.getDouble("price")),
        stop = j.optDouble("stop", j.getDouble("price")), target = j.optDouble("target", j.getDouble("price")),
        riskReward = j.optDouble("riskReward", 0.0), regime = j.optString("regime", "区间震荡"),
        regimeConfidence = j.optDouble("regimeConfidence", 50.0)
    )

    private fun JSONObject.putNullable(key: String, value: Double?) { if (value == null) put(key, JSONObject.NULL) else put(key, value) }
    private fun JSONObject.nullableDouble(key: String): Double? = if (!has(key) || isNull(key)) null else optDouble(key).takeIf { it.isFinite() }

    // ── v5.0.17 统一平仓台账（工作台统计唯一来源） ──────────────────────────────

    /** 一笔已平仓交易（手动/自动/后台/轮换/分档都记）。 */
    data class ClosedTrade(
        val id: String,
        val market: String,
        val symbol: String,
        val direction: String,
        val timeframe: String = "",
        val tier: String = "STEADY",
        val entry: Double,
        val stop: Double = 0.0,
        val target: Double = 0.0,
        val closePrice: Double,
        val leverage: Double = 0.0,
        val margin: Double = 0.0,
        val realizedR: Double = 0.0,
        val realizedPnlUsdt: Double = 0.0,
        val win: Boolean = false,
        val reason: String = "",
        val source: String = "auto",
        val trailCount: Int = 0,
        val openedAt: Long = 0L,
        val closedAt: Long = 0L,
        val barsHeld: Int = 0
    ) {
        companion object {
            // 平仓原因
            const val R_TARGET = "TARGET"            // 到目标止盈（稳健 2R / 进取 3R）
            const val R_STOP = "STOP"                // 初始止损
            const val R_BREAKEVEN = "BREAKEVEN_STOP" // 保本/移动止损（延续后）
            const val R_REVERSE = "REVERSE"          // 反向 CHoCH
            const val R_TIMEOUT = "TIMEOUT"          // 时间止损
            const val R_ROTATE = "ROTATE"            // 轮换腾出槽位
            const val R_MANUAL = "MANUAL"            // 手动平仓
            // 来源
            const val S_AUTO = "auto"
            const val S_MANUAL = "manual"
            const val S_BACKGROUND = "background"
            const val S_ROTATION = "rotation"
        }
    }

    /** 台账聚合统计（工作台胜率/盈亏比/期望/收益率 + 两档分组）。 */
    data class ClosedTradeStats(
        val count: Int,
        val wins: Int,
        val losses: Int,
        val winRate: Double,
        val totalR: Double,
        val avgR: Double,
        val expectancyR: Double,
        val totalPnlUsdt: Double,
        val sumMargin: Double,
        val avgWinR: Double,
        val avgLossR: Double,
        val steadyCount: Int,
        val steadyWinRate: Double,
        val steadyTotalR: Double,
        val aggrCount: Int,
        val aggrWinRate: Double,
        val aggrTotalR: Double
    ) {
        /** 累计投入本金回报率（每单位本金创造的累计盈亏），空本金返回 0。 */
        val roiPct: Double get() = if (sumMargin > 0) totalPnlUsdt / sumMargin * 100.0 else 0.0
        val empty: Boolean get() = count == 0
    }

    /** 幂等写一笔平仓（按 position id 去重，防止前后台重复记账）。 */
    fun saveClosedTrade(t: ClosedTrade) {
        val values = ContentValues().apply {
            put("id", t.id); put("market", t.market); put("symbol", t.symbol); put("direction", t.direction)
            put("timeframe", t.timeframe); put("tier", t.tier)
            put("entry", t.entry); put("stop", t.stop); put("target", t.target); put("close_price", t.closePrice)
            put("leverage", t.leverage); put("margin", t.margin)
            put("realized_r", t.realizedR); put("realized_pnl_usdt", t.realizedPnlUsdt)
            put("win", if (t.win) 1 else 0); put("reason", t.reason); put("source", t.source)
            put("trail_count", t.trailCount); put("opened_at", t.openedAt); put("closed_at", t.closedAt)
            put("bars_held", t.barsHeld)
        }
        writableDatabase.insertWithOnConflict("closed_trades", null, values, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun closedTradeExists(id: String): Boolean {
        readableDatabase.query("closed_trades", arrayOf("id"), "id=?", arrayOf(id), null, null, null).use { c ->
            return c.moveToFirst()
        }
    }

    fun loadClosedTrades(market: String, limit: Int = 500): List<ClosedTrade> {
        val out = mutableListOf<ClosedTrade>()
        readableDatabase.query("closed_trades", null, "market=?", arrayOf(market), null, null,
            "closed_at DESC", limit.toString()).use { c ->
            while (c.moveToNext()) out += ClosedTrade(
                id = c.getString(c.getColumnIndexOrThrow("id")),
                market = c.getString(c.getColumnIndexOrThrow("market")),
                symbol = c.getString(c.getColumnIndexOrThrow("symbol")),
                direction = c.getString(c.getColumnIndexOrThrow("direction")),
                timeframe = c.getString(c.getColumnIndexOrThrow("timeframe")),
                tier = c.getString(c.getColumnIndexOrThrow("tier")),
                entry = c.getDouble(c.getColumnIndexOrThrow("entry")),
                stop = c.getDouble(c.getColumnIndexOrThrow("stop")),
                target = c.getDouble(c.getColumnIndexOrThrow("target")),
                closePrice = c.getDouble(c.getColumnIndexOrThrow("close_price")),
                leverage = c.getDouble(c.getColumnIndexOrThrow("leverage")),
                margin = c.getDouble(c.getColumnIndexOrThrow("margin")),
                realizedR = c.getDouble(c.getColumnIndexOrThrow("realized_r")),
                realizedPnlUsdt = c.getDouble(c.getColumnIndexOrThrow("realized_pnl_usdt")),
                win = c.getInt(c.getColumnIndexOrThrow("win")) != 0,
                reason = c.getString(c.getColumnIndexOrThrow("reason")),
                source = c.getString(c.getColumnIndexOrThrow("source")),
                trailCount = c.getInt(c.getColumnIndexOrThrow("trail_count")),
                openedAt = c.getLong(c.getColumnIndexOrThrow("opened_at")),
                closedAt = c.getLong(c.getColumnIndexOrThrow("closed_at")),
                barsHeld = c.getInt(c.getColumnIndexOrThrow("bars_held"))
            )
        }
        return out
    }

    fun closedTradeStats(market: String): ClosedTradeStats {
        val list = loadClosedTrades(market, Int.MAX_VALUE)
        val n = list.size
        if (n == 0) return ClosedTradeStats(0, 0, 0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0, 0.0, 0.0, 0, 0.0, 0.0)
        val wins = list.filter { it.win }
        val losses = list.filter { !it.win }
        val totalR = list.sumOf { it.realizedR }
        val totalPnl = list.sumOf { it.realizedPnlUsdt }
        val sumMargin = list.sumOf { it.margin }
        val avgWin = if (wins.isEmpty()) 0.0 else wins.sumOf { it.realizedR } / wins.size
        val avgLoss = if (losses.isEmpty()) 0.0 else losses.sumOf { it.realizedR } / losses.size
        fun grp(tier: String): List<ClosedTrade> = list.filter { it.tier == tier }
        fun wr(l: List<ClosedTrade>): Double = if (l.isEmpty()) 0.0 else l.count { it.win }.toDouble() / l.size
        val steady = grp("STEADY"); val aggr = grp("AGGRESSIVE")
        return ClosedTradeStats(
            count = n,
            wins = wins.size,
            losses = losses.size,
            winRate = wins.size.toDouble() / n,
            totalR = totalR,
            avgR = totalR / n,
            expectancyR = totalR / n,
            totalPnlUsdt = totalPnl,
            sumMargin = sumMargin,
            avgWinR = avgWin,
            avgLossR = avgLoss,
            steadyCount = steady.size,
            steadyWinRate = wr(steady),
            steadyTotalR = steady.sumOf { it.realizedR },
            aggrCount = aggr.size,
            aggrWinRate = wr(aggr),
            aggrTotalR = aggr.sumOf { it.realizedR }
        )
    }
}
