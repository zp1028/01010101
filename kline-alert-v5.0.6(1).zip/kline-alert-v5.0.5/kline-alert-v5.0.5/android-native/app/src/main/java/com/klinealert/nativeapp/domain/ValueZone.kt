package com.klinealert.nativeapp.domain

import kotlin.math.abs

/**
 * v5.0.15 价值区（Value Zone）：回答"在什么价格开才合理"，而不是信号一出现就按现价追。
 *
 * 做多价值区（价格下方的有效支撑），按优先级：
 *  1. BOS_RETEST 破位回踩：价格先 BOS_UP 收盘突破结构位（趋势启动），再回踩被突破的阻力
 *     —— 破阻力变支撑，是结构上最经典、风险回报比最好的入场位。
 *  2. EMA20 / EMA60 动态均线支撑（趋势回踩）。
 *  3. 最近 swing 低点 / 支撑位（a.support）。
 * 做空镜像（反抽压力位）。
 *
 * 入场取"回踩最先触及的位"（做多取现价下方最近的支撑）；
 * 止损 = 价值区价 − stopMult×ATR，止盈 = 价值区价 + targetMult×ATR（默认 2 / 3，与全局一致）。
 * 与现价入场用同一套止损止盈倍数，保证回测对比只改变入场价、口径公平。
 */
data class ValueZone(
    val direction: String,        // LONG / SHORT
    val zonePrice: Double,        // 价值区中枢（理想限价）
    val zoneTop: Double,          // 区间上沿（到位判定）
    val zoneBottom: Double,       // 区间下沿（跌破即失效）
    val label: String,
    val source: String,           // BOS_RETEST / EMA20 / EMA60 / SWING / SUPPORT
    val entry: Double,
    val stop: Double,
    val target: Double,
    val rr: Double,
    val distancePct: Double       // 现价距价值区中枢百分比（带方向：正=还需回落/反弹）
) {
    companion object {
        const val SRC_BOS_RETEST = "BOS_RETEST"
        const val SRC_EMA20 = "EMA20"
        const val SRC_EMA60 = "EMA60"
        const val SRC_SWING = "SWING"
        const val SRC_SUPPORT = "SUPPORT"
    }
}

object ValueZoneEngine {
    const val DEFAULT_TOL_ATR = 0.3           // 到位容差 ±0.3×ATR
    const val DEFAULT_MAX_DISTANCE_ATR = 3.0  // 价值区距现价超过 3×ATR 视为近期等不到，不给

    private data class Candidate(val price: Double, val source: String, val label: String, val priority: Int)

    /**
     * 计算价值区。无合理位（方向矛盾/距离过远/数据不足）返回 null。
     * 注意 Analysis.ema50 字段承载的是 EMA60（见 AnalysisEngine 构造顺序，传入的是 snap.ema60）。
     */
    fun build(
        a: Analysis,
        structure: StructureState?,
        direction: String,
        livePrice: Double? = null,
        tolAtr: Double = DEFAULT_TOL_ATR,
        stopMult: Double = BattleLoopEngine.DEFAULT_STOP_MULT,
        targetMult: Double = BattleLoopEngine.DEFAULT_TARGET_MULT,
        maxDistanceAtr: Double = DEFAULT_MAX_DISTANCE_ATR
    ): ValueZone? {
        val long = direction == "LONG"
        val price = livePrice?.takeIf { it > 0 } ?: a.price
        val atr = a.atr.takeIf { it > 0 } ?: return null
        if (price <= 0 || !price.isFinite()) return null

        // 候选位（先不区分方向，统一收集后按方向过滤）
        val candidates = mutableListOf<Candidate>()
        // 1. BOS 破位回踩
        structure?.recentEvent?.let { ev ->
            val validRetest = when (direction) {
                "LONG" -> ev.type == StructureEvent.BOS_UP && ev.valid != StructureEvent.FAILED
                "SHORT" -> ev.type == StructureEvent.BOS_DOWN && ev.valid != StructureEvent.FAILED
                else -> false
            }
            if (validRetest) candidates += Candidate(ev.level, ValueZone.SRC_BOS_RETEST,
                "破位回踩 ${if (long) "阻力→支撑" else "支撑→压力"} @ ${fmt(ev.level)}", priority = 0)
        }
        // 2. EMA20 / EMA60
        a.ema20?.takeIf { it.isFinite() && it > 0 }?.let { candidates += Candidate(it, ValueZone.SRC_EMA20, "EMA20 动态${if (long) "支撑" else "压力"} @ ${fmt(it)}", priority = 1) }
        a.ema50?.takeIf { it.isFinite() && it > 0 }?.let { candidates += Candidate(it, ValueZone.SRC_EMA60, "EMA60 动态${if (long) "支撑" else "压力"} @ ${fmt(it)}", priority = 1) }
        // 3. swing 极值 / 结构支撑压力
        val swing = if (long) structure?.lastSwingLow?.price ?: a.swingLow
        else structure?.lastSwingHigh?.price ?: a.swingHigh
        swing?.takeIf { it > 0 }?.let { candidates += Candidate(it, ValueZone.SRC_SWING, "摆动${if (long) "低" else "高"} @ ${fmt(it)}", priority = 2) }
        val level = if (long) a.support else a.resistance
        level?.takeIf { it > 0 }?.let { candidates += Candidate(it, ValueZone.SRC_SUPPORT, "${if (long) "支撑" else "压力"}位 @ ${fmt(it)}", priority = 2) }

        // 方向过滤：做多只保留现价下方，做空只保留现价上方
        val onSide = candidates.filter { if (long) it.price < price else it.price > price }
        if (onSide.isEmpty()) return null
        // 距离过滤：超过 maxDistance×ATR 视为近期等不到
        val inReach = onSide.filter { abs(it.price - price) / atr <= maxDistanceAtr }
        if (inReach.isEmpty()) return null

        // 选位：优先 BOS_RETEST；否则取"回踩最先触及"的位（做多=现价下方最高者，做空=现价上方最低者）
        val retest = inReach.filter { it.source == ValueZone.SRC_BOS_RETEST }.minByOrNull { abs(it.price - price) }
        val chosen = retest
            ?: if (long) inReach.maxByOrNull { it.price }!! else inReach.minByOrNull { it.price }!!

        val zonePrice = chosen.price
        val tol = tolAtr * atr
        val sign = if (long) 1.0 else -1.0
        val stop = zonePrice - sign * stopMult * atr
        // v5.0.17 统一 R 口径：targetMult 即目标盈亏比 R，目标 = targetMult × 实际风险距离(stopMult×ATR)
        val riskDist = stopMult * atr
        val target = zonePrice + sign * targetMult * riskDist
        val rr = targetMult
        // 带方向的距离百分比：做多为正=还需下跌到区，做空为正=还需反弹到区
        val distancePct = (price - zonePrice) / price * 100 * (if (long) 1 else -1)
        return ValueZone(
            direction = direction, zonePrice = zonePrice,
            zoneTop = zonePrice + tol, zoneBottom = zonePrice - tol,
            label = chosen.label, source = chosen.source,
            entry = zonePrice, stop = stop, target = target, rr = rr,
            distancePct = distancePct
        )
    }

    /** 价格是否在价值区内（含边界）。 */
    fun contains(zone: ValueZone, price: Double): Boolean =
        price > 0 && price in zone.zoneBottom..zone.zoneTop

    /** 价格是否已越过价值区（做多跌破下沿 / 做空涨过上沿）= 支撑/压力失效。 */
    fun broken(zone: ValueZone, price: Double): Boolean =
        price > 0 && (if (zone.direction == "LONG") price < zone.zoneBottom else price > zone.zoneTop)

    private fun fmt(v: Double) =
        String.format(java.util.Locale.US, if (v >= 1) "%.4f" else "%.8f", v)
}
