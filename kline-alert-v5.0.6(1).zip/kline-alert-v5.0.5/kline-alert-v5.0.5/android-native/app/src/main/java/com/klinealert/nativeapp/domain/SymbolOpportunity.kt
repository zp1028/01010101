package com.klinealert.nativeapp.domain

/**
 * 品种维度的聚合机会：一个品种一张卡，融合所有所选周期的信号。
 *
 * 融合规则（OpportunityFusion）：
 * - 方向投票：按周期灵敏度权重加权（15m 灵敏 / 4h 可靠）
 * - 综合分：同向周期的加权平均分 + 共振加成 - 反向惩罚
 * - 代表信号：取权重最高的同向周期作为展示/止损止盈依据
 */
data class SymbolOpportunity(
    val symbol: String,
    val market: String,
    val direction: String,
    val score: Int,
    val confidence: Int,
    val price: Double,
    val changePct: Double,
    val perTimeframe: Map<String, Analysis>,
    val rep: Analysis,
    val resonanceCount: Int,
    val oppositeCount: Int,
    val grade: String = "",
    val plan: List<String> = emptyList(),
    // v5.0.17 目标分档（方案甲）
    val tierHint: String = TargetTier.STEADY,   // 建议档位（开仓时可用完整结构再判/手动覆盖）
    val targetSteady: Double = 0.0,             // 稳健档目标价（2R）
    val targetAggr: Double = 0.0,               // 进取档目标价（3R）
    val tierReasons: List<String> = emptyList() // 分档判定理由
)

object OpportunityFusion {
    /** 基础周期灵敏度权重：15m 灵敏 / 4h 可靠。可被 LearnedWeights 按周期×方向覆盖。 */
    val defaultWeights = mapOf("15m" to 1.2, "30m" to 1.0, "1h" to 0.8, "4h" to 0.6)
    private val weights = defaultWeights

    /**
     * learned 可选：key 为 "15m|LONG"，值为该周期×方向的学习后权重（胜率越高权重越大）。
     * patternBonus 可选：key 为 "模式|方向"（如 "趋势回调至关键位|LONG"），校准加减分（±8）。
     * tierCfg 可选：v5.0.17 目标分档配置（止损/两档 R 由全局传入，不再写死 3R）。
     */
    fun fuse(symbol: String, market: String, per: Map<String, Analysis>, learned: Map<String, Double> = emptyMap(), patternBonus: Map<String, Int> = emptyMap(), tierCfg: TargetTier.TierConfig = TargetTier.TierConfig()): SymbolOpportunity? {
        val entries = per.values.filterNotNull()
        if (entries.isEmpty()) return null
        fun wOf(a: Analysis): Double = learned["${a.timeframe}|${a.direction}"] ?: (weights[a.timeframe] ?: 1.0)
        val longW = entries.filter { it.direction == "LONG" }.sumOf { wOf(it) }
        val shortW = entries.filter { it.direction == "SHORT" }.sumOf { wOf(it) }
        val direction = if (longW >= shortW) "LONG" else "SHORT"
        val same = entries.filter { it.direction == direction }
        val opposite = entries.filter { it.direction != direction }
        if (same.isEmpty()) return null
        val wSum = same.sumOf { wOf(it) }.coerceAtLeast(0.1)
        var score = same.sumOf { wOf(it) * it.score } / wSum
        val resonance = same.size - 1
        val opposition = opposite.size
        if (resonance >= 1) score += 8 * minOf(resonance, 2)
        if (opposition >= 1) score -= 12
        val rep = same.maxBy { wOf(it) * it.score }
        val fusedScore0 = score.coerceIn(0.0, 100.0).toInt()
        if (fusedScore0 < 50) return null
        // ML-1 校准：历史胜率显著偏离基线的模式×方向自动加减分（样本≥20 才有值）
        val calibBonus = if (patternBonus.isEmpty()) 0 else rep.patterns.sumOf { patternBonus["$it|$direction"] ?: 0 }
        val fusedScore = (fusedScore0 + calibBonus).coerceIn(0, 100)
        val note = buildString {
            if (resonance >= 1) append("；${resonance} 个其他周期同向共振")
            if (opposition >= 1) append("；注意：${opposition} 个周期存在反向信号")
        }
        val repWithNote = if (note.isEmpty()) rep else rep.copy(reason = rep.reason + note, score = fusedScore)
        val latest = entries.maxByOrNull { it.candleTime } ?: rep
        val base = SymbolOpportunity(
            symbol = symbol, market = market, direction = direction, score = fusedScore,
            confidence = rep.confidence, price = latest.price, changePct = latest.changePct,
            perTimeframe = per.filterValues { it != null }.mapValues { it.value!! },
            rep = repWithNote, resonanceCount = resonance, oppositeCount = opposition
        )
        val grade = PrecisionRank.gradeOf(base)
        // SmartLevels：结构位优先 + 波动自适应的止损（与确认/生命线/持仓全链路共享同一套价位）
        val sl = SmartLevelsEngine.build(repWithNote, direction)
        // 风险距离（1R）：结构止损距离，兜底 1.5×ATR（与 TargetTier 口径一致）
        val risk = (sl.entry - sl.stop).takeIf { direction == "LONG" && it > 0 }
            ?: (sl.stop - sl.entry).takeIf { it > 0 }
            ?: repWithNote.atr.let { it * 1.5 }.takeIf { it > 0 }
            ?: repWithNote.price * 0.015
        // v5.0.17 两档目标（统一 R 口径，倍数读全局 tierCfg，不再写死 3R）
        val targetSteady = if (direction == "LONG") sl.entry + tierCfg.steadyR * risk else sl.entry - tierCfg.steadyR * risk
        val targetAggr = if (direction == "LONG") sl.entry + tierCfg.aggrR * risk else sl.entry - tierCfg.aggrR * risk
        // 建议档位：机会卡阶段无完整结构，用代表信号 Analysis 轻量判（开仓时 VM 用结构再判，可手动覆盖）
        val tier = TargetTier.classify(direction, sl.entry, sl.stop, fusedScore, tierCfg, a = repWithNote, structure = null)
        val aggr = tier.tier == TargetTier.AGGRESSIVE
        val target = if (aggr) targetAggr else targetSteady
        val repTargetR = if (aggr) tierCfg.aggrR else tierCfg.steadyR
        val repSmart = repWithNote.copy(entry = sl.entry, stop = sl.stop, target = target, riskReward = repTargetR)
        val withTier = base.copy(
            rep = repSmart, grade = grade,
            tierHint = tier.tier, targetSteady = targetSteady, targetAggr = targetAggr, tierReasons = tier.reasons
        )
        return withTier.copy(plan = PrecisionRank.buildPlan(withTier) + sl.notes.map { "◈ $it" })
    }
}

/* ------------------------------------------------------------------ */
/* 精准入场榜：严格多条件门槛，宁缺毋滥                                  */
/* ------------------------------------------------------------------ */

data class PrecisionCheck(val label: String, val pass: Boolean, val detail: String, val weight: Double = 1.0, val score: Double = if (pass) 1.0 else 0.0)

object PrecisionRank {
    /** 核心门槛（权重1.5）：A级必须全过。 */
    val CORE_LABELS = setOf("多周期共振", "无周期反向", "当前处于金叉状态", "位置贴近周期极值", "量能确认")

    private fun stateOf(a: Analysis, name: String) = a.states.firstOrNull { it.name == name }

    /** 加权得分（0-100）。 */
    fun weightedScore(checks: List<PrecisionCheck>): Double {
        val w = checks.sumOf { it.weight }.coerceAtLeast(0.1)
        return checks.sumOf { it.score * it.weight } / w * 100.0
    }

    fun rankScore(checks: List<PrecisionCheck>): Int = weightedScore(checks).toInt()

    /** 返回逐项门槛检查（14 项，含权重与得分）。 */
    fun evaluate(sop: SymbolOpportunity, livePrice: Double?, tfWinRates: Map<String, Pair<Int, Double>> = emptyMap()): List<PrecisionCheck> {
        val a = sop.rep
        val long = sop.direction == "LONG"
        val checks = mutableListOf<PrecisionCheck>()
        val fmt = { v: Double -> String.format(java.util.Locale.US, "%.2f", v) }

        // 1. 多周期共振确认（核心 ×1.5）
        checks += PrecisionCheck("多周期共振", sop.resonanceCount >= 1,
            if (sop.resonanceCount >= 1) "${sop.resonanceCount + 1} 个周期同向" else "仅单周期信号", weight = 1.5)

        // 2. 无反向信号（核心 ×1.5）
        checks += PrecisionCheck("无周期反向", sop.oppositeCount == 0,
            if (sop.oppositeCount == 0) "各周期方向一致" else "${sop.oppositeCount} 个周期反向", weight = 1.5)

        // 3. 临近触发（距关键位 ≤0.6%，优先实时价）
        val keyLevel = if (long) a.resistance else a.support
        val refPrice = livePrice ?: a.price
        val dist = if (keyLevel != null && refPrice > 0) (keyLevel - refPrice) / refPrice * 100 else null
        checks += PrecisionCheck("临近关键位≤0.6%", dist != null && kotlin.math.abs(dist) <= 0.6,
            if (dist != null) "距${if (long) "承压" else "支撑"} ${fmt(dist)}%" else "无关键位参考")

        // 4. 盈亏比 ≥1.5
        checks += PrecisionCheck("盈亏比≥1.5", a.riskReward >= 1.5, fmt(a.riskReward))

        // 5. 波动适中（ATR 0.3%~5%）
        checks += PrecisionCheck("ATR 0.3%~5%", a.atrPct in 0.3..5.0, fmt(a.atrPct) + "%")

        // 6. RSI 不追极端
        val rsiOk = a.rsi14?.let { if (long) it < 75 else it > 25 } ?: true
        checks += PrecisionCheck("RSI不追极端", rsiOk, a.rsi14?.let { String.format(java.util.Locale.US, "%.1f", it) } ?: "—")

        // 7. 可信度 ≥60
        checks += PrecisionCheck("可信度≥60", sop.confidence >= 60, "${sop.confidence}%")

        // 8. 阶段趋势匹配
        val regimeOk = if (long)
            sop.perTimeframe.values.any { it.regime.contains("牛") || it.regime.contains("多") || it.regime.contains("上涨") }
        else
            sop.perTimeframe.values.any { it.regime.contains("熊") || it.regime.contains("空") || it.regime.contains("下跌") }
        checks += PrecisionCheck("阶段趋势匹配", regimeOk, a.regime)

        // 9. 当前处于金叉/死叉状态（核心 ×1.5）：MACD + EMA9/21 + KDJ 三项按当前延续状态计分
        run {
            val names = listOf("MACD", "EMA9/21", "KDJ")
            val matched = names.count { name ->
                stateOf(a, name)?.let { if (long) it.state.contains("多头") else it.state.contains("空头") } == true
            }
            val macdState = stateOf(a, "MACD")
            val barsAgo = macdState?.detail?.let { Regex("(\\d+) 根K线前").find(it)?.groupValues?.getOrNull(1)?.toIntOrNull() }
            var score = matched / 3.0
            if (matched == 3 && (barsAgo ?: 0) > 30) score = 0.75 // 交叉延续超30根：延续末端降分
            val detail = when {
                matched == 3 -> "MACD/EMA/KDJ 全部${if (long) "多头" else "空头"}延续" + ((barsAgo ?: 0).takeIf { it > 30 }?.let { "（MACD 已 $it 根，延续末端）" } ?: "")
                matched == 2 -> "3 项中 2 项同向延续"
                else -> "仅 $matched/3 项同向，等待交叉确认"
            }
            checks += PrecisionCheck("当前处于金叉状态", matched >= 2, detail, weight = 1.5, score = score)
        }

        // 10. 位置门槛（核心 ×1.5）：做多贴近周期低点且远离高点；做空镜像
        run {
            val ref = refPrice
            val atrPct = a.atrPct.takeIf { it > 0 } ?: 1.0
            var pass = false; var score = 0.0; var detail: String
            if (ref <= 0 || (a.swingLow == null && a.swingHigh == null)) {
                detail = "无周期极值参考"; score = 0.5; pass = true
            } else if (long) {
                val low = a.swingLow
                val high = a.swingHigh
                val distLow = low?.let { (ref - it) / ref * 100 }
                val distHigh = high?.let { (it - ref) / ref * 100 }
                val nearLow = distLow != null && (distLow <= 1.5 || distLow <= atrPct * 2)
                val farFromHigh = distHigh == null || distHigh >= 1.5
                pass = nearLow && farFromHigh; score = if (pass) 1.0 else if (nearLow || farFromHigh) 0.5 else 0.0
                detail = "距周期低点 " + (distLow?.let { fmt(it) } ?: "—") + "%，距周期高点 " + (distHigh?.let { fmt(it) } ?: "—") + "%" +
                    (if (pass) " ✓ 低位区" else if (!nearLow) " ✗ 已脱离低位，等回踩" else " ✗ 距高点过近，上方空间不足")
            } else {
                val high = a.swingHigh
                val low = a.swingLow
                val distHigh = high?.let { (it - ref) / ref * 100 }
                val distLow = low?.let { (ref - it) / ref * 100 }
                val nearHigh = distHigh != null && (kotlin.math.abs(distHigh) <= 1.5 || kotlin.math.abs(distHigh) <= atrPct * 2)
                val farFromLow = distLow == null || distLow >= 1.5
                pass = nearHigh && farFromLow; score = if (pass) 1.0 else if (nearHigh || farFromLow) 0.5 else 0.0
                detail = "距周期高点 " + (distHigh?.let { fmt(kotlin.math.abs(it)) } ?: "—") + "%，距周期低点 " + (distLow?.let { fmt(it) } ?: "—") + "%" +
                    (if (pass) " ✓ 高位区" else if (!nearHigh) " ✗ 已脱离高位，等反抽" else " ✗ 距低点过近，下方空间不足")
            }
            checks += PrecisionCheck("位置贴近周期极值", pass, detail, weight = 1.5, score = score)
        }

        // 11. 15m 入场时机：15m 不得逆向加速（接飞刀过滤）
        run {
            val a15 = sop.perTimeframe["15m"]
            if (a15 == null) {
                checks += PrecisionCheck("15m入场时机", true, "无15m数据，跳过", score = 0.5)
            } else {
                val emaState = stateOf(a15, "EMA20")
                val macdState = stateOf(a15, "MACD")
                val streak = emaState?.detail?.let { Regex("连续 (\\d+) 根").find(it)?.groupValues?.getOrNull(1)?.toIntOrNull() } ?: 0
                val accelDown = emaState?.state?.contains("下方") == true && streak >= 3 && macdState?.detail?.contains("绿柱扩大") == true
                val accelUp = emaState?.state?.contains("上方") == true && streak >= 3 && macdState?.detail?.contains("红柱扩大") == true
                val bad = (long && accelDown) || (!long && accelUp)
                checks += PrecisionCheck("15m入场时机", !bad,
                    if (bad) "15m 正逆向加速，${if (long) "等绿柱收敛/收回EMA20上" else "等红柱收敛/跌破EMA20"}再入场" else "15m 无逆向加速 ✓")
            }
        }

        // 12. 量能确认（核心 ×1.5）：OBV 背离一票否决
        run {
            val volState = stateOf(a, "量能")
            val detail = volState?.detail ?: ""
            val div = detail.contains("顶背离") || detail.contains("底背离")
            val wrongDiv = (long && detail.contains("顶背离")) || (!long && detail.contains("底背离"))
            checks += PrecisionCheck("量能确认", !wrongDiv,
                if (!div) "量价配合正常 ✓" else if (wrongDiv) "OBV ${if (long) "顶" else "底"}背离，方向缺乏量能支持" else "背离方向与本单相反，不影响",
                weight = 1.5)
        }

        // 13. 历史胜率背书（软性 ×0.5）：该 周期×方向 历史胜率 ≥55%（样本≥10）
        run {
            val wr = tfWinRates["${a.timeframe}|${sop.direction}"]
            when {
                wr == null || wr.first < 10 -> checks += PrecisionCheck("历史胜率背书", true, "样本积累中（${wr?.first ?: 0}/10）", score = 0.5)
                wr.second >= 0.55 -> checks += PrecisionCheck("历史胜率背书", true, String.format(java.util.Locale.US, "历史胜率 %.0f%%（%d 样本）✓", wr.second * 100, wr.first))
                else -> checks += PrecisionCheck("历史胜率背书", false, String.format(java.util.Locale.US, "历史胜率仅 %.0f%%（%d 样本）", wr.second * 100, wr.first))
            }
        }

        // 14. 波动健康度（软性 ×0.5）：强趋势末端+布林极度扩张时拒绝
        run {
            val adxState = stateOf(a, "ADX")?.detail ?: ""
            val bollState = stateOf(a, "布林")?.detail ?: ""
            val exhaustion = adxState.contains("衰竭") && bollState.contains("显著扩张")
            checks += PrecisionCheck("波动健康度", !exhaustion,
                if (exhaustion) "ADX 高位衰竭 + 布林极度扩张，行情已走完主段" else "波动结构正常 ✓")
        }

        return checks
    }

    /** A：核心门槛全过且加权得分≥90；B：加权≥70 且核心最多差1项；其余 C。 */
    fun gradeOf(sop: SymbolOpportunity, tfWinRates: Map<String, Pair<Int, Double>> = emptyMap()): String {
        val checks = evaluate(sop, null, tfWinRates)
        val coreChecks = checks.filter { it.weight >= 1.5 }
        val corePass = coreChecks.count { it.score >= 0.99 }
        val wScore = weightedScore(checks)
        return when {
            corePass == coreChecks.size && wScore >= 90.0 -> "A"
            wScore >= 70.0 && corePass >= coreChecks.size - 1 -> "B"
            else -> "C"
        }
    }

    /** 标准交易计划：入场区 / 止损 / 三档止盈 / 盈亏比 / 失效条件。 */
    fun buildPlan(sop: SymbolOpportunity): List<String> {
        val a = sop.rep
        val long = sop.direction == "LONG"
        fun f(v: Double) = if (v >= 1) String.format(java.util.Locale.US, "%.4f", v) else String.format(java.util.Locale.US, "%.8f", v)
        // R = 入场到止损的风险距离；T2=稳健 2R、T3=进取 3R（v5.0.17 读全局，缺失兜底）
        val riskDist = kotlin.math.abs(a.entry - a.stop)
        val r = if (riskDist > 0) riskDist else if (a.atr > 0) 1.5 * a.atr else a.price * 0.01
        val t1 = if (long) a.entry + r else a.entry - r
        val t2 = if (sop.targetSteady > 0) sop.targetSteady else (if (long) a.entry + 2 * r else a.entry - 2 * r)
        val t3 = if (sop.targetAggr > 0) sop.targetAggr else a.target
        val tierLabel = if (sop.tierHint == TargetTier.AGGRESSIVE) "进取档 3R（2R 保本后冲）" else "稳健档 2R（到点落袋）"
        val adverse = if (long) "跌破" else "突破"
        return listOf(
            "方向 ${if (long) "做多" else "做空/承压"} · 代表周期 ${a.timeframe} · 阶段「${a.regime}」",
            "入场区 ${f(a.entry)} 附近（关键位 ±0.2%，回踩确认更佳）",
            "止损 ${f(a.stop)}（结构位外 0.5×ATR · 波动自适应）",
            "止盈 稳健 T2 ${f(t2)} / 进取 T3 ${f(t3)}（T1 保本 ${f(t1)}）",
            "建议档位：$tierLabel · ATR ${String.format(java.util.Locale.US, "%.2f", a.atrPct)}%",
            "失效条件：收盘$adverse ${f(a.stop)}，或 ${a.timeframe} 出现反向${if (long) "死叉" else "金叉"}，或阶段转为「假突破」"
        )
    }
}

/* ------------------------------------------------------------------ */
/* 训练闭环：历史机会反馈 → 学习权重                                     */
/* 原理：用已结算信号（hit/miss）按 周期×方向 统计胜率，                  */
/* 用贝叶斯收缩（先验 0.5、等效样本 5）防止小样本过拟合，                 */
/* 映射为融合权重：weight = base × (0.55 + 0.9 × 胜率)。                 */
/* 例：15m 做多胜率 70% → 权重 1.2×1.18=1.42；胜率 30% → 1.2×0.82=0.98   */
/* ------------------------------------------------------------------ */
object LearnedWeights {
    /** key "15m|LONG" → 学习后融合权重。 */
    fun from(records: List<ReviewRecord>): Map<String, Double> {
        val settled = records.filter { it.verdict == "hit" || it.verdict == "miss" }
        val out = mutableMapOf<String, Double>()
        settled.groupBy { "${it.timeframe}|${it.direction}" }.forEach { (key, list) ->
            val tf = key.substringBefore("|")
            val base = OpportunityFusion.defaultWeights[tf] ?: 1.0
            val hits = list.count { it.verdict == "hit" }
            val rate = (hits + 2.5) / (list.size + 5.0) // 收缩先验：等效 5 个 50% 样本
            out[key] = base * (0.55 + 0.9 * rate)
        }
        return out
    }

    /** key "15m|LONG" → (样本数, 胜率0-1)。供 UI 胜率标记展示。 */
    fun winRates(records: List<ReviewRecord>): Map<String, Pair<Int, Double>> {
        val settled = records.filter { it.verdict == "hit" || it.verdict == "miss" }
        val out = mutableMapOf<String, Pair<Int, Double>>()
        settled.groupBy { "${it.timeframe}|${it.direction}" }.forEach { (key, list) ->
            val hits = list.count { it.verdict == "hit" }
            out[key] = list.size to hits.toDouble() / list.size
        }
        return out
    }
}
