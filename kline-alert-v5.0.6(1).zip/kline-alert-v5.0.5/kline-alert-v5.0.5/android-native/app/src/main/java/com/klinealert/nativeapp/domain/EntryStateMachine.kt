package com.klinealert.nativeapp.domain

/**
 * v5.0.15 入场触发引擎（Entry State Machine）：把"出方向"与"可开仓"彻底分离。
 *
 * 扫描/融合只产出方向观察名单；真正可开仓必须走完状态机：
 *
 *   WATCHING（观察）  价格在价值区外 —— 做多等回踩、做空等反抽，显示"等待到 X（距 Y%）"
 *      → IN_ZONE（到位）  价格进入价值区 ±0.3×ATR，但止跌/企稳未确认
 *      → READY（可开仓）  区内 + 止跌扳机命中 + 盈亏比达标 + 无风控否决
 *   DEAD（失效）  任一：价值区被收盘越过（支撑/压力破位）、反向 CHoCH 确认、OBV 错误背离
 *
 * 指标扳机（微观，只在结构与位置都满足后微调）：
 *  做多：止跌阳线 / 下影收回 / MACD 绿柱收敛 / KDJ 低位拐头；排除 MACD 绿柱扩大、放量破位。
 *  做空镜像。
 * 风控一票否决（结构层）：反向 CHoCH 确认、价值区破位、OBV 背离 —— 不管指标多好看都不开。
 */
data class EntryDecision(
    val state: String,            // WATCHING / IN_ZONE / READY / DEAD
    val direction: String,
    val entry: Double,
    val stop: Double,
    val target: Double,
    val rr: Double,
    val distPct: Double,          // 现价距价值区（%，带方向）
    val triggers: List<String>,   // 已命中的止跌/企稳扳机
    val missing: List<String>,    // 尚缺条件
    val veto: String,             // 风控否决原因（非空 = DEAD）
    val zoneLabel: String
) {
    val ready: Boolean get() = state == READY
    val dead: Boolean get() = state == DEAD
    companion object {
        const val WATCHING = "WATCHING"
        const val IN_ZONE = "IN_ZONE"
        const val READY = "READY"
        const val DEAD = "DEAD"
    }
}

object EntryTrigger {
    /** 从指标状态列表取某指标的明细文案。 */
    private fun stateDetail(a: Analysis, name: String): String =
        a.states.firstOrNull { it.name == name }?.detail ?: ""

    /** 止跌/企稳扳机判定。hits=命中的做多/做空证据，blocks=逆势加速（一票否决开仓）。 */
    fun evaluate(a: Analysis, long: Boolean, latest: Candle?): Pair<List<String>, List<String>> {
        val hits = mutableListOf<String>()
        val blocks = mutableListOf<String>()
        val macd = stateDetail(a, "MACD")
        val vol = stateDetail(a, "量能")

        if (latest != null) {
            val range = (latest.high - latest.low).takeIf { it > 0 } ?: 0.0
            val bodyMid = (latest.open + latest.close) / 2
            if (long) {
                if (latest.close > latest.open) hits += "止跌阳线"
                if (range > 0 && (minOf(latest.open, latest.close) - latest.low) / range >= 0.5 && latest.close >= bodyMid)
                    hits += "下影收回"
            } else {
                if (latest.close < latest.open) hits += "滞涨阴线"
                if (range > 0 && (latest.high - maxOf(latest.open, latest.close)) / range >= 0.5 && latest.close <= bodyMid)
                    hits += "上影承压"
            }
        }
        // MACD 动量
        if (long) {
            if (macd.contains("绿柱收敛")) hits += "MACD绿柱收敛"
            if (macd.contains("红柱")) hits += "MACD红柱"
            if (macd.contains("绿柱扩大")) blocks += "MACD绿柱扩大（下跌加速）"
        } else {
            if (macd.contains("红柱收敛")) hits += "MACD红柱收敛"
            if (macd.contains("绿柱")) hits += "MACD绿柱"
            if (macd.contains("红柱扩大")) blocks += "MACD红柱扩大（上涨加速）"
        }
        // KDJ 低位/高位拐头
        val k = a.kdjK
        val d = a.kdjD
        if (k != null) {
            if (long && k <= 40 && (d == null || k >= d)) hits += "KDJ低位拐头(${k.toInt()})"
            if (!long && k >= 60 && (d == null || k <= d)) hits += "KDJ高位拐头(${k.toInt()})"
        }
        // 放量破位风险（回踩/反抽途中不应放量）
        if (a.volRatio >= 1.5) blocks += "回踩放量${String.format(java.util.Locale.US, "%.1f", a.volRatio)}×（疑破位）"
        // OBV 错误背离（结构层否决）
        if (long && vol.contains("顶背离")) blocks += "OBV顶背离"
        if (!long && vol.contains("底背离")) blocks += "OBV底背离"
        return hits to blocks
    }
}

object EntryStateMachine {
    const val DEFAULT_MIN_RR = 1.5

    /**
     * 核心评估（纯函数，回测/实盘同构）。
     * @param zone 价值区（由 ValueZoneEngine 给出）
     * @param a 代表周期 Analysis
     * @param structure 结构快照（可空，空则不做结构否决）
     * @param price 实时/回放价格
     * @param latest 最新收盘 K 线（可空，用于止跌 K 线判定）
     */
    fun evaluate(
        zone: ValueZone?,
        a: Analysis,
        structure: StructureState?,
        price: Double,
        latest: Candle? = null,
        minRR: Double = DEFAULT_MIN_RR
    ): EntryDecision {
        if (zone == null) {
            return EntryDecision(EntryDecision.DEAD, a.direction, a.price, a.stop, a.target,
                a.riskReward, 0.0, emptyList(), emptyList(), "无合理价值区（无有效支撑/压力位或距离过远）", "")
        }
        val long = zone.direction == "LONG"
        val missing = mutableListOf<String>()
        val triggers = mutableListOf<String>()

        // ---- 1. 结构层一票否决 ----
        var veto = ""
        structure?.recentEvent?.let { ev ->
            if (long && ev.type == StructureEvent.CHOCH_DOWN && ev.valid == StructureEvent.CONFIRMED)
                veto = "结构转变 CHoCH：收盘跌破最近 swing 低，多头结构破坏"
            if (!long && ev.type == StructureEvent.CHOCH_UP && ev.valid == StructureEvent.CONFIRMED)
                veto = "结构转变 CHoCH：收盘突破最近 swing 高，空头结构破坏"
        }
        if (veto.isEmpty() && ValueZoneEngine.broken(zone, price)) {
            veto = if (long) "价格已跌破价值区下沿 ${fmt(zone.zoneBottom)}，支撑失效"
            else "价格已涨破价值区上沿 ${fmt(zone.zoneTop)}，压力失效"
        }
        if (veto.isNotEmpty()) {
            return EntryDecision(EntryDecision.DEAD, zone.direction, zone.entry, zone.stop, zone.target,
                zone.rr, zone.distancePct, emptyList(), emptyList(), veto, zone.label)
        }

        // ---- 2. 位置状态 ----
        val inZone = ValueZoneEngine.contains(zone, price)
        if (!inZone) {
            // 区外：等回踩/反抽
            val wait = if (long) "等待回落至 ${fmt(zone.zonePrice)}（距 ${String.format(java.util.Locale.US, "%.2f", zone.distancePct)}%）"
            else "等待反抽至 ${fmt(zone.zonePrice)}（距 ${String.format(java.util.Locale.US, "%.2f", zone.distancePct)}%）"
            return EntryDecision(EntryDecision.WATCHING, zone.direction, zone.entry, zone.stop, zone.target,
                zone.rr, zone.distancePct, emptyList(), listOf(wait), "", zone.label)
        }

        // ---- 3. 区内：止跌扳机 ----
        val (hits0, blocks0) = EntryTrigger.evaluate(a, long, latest)
        triggers += hits0
        val blocks = blocks0.toMutableList()
        // 反向 CHoCH 未确认（PENDING）也先冻结，不给 READY
        structure?.recentEvent?.let { ev ->
            if (long && ev.type == StructureEvent.CHOCH_DOWN) blocks += "出现反向 CHoCH（待验证）"
            if (!long && ev.type == StructureEvent.CHOCH_UP) blocks += "出现反向 CHoCH（待验证）"
        }
        if (triggers.isEmpty()) missing += "等待止跌企稳（止跌K / MACD收敛 / KDJ拐头）"
        if (blocks.isNotEmpty()) missing += blocks
        if (zone.rr < minRR) missing += "盈亏比 ${String.format(java.util.Locale.US, "%.2f", zone.rr)} < $minRR"

        val ready = triggers.isNotEmpty() && blocks.isEmpty() && zone.rr >= minRR
        val state = if (ready) EntryDecision.READY else EntryDecision.IN_ZONE
        return EntryDecision(state, zone.direction, zone.entry, zone.stop, zone.target,
            zone.rr, zone.distancePct, triggers, missing, "", zone.label)
    }

    private fun fmt(v: Double) =
        String.format(java.util.Locale.US, if (v >= 1) "%.4f" else "%.8f", v)
}
