package com.klinealert.nativeapp.domain

import kotlin.math.abs
import kotlin.math.max

/** Local, reference-only position assessment ported from src/engine/positions.ts. */
data class PositionInput(
    val id: String = "", val symbol: String, val market: String, val direction: String,
    val entry: Double, val leverage: Double = 1.0, val size: Double = 0.0,
    val stop: Double = 0.0, val target: Double = 0.0, val note: String = ""
)

data class TimeframeContext(
    val timeframe: String, val price: Double, val bias: String, val phase: String,
    val phaseLabel: String, val confidence: Double, val atrPct: Double,
    val nearestSupport: Double? = null, val nearestSupportLabel: String = "支撑位",
    val nearestResistance: Double? = null, val nearestResistanceLabel: String = "承压位"
)

data class PositionAssessment(
    val id: String, val symbol: String, val market: String, val direction: String,
    val entry: Double, val leverage: Double, val size: Double, val price: Double,
    val pnlPct: Double, val leveragedPnlPct: Double, val status: String,
    val statusLabel: String, val confidence: Double, val reasons: List<String>,
    val riskFlags: List<String>, val primaryTimeframe: String,
    val regimes: Map<String, String>, val stop: Double, val target: Double,
    val stopDistancePct: Double?, val targetDistancePct: Double?, val note: String
)

object PositionEngine {
    private fun round2(v: Double) = kotlin.math.round(v * 100.0) / 100.0
    private fun round4(v: Double) = kotlin.math.round(v * 10000.0) / 10000.0

    /** Direction-aware move relative to reference entry; percentage points (1% → 1.0), not account PnL. */
    fun directionalMovePct(entry: Double, price: Double, direction: String): Double {
        if (!entry.isFinite() || entry <= 0.0 || !price.isFinite() || price <= 0.0) return 0.0
        val move = (price - entry) / entry * 100.0
        return if (direction.equals("SHORT", ignoreCase = true)) -move else move
    }

    /**
     * LocalPosition.size 语义 = 起始保证金 marginUsdt（本金，USDT）。
     * 数量 = 本金 × 杠杆 / 开仓价。
     * 未实现盈亏(USDT) = 本金 × 杠杆 × 方向变动% / 100。
     * 收益率%（开仓保证金口径）= 杠杆 × 方向变动%。
     */
    fun quantity(marginUsdt: Double, leverage: Double, entry: Double): Double {
        if (!entry.isFinite() || entry <= 0.0 || !marginUsdt.isFinite() || marginUsdt <= 0.0) return 0.0
        val lev = leverage.takeIf { it.isFinite() && it > 0 } ?: 1.0
        return round4(marginUsdt * lev / entry)
    }

    /** 未实现盈亏 USDT。movePct 为百分点（涨 1% → 1.0）。例：本金1×杠杆50×1% = +0.50 USDT。 */
    fun pnlUsdt(marginUsdt: Double, leverage: Double, movePct: Double): Double {
        val m = marginUsdt.takeIf { it.isFinite() && it > 0 } ?: 0.0
        val lev = leverage.takeIf { it.isFinite() && it > 0 } ?: 1.0
        val move = movePct.takeIf { it.isFinite() } ?: 0.0
        return round4(m * lev * (move / 100.0))
    }

    /** 开仓保证金口径收益率百分点。例：杠杆 50、涨 1% → +50%。 */
    fun yieldPct(leverage: Double, movePct: Double): Double {
        val lev = leverage.takeIf { it.isFinite() && it > 0 } ?: 1.0
        val move = movePct.takeIf { it.isFinite() } ?: 0.0
        return round2(lev * move)
    }

    /**
     * v5.0.10 预估强平价（USDT 本位合约简化，含维持保证金率 mmr）：
     * LONG:  entry × (1 − (1 − mmr) / lev)；SHORT: entry × (1 + (1 − mmr) / lev)。
     * 仅本地预估，实际以交易所及仓位档位维持保证金率为准；非法输入返回 0.0（UI 显示"—"）。
     */
    fun liquidationPrice(entry: Double, leverage: Double, direction: String, mmr: Double = 0.005): Double {
        if (!entry.isFinite() || entry <= 0.0 || !leverage.isFinite() || leverage <= 0.0 || !mmr.isFinite()) return 0.0
        val lev = leverage.coerceAtLeast(1.0)
        val factor = (1.0 - mmr) / lev
        return if (direction.equals("SHORT", ignoreCase = true)) entry * (1.0 + factor)
        else entry * (1.0 - factor)
    }

    /** preferTimeframes preserves the original default priority: 1h, 4h, 15m. */
    fun assess(
        position: PositionInput,
        contexts: List<TimeframeContext>,
        livePrice: Double? = null,
        preferTimeframes: List<String> = listOf("1h", "4h", "15m", "30m")
    ): PositionAssessment? {
        val byTf = contexts.associateBy { it.timeframe }
        val available = preferTimeframes.mapNotNull(byTf::get)
        if (available.isEmpty()) return null
        val primary = available.first()
        val price = (livePrice ?: primary.price).takeIf { it.isFinite() && it > 0 } ?: return null
        val direction = position.direction.uppercase().let { if (it == "SHORT") "SHORT" else "LONG" }
        val favor = if (direction == "LONG") "bull" else "bear"
        val against = if (direction == "LONG") "bear" else "bull"
        val leverage = position.leverage.takeIf { it.isFinite() }?.coerceAtLeast(1.0) ?: 1.0
        val pnl = directionalMovePct(position.entry, price, direction)
        var score = 0
        val reasons = mutableListOf<String>()
        val risks = mutableListOf<String>()
        when (primary.bias) {
            favor -> { score += 40; reasons += "${primary.timeframe} 阶段「${primary.phaseLabel}」与持仓方向一致" }
            against -> { score -= 45; reasons += "${primary.timeframe} 阶段「${primary.phaseLabel}」与持仓方向相悖"; risks += "主周期阶段转空" }
            else -> reasons += "${primary.timeframe} 阶段「${primary.phaseLabel}」中性"
        }
        if (primary.confidence >= 70) score += if (primary.bias == favor) 8 else -8
        val aligned = available.drop(1).count { it.bias == favor }
        val opposed = available.drop(1).count { it.bias == against }
        if (aligned >= 2) { score += 15; reasons += "${aligned} 个副周期同向共振" }
        else if (opposed >= 2) { score -= 20; reasons += "${opposed} 个副周期反向，注意结构破坏"; risks += "多周期反向" }

        val stopDistance = if (position.stop > 0) (position.stop - price) / price * 100.0 else null
        val targetDistance = if (position.target > 0) (position.target - price) / price * 100.0 else null
        if (stopDistance != null && abs(stopDistance) <= 1.0) {
            risks += "距止损仅 ${String.format(java.util.Locale.US, "%.2f", abs(stopDistance))}%"; score -= 15
        }
        if (direction == "LONG" && primary.nearestResistance != null && abs(primary.nearestResistance - price) / price <= 0.008) {
            score -= 12
            val dist = (primary.nearestResistance - price) / price * 100
            reasons += "上方 ${primary.nearestResistanceLabel} 承压（${String.format(java.util.Locale.US, "%.2f", dist)}%）"; risks += "逼近承压位"
        }
        if (direction == "SHORT" && primary.nearestSupport != null && abs(primary.nearestSupport - price) / price <= 0.008) {
            score -= 12
            val dist = (primary.nearestSupport - price) / price * 100
            reasons += "下方 ${primary.nearestSupportLabel} 支撑（${String.format(java.util.Locale.US, "%.2f", dist)}%）"; risks += "逼近支撑位"
        }
        if (pnl < -2) { score -= 10; reasons += "当前浮亏 ${String.format(java.util.Locale.US, "%.2f", pnl)}%" }
        else if (pnl > 2) { score += 6; reasons += "当前浮盈 ${String.format(java.util.Locale.US, "%.2f", pnl)}%" }
        if (primary.atrPct >= 5) risks += "波动偏大（ATR ${String.format(java.util.Locale.US, "%.1f", primary.atrPct)}%）"
        val status = when { score >= 35 -> "continuation"; score <= -25 -> "reversal"; else -> "watch" }
        val label = when (status) { "continuation" -> "延续"; "reversal" -> "反转预警"; else -> "观望" }
        return PositionAssessment(
            position.id, position.symbol, position.market, direction, position.entry, leverage, position.size,
            price, round2(pnl), round2(pnl * leverage), status, label,
            (50 + score * 0.6).coerceIn(20.0, 99.0), reasons, risks, primary.timeframe,
            available.associate { it.timeframe to "${it.phaseLabel} · ${it.bias} · ${String.format(java.util.Locale.US, "%.1f", it.confidence)}%" },
            position.stop, position.target, stopDistance?.let(::round2), targetDistance?.let(::round2), position.note
        )
    }
}
