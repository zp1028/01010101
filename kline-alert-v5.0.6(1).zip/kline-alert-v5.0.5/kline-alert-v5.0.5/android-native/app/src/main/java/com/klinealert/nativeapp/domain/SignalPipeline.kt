package com.klinealert.nativeapp.domain

/**
 * v5.0.15 统一事件管道（Signal Pipeline）：回测与实盘共用同一套评估内核。
 *
 * 业界生产级实践（NautilusTrader / QuantConnect LEAN 的 research-to-live parity）：
 * 同一个事件模型、同一套结构/价值区/入场判定，回测时逐根"回放"历史 K 线，实盘时喂实时 tick，
 * 唯一区别是数据源——杜绝未来函数、杜绝"回测好、实盘差"。
 *
 * 管道：Bar/Tick → AnalysisEngine（指标）→ StructureEngine（BOS/CHoCH）
 *      → ValueZoneEngine（价值区）→ EntryStateMachine（观察→到位→可开仓→失效）。
 * 方向（LONG/SHORT）与"可开仓"在此分离：方向来自融合层，本管道只回答"此刻此价能不能开"。
 */
sealed class MarketEvent {
    /** 新收盘 K 线（结构/指标仅在收盘根更新）。 */
    data class BarClosed(val symbol: String, val market: String, val timeframe: String,
                         val candle: Candle, val history: List<Candle>) : MarketEvent()
    /** 实时价格 tick（只推进入场状态机，不重算结构）。 */
    data class Tick(val symbol: String, val market: String, val price: Double, val time: Long) : MarketEvent()
}

/** 入场引擎参数（可开关、可调、可回退）。 */
data class EntryConfig(
    val tolAtr: Double = ValueZoneEngine.DEFAULT_TOL_ATR,
    val stopMult: Double = BattleLoopEngine.DEFAULT_STOP_MULT,
    val targetMult: Double = BattleLoopEngine.DEFAULT_TARGET_MULT,
    val minRR: Double = EntryStateMachine.DEFAULT_MIN_RR,
    val maxDistanceAtr: Double = ValueZoneEngine.DEFAULT_MAX_DISTANCE_ATR,
    /** 总开关：false 时退回旧的"现价入场"逻辑（可回退）。 */
    val valueZoneEnabled: Boolean = true,
    /** v5.0.17 目标分档配置（稳健 2R / 进取 3R 判定）。 */
    val tierCfg: TargetTier.TierConfig = TargetTier.TierConfig()
)

data class PipelineResult(
    val analysis: Analysis?,
    val structure: StructureState?,
    val zone: ValueZone?,
    val decision: EntryDecision
) {
    val ready: Boolean get() = decision.ready
}

object SignalPipeline {

    /**
     * 单周期完整评估（回测器主入口）。
     * @param closedCandles 截至当前的已收盘 K 线（最新一根为最新收盘）
     * @param livePrice 评估价（回放时为某根收盘价；实盘为实时价）
     * @param latest 用于止跌 K 线判定的最新收盘根（可空）
     * @param direction 指定方向（null 则用 AnalysisEngine 的方向）
     */
    fun evaluate(
        symbol: String, market: String, timeframe: String,
        closedCandles: List<Candle>, livePrice: Double,
        latest: Candle? = null, direction: String? = null,
        cfg: EntryConfig = EntryConfig()
    ): PipelineResult {
        val a = AnalysisEngine.analyze(symbol, market, timeframe, closedCandles)
        if (a == null) {
            return PipelineResult(null, null, null,
                EntryDecision(EntryDecision.DEAD, "NEUTRAL", livePrice, 0.0, 0.0, 0.0, 0.0,
                    emptyList(), emptyList(), "指标数据不足（K 线 < 220 根）", ""))
        }
        return evaluateAnalysis(a, closedCandles, livePrice, latest, direction, cfg)
    }

    /**
     * 基于已算出的 Analysis（实盘 VM 融合机会入口）：结构层可在有 K 线时附加。
     */
    fun evaluateAnalysis(
        a: Analysis,
        closedCandles: List<Candle>?,
        livePrice: Double,
        latest: Candle? = null,
        direction: String? = null,
        cfg: EntryConfig = EntryConfig()
    ): PipelineResult {
        val dir = direction ?: a.direction
        val structure = closedCandles?.takeIf { it.size >= 30 }?.let {
            runCatching { StructureEngine.evaluate(it, a.atr) }.getOrNull()
        }
        if (!cfg.valueZoneEnabled) {
            // 回退模式：不做价值区/状态机，保持旧"现价"口径（decision 仅占位）
            return PipelineResult(a, structure, null,
                EntryDecision(if (dir == "NEUTRAL") EntryDecision.DEAD else EntryDecision.READY,
                    dir, livePrice, a.stop, a.target, a.riskReward, 0.0,
                    listOf("现价入场（价值区已关闭）"), emptyList(), "", "回退模式"))
        }
        val zone = ValueZoneEngine.build(a, structure, dir, livePrice,
            cfg.tolAtr, cfg.stopMult, cfg.targetMult, cfg.maxDistanceAtr)
        val decision = EntryStateMachine.evaluate(zone, a, structure, livePrice, latest, cfg.minRR)
        return PipelineResult(a, structure, zone, decision)
    }
}
