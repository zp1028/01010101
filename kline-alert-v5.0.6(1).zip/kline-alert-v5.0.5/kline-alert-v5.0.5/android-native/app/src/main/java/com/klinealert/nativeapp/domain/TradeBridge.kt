package com.klinealert.nativeapp.domain

import com.klinealert.nativeapp.data.BinanceTradeClient
import com.klinealert.nativeapp.data.LocalStore
import com.klinealert.nativeapp.domain.TradeModels.TradeConfig
import com.klinealert.nativeapp.domain.TradeModels.TradeLink
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.min

/**
 * 跟单桥：本地持仓事件 → 币安下单。
 * 去重：localPositionId 占坑 + clientOrderId 幂等 + 品种方向冷却。
 */
class TradeBridge(
    private val store: LocalStore,
    private val client: BinanceTradeClient = BinanceTradeClient()
) {
    private val openInFlight = ConcurrentHashMap.newKeySet<String>()
    private val closeInFlight = ConcurrentHashMap.newKeySet<String>()
    private val symbolDirCooldown = ConcurrentHashMap<String, Long>()

    data class OpenRequest(
        val localPositionId: String,
        val symbol: String,
        val direction: String,
        val entry: Double,
        val stop: Double,
        val target: Double,
        val source: String,
        val note: String = "",
        val localCreatedAt: Long = System.currentTimeMillis()
    )

    sealed class Result {
        data class Ok(val link: TradeLink, val message: String) : Result()
        data class Skip(val reason: String) : Result()
        data class Err(val reason: String) : Result()
    }

    fun activeOpenCount(): Int =
        store.loadTradeLinks(TradeModels.STATUS_OPEN, 100).size +
            store.loadTradeLinks(TradeModels.STATUS_PENDING_OPEN, 100).size +
            store.loadTradeLinks(TradeModels.STATUS_CLOSING, 50).size

    /**
     * 尝试开仓。返回 Skip 表示去重/风控拒绝（非错误）。
     */
    suspend fun tryOpen(
        creds: BinanceTradeClient.Credentials,
        cfg: TradeConfig,
        req: OpenRequest,
        dualSide: Boolean
    ): Result {
        val id = req.localPositionId
        if (!openInFlight.add(id)) return Result.Skip("OPEN_SKIP_INFLIGHT")
        try {
            if (!cfg.enabled) return Result.Skip("OPEN_SKIP_DISABLED")
            store.loadTradeLink(id)?.let {
                return Result.Skip("OPEN_SKIP_EXISTS status=${it.status}")
            }
            if (activeOpenCount() >= cfg.maxFollowSlots)
                return Result.Skip("OPEN_SKIP_MAX_SLOTS")
            val sd = "${req.symbol}|${req.direction}"
            val cdUntil = symbolDirCooldown[sd] ?: 0L
            if (System.currentTimeMillis() < cdUntil)
                return Result.Skip("OPEN_SKIP_COOLDOWN")
            if (cfg.onlyAutoBattle && !req.source.contains("自动") && req.source != "auto")
                return Result.Skip("OPEN_SKIP_NOT_AUTO")
            // 仅跟随新建后 maxFollowAgeMs 内的仓，避免过时价位入场
            val age = System.currentTimeMillis() - req.localCreatedAt
            if (cfg.maxFollowAgeMs > 0 && age > cfg.maxFollowAgeMs)
                return Result.Skip("OPEN_SKIP_STALE age=${age / 1000}s > ${cfg.maxFollowAgeMs / 1000}s")

            val clientOid = TradeModels.clientOrderIdFor(id, "o")
            val pending = TradeLink(
                localPositionId = id, symbol = req.symbol, direction = req.direction,
                marginUsdt = cfg.marginUsdt, leverage = 0.0, status = TradeModels.STATUS_PENDING_OPEN,
                stopPrice = req.stop, targetPrice = req.target, clientOrderId = clientOid,
                source = req.source, openedAt = System.currentTimeMillis(), updatedAt = System.currentTimeMillis()
            )
            if (!store.tryInsertTradeLink(pending))
                return Result.Skip("OPEN_SKIP_EXISTS_RACE")

            val dayStart = java.util.Calendar.getInstance().apply {
                set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0)
                set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
            }.timeInMillis
            val dayClosed = store.loadTradeLinks(TradeModels.STATUS_CLOSED, 500).filter { it.closedAt >= dayStart }
            val dayPnl = dayClosed.sumOf { it.realizedPnlNet }
            if (dayPnl <= -kotlin.math.abs(cfg.dailyMaxLossUsdt))
                return fail(pending, "日亏损熔断：今日已实现 ${"%.2f".format(dayPnl)}U")
            if (dayClosed.size >= cfg.dailyMaxOpens)
                return fail(pending, "日开仓次数熔断：${dayClosed.size}/${cfg.dailyMaxOpens}")

            val (available, _, _) = client.balanceUsdt(creds)
            if (available < cfg.marginUsdt * 1.02)
                return fail(pending, "余额不足：可用 ${"%.2f".format(available)} < 本金 ${cfg.marginUsdt}")

            runCatching { client.ensureFilters(creds.testnet) }
            var lev = if (cfg.useMaxLeverage) {
                runCatching { client.maxLeverage(creds, req.symbol) }.getOrDefault(20)
            } else cfg.maxLeverageCap
            lev = min(lev, cfg.maxLeverageCap).coerceAtLeast(1)
            runCatching { client.setLeverage(creds, req.symbol, lev) }

            val px = req.entry.takeIf { it > 0 } ?: return fail(pending, "无效开仓价")
            val filt = client.filterOf(creds.testnet, req.symbol)
            val qtyRaw = TradeModels.quantity(cfg.marginUsdt, lev.toDouble(), px)
            val qtyStr = if (filt != null) client.formatByStep(qtyRaw, filt.qtyStep) else formatQty(qtyRaw)
            val qtyNum = qtyStr.toDoubleOrNull() ?: 0.0
            if (qtyStr == "0" || qtyNum <= 0)
                return fail(pending, "数量过小 qty=$qtyRaw")
            if (filt != null && qtyNum < filt.minQty)
                return fail(pending, "低于 minQty ${filt.minQty}")
            if (filt != null && qtyNum * px < filt.minNotional)
                return fail(pending, "低于最小名义 ${filt.minNotional}")

            val side = if (req.direction.equals("SHORT", true)) "SELL" else "BUY"
            val posSide = when {
                dualSide && req.direction.equals("SHORT", true) -> "SHORT"
                dualSide -> "LONG"
                else -> "BOTH"
            }
            val order = try {
                client.marketOpen(creds, req.symbol, side, qtyStr, posSide, clientOid)
            } catch (e: Exception) {
                return fail(pending, e.message ?: "开仓失败")
            }
            val avg = order.optString("avgPrice", "0").toDoubleOrNull()?.takeIf { it > 0 }
                ?: order.optString("price", "0").toDoubleOrNull() ?: px
            val execQty = order.optString("executedQty", qtyStr).toDoubleOrNull() ?: qtyRaw
            val orderId = order.optLong("orderId", 0L)
            val commission = order.optString("commission", "0").toDoubleOrNull() ?: 0.0
            val protectErrs = mutableListOf<String>()

            // v5.0.12 滑点保护：成交价距止损必须 ≥ 止损距离 × minStopGapRatio（不逼近/越过止损）
            if (req.stop > 0) {
                val tight = TradeModels.tightStopReason(px, req.stop, avg, cfg.minStopGapRatio)
                if (tight != null) {
                    if (cfg.rejectOnTightStop) {
                        // 已成交 → 立即对冲平掉，避免裸仓
                        runCatching {
                            client.marketClose(creds, req.symbol, if (side == "BUY") "SELL" else "BUY", qtyStr, posSide, TradeModels.clientOrderIdFor(id, "h"))
                        }
                        return fail(pending.copy(qty = execQty, avgEntry = avg, entryOrderId = orderId, commissionOpen = commission), "开仓拒收：$tight")
                    }
                    protectErrs += "⚠$tight"
                }
            }

            // 挂止盈止损：严格使用监控页 stop/target（与盈亏比一致），tick 圆整后挂单；失败重试 1 次
            val closeSide = if (side == "BUY") "SELL" else "BUY"
            val tick = filt?.priceTick ?: 0.01
            var stopOid = 0L
            var tpOid = 0L
            val stopPx = if (req.stop > 0) client.formatByStep(req.stop, tick) else "0"
            val tpPx = if (req.target > 0) client.formatByStep(req.target, tick) else "0"
            suspend fun placeSl(): Long {
                if (req.stop <= 0 || stopPx == "0") return 0L
                repeat(2) { attempt ->
                    try {
                        val j = client.stopMarketClose(
                            creds, req.symbol, closeSide, stopPx, posSide,
                            TradeModels.clientOrderIdFor(id, if (attempt == 0) "s" else "s1")
                        )
                        val oid = j.optLong("orderId", 0L)
                        if (oid > 0) return oid
                    } catch (e: Exception) {
                        if (attempt == 1) protectErrs += "止损挂单失败: ${e.message}"
                    }
                }
                return 0L
            }
            suspend fun placeTp(): Long {
                if (req.target <= 0 || tpPx == "0") return 0L
                repeat(2) { attempt ->
                    try {
                        val j = client.takeProfitMarketClose(
                            creds, req.symbol, closeSide, tpPx, posSide,
                            TradeModels.clientOrderIdFor(id, if (attempt == 0) "t" else "t1")
                        )
                        val oid = j.optLong("orderId", 0L)
                        if (oid > 0) return oid
                    } catch (e: Exception) {
                        if (attempt == 1) protectErrs += "止盈挂单失败: ${e.message}"
                    }
                }
                return 0L
            }
            stopOid = placeSl()
            tpOid = placeTp()
            val needSl = req.stop > 0
            val needTp = req.target > 0
            val protectOk = (!needSl || stopOid > 0) && (!needTp || tpOid > 0)
            val open = pending.copy(
                status = TradeModels.STATUS_OPEN,
                leverage = lev.toDouble(),
                qty = execQty,
                avgEntry = avg,
                entryOrderId = orderId,
                stopOrderId = stopOid,
                tpOrderId = tpOid,
                commissionOpen = commission,
                // v5.0.17 写回 tick 圆整后的实际挂单价（本地与交易所逐分一致，供对账/移动止损基准）
                stopPrice = stopPx.toDoubleOrNull() ?: req.stop,
                targetPrice = tpPx.toDoubleOrNull() ?: req.target,
                lastError = if (protectOk) "" else protectErrs.joinToString("; ").ifBlank { "止盈止损未完全挂上（对账将自动补挂）" },
                updatedAt = System.currentTimeMillis()
            )
            store.saveTradeLink(open)
            val msg = buildString {
                append("市价开仓成功 qty=$execQty lev=${lev}x")
                append(" · SL=${if (stopOid > 0) stopPx else "未挂"}")
                append(" · TP=${if (tpOid > 0) tpPx else "未挂"}")
                if (!protectOk) append(" ⚠保护单异常")
            }
            return Result.Ok(open, msg)
        } finally {
            openInFlight.remove(id)
        }
    }

    suspend fun tryClose(
        creds: BinanceTradeClient.Credentials,
        cfg: TradeConfig,
        localPositionId: String,
        reason: String,
        dualSide: Boolean
    ): Result {
        if (!closeInFlight.add(localPositionId)) return Result.Skip("CLOSE_SKIP_INFLIGHT")
        try {
            val link = store.loadTradeLink(localPositionId)
                ?: return Result.Skip("CLOSE_SKIP_NO_LINK")
            if (link.status != TradeModels.STATUS_OPEN)
                return Result.Skip("CLOSE_SKIP_NOT_OPEN status=${link.status}")
            val closing = link.copy(status = TradeModels.STATUS_CLOSING, updatedAt = System.currentTimeMillis())
            if (!store.updateTradeLinkIfStatus(closing, TradeModels.STATUS_OPEN))
                return Result.Skip("CLOSE_SKIP_RACE")

            // 撤条件单
            if (link.stopOrderId > 0) runCatching { client.cancelOrder(creds, link.symbol, link.stopOrderId) }
            if (link.tpOrderId > 0) runCatching { client.cancelOrder(creds, link.symbol, link.tpOrderId) }

            val side = if (link.direction.equals("SHORT", true)) "BUY" else "SELL"
            val posSide = when {
                dualSide && link.direction.equals("SHORT", true) -> "SHORT"
                dualSide -> "LONG"
                else -> "BOTH"
            }
            val qtyStr = formatQty(link.qty)
            val exitPx: Double
            val feeClose: Double
            if (link.qty > 0) {
                val order = try {
                    client.marketClose(
                        creds, link.symbol, side, qtyStr, posSide,
                        TradeModels.clientOrderIdFor(localPositionId, "c")
                    )
                } catch (e: Exception) {
                    // 可能已在交易所被条件单平掉
                    val flat = link.copy(
                        status = TradeModels.STATUS_CLOSED, closeReason = reason,
                        closedAt = System.currentTimeMillis(), lastError = e.message ?: "",
                        updatedAt = System.currentTimeMillis()
                    )
                    store.saveTradeLink(flat)
                    symbolDirCooldown["${link.symbol}|${link.direction}"] =
                        System.currentTimeMillis() + cfg.symbolDirCooldownMs
                    return Result.Ok(flat, "平仓异常（可能已平）：${e.message}")
                }
                exitPx = order.optString("avgPrice", "0").toDoubleOrNull()?.takeIf { it > 0 }
                    ?: order.optString("price", "0").toDoubleOrNull() ?: link.markPrice
                feeClose = order.optString("commission", "0").toDoubleOrNull() ?: 0.0
            } else {
                exitPx = link.markPrice
                feeClose = 0.0
            }
            val net = TradeModels.netPnl(link.qty, link.direction, link.avgEntry, exitPx, link.commissionOpen, feeClose)
            val closed = link.copy(
                status = TradeModels.STATUS_CLOSED,
                avgExit = exitPx,
                commissionClose = feeClose,
                realizedPnlNet = net,
                closeReason = reason,
                closedAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )
            store.saveTradeLink(closed)
            symbolDirCooldown["${link.symbol}|${link.direction}"] =
                System.currentTimeMillis() + cfg.symbolDirCooldownMs
            return Result.Ok(closed, "已平仓 净盈亏 ${"%.2f".format(net)}U")
        } finally {
            closeInFlight.remove(localPositionId)
        }
    }

    /**
     * v5.0.17 同步保护价（监控 stop/target 变更：分档保本/移动止损/手动改价/编辑都走这里）。
     * 强对账保证：
     *  1) 价格按品种 tickSize 圆整（与开仓一致，杜绝 %.6f 导致的拒单）；
     *  2) 每次移动用唯一 clientOrderId（修复旧版固定 s2/t2 二次移动被拒）；
     *  3) 撤旧复查确认（不重复挂单）；
     *  4) 挂新幂等重试 1 次；
     *  5) 任一必需保护单未挂上 → 明确返回 Err（不再静默 Ok 裸奔），并把圆整后实际价/oid 写回 link。
     */
    suspend fun syncProtective(
        creds: BinanceTradeClient.Credentials,
        localPositionId: String,
        stop: Double,
        target: Double,
        dualSide: Boolean
    ): Result {
        val link = store.loadTradeLink(localPositionId) ?: return Result.Skip("NO_LINK")
        if (link.status != TradeModels.STATUS_OPEN) return Result.Skip("NOT_OPEN")
        runCatching { client.ensureFilters(creds.testnet) }
        val filt = client.filterOf(creds.testnet, link.symbol)
        val tick = filt?.priceTick ?: 0.01
        val stopStr = if (stop > 0) client.formatByStep(stop, tick) else "0"
        val tpStr = if (target > 0) client.formatByStep(target, tick) else "0"
        val stopRounded = stopStr.toDoubleOrNull() ?: 0.0
        val tpRounded = tpStr.toDoubleOrNull() ?: 0.0
        val closeSide = if (link.direction.equals("SHORT", true)) "BUY" else "SELL"
        val posSide = posSideOf(link.direction, dualSide)

        // 撤旧并复查确认（撤不掉的那一侧保留旧单、不重复挂，避免双重保护单/裸奔）
        var stopOid = link.stopOrderId
        var tpOid = link.tpOrderId
        val errs = mutableListOf<String>()
        val slGone = cancelAndConfirmGone(creds, link.symbol, link.stopOrderId)
        val tpGone = cancelAndConfirmGone(creds, link.symbol, link.tpOrderId)

        val ver = (System.currentTimeMillis() % 100_000_000L).toString()
        if (stop > 0 && stopRounded > 0) {
            if (slGone) {
                val (oid, err) = placeProtective(creds, link.symbol, closeSide, posSide, true,
                    stopStr, TradeModels.clientOrderIdFor(localPositionId, "s$ver"))
                stopOid = oid
                if (oid <= 0) errs += "止损挂单失败：$err"
            } else {
                errs += "旧止损单未撤销，保留旧单未重复挂（请在对账中自愈）"
            }
        } else {
            stopOid = 0L
        }
        if (target > 0 && tpRounded > 0) {
            if (tpGone) {
                val (oid, err) = placeProtective(creds, link.symbol, closeSide, posSide, false,
                    tpStr, TradeModels.clientOrderIdFor(localPositionId, "t$ver"))
                tpOid = oid
                if (oid <= 0) errs += "止盈挂单失败：$err"
            } else {
                errs += "旧止盈单未撤销，保留旧单未重复挂（请在对账中自愈）"
            }
        } else {
            tpOid = 0L
        }

        val needSl = stop > 0
        val needTp = target > 0
        val ok = (!needSl || stopOid > 0) && (!needTp || tpOid > 0)
        val now = System.currentTimeMillis()
        val u = link.copy(
            stopPrice = stopRounded, targetPrice = tpRounded,
            stopOrderId = stopOid, tpOrderId = tpOid,
            lastError = if (ok) "" else errs.joinToString("；").ifBlank { "保护单未完全挂上" },
            updatedAt = now
        )
        store.saveTradeLink(u)
        return if (ok) {
            Result.Ok(u, "保护单已更新 SL=${if (needSl) stopStr else "无"} TP=${if (needTp) tpStr else "无"}")
        } else {
            Result.Err("${link.symbol} 保护单未完全挂上（${errs.joinToString("；")}），存在裸奔风险，请检查网络/权限后重试")
        }
    }

    /** 挂一张保护单（幂等重试 1 次；同 clientOrderId 重复时币安会拒绝，不会产生第二张）。返回 (orderId, error)。 */
    private suspend fun placeProtective(
        creds: BinanceTradeClient.Credentials,
        symbol: String,
        closeSide: String,
        posSide: String,
        isStop: Boolean,
        priceStr: String,
        clientOid: String
    ): Pair<Long, String?> {
        var lastErr = "未知错误"
        repeat(2) { attempt ->
            try {
                val j = if (isStop) client.stopMarketClose(creds, symbol, closeSide, priceStr, posSide, if (attempt == 0) clientOid else clientOid + "r")
                else client.takeProfitMarketClose(creds, symbol, closeSide, priceStr, posSide, if (attempt == 0) clientOid else clientOid + "r")
                val oid = j.optLong("orderId", 0L)
                if (oid > 0) return oid to null
                lastErr = "返回 orderId=0"
            } catch (e: Exception) {
                lastErr = e.message ?: "挂单异常"
            }
        }
        return 0L to lastErr
    }

    /** 撤单并复查 openOrders 确认该单已消失（容忍 -2013 不存在）。true=已无（可安全挂新）。 */
    private suspend fun cancelAndConfirmGone(creds: BinanceTradeClient.Credentials, symbol: String, orderId: Long): Boolean {
        if (orderId <= 0) return true
        runCatching { client.cancelOrder(creds, symbol, orderId) }
        return runCatching {
            val arr = client.openOrders(creds, symbol)
            for (i in 0 until arr.length()) {
                if (arr.getJSONObject(i).optLong("orderId", -1L) == orderId) {
                    // 仍在：再撤一次后复查
                    runCatching { client.cancelOrder(creds, symbol, orderId) }
                    val arr2 = client.openOrders(creds, symbol)
                    for (j in 0 until arr2.length()) {
                        if (arr2.getJSONObject(j).optLong("orderId", -1L) == orderId) return false
                    }
                    return true
                }
            }
            true
        }.getOrDefault(true)   // 查询失败时乐观放行，交由定期 reconcile 自愈兜底
    }

    private fun posSideOf(direction: String, dualSide: Boolean): String = when {
        dualSide && direction.equals("SHORT", true) -> "SHORT"
        dualSide -> "LONG"
        else -> "BOTH"
    }

    private fun priceMatches(actual: Double, want: Double, tick: Double): Boolean =
        want > 0 && kotlin.math.abs(actual - want) < tick * 0.6

    /**
     * v5.0.17 保护单自愈对账：每 20s 随主对账跑。
     * 对每个 OPEN 仓位，按方向核对 SL/TP：缺失补挂、价格漂移撤旧重挂、同方向多余单清理。
     * 本地（link）与交易所（openOrders）逐分一致后返回，修复 App 外删单/挂单失败/重复单。
     */
    suspend fun reconcileProtectiveOrders(
        creds: BinanceTradeClient.Credentials,
        dualSide: Boolean
    ): List<String> {
        val notes = mutableListOf<String>()
        val opens = store.loadTradeLinks(TradeModels.STATUS_OPEN, 100)
        if (opens.isEmpty()) return notes
        runCatching { client.ensureFilters(creds.testnet) }
        for (link in opens) {
            val sym = link.symbol
            val arr = runCatching { client.openOrders(creds, sym) }.getOrNull() ?: continue
            val cond = (0 until arr.length()).map { arr.getJSONObject(it) }.filter {
                val t = it.optString("type")
                (t == "STOP_MARKET" || t == "TAKE_PROFIT_MARKET")
            }
            val closeSide = if (link.direction.equals("SHORT", true)) "BUY" else "SELL"
            val posSide = posSideOf(link.direction, dualSide)
            val tick = client.filterOf(creds.testnet, sym)?.priceTick ?: 0.01

            // 止损侧（link.stopPrice<=0 表示不需要，撤掉多余单）
            val newSl = reconcileOneSide(creds, link, cond, closeSide, posSide, true,
                link.stopPrice, link.stopOrderId, tick, notes)
            // 止盈侧
            val newTp = reconcileOneSide(creds, link, cond, closeSide, posSide, false,
                link.targetPrice, link.tpOrderId, tick, notes)
            if (newSl != null && (newSl != link.stopOrderId)) {
                store.saveTradeLink(link.copy(stopOrderId = newSl, updatedAt = System.currentTimeMillis()))
            }
            if (newTp != null && (newTp != link.tpOrderId)) {
                // 读最新（上一行可能已 save），避免覆盖 stopOrderId
                val latest = store.loadTradeLink(link.localPositionId) ?: link
                store.saveTradeLink(latest.copy(tpOrderId = newTp, updatedAt = System.currentTimeMillis()))
            }
        }
        return notes
    }

    /** 核对单侧保护单。返回该侧最终应有的 orderId（null=本轮无法判定，保持 link 原值）。 */
    private suspend fun reconcileOneSide(
        creds: BinanceTradeClient.Credentials,
        link: TradeLink,
        cond: List<org.json.JSONObject>,
        closeSide: String,
        posSide: String,
        isStop: Boolean,
        wantPrice: Double,
        wantOid: Long,
        tick: Double,
        notes: MutableList<String>
    ): Long? {
        val type = if (isStop) "STOP_MARKET" else "TAKE_PROFIT_MARKET"
        val label = if (isStop) "止损" else "止盈"
        // 同方向、同持仓侧的该类条件单（属于这个仓位的候选）
        val mine = cond.filter {
            it.optString("type") == type && it.optString("side") == closeSide &&
                it.optString("positionSide") == posSide
        }
        if (wantPrice <= 0) {
            // 本地不需要该保护单：清理同方向多余单
            mine.forEach { runCatching { client.cancelOrder(creds, link.symbol, it.optLong("orderId", 0L)) } }
            if (mine.isNotEmpty()) notes += "${link.symbol} 清理多余${label}单 ${mine.size} 张"
            return 0L
        }
        val wantStr = client.formatByStep(wantPrice, tick)
        val wantNum = wantStr.toDoubleOrNull() ?: wantPrice
        val correct = mine.firstOrNull {
            priceMatches(it.optString("stopPrice", "0").toDoubleOrNull() ?: -1.0, wantNum, tick)
        }
        if (correct != null) {
            // 已有正确价的单：清理其它多余单，oid 归一到正确单
            val correctOid = correct.optLong("orderId", 0L)
            mine.filter { it.optLong("orderId", 0L) != correctOid }.forEach {
                runCatching { client.cancelOrder(creds, link.symbol, it.optLong("orderId", 0L)) }
                notes += "${link.symbol} 清理重复${label}单"
            }
            return correctOid
        }
        // 没有正确价单：撤掉全部旧的（漂移/错价），再补挂正确价
        mine.forEach { runCatching { client.cancelOrder(creds, link.symbol, it.optLong("orderId", 0L)) } }
        val drifted = mine.isNotEmpty()
        val ver = (System.currentTimeMillis() % 100_000_000L).toString()
        val oidPrefix = if (isStop) "rs$ver" else "rt$ver"
        val (oid, err) = placeProtective(creds, link.symbol, closeSide, posSide, isStop, wantStr,
            TradeModels.clientOrderIdFor(link.localPositionId, oidPrefix))
        if (oid > 0) {
            notes += "${link.symbol} ${if (drifted) "修正漂移$label" else "补挂缺失$label"} → $wantStr"
        } else {
            notes += "${link.symbol} ⚠${label}单自愈失败：$err"
        }
        return oid.takeIf { it > 0 } ?: wantOid.takeIf { !drifted }
    }

    private fun fail(pending: TradeLink, msg: String): Result {
        val f = pending.copy(status = TradeModels.STATUS_FAILED, lastError = msg, updatedAt = System.currentTimeMillis())
        store.saveTradeLink(f)
        return Result.Err(msg)
    }

    private fun formatQty(q: Double): String {
        if (q <= 0) return "0"
        return String.format(java.util.Locale.US, "%.3f", q).trimEnd('0').trimEnd('.')
    }

    private fun formatPrice(p: Double): String =
        String.format(java.util.Locale.US, "%.6f", p).trimEnd('0').trimEnd('.')

    /**
     * 对账：OPEN 但交易所无仓 → CLOSED(external)；刷新标记价与未实现盈亏。
     */
    suspend fun reconcileAndRefreshMarks(creds: BinanceTradeClient.Credentials, dualSide: Boolean = true): List<String> {
        val notes = mutableListOf<String>()
        val opens = store.loadTradeLinks(TradeModels.STATUS_OPEN, 100)
        if (opens.isEmpty()) return notes
        val risks = runCatching { client.positionRisk(creds) }.getOrNull() ?: return notes
        val bySym = mutableMapOf<String, org.json.JSONObject>()
        for (i in 0 until risks.length()) {
            val o = risks.getJSONObject(i)
            val amt = o.optString("positionAmt", "0").toDoubleOrNull() ?: 0.0
            if (kotlin.math.abs(amt) > 0) bySym[o.optString("symbol")] = o
        }
        for (link in opens) {
            val o = bySym[link.symbol]
            if (o == null) {
                // 外部已平：撤掉可能残留的保护单（closePosition 单通常随仓位失效，但显式清理更干净）
                if (link.stopOrderId > 0) runCatching { client.cancelOrder(creds, link.symbol, link.stopOrderId) }
                if (link.tpOrderId > 0) runCatching { client.cancelOrder(creds, link.symbol, link.tpOrderId) }
                val closed = link.copy(
                    status = TradeModels.STATUS_CLOSED,
                    stopOrderId = 0L, tpOrderId = 0L,
                    closeReason = TradeModels.CLOSE_EXTERNAL,
                    closedAt = System.currentTimeMillis(),
                    updatedAt = System.currentTimeMillis(),
                    lastError = "对账：交易所无持仓"
                )
                store.saveTradeLink(closed)
                notes += "${link.symbol} 外部已平 → CLOSED"
                symbolDirCooldown["${link.symbol}|${link.direction}"] =
                    System.currentTimeMillis() + 60_000L
            } else {
                val mark = o.optString("markPrice", "0").toDoubleOrNull() ?: 0.0
                val upnl = o.optString("unRealizedProfit", "0").toDoubleOrNull() ?: 0.0
                val amt = kotlin.math.abs(o.optString("positionAmt", "0").toDoubleOrNull() ?: 0.0)
                store.saveTradeLink(
                    link.copy(
                        markPrice = mark, unrealizedPnl = upnl,
                        qty = if (amt > 0) amt else link.qty,
                        updatedAt = System.currentTimeMillis()
                    )
                )
            }
        }
        // v5.0.17 仍有仓的 link：保护单缺失补挂 / 漂移修正 / 多余清理（本地与交易所逐分一致）
        notes += runCatching { reconcileProtectiveOrders(creds, dualSide) }.getOrDefault(emptyList())
        return notes
    }
}
