package com.klinealert.nativeapp.domain

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.round

/**
 * v5.0.16 出场 / 持仓状态机（与 [EntryStateMachine] 对称）：
 * 入场管"何时开"（等价值区 + 止跌），本类管"怎么拿、何时走"。
 *
 * 核心理念：到第一目标（3×ATR）**不机械平仓**，而是判断趋势是否还能延续：
 *  - 能延续：全仓移动止损（首次先保本+手续费，之后取"结构位与吊灯"更优保护位），
 *    目标上移到下一结构位，标记「延续 ×n」；
 *  - 不能延续：在目标位止盈结束；
 *  - 任意时刻：打破移动止损 / 反向 CHoCH 确认 / 延续后时间止损 → 立即结束。
 *
 * 纯函数、无状态：持仓状态（trailCount、bestPrice、K 线计数）由 VM/ReplayEngine 持有并传入。
 * 本类只做判定，输出 [ExitDecision]。
 */
object ExitStateMachine {

    const val ACTION_HOLD = "HOLD"                      // 继续持有，不动
    const val ACTION_RAISE_STOP = "RAISE_STOP"          // 延续成立：移动止损 + 上移目标
    const val ACTION_EXIT_TARGET = "EXIT_TARGET"        // 到目标且不能延续 → 止盈结束
    const val ACTION_EXIT_STOP = "EXIT_STOP"            // 打破止损 / 移动止损
    const val ACTION_EXIT_REVERSE = "EXIT_REVERSE"      // 反向 CHoCH 结构反转
    const val ACTION_EXIT_TIMEOUT = "EXIT_TIMEOUT"      // 延续后时间止损

    const val STAGE_INITIAL = "INITIAL"                 // 初始仓（朝第一目标走）
    const val STAGE_BREAKEVEN = "BREAKEVEN"             // 进取档已到 2R、止损锁保本（冲 3R 中）
    const val STAGE_TRAILING = "TRAILING"               // 已进入延续（锁定保本/结构位）

    const val MAX_TRAIL = 3                             // 延续次数上限（之后只收紧保护、不再上移目标）
    const val TIMEOUT_BARS = 16                         // 延续后 N 根 K 线无新进展 → 时间止损
    const val BREAK_EVEN_BUFFER_PCT = 0.0005            // 保本缓冲 0.05%（覆盖双边手续费 + 滑点）
    const val SWING_BUFFER_ATR = 0.2                    // 结构位缓冲
    const val CHANDELIER_ATR = 1.5                      // 吊灯回撤倍数（与 BattleLoopEngine.DEFAULT_TRAIL_ATR 一致）
    const val MIN_REMAINING_R = 1.2                     // 延续后到下一目标至少还需 1.2R
    const val VOL_SPIKE = 1.5                           // 放量阈值（与结构突破一致）
    const val RSI_EXTREME = 75.0                        // 超买阈值（做空镜像用 25）
    const val CONTINUE_SCORE = 60                       // 延续成立最低分

    data class ExitConfig(
        val continuationEnabled: Boolean = true,
        val stopMult: Double = 2.0,
        val targetMult: Double = 3.0,
        val breakEvenBufferPct: Double = BREAK_EVEN_BUFFER_PCT,
        val swingBufferAtr: Double = SWING_BUFFER_ATR,
        val chandelierAtr: Double = CHANDELIER_ATR,
        val minRemainingR: Double = MIN_REMAINING_R,
        val maxTrail: Int = MAX_TRAIL,
        val timeoutBars: Int = TIMEOUT_BARS,
        // v5.0.17 目标分档（方案甲）
        val tier: String = TargetTier.STEADY,              // 稳健档 2R 落袋 / 进取档 2R 保本冲 3R
        val breakEvenR: Double = TargetTier.DEFAULT_BREAK_EVEN_R // 进取档到该 R 移动保本
    )

    data class ExitDecision(
        val action: String,
        val newStop: Double = 0.0,
        val newTarget: Double = 0.0,
        val trailCount: Int = 0,
        val stage: String = STAGE_INITIAL,
        val score: Int = 0,
        val breakEvenDone: Boolean = false,             // v5.0.17 进取档保本是否已完成
        val reasons: List<String> = emptyList(),
        val label: String = ""
    ) {
        val isExit: Boolean
            get() = action == ACTION_EXIT_TARGET || action == ACTION_EXIT_STOP ||
                action == ACTION_EXIT_REVERSE || action == ACTION_EXIT_TIMEOUT
        val isRaise: Boolean get() = action == ACTION_RAISE_STOP
    }

    /**
     * 评估当前持仓的出场动作（每 tick 或每根收盘 K 线调用）。
     *
     * @param trailCount    已延续次数（0=初始仓，1=已延续一次…）
     * @param barsSinceTrail 自上次移动止损（或开仓）以来经过的 K 线数，用于时间止损
     * @param bestPrice     持仓期极值（LONG 最高 / SHORT 最低），用于吊灯位
     * @param structure     截至最近收盘 K 线的结构状态（可空）
     * @param latest        最近一根已收盘 K 线（站稳/形态用，可空则退化为 livePrice）
     * @param a             最近收盘 K 线的指标快照（可空）
     */
    fun evaluate(
        direction: String,
        entry: Double,
        stop: Double,
        target: Double,
        livePrice: Double,
        a: Analysis?,
        structure: StructureState?,
        latest: Candle?,
        trailCount: Int,
        barsSinceTrail: Int,
        bestPrice: Double,
        breakEvenDone: Boolean = false,
        cfg: ExitConfig = ExitConfig()
    ): ExitDecision {
        if (livePrice <= 0 || !livePrice.isFinite()) return hold(trailCount, breakEvenDone)
        val long = direction != "SHORT"
        val atr = a?.atr?.takeIf { it > 0 }
        if (!cfg.continuationEnabled || atr == null) return hold(trailCount, breakEvenDone)

        // 1) 打破止损（含移动止损）→ 立即结束（tick 级，最优先保护）
        if (stop > 0) {
            val hitStop = if (long) livePrice <= stop else livePrice >= stop
            if (hitStop) {
                return ExitDecision(
                    ACTION_EXIT_STOP, trailCount = trailCount, stage = stageOf(trailCount, breakEvenDone),
                    breakEvenDone = breakEvenDone,
                    label = if (trailCount > 0) "移动止损离场（延续×$trailCount）" else "止损离场",
                    reasons = listOf("价格触及止损 ${r4(stop)}")
                )
            }
        }

        // 2) 反向 CHoCH 确认 → 提前结束（不等价格回止损）
        structure?.recentEvent?.takeIf { it.valid == StructureEvent.CONFIRMED && it.isReversal }?.let { ev ->
            val against = if (long) ev.type == StructureEvent.CHOCH_DOWN else ev.type == StructureEvent.CHOCH_UP
            if (against) {
                return ExitDecision(
                    ACTION_EXIT_REVERSE, trailCount = trailCount, stage = stageOf(trailCount, breakEvenDone),
                    breakEvenDone = breakEvenDone,
                    label = "结构反转离场（CHoCH，延续×$trailCount）",
                    reasons = listOf("反向 CHoCH 确认 @${r4(ev.level)}")
                )
            }
        }

        // 3) 时间止损：进入延续后，超过 timeoutBars 根 K 线无新进展
        if (trailCount >= 1 && barsSinceTrail > cfg.timeoutBars) {
            return ExitDecision(
                ACTION_EXIT_TIMEOUT, trailCount = trailCount, stage = STAGE_TRAILING,
                breakEvenDone = breakEvenDone,
                label = "时间止损（延续×$trailCount 后 ${cfg.timeoutBars} 根无新进展）",
                reasons = listOf("趋势未继续兑现")
            )
        }

        // 3.5) v5.0.17 进取档：价格到 2R 保本线（尚未保本）→ 止损移保本（tick 级，只收紧一次）
        if (cfg.tier == TargetTier.AGGRESSIVE && !breakEvenDone) {
            val beLine = TargetTier.breakEvenPrice(long, entry, stop, cfg.breakEvenR, atr)
            if (beLine > 0) {
                val reachedBE = if (long) livePrice >= beLine else livePrice <= beLine
                if (reachedBE) {
                    val be = if (long) entry * (1 + cfg.breakEvenBufferPct) else entry * (1 - cfg.breakEvenBufferPct)
                    if (isBetter(long, be, stop)) {
                        return ExitDecision(
                            ACTION_RAISE_STOP, newStop = be, newTarget = target,
                            trailCount = trailCount, stage = STAGE_BREAKEVEN, breakEvenDone = true,
                            label = "进取档到 ${r1(cfg.breakEvenR)}R：止损移保本 ${r4(be)}，继续冲 ${r1(targetR(long, entry, target, cfg.stopMult, atr))}R",
                            reasons = listOf("到 ${r1(cfg.breakEvenR)}R 锁定保本")
                        )
                    }
                }
            }
        }

        // 4) 到达目标？用"收盘确认"而非瞬时 tick（避免插针假突破），无 K 线时退化为 livePrice
        val ref = latest?.close ?: livePrice
        val reached = if (long) ref >= target else ref <= target
        if (!reached || target <= 0) return hold(trailCount, breakEvenDone)

        // 4.1) v5.0.17 稳健档：到 2R 直接落袋，不做延续（主打高胜率）
        if (cfg.tier == TargetTier.STEADY) {
            return ExitDecision(
                ACTION_EXIT_TARGET, trailCount = trailCount,
                stage = STAGE_INITIAL, breakEvenDone = breakEvenDone,
                label = "稳健档到 ${r1(targetR(long, entry, target, cfg.stopMult, atr))}R 止盈落袋",
                reasons = listOf("收盘到达稳健目标 ${r4(target)}")
            )
        }

        // 已达延续上限：不再上移目标，仅在更有利位置收紧保护（不增 trailCount）
        if (trailCount >= cfg.maxTrail) {
            val tighten = protectiveStop(long, entry, stop, bestPrice, livePrice, structure, atr, cfg, firstMove = false)
            return if (tighten > 0 && isBetter(long, tighten, stop)) {
                ExitDecision(
                    ACTION_RAISE_STOP, newStop = tighten, newTarget = target,
                    trailCount = trailCount, stage = STAGE_TRAILING, breakEvenDone = breakEvenDone,
                    label = "已达延续上限×${cfg.maxTrail}，收紧保护至 ${r4(tighten)}",
                    reasons = listOf("止损收紧")
                )
            } else hold(trailCount, breakEvenDone)
        }

        // 5) 延续评估（进取档到 3R 后判断能否继续奔跑）
        val verdict = evaluateContinuation(long, livePrice, target, a, structure, latest, atr)
        if (!verdict.pass) {
            return ExitDecision(
                ACTION_EXIT_TARGET, trailCount = trailCount, stage = stageOf(trailCount, breakEvenDone),
                breakEvenDone = breakEvenDone, score = verdict.score, reasons = verdict.reasons,
                label = if (trailCount == 0) "进取档到 ${r1(cfg.targetMult)}R，趋势不延续 → 止盈结束"
                else "延续×$trailCount 后动能衰竭 → 止盈结束"
            )
        }

        // 6) 延续成立：移动止损 + 上移目标
        val firstMove = trailCount == 0
        val newStop = protectiveStop(long, entry, stop, bestPrice, livePrice, structure, atr, cfg, firstMove)
        if (newStop <= 0 || !isBetter(long, newStop, stop)) {
            return ExitDecision(
                ACTION_EXIT_TARGET, trailCount = trailCount, stage = stageOf(trailCount, breakEvenDone),
                breakEvenDone = breakEvenDone, score = verdict.score,
                reasons = verdict.reasons + "无法给出更优保护位",
                label = "到达止盈，无可上移保护位 → 止盈结束"
            )
        }
        val newTarget = nextTarget(long, livePrice, target, structure, atr, cfg)
        val oneR = cfg.stopMult * atr
        val room = if (long) newTarget - livePrice else livePrice - newTarget
        if (newTarget <= 0 || room < cfg.minRemainingR * oneR) {
            return ExitDecision(
                ACTION_EXIT_TARGET, trailCount = trailCount, stage = stageOf(trailCount, breakEvenDone),
                breakEvenDone = breakEvenDone, score = verdict.score,
                reasons = verdict.reasons + "剩余空间不足（${r2(room / oneR)}R）",
                label = "到达止盈，前方无足够空间 → 止盈结束"
            )
        }
        val nextCount = trailCount + 1
        return ExitDecision(
            ACTION_RAISE_STOP, newStop = newStop, newTarget = newTarget,
            trailCount = nextCount, stage = STAGE_TRAILING, score = verdict.score,
            breakEvenDone = breakEvenDone,
            reasons = verdict.reasons,
            label = if (firstMove) "延续×1：止损上移保本至 ${r4(newStop)}，目标上移至 ${r4(newTarget)}"
            else "延续×$nextCount：止损上移结构位至 ${r4(newStop)}，目标上移至 ${r4(newTarget)}"
        )
    }

    // ------------------------------------------------------------------ 延续评估

    private class Verdict(val pass: Boolean, val score: Int, val reasons: List<String>)

    /**
     * 到目标后判断趋势能否延续。
     * 一票否决（反转结构 / 放量滞涨 / 强压力+超买）优先；无否决且综合分 ≥ [CONTINUE_SCORE] 才延续。
     */
    private fun evaluateContinuation(
        long: Boolean,
        price: Double,
        target: Double,
        a: Analysis?,
        structure: StructureState?,
        latest: Candle?,
        atr: Double
    ): Verdict {
        val veto = mutableListOf<String>()
        val support = mutableListOf<String>()
        var score = 0

        // —— 否决项 ——
        // 1 反向 CHoCH（外层也查，此处再判一次以保留到评估理由）
        structure?.recentEvent?.takeIf { it.valid == StructureEvent.CONFIRMED && it.isReversal }?.let { ev ->
            val against = if (long) ev.type == StructureEvent.CHOCH_DOWN else ev.type == StructureEvent.CHOCH_UP
            if (against) veto += "反向 CHoCH 已确认"
        }
        // 2 目标位放量滞涨 / 长上影（做空镜像：放量承接 / 长下影）
        if (latest != null && a != null && a.volRatio >= VOL_SPIKE) {
            val body = latest.close - latest.open
            val bodyAbs = abs(body)
            if (long) {
                val upperWick = latest.high - maxOf(latest.open, latest.close)
                if (body < 0 || upperWick >= maxOf(0.5 * atr, 2 * bodyAbs)) veto += "目标位放量滞涨/长上影"
            } else {
                val lowerWick = minOf(latest.open, latest.close) - latest.low
                if (body > 0 || lowerWick >= maxOf(0.5 * atr, 2 * bodyAbs)) veto += "目标位放量承接/长下影"
            }
        }
        // 3 强压力 + RSI 超买（做空镜像：强支撑 + RSI 超卖）
        a?.rsi14?.let { rsi ->
            if (long) {
                val atRes = a.resistance != null && abs(price - a.resistance!!) <= atr * 0.5
                if (atRes && rsi >= RSI_EXTREME) veto += "强压力 + RSI 超买(${rsi.toInt()})"
            } else {
                val atSup = a.support != null && abs(a.support!! - price) <= atr * 0.5
                if (atSup && rsi <= (100 - RSI_EXTREME)) veto += "强支撑 + RSI 超卖(${rsi.toInt()})"
            }
        }

        // —— 成立项 ——
        // 结构顺势（trend + 顺势 BOS）
        if (structure != null) {
            val trendOk = if (long) structure.trend == StructureEngine.UP else structure.trend == StructureEngine.DOWN
            if (trendOk) { score += 40; support += "趋势结构 ${structure.trend}" }
            structure.recentEvent?.takeIf { it.valid == StructureEvent.CONFIRMED }?.let { ev ->
                val bosSame = if (long) ev.type == StructureEvent.BOS_UP else ev.type == StructureEvent.BOS_DOWN
                if (bosSame) { score += 20; support += "顺势 BOS" }
            }
        }
        // 收盘站稳目标
        if (latest != null) {
            val hold = if (long) latest.close >= target else latest.close <= target
            if (hold) { score += 15; support += "收盘站稳目标" }
        }
        // 动能未衰竭：MACD 顺向；KDJ 未在极值区反向
        if (a != null) {
            a.macdHist?.let { h ->
                if (if (long) h >= 0 else h <= 0) { score += 15; support += "MACD 顺向" }
            }
            val k = a.kdjK; val d = a.kdjD
            if (k != null && d != null) {
                val kdjOk = if (long) !(k >= 80 && k < d) else !(k <= 20 && k > d)
                if (kdjOk) { score += 10; support += "KDJ 未反向" }
            }
        }
        if (veto.isEmpty()) { score += 10; support += "无否决信号" }

        val pass = veto.isEmpty() && score >= CONTINUE_SCORE
        val reasons = if (veto.isNotEmpty()) veto else support
        return Verdict(pass, score.coerceIn(0, 100), reasons)
    }

    // ------------------------------------------------------------------ 止损 / 目标

    /**
     * 计算更优的新止损（只往有利方向移动，由 [isBetter] 保证不回调）：
     *  - 首次：保本位（entry ± 手续费缓冲）强制入候选，保证最差不亏；
     *  - 吊灯位：极值回撤 chandelierAtr×ATR；
     *  - 结构位：最近 swing 低/高 ± swingBufferAtr×ATR（须在当前价正确侧）；
     * 取对持仓最有利者（LONG 取最高、SHORT 取最低）。
     */
    private fun protectiveStop(
        long: Boolean,
        entry: Double,
        stop: Double,
        bestPrice: Double,
        livePrice: Double,
        structure: StructureState?,
        atr: Double,
        cfg: ExitConfig,
        firstMove: Boolean
    ): Double {
        val candidates = mutableListOf(stop)
        if (firstMove) {
            val be = if (long) entry * (1 + cfg.breakEvenBufferPct) else entry * (1 - cfg.breakEvenBufferPct)
            candidates += be
        }
        if (bestPrice > 0) {
            val ch = if (long) bestPrice - cfg.chandelierAtr * atr else bestPrice + cfg.chandelierAtr * atr
            candidates += ch
        }
        val swing = if (long) structure?.lastSwingLow?.price else structure?.lastSwingHigh?.price
        if (swing != null && swing > 0) {
            val sp = if (long) swing - cfg.swingBufferAtr * atr else swing + cfg.swingBufferAtr * atr
            val validSide = if (long) sp < livePrice else sp > livePrice
            if (validSide) candidates += sp
        }
        val valid = candidates.filter { it > 0 }
        return if (valid.isEmpty()) 0.0 else if (long) valid.max() else valid.min()
    }

    /**
     * 下一个延伸目标：优先顺势前方、距现价 ≥ minRemainingR×1R 的最近 swing；
     * 没有则给最小延伸空间（保证至少 1.2R 可跑）。
     */
    private fun nextTarget(
        long: Boolean,
        livePrice: Double,
        @Suppress("UNUSED_PARAMETER") oldTarget: Double,
        structure: StructureState?,
        atr: Double,
        cfg: ExitConfig
    ): Double {
        val minRoom = cfg.minRemainingR * cfg.stopMult * atr
        val swings = structure?.swings
        if (swings != null) {
            if (long) {
                val t = swings.filter { it.isHigh }.map { it.price }
                    .filter { it > livePrice + minRoom }.minOrNull()
                if (t != null) return t
            } else {
                val t = swings.filter { !it.isHigh }.map { it.price }
                    .filter { it > 0 && it < livePrice - minRoom }.maxOrNull()
                if (t != null) return t
            }
        }
        return if (long) livePrice + minRoom else livePrice - minRoom
    }

    private fun isBetter(long: Boolean, candidate: Double, current: Double): Boolean =
        if (current <= 0) candidate > 0
        else if (long) candidate > current + 1e-12 else candidate < current - 1e-12

    private fun stageOf(trailCount: Int, breakEvenDone: Boolean = false): String = when {
        trailCount > 0 -> STAGE_TRAILING
        breakEvenDone -> STAGE_BREAKEVEN
        else -> STAGE_INITIAL
    }

    private fun hold(trailCount: Int, breakEvenDone: Boolean = false): ExitDecision =
        ExitDecision(ACTION_HOLD, trailCount = trailCount, stage = stageOf(trailCount, breakEvenDone),
            breakEvenDone = breakEvenDone)

    /**
     * 目标价对应的 R 倍数（1R = stopMult×ATR，与 [BattleLoopEngine.buildEntry] 的入场口径一致）。
     * 用于 UI 标签显示真实档位（2R 稳健 / 3R 进取），避免沿用写死的 targetMult。
     */
    private fun targetR(long: Boolean, entry: Double, target: Double, stopMult: Double, atr: Double): Double {
        val oneR = stopMult * atr
        if (oneR <= 0 || entry <= 0 || target <= 0) return 0.0
        return if (long) (target - entry) / oneR else (entry - target) / oneR
    }

    private fun r4(v: Double): String = String.format(java.util.Locale.US, "%.4f", v)
    private fun r2(v: Double): String = String.format(java.util.Locale.US, "%.1f", v)
    private fun r1(v: Double): String = String.format(java.util.Locale.US, "%.1f", v)
}
