package com.klinealert.nativeapp.domain

/**
 * v5.0.15 回放器（Replay Engine）：回测/实盘同构管道的历史验证。
 *
 * 用同一份历史 K 线，并排跑两种入场，只改变入场位置这一个变量：
 *  - 价值区入场（实验组，本版）：结构 BOS 给方向 → 等价格回踩价值区 + 止跌扳机 → 按支撑/压力价开。
 *  - 现价入场（对照组，旧逻辑）：方向信号出现即按当根收盘价开。
 *
 * 两臂统一用 Triple Barrier（Lopez de Prado）结算：
 *  - 上轨=止盈、下轨=止损、垂直屏障=最大持仓根数；同一根同时触及，保守判止损先。
 *  - 1R = 入场到止损的实际风险距离（v5.0.17 统一口径），止盈 = 目标盈亏比 × R（稳健 2R / 进取 3R）。
 * 平仓后冷却若干根，避免同一区间重复计数。
 *
 * 诚实原则：样本不足明确标注；纯函数、确定性，可作为单测与线上"回测"按钮的同一实现。
 */
data class ReplayTrade(
    val openIndex: Int,
    val exitIndex: Int,
    val direction: String,
    val entry: Double,
    val exit: Double,
    val rMultiple: Double,
    val outcome: String,      // TARGET / STOP / TIMEOUT
    val barsHeld: Int,
    val tier: String = TargetTier.STEADY   // v5.0.17 目标分档：稳健/进取
) {
    companion object {
        const val TARGET = "TARGET"
        const val STOP = "STOP"
        const val TIMEOUT = "TIMEOUT"
    }
}

data class ReplayStat(
    val name: String,
    val trades: List<ReplayTrade>
) {
    val wins: Int get() = trades.count { it.outcome == ReplayTrade.TARGET }
    val losses: Int get() = trades.count { it.outcome == ReplayTrade.STOP }
    val timeouts: Int get() = trades.count { it.outcome == ReplayTrade.TIMEOUT }
    val decided: Int get() = wins + losses
    val winRate: Double get() = if (decided == 0) 0.0 else wins.toDouble() / decided
    val totalR: Double get() = trades.sumOf { it.rMultiple }
    val avgR: Double get() = if (trades.isEmpty()) 0.0 else totalR / trades.size
    val avgBars: Double get() = if (trades.isEmpty()) 0.0 else trades.map { it.barsHeld }.average()

    // v5.0.17 分档统计（稳健 2R / 进取 3R）
    val steadyTrades: List<ReplayTrade> get() = trades.filter { it.tier == TargetTier.STEADY }
    val aggrTrades: List<ReplayTrade> get() = trades.filter { it.tier == TargetTier.AGGRESSIVE }
    private fun statR(list: List<ReplayTrade>): Double = list.sumOf { it.rMultiple }
    private fun statWR(list: List<ReplayTrade>): Double {
        val decided = list.count { it.outcome == ReplayTrade.TARGET || it.outcome == ReplayTrade.STOP }
        return if (decided == 0) 0.0 else list.count { it.outcome == ReplayTrade.TARGET }.toDouble() / decided
    }
    val steadyCount: Int get() = steadyTrades.size
    val aggrCount: Int get() = aggrTrades.size
    val steadyTotalR: Double get() = statR(steadyTrades)
    val aggrTotalR: Double get() = statR(aggrTrades)
    val steadyWinRate: Double get() = statWR(steadyTrades)
    val aggrWinRate: Double get() = statWR(aggrTrades)
}

data class ReplayReport(
    val value: ReplayStat,
    val market: ReplayStat,
    val trail: ReplayStat = ReplayStat("价值区+结构延续", emptyList()),
    val bars: Int,
    val valueVetoed: Int,
    val note: String
) {
    /** 价值区相对现价的总 R 改善。 */
    val edgeR: Double get() = value.totalR - market.totalR
    val winRateDelta: Double get() = value.winRate - market.winRate
    /** 结构延续相对固定价值区止盈的总 R 改善（v5.0.16）。 */
    val trailEdgeR: Double get() = trail.totalR - value.totalR
}

/** v5.0.15 单品种回放对比的 UI 行（VM 汇总后供页面展示）。 */
data class ReplayRow(
    val symbol: String,
    val market: String,
    val timeframe: String,
    val bars: Int,
    val valueTrades: Int,
    val valueWinRate: Double,
    val valueTotalR: Double,
    val valueAvgR: Double,
    val marketTrades: Int,
    val marketWinRate: Double,
    val marketTotalR: Double,
    val marketAvgR: Double,
    val trailTrades: Int = 0,
    val trailWinRate: Double = 0.0,
    val trailTotalR: Double = 0.0,
    val trailAvgR: Double = 0.0,
    val vetoed: Int,
    val note: String
) {
    val edgeR: Double get() = valueTotalR - marketTotalR
    val winRateDelta: Double get() = valueWinRate - marketWinRate
    /** 结构延续相对固定价值区的总 R 改善。 */
    val trailEdgeR: Double get() = trailTotalR - valueTotalR

    companion object {
        fun of(symbol: String, market: String, timeframe: String, r: ReplayReport): ReplayRow = ReplayRow(
            symbol, market, timeframe, r.bars,
            r.value.trades.size, r.value.winRate, r.value.totalR, r.value.avgR,
            r.market.trades.size, r.market.winRate, r.market.totalR, r.market.avgR,
            r.trail.trades.size, r.trail.winRate, r.trail.totalR, r.trail.avgR,
            r.valueVetoed, r.note
        )
    }
}

object ReplayEngine {
    const val WARMUP = 220               // 指标预热根数（与 AnalysisEngine.MIN_CANDLES 一致）
    const val MAX_HOLD_BARS = 16         // 垂直屏障：最大持仓根数
    const val COOLDOWN_BARS = 3          // 平仓后冷却

    private class Arm(var until: Int = -1, var cooldownUntil: Int = -1, var vetoed: Int = 0,
                      val trades: MutableList<ReplayTrade> = mutableListOf())

    /** v5.0.16 第三臂（结构延续 / v5.0.17 分档）持仓状态。 */
    private class TrailPos(
        var openIndex: Int, var entry: Double, var atr: Double, var long: Boolean,
        var stop: Double, var target: Double, var risk: Double,
        var trailCount: Int = 0, var bestPrice: Double, var lastRaiseBar: Int,
        var tier: String = TargetTier.STEADY,
        var breakEvenDone: Boolean = false,
        var targetR: Double = TargetTier.DEFAULT_STEADY_R
    )

    /** 第三臂结算：按实际出场价算 R；除垂直屏障超时外，按 R 正负归 TARGET/STOP。 */
    private fun settleTrail(tp: TrailPos, exitIndex: Int, exitPrice: Double, timeout: Boolean): ReplayTrade {
        val r = (exitPrice - tp.entry) * (if (tp.long) 1 else -1) / tp.risk
        val outcome = when {
            timeout -> ReplayTrade.TIMEOUT
            r >= 0 -> ReplayTrade.TARGET
            else -> ReplayTrade.STOP
        }
        return ReplayTrade(tp.openIndex, exitIndex, if (tp.long) "LONG" else "SHORT",
            tp.entry, exitPrice, r, outcome, exitIndex - tp.openIndex, tp.tier)
    }

    /** Triple Barrier：从 openIndex+1 起逐根判定，返回成交结果。internal 以便单测直接验证结算。 */
    internal fun resolve(candles: List<Candle>, openIndex: Int, entry: Double, atr: Double,
                        long: Boolean, stopMult: Double, targetMult: Double): ReplayTrade {
        val sign = if (long) 1.0 else -1.0
        val stop = entry - sign * stopMult * atr
        val target = entry + sign * targetMult * atr
        val risk = (stopMult * atr).takeIf { it > 0 } ?: atr
        val last = minOf(openIndex + MAX_HOLD_BARS, candles.lastIndex)
        for (k in (openIndex + 1)..last) {
            val c = candles[k]
            if (long) {
                if (c.low <= stop) return mk(openIndex, k, long, entry, stop, -1.0, risk, ReplayTrade.STOP)
                if (c.high >= target) return mk(openIndex, k, long, entry, target, targetMult / stopMult, risk, ReplayTrade.TARGET)
            } else {
                if (c.high >= stop) return mk(openIndex, k, long, entry, stop, -1.0, risk, ReplayTrade.STOP)
                if (c.low <= target) return mk(openIndex, k, long, entry, target, targetMult / stopMult, risk, ReplayTrade.TARGET)
            }
        }
        val exitPrice = candles[last].close
        val r = (exitPrice - entry) * sign / risk
        return mk(openIndex, last, long, entry, exitPrice, r, risk, ReplayTrade.TIMEOUT)
    }

    private fun mk(openIndex: Int, exitIndex: Int, long: Boolean, entry: Double, exit: Double,
                   r: Double, risk: Double, outcome: String): ReplayTrade {
        val rMult = if (outcome == ReplayTrade.TARGET || outcome == ReplayTrade.STOP) r
        else (exit - entry) * (if (long) 1 else -1) / risk
        return ReplayTrade(openIndex, exitIndex, if (long) "LONG" else "SHORT",
            entry, exit, rMult, outcome, exitIndex - openIndex)
    }

    /**
     * 双臂回放。
     * @param candles 完整历史（含足够预热）；只在收盘根上决策。
     */
    fun run(
        symbol: String, market: String, timeframe: String,
        candles: List<Candle>, cfg: EntryConfig = EntryConfig()
    ): ReplayReport {
        val sorted = candles.sortedBy { it.openTime }.distinctBy { it.openTime }
        val n = sorted.size
        val valueArm = Arm()
        val marketArm = Arm()
        var marketDirPrev = ""
        // v5.0.16 第三臂：价值区入场 + 结构延续出场
        var trailPos: TrailPos? = null
        var trailCooldownUntil = -1
        val trailTrades = mutableListOf<ReplayTrade>()
        val exitCfg = ExitStateMachine.ExitConfig(
            continuationEnabled = true, stopMult = cfg.stopMult, targetMult = cfg.targetMult
        )

        for (i in WARMUP until n) {
            val closed = sorted.subList(0, i + 1)
            val price = sorted[i].close
            val res = SignalPipeline.evaluate(symbol, market, timeframe, closed, price, sorted[i], null, cfg)
            val a = res.analysis ?: continue
            val long = a.direction == "LONG" || a.direction == "SHORT"

            // ---- 对照组：现价入场（方向信号出现即按收盘价） ----
            if (i > marketArm.cooldownUntil && i > marketArm.until) {
                if (a.direction != "NEUTRAL" && a.direction != marketDirPrev) {
                    val t = resolve(sorted, i, price, a.atr, a.direction == "LONG", cfg.stopMult, cfg.targetMult)
                    marketArm.trades += t
                    marketArm.until = t.exitIndex
                    marketArm.cooldownUntil = t.exitIndex + COOLDOWN_BARS
                }
            }
            marketDirPrev = a.direction
            if (i <= marketArm.until) { /* 对照组持仓中 */ }

            // ---- 实验组：价值区入场（READY 才开） ----
            if (i > valueArm.cooldownUntil && i > valueArm.until) {
                val dec = res.decision
                if (dec.dead && res.zone != null) valueArm.vetoed++   // 价值区被结构/破位否决
                if (dec.ready && res.zone != null) {
                    val z = res.zone
                    val t = resolve(sorted, i, z.entry, a.atr, z.direction == "LONG", cfg.stopMult, cfg.targetMult)
                    valueArm.trades += t
                    valueArm.until = t.exitIndex
                    valueArm.cooldownUntil = t.exitIndex + COOLDOWN_BARS
                }
            }

            // ---- 第三臂：价值区入场 + 结构延续出场（v5.0.16） ----
            val tp0 = trailPos
            if (tp0 == null) {
                if (i > trailCooldownUntil) {
                    val dec = res.decision
                    if (dec.ready && res.zone != null) {
                        val z = res.zone
                        // v5.0.17 分档：按质量/结构/空间判稳健 2R 或进取 3R，目标用统一 R 口径
                        val long = z.direction == "LONG"
                        val tier = TargetTier.classify(z.direction, z.entry, z.stop, a.score, cfg.tierCfg, a, res.structure)
                        val risk = TargetTier.riskDistance(z.entry, z.stop, a.atr)
                        val target = TargetTier.targetFor(long, z.entry, z.stop, tier.targetR, a.atr)
                        trailPos = TrailPos(
                            i, z.entry, a.atr, long, z.stop, target, risk,
                            trailCount = 0, bestPrice = z.entry, lastRaiseBar = i,
                            tier = tier.tier, breakEvenDone = false, targetR = tier.targetR
                        )
                    }
                }
            } else {
                val bar = sorted[i]
                val stopHit = if (tp0.long) bar.low <= tp0.stop else bar.high >= tp0.stop
                if (stopHit) {
                    // 盘中极值先判移动止损（保守，同根优先于延续/目标）
                    trailTrades += settleTrail(tp0, i, tp0.stop, timeout = false)
                    trailCooldownUntil = i + COOLDOWN_BARS
                    trailPos = null
                } else {
                    tp0.bestPrice = if (tp0.long) maxOf(tp0.bestPrice, bar.high) else minOf(tp0.bestPrice, bar.low)
                    // 保本/止损用盘中有利极值（LONG 最高、SHORT 最低），到目标/延续用收盘
                    val livePx = if (tp0.long) bar.high else bar.low
                    val ed = ExitStateMachine.evaluate(
                        if (tp0.long) "LONG" else "SHORT", tp0.entry, tp0.stop, tp0.target,
                        livePx, res.analysis, res.structure, bar,
                        tp0.trailCount, i - tp0.lastRaiseBar, tp0.bestPrice,
                        tp0.breakEvenDone,
                        exitCfg.copy(targetMult = tp0.targetR, tier = tp0.tier, breakEvenR = cfg.tierCfg.breakEvenR)
                    )
                    when {
                        ed.isRaise -> {
                            tp0.stop = ed.newStop; tp0.target = ed.newTarget
                            tp0.trailCount = ed.trailCount; tp0.lastRaiseBar = i
                            tp0.breakEvenDone = tp0.breakEvenDone || ed.breakEvenDone
                        }
                        ed.isExit -> {
                            trailTrades += settleTrail(tp0, i, bar.close, timeout = false)
                            trailCooldownUntil = i + COOLDOWN_BARS
                            trailPos = null
                        }
                        tp0.trailCount == 0 && i - tp0.openIndex > MAX_HOLD_BARS -> {
                            // 初始仓到最大持仓仍未到目标 → 垂直屏障超时
                            trailTrades += settleTrail(tp0, i, bar.close, timeout = true)
                            trailCooldownUntil = i + COOLDOWN_BARS
                            trailPos = null
                        }
                    }
                }
            }
        }

        // 循环结束仍持仓的第三臂单子：按最后一根收盘结算（不丢样本）
        trailPos?.let { tp ->
            if (n > 0) trailTrades += settleTrail(tp, n - 1, sorted[n - 1].close, timeout = false)
        }

        val vs = ReplayStat("价值区入场", valueArm.trades)
        val ms = ReplayStat("现价入场", marketArm.trades)
        val ts = ReplayStat("价值区+结构延续", trailTrades)
        val note = when {
            n < WARMUP + 30 -> "样本不足：K 线 < ${WARMUP + 30} 根，回放结论不可靠"
            vs.trades.size < 8 || ms.trades.size < 8 ->
                "交易样本偏少（价值区 ${vs.trades.size} / 现价 ${ms.trades.size} / 延续 ${ts.trades.size}），仅供参考"
            else -> "总 R：现价 ${String.format(java.util.Locale.US, "%.1f", ms.totalR)} → 价值区 " +
                "${String.format(java.util.Locale.US, "%.1f", vs.totalR)} → 结构延续 " +
                "${String.format(java.util.Locale.US, "%.1f", ts.totalR)}；价值区否决 ${valueArm.vetoed} 次"
        }
        return ReplayReport(vs, ms, ts, n, valueArm.vetoed, note)
    }
}
