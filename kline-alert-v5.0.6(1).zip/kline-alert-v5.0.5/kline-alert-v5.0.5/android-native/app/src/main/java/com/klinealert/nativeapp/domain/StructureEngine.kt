package com.klinealert.nativeapp.domain

import kotlin.math.abs

/**
 * v5.0.15 结构层引擎（StructureEngine）：把"结构"从 regime 快照升级为事件流。
 *
 * 概念（ICT / Smart Money Concepts，业界通用定义）：
 *  - Swing 点：fractal（左右各若干根）确认的摆动高/低，ZigZag 强制高/低严格交替；
 *    一个 swing 点必须在 i+right 根之后才"可见"，天然无未来函数。
 *  - BOS（Break of Structure，结构突破）：收盘价突破「同向」最近 swing 点 → 趋势延续。
 *      上涨中 close > 最近 swing high = BOS_UP；下跌中 close < 最近 swing low = BOS_DOWN。
 *  - CHoCH（Change of Character，结构转变）：收盘价突破「反向」最近 swing 点 → 反转警告。
 *      上涨中 close < 最近 swing low = CHoCH_DOWN；下跌中 close > 最近 swing high = CHoCH_UP。
 *  - 真假突破：突破后 confirmBars 根内，收盘站稳突破位之外 = 真突破（CONFIRMED）；
 *    收回突破位（含 buffer）= 假突破（FAILED）；K 线不足 = PENDING。
 *    收盘确认（非影线）是最有效的假突破过滤；量能 ≥1.5× 为增强确认。
 *
 * 纯函数、无状态：回测（历史 K 线回放）与实盘（实时窗口）调用同一函数，保证同构。
 */
data class SwingPoint(val index: Int, val price: Double, val type: String) {
    val isHigh: Boolean get() = type == HIGH
    companion object {
        const val HIGH = "HIGH"
        const val LOW = "LOW"
    }
}

/** 结构事件。type=NONE 表示最新一根无事件。valid 表示真假突破验证状态。 */
data class StructureEvent(
    val type: String,        // BOS_UP / BOS_DOWN / CHOCH_UP / CHOCH_DOWN / NONE
    val level: Double,       // 被突破的结构位
    val index: Int,          // 突破发生的 K 线索引
    val close: Double,       // 突破根收盘价
    val valid: String = PENDING,  // PENDING / CONFIRMED / FAILED / NONE
    val volRatio: Double = 1.0
) {
    val isBreak: Boolean get() = type == BOS_UP || type == BOS_DOWN
    val isReversal: Boolean get() = type == CHOCH_UP || type == CHOCH_DOWN
    val direction: String get() = when (type) {
        BOS_UP, CHOCH_UP -> "LONG"
        BOS_DOWN, CHOCH_DOWN -> "SHORT"
        else -> ""
    }
    companion object {
        const val BOS_UP = "BOS_UP"
        const val BOS_DOWN = "BOS_DOWN"
        const val CHOCH_UP = "CHOCH_UP"
        const val CHOCH_DOWN = "CHOCH_DOWN"
        const val NONE = "NONE"
        const val PENDING = "PENDING"
        const val CONFIRMED = "CONFIRMED"
        const val FAILED = "FAILED"
    }
}

/** 结构快照：趋势、最近 swing、最新事件。 */
data class StructureState(
    val trend: String,               // UP / DOWN / RANGE
    val swings: List<SwingPoint>,
    val lastSwingHigh: SwingPoint?,
    val lastSwingLow: SwingPoint?,
    val event: StructureEvent,
    val recentEvent: StructureEvent? = null   // 最近一次（可能已验证）的突破事件
) {
    val label: String
        get() = when (trend) {
            "UP" -> "多头结构（HH/HL）"
            "DOWN" -> "空头结构（LH/LL）"
            else -> "震荡结构"
        }
}

object StructureEngine {
    const val UP = "UP"
    const val DOWN = "DOWN"
    const val RANGE = "RANGE"

    /** fractal 左右确认根数；right 根确认延迟，避免重绘。 */
    const val DEFAULT_LEFT = 2
    const val DEFAULT_RIGHT = 2
    /** 突破后站稳验证根数（观察窗口）。 */
    const val CONFIRM_BARS = 2
    /** 站稳容差（×ATR）：收盘回到突破位内侧超过 buffer 视为收回。 */
    const val BUFFER_ATR = 0.1
    /** 真突破量能门槛（×20 根均量）。 */
    const val VOLUME_CONFIRM = 1.5
    /** 结构扫描滚动窗口（根）。 */
    const val STRUCT_WINDOW = 120
    /** 结构事件回看窗口（根）。 */
    const val EVENT_LOOKBACK = 12

    /** 提取严格交替的 ZigZag swing 序列（只含截至 lastIndex 已确认的点）。 */
    fun swings(high: DoubleArray, low: DoubleArray, left: Int = DEFAULT_LEFT, right: Int = DEFAULT_RIGHT): List<SwingPoint> {
        val n = high.size
        if (n < left + right + 1) return emptyList()
        // 1. fractal 候选
        data class Raw(val index: Int, val price: Double, val type: String)
        val raw = mutableListOf<Raw>()
        for (i in left..(n - 1 - right)) {
            var isHigh = true
            var isLow = true
            for (j in (i - left)..(i + right)) {
                if (j == i) continue
                if (high[i] <= high[j]) isHigh = false
                if (low[i] >= low[j]) isLow = false
            }
            if (isHigh) raw += Raw(i, high[i], SwingPoint.HIGH)
            if (isLow) raw += Raw(i, low[i], SwingPoint.LOW)
        }
        // 2. ZigZag 严格交替：连续同类取极值，异类校验后追加
        val zig = mutableListOf<SwingPoint>()
        for (r in raw) {
            val last = zig.lastOrNull()
            if (last == null) {
                zig += SwingPoint(r.index, r.price, r.type)
            } else if (r.type == last.type) {
                // 连续同类：high 取更高，low 取更低（更新极值点）
                val better = if (r.type == SwingPoint.HIGH) r.price > last.price else r.price < last.price
                if (better) zig[zig.lastIndex] = SwingPoint(r.index, r.price, r.type)
            } else {
                // 异类：只有价格关系合理才追加（high 后接 low 必须更低，反之亦然）
                val sane = if (r.type == SwingPoint.LOW) r.price < last.price else r.price > last.price
                if (sane) zig += SwingPoint(r.index, r.price, r.type)
            }
        }
        return zig
    }

    /** 由 swing 序列判断趋势：最近两个 high 与两个 low 同向抬高/降低。 */
    fun trendOf(swings: List<SwingPoint>): String {
        val highs = swings.filter { it.isHigh }
        val lows = swings.filter { !it.isHigh }
        if (highs.size < 2 || lows.size < 2) return RANGE
        val hh = highs[highs.lastIndex].price > highs[highs.lastIndex - 1].price
        val hl = lows[lows.lastIndex].price > lows[lows.lastIndex - 1].price
        val lh = highs[highs.lastIndex].price < highs[highs.lastIndex - 1].price
        val ll = lows[lows.lastIndex].price < lows[lows.lastIndex - 1].price
        return when {
            hh && hl -> UP
            lh && ll -> DOWN
            else -> RANGE
        }
    }

    /**
     * 真假突破验证。postCloses = 突破根「之后」的收盘价（不含突破根）。
     * BOS_UP：观察期内任何一根收盘 < level - buffer×ATR → FAILED；全部站稳 → CONFIRMED；不足 → PENDING。
     */
    fun verifyBreak(direction: String, level: Double, postCloses: List<Double>, atr: Double,
                    confirmBars: Int = CONFIRM_BARS, bufferAtr: Double = BUFFER_ATR): String {
        if (postCloses.size < confirmBars) return StructureEvent.PENDING
        val buffer = bufferAtr * atr
        val up = direction == "LONG"
        for (k in 0 until confirmBars) {
            val c = postCloses[k]
            val failed = if (up) c < level - buffer else c > level + buffer
            if (failed) return StructureEvent.FAILED
        }
        return StructureEvent.CONFIRMED
    }

    /** 量能确认：突破根量比 ≥ 1.5×。 */
    fun volumeConfirmed(volRatio: Double, threshold: Double = VOLUME_CONFIRM): Boolean = volRatio >= threshold

    /** 在某根 bar 上判断是否构成 BOS/CHoCH（swings 已截至该 bar）。无事件返回 null。 */
    private fun eventAt(swings: List<SwingPoint>, trend: String, close: Double, idx: Int): StructureEvent? {
        val lastHigh = swings.lastOrNull { it.isHigh }
        val lastLow = swings.lastOrNull { !it.isHigh }
        // 防守：结构位必须早于当前 bar
        if (lastHigh != null && lastHigh.index >= idx) return null
        if (lastLow != null && lastLow.index >= idx) return null
        return when (trend) {
            UP -> when {
                lastHigh != null && close > lastHigh.price -> StructureEvent(StructureEvent.BOS_UP, lastHigh.price, idx, close)
                lastLow != null && close < lastLow.price -> StructureEvent(StructureEvent.CHOCH_DOWN, lastLow.price, idx, close)
                else -> null
            }
            DOWN -> when {
                lastLow != null && close < lastLow.price -> StructureEvent(StructureEvent.BOS_DOWN, lastLow.price, idx, close)
                lastHigh != null && close > lastHigh.price -> StructureEvent(StructureEvent.CHOCH_UP, lastHigh.price, idx, close)
                else -> null
            }
            else -> when {
                lastHigh != null && close > lastHigh.price -> StructureEvent(StructureEvent.BOS_UP, lastHigh.price, idx, close)
                lastLow != null && close < lastLow.price -> StructureEvent(StructureEvent.BOS_DOWN, lastLow.price, idx, close)
                else -> null
            }
        }
    }

    /** 取截至 endIdx（含）已收盘 K 线的结构快照（滚动窗口）。 */
    fun evaluateAt(candles: List<Candle>, endIdx: Int, atr: Double,
                   left: Int = DEFAULT_LEFT, right: Int = DEFAULT_RIGHT,
                   windowBars: Int = STRUCT_WINDOW): StructureState {
        val start = maxOf(0, endIdx + 1 - windowBars)
        val win = if (endIdx >= candles.size) candles else candles.subList(start, endIdx + 1)
        val high = DoubleArray(win.size) { win[it].high }
        val low = DoubleArray(win.size) { win[it].low }
        val close = DoubleArray(win.size) { win[it].close }
        val sw = swings(high, low, left, right)
        // 映射回全局索引
        val swingsG = sw.map { SwingPoint(it.index + start, it.price, it.type) }
        val trend = trendOf(swingsG)
        val lastEvent = eventAt(swingsG, trend, close.last(), endIdx)?.copy(volRatio = volRatioAt(win, win.lastIndex))
        val recent = if (lastEvent == null) scanRecent(win, start, atr, left, right, endIdx) else lastEvent
        return StructureState(
            trend = trend,
            swings = swingsG,
            lastSwingHigh = swingsG.lastOrNull { it.isHigh },
            lastSwingLow = swingsG.lastOrNull { !it.isHigh },
            event = lastEvent ?: StructureEvent(StructureEvent.NONE, 0.0, endIdx, close.last(), StructureEvent.NONE),
            recentEvent = recent
        )
    }

    /** 最新窗口结构快照（传入的 candles 最后一根为最新收盘）。 */
    fun evaluate(candles: List<Candle>, atr: Double): StructureState =
        evaluateAt(candles, candles.lastIndex, atr)

    /** 量比：当根 / 前 20 根均量。 */
    private fun volRatioAt(win: List<Candle>, idx: Int): Double {
        if (idx < 1) return 1.0
        val base = win.subList(maxOf(0, idx - 20), idx).map { it.volume }.average().takeIf { it > 0 } ?: return 1.0
        return win[idx].volume / base
    }

    /** 在最后一根未触发新事件时，回看最近 EVENT_LOOKBACK 根，找最近一次突破并给验证结果。 */
    private fun scanRecent(win: List<Candle>, globalStart: Int, atr: Double,
                           left: Int, right: Int, globalEnd: Int): StructureEvent? {
        val n = win.size
        val lookFrom = maxOf(left + right, n - 1 - EVENT_LOOKBACK)
        var found: StructureEvent? = null
        for (i in lookFrom until n) {
            val sub = win.subList(0, i + 1)
            val high = DoubleArray(sub.size) { sub[it].high }
            val low = DoubleArray(sub.size) { sub[it].low }
            val sw = swings(high, low, left, right).map { SwingPoint(it.index, it.price, it.type) }
            val tr = trendOf(sw)
            val ev = eventAt(sw, tr, sub[i].close, i) ?: continue
            val post = (i + 1 until n).map { sub[it].close }
            val valid = verifyBreak(ev.direction, ev.level, post, atr)
            found = ev.copy(index = ev.index + globalStart, valid = valid, volRatio = volRatioAt(win, i))
        }
        return found
    }
}
