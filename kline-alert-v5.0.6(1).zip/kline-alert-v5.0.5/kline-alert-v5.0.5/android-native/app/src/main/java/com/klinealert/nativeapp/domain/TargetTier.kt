package com.klinealert.nativeapp.domain

import kotlin.math.abs

/**
 * v5.0.17 目标分档（方案甲：整笔分档，全仓进全仓出）。
 *
 * 开仓时把每笔判定为两档之一：
 *  - [STEADY] 稳健档（默认目标 [TierConfig.steadyR] = 2R）：到 2R 直接落袋，主打高胜率；
 *  - [AGGRESSIVE] 进取档（默认目标 [TierConfig.aggrR] = 3R）：到 2R 先把止损移到保本，再靠
 *    v5.0.16 的信号延续冲 3R 甚至更高，主打赔率。
 *
 * 不设固定比例（不硬凑 6:4）：每笔独立判定，趋势行情自然多进取档、震荡行情自然多稳健档。
 * 数学上，纯进取档只需 25% 胜率（10 笔中 3 个 3R）即保本、4 个 3R 命中（其余全亏）即 +6R。
 *
 * 纯函数、无状态：自动判定看结构/空间/质量/动能，手动覆盖与全局强制优先。
 */
object TargetTier {

    const val STEADY = "STEADY"            // 稳健档：2R 落袋
    const val AGGRESSIVE = "AGGRESSIVE"    // 进取档：2R 保本，冲 3R

    const val DEFAULT_STEADY_R = 2.0
    const val DEFAULT_AGGR_R = 3.0
    const val DEFAULT_BREAK_EVEN_R = 2.0   // 进取档到 2R 移动保本
    const val DEFAULT_MIN_SCORE = 75       // 进取档质量分门槛
    const val DEFAULT_MOMENTUM_VOL = 1.3   // 放量动能门槛（量比）
    const val DEFAULT_ADX_STRONG = 22.0    // 趋势强度门槛（ADX）

    /** 全局/单笔分档模式。 */
    const val MODE_AUTO = "AUTO"                    // 自动判定（默认）
    const val MODE_FORCE_STEADY = "FORCE_STEADY"    // 强制全部 2R
    const val MODE_FORCE_AGGRESSIVE = "FORCE_AGGRESSIVE" // 强制全部 3R

    data class TierConfig(
        val mode: String = MODE_AUTO,
        val steadyR: Double = DEFAULT_STEADY_R,
        val aggrR: Double = DEFAULT_AGGR_R,
        val breakEvenR: Double = DEFAULT_BREAK_EVEN_R,
        val minScore: Int = DEFAULT_MIN_SCORE,
        val momentumVol: Double = DEFAULT_MOMENTUM_VOL,
        val adxStrong: Double = DEFAULT_ADX_STRONG,
        /** 前方空间是否为进取档硬门槛（挂得到 3R 才允许进取）。 */
        val requireRoom: Boolean = true
    )

    data class TierResult(
        val tier: String,
        val targetR: Double,
        /** 自动判定是否满足进取档（强制/手动模式下仅表示最终档）。 */
        val pass: Boolean,
        val reasons: List<String>
    ) {
        val isAggr: Boolean get() = tier == AGGRESSIVE
    }

    /**
     * 判定单笔目标档位。
     *
     * @param direction      LONG / SHORT
     * @param entry          入场价
     * @param stop           止损价（实际风险距离 R = |entry - stop|）
     * @param qualityScore   信号质量分（0-100，融合分或精准分）
     * @param a              最新指标快照（可空；用其前方支撑阻力/量比/ADX/阶段）
     * @param structure      结构状态（可空；用其趋势/反向 CHoCH/前方 swing）
     * @param manualOverride 手动指定档位（[STEADY]/[AGGRESSIVE]，非空时优先于一切）
     */
    fun classify(
        direction: String,
        entry: Double,
        stop: Double,
        qualityScore: Int,
        cfg: TierConfig = TierConfig(),
        a: Analysis? = null,
        structure: StructureState? = null,
        manualOverride: String? = null
    ): TierResult {
        val long = direction != "SHORT"

        // 1) 手动覆盖最高优先
        if (manualOverride == STEADY) {
            return TierResult(STEADY, cfg.steadyR, false, listOf("手动指定稳健档（${cfg.steadyR}R 落袋）"))
        }
        if (manualOverride == AGGRESSIVE) {
            return TierResult(AGGRESSIVE, cfg.aggrR, true, listOf("手动指定进取档（${cfg.breakEvenR}R 保本，冲 ${cfg.aggrR}R）"))
        }
        // 2) 全局强制模式
        when (cfg.mode) {
            MODE_FORCE_STEADY -> return TierResult(STEADY, cfg.steadyR, false, listOf("全局强制稳健档"))
            MODE_FORCE_AGGRESSIVE -> return TierResult(AGGRESSIVE, cfg.aggrR, true, listOf("全局强制进取档"))
        }
        // 3) 自动判定：4 条全满足才进取
        val risk = riskDistance(entry, stop, a?.atr)
        if (risk <= 0) return TierResult(STEADY, cfg.steadyR, false, listOf("风险距离无效 → 稳健档"))

        val checks = mutableListOf<Pair<Boolean, String>>()

        // ① 前方剩余空间 ≥ aggrR×risk（最近结构阻力 / 支撑；看不到则视为开阔，不否决）
        val obstacle = forwardObstacle(long, entry, a, structure)
        if (obstacle > 0) {
            val room = if (long) obstacle - entry else entry - obstacle
            val need = cfg.aggrR * risk
            val ok = !cfg.requireRoom || room >= need
            checks += ok to if (ok) "前方空间 ${r1(room / risk)}R ≥ ${r1(cfg.aggrR)}R"
            else "前方空间仅 ${r1(room / risk)}R < ${r1(cfg.aggrR)}R（${if (long) "阻力" else "支撑"} ${p4(obstacle)}）"
        } else {
            checks += true to "前方未见明显${if (long) "阻力" else "支撑"}（空间开阔）"
        }

        // ② 顺势结构：趋势同向且无反向 CHoCH（无结构时退化为阶段判断）
        val trendOk = trendAligns(long, a, structure)
        val reversal = structure?.recentEvent?.takeIf {
            it.valid == StructureEvent.CONFIRMED && it.isReversal
        }
        val against = reversal?.let { if (long) it.type == StructureEvent.CHOCH_DOWN else it.type == StructureEvent.CHOCH_UP } == true
        checks += (trendOk && !against) to when {
            against -> "出现反向 CHoCH"
            trendOk -> "趋势同向、无反向结构"
            else -> "非顺势（${a?.regime ?: "阶段不明"}）"
        }

        // ③ 质量分
        checks += (qualityScore >= cfg.minScore) to "质量分 $qualityScore ${if (qualityScore >= cfg.minScore) "≥" else "<"} ${cfg.minScore}"

        // ④ 动能确认：放量或趋势强度
        val vol = a?.volRatio ?: 1.0
        val adx = a?.adx ?: 0.0
        val momentum = vol >= cfg.momentumVol || adx >= cfg.adxStrong
        checks += momentum to if (momentum) "动能确认（量比 ${r1(vol)}/ADX ${adx.toInt()}）"
        else "动能不足（量比 ${r1(vol)}、ADX ${adx.toInt()}）"

        val passed = checks.all { it.first }
        return if (passed) {
            TierResult(AGGRESSIVE, cfg.aggrR, true, checks.filter { it.first }.map { it.second })
        } else {
            TierResult(STEADY, cfg.steadyR, false, checks.filterNot { it.first }.map { "✗ ${it.second}" })
        }
    }

    // ─────────────────────────── v5.0.18 UI 接入（切档 + 参数校验） ───────────────────────────

    /** 分档参数合法区间（UI 调节入口与持久化共用，越界即夹紧）。 */
    const val MIN_STEADY_R = 1.0
    const val MAX_STEADY_R = 6.0
    const val MIN_AGGR_R = 1.0
    const val MAX_AGGR_R = 10.0
    const val MIN_BREAK_EVEN_R = 1.0
    const val MAX_BREAK_EVEN_R = 6.0
    const val MIN_SCORE_RANGE = 50
    const val MAX_SCORE_RANGE = 95
    const val MIN_MOMENTUM_VOL = 1.0
    const val MAX_MOMENTUM_VOL = 3.0
    const val MIN_ADX_STRONG = 10.0
    const val MAX_ADX_STRONG = 40.0

    /** 当前档位显示标签："稳健2R" / "进取3R"（整数不带小数位）。 */
    fun label(tier: String, targetR: Double): String =
        (if (tier == AGGRESSIVE) "进取" else "稳健") + rN(targetR) + "R"

    /** 另一档。切档按钮即 STEADY ↔ AGGRESSIVE。 */
    fun flip(tier: String): String = if (tier == AGGRESSIVE) STEADY else AGGRESSIVE

    /** 单笔切档结果（纯函数，供 UI 的 togglePositionTier 使用）。 */
    data class TierSwitch(
        val tier: String,
        val targetR: Double,
        val target: Double,
        val breakEvenDone: Boolean,
        val allowed: Boolean,
        val reason: String,
        val label: String
    )

    /**
     * v5.0.18 单笔切档：把一笔持仓在稳健/进取之间切换并重算目标价。
     *
     * 风险距离优先取 `stopMult×ATR`（与开仓时一致，止损可能已上移故不能只看到现价止损），
     * 缺失时回退 |entry-stop|。切到进取档时重置保本标记（重新评估 2R 保本线）；
     * 切到稳健档时保留既有保本标记（不撤销已经发生的止损上移）。
     */
    fun planSwitch(
        currentTier: String,
        direction: String,
        entry: Double,
        stop: Double,
        atr: Double = 0.0,
        stopMult: Double = BattleLoopEngine.DEFAULT_STOP_MULT,
        breakEvenDone: Boolean = false,
        cfg: TierConfig = TierConfig()
    ): TierSwitch {
        val next = flip(currentTier)
        val targetR = if (next == AGGRESSIVE) cfg.aggrR else cfg.steadyR
        val risk = (stopMult * atr).takeIf { it > 0 && it.isFinite() }
            ?: riskDistance(entry, stop, atr)
        if (entry <= 0 || entry.isNaN() || risk <= 0 || !risk.isFinite()) {
            return TierSwitch(next, targetR, 0.0, breakEvenDone, false,
                "无法确定风险距离（ATR/止损缺失），切档后目标价不可计算", label(next, targetR))
        }
        val long = direction != "SHORT"
        val target = if (long) entry + targetR * risk else entry - targetR * risk
        return TierSwitch(
            tier = next, targetR = targetR, target = target,
            breakEvenDone = if (next == AGGRESSIVE) false else breakEvenDone,
            allowed = true, reason = "", label = label(next, targetR)
        )
    }

    /** 参数越界夹紧（持久化前统一调用，UI 滑杆/手输共用）。 */
    fun sanitize(cfg: TierConfig): TierConfig = cfg.copy(
        steadyR = cfg.steadyR.coerceIn(MIN_STEADY_R, MAX_STEADY_R),
        aggrR = cfg.aggrR.coerceIn(MIN_AGGR_R, MAX_AGGR_R),
        breakEvenR = cfg.breakEvenR.coerceIn(MIN_BREAK_EVEN_R, MAX_BREAK_EVEN_R),
        minScore = cfg.minScore.coerceIn(MIN_SCORE_RANGE, MAX_SCORE_RANGE),
        momentumVol = cfg.momentumVol.coerceIn(MIN_MOMENTUM_VOL, MAX_MOMENTUM_VOL),
        adxStrong = cfg.adxStrong.coerceIn(MIN_ADX_STRONG, MAX_ADX_STRONG)
    )

    /** 参数一致性提醒（null = 正常）。稳健 R ≥ 进取 R 时进取档没有意义。 */
    fun warning(cfg: TierConfig): String? = when {
        cfg.steadyR >= cfg.aggrR -> "⚠ 稳健 ${rN(cfg.steadyR)}R ≥ 进取 ${rN(cfg.aggrR)}R：进取档无空间，建议进取 > 稳健"
        cfg.breakEvenR >= cfg.aggrR -> "⚠ 保本线 ${rN(cfg.breakEvenR)}R ≥ 进取目标 ${rN(cfg.aggrR)}R：进取档到目标即已保本"
        else -> null
    }

    /** 分档参数摘要（作战面板一行显示）。 */
    fun summary(cfg: TierConfig): String {
        val mode = when (cfg.mode) {
            MODE_FORCE_STEADY -> "全部稳健"
            MODE_FORCE_AGGRESSIVE -> "全部进取"
            else -> "自动"
        }
        return "$mode · 稳健 ${rN(cfg.steadyR)}R / 进取 ${rN(cfg.aggrR)}R（${rN(cfg.breakEvenR)}R 保本）· 门槛 分${cfg.minScore}/量${rN(cfg.momentumVol)}/ADX${cfg.adxStrong.toInt()}"
    }

    /** 实际风险距离（1R）：优先用入场到止损，缺失回退到 1.5×ATR（与 SmartLevels 兜底一致）。 */
    fun riskDistance(entry: Double, stop: Double, atr: Double? = null): Double {
        val d = abs(entry - stop)
        if (d > 0) return d
        if (atr != null && atr > 0) return 1.5 * atr
        return 0.0
    }

    /** 目标价 = entry ± targetR × 风险距离。 */
    fun targetFor(long: Boolean, entry: Double, stop: Double, targetR: Double, atr: Double? = null): Double {
        val risk = riskDistance(entry, stop, atr)
        return if (long) entry + targetR * risk else entry - targetR * risk
    }

    /** 进取档保本价 = entry ± breakEvenR × 风险（默认 2R 保本线）；方向返回 0 表示无需保本。 */
    fun breakEvenPrice(long: Boolean, entry: Double, stop: Double, breakEvenR: Double, atr: Double? = null): Double {
        val risk = riskDistance(entry, stop, atr)
        if (risk <= 0) return 0.0
        return if (long) entry + breakEvenR * risk else entry - breakEvenR * risk
    }

    /** 已实现盈亏（R，按开仓风险距离归一化；正=盈）。 */
    fun realizedR(long: Boolean, entry: Double, close: Double, stop: Double, atr: Double? = null): Double {
        val risk = riskDistance(entry, stop, atr)
        if (risk <= 0 || entry <= 0) return 0.0
        val move = if (long) close - entry else entry - close
        return move / risk
    }

    // ------------------------------------------------------------------ 内部

    /** 前方最近障碍：LONG 取最近的结构 swing 高点（否则阻力），SHORT 镜像。 */
    private fun forwardObstacle(
        long: Boolean,
        entry: Double,
        a: Analysis?,
        structure: StructureState?
    ): Double {
        if (long) {
            val swingHigh = structure?.swings
                ?.filter { it.isHigh && it.price > entry }
                ?.minByOrNull { it.price }?.price
            if (swingHigh != null && swingHigh > 0) return swingHigh
            return a?.resistance?.takeIf { it > entry } ?: 0.0
        } else {
            val swingLow = structure?.swings
                ?.filter { !it.isHigh && it.price > 0 && it.price < entry }
                ?.maxByOrNull { it.price }?.price
            if (swingLow != null && swingLow > 0) return swingLow
            return a?.support?.takeIf { it in 1.0..entry } ?: 0.0
        }
    }

    /** 结构是否顺势；无结构时用阶段关键词（含"趋势"且不含"区间/震荡"）。 */
    private fun trendAligns(long: Boolean, a: Analysis?, structure: StructureState?): Boolean {
        if (structure != null) {
            return if (long) structure.trend == StructureEngine.UP else structure.trend == StructureEngine.DOWN
        }
        val regime = a?.regime ?: return false
        if (regime.contains("区间") || regime.contains("震荡")) return false
        return regime.contains("趋势")
    }

    private fun r1(v: Double): String = String.format(java.util.Locale.US, "%.1f", v)

    /** 整数不带小数位（2.0 → "2"，2.5 → "2.5"），用于档位标签与参数摘要。 */
    private fun rN(v: Double): String =
        if (v == kotlin.math.floor(v) && !v.isInfinite()) v.toInt().toString()
        else String.format(java.util.Locale.US, "%.1f", v)
    private fun p4(v: Double): String =
        if (v >= 1) String.format(java.util.Locale.US, "%.4f", v)
        else String.format(java.util.Locale.US, "%.8f", v)
}
