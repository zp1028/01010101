package com.klinealert.nativeapp.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import com.klinealert.nativeapp.MainActivity
import com.klinealert.nativeapp.R
import com.klinealert.nativeapp.data.LocalStore
import com.klinealert.nativeapp.data.MarketRepository
import com.klinealert.nativeapp.domain.Analysis
import com.klinealert.nativeapp.domain.AnalysisEngine
import com.klinealert.nativeapp.domain.BattleLoopEngine
import com.klinealert.nativeapp.domain.Candle
import com.klinealert.nativeapp.domain.ExitStateMachine
import com.klinealert.nativeapp.domain.StructureEngine
import com.klinealert.nativeapp.domain.TargetTier
import com.klinealert.nativeapp.data.LocalStore.ClosedTrade
import com.klinealert.nativeapp.domain.ReviewEngine
import com.klinealert.nativeapp.domain.ReviewRecord
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.WebSocket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/**
 * Foreground service that keeps full-market monitoring alive after the UI goes to the
 * background, and raises system notifications on signal appearance / direction change.
 *
 * Design notes:
 * - Runs its own MarketRepository/LocalStore instances (a separate SQLite connection is safe).
 * - The first selected timeframe gets live combined K-line sockets; additional timeframes
 *   are refreshed by periodic scans only, to bound battery, traffic and CPU usage.
 * - The universe watch is restarted (rescan included) at least every 30 minutes so newly
 *   ranked symbols are picked up, and immediately on socket failure.
 * - Uses the specialUse foreground-service type: there is no matching platform category
 *   for user-configured market alerting.
 */
class BackgroundMonitorService : Service() {
    companion object {
        const val ACTION_STOP = "com.klinealert.nativeapp.action.STOP_MONITOR"
        private const val CHANNEL_ONGOING = "kline_monitor_ongoing"
        private const val CHANNEL_ALERTS = "kline_alerts"
        private const val CHANNEL_ALERTS_SILENT = "kline_alerts_silent"
        private const val ONGOING_ID = 1001
        private const val EXTRA_MARKET = "market"
        private const val EXTRA_TIMEFRAMES = "timeframes"

        /** UI-observable runtime state; updated on start/destroy. */
        private val _running = MutableStateFlow(false)
        val running: StateFlow<Boolean> = _running.asStateFlow()

        fun start(context: Context, market: String, timeframes: List<String>) {
            val intent = Intent(context, BackgroundMonitorService::class.java)
                .putExtra(EXTRA_MARKET, market)
                .putExtra(EXTRA_TIMEFRAMES, timeframes.distinct().toTypedArray())
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, BackgroundMonitorService::class.java))
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var repo: MarketRepository
    private lateinit var store: LocalStore
    private lateinit var notifications: NotificationManager
    private val watchSockets = mutableListOf<WebSocket>()
    private val lastDirections = ConcurrentHashMap<String, String>()
    private val lastOpenTimes = ConcurrentHashMap<String, Long>()
    private val alertIdSeq = AtomicInteger(2000)
    private var alertSeq = 0
    /** v4.6 后台自动平仓冷却：key = "symbol|direction" → 平仓时刻（服务进程内，与前台互不干扰） */
    private val battleClosedKeys = ConcurrentHashMap<String, Long>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        repo = MarketRepository()
        store = LocalStore(this)
        notifications = getSystemService(NotificationManager::class.java)
        createChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        val market = intent?.getStringExtra(EXTRA_MARKET) ?: "SPOT"
        val timeframes = (intent?.getStringArrayExtra(EXTRA_TIMEFRAMES) ?: arrayOf("15m"))
            .filter { it in AnalysisEngine.supportedTimeframes }
            .ifEmpty { listOf("15m") }
        startAsForeground("正在准备后台预警")
        _running.value = true
        scope.launch { runMonitor(market, timeframes) }
        return START_STICKY
    }

    override fun onDestroy() {
        _running.value = false
        scope.cancel()
        closeWatchSockets()
        runCatching { store.close() }
        super.onDestroy()
    }

    // ------------------------------------------------------------------ //
    // 监控主循环
    // ------------------------------------------------------------------ //

    private suspend fun runMonitor(market: String, timeframes: List<String>) {
        // v4.6 后台持仓自动平仓：60s 轮询实时价，止盈/止损/移动止盈照常执行（退出后台不断联）
        scope.launch { positionWatchLoop(market, timeframes) }
        var backoffMs = 10_000L
        while (currentCoroutineContext().isActive) {
            updateOngoing("扫描 $market · ${timeframes.joinToString("/")} 全市场…", 0, 0)
            // 品种统一扫描：与前台同一套融合口径（多周期共振/A-B分级/学习权重）
            val outcome = runCatching {
                repo.scanSymbols(market, timeframes, { done, total -> updateOngoing("品种统一扫描 $done/$total", done, total) })
            }.getOrNull()
            if (outcome == null) {
                updateOngoing("扫描失败，${backoffMs / 1000} 秒后重试", 0, 0)
                delay(backoffMs)
                backoffMs = (backoffMs * 2).coerceAtMost(5 * 60_000L)
                continue
            }
            backoffMs = 10_000L
            val byTf = outcome.symbols.flatMap { sop -> sop.perTimeframe.values }.groupBy { it.timeframe }
            byTf.forEach { (tf, rows) -> store.saveAnalyses(market, tf, rows) }
            byTf.forEach { (tf, rows) -> rows.forEach { lastDirections[key(market, tf, it.symbol)] = it.direction } }
            // 训练闭环：A/B 级机会自动记账（id 唯一键去重）
            outcome.symbols.filter { it.grade == "A" || it.grade == "B" }.forEach { sop ->
                runCatching { store.saveReview(ReviewEngine.create(sop.rep)) }
            }
            // 结算：用本轮最新价结算未决记录
            val priceBySymbol = outcome.symbols.associate { it.symbol to it.price }
            settleByPrices(market, priceBySymbol)
            // v4.6 后台自动平仓：同一批最新价判持仓止盈/止损（跨扫描周期兜底）
            settleBattlePositions(market, priceBySymbol)
            updateOngoing("后台实时监控 ${outcome.symbols.size} 个品种 · ${timeframes.joinToString("/")}", 0, 0)

            val failure = CompletableDeferred<Unit>()
            lastOpenTimes.clear()
            watchUniverse(market, timeframes.first(), outcome.symbols.map { it.symbol }, failure)
            // Live watch runs for at most 30 minutes, then a rescan refreshes the universe;
            // a socket failure ends the wait early and the loop retries after a short backoff.
            val timedOut = withTimeoutOrNull(30 * 60_000L) { failure.await() } == null
            closeWatchSockets()
            if (!timedOut) delay(backoffMs)
        }
    }

    /** v4.8 审计：结算与前台统一口径——优先真实 K 线触碰判定（ReviewEngine.touch：区间高/低点、同时触碰判 miss），
     *  K 线不可用（冷门品种/接口限流）时才回退扫描现价近似判定（优先级与前台一致：同时触碰→miss → hit → miss → 超期中性）。 */
    private suspend fun settleByPrices(market: String, priceBySymbol: Map<String, Double>) {
        val records = runCatching { store.loadReviews(market, 1000) }.getOrDefault(emptyList())
        val now = System.currentTimeMillis()
        records.filter { it.verdict == "open" }.forEach { rec ->
            val bars = runCatching { repo.candles(rec.symbol, market, rec.timeframe.ifBlank { "1h" }, 60) }.getOrNull()
            if (!bars.isNullOrEmpty()) {
                val after = bars.filter { it.openTime > rec.alertedAt }
                if (after.isNotEmpty()) {
                    val out = ReviewEngine.touch(after, rec)
                    if (out.verdict != "open") {
                        runCatching { store.updateReview(ReviewEngine.settle(rec, out, now)) }
                        return@forEach
                    }
                }
            }
            val price = priceBySymbol[rec.symbol] ?: return@forEach
            val hit = if (rec.direction == "LONG") price >= rec.target else price <= rec.target
            val miss = if (rec.direction == "LONG") price <= rec.stop else price >= rec.stop
            val expired = ReviewEngine.expire(rec, now)
            when {
                hit && miss -> runCatching { store.updateReview(ReviewEngine.settle(rec, com.klinealert.nativeapp.domain.ReviewOutcome("miss", rec.stop, 0), now)) }
                hit -> runCatching { store.updateReview(ReviewEngine.settle(rec, com.klinealert.nativeapp.domain.ReviewOutcome("hit", rec.target, 0), now)) }
                miss -> runCatching { store.updateReview(ReviewEngine.settle(rec, com.klinealert.nativeapp.domain.ReviewOutcome("miss", rec.stop, 0), now)) }
                expired != rec -> runCatching { store.updateReview(expired) }
            }
        }
    }

    // ------------------------------------------------------------------ //
    // v4.6 后台自动作战：持仓止盈/止损/移动止盈（退出后台不断联）
    // ------------------------------------------------------------------ //

    /** 每 60 秒轮询全部 LIVE 持仓：用标记价判平仓（实时 + 天然抗插针，与前台口径一致）；失败回退 K 线收盘价。 */
    private suspend fun positionWatchLoop(market: String, timeframes: List<String>) {
        val tf = timeframes.first()
        while (currentCoroutineContext().isActive) {
            val positions = runCatching { store.loadPositions(market) }.getOrDefault(emptyList())
                .filter { it.status == "LIVE" }
            // v5.0.11 优先 markPrice（fapi premiumIndex，实时标记价抗插针）；冷门品种/限流时回退 K 线 close
            val marks = if (positions.isNotEmpty())
                runCatching { repo.markPrices(positions.map { it.symbol }) }.getOrDefault(emptyMap())
            else emptyMap()
            for (p in positions) {
                val price = marks[p.symbol]
                    ?: runCatching { repo.candles(p.symbol, market, p.timeframe.ifBlank { tf }, 1).lastOrNull()?.close }
                        .getOrNull()
                    ?: continue
                if (price <= 0 || !price.isFinite()) continue
                judgeAndClose(p, price)
            }
            delay(60_000L)
        }
    }

    /** 用最新价对单个持仓做平仓判定 + 移动止盈锚点更新。
     *  v5.0.17：有 K 线（websocket 收盘）时先跑 [ExitStateMachine] 分档出场（进取档 2R 保本/稳健 2R 落袋/3R 延续/反转/时间）；
     *  无 K 线（60s 标记价轮询）时走固定/吊灯止盈止损兜底，且读的是库中最新 stop/target（前台分档保本移动后会跟随）。 */
    private fun judgeAndClose(p: LocalStore.LocalPosition, price: Double, candles: List<Candle>? = null) {
        val now = System.currentTimeMillis()
        if (candles != null && candles.size >= 35) {
            val tf = p.timeframe.ifBlank { "1h" }
            val closed = candles.dropLast(1)
            val latest = closed.lastOrNull()
            val a = runCatching { AnalysisEngine.analyze(p.symbol, p.market, tf, closed) }.getOrNull()
            if (a != null && a.atr > 0 && latest != null) {
                val structure = runCatching { StructureEngine.evaluate(closed, a.atr) }.getOrNull()
                val anchor = if (p.lastRaiseAt > 0) p.lastRaiseAt else p.createdAt
                val barsSince = if (anchor > 0) ((latest.openTime - anchor) / tfMs(tf)).toInt() else 0
                val cfg = ExitStateMachine.ExitConfig(
                    continuationEnabled = true,
                    stopMult = p.stopMult, targetMult = p.targetMult,
                    tier = p.tier, breakEvenR = TargetTier.DEFAULT_BREAK_EVEN_R
                )
                val d = ExitStateMachine.evaluate(
                    p.direction, p.entry, p.stop, p.target, price, a, structure, latest,
                    p.trailCount, barsSince, p.bestPrice, p.breakEvenDone, cfg
                )
                if (d.isRaise) {
                    val nb = BattleLoopEngine.updatedBest(p.direction, p.bestPrice, price)
                    runCatching {
                        store.savePosition(
                            p.copy(
                                stop = d.newStop, target = d.newTarget,
                                trailCount = d.trailCount, stage = d.stage, lastRaiseAt = now,
                                bestPrice = nb, breakEvenDone = p.breakEvenDone || d.breakEvenDone,
                                updatedAt = now
                            )
                        )
                    }
                    return
                }
                if (d.isExit) {
                    val pnl = BattleLoopEngine.movePct(p.entry, price, p.direction)
                    val type = when (d.action) {
                        ExitStateMachine.ACTION_EXIT_TARGET -> BattleLoopEngine.CLOSE_TAKE_PROFIT
                        ExitStateMachine.ACTION_EXIT_STOP ->
                            if (p.breakEvenDone || p.trailCount > 0) BattleLoopEngine.CLOSE_TRAIL_STOP
                            else BattleLoopEngine.CLOSE_STOP_LOSS
                        else -> if (pnl >= 0) BattleLoopEngine.CLOSE_TRAIL_STOP else BattleLoopEngine.CLOSE_STOP_LOSS
                    }
                    closeBattlePosition(p, BattleLoopEngine.CloseDecision(type, price, pnl, d.label))
                    return
                }
                val nb = BattleLoopEngine.updatedBest(p.direction, p.bestPrice, price)
                if (nb != p.bestPrice) {
                    runCatching { store.savePosition(p.copy(bestPrice = nb, updatedAt = now)) }
                }
                return
            }
        }
        val trailStep = if (p.atr > 0) BattleLoopEngine.DEFAULT_TRAIL_ATR * p.atr else 0.0
        val d = BattleLoopEngine.evaluateClose(
            p.direction, p.entry, p.stop, p.target, price, crossCheckOk = true,
            trailing = p.trailing, bestPrice = p.bestPrice, trailStep = trailStep
        )
        if (d != null) { closeBattlePosition(p, d); return }
        val nb = BattleLoopEngine.updatedBest(p.direction, p.bestPrice, price)
        if (nb != p.bestPrice) {
            runCatching { store.savePosition(p.copy(bestPrice = nb, updatedAt = System.currentTimeMillis())) }
        }
    }

    private fun tfMs(tf: String): Long = when (tf) {
        "1m" -> 60_000L; "3m" -> 180_000L; "5m" -> 300_000L; "15m" -> 900_000L
        "30m" -> 1_800_000L; "1h" -> 3_600_000L; "2h" -> 7_200_000L; "4h" -> 14_400_000L
        "6h" -> 21_600_000L; "8h" -> 28_800_000L; "12h" -> 43_200_000L; "1d" -> 86_400_000L
        else -> 3_600_000L
    }

    /** 扫描轮兜底：用本轮扫描最新价批量判持仓平仓。 */
    private fun settleBattlePositions(market: String, priceBySymbol: Map<String, Double>) {
        val positions = runCatching { store.loadPositions(market) }.getOrDefault(emptyList())
            .filter { it.status == "LIVE" }
        positions.forEach { p ->
            val price = priceBySymbol[p.symbol] ?: return@forEach
            if (price <= 0 || !price.isFinite()) return@forEach
            judgeAndClose(p, price)
        }
    }

    /** 后台自动平仓：写 auto| 结算样本 → 写统一平仓台账（v5.0.17）→ 删除持仓（消失）→ 冷却落库 → 系统通知。
     *  v4.8 审计：双端平仓原子守卫——只有首个写入方才保存样本与发通知（前台 VM 可能同 tick 先平，避免重复通知）。 */
    private fun closeBattlePosition(p: LocalStore.LocalPosition, d: BattleLoopEngine.CloseDecision) {
        val hit = d.action == BattleLoopEngine.CLOSE_TAKE_PROFIT || d.action == BattleLoopEngine.CLOSE_TRAIL_STOP
        val now = System.currentTimeMillis()
        val rec = ReviewRecord(
            id = "auto|${p.market}|${p.symbol}|${p.direction}|${p.createdAt}",
            symbol = p.symbol, market = p.market, timeframe = p.timeframe.ifBlank { "auto" },
            direction = p.direction, entry = p.entry, stop = p.stop, target = p.target,
            score = p.evidenceScore, alertedAt = p.createdAt,
            verdict = if (hit) "hit" else "miss", verdictAt = now, hitPrice = d.closePrice,
            evidenceScore = p.evidenceScore
        )
        battleClosedKeys["${p.symbol}|${p.direction}"] = now
        val firstWriter = !runCatching { store.reviewExists(rec.id) }.getOrDefault(false)
        runCatching { store.saveCooldown(p.symbol, p.direction, now) }   // v4.8：冷却落库，前台重启防重入
        if (firstWriter) {
            runCatching { store.saveReview(rec) }
            // v5.0.17 统一平仓台账：所有后台自动平仓都记账（分档/保本/止盈/止损/反转/时间），修工作台统计为空
            runCatching {
                val reason = when {
                    d.reason.contains("反转") -> ClosedTrade.R_REVERSE
                    d.reason.contains("时间") -> ClosedTrade.R_TIMEOUT
                    d.action == BattleLoopEngine.CLOSE_TAKE_PROFIT -> ClosedTrade.R_TARGET
                    d.action == BattleLoopEngine.CLOSE_TRAIL_STOP -> ClosedTrade.R_BREAKEVEN
                    else -> ClosedTrade.R_STOP
                }
                recordClosedTrade(p, d.closePrice, reason, ClosedTrade.S_BACKGROUND, now)
            }
        }
        runCatching { store.deletePosition(p.id) }
        if (firstWriter) notifyAutoClose(p, d, hit)
    }

    /** v5.0.17 写统一平仓台账（幂等）；R 按开仓原始风险 atr×stopMult 归一化，保本单(R≈0)不算胜。 */
    private fun recordClosedTrade(
        p: LocalStore.LocalPosition, closePrice: Double, reason: String, source: String, now: Long
    ) {
        val id = "closed|${p.id}"
        if (runCatching { store.closedTradeExists(id) }.getOrDefault(false)) return
        val long = p.direction != "SHORT"
        val origRisk = (p.atr * p.stopMult).takeIf { it > 0 }
            ?: kotlin.math.abs(p.entry - p.stop).takeIf { it > 0 }
            ?: 0.0
        val move = if (long) closePrice - p.entry else p.entry - closePrice
        val realizedR = if (origRisk > 0) move / origRisk else 0.0
        val pnlPct = if (p.entry > 0) (closePrice - p.entry) / p.entry * 100.0 * (if (long) 1 else -1) else 0.0
        val pnlUsdt = com.klinealert.nativeapp.domain.PositionEngine.pnlUsdt(p.size, p.leverage, pnlPct)
        val win = realizedR > 0.05
        val barsHeld = if (p.createdAt > 0) ((now - p.createdAt) / tfMs(p.timeframe.ifBlank { "1h" })).toInt() else 0
        val ct = ClosedTrade(
            id = id, market = p.market, symbol = p.symbol, direction = p.direction,
            timeframe = p.timeframe, tier = p.tier,
            entry = p.entry, stop = p.stop, target = p.target, closePrice = closePrice,
            leverage = p.leverage, margin = p.size, realizedR = realizedR,
            realizedPnlUsdt = pnlUsdt, win = win, reason = reason, source = source,
            trailCount = p.trailCount, openedAt = p.createdAt, closedAt = now, barsHeld = barsHeld
        )
        runCatching { store.saveClosedTrade(ct) }
    }

    private fun notifyAutoClose(p: LocalStore.LocalPosition, d: BattleLoopEngine.CloseDecision, hit: Boolean) {
        val title = "🤖 自动${if (hit) "止盈" else "止损"}：${p.symbol}"
        // size=本金 USDT；盈亏=本金×杠杆×变动%/100（不再把百分点×50 放大 100 倍）
        val actual = com.klinealert.nativeapp.domain.PositionEngine.pnlUsdt(p.size, p.leverage, d.pnlPct)
        val yld = com.klinealert.nativeapp.domain.PositionEngine.yieldPct(p.leverage, d.pnlPct)
        val text = "${d.reason} · 价格 ${String.format(java.util.Locale.US, "%+.2f", d.pnlPct)}% · 盈亏 ${String.format(java.util.Locale.US, "%+.2f", actual)}U · 收益 ${String.format(java.util.Locale.US, "%+.1f", yld)}%（本金${p.size}×${p.leverage.toInt()}x）"
        val contentIntent = PendingIntent.getActivity(
            this, alertSeq++,
            Intent(this, MainActivity::class.java).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification = Notification.Builder(this, CHANNEL_ALERTS)
            .setSmallIcon(R.drawable.ic_monitor)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(contentIntent)
            .build()
        runCatching { notifications.notify(alertIdSeq.incrementAndGet(), notification) }
    }

    private fun watchUniverse(market: String, timeframe: String, symbols: List<String>, failure: CompletableDeferred<Unit>) {
        val sockets = repo.watchUniverseKlines(symbols, market, timeframe, onCandle = { symbol, _, history ->
            if (history.size < 220) return@watchUniverseKlines
            val openTime = history.last().openTime
            val previous = lastOpenTimes.put(key(market, timeframe, symbol), openTime)
            if (previous != null && openTime <= previous) return@watchUniverseKlines
            val closedBars = history.dropLast(1)
            runCatching { settleReviews(market, symbol, timeframe, closedBars) }
            // v4.6 后台自动平仓：新 K 线收盘即判该品种持仓（止盈/止损/移动止盈）
            runCatching {
                store.loadPositions(market).firstOrNull { it.symbol == symbol && it.status == "LIVE" }
                    ?.let { judgeAndClose(it, history.last().close, history) }
            }
            val analysis = runCatching { AnalysisEngine.analyze(symbol, market, timeframe, history) }.getOrNull()
                ?: return@watchUniverseKlines
            val k = key(market, timeframe, symbol)
            val old = lastDirections.put(k, analysis.direction)
            store.saveAnalyses(market, timeframe, listOf(analysis))
            // Scan seeding recorded the pre-existing direction; old == null/NEUTRAL means a
            // brand-new signal on a symbol that had none, otherwise it is a direction flip.
            val isNew = old == null || old == "NEUTRAL"
            if (analysis.direction != "NEUTRAL" && (isNew || old != analysis.direction)) {
                if (cooldownOk(market, symbol, analysis.direction)) {
                    notifySignal(if (isNew) null else old, analysis, highPriority = analysis.score >= 75 && analysis.confidence >= 70)
                }
            }
            // 持仓反向预警：始终强提醒，不受冷却限制
            if (analysis.direction != "NEUTRAL") {
                val hasReverse = runCatching { store.loadPositions(market) }.getOrDefault(emptyList())
                    .any { it.symbol == symbol && it.direction != analysis.direction }
                if (hasReverse) notifyPositionRisk(symbol, analysis)
            }
        }, onError = { failure.complete(Unit) })
        synchronized(watchSockets) { watchSockets.addAll(sockets) }
    }

    /** Same settle logic as the ViewModel: only fires while new candles arrive. */
    private fun settleReviews(market: String, symbol: String, timeframe: String, candles: List<Candle>) {
        val records = runCatching { store.loadReviews(market, 500) }.getOrDefault(emptyList())
        val now = System.currentTimeMillis()
        records.asSequence()
            .filter { it.verdict == "open" && it.symbol == symbol && it.timeframe == timeframe }
            .forEach { record ->
                val expired = ReviewEngine.expire(record, now)
                val updated = if (expired.verdict != "open") expired else {
                    val afterAlert = candles.filter { it.openTime > record.alertedAt }
                    if (afterAlert.isEmpty()) record else ReviewEngine.settle(record, ReviewEngine.touch(afterAlert, record), now)
                }
                if (updated != record) runCatching { store.updateReview(updated) }
            }
    }

    private fun closeWatchSockets() {
        synchronized(watchSockets) {
            watchSockets.forEach { runCatching { it.cancel() } }
            watchSockets.clear()
        }
    }

    private fun key(market: String, timeframe: String, symbol: String) = "$market|$timeframe|$symbol"

    /** 同品种同方向 30 分钟信号冷却，抑制通知轰炸。 */
    private val lastAlertAt = ConcurrentHashMap<String, Long>()
    private fun cooldownOk(market: String, symbol: String, direction: String): Boolean {
        val k = "$market|$symbol|$direction"
        val now = System.currentTimeMillis()
        val last = lastAlertAt[k] ?: 0L
        if (now - last < 30 * 60_000L) return false
        lastAlertAt[k] = now
        return true
    }

    // ------------------------------------------------------------------ //
    // 通知
    // ------------------------------------------------------------------ //

    private fun createChannels() {
        notifications.createNotificationChannel(
            NotificationChannel(CHANNEL_ONGOING, "后台预警运行状态", NotificationManager.IMPORTANCE_LOW)
        )
        // A 级强提醒（声音+振动），B/C 级静默入列表。
        notifications.createNotificationChannel(
            NotificationChannel(CHANNEL_ALERTS, "K线信号预警（强提醒）", NotificationManager.IMPORTANCE_HIGH).apply {
                enableVibration(true)
            }
        )
        notifications.createNotificationChannel(
            NotificationChannel(CHANNEL_ALERTS_SILENT, "K线信号预警（静默）", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun startAsForeground(text: String) {
        val notification = buildOngoing(text)
        // specialUse type is only valid on API 34+; older versions use the default type.
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(ONGOING_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(ONGOING_ID, notification)
        }
    }

    private fun updateOngoing(text: String, done: Int, total: Int) {
        runCatching { notifications.notify(ONGOING_ID, buildOngoing(text, done, total)) }
    }

    private fun buildOngoing(text: String, done: Int = 0, total: Int = 0): Notification {
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, BackgroundMonitorService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val builder = Notification.Builder(this, CHANNEL_ONGOING)
            .setSmallIcon(R.drawable.ic_monitor)
            .setContentTitle("K线预警 · 后台监控运行中")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(Notification.Action.Builder(R.drawable.ic_monitor, "停止预警", stopIntent).build())
        if (total > 0) builder.setProgress(total, done, false)
        return builder.build()
    }

    private fun notifyPositionRisk(symbol: String, a: Analysis) {
        val title = "⚠ 持仓反向预警：$symbol"
        val text = "你的持仓方向与最新 ${a.direction} 信号（${a.timeframe}，评分 ${a.score}）相反，注意风控"
        val contentIntent = PendingIntent.getActivity(
            this, alertSeq++,
            Intent(this, MainActivity::class.java).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification = Notification.Builder(this, CHANNEL_ALERTS)
            .setSmallIcon(R.drawable.ic_monitor)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(contentIntent)
            .build()
        runCatching { notifications.notify(alertIdSeq.incrementAndGet(), notification) }
    }

    private fun notifySignal(previousDirection: String?, a: Analysis, highPriority: Boolean = false) {
        val title = if (previousDirection == null) "${a.symbol} ${a.timeframe} 新信号：${a.direction}"
        else "${a.symbol} ${a.timeframe} 信号变化：$previousDirection → ${a.direction}"
        val text = "评分 ${a.score} · 可信度 ${a.confidence}% · 阶段 ${a.regime}" +
            if (highPriority) " · 高分信号" else ""
        val contentIntent = PendingIntent.getActivity(
            this, alertSeq++,
            Intent(this, MainActivity::class.java).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification = Notification.Builder(this, if (highPriority) CHANNEL_ALERTS else CHANNEL_ALERTS_SILENT)
            .setSmallIcon(R.drawable.ic_monitor)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(contentIntent)
            .build()
        runCatching { notifications.notify(alertIdSeq.incrementAndGet(), notification) }
    }
}
