package com.klinealert.nativeapp.domain

import kotlin.math.abs

/**
 * 待命单（Pending Setup）——v3.8 核心：把「机会」从状态快照改成「价格到 X 我就进」的挂单。
 *
 * 三重门锁（Gate）：
 *  - 位置门：价格必须回到结构位（支撑/压力/前低前高/EMA20）±0.5×ATR 内
 *  - 信号门：必须出现「新鲜」触发（MACD 刚交叉 ≤2 根 / 缩量回踩形态 / 放量突破收回）
 *  - 时间门：触发必须发生在最近 2 根 K 线内（事件属性，而非陈旧状态）
 *
 * 状态机（v4.1 加入回踩确认）：
 *  PENDING(待命·未到位) → ARMED(已到触发价·等回踩确认)
 *                       → TRIGGERED(⚡回踩确认·可入场) → CONFIRMED(已确认) / REGRET(反悔取消)
 *                       → EXPIRED(窗口过期作废 / 破失效价)
 *
 * 回踩确认（Pullback Confirm）解决的问题：价格冲过触发价那一刻往往是「插针/追高」，
 * 直接给「可入场」会让用户接到最差价位。改为：先 ARMED，等一次回踩不破再确认入场。
 *  - ARMED 判定：价格第一次触及触发价
 *  - 确认：ARMED 后价格回踩到触发价 ±0.5×ATR 内，且期间未破失效价
 *  - 追高保护：ARMED 后若价格顺势走出 > 1.2×ATR 仍未回踩 → 不再确认（避免追高）
 *  - 超时：ARMED 超过 pullbackWindow（按周期 2~3 根K线）未确认 → EXPIRED
 */
data class PendingSetup(
    val key: String,              // market|symbol|direction
    val symbol: String,
    val market: String,
    val direction: String,
    val timeframe: String,
    /** 触发价：做多=回踩入场；做空=反抽入场 */
    val triggerPrice: Double,
    /** 失效价：破此价机会作废 */
    val invalidPrice: Double,
    /** 参考止损（结构位或 stopMult×ATR）与 targetMult×风险止盈（v5.0.9 全局乘数） */
    val stop: Double,
    val target3R: Double,
    val atr: Double,
    val score: Int,
    val evidenceScore: Int,
    val gatePosition: Boolean,
    val gateSignal: Boolean,
    val gateTime: Boolean,
    val missingGate: String,      // 还差哪道门（UI 显示"在等什么"）
    val createdAt: Long,          // 生成时间（新分页按此倒序）
    val triggerWindowMs: Long,    // 有效窗口（按周期，方向不对称）
    val expireAt: Long,
    val status: String = PENDING,
    val triggeredAt: Long = 0L,
    val triggeredPrice: Double = 0.0,
    /** v4.1 回踩确认：ARMED 时刻（首次触及触发价的时间） */
    val armedAt: Long = 0L,
    /** v4.1 回踩确认：ARMED 期间触及的极值价（做多取最低，做空取最高），用于追高保护 */
    val armedExtreme: Double = 0.0,
    val note: String = ""         // 形态/触发原因说明
) {
    companion object {
        const val PENDING = "待命"
        /** v4.1 已到触发价，等待回踩确认（不再是可入场） */
        const val ARMED = "等回踩确认"
        const val TRIGGERED = "已触发"
        const val CONFIRMED = "已确认"
        const val REGRET = "触发后反悔"
        const val EXPIRED = "已过期"
    }

    val active: Boolean get() = status == PENDING || status == ARMED || status == TRIGGERED
    /** 距离触发价的百分比（未到位为负向间距，正数表示还有多少空间） */
    fun distPct(live: Double?): Double? {
        val p = live?.takeIf { it > 0 } ?: return null
        return (triggerPrice - p) / p * 100
    }
    /** 剩余有效时间（毫秒） */
    fun remainMs(now: Long): Long = (expireAt - now).coerceAtLeast(0L)
}

object PendingSetupEngine {
    /** 周期 → 窗口根数（做多基准），做空不对称缩到 60% */
    private val windowBars = mapOf("5m" to 5, "15m" to 4, "30m" to 3, "1h" to 3, "4h" to 2)
    /** v4.1 回踩确认窗口：ARMED 后允许等待的根数（太长会错过、太短会误判） */
    private val pullbackBars = mapOf("5m" to 3, "15m" to 3, "30m" to 2, "1h" to 2, "4h" to 1)
    private val tfMillis = mapOf(
        "5m" to 5 * 60_000L, "15m" to 15 * 60_000L, "30m" to 30 * 60_000L,
        "1h" to 60 * 60_000L, "4h" to 4 * 60 * 60_000L
    )

    /** v4.1 回踩确认窗口（毫秒）：ARMED 后等回踩确认的最长时间；做空窗口 ×0.6 */
    fun pullbackWindowOf(timeframe: String, direction: String): Long {
        val bars = pullbackBars[timeframe] ?: 2
        val tf = tfMillis[timeframe] ?: 15 * 60_000L
        val mul = if (direction == "SHORT") 0.6 else 1.0
        return (bars * tf * mul).toLong()
    }

    /** v4.1 回踩容差：确认时价格与触发价允许的偏离（ATR 倍数） */
    private const val PULLBACK_TOL_ATR = 0.5
    /** v4.1 追高保护：ARMED 后价格顺势走出超过该 ATR 倍数仍未回踩 → 视为已错过 */
    private const val CHASE_GUARD_ATR = 1.2

    fun keyOf(market: String, symbol: String, direction: String) = "$market|$symbol|$direction"

    /** 有效窗口：按代表周期根数；做空窗口 ×0.6（下跌机会窗口更窄） */
    fun windowOf(timeframe: String, direction: String, now: Long): Long {
        val bars = windowBars[timeframe] ?: 4
        val tf = tfMillis[timeframe] ?: 15 * 60_000L
        val mul = if (direction == "SHORT") 0.6 else 1.0
        return (bars * tf * mul).toLong()
    }

    /**
     * 构建待命单：三门评估。
     * 只有「位置门」通过才建单（否则价格根本不在可埋伏区，等也是白等）；
     * 信号门/时间门未过 → 状态仍为待命，但标注"还差哪道门"。
     */
    /** v5.0.9 默认全局乘数：与 BattleLoopEngine 一致（止损 2×ATR / 止盈 3×风险） */
    private const val DEFAULT_STOP_MULT = 2.0
    private const val DEFAULT_TARGET_MULT = 3.0

    fun build(sop: SymbolOpportunity, live: Double?, evidence: EvidenceEngine.Evidence?, winRate: Pair<Int, Double>?, confirmRate: Double?, now: Long = System.currentTimeMillis(),
              stopMult: Double = DEFAULT_STOP_MULT, targetMult: Double = DEFAULT_TARGET_MULT): PendingSetup? {
        val a = sop.rep
        val long = sop.direction == "LONG"
        val atr = a.atr.takeIf { it != null && it > 0 } ?: return null
        val price = live?.takeIf { it > 0 } ?: a.price
        val tf = a.timeframe
        // 触发价：结构位优先（支撑/EMA20 上方 0.2×ATR；做空镜像）
        val struct = if (long) (a.support ?: a.ema20 ?: a.entry) else (a.resistance ?: a.ema20 ?: a.entry)
        val trigger = if (long) struct + 0.2 * atr else struct - 0.2 * atr
        // v5.0.9 止损：默认 stopMult×ATR（原 1.5×ATR 硬编码改为全局乘数）
        val stop = a.stop.takeIf { it > 0 } ?: (if (long) trigger - stopMult * atr else trigger + stopMult * atr)
        // 方向不对称：做空止损缓冲 ×1.25（下跌插针更狠，止损放到更远的压力侧上方）
        val stopAdj = if (long) stop else stop + abs(stop - trigger) * 0.25
        val risk = abs(stopAdj - trigger).takeIf { it > 0 } ?: stopMult * atr
        // v5.0.9 止盈：targetMult×风险距离（原 3×risk 硬编码改为全局乘数）
        val target = if (long) trigger + targetMult * risk else trigger - targetMult * risk
        val invalid = stopAdj
        // 位置门：live 与触发价偏离 ≤0.5×ATR（已在可埋伏区）
        val gatePos = abs(price - trigger) <= 0.5 * atr
        // 信号门：新鲜触发
        val freshCross = a.states.any { st ->
            (st.name == "MACD" || st.name == "KDJ" || st.name == "EMA9/21") &&
                Regex("(\\d+) 根K线前").find(st.detail)?.groupValues?.getOrNull(1)?.toIntOrNull()?.let { it <= 2 } == true &&
                ((long && st.state.contains("多头")) || (!long && st.state.contains("空头")))
        }
        val goodPattern = a.volumePattern == "缩量回踩" && long || a.volumePattern == "缩量反抽" && !long ||
            a.volumePattern == "放量突破" || a.volumePattern == "恐慌抛售" && long
        val gateSig = freshCross || goodPattern
        // 时间门：机会事件新鲜度（代表周期K线时间距现在 ≤2 根）
        val tfMs = tfMillis[tf] ?: 15 * 60_000L
        val barsSince = ((now - a.candleTime).coerceAtLeast(0)).toDouble() / tfMs
        val gateTime = barsSince <= 2.0
        val missing = when {
            !gatePos -> "等价格到位"
            !gateSig -> "等信号触发"
            !gateTime -> "等新一轮K线"
            else -> ""
        }
        val evScore = evidence?.score ?: sop.score
        val win = windowOf(tf, sop.direction, now)
        return PendingSetup(
            key = keyOf(sop.market, sop.symbol, sop.direction), symbol = sop.symbol, market = sop.market,
            direction = sop.direction, timeframe = tf, triggerPrice = trigger, invalidPrice = invalid,
            stop = stopAdj, target3R = target, atr = atr, score = sop.score, evidenceScore = evScore,
            gatePosition = gatePos, gateSignal = gateSig, gateTime = gateTime, missingGate = missing,
            createdAt = now, triggerWindowMs = win, expireAt = now + win,
            status = PendingSetup.PENDING,
            note = if (goodPattern) a.volumePattern else if (freshCross) "指标刚交叉" else ""
        )
    }

    /**
     * tick 驱动状态机（v4.1 含回踩确认）：
     *  - PENDING：破失效价 → EXPIRED；触及触发价 → ARMED（等回踩确认，不再直接可入场）
     *  - ARMED  ：破失效价 → EXPIRED；价格回踩到触发价 ±0.5×ATR → TRIGGERED（确认可入场）；
     *             顺势走出 > 1.2×ATR 未回踩 → EXPIRED（追高保护）；超 pullbackWindow → EXPIRED
     *  - TRIGGERED：2 根K线内反向量价形态 → REGRET
     */
    fun onTick(s: PendingSetup, price: Double, now: Long, volumePattern: String = ""): PendingSetup {
        if (!s.active || price <= 0) return s
        // 窗口过期（TRIGGERED 之后不再按窗口作废，交给结算）
        if (now > s.expireAt && s.status != PendingSetup.TRIGGERED) {
            return s.copy(status = PendingSetup.EXPIRED, note = "窗口过期作废")
        }
        val long = s.direction == "LONG"
        val atr = s.atr.takeIf { it > 0 } ?: 0.0
        // ── 待命：破失效价 → 作废；触及触发价 → 进入等回踩确认
        if (s.status == PendingSetup.PENDING) {
            val broken = if (long) price <= s.invalidPrice else price >= s.invalidPrice
            if (broken) return s.copy(status = PendingSetup.EXPIRED, note = "已破失效位作废")
            val hit = if (long) price <= s.triggerPrice else price >= s.triggerPrice
            if (hit) {
                return s.copy(
                    status = PendingSetup.ARMED, armedAt = now, triggeredPrice = price,
                    armedExtreme = price, note = "已到触发价，等回踩确认"
                )
            }
        }
        // ── 等回踩确认：确认入场 / 破位作废 / 追高保护 / 超时
        if (s.status == PendingSetup.ARMED) {
            val broken = if (long) price <= s.invalidPrice else price >= s.invalidPrice
            if (broken) return s.copy(status = PendingSetup.EXPIRED, note = "等回踩期间破失效位")
            // 更新期间极值（做多跟踪最低，做空跟踪最高）
            val ext = if (s.armedExtreme <= 0.0) price else if (long) kotlin.math.min(s.armedExtreme, price) else kotlin.math.max(s.armedExtreme, price)
            // 追高保护：ARMED 后顺势走出过多，不再确认（避免追在最高点/最低点）
            val runaway = if (long) price - s.triggerPrice > CHASE_GUARD_ATR * atr
                          else s.triggerPrice - price > CHASE_GUARD_ATR * atr
            if (runaway) return s.copy(status = PendingSetup.EXPIRED, armedExtreme = ext, note = "已顺势走远，错过入场区")
            // 超时：等回踩太久 → 作废
            if (now - s.armedAt > pullbackWindowOf(s.timeframe, s.direction)) {
                return s.copy(status = PendingSetup.EXPIRED, armedExtreme = ext, note = "等回踩确认超时")
            }
            // 回踩确认：价格回到触发价 ±0.5×ATR 容差内（且未破失效价）
            val tol = PULLBACK_TOL_ATR * atr
            if (kotlin.math.abs(price - s.triggerPrice) <= tol) {
                return s.copy(status = PendingSetup.TRIGGERED, triggeredAt = now, triggeredPrice = price,
                    armedExtreme = ext, note = "回踩确认，可入场")
            }
            return s.copy(armedExtreme = ext)
        }
        // ── 已触发：反悔机制（2 根K线内反向形态）
        if (s.status == PendingSetup.TRIGGERED) {
            val tfMs = tfMillis[s.timeframe] ?: 15 * 60_000L
            val sinceTrigger = now - s.triggeredAt
            val adverse = (long && volumePattern == "放量下跌") || (!long && volumePattern == "放量上涨")
            if (adverse && sinceTrigger <= 2 * tfMs) {
                return s.copy(status = PendingSetup.REGRET, note = "触发后出现$volumePattern，建议放弃")
            }
        }
        return s
    }
}
