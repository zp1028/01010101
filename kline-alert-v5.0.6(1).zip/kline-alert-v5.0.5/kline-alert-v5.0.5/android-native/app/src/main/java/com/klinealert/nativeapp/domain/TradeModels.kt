package com.klinealert.nativeapp.domain

/**
 * 币安 U 本位跟单领域模型。
 * size/本金口径与 PositionEngine 一致：marginUsdt 为投入保证金。
 */
object TradeModels {

    const val STATUS_PENDING_OPEN = "PENDING_OPEN"
    const val STATUS_OPEN = "OPEN"
    const val STATUS_CLOSING = "CLOSING"
    const val STATUS_CLOSED = "CLOSED"
    const val STATUS_FAILED = "FAILED"

    const val CLOSE_TP = "take_profit"
    const val CLOSE_SL = "stop_loss"
    const val CLOSE_TRAIL = "trail_stop"
    const val CLOSE_MANUAL = "manual"
    const val CLOSE_EXTERNAL = "external"
    const val CLOSE_EMERGENCY = "emergency"

    /** 跟单配置（存 prefs + 内存）。 */
    data class TradeConfig(
        val enabled: Boolean = false,
        val testnet: Boolean = true,
        val marginUsdt: Double = 10.0,
        val maxLeverageCap: Int = 20,
        val useMaxLeverage: Boolean = true,
        val maxFollowSlots: Int = 3,
        val onlyAutoBattle: Boolean = true,
        val slipProtectPct: Double = 0.5,
        val dailyMaxOpens: Int = 20,
        val dailyMaxLossUsdt: Double = 50.0,
        val symbolDirCooldownMs: Long = 90_000L,
        /** 仅跟随本地建仓后 N ms 内的仓，避免过时入场价。默认 5 分钟。 */
        val maxFollowAgeMs: Long = 5 * 60_000L,
        /** v5.0.12 滑点保护：成交价距止损的最小距离 = 止损距离 × 该比例（默认 30%）。 */
        val minStopGapRatio: Double = 0.3,
        /** v5.0.12 成交价距止损不足安全距离时：true=拒绝开仓；false=仅记录告警继续。 */
        val rejectOnTightStop: Boolean = true
    )

    /** 本地仓 ↔ 实盘映射。 */
    data class TradeLink(
        val localPositionId: String,
        val symbol: String,
        val direction: String,
        val marginUsdt: Double,
        val leverage: Double,
        val qty: Double = 0.0,
        val status: String = STATUS_PENDING_OPEN,
        val entryOrderId: Long = 0L,
        val avgEntry: Double = 0.0,
        val stopOrderId: Long = 0L,
        val tpOrderId: Long = 0L,
        val stopPrice: Double = 0.0,
        val targetPrice: Double = 0.0,
        val markPrice: Double = 0.0,
        val unrealizedPnl: Double = 0.0,
        val commissionOpen: Double = 0.0,
        val commissionClose: Double = 0.0,
        val realizedPnlNet: Double = 0.0,
        val closeReason: String = "",
        val avgExit: Double = 0.0,
        val clientOrderId: String = "",
        val lastError: String = "",
        val source: String = "auto",
        val openedAt: Long = 0L,
        val closedAt: Long = 0L,
        val updatedAt: Long = System.currentTimeMillis()
    )

    data class AccountSnapshot(
        val availableBalance: Double = 0.0,
        val walletBalance: Double = 0.0,
        val totalUnrealized: Double = 0.0,
        val canTrade: Boolean = false,
        val positionMode: String = "",
        val accountIdMask: String = "",
        val fetchedAt: Long = 0L
    )

    data class TradeStats(
        val realizedPnl: Double = 0.0,
        val wins: Int = 0,
        val losses: Int = 0,
        val flats: Int = 0,
        val fees: Double = 0.0,
        val openCount: Int = 0,
        val floatingPnl: Double = 0.0,
        /** v5.0.13 已平仓累计本金（收益率分母） */
        val closedMarginUsdt: Double = 0.0,
        /** v5.0.13 当前持仓累计本金 */
        val openMarginUsdt: Double = 0.0
    ) {
        val winRate: Double
            get() {
                val d = wins + losses
                return if (d <= 0) 0.0 else wins * 100.0 / d
            }

        /** 已实现收益率：已实现盈亏 / 已平仓累计本金 × 100% */
        val realizedYieldPct: Double
            get() = if (closedMarginUsdt <= 0) 0.0 else realizedPnl / closedMarginUsdt * 100.0

        /** 浮动收益率：浮盈 / 当前持仓本金 × 100% */
        val floatingYieldPct: Double
            get() = if (openMarginUsdt <= 0) 0.0 else floatingPnl / openMarginUsdt * 100.0

        /** 总收益率（含浮盈）：(已实现+浮盈) / (已平仓本金+持仓本金) × 100% */
        val totalYieldPct: Double
            get() {
                val base = closedMarginUsdt + openMarginUsdt
                return if (base <= 0) 0.0 else (realizedPnl + floatingPnl) / base * 100.0
            }
    }

    data class TradeLog(
        val at: Long,
        val symbol: String,
        val action: String,
        val ok: Boolean,
        val detail: String
    )

    /** 稳定 clientOrderId（币安限制长度与字符）。 */
    fun clientOrderIdFor(localPositionId: String, kind: String = "o"): String {
        val h = localPositionId.hashCode().toUInt().toString(16)
        val base = localPositionId.filter { it.isLetterOrDigit() }.takeLast(12)
        return ("kl$kind$base$h").take(36)
    }

    fun quantity(marginUsdt: Double, leverage: Double, price: Double): Double {
        if (price <= 0 || marginUsdt <= 0 || leverage <= 0) return 0.0
        return marginUsdt * leverage / price
    }

    /**
     * v5.0.12 滑点保护判据（纯函数）：市价成交价（avg）与止损价的距离是否仍安全。
     * 规则：成交价距止损 ≥ 止损距离 × minStopGapRatio 才安全——滑点只要不逼近/越过止损即可。
     * @return 安全时返回 null；否则返回拒绝原因（含距离明细）。
     */
    fun tightStopReason(entry: Double, stop: Double, avg: Double, minStopGapRatio: Double): String? {
        if (entry <= 0 || stop <= 0 || avg <= 0) return null   // 无止损或无有效价不判
        if (minStopGapRatio <= 0) return null                  // 关闭保护
        val stopDist = kotlin.math.abs(stop - entry)
        if (stopDist <= 0) return null                         // 止损与入场同价（理论上不应发生）
        val minGap = stopDist * minStopGapRatio
        val actualGap = kotlin.math.abs(avg - stop)
        return if (actualGap < minGap)
            "滑点致止损过近：成交价 ${java.util.Locale.US.let { String.format(it, "%.6f", avg) }} 距止损 ${java.util.Locale.US.let { String.format(it, "%.6f", stop) }} 仅 ${java.util.Locale.US.let { String.format(it, "%.6f", actualGap) }}（安全距离需 ≥ ${java.util.Locale.US.let { String.format(it, "%.6f", minGap) }}）"
        else null
    }

    fun netPnl(qty: Double, direction: String, entry: Double, exit: Double, feeOpen: Double, feeClose: Double): Double {
        if (qty <= 0 || entry <= 0 || exit <= 0) return 0.0
        val raw = if (direction.equals("SHORT", true)) qty * (entry - exit) else qty * (exit - entry)
        return raw - feeOpen - feeClose
    }

    fun yieldPct(netPnl: Double, marginUsdt: Double): Double {
        if (marginUsdt <= 0) return 0.0
        return netPnl / marginUsdt * 100.0
    }

    fun statsFrom(links: List<TradeLink>, openLinks: List<TradeLink>, eps: Double = 0.01): TradeStats {
        var realized = 0.0
        var fees = 0.0
        var w = 0
        var l = 0
        var f = 0
        links.filter { it.status == STATUS_CLOSED }.forEach { t ->
            realized += t.realizedPnlNet
            fees += t.commissionOpen + t.commissionClose
            when {
                t.realizedPnlNet > eps -> w++
                t.realizedPnlNet < -eps -> l++
                else -> f++
            }
        }
        val floating = openLinks.sumOf { it.unrealizedPnl }
        val closedMargin = links.filter { it.status == STATUS_CLOSED }.sumOf { it.marginUsdt }
        val openMargin = openLinks.sumOf { it.marginUsdt }
        return TradeStats(realized, w, l, f, fees, openLinks.size, floating, closedMargin, openMargin)
    }
}
