package com.klinealert.nativeapp.domain

/**
 * v5.0.18 工作台统计图表引擎（纯 Kotlin，可单测）。
 *
 * 输入 = 统一平仓台账的样本（[Sample]，由 UI 层从 `LocalStore.ClosedTrade` 映射，
 * 因此本文件不依赖任何 Android 类）；输出 = 直接可绘制的图表数据：
 *  - 汇总卡：笔数/胜率/总 R/平均 R/期望 R/盈亏比/累计 USDT；
 *  - 两档对比：稳健 vs 进取 的笔数/胜率/总 R（[Bucket]）；
 *  - 平仓原因分布：止盈/止损/保本/反转/超时/轮换/手动；
 *  - R 分布直方图：[R_BINS] 固定区间；
 *  - 资金曲线：按平仓时间升序的累计 R 曲线（含起点 0）+ 最大回撤（R）。
 *
 * 口径与 [TargetTier] 一致：R 以开仓时风险距离归一化（1R = 止损距离）。
 */
object LedgerStats {

    // 与 LocalStore.ClosedTrade 的平仓原因常量同值（domain 保持零依赖，故此处复述）
    const val R_TARGET = "TARGET"
    const val R_STOP = "STOP"
    const val R_BREAKEVEN = "BREAKEVEN_STOP"
    const val R_REVERSE = "REVERSE"
    const val R_TIMEOUT = "TIMEOUT"
    const val R_ROTATE = "ROTATE"
    const val R_MANUAL = "MANUAL"

    const val TIER_STEADY = "STEADY"
    const val TIER_AGGRESSIVE = "AGGRESSIVE"

    /** 一笔平仓样本（UI 层从台账映射）。 */
    data class Sample(
        val tier: String,
        val reason: String,
        val realizedR: Double,
        val win: Boolean,
        val pnlUsdt: Double,
        val closedAt: Long = 0L,
        val symbol: String = ""
    )

    /** 分组统计（档位 / 原因 / R 区间共用）。 */
    data class Bucket(val key: String, val label: String, val count: Int, val wins: Int, val totalR: Double) {
        val winRate: Double get() = if (count > 0) wins.toDouble() / count else 0.0
        val avgR: Double get() = if (count > 0) totalR / count else 0.0
    }

    /** R 分布固定区间：上界（含），最后一档为 +∞。 */
    val R_BINS: List<Pair<String, Double>> = listOf(
        "≤-1R" to -1.0,
        "-1~-0.5R" to -0.5,
        "-0.5~0R" to 0.0,
        "0~0.5R" to 0.5,
        "0.5~1R" to 1.0,
        "1~2R" to 2.0,
        "2~3R" to 3.0,
        "≥3R" to Double.MAX_VALUE
    )

    data class Chart(
        val count: Int,
        val wins: Int,
        val losses: Int,
        val winRate: Double,
        val totalR: Double,
        val avgR: Double,
        val expectancyR: Double,
        val totalPnlUsdt: Double,
        val avgWinR: Double,
        val avgLossR: Double,
        /** 盈亏比 = 平均盈利 R / |平均亏损 R|（无亏损样本时为 +∞ 语义，返回 0 表示不可算）。 */
        val payoffRatio: Double,
        val maxDrawdownR: Double,
        val bestR: Double,
        val worstR: Double,
        val equity: List<Double>,
        val tiers: List<Bucket>,
        val reasons: List<Bucket>,
        val rHistogram: List<Bucket>
    ) {
        val empty: Boolean get() = count == 0
        /** 稳健档笔数占比（0..1，用于两档分布条）。 */
        val steadyShare: Double get() {
            val s = tiers.firstOrNull { it.key == TIER_STEADY }?.count ?: 0
            return if (count > 0) s.toDouble() / count else 0.0
        }
    }

    /** 构建图表数据。样本顺序无关（资金曲线按 [Sample.closedAt] 升序重排）。 */
    fun build(samples: List<Sample>): Chart {
        val n = samples.size
        if (n == 0) return emptyChart()
        val wins = samples.filter { it.win }
        val losses = samples.filterNot { it.win }
        val totalR = samples.sumOf { it.realizedR }
        val totalPnl = samples.sumOf { it.pnlUsdt }
        val avgWin = if (wins.isEmpty()) 0.0 else wins.sumOf { it.realizedR } / wins.size
        val avgLoss = if (losses.isEmpty()) 0.0 else losses.sumOf { it.realizedR } / losses.size
        val payoff = if (losses.isEmpty() || avgLoss == 0.0) 0.0 else avgWin / kotlin.math.abs(avgLoss)
        val ordered = samples.sortedBy { it.closedAt }
        val equity = mutableListOf(0.0)
        var run = 0.0
        ordered.forEach { run += it.realizedR; equity += run }
        return Chart(
            count = n,
            wins = wins.size,
            losses = losses.size,
            winRate = wins.size.toDouble() / n,
            totalR = totalR,
            avgR = totalR / n,
            expectancyR = totalR / n,
            totalPnlUsdt = totalPnl,
            avgWinR = avgWin,
            avgLossR = avgLoss,
            payoffRatio = payoff,
            maxDrawdownR = maxDrawdown(equity),
            bestR = samples.maxOf { it.realizedR },
            worstR = samples.minOf { it.realizedR },
            equity = equity,
            tiers = listOf(
                group(samples, TIER_STEADY, "稳健", tierOf = { it.tier }),
                group(samples, TIER_AGGRESSIVE, "进取", tierOf = { it.tier })
            ),
            reasons = reasonOrder().mapNotNull { r ->
                val g = samples.filter { it.reason == r }
                if (g.isEmpty()) null else bucket(r, reasonLabel(r), g)
            },
            rHistogram = histogram(samples)
        )
    }

    /** 平仓原因中文标签。 */
    fun reasonLabel(reason: String): String = when (reason) {
        R_TARGET -> "止盈"
        R_STOP -> "止损"
        R_BREAKEVEN -> "保本/移动止损"
        R_REVERSE -> "结构反转"
        R_TIMEOUT -> "时间止损"
        R_ROTATE -> "满仓轮换"
        R_MANUAL -> "手动平仓"
        else -> if (reason.isBlank()) "未知" else reason
    }

    /** 档位中文标签。 */
    fun tierLabel(tier: String): String = if (tier == TIER_AGGRESSIVE) "进取" else "稳健"

    /** 累计 R 曲线的最大回撤（峰值到谷底的最大跌幅，正数；空/单调不亏返回 0）。 */
    fun maxDrawdown(equity: List<Double>): Double {
        var peak = Double.NEGATIVE_INFINITY
        var dd = 0.0
        equity.forEach { v ->
            if (v > peak) peak = v
            val drop = peak - v
            if (drop > dd) dd = drop
        }
        return if (dd.isFinite()) dd else 0.0
    }

    /** 原因固定展示顺序（未知原因排在后面按原样追加）。 */
    private fun reasonOrder(): List<String> =
        listOf(R_TARGET, R_STOP, R_BREAKEVEN, R_REVERSE, R_TIMEOUT, R_ROTATE, R_MANUAL)

    private fun histogram(samples: List<Sample>): List<Bucket> {
        var lower = Double.NEGATIVE_INFINITY
        return R_BINS.map { (label, upper) ->
            val lo = lower
            val g = samples.filter { it.realizedR > lo && it.realizedR <= upper }
            lower = upper
            bucket(label, label, g, wins = g.count { it.win })
        }
    }

    private fun group(
        samples: List<Sample>, key: String, label: String,
        tierOf: (Sample) -> String
    ): Bucket = bucket(key, label, samples.filter { tierOf(it) == key })

    private fun bucket(key: String, label: String, g: List<Sample>, wins: Int = -1): Bucket = Bucket(
        key = key, label = label, count = g.size,
        wins = if (wins >= 0) wins else g.count { it.win },
        totalR = g.sumOf { it.realizedR }
    )

    private fun emptyChart() = Chart(
        count = 0, wins = 0, losses = 0, winRate = 0.0, totalR = 0.0, avgR = 0.0,
        expectancyR = 0.0, totalPnlUsdt = 0.0, avgWinR = 0.0, avgLossR = 0.0,
        payoffRatio = 0.0, maxDrawdownR = 0.0, bestR = 0.0, worstR = 0.0,
        equity = listOf(0.0),
        tiers = listOf(
            Bucket(TIER_STEADY, "稳健", 0, 0, 0.0),
            Bucket(TIER_AGGRESSIVE, "进取", 0, 0, 0.0)
        ),
        reasons = emptyList(),
        rHistogram = R_BINS.map { (label, _) -> Bucket(label, label, 0, 0, 0.0) }
    )
}
