package com.caifenxi.app.ui.screens

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.graphics.Bitmap
import android.os.Bundle
import android.os.Message
import android.webkit.JavascriptInterface
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import com.caifenxi.app.util.RuntimeLog
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.DragHandle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay
import kotlin.math.roundToInt
import com.caifenxi.app.automation.LocalSelectorLoader
import com.caifenxi.app.data.config.UrlHistoryStore
import com.caifenxi.app.domain.execution.ClickMatchConfig
import com.caifenxi.app.domain.execution.ExecutorManager
import com.caifenxi.app.domain.execution.ExecutionTicketStore
import com.caifenxi.app.service.WebViewExecutor
import com.caifenxi.app.ui.ExecutorViewModel
import com.caifenxi.app.ui.MainViewModel

/**
 * 按钮标注 JavascriptInterface：用户在 WebView 点击元素 → JS 生成 selector → 回传 Android。
 */
class MappingBridge {
    @Volatile
    var pickedCallback: ((String, String) -> Unit)? = null

    @JavascriptInterface
    fun onPicked(selector: String, text: String) {
        pickedCallback?.invoke(selector, text)
    }
}

/** 持久化 WebView 状态，防止页面切换时白屏 */
private object WebViewStateHolder {
    var savedState: Bundle? = null
}

/**
 * 标注模式注入的 JS：监听 click + touchend，生成 CSS selector，通过 bridge 回传。
 * 支持同源 iframe 内元素标注；页面导航后由 onPageFinished 重新注入。
 */
private const val MAPPING_JS = """
(function(){
  // 允许重复注入：页面 SPA 导航后重新绑定
  window.__CFX_MAPPING_ACTIVE = window.__CFX_MAPPING_ACTIVE || false;
  window.__cfxMappingLastEvent = 0;

  function __cfxCssEscape(s){
    if(window.CSS && CSS.escape) return CSS.escape(s);
    return String(s).replace(/([ !"#$%&'()*+,./:;<=>?@\[\\\]^`{|}~])/g, '\\$1');
  }

  function __cfxGetClasses(el){
    try{
      if(el.classList && el.classList.length){
        return Array.prototype.slice.call(el.classList).filter(function(c){
          return c && c.indexOf('cfx-')!==0 && !/^ng-|^css-|^sc-|^emotion-|^jsx-/.test(c);
        });
      }
      var cn = el.className;
      if(typeof cn === 'string') return cn.trim().split(/\s+/).filter(Boolean);
      if(cn && typeof cn.baseVal === 'string') return cn.baseVal.trim().split(/\s+/).filter(Boolean);
    }catch(e){}
    return [];
  }

  function __cfxUniqueSelector(el){
    if(!el || el.nodeType !== 1) return '';
    if(el.id && typeof el.id === 'string' && el.id.indexOf('cfx-')!==0){
      var idSel = '#' + __cfxCssEscape(el.id);
      try{ if(document.querySelectorAll(idSel).length === 1) return idSel; }catch(e){}
    }
    var attrs = ['data-testid','data-id','data-play','data-type','data-value','data-name','data-code','name','aria-label','role'];
    for(var ai=0; ai<attrs.length; ai++){
      var av = el.getAttribute(attrs[ai]);
      if(av && av.length < 64){
        var aSel = el.tagName.toLowerCase() + '[' + attrs[ai] + '="' + av.replace(/"/g,'\\"') + '"]';
        try{ if(document.querySelectorAll(aSel).length === 1) return aSel; }catch(e){}
      }
    }
    var tag = el.tagName.toLowerCase();
    var classes = __cfxGetClasses(el).slice(0, 4);
    var sel = tag;
    for(var ci=0; ci<classes.length; ci++){
      sel += '.' + __cfxCssEscape(classes[ci]);
      try{ if(document.querySelectorAll(sel).length === 1) return sel; }catch(e){}
    }
    var path = [];
    var cur = el;
    var depth = 0;
    while(cur && cur !== document.body && cur !== document.documentElement && depth < 10){
      var p = cur.parentElement;
      if(!p) break;
      var sameTag = 0, idx = 0;
      for(var i=0;i<p.children.length;i++){
        if(p.children[i].tagName === cur.tagName){
          sameTag++;
          if(p.children[i] === cur) idx = sameTag;
        }
      }
      var part = cur.tagName.toLowerCase();
      var pcs = __cfxGetClasses(cur).slice(0, 1);
      if(pcs.length) part += '.' + __cfxCssEscape(pcs[0]);
      if(sameTag > 1) part += ':nth-of-type(' + idx + ')';
      path.unshift(part);
      var trial = path.join(' > ');
      try{ if(document.querySelectorAll(trial).length === 1) return trial; }catch(e){}
      cur = p;
      depth++;
    }
    return path.join(' > ');
  }

  function __cfxReport(el){
    var sel = __cfxUniqueSelector(el);
    if(!sel) return;
    // v2.5.3: 验证生成的 selector 是否唯一且能正确找到目标元素
    try{
      var matched = document.querySelectorAll(sel);
      if(matched.length !== 1 || matched[0] !== el){
        // 不唯一或匹配到错误元素 → 追加 nth-child 精确化
        var parent = el.parentElement;
        if(parent){
          var siblings = Array.prototype.slice.call(parent.children);
          var idx = siblings.indexOf(el) + 1;
          sel = sel + ':nth-child(' + idx + ')';
          // 再次验证
          var matched2 = document.querySelectorAll(sel);
          if(matched2.length !== 1 || matched2[0] !== el){
            console.warn('[CFX] selector not unique after nth-child fix:', sel, 'matched', matched2.length);
          }
        }
      }
    }catch(e){ console.warn('[CFX] selector validation error:', e); }
    try{
      el.style.outline = '4px solid #00c853';
      el.style.outlineOffset = '2px';
      setTimeout(function(){ try{ el.style.outline=''; el.style.outlineOffset=''; }catch(_){} }, 1800);
    }catch(_){}
    var txt = (el.innerText || el.value || el.getAttribute('aria-label') || el.getAttribute('placeholder') || '').replace(/\s+/g,' ').substring(0, 50);
    try{
      if(window.CfxMappingBridge && typeof window.CfxMappingBridge.onPicked === 'function'){
        window.CfxMappingBridge.onPicked(sel, txt);
        return;
      }
    }catch(e){}
    try{
      if(window.top && window.top !== window){
        window.top.postMessage({__cfxMapping:true, selector:sel, text:txt}, '*');
      }
    }catch(e){}
  }

  window.__cfxMappingHandler = function(e){
    if(!window.__CFX_MAPPING_ACTIVE) return;
    var now = Date.now();
    // v2.5.3: 去抖间隔从 280ms 提升到 600ms，防止快速连击/触屏抖动产生重复选择
    if(now - window.__cfxMappingLastEvent < 600) return;
    window.__cfxMappingLastEvent = now;
    var el = e.target;
    var hops = 0;
    while(el && hops < 5){
      if(el === document || el === document.body || el === document.documentElement) break;
      if(el.id && String(el.id).indexOf('cfx-')===0) return;
      var tag = (el.tagName||'').toLowerCase();
      var role = el.getAttribute && el.getAttribute('role');
      var clickable = tag==='button'||tag==='a'||tag==='input'||tag==='label'||tag==='li'||
        role==='button'|| (el.onclick) || (el.getAttribute && (el.getAttribute('ng-click')||el.getAttribute('@click')));
      if(clickable || hops===0){
        try{ e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); }catch(_){}
        __cfxReport(el);
        return false;
      }
      el = el.parentElement;
      hops++;
    }
    if(e.target && e.target !== document.body){
      try{ e.preventDefault(); e.stopPropagation(); }catch(_){}
      __cfxReport(e.target);
    }
    return false;
  };

  try{
    document.removeEventListener('click', window.__cfxMappingHandler, true);
    document.removeEventListener('touchend', window.__cfxMappingHandler, true);
    document.removeEventListener('pointerup', window.__cfxMappingHandler, true);
  }catch(e){}
  document.addEventListener('click', window.__cfxMappingHandler, true);
  document.addEventListener('touchend', window.__cfxMappingHandler, true);
  document.addEventListener('pointerup', window.__cfxMappingHandler, true);

  if(!window.__cfxMappingMsgBound){
    window.__cfxMappingMsgBound = true;
    window.addEventListener('message', function(ev){
      try{
        var d = ev.data;
        if(d && d.__cfxMapping && d.selector && window.CfxMappingBridge){
          window.CfxMappingBridge.onPicked(d.selector, d.text||'');
        }
      }catch(e){}
    });
  }

  window.__cfxInjectIframes = function(){
    try{
      var frames = document.querySelectorAll('iframe');
      for(var i=0;i<frames.length;i++){
        try{
          var fd = frames[i].contentDocument || (frames[i].contentWindow && frames[i].contentWindow.document);
          if(!fd) continue;
          // v2.5.3: iframe 使用与主页面完全一致的 __cfxMappingHandler（函数引用共享），
          // 确保事件去抖、selector 生成、验证逻辑完全一致
          var win = frames[i].contentWindow;
          if(win && !win.__cfxMappingInjected){
            win.__cfxMappingInjected = true;
            win.__CFX_MAPPING_ACTIVE = window.__CFX_MAPPING_ACTIVE;
            win.__cfxMappingLastEvent = 0;
            win.__cfxMappingHandler = window.__cfxMappingHandler;
            win.__cfxUniqueSelector = window.__cfxUniqueSelector;
            win.__cfxReport = window.__cfxReport;
            win.__cfxCssEscape = window.__cfxCssEscape;
            win.__cfxGetClasses = window.__cfxGetClasses;
            fd.removeEventListener('click', win.__cfxMappingHandler, true);
            fd.removeEventListener('touchend', win.__cfxMappingHandler, true);
            fd.addEventListener('click', win.__cfxMappingHandler, true);
            fd.addEventListener('touchend', win.__cfxMappingHandler, true);
          }
        }catch(e){}
      }
    }catch(e){}
  };
  // v2.5.3: 监听 iframe 动态插入（SPA 懒加载 iframe），自动注入标注能力
  if(!window.__cfxIframeObserver){
    window.__cfxIframeObserver = new MutationObserver(function(mutations){
      var hasNewIframe = false;
      for(var mi=0; mi<mutations.length; mi++){
        var nodes = mutations[mi].addedNodes;
        for(var ni=0; nodes && ni<nodes.length; ni++){
          if(nodes[ni].tagName === 'IFRAME'){ hasNewIframe = true; break; }
          if(nodes[ni].querySelectorAll && nodes[ni].querySelectorAll('iframe').length > 0){ hasNewIframe = true; break; }
        }
        if(hasNewIframe) break;
      }
      if(hasNewIframe){
        setTimeout(window.__cfxInjectIframes, 300);
      }
    });
    window.__cfxIframeObserver.observe(document.body || document.documentElement, {childList:true, subtree:true});
  }
  window.__cfxInjectIframes();
  setTimeout(window.__cfxInjectIframes, 1500);
  setTimeout(window.__cfxInjectIframes, 3500);
})();
"""

/**
 * 一级导航全屏网页执行台：
 * - 主区域 WebView
 * - 顶部可折叠状态条：期号/口径/方向金额/执行器/选择器
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebBetScreen(
    mainViewModel: MainViewModel = viewModel(),
    executorViewModel: ExecutorViewModel = viewModel(),
    onBack: () -> Unit = {},
    onWorkbench: () -> Unit = {},
    onBet: () -> Unit = {}
) {
    val context = LocalContext.current
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    val executorStatus by executorViewModel.executorStatus.collectAsState()
    val currentTask by executorViewModel.currentTask.collectAsState()
    val executorLogs by executorViewModel.executorLogs.collectAsState()
    val lastFailedTask by executorViewModel.lastFailedTask.collectAsState()
    val ticket by ExecutionTicketStore.ticket.collectAsState()
    val pendingQueueSize by com.caifenxi.app.domain.execution.PendingBetQueue.pendingSize.collectAsState()
    val pendingQueueMsg by com.caifenxi.app.domain.execution.PendingBetQueue.lastMessage.collectAsState()
    val autoRunning by executorViewModel.autoRunning.collectAsState()
    val executionMode by executorViewModel.executionMode.collectAsState()

    var urlInput by rememberSaveable { mutableStateOf("https://www.baidu.com") }
    var pageTitle by rememberSaveable { mutableStateOf("未加载") }
    var pageStatus by rememberSaveable { mutableStateOf("待命") }
    var panelExpanded by rememberSaveable { mutableStateOf(true) }
    var dryRun by rememberSaveable { mutableStateOf(true) }
    var testDx by rememberSaveable { mutableStateOf("") }
    var testDs by rememberSaveable { mutableStateOf("") }
    var testAmount by rememberSaveable { mutableStateOf("") }
    var pageLoading by remember { mutableStateOf(false) }
    var pageProgress by remember { mutableStateOf(0) }
    var selectorInfo by remember {
        mutableStateOf(LocalSelectorLoader.current(context))
    }

    // URL 历史/书签
    var urlHistory by remember { mutableStateOf(UrlHistoryStore.getHistory(context)) }
    var showHistory by remember { mutableStateOf(false) }
    val currentEntry = urlHistory.find { it.url == urlInput }
    val isBookmarked = currentEntry?.bookmarked == true

    val lotteryName = mainViewModel.currentLottery.value.name
    val targetIssue = mainViewModel.nextIssueText.value
    val webReady = WebViewExecutor.isAvailable
    val mode = ExecutorManager.getMode()
    var clickProfile by remember { mutableStateOf(ClickMatchConfig.load(context)) }

    // 标注模式状态
    var mappingMode by rememberSaveable { mutableStateOf(false) }
    var mappingStep by rememberSaveable { mutableStateOf(0) }
    var mappingPaused by rememberSaveable { mutableStateOf(false) }
    var mappingFeedback by remember { mutableStateOf("") }
    val mappingSteps = listOf("大按钮", "小按钮", "单按钮", "双按钮", "金额输入框", "确认按钮", "余额元素")
    val mappingBridge = remember { MappingBridge() }
    val mappingHandler = remember { Handler(Looper.getMainLooper()) }

    // 标注模式：mappingMode 或 WebView 就绪时重新注册 bridge + 注入 JS（SPA 导航后也需重注）
    LaunchedEffect(mappingMode, webViewRef) {
        if (mappingMode) {
            webViewRef?.let { wv ->
                try { wv.removeJavascriptInterface("CfxMappingBridge") } catch (_: Exception) {}
                wv.addJavascriptInterface(mappingBridge, "CfxMappingBridge")
                wv.evaluateJavascript(MAPPING_JS, null)
                wv.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = ${if (mappingPaused) "false" else "true"};", null)
                wv.evaluateJavascript("if(window.__cfxInjectIframes) window.__cfxInjectIframes();", null)
            }
        } else {
            webViewRef?.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = false;", null)
            try { webViewRef?.removeJavascriptInterface("CfxMappingBridge") } catch (_: Exception) {}
        }
    }

    // 暂停/继续标注：切换 mapping flag 但不注销 bridge
    LaunchedEffect(mappingPaused) {
        if (mappingMode) {
            webViewRef?.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = ${if (mappingPaused) "false" else "true"};", null)
        }
    }

    // 保存 selector 到 ClickMatchConfig，推进到下一步
    // 必须在 pickedCallback 之前声明，否则 lambda 内前向引用未初始化的 val 会编译失败
    val saveMappingStep: (Int, String, String) -> Unit = { step, selector, text ->
        val newProfile = when (step) {
            0 -> clickProfile.copy(selectorBig = selector)
            1 -> clickProfile.copy(selectorSmall = selector)
            2 -> clickProfile.copy(selectorOdd = selector)
            3 -> clickProfile.copy(selectorEven = selector)
            4 -> clickProfile.copy(selectorAmount = selector)
            5 -> clickProfile.copy(selectorConfirm = selector)
            6 -> clickProfile.copy(selectorBalance = selector)
            else -> clickProfile
        }
        ClickMatchConfig.save(context, newProfile)
        ClickMatchConfig.clearCache()
        clickProfile = newProfile
        mappingFeedback = "已保存: ${mappingSteps[step]} → $selector (${text.take(15)})"
        mappingStep = step + 1
        if (mappingStep >= mappingSteps.size) {
            mappingMode = false
            webViewRef?.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = false;", null)
            webViewRef?.removeJavascriptInterface("CfxMappingBridge")
        }
    }

    // bridge 回调：保存 selector 到 ClickMatchConfig，推进到下一步
    // v2.5.3: 保存前通过 WebView JS 验证 selector 唯一性，不唯一则提示重新标注
    mappingBridge.pickedCallback = { selector, text ->
        mappingHandler.post {
            if (mappingPaused) return@post
            val step = mappingStep
            if (step >= mappingSteps.size) return@post
            
            // 验证 selector 唯一性
            var verifiedSelector = selector
            val wv = webViewRef
            if (wv != null) {
                val verifyJs = """
                    (function(){
                        try{
                            var matched = document.querySelectorAll('$selector');
                            if(matched.length === 1) return {ok:true, count:1};
                            return {ok:false, count:matched.length};
                        }catch(e){ return {ok:false, error:e.message}; }
                    })()
                """.trimIndent()
                wv.evaluateJavascript(verifyJs) { result ->
                    val count = result?.let { 
                        val m = it.replace("\"", "").replace("'", "")
                        val c = Regex("count:(\\d+)").find(m)?.groupValues?.get(1)?.toIntOrNull() ?: 0
                        c
                    } ?: 0
                    if (count != 1) {
                        mappingFeedback = "⚠ selector 不唯一（匹配 $count 个元素），请重新点击"
                        RuntimeLog.warn("Mapping", "selector 不唯一: $selector 匹配 $count 个")
                        return@evaluateJavascript
                    }
                    // 唯一 → 保存
                    saveMappingStep(step, verifiedSelector, text)
                }
            } else {
                saveMappingStep(step, verifiedSelector, text)
            }
        }
    }

    BackHandler {
        val wv = webViewRef
        if (wv?.canGoBack() == true) wv.goBack() else onBack()
    }

    // 离开页面时保存 WebView 状态，防止返回时白屏
    DisposableEffect(Unit) {
        onDispose {
            try {
                webViewRef?.saveState(Bundle().also { WebViewStateHolder.savedState = it })
            } catch (_: Exception) {}
        }
    }

    // —— 持久连接：周期 keep-alive 探活（15s 一次）+ 渲染层失效自愈（黑屏自动恢复） ——
    LaunchedEffect(Unit) {
        while (true) {
            delay(15_000)
            try {
                val wv = webViewRef
                if (wv != null) {
                    WebViewExecutor.keepAlive(wv)
                    if (!WebViewExecutor.isAvailable) {
                        WebViewExecutor.reattach(wv)
                    } else {
                        // P0 渲染自愈：心跳活着但渲染层停滞（黑屏）时自动恢复，不再依赖手动切页
                        WebViewExecutor.probeRender(wv)
                        delay(2_000) // 等待探针的绘制回报窗口
                        if (WebViewExecutor.isRenderStalled()) {
                            WebViewExecutor.selfHeal(wv)
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    val panelScrollState = rememberScrollState()
    val screenWidth = LocalConfiguration.current.screenWidthDp.dp
    // 浮动面板拖拽位置
    var panelOffsetX by remember { mutableStateOf(0f) }
    var panelOffsetY by remember { mutableStateOf(0f) }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface)) {
        // —— 全屏 WebView（底层）——
        AndroidView(
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.databaseEnabled = true
                    settings.useWideViewPort = true
                    settings.loadWithOverviewMode = true
                    settings.cacheMode = WebSettings.LOAD_CACHE_ELSE_NETWORK
                    settings.userAgentString =
                        "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                    // —— 补齐“真正网站”渲染所需设置 ——
                    settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW // http/https 混合资源
                    settings.javaScriptCanOpenWindowsAutomatically = true               // 允许 JS 开新窗口
                    settings.mediaPlaybackRequiresUserGesture = false                   // 页面自动播放不拦截
                    settings.loadsImagesAutomatically = true
                    settings.blockNetworkImage = false
                    settings.textZoom = 100
                    settings.setSupportZoom(true)                                      // 支持双指缩放
                    settings.builtInZoomControls = true
                    settings.displayZoomControls = false
                    settings.domStorageEnabled = true
                    settings.databaseEnabled = true
                    settings.allowFileAccess = true
                    settings.setGeolocationEnabled(false)
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                            // 所有导航留在 WebView 内（真正网站体验），不跳系统浏览器
                            return false
                        }
                        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                            pageStatus = "加载中..."
                            pageLoading = true
                        }
                        override fun onPageFinished(view: WebView?, url: String?) {
                            pageStatus = "已加载"
                            pageLoading = false
                            pageProgress = 100
                            pageTitle = view?.title ?: url ?: ""
                            if (url != null) {
                                urlInput = url
                                UrlHistoryStore.recordVisit(ctx, url, pageTitle)
                                urlHistory = UrlHistoryStore.getHistory(ctx)
                            }
                            WebViewExecutor.reattach(this@apply)
                            WebViewExecutor.heartbeat()
                            if (mappingMode) {
                                view?.addJavascriptInterface(mappingBridge, "CfxMappingBridge")
                                view?.evaluateJavascript(MAPPING_JS, null)
                                view?.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = ${if (mappingPaused) "false" else "true"};", null)
                                view?.evaluateJavascript("if(window.__cfxInjectIframes) window.__cfxInjectIframes();", null)
                            }
                        }
                        override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                            // 只把主框架错误算作加载失败；子资源错误不打扰用户
                            if (request?.isForMainFrame == true) {
                                pageLoading = false
                                pageStatus = "加载失败(${error?.errorCode})，请检查站点地址或网络后刷新"
                            }
                        }
                        override fun onRenderProcessGone(view: WebView?, detail: android.webkit.RenderProcessGoneDetail?): Boolean {
                            // 渲染进程被杀（内存不足等）→ 提示并自动重载，避免白屏/黑屏
                            RuntimeLog.warn("WebView", "渲染进程异常终止：${detail?.didCrash()}")
                            pageStatus = "页面渲染异常，自动恢复中..."
                            mappingHandler.postDelayed({
                                try {
                                    // 重建绑定 + 重载当前页：光 reload 有时不恢复显示，须重挂执行器
                                    view?.let { wv ->
                                        WebViewExecutor.reattach(wv)
                                        wv.reload()
                                        WebViewExecutor.heartbeat()
                                    }
                                } catch (_: Exception) {
                                }
                            }, 600)
                            return true
                        }
                        override fun onReceivedHttpError(view: WebView?, request: WebResourceRequest?, errorResponse: android.webkit.WebResourceResponse?) {
                            if (request?.isForMainFrame == true) {
                                pageStatus = "页面响应异常(${errorResponse?.statusCode})，请刷新"
                            }
                        }
                    }
                    webChromeClient = object : WebChromeClient() {
                        override fun onReceivedTitle(view: WebView?, title: String?) {
                            if (!title.isNullOrBlank()) pageTitle = title
                        }
                        override fun onProgressChanged(view: WebView?, newProgress: Int) {
                            pageProgress = newProgress
                            // 加载期间持续保活
                            if (newProgress in 1..99) {
                                WebViewExecutor.heartbeat()
                            }
                        }
                        // —— 接管 JS 弹窗：自动确认 + 提示，防止系统对话框阻塞渲染导致黑屏 ——
                        private fun reviveAfterPopup(view: WebView?) {
                            // 弹窗应答后，JS 线程可能挂起未恢复渲染提交；
                            // 用一次无意义 JS 执行"唤醒"Chromium 主线程，触发渲染管线继续提交帧
                            try { view?.evaluateJavascript("(function(){ return document.visibilityState; })()", null) } catch (_: Exception) {}
                            // 延迟复检：若页面 still 挂死（visibilityState 异常或渲染未恢复），自动 reload
                            mappingHandler.postDelayed({
                                try {
                                    view?.evaluateJavascript(
                                        "(function(){ try{ return document.visibilityState + '|' + (document.body?.scrollHeight||0); }catch(e){ return 'dead'; } })()"
                                    ) { result ->
                                        val dead = result == null || result == "null" || (result?.contains("dead") ?: false)
                                        if (dead) {
                                            RuntimeLog.warn("WebView", "弹窗后复检页面挂死，触发自动恢复")
                                            view?.let { wv ->
                                                WebViewExecutor.reattach(wv)
                                                wv.reload()
                                                WebViewExecutor.heartbeat()
                                            }
                                        }
                                    }
                                } catch (_: Exception) {}
                            }, 1_200)
                        }

                        override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                            try {
                                mappingHandler.post {
                                    try {
                                        android.widget.Toast.makeText(ctx, message ?: "网页提示", android.widget.Toast.LENGTH_SHORT).show()
                                    } catch (_: Exception) {}
                                }
                                result?.confirm()
                                reviveAfterPopup(view)
                            } catch (e: Exception) {
                                RuntimeLog.warn("WebView", "onJsAlert 异常: ${e.message}")
                                result?.confirm()
                                reviveAfterPopup(view)
                            }
                            return true
                        }
                        override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                            try {
                                mappingHandler.post {
                                    try {
                                        android.widget.Toast.makeText(ctx, "网页确认: ${message ?: ""}", android.widget.Toast.LENGTH_SHORT).show()
                                    } catch (_: Exception) {}
                                }
                                result?.confirm() // 自动化流程自动点确定，避免卡死
                                reviveAfterPopup(view)
                            } catch (e: Exception) {
                                RuntimeLog.warn("WebView", "onJsConfirm 异常: ${e.message}")
                                result?.confirm()
                                reviveAfterPopup(view)
                            }
                            return true
                        }
                        override fun onJsPrompt(view: WebView?, url: String?, message: String?, defaultValue: String?, result: android.webkit.JsPromptResult?): Boolean {
                            try {
                                result?.cancel()
                                reviveAfterPopup(view)
                            } catch (e: Exception) {
                                RuntimeLog.warn("WebView", "onJsPrompt 异常: ${e.message}")
                                result?.cancel()
                                reviveAfterPopup(view)
                            }
                            return true
                        }
                        override fun onJsBeforeUnload(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                            // 下注成功站点常触发 beforeunload（离开确认），自动确认放行，避免页面挂起黑屏
                            try {
                                result?.confirm()
                                reviveAfterPopup(view)
                            } catch (e: Exception) {
                                RuntimeLog.warn("WebView", "onJsBeforeUnload 异常: ${e.message}")
                                result?.confirm()
                                reviveAfterPopup(view)
                            }
                            return true
                        }
                        override fun onCreateWindow(
                            view: WebView?,
                            isDialog: Boolean,
                            isUserGesture: Boolean,
                            resultMsg: Message?
                        ): Boolean {
                            // target=_blank 新窗口：直接在当前 WebView 打开，保持页面完整
                            val newWebView = WebView(view?.context ?: ctx)
                            newWebView.settings.javaScriptEnabled = true
                            // 新窗口同样接管 JS 弹窗，避免站点在新窗内弹 alert/confirm 时卡死黑屏
                            newWebView.webChromeClient = object : WebChromeClient() {
                                override fun onJsAlert(v: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                                    try { result?.confirm() } catch (_: Exception) { result?.confirm() }
                                    return true
                                }
                                override fun onJsConfirm(v: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                                    try { result?.confirm() } catch (_: Exception) { result?.confirm() }
                                    return true
                                }
                                override fun onJsPrompt(v: WebView?, url: String?, message: String?, defaultValue: String?, result: android.webkit.JsPromptResult?): Boolean {
                                    try { result?.cancel() } catch (_: Exception) { result?.cancel() }
                                    return true
                                }
                                override fun onJsBeforeUnload(v: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                                    try { result?.confirm() } catch (_: Exception) { result?.confirm() }
                                    return true
                                }
                            }
                            newWebView.webViewClient = object : WebViewClient() {
                                override fun shouldOverrideUrlLoading(v: WebView?, request: WebResourceRequest?): Boolean {
                                    view?.loadUrl(request?.url?.toString() ?: "")
                                    v?.destroy()
                                    return true
                                }
                            }
                            resultMsg?.obj = newWebView
                            resultMsg?.sendToTarget()
                            return true
                        }
                    }
                    WebViewExecutor.reattach(this)
                    WebViewExecutor.watchRendering(this)
                    webViewRef = this
                    val saved = WebViewStateHolder.savedState
                    if (saved != null && !saved.isEmpty()) {
                        restoreState(saved)
                        WebViewStateHolder.savedState = null
                    } else {
                        val currentUrl = urlInput.ifBlank { "https://www.baidu.com" }
                        loadUrl(currentUrl)
                    }
                }
            },
            modifier = Modifier.fillMaxSize(),
            update = { wv ->
                webViewRef = wv
                if (!WebViewExecutor.isAvailable) {
                    WebViewExecutor.reattach(wv)
                }
                WebViewExecutor.watchRendering(wv)
            }
        )

        // 加载进度条
        if (pageLoading) {
            LinearProgressIndicator(
                progress = { pageProgress / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
            )
        }

        // —— 浮动控制面板（叠加在 WebView 上层）——
        Surface(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(horizontal = 4.dp, vertical = 2.dp)
                .offset { IntOffset(0, panelOffsetY.roundToInt()) }
                .pointerInput(Unit) {
                    detectDragGestures { _, drag ->
                        panelOffsetY = (panelOffsetY + drag.y).coerceAtLeast(0f)
                    }
                }
                .widthIn(max = screenWidth - 8.dp),
            shape = RoundedCornerShape(12.dp),
            tonalElevation = 4.dp,
            shadowElevation = 8.dp
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .verticalScroll(panelScrollState)
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Icon(Icons.Filled.DragHandle, contentDescription = "拖拽",
                        modifier = Modifier.size(18.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "返回")
                    }
                    Column(Modifier.weight(1f)) {
                        Text("网页执行台", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        if (!panelExpanded) {
                            Text(
                                buildString {
                                    append(lotteryName)
                                    append(" · ")
                                    append(if (webReady) "已连接" else "未连接")
                                    append(" · 跟随挂机")
                                    if (pendingQueueSize > 0) append(" · 排队$pendingQueueSize")
                                    val tk = ticket
                                    if (tk.cmdId.isNotBlank()) {
                                        append(" · ")
                                        append(tk.status)
                                        if (!tk.dx.isNullOrBlank() || !tk.ds.isNullOrBlank()) {
                                            append(" ")
                                            append(listOfNotNull(tk.dx, tk.ds).joinToString("/"))
                                        }
                                        if (!tk.amountText.isNullOrBlank()) append(" ¥${tk.amountText}")
                                    }
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1
                            )
                        }
                    }
                    if (panelExpanded) {
                        TextButton(onClick = onWorkbench) { Text("工作台", fontSize = 12.sp) }
                        TextButton(onClick = onBet) { Text("挂机", fontSize = 12.sp) }
                    }
                    IconButton(onClick = { panelExpanded = !panelExpanded }) {
                        Icon(
                            if (panelExpanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                            contentDescription = "展开状态"
                        )
                    }
                }

                if (panelExpanded) {
                // 一行关键状态
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatusChip(
                        "按钮映射",
                        if (clickProfile.hasMapping()) "已配置" else "未配置",
                        if (clickProfile.hasMapping()) Color(0xFF2E7D32) else Color(0xFFC62828)
                    )
                    StatusChip(
                        "WebView",
                        if (webReady) "已连接" else "未连接",
                        if (webReady) Color(0xFF2E7D32) else Color(0xFFC62828)
                    )
                    StatusChip(
                        "执行",
                        when (executorStatus) {
                            ExecutorViewModel.ExecutorStatus.IDLE -> "待机"
                            ExecutorViewModel.ExecutorStatus.RUNNING -> "执行中"
                            ExecutorViewModel.ExecutorStatus.COMPLETED -> "完成"
                            else -> executorStatus.name
                        },
                        MaterialTheme.colorScheme.primary
                    )
                    StatusChip(
                        "模式",
                        if (dryRun) "仅识别" else "实盘",
                        if (dryRun) Color(0xFFF9A825) else Color(0xFFC62828)
                    )
                }

                    Spacer(Modifier.height(8.dp))
                    // 选择器
                    val selText = when (val s = selectorInfo) {
                        is LocalSelectorLoader.State.Ok ->
                            "选择器: ${if (s.source == LocalSelectorLoader.Source.EXTERNAL) "外部" else "内置"} v${s.version}"
                        is LocalSelectorLoader.State.ExternalBroken ->
                            "选择器损坏: ${s.message.take(40)}"
                    }
                    Text(selText, style = MaterialTheme.typography.bodySmall,
                        color = if (selectorInfo is LocalSelectorLoader.State.ExternalBroken)
                            MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.onSurfaceVariant)

                    // 工单条：跟随挂机 · 计划 / 口径 / 方向 / 金额 / 回执
                    val tk = ticket
                    LaunchedEffect(tk.cmdId) {
                        if (tk.cmdId.isNotBlank()) {
                            tk.dx?.takeIf { it in setOf("大", "小") }?.let { testDx = it }
                            tk.ds?.takeIf { it in setOf("单", "双") }?.let { testDs = it }
                            tk.amountText?.takeIf { it.isNotBlank() }?.let { testAmount = it }
                        }
                    }
                    Text(
                        "跟随挂机（方向与金额仅来自挂机页派发，本页不重算计划）",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    if (tk.cmdId.isNotBlank()) {
                        Text(
                            "工单 ${ExecutionTicketStore.stageLabel(tk.stage, tk.leg)} · ${tk.planLabel.ifBlank { "挂机" }}",
                            fontWeight = FontWeight.SemiBold,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            "期号 ${tk.issue} · 方向 ${tk.dx ?: "-"}/${tk.ds ?: "-"} · 金额 ${tk.amountText ?: "-"}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            "状态 ${tk.status} · ${tk.message}",
                            style = MaterialTheme.typography.bodySmall,
                            color = when (tk.status) {
                                "SUCCESS" -> Color(0xFF2E7D32)
                                "FAILED", "EXPIRED" -> Color(0xFFC62828)
                                "PENDING", "QUEUED", "RUNNING" -> Color(0xFFEF6C00)
                                else -> MaterialTheme.colorScheme.onSurfaceVariant
                            }
                        )
                        if (tk.balanceBefore.isNotBlank() || tk.balanceAfter.isNotBlank()) {
                            Text(
                                "余额 ${tk.balanceBefore.ifBlank { "-" }} → ${tk.balanceAfter.ifBlank { "-" }}",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    } else {
                        Text(
                            "工单: 等待挂机派发（挂机页选计划并开启 → 每期自动带方向+金额到本页执行）",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (pendingQueueSize > 0) {
                        Text(
                            "排队补点 $pendingQueueSize 条 · ${pendingQueueMsg.ifBlank { "连接后自动执行" }}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFEF6C00)
                        )
                    }

                    // URL + 书签 + 历史
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = urlInput,
                            onValueChange = { urlInput = it },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            label = { Text("投注站地址") },
                            textStyle = LocalTextStyle.current.copy(fontSize = 13.sp)
                        )
                        IconButton(onClick = {
                            val newState = UrlHistoryStore.toggleBookmark(context, urlInput)
                            urlHistory = UrlHistoryStore.getHistory(context)
                            val msg = if (newState) "已收藏" else "已取消收藏"
                            android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_SHORT).show()
                        }) {
                            Icon(
                                if (isBookmarked) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                                contentDescription = "书签",
                                tint = if (isBookmarked) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = { showHistory = !showHistory }) {
                            Icon(Icons.Filled.History, contentDescription = "历史",
                                tint = if (showHistory) MaterialTheme.colorScheme.primary
                                       else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { webViewRef?.loadUrl(urlInput) }) {
                            Icon(Icons.Filled.Refresh, contentDescription = "加载")
                        }
                    }

                    // URL 历史下拉
                    if (showHistory) {
                        val items = urlHistory
                        if (items.isEmpty()) {
                            Text("暂无历史记录", fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(vertical = 4.dp))
                        } else {
                            Column(
                                Modifier
                                    .fillMaxWidth()
                                    .height(120.dp)
                                    .verticalScroll(rememberScrollState())
                            ) {
                                items.forEach { entry ->
                                    Row(
                                        Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 2.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        TextButton(
                                            onClick = {
                                                urlInput = entry.url
                                                webViewRef?.loadUrl(entry.url)
                                                showHistory = false
                                            },
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text(
                                                "${if (entry.bookmarked) "★ " else ""}${entry.url}",
                                                fontSize = 11.sp,
                                                maxLines = 1
                                            )
                                        }
                                        Text(
                                            entry.title.ifBlank { "" }.take(20),
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                TextButton(onClick = {
                                    UrlHistoryStore.clearHistory(context)
                                    urlHistory = UrlHistoryStore.getHistory(context)
                                }) { Text("清空历史", fontSize = 11.sp, color = Color(0xFFC62828)) }
                            }
                        }
                    }

                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = dryRun,
                            onClick = { dryRun = true },
                            label = { Text("仅识别") }
                        )
                        FilterChip(
                            selected = !dryRun,
                            onClick = { dryRun = false },
                            label = { Text("实盘点击") }
                        )
                        TextButton(onClick = {
                            selectorInfo = LocalSelectorLoader.reload(context)
                        }) { Text("重载选择器") }
                        TextButton(onClick = {
                            LocalSelectorLoader.exportTemplate(context)
                            selectorInfo = LocalSelectorLoader.reload(context)
                        }) { Text("导出模板") }
                    }

                    // 按钮标注模式
                    Surface(
                        shape = MaterialTheme.shapes.small,
                        color = if (mappingMode) Color(0xFFE8F5E9) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                    ) {
                        Column(Modifier.fillMaxWidth().padding(8.dp)) {
                            Row(
                                Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "按钮标注",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp,
                                    modifier = Modifier.weight(1f)
                                )
                                if (mappingMode) {
                                    Text(
                                        "第 ${mappingStep + 1}/${mappingSteps.size} 步${if (mappingPaused) " (暂停)" else ""}",
                                        fontSize = 11.sp,
                                        color = if (mappingPaused) Color(0xFFF9A825) else Color(0xFF2E7D32)
                                    )
                                } else {
                                    Button(
                                        onClick = {
                                            mappingStep = 0
                                            mappingFeedback = ""
                                            mappingMode = true
                                        },
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                                    ) { Text("开始标注", fontSize = 12.sp) }
                                }
                            }

                            if (mappingMode) {
                                Text(
                                    if (mappingPaused) "标注已暂停 · 可在网页上自由操作" else "请在页面上点击：${mappingSteps[mappingStep]}",
                                    fontSize = 12.sp,
                                    color = if (mappingPaused) Color(0xFFF9A825) else Color(0xFF2E7D32),
                                    fontWeight = FontWeight.Medium
                                )
                                Row(
                                    Modifier.fillMaxWidth().padding(top = 4.dp),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    TextButton(
                                        onClick = { mappingPaused = !mappingPaused },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                                    ) {
                                        Text(
                                            if (mappingPaused) "继续标注" else "暂停(操作网页)",
                                            fontSize = 11.sp,
                                            color = if (mappingPaused) Color(0xFF2E7D32) else Color(0xFFF9A825)
                                        )
                                    }
                                    if (mappingStep > 0) {
                                        TextButton(
                                            onClick = {
                                                mappingStep = mappingStep - 1
                                                mappingFeedback = "返回上一步：${mappingSteps[mappingStep]}"
                                            },
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                                        ) { Text("上一步", fontSize = 11.sp) }
                                    }
                                    TextButton(
                                        onClick = {
                                            mappingFeedback = "已跳过：${mappingSteps[mappingStep]}"
                                            mappingStep = mappingStep + 1
                                            if (mappingStep >= mappingSteps.size) {
                                                mappingMode = false
                                                webViewRef?.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = false;", null)
                                                webViewRef?.removeJavascriptInterface("CfxMappingBridge")
                                            }
                                        },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                                    ) { Text("跳过", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                                    TextButton(
                                        onClick = {
                                            mappingMode = false
                                            mappingPaused = false
                                            webViewRef?.evaluateJavascript("window.__CFX_MAPPING_ACTIVE = false;", null)
                                            webViewRef?.removeJavascriptInterface("CfxMappingBridge")
                                        },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                                    ) { Text("退出", color = Color(0xFFC62828), fontSize = 11.sp) }
                                }
                            }

                            if (mappingFeedback.isNotBlank()) {
                                Text(
                                    mappingFeedback,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            // 显示已标注的 selector 摘要
                            if (clickProfile.hasMapping()) {
                                val mapped = buildList {
                                    if (clickProfile.selectorBig.isNotBlank()) add("大")
                                    if (clickProfile.selectorSmall.isNotBlank()) add("小")
                                    if (clickProfile.selectorOdd.isNotBlank()) add("单")
                                    if (clickProfile.selectorEven.isNotBlank()) add("双")
                                    if (clickProfile.selectorAmount.isNotBlank()) add("金额")
                                    if (clickProfile.selectorConfirm.isNotBlank()) add("确认")
                                    if (clickProfile.selectorBalance.isNotBlank()) add("余额")
                                }
                                Text(
                                    "已标注: ${mapped.joinToString(" · ")}",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                TextButton(
                                    onClick = {
                                        val cleared = clickProfile.copy(
                                            selectorBig = "", selectorSmall = "",
                                            selectorOdd = "", selectorEven = "",
                                            selectorAmount = "", selectorConfirm = "",
                                            selectorBalance = ""
                                        )
                                        ClickMatchConfig.save(context, cleared)
                                        ClickMatchConfig.clearCache()
                                        clickProfile = cleared
                                        mappingFeedback = "已清空所有标注"
                                    },
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
                                ) { Text("清空标注", fontSize = 10.sp, color = Color(0xFFC62828)) }
                            }
                        }
                    }
                    Spacer(Modifier.height(4.dp))

                    // 执行模式切换 + 自动挂机开关
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("执行模式", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        FilterChip(
                            selected = executionMode == "webview",
                            onClick = { executorViewModel.setExecutionMode("webview") },
                            label = { Text("WebView", fontSize = 11.sp) }
                        )
                        FilterChip(
                            selected = executionMode == "accessibility",
                            onClick = { executorViewModel.setExecutionMode("accessibility") },
                            label = { Text("无障碍", fontSize = 11.sp) }
                        )
                        Spacer(Modifier.weight(1f))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                if (autoRunning) "挂机中" else "挂机",
                                fontSize = 12.sp,
                                color = if (autoRunning) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(Modifier.width(4.dp))
                            Switch(
                                checked = autoRunning,
                                onCheckedChange = { on ->
                                    if (on) {
                                        // v2.5.3: 开启挂机时清空测试参数，防止历史参数干扰
                                        testDx = ""
                                        testDs = ""
                                        testAmount = ""
                                        dryRun = true
                                        executorViewModel.startAuto(mainViewModel.currentLottery.value.name)
                                    } else executorViewModel.stopAuto()
                                }
                            )
                        }
                    }

                    // 模式状态提示
                    Text(
                        when (executionMode) {
                            "accessibility" -> {
                                val a11yReady = com.caifenxi.app.service.AutoBetAccessibilityService.isRunning()
                                if (a11yReady) "无障碍已就绪 · 复用已配置的点击流水线"
                                else "⚠ 无障碍服务未连接 · 请到「更多→无障碍跟投」开启"
                            }
                            else -> {
                                if (WebViewExecutor.isAvailable) "WebView已连接 · DOM注入点击"
                                else "⚠ WebView未连接 · 请等页面加载完成"
                            }
                        },
                        fontSize = 10.sp,
                        color = when {
                            executionMode == "accessibility" && !com.caifenxi.app.service.AutoBetAccessibilityService.isRunning() -> Color(0xFFC62828)
                            executionMode != "accessibility" && !WebViewExecutor.isAvailable -> Color(0xFFC62828)
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )

                    // 测试参数：方向/金额必须显式确定；不再存在固定“大/单/10”测试工单
                    Surface(
                        shape = MaterialTheme.shapes.small,
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                    ) {
                        Column(Modifier.fillMaxWidth().padding(8.dp)) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text("测试执行参数", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                                TextButton(onClick = {
                                    if (tk.cmdId.isNotBlank()) {
                                        testDx = tk.dx.orEmpty()
                                        testDs = tk.ds.orEmpty()
                                        testAmount = tk.amountText.orEmpty()
                                    }
                                }) { Text("同步当前工单", fontSize = 11.sp) }
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("大小", fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterVertically))
                                listOf("大", "小").forEach { v ->
                                    FilterChip(selected = testDx == v, onClick = { testDx = if (testDx == v) "" else v }, label = { Text(v) })
                                }
                                Spacer(Modifier.width(4.dp))
                                Text("单双", fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterVertically))
                                listOf("单", "双").forEach { v ->
                                    FilterChip(selected = testDs == v, onClick = { testDs = if (testDs == v) "" else v }, label = { Text(v) })
                                }
                            }
                            OutlinedTextField(
                                value = testAmount,
                                onValueChange = { value -> testAmount = value.filter { it.isDigit() || it == '.' }.take(12) },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                label = { Text("测试金额")
                                },
                                placeholder = { Text("必须手动确认，例如 1、2、5") },
                                textStyle = LocalTextStyle.current.copy(fontSize = 13.sp)
                            )
                            Text(
                                "测试只执行上面明确选择的方向；未选择方向或金额无效时不会派发。当前模式：${if (dryRun) "仅识别，不点击" else "实盘点击"}",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // 操作
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                if (autoRunning) return@Button
                                val amountOk = testAmount.toDoubleOrNull()?.let { it > 0.0 && it.isFinite() } == true
                                if ((testDx.isBlank() && testDs.isBlank()) || !amountOk) {
                                    executorViewModel.testSelectorsOnly(context)
                                } else {
                                    val t = executorViewModel.generateTestTask(
                                        dryRun = dryRun,
                                        dx = testDx.takeIf { it.isNotBlank() },
                                        ds = testDs.takeIf { it.isNotBlank() },
                                        amountText = testAmount,
                                        lotteryKey = "manual-test",
                                        issue = "test-${System.currentTimeMillis()}"
                                    )
                                    executorViewModel.startTask(t)
                                }
                            },
                            enabled = !autoRunning,
                            modifier = Modifier.weight(1f)
                        ) { Text(if (dryRun) "测试识别" else "测试执行") }
                        OutlinedButton(
                            onClick = { executorViewModel.testSelectorsOnly(context) },
                            modifier = Modifier.weight(1f)
                        ) { Text("检查选择器") }
                        if (lastFailedTask != null) {
                            Button(
                                onClick = { executorViewModel.retryLastTask() },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFFC62828)
                                )
                            ) {
                                Icon(Icons.Filled.Replay, contentDescription = "重试",
                                    modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("重试")
                            }
                        }
                        OutlinedButton(
                            onClick = { executorViewModel.clearLogs() },
                            modifier = Modifier.weight(1f)
                        ) { Text("清空") }
                    }

                    // 日志
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        if (executorLogs.isEmpty()) {
                            Text("日志空 · 挂机下单后将自动派发到本页", fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        } else {
                            executorLogs.takeLast(8).forEach { log ->
                                Text(
                                    log,
                                    fontSize = 11.sp,
                                    color = when {
                                        log.contains("成功") -> Color(0xFF2E7D32)
                                        log.contains("失败") || log.contains("未找到") -> Color(0xFFC62828)
                                        else -> MaterialTheme.colorScheme.onSurface
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusChip(label: String, value: String, color: Color) {
    Surface(
        shape = MaterialTheme.shapes.small,
        color = color.copy(alpha = 0.12f)
    ) {
        Text(
            "$label $value",
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            fontSize = 11.sp,
            color = color,
            fontWeight = FontWeight.Medium
        )
    }
}
