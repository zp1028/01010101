from __future__ import annotations
import os
from typing import Any

class MarketDataStatusService:
    """Describes configured data capabilities without pretending unavailable feeds are live."""
    def snapshot(self) -> dict[str, Any]:
        hk = bool(os.getenv("SMART_TRADER_HK_UNIVERSE_URL"))
        hk_quote = bool(os.getenv("SMART_TRADER_HK_QUOTE_URL"))
        us_quote = os.getenv("SMART_TRADER_US_QUOTE_URL", "").strip()
        return {
            "analysis_only": True,
            "providers": {
                "crypto": {
                    "universe": "Binance Spot + Futures exchangeInfo",
                    "quotes": "Binance public REST/WebSocket",
                    "configured": True,
                    "realtime": True,
                },
                "us": {
                    "universe": "SEC ticker/CIK discovery",
                    "quotes": "Yahoo public chart endpoint for historical/intraday analysis; optional synchronized provider via SMART_TRADER_US_QUOTE_URL",
                    "configured": True,
                    "realtime": False,
                    "custom_quote_provider": bool(us_quote),
                },
                "hk": {
                    "universe": "HKEX/provider symbol master",
                    "quotes": "Configured provider only",
                    "configured": hk and hk_quote,
                    "realtime": hk_quote,
                    "missing": [x for x, ok in (("universe", hk), ("quote", hk_quote)) if not ok],
                },
                "commodities": {
                    "universe": "Configured futures symbol master only",
                    "quotes": "Provider required for synchronized futures quotes",
                    "configured": bool(os.getenv("SMART_TRADER_COMMODITY_UNIVERSE_URL")) and bool(os.getenv("SMART_TRADER_COMMODITY_QUOTE_URL")),
                    "realtime": bool(os.getenv("SMART_TRADER_COMMODITY_QUOTE_URL")),
                },
            },
            "truth_rule": "A market is not labelled fully covered unless symbol discovery and the required quote feed are both configured.",
        }
