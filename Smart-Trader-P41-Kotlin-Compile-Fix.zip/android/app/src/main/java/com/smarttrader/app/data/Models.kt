package com.smarttrader.app.data

data class MarketItem(
    val symbol: String,
    val name: String,
    val price: String,
    val changePct: Double,
    val attention: Double,
    val regime: String,
    val assetClass: String = "crypto",
    val venue: String = "",
    val currency: String = "",
    val quoteStatus: String = "unknown",
)

data class SignalItem(
    val symbol: String,
    val name: String,
    val direction: String,
    val strength: Double,
    val timeframe: String,
)

data class PositionUi(
    val symbol: String,
    val side: String,
    val qty: String,
    val entry: String,
    val pnl: String,
    val pnlPct: Double,
)

object Watchlist {
    /** Empty by design: the market universe must come from a live provider or cache. */
    val defaults: List<MarketItem> = emptyList()
}
