package com.diveintocrypto.android.ui.scanner

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.diveintocrypto.android.AppContainer
import com.diveintocrypto.android.data.ai.AiAnalysisClient
import com.diveintocrypto.android.domain.consensus.Regime
import com.diveintocrypto.android.domain.accumulation.AccumulationDistributionAssessment
import com.diveintocrypto.android.domain.accumulation.MultiTimeframeAccumulation
import com.diveintocrypto.android.domain.divergence.DivergenceAlignment
import com.diveintocrypto.android.domain.divergence.WhaleDivergence
import com.diveintocrypto.android.domain.model.Signal
import com.diveintocrypto.android.domain.overlay.Microstructure
import com.diveintocrypto.android.domain.overlay.TimestampSeriesAlignment
import com.diveintocrypto.android.domain.overlay.MtfConfluence
import com.diveintocrypto.android.domain.scanner.ScanCandleQuality
import com.diveintocrypto.android.domain.scanner.ScannerRanking
import com.diveintocrypto.android.domain.scanner.OpportunityConfidenceQuality
import com.diveintocrypto.android.platform.beginBackgroundTask
import com.diveintocrypto.android.platform.endBackgroundTask
import com.diveintocrypto.android.platform.nowMillis
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.atomicfu.atomic
import kotlin.math.abs

/**
 * Multi-TF universe scanner — port of the original Python reference
 * implementation (`_run_auto_scan` and its companion `_process_multi_scan_results`).
 *
 * Algorithm (verbatim semantics from the Python source):
 *
 *   1. Pull the full Binance USDT-M futures universe sorted by 24h quoteVolume,
 *      stablecoins removed (see [com.diveintocrypto.android.data.binance.BinanceFuturesClient]).
 *
 *   2. **Phase 1** — scan the high-time-weight timeframes [1d, 12h, 8h] across EVERY
 *      symbol in the universe. After phase 1 completes, aggregate each symbol's
 *      `finalScore` total and keep the top `scanSurvivors` (Settings, 50 by default).
 *
 *   3. **Phase 2** — scan the remaining 9 lower-time-weight timeframes
 *      [1m, 3m, 5m, 15m, 30m, 1h, 2h, 4h, 6h] but ONLY across the phase-2
 *      survivors. This is the optimization that lets the original scanner scan
 *      12 timeframes in a few minutes instead of 578 × 12 = 6936 individual
 *      kline requests.
 *
 *   4. **Per-TF top15** — for each timeframe, sort results by
 *      `finalScore = confidence² × timeWeight / 100` desc and keep the top 15.
 *
 *   5. **Cross-rank** — for every symbol that appears in any TF's top15,
 *      compute `buy_nss = Σ finalScore where signal ∈ {BUY, STRONG_BUY}`,
 *      `sell_nss = Σ finalScore where signal ∈ {SELL, STRONG_SELL}`. Dominant
 *      direction is whichever is larger; `net_nss = max - min`. Sort symbols
 *      by `net_nss` desc.
 *
 *   6. **Fill in non-top15 TFs for the displayed top-N** — so every CoinResultCard
 *      shows 12 real per-TF cells (not 11 placeholders).
 */
class ScannerViewModel(private val container: AppContainer) : ViewModel() {

    private val _ui = MutableStateFlow(ScannerUiState())
    val ui: StateFlow<ScannerUiState> = _ui.asStateFlow()

    /** Active scan coroutine. Cancelled on stop or when a new scan supersedes it. */
    private var scanJob: Job? = null

    /**
     * Baseline used by opportunity lifecycle checks. Unlike [ScannerUiState.survivors],
     * this is updated only after a complete scan: preview rows and interrupted/partial
     * scans must never become the "previous completed" truth for risk-plan invalidation.
     */
    private val lifecycleBaseline = com.diveintocrypto.android.domain.scanner.OpportunityLifecycleBaseline()

    private data class CachedAiFusion(
        val savedAtMs: Long,
        val advice: AiAnalysisClient.FusionAdvice,
        val localDirection: Int,
        val referencePrice: Double,
        val baseUrl: String,
        val model: String,
    )
    private val aiFusionCache = mutableMapOf<String, CachedAiFusion>()

    /**
     * Monotonic generation token. Every [startScan] bumps it; late results from an
     * older generation are discarded so a stopped/restarted scan cannot overwrite
     * newer UI state.
     */
    private val scanGeneration = atomic(0L)

    init {
        // App-scoped services that scans (and the watchlist) rely on. Both are
        // idempotent: the all-market mini-ticker socket feeds live prices, and
        // the alert engine arms its price-rule observation if rules exist.
        container.liveTickerEngine.ensureStarted()
        runCatching { container.alertEngine.startTickerObservation() }
    }

    /** Toggle CONTINUOUS (back-to-back) scanning. When on, a new scan starts as soon as one finishes. */
    fun setContinuous(on: Boolean) { _ui.update { it.copy(continuous = on) } }

    /** Table size (how many surviving coins to show): 5/10/15/20 or Int.MAX_VALUE = All.
     *  No re-scan needed — the screen takes this many from [ScannerUiState.survivors]. */
    fun setDisplaySize(n: Int) { _ui.update { it.copy(displaySize = n) } }

    /** Toggle the OPT-IN "背离排序" lens (default OFF).
     *  Triggers ONLY a presentation re-sort — the SAME survivor pool is sorted by |divergenceScore|
     *  desc (surfacing the cross-sectional top-K validated by backtest). The signal/score/
     *  elimination/candidate-pool are UNCHANGED; when OFF, behavior is bit-for-bit identical to today. */
    fun setDivergenceSort(on: Boolean) { _ui.update { it.copy(divergenceSort = on) } }

    /** Persist a new phase-1 universe mode (scanner depth chips). Takes effect on the next scan. */
    fun setUniverseMode(label: String) {
        val mode = com.diveintocrypto.android.data.ScanUniverseMode.fromLabel(label)
        val s = container.settingsStore.getSettings()
        container.settingsStore.updateSettings(s.copy(scanUniverse = mode.label))
        _ui.update { it.copy(universeMode = mode.label) }
    }

    fun startScan() = startScanInternal(requestedSymbols = null)

    /** Scan only the supplied favorites, bypassing the normal TOP20/TOP50 universe cap. */
    fun startWatchlistScan(symbols: List<String>) {
        val normalized = symbols.map { it.trim().uppercase() }.filter { it.isNotBlank() }.distinct()
        if (normalized.isEmpty()) {
            _ui.update { it.copy(error = "自选快速扫描未启动：请先添加自选品种。") }
            return
        }
        startScanInternal(requestedSymbols = normalized)
    }

    private fun startScanInternal(requestedSymbols: List<String>?) {
        // Prevent concurrent / duplicate scan tasks. A second click while scanning is a no-op.
        if (_ui.value.scanning) return

        // Bump generation so any in-flight work from a previous (cancelled) job cannot
        // commit results after this new scan owns the UI.
        val gen = scanGeneration.incrementAndGet()

        // A new scan does NOT clear previous results — they stay on screen until new ones arrive.
        // (Only progress/error are reset; feed/survivors/eliminated are kept.)
        _ui.update {
            it.copy(
                scanning = true,
                stopRequested = false,
                cycle = 0,
                completedCount = 0,
                totalCount = 0,
                failedCount = 0,
                failureReasonCounts = emptyMap(),
                etaSeconds = null,
                currentSymbol = null,
                currentPhase = ScanPhase.UNIVERSE,
                error = null,
                universeLoading = true,
            )
        }

        // Cancel any leftover job (should already be null when !scanning, but be defensive).
        scanJob?.cancel()
        scanJob = viewModelScope.launch(kotlinx.coroutines.Dispatchers.Default) {
            var ok = false
            try {
                do {
                    // Best-effort: if the app goes to the background during a scan cycle,
                    // request a short extra execution window from iOS (≈30s). No-op on Android.
                    val bgToken = beginBackgroundTask("dive-scan")
                    try {
                        ok = runOneScan(gen, requestedSymbols)
                    } catch (e: CancellationException) {
                        // ViewModel teardown / parent cancellation / stop must remain cooperative.
                        throw e
                    } catch (t: Throwable) {
                        // 交叉排名等阶段异常不得让 scanning 永远为 true
                        if (scanGeneration.value == gen) {
                            _ui.update {
                                it.copy(
                                    error = "扫描异常：${t.message ?: t::class.simpleName}",
                                    currentPhase = ScanPhase.IDLE,
                                    currentSymbol = null,
                                    universeLoading = false,
                                )
                            }
                        }
                        ok = false
                    } finally {
                        endBackgroundTask(bgToken)
                    }
                    if (ok && scanGeneration.value == gen) {
                        _ui.update { it.copy(cycle = it.cycle + 1) }
                    }
                } while (
                    ok &&
                    scanGeneration.value == gen &&
                    _ui.value.continuous &&
                    !_ui.value.stopRequested
                )
            } finally {
                // Only the owner generation may clear the running flags. A newer startScan
                // (or an explicit stop that already cleaned UI) must not be clobbered.
                if (scanGeneration.value == gen) {
                    _ui.update {
                        it.copy(
                            scanning = false,
                            stopRequested = false,
                            currentPhase = ScanPhase.IDLE,
                            currentSymbol = null,
                            universeLoading = false,
                            etaSeconds = null,
                        )
                    }
                    scanJob = null
                }
            }
        }
    }

    fun stopDemoScan() {
        // Signal cooperative stop for in-flight scanOne / phase loops.
        _ui.update { it.copy(stopRequested = true) }
        // Hard-cancel the job so network work and late result commits stop promptly.
        scanJob?.cancel()
        scanJob = null
        // Bump generation so any CancellationException handler or late _ui.update from
        // the dying job cannot overwrite the cleaned state or a subsequent scan.
        scanGeneration.incrementAndGet()
        // Immediate UI cleanup — no leftover "still scanning" / progress / loading flags.
        _ui.update {
            it.copy(
                scanning = false,
                stopRequested = false,
                currentPhase = ScanPhase.IDLE,
                currentSymbol = null,
                universeLoading = false,
                etaSeconds = null,
                completedCount = 0,
                totalCount = 0,
            )
        }
    }

    /** Fills missing (non-top15) TF cells for a displayed row from the full results.
     *  Pure — delegates to the companion function. */
    private fun patchPerTf(row: CrossRankingRow, tfResults: Map<String, List<SymbolTfResult>>): CrossRankingRow =
        patchPerTfRow(row, tfResults)

    /**
     * Runs one FULL universe scan. true = completed, false = stopped/error.
     * [generation] must still equal [scanGeneration] when results are committed;
     * otherwise the work is discarded (prevents stale results overwriting a newer scan).
     */
    private suspend fun runOneScan(generation: Long, requestedSymbols: List<String>?): Boolean {
        // Use only the last fully completed baseline. The visible survivors list may be
        // replaced by provisional preview rows during a scan or after an interrupted run.
        val previousCompletedSnapshots = lifecycleBaseline.snapshot()
        // Reset progress but keep previous results on screen (so continuous mode doesn't flicker).
        if (scanGeneration.value != generation) return false
        _ui.update {
            it.copy(
                completedCount = 0,
                totalCount = 0,
                failedCount = 0,
                failureReasonCounts = emptyMap(),
                currentSymbol = null,
                currentPhase = ScanPhase.UNIVERSE,
                universeLoading = true,
                error = null,
            )
        }
        run {
            val fullUniverse = try {
                container.repository.futuresUniverse()
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                if (scanGeneration.value == generation) {
                    _ui.update {
                        it.copy(
                            universeLoading = false,
                            currentPhase = ScanPhase.IDLE,
                            error = "获取交易对列表失败：${t.message ?: "网络错误"}",
                        )
                    }
                }
                return false
            }
            if (fullUniverse.isEmpty()) {
                if (scanGeneration.value == generation) {
                    _ui.update {
                        it.copy(
                            universeLoading = false,
                            currentPhase = ScanPhase.IDLE,
                            error = "币安合约交易对列表为空",
                        )
                    }
                }
                return false
            }

            val settings = container.settingsStore.getSettings()

            // ── Universe: regular volume-ranked cap OR explicit favorites-only quick scan. ──
            val universeMode = com.diveintocrypto.android.data.ScanUniverseMode.fromLabel(settings.scanUniverse)
            val universe = if (requestedSymbols != null) {
                val requested = requestedSymbols.map { it.uppercase() }.toSet()
                fullUniverse.filter { it.trim().uppercase() in requested }
            } else {
                fullUniverse.take(universeMode.limit ?: fullUniverse.size)
            }
            if (universe.isEmpty()) {
                if (scanGeneration.value == generation) {
                    _ui.update { it.copy(universeLoading = false, currentPhase = ScanPhase.IDLE,
                        error = if (requestedSymbols != null) "自选快速扫描未找到可用的币安 USDT-M 合约，请检查自选品种。" else "币安合约交易对列表为空") }
                }
                return false
            }
            // Phase-2 survivor pool N is capped by the actual universe to keep progress/ETA honest.
            val phase2N = settings.scanDepthTop.coerceAtLeast(1).coerceAtMost(universe.size)
            val effectiveUniverseLabel = if (requestedSymbols != null) "自选快速" else universeMode.label

            val totalTfScans = universe.size * PHASE1_TFS.size + phase2N * PHASE2_TFS.size
            val scanStartedMs = nowMillis()
            if (scanGeneration.value != generation) return false
            _ui.update {
                it.copy(
                    universeLoading = false,
                    universeSize = universe.size,
                    universeMode = effectiveUniverseLabel,
                    totalCount = totalTfScans,
                    etaSeconds = null,
                    currentPhase = ScanPhase.PHASE1,
                )
            }

            // ── ADAPTIVE CONCURRENCY: big universes get more in-flight requests ──
            val parallelism = adaptiveParallelism(settings.scanParallelism, universe.size)
            val sem = Semaphore(parallelism)
            val mutex = Mutex()
            val tfResults: MutableMap<String, MutableList<SymbolTfResult>> = mutableMapOf()
            // HONESTY: symbols whose kline fetch FAILED (network error) — previously the
            // failure was swallowed (`catch → emptyList`) and silently shrank the coverage.
            // Now counted and exposed as ScannerUiState.failedCount so the UI can say
            // "N symbols could not be scanned".
            val failedSymbols = mutableSetOf<String>()
            val failureReasonCounts = mutableMapOf<String, Int>()
            var completed = 0

            suspend fun recordScanFailure(symbol: String, reason: String) {
                mutex.withLock {
                    failedSymbols.add(symbol)
                    failureReasonCounts[reason] = (failureReasonCounts[reason] ?: 0) + 1
                    if (scanGeneration.value == generation) {
                        _ui.update { state -> state.copy(
                            failedCount = failedSymbols.size,
                            failureReasonCounts = failureReasonCounts.toMap(),
                        ) }
                    }
                }
            }

            suspend fun scanOne(symbol: String, tf: String) {
                if (_ui.value.stopRequested || scanGeneration.value != generation) return
                sem.withPermit {
                    if (_ui.value.stopRequested || scanGeneration.value != generation) return@withPermit
                    if (scanGeneration.value == generation) {
                        _ui.update { it.copy(currentSymbol = symbol) }
                    }
                    val candles = try {
                        container.repository.futuresHistory(symbol, tf, limit = 300)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (_: Throwable) {
                        recordScanFailure(symbol, "network_or_api")
                        emptyList()
                    }

                    val quality = ScanCandleQuality.validate(
                        candles = candles,
                        timeframeMs = PERIOD_MS[tf] ?: 60_000L,
                        nowMs = nowMillis(),
                    )
                    if (quality.valid) {
                        val indicatorOuts = container.indicators.map { it.calculate(candles) }
                        val out = container.consensus.evaluate(indicatorOuts)
                        val price = candles.last().close
                        val weight = TIME_WEIGHTS[tf] ?: 50
                        val finalScore = ScannerRanking.finalScore(out.confidence, tf)
                        // DISPLAY-ONLY: read the ATR% that the indicator layer ALREADY computed
                        // (atr_filter → atr_pct). No new computation; it never enters the score.
                        val atrPct = indicatorOuts
                            .firstOrNull { it.name == "atr_filter" }
                            ?.rawValues?.get("atr_pct")
                        // REGIME overlay (domain/consensus/Regime.kt): label-only, computed from
                        // the already-computed ADX/Choppiness raws. ADDITIVE annotation — it
                        // never enters score/elimination (the consensus verdict is untouched).
                        val regime = Regime.detect(indicatorOuts).regime
                        // Confirmed swing levels are display-only and never enter scoring.
                        val structureLevels = com.diveintocrypto.android.domain.scanner.ConfirmedStructureLevels.find(
                            highs = candles.map { it.high },
                            lows = candles.map { it.low },
                            currentPrice = price,
                        )
                        // Descriptive accumulation/distribution evidence from the exact OHLCV
                        // series already fetched for this symbol/timeframe. Display-only.
                        val accumulation = AccumulationDistributionAssessment.assess(
                            AccumulationDistributionAssessment.Input(
                                high = candles.map { it.high },
                                low = candles.map { it.low },
                                close = candles.map { it.close },
                                volume = candles.map { it.volume },
                            ),
                        )

                        mutex.withLock {
                            tfResults.getOrPut(tf) { mutableListOf() }.add(
                                SymbolTfResult(
                                    symbol = symbol,
                                    tf = tf,
                                    signal = out.finalSignal,
                                    confidence = out.confidence,
                                    price = price,
                                    timeWeight = weight,
                                    finalScore = finalScore,
                                    atrPct = atrPct,
                                    supportPrice = structureLevels.support,
                                    resistancePrice = structureLevels.resistance,
                                    regime = regime,
                                    accumulation = accumulation,
                                    latestCandleOpenTimeMs = candles.last().openTime,
                                    timeframeMs = PERIOD_MS[tf] ?: 60_000L,
                                ),
                            )
                        }
                    } else {
                        recordScanFailure(symbol, quality.reason ?: "invalid_candles")
                    }
                    mutex.withLock {
                        completed += 1
                        val snap = completed
                        // HONEST PROGRESS: rolling throughput → ETA (null until the
                        // first completions give a rate). Skip if this generation is stale.
                        if (scanGeneration.value == generation) {
                            _ui.update { s ->
                                val eta = estimateEtaSeconds(snap, s.totalCount, nowMillis() - scanStartedMs)
                                if (s.completedCount == snap && s.etaSeconds == eta) s
                                else s.copy(completedCount = snap, etaSeconds = eta)
                            }
                        }
                    }
                }
            }

            // ── Phase 1: all universe on [1d, 12h, 8h] ────────────────────────
            coroutineScope {
                // Bound coroutine fan-out by symbols, not symbol × timeframe cells.
                // `scanOne` still uses the shared semaphore, so network concurrency remains
                // capped while ALL-universe scans avoid allocating thousands of Deferred jobs.
                val jobs = universe.map { sym ->
                    async {
                        for (tf in PHASE1_TFS) {
                            if (_ui.value.stopRequested) break
                            scanOne(sym, tf)
                        }
                    }
                }
                jobs.awaitAll()
            }

            if (_ui.value.stopRequested || scanGeneration.value != generation) return false

            // ── Determine phase-2 survivors: top scanDepthTop by Σ phase-1 finalScore ──
            // Shared pure ranking (ScannerRanking) keeps live scan and historical replay identical.
            val phase1Cells = PHASE1_TFS.flatMap { tf ->
                (tfResults[tf] ?: emptyList()).map { r ->
                    ScannerRanking.RankCell(
                        symbol = r.symbol,
                        timeframe = tf,
                        signal = r.signal,
                        confidence = r.confidence,
                        finalScore = r.finalScore,
                        price = r.price,
                    )
                }
            }
            val survivors = ScannerRanking.selectPhase2Survivors(phase1Cells, depth = phase2N)

            if (scanGeneration.value != generation) return false
            _ui.update { it.copy(currentPhase = ScanPhase.PHASE2) }

            // ── Phase 2: survivors only on remaining 9 TFs ───────────────────
            coroutineScope {
                // One coroutine per survivor; scan its timeframe cells sequentially.
                // This substantially reduces task allocation without changing scoring,
                // timeframe coverage, or the shared in-flight request limit.
                val jobs = survivors.map { sym ->
                    async {
                        for (tf in PHASE2_TFS) {
                            if (_ui.value.stopRequested) break
                            scanOne(sym, tf)
                        }
                    }
                }
                jobs.awaitAll()
            }

            if (_ui.value.stopRequested || scanGeneration.value != generation) return false

            _ui.update { it.copy(currentPhase = ScanPhase.FINALIZING) }

            // ── Per-TF top15 by finalScore desc (shared ScannerRanking.perTfTopN) ──
            val allRankCells = ALL_TFS.flatMap { tf ->
                (tfResults[tf] ?: emptyList()).map { r ->
                    ScannerRanking.RankCell(
                        symbol = r.symbol,
                        timeframe = tf,
                        signal = r.signal,
                        confidence = r.confidence,
                        finalScore = r.finalScore,
                        price = r.price,
                    )
                }
            }
            val topCellsByTf = ScannerRanking.perTfTopN(allRankCells, n = ScannerRanking.DEFAULT_PER_TF_TOP_N)
            val tfTop15: Map<String, List<SymbolTfResult>> = ALL_TFS.associateWith { tf ->
                val topSyms = topCellsByTf[tf].orEmpty().map { it.symbol.trim().uppercase() }.toSet()
                (tfResults[tf] ?: emptyList())
                    .filter { it.symbol.trim().uppercase() in topSyms }
                    .sortedByDescending { it.finalScore }
                    .take(ScannerRanking.DEFAULT_PER_TF_TOP_N)
            }

            // ── Cross-rank；若 top15 全空则用全部 TF 结果回退，避免「排名完没列表」
            var crossRows: List<CrossRankingRow> = crossRankRows(tfTop15, tfResults)
            if (crossRows.isEmpty()) {
                val allByTf = ALL_TFS.associateWith { tf -> tfResults[tf] ?: emptyList() }
                crossRows = crossRankRows(allByTf, tfResults)
            }

            // ── TF 补扫（对齐原版意图：进榜卡应尽量 12 格都有数据）────────
            // 阶段2只扫 ~50 币；1d/12h Top15 里可能混入未做短周期的币，格子会全是 —。
            // 对交叉榜符号检查缺失周期并补扫，再 patchPerTf 填格。不改得分公式。
            if (crossRows.isNotEmpty() && !_ui.value.stopRequested) {
                val boardSymbols = crossRows.map { it.symbol }.distinct()
                // Build the missing-cell plan once. Keep fan-out bounded by symbols rather
                // than allocating one Deferred for every missing symbol × timeframe cell.
                val missingBySymbol = boardSymbols.associateWith { sym ->
                    ALL_TFS.filter { tf ->
                        tfResults[tf]?.any { it.symbol.equals(sym, ignoreCase = true) } != true
                    }
                }.filterValues { it.isNotEmpty() }
                val extraScans = missingBySymbol.values.sumOf { it.size }
                if (extraScans > 0) {
                    // Fill scans are real requests too; include them in progress/ETA totals.
                    _ui.update { it.copy(totalCount = it.totalCount + extraScans, etaSeconds = null) }
                }
                coroutineScope {
                    val jobs = missingBySymbol.map { (sym, missingTfs) ->
                        async {
                            for (tf in missingTfs) {
                                if (_ui.value.stopRequested) break
                                scanOne(sym, tf)
                            }
                        }
                    }
                    jobs.awaitAll()
                }
            }

            // 尽快把初步排名推到 UI（背离/微观结构仍可在后台 refinement）
            if (crossRows.isNotEmpty()) {
                val preview = crossRows.map { patchPerTf(it, tfResults) }
                val previewHot = preview.take(_ui.value.displaySize.coerceAtMost(preview.size).coerceAtLeast(1)).mapIndexed { i, row ->
                    ScannerFeedItem(
                        symbol = row.symbol,
                        rank = i + 1,
                        signal = row.dominantDir,
                        confidence = confidenceFor(row),
                        price = row.price,
                        riskLevel = riskFromAgreement(row.countHit, row.totalTfs),
                        error = null,
                    )
                }
                _ui.update {
                    it.copy(
                        crossRanking = preview,
                        survivors = preview,
                        hotList = previewHot,
                        currentPhase = ScanPhase.FINALIZING,
                        currentSymbol = null,
                    )
                }
            }

            // ── Whale L/S divergence: compute for the candidate pool (first DIVERGENCE_CANDIDATES,
            //    by netNss); then blend the table order with netNss. Since L/S data is expensive,
            //    it is fetched only for the candidates, not the whole universe.
            // Candidate pool = top-N by netNss ∪ high-TF (1d/12h) leaders. High-TF leaders are the
            // symbols most likely to have experienced a price rally; even when their netNss is low,
            // divergence is computed → this closes the low-netNss blind spot (reviewer P1).
            val highTfLeaders = (tfTop15["1d"].orEmpty() + tfTop15["12h"].orEmpty())
                .map { it.symbol }.toSet()
            val candidateSymbols =
                crossRows.take(DIVERGENCE_CANDIDATES).map { it.symbol }.toSet() + highTfLeaders
            val candidates = crossRows.filter { it.symbol in candidateSymbols }
            // value = (result, usable-TF count) — for coverage visibility.
            val divMap = mutableMapOf<String, Pair<WhaleDivergence.SymbolResult, Int>>()
            // A SEPARATE semaphore for the divergence phase — we don't tie up the scan sem. (P0 fix:
            // 18 sequential network calls under a single permit serialized the phase.) All
            // candidate × TF requests share this gate → real bounded parallelism.
            val divGate = Semaphore(parallelism)
            // 背离计算允许失败/超时：不得阻塞「排名结果」落盘
            try {
                kotlinx.coroutines.withTimeout(90_000L) {
                    coroutineScope {
                        candidates.map { row ->
                            async {
                                if (_ui.value.stopRequested) return@async
                                _ui.update { it.copy(currentSymbol = row.symbol) }
                                val res = computeDivergence(row.symbol, divGate)
                                mutex.withLock { divMap[row.symbol] = res }
                            }
                        }.awaitAll()
                    }
                }
            } catch (_: kotlinx.coroutines.TimeoutCancellationException) {
                // 背离计算超时：仍用已有 crossRows 出榜。
            } catch (e: CancellationException) {
                // Parent/ViewModel cancellation must not be converted into a successful partial scan.
                throw e
            } catch (_: Throwable) {
                // 部分或全部背离失败 → 仍用已有 crossRows 出榜
            }
            val maxNet = crossRows.maxOfOrNull { it.netNss }?.takeIf { it > 0.0 } ?: 1.0
            // 候选为空时回退全量 crossRows，避免排名阶段结束后列表空白
            val rankSource = if (candidates.isNotEmpty()) candidates else crossRows
            val locallyRankedRows = rankSource
                .map { row ->
                    val d = divMap[row.symbol]
                    row.copy(
                        divergenceScore = d?.first?.score ?: 0.0,
                        divergenceTf = d?.first?.bestTf,
                        divergenceRisePct = d?.first?.bestRisePct ?: 0.0,
                        divergenceWhaleDrop = d?.first?.bestWhaleDrop ?: 0.0,
                        // -1 = was not a candidate (never tried); 0 = tried but no whale data.
                        divergenceCoverage = d?.second ?: -1,
                        divergenceDirection = d?.first?.direction ?: 0,
                        divergencePatternDirection = d?.first?.patternDirection ?: 0,
                    )
                }
                .sortedByDescending { row ->
                    val netNorm = (row.netNss / maxNet).coerceIn(0.0, 1.0)
                    // DIRECTIONAL divergence: the signed score shifts ranking directly —
                    // bullish (+, accumulation) pushes up, bearish (−, distribution) pushes DOWN (negative score).
                    // Sub-threshold |score| is treated as noise.
                    val sig = if (abs(row.divergenceScore) >= DIVERGENCE_MIN_SHOWN)
                        (row.divergenceScore / 100.0).coerceIn(-1.0, 1.0) else 0.0
                    netNorm + DIVERGENCE_RANK_WEIGHT * sig
                }.map { row ->
                    val netNorm = (row.netNss / maxNet).coerceIn(0.0, 1.0)
                    val sig = if (abs(row.divergenceScore) >= DIVERGENCE_MIN_SHOWN)
                        (row.divergenceScore / 100.0).coerceIn(-1.0, 1.0) else 0.0
                    row.copy(localRankScore = netNorm + DIVERGENCE_RANK_WEIGHT * sig)
                }
            val rankedRows = applyAiFusionRanking(locallyRankedRows, maxNet)

            // ── ELIMINATION + BACKFILL: eliminate coins whose whale divergence runs OPPOSITE
            //    the indicator direction; fill the vacated slots with the next (lower-scoring)
            //    eligible coins (filter-then-take = automatic backfill). ───────────────
            val (survivorsRaw, eliminatedRows) = eliminateAdverse(rankedRows)
            // Fill TF cells for ALL rows — displaySize=All shows every survivor.
            val survivorRows = survivorsRaw.map { patchPerTf(it, tfResults) }
            val elimRows = eliminatedRows.map { patchPerTf(it, tfResults) }
            // 剔除前完整排名（供共识回退与启动池使用）
            val rankedPatched = rankedRows.map { patchPerTf(it, tfResults) }
            // 若背离剔除后为空，回退到剔除前排名，避免扫描完成却「完全没列表」
            val displaySurvivorRows =
                if (survivorRows.isNotEmpty()) survivorRows else rankedPatched

            // ── MICROSTRUCTURE overlay annotations (domain/overlay/Microstructure.kt) ──
            // ADDITIVE display-only, computed for the visible head of the survivor table
            // (bounded by [MICRO_ANNOTATION_LIMIT] to cap the extra REST calls; the engine's
            // 30s series caches absorb repeats in continuous mode). Any fetch failure → no
            // annotation (fields stay null). NEVER enters score/elimination.
            val microGate = Semaphore(parallelism)
            val microLimit = displaySurvivorRows.size.coerceAtMost(MICRO_ANNOTATION_LIMIT)
            val microResults: Map<String, Microstructure.Result> =
                if (microLimit > 0 && !_ui.value.stopRequested) {
                    try {
                        kotlinx.coroutines.withTimeout(45_000L) {
                            coroutineScope {
                                displaySurvivorRows.take(microLimit).map { row ->
                                    async { row.symbol to computeMicrostructure(row.symbol, microGate) }
                                }.awaitAll().mapNotNull { (sym, res) -> res?.let { sym to it } }.toMap()
                            }
                        }
                    } catch (_: kotlinx.coroutines.TimeoutCancellationException) {
                        // Optional microstructure enrichment is time-bounded; keep core scan results.
                        emptyMap()
                    } catch (e: CancellationException) {
                        throw e
                    } catch (_: Throwable) {
                        emptyMap()
                    }
                } else emptyMap()
            val annotatedSurvivorRows = displaySurvivorRows.mapIndexed { i, row ->
                val m = if (i < microLimit) microResults[row.symbol] else null
                if (m != null) {
                    row.copy(
                        microScore = m.score,
                        microDirection = m.direction,
                        microLabel = m.label,
                        microActive = m.active,
                        microCoveragePercent = m.coveragePercent,
                    )
                } else row
            }

            val size = _ui.value.displaySize
            val finalHotList: List<ScannerFeedItem> = annotatedSurvivorRows
                .take(size.coerceAtMost(annotatedSurvivorRows.size))
                .mapIndexed { i, row ->
                    ScannerFeedItem(
                        symbol = row.symbol,
                        rank = i + 1,
                        signal = row.dominantDir,
                        confidence = confidenceFor(row),
                        price = row.price,
                        riskLevel = riskFromAgreement(row.countHit, row.totalTfs),
                        error = null,
                    )
                }

            // ── ALERT HOOK (domain/alerts/AlertEngine): VERDICT + CONFIDENCE rules
            //    evaluated over the survivor head. Bounded to [ALERT_SCAN_LIMIT]
            //    rows; the OI series is only fetched for symbols with an OI rule.
            //    Failure-tolerant: alerts must never break the scan. ──
            try {
                val alertRows = annotatedSurvivorRows.take(ALERT_SCAN_LIMIT)
                val verdicts = alertRows.associate { row ->
                    row.symbol to com.diveintocrypto.android.domain.alerts.AlertVerdict(
                        signal = row.dominantDir.name,
                        confidence = confidenceFor(row),
                        price = row.price,
                    )
                }
                val oiRules = container.alertEngine.rules.value.filter {
                    it.enabled && it.kind == com.diveintocrypto.android.domain.alerts.AlertKind.OI_SPIKE_PCT
                }
                val oiSpike = if (oiRules.isEmpty()) emptyMap() else {
                    val gate = Semaphore(parallelism)
                    val wanted = oiRules.map { it.symbol }.toSet()
                        .intersect(alertRows.map { it.symbol }.toSet())
                    coroutineScope {
                        wanted.map { sym ->
                            async {
                                gate.withPermit {
                                    try {
                                        val oi = container.repository.openInterestHist(sym, "1h", limit = 30)
                                        sym to (com.diveintocrypto.android.domain.alerts.AlertEvaluator
                                            .oiSpikePct(oi.map { it.sumOpenInterestValue }) ?: Double.NaN)
                                    } catch (e: CancellationException) {
                                        throw e
                                    } catch (_: Throwable) {
                                        sym to Double.NaN
                                    }
                                }
                            }
                        }.awaitAll().toMap().filterValues { !it.isNaN() }
                    }
                }
                container.alertEngine.onScanResultsAsync(verdicts, oiSpike)
            } catch (e: CancellationException) {
                throw e
            } catch (_: Throwable) {
                // Alert side effects are best-effort, but parent cancellation must propagate.
            }

            // Compare this completed scan against the previous completed snapshot. This is
            // presentation/risk-review metadata only; it does not alter scores or ranking.
            val previousSnapshots = previousCompletedSnapshots
            val previousBySymbol = previousSnapshots.filter { it.symbol.isNotBlank() }.associateBy { it.symbol.trim().uppercase() }
            val lifecycleRows = annotatedSurvivorRows.map { row ->
                val snapshot = com.diveintocrypto.android.domain.scanner.OpportunityLifecycle.Snapshot(
                    row.symbol, lifecycleDirection(row.dominantDir), row.price, row.atrPct
                )
                val assessment = com.diveintocrypto.android.domain.scanner.OpportunityLifecycle.assess(
                    snapshot, previousBySymbol[row.symbol.trim().uppercase()]
                )
                row.copy(lifecycleLabel = assessment.label, lifecycleNote = assessment.note,
                    lifecycleStatus = assessment.status.name)
            }
            val scanCoverageComplete = _ui.value.failedCount == 0 &&
                _ui.value.completedCount >= _ui.value.totalCount && _ui.value.totalCount > 0
            val currentLifecycleSnapshots = lifecycleRows.map {
                com.diveintocrypto.android.domain.scanner.OpportunityLifecycle.Snapshot(
                    it.symbol, lifecycleDirection(it.dominantDir), it.price, it.atrPct
                )
            }
            val lifecycleSummary = com.diveintocrypto.android.domain.scanner.OpportunityLifecycle.summarize(
                currentLifecycleSnapshots,
                previousSnapshots,
                scanComplete = scanCoverageComplete
            )

            // ── VERDICT EVIDENCE (domain/evidence): archive the survivor head for
            //    the Performance screen's self-grading. Failure-tolerant; capped. ──
            try {
                val now = nowMillis()
                val records = annotatedSurvivorRows.take(EVIDENCE_APPEND_LIMIT).map { row ->
                    com.diveintocrypto.android.domain.evidence.VerdictRecord(
                        ts = now,
                        symbol = row.symbol,
                        verdict = row.dominantDir.name,
                        confidence = confidenceFor(row),
                        risk = riskFromAgreement(row.countHit, row.totalTfs),
                        price = row.price,
                        dominantDir = when {
                            row.dominantDir == Signal.BUY || row.dominantDir == Signal.STRONG_BUY -> 1
                            row.dominantDir == Signal.SELL || row.dominantDir == Signal.STRONG_SELL -> -1
                            else -> 0
                        },
                    )
                }
                container.evidenceStore.appendAll(records)
            } catch (e: CancellationException) {
                throw e
            } catch (_: Throwable) {
                // Evidence persistence is best-effort; cancellation is never swallowed.
            }

            // Discard late results if this scan was superseded (stop / new startScan).
            if (scanGeneration.value != generation) return false

            // Promote the lifecycle baseline only when this scan fully covered its work.
            // Partial scans still render useful results, but cannot overwrite the trusted
            // comparison snapshot used to invalidate or regenerate risk-plan levels.
            lifecycleBaseline.promoteIfComplete(currentLifecycleSnapshots, scanComplete = scanCoverageComplete)

            _ui.update {
                it.copy(
                    currentPhase = ScanPhase.IDLE,
                    currentSymbol = null,
                    hotList = finalHotList,
                    // 完整剔除前排名（诊断与回退）
                    crossRanking = rankedPatched,
                    // 展示用：剔除后列表；若全被剔除则回退为 rankedPatched
                    survivors = lifecycleRows,
                    lifecycleSummary = "新 ${lifecycleSummary.newCount} · 跟踪 ${lifecycleSummary.activeCount} · 反转 ${lifecycleSummary.reversedCount} · 价格复核 ${lifecycleSummary.movedCount} · " +
                        if (lifecycleSummary.coverageComplete) "消失 ${lifecycleSummary.disappearedCount}" else "扫描不完整，消失待确认",
                    eliminated = elimRows,
                    lastScanAtMs = nowMillis(),
                    error = when {
                        annotatedSurvivorRows.isEmpty() && rankedPatched.isEmpty() ->
                            "扫描完成但无可用排名：请检查网络线路或缩小扫描宇宙后重试"
                        survivorRows.isEmpty() && rankedPatched.isNotEmpty() ->
                            "提示：背离剔除后无剩余币种，已回退显示剔除前排名"
                        else -> it.error
                    },
                )
            }
        }
        return scanGeneration.value == generation
    }

    /**
     * Opt-in AI fusion runs only on the four strongest local candidates. Local ranking is
     * preserved as baseline; AI contributes a tightly bounded delta and cannot change direction,
     * bypass adverse-divergence elimination, or execute trades. Failure/timeout is a local fallback.
     */
    private suspend fun applyAiFusionRanking(
        rows: List<CrossRankingRow>,
        maxNet: Double,
    ): List<CrossRankingRow> {
        val settings = container.settingsStore.getSettings()
        if (!settings.aiFusionEnabled || !settings.aiEnabled || settings.aiApiKey.isBlank() || rows.isEmpty()) {
            return rows.map { it.copy(aiFusionStatus = if (settings.aiFusionEnabled) "AI未启用/未配置Key" else "AI融合关闭") }
        }
        val now = nowMillis()
        val candidates = rows.take(4).filter { it.dominantDir != Signal.NEUTRAL }
        if (candidates.isEmpty()) return rows.map { it.copy(aiFusionStatus = "无可研判的本地定向候选") }
        val evaluated = mutableMapOf<String, Triple<com.diveintocrypto.android.domain.scanner.AiFusionPolicy.Decision, AiAnalysisClient.FusionAdvice?, String?>>()
        val gate = Semaphore(2)
        try {
            withTimeout(24_000L) {
                coroutineScope {
                    candidates.map { row -> async {
                        gate.withPermit {
                            val localDirection = if (row.dominantDir.score > 0) 1 else if (row.dominantDir.score < 0) -1 else 0
                            val cached = aiFusionCache[row.symbol]?.takeIf {
                                now - it.savedAtMs in 0..60_000L && it.localDirection == localDirection &&
                                    it.baseUrl == settings.aiApiBaseUrl && it.model == settings.aiModel && row.price > 0 &&
                                    kotlin.math.abs(row.price - it.referencePrice) / it.referencePrice * 100.0 <= 0.5
                            }
                            val advice = if (cached != null) cached.advice else try {
                                val tfs = withTimeout(7_000L) {
                                    listOf("15m", "1h", "4h").mapNotNull { tf ->
                                        val bars = container.repository.futuresHistory(row.symbol, tf, limit = 50)
                                            .filter { it.closeTime < nowMillis() }
                                        if (bars.size >= 10) AiAnalysisClient.TfSlice(tf, bars) else null
                                    }
                                }
                                val primary = tfs.firstOrNull { it.timeframe == "1h" } ?: tfs.firstOrNull()
                                    ?: throw IllegalStateException("缺少足够的已收盘K线")
                                val ctx = AiAnalysisClient.MarketContext(
                                    symbol = row.symbol, timeframe = primary.timeframe, candles = primary.candles,
                                    multiTf = tfs, signal = row.dominantDir,
                                    confidence = ((row.netNss / maxNet.coerceAtLeast(1.0)) * 100.0).toInt().coerceIn(0, 100),
                                    shouldTrade = row.mtfGate && row.mtfDirection != 0, enginePlan = null,
                                    support = row.supportPrice, resistance = row.resistancePrice,
                                    patternName = row.regime, livePrice = row.price,
                                    userQuestion = "仅辅助扫描排行：分析已收盘的15m/1h/4h结构，严格返回指定JSON。不要把未收盘K线用于结论。",
                                )
                                val result = withTimeout(12_000L) {
                                    AiAnalysisClient.analyze(
                                        AiAnalysisClient.Config(settings.aiApiBaseUrl, settings.aiApiKey, settings.aiModel),
                                        ctx, AiAnalysisClient.fusionSystemPrompt(),
                                    )
                                }
                                if (!result.ok) throw IllegalStateException(result.error ?: "AI请求失败")
                                AiAnalysisClient.parseFusionAdvice(result.text)
                                    ?: throw IllegalStateException("AI结构化结果无法解析")
                            } catch (_: kotlinx.coroutines.TimeoutCancellationException) {
                                // A per-candidate AI/K-line deadline is a local fallback, not a scan cancellation.
                                null
                            } catch (cancelled: CancellationException) {
                                throw cancelled
                            } catch (_: Throwable) {
                                null
                            }
                            val decision = com.diveintocrypto.android.domain.scanner.AiFusionPolicy.evaluate(
                                localDirection = if (row.dominantDir.score > 0) 1 else if (row.dominantDir.score < 0) -1 else 0,
                                localPrice = row.price, atrPct = row.atrPct, advice = advice?.let {
                                    com.diveintocrypto.android.domain.scanner.AiFusionAdvice(
                                        direction = it.direction, confidence = it.confidence, fakeBreakoutRisk = it.fakeBreakoutRisk,
                                        entry = it.entry, stop = it.stop, target = it.target, riskRewardRatio = it.riskRewardRatio,
                                    )
                                },
                            )
                            val error = if (advice == null) "AI不可用或超时，保留本地基线" else null
                            row.symbol to Triple(decision, advice, error)
                        }
                    } }.awaitAll().forEach { (symbol, result) ->
                        evaluated[symbol] = result
                        val advice = result.second
                        if (advice != null) {
                            val row = candidates.firstOrNull { it.symbol == symbol }
                            if (row != null) aiFusionCache[symbol] = CachedAiFusion(
                                savedAtMs = now, advice = advice,
                                localDirection = if (row.dominantDir.score > 0) 1 else if (row.dominantDir.score < 0) -1 else 0,
                                referencePrice = row.price, baseUrl = settings.aiApiBaseUrl, model = settings.aiModel,
                            )
                        }
                    }
                }
            }
        } catch (_: kotlinx.coroutines.TimeoutCancellationException) {
            // Overall AI deadline: keep the original local ranking for every unevaluated row.
        } catch (e: CancellationException) {
            throw e
        } catch (_: Throwable) {
            // Provider failure: do not disrupt the regular scanner.
        }
        val adjusted = rows.map { row ->
            val item = evaluated[row.symbol]
            if (item == null) row.copy(aiFusionStatus = "本地排行（AI未返回/超时）", aiFusionReason = "未改变本地分数")
            else {
                val (decision, advice, error) = item
                row.copy(
                    aiRankDelta = decision.delta,
                    aiFusionStatus = if (error != null) "LOCAL_FALLBACK" else decision.status,
                    aiFusionReason = decision.reason,
                    aiFusionThesis = advice?.thesis,
                    aiSuggestedTimeframe = advice?.primaryTimeframe,
                    aiPlanAccepted = decision.acceptedPlan,
                    aiSuggestedEntry = advice?.entry?.takeIf { decision.acceptedPlan },
                    aiSuggestedStop = advice?.stop?.takeIf { decision.acceptedPlan },
                    aiSuggestedTarget = advice?.target?.takeIf { decision.acceptedPlan },
                )
            }
        }
        return adjusted.sortedByDescending { it.localRankScore + it.aiRankDelta }
    }

    /**
     * MICROSTRUCTURE overlay (domain/overlay/Microstructure.kt) for one survivor row.
     * Uses the 1h cadence for every series (klines are usually already in the engine's
     * candle cache from phase 2; the REST series are covered by its 30s caches).
     * DISPLAY-ONLY annotation: any fetch failure / insufficient data → null (no
     * annotation). Never enters score/elimination.
     */
    /** Confidence used in cards, alerts and evidence is discounted for missing/conflicting TFs. */
    fun confidenceFor(row: CrossRankingRow): Int {
        val dominant = lifecycleDirection(row.dominantDir)
        val directions = row.perTf.values.map { slot ->
            when (slot.signal) {
                Signal.BUY, Signal.STRONG_BUY -> 1
                Signal.SELL, Signal.STRONG_SELL -> -1
                Signal.NEUTRAL -> 0
            }
        }
        // Confidence must describe the dominant direction, not the strongest
        // indicator vote in the opposite direction. Otherwise a high-confidence
        // SELL timeframe could inflate the displayed confidence of a BUY-ranked row.
        val dominantConfidence = OpportunityConfidenceQuality.dominantBaseConfidence(
            row.perTf.values.map { slot ->
                val direction = when (slot.signal) {
                    Signal.BUY, Signal.STRONG_BUY -> 1
                    Signal.SELL, Signal.STRONG_SELL -> -1
                    Signal.NEUTRAL -> 0
                }
                direction to slot.confidence
            },
            dominant,
        )
        return OpportunityConfidenceQuality.adjust(
            baseConfidence = dominantConfidence,
            expectedTimeframes = ALL_TFS.size,
            observedDirections = directions,
            dominantDirection = dominant,
        ).adjustedConfidence
    }

    private fun lifecycleDirection(signal: Signal): Int = when (signal) {
        Signal.BUY, Signal.STRONG_BUY -> 1
        Signal.SELL, Signal.STRONG_SELL -> -1
        Signal.NEUTRAL -> 0
    }

    private suspend fun computeMicrostructure(symbol: String, gate: Semaphore): Microstructure.Result? = try {
        gate.withPermit {
            val candles = container.repository.futuresHistory(symbol, "1h", limit = 30)
            if (candles.size < 10) {
                null // Price history is the required primary input for the OI/price signals.
            } else {
                // Auxiliary endpoints fail independently. Preserve every source that did return
                // real data; Microstructure reports the resulting coverage instead of replacing
                // missing OI/funding/L-S data with zeros or dropping the entire overlay.
                suspend fun <T> fetchAuxiliary(fetch: suspend () -> List<T>): List<T> = try {
                    fetch()
                } catch (e: CancellationException) {
                    throw e
                } catch (_: Throwable) {
                    emptyList()
                }
                val oi = fetchAuxiliary { container.repository.openInterestHist(symbol, "1h", limit = 30) }
                val taker = fetchAuxiliary { container.repository.takerLongShortRatio(symbol, "1h", limit = 30) }
                val glob = fetchAuxiliary { container.repository.globalLongShortAccountRatio(symbol, "1h", limit = 30) }
                val pos = fetchAuxiliary { container.repository.topLongShortPositionRatio(symbol, "1h", limit = 30) }
                val funding = fetchAuxiliary { container.repository.fundingRate(symbol, limit = 30) }
                // Pair sources by their actual hourly buckets, not by taking equal-length tails.
                // REST endpoints can return different start times or omit a bucket; tail pairing
                // would silently compare observations from different hours.
                val oiPrice = TimestampSeriesAlignment.align(
                    left = oi.map { it.timestamp to it.sumOpenInterestValue },
                    right = candles.map { it.openTime to it.close },
                )
                val positionGlobal = TimestampSeriesAlignment.align(
                    left = pos.map { it.timestamp to it.longShortRatio },
                    right = glob.map { it.timestamp to it.longShortRatio },
                )
                Microstructure.evaluate(
                    Microstructure.Series(
                        oi = oiPrice.left,
                        price = oiPrice.right,
                        funding = funding.map { it.fundingRate },
                        taker = taker.map { it.buySellRatio },
                        glob = positionGlobal.right,
                        pos = positionGlobal.left,
                    )
                )
            }
        }
    } catch (e: CancellationException) {
        throw e
    } catch (_: Throwable) {
        null
    }

    /**
     * Computes a symbol's whale L/S bearish divergence across the 9 supported TFs.
     * For each TF, price (close) + whale L/S (topLongShortPositionRatio) are fetched,
     * aligned to equal length from the tail, and fed to [WhaleDivergence.perTf];
     * then reduced to a single score with [WhaleDivergence.forSymbol].
     * A network error / insufficient data silently zeroes that TF (graceful degrade).
     */
    /** @return (divergence result, usable TF count 0..9). Coverage=0 →
     *  no whale data could be fetched (throttle/none); a score of 0 here is DISTINCT from "clean". */
    private suspend fun computeDivergence(
        symbol: String,
        gate: Semaphore,
    ): Pair<WhaleDivergence.SymbolResult, Int> = coroutineScope {
        val perTf = DIVERGENCE_TFS.map { tf ->
            async {
                if (_ui.value.stopRequested) return@async null
                gate.withPermit {
                    val candles = try {
                        container.repository.futuresHistory(symbol, tf, limit = 200)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (_: Throwable) { emptyList() }
                    if (candles.size < 25) return@withPermit null
                    val ls = try {
                        container.repository.topLongShortPositionRatio(symbol, tf, limit = 200)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (_: Throwable) { emptyList() }
                    if (ls.size < 25) return@withPermit null

                    // Timestamped alignment (pure [DivergenceAlignment]): matches whale L/S to the
                    // price candle by period bucket, forward-filling gaps. (Tail alignment would
                    // shift a single dropped 1d L/S bar by a FULL DAY.)
                    val periodMs = PERIOD_MS[tf] ?: return@withPermit null
                    val aligned = DivergenceAlignment.align(
                        priceTimes = candles.map { it.openTime },
                        priceVals = candles.map { it.close },
                        lsTimes = ls.map { it.timestamp },
                        lsVals = ls.map { it.longShortRatio },
                        periodMs = periodMs,
                    )
                    if (aligned.price.size < 25) return@withPermit null
                    // If more than half of the aligned window is forward-filled (sparse/gappy L/S,
                    // e.g. a short 1d L/S history spread over a long price window) → the peak
                    // flattens artificially, causing silent under-detection → skip this TF.
                    if (aligned.matched < aligned.price.size / 2) return@withPermit null
                    tf to WhaleDivergence.perTf(aligned.price, aligned.whale, TIME_WEIGHTS[tf] ?: 50)
                }
            }
        }.awaitAll().filterNotNull().toMap()
        WhaleDivergence.forSymbol(perTf) to perTf.size
    }

    companion object {
        /** Phase 1 covers the high-time-weight timeframes that filter the universe fast. */
        val PHASE1_TFS: List<String> = ScannerRanking.PHASE1_TFS

        /** Phase 2 covers the rest — only run against phase-1 survivors. */
        val PHASE2_TFS: List<String> = ScannerRanking.PHASE2_TFS

        /** Display order is chronological (lowest TF to highest). */
        val ALL_TFS: List<String> = ScannerRanking.ALL_TFS

        /** Backwards-compat alias used by the UI's ScannerUiState default. */
        val DEFAULT_TFS: List<String> = ALL_TFS

        // ── Pure scan-logic helpers (unit-testable, no VM state) ─────────

        /**
         * ADAPTIVE CONCURRENCY: universes larger than 100 symbols bump the base
         * parallelism to at least 12 (phase-1 is latency-bound on 3×universe
         * kline fetches), hard-capped at [MAX_SCAN_PARALLELISM] to stay polite
         * to the venue's rate limits.
         */
        fun adaptiveParallelism(base: Int, universeSize: Int): Int {
            val effective = if (universeSize > 100) maxOf(base, 12) else base
            return effective.coerceIn(1, MAX_SCAN_PARALLELISM)
        }

        /** Hard cap on in-flight scan requests. */
        const val MAX_SCAN_PARALLELISM = 16

        /**
         * ETA estimator from rolling throughput (PURE): rate = completed/elapsed,
         * eta = remaining/rate. null while there is no rate yet (no completions,
         * zero elapsed) or nothing remains — the UI shows "—" rather than a fake 0.
         */
        fun estimateEtaSeconds(completed: Int, total: Int, elapsedMs: Long): Long? {
            if (completed <= 0 || total <= 0 || elapsedMs <= 0L || completed >= total) return null
            val elapsedSec = elapsedMs / 1000.0
            if (elapsedSec <= 0.0) return null
            val ratePerSec = completed / elapsedSec
            if (ratePerSec <= 0.0) return null
            return Math.ceil((total - completed) / ratePerSec).toLong()
        }

        /** Rows handed to the alert engine per scan cycle (bounded REST for OI rules). */
        const val ALERT_SCAN_LIMIT = 40

        /** Verdict records archived per scan cycle. */
        const val EVIDENCE_APPEND_LIMIT = 40

        /**
         * CANONICAL risk-from-TF-agreement mapping (identical to the private
         * `riskFromAgreement` in ScannerScreen — the UI agent should DELETE that
         * copy and delegate to this function):
         *   ≥ total-1 → LOW · ≥ total/2 → MEDIUM · > 0 → HIGH · else N/A
         */
        fun riskFromAgreement(countHit: Int, totalTfs: Int): String = when {
            countHit >= totalTfs - 1 -> "LOW"
            countHit >= totalTfs / 2 -> "MEDIUM"
            countHit > 0 -> "HIGH"
            else -> "N/A"
        }

        /** Is the whale divergence OPPOSITE the indicator direction? (adverse = will be eliminated)
         *  Indicator BUY but divergence bearish (distribution) → adverse; Indicator SELL but
         *  divergence bullish (accumulation) → adverse. Sub-threshold divergence or no
         *  direction → not adverse. */
        internal fun isAdverseRow(row: CrossRankingRow): Boolean {
            if (abs(row.divergenceScore) < DIVERGENCE_MIN_SHOWN) return false
            val dir = when (row.dominantDir) {
                Signal.BUY, Signal.STRONG_BUY -> 1
                Signal.SELL, Signal.STRONG_SELL -> -1
                else -> 0
            }
            if (dir == 0) return false
            return row.divergenceDirection == -dir
        }

        /** ELIMINATION + BACKFILL: partition ranked rows into (survivors, eliminated).
         *  Order-preserving; survivors feed the final table (backfill is implicit in
         *  the filter-then-take). Pure. */
        internal fun eliminateAdverse(rows: List<CrossRankingRow>): Pair<List<CrossRankingRow>, List<CrossRankingRow>> =
            rows.partition { !isAdverseRow(it) }

        /** Fills missing (non-top15) TF cells for a displayed row from the full results. Pure. */
        internal fun patchPerTfRow(
            row: CrossRankingRow,
            tfResults: Map<String, List<SymbolTfResult>>,
        ): CrossRankingRow {
            val patched = row.perTf.toMutableMap()
            for (tf in ALL_TFS) {
                if (tf in patched) continue
                val weight = TIME_WEIGHTS[tf] ?: 50
                val rr = tfResults[tf]?.firstOrNull { it.symbol.equals(row.symbol, ignoreCase = true) }
                if (rr != null) {
                    patched[tf] = TfSlotState(rr.signal, rr.confidence, weight, rr.finalScore, inTop15 = false)
                }
            }
            // Recompute descriptive accumulation summary from every successfully scanned TF,
            // including TF-fill scans and results outside the per-TF Top 15. Ranking fields
            // remain unchanged; this is display-only evidence aggregation.
            val accumulationItems = ALL_TFS.mapNotNull { tf ->
                tfResults[tf]
                    ?.firstOrNull { it.symbol.equals(row.symbol, ignoreCase = true) }
                    ?.let { MultiTimeframeAccumulation.TimeframeResult(tf, it.accumulation) }
            }
            return row.copy(
                perTf = patched.toMap(),
                accumulationSummary = MultiTimeframeAccumulation.summarize(accumulationItems),
            )
        }

        /**
         * CROSS-RANK: aggregate the per-TF top15 lists into one row per symbol,
         * sorted by net_nss desc, and annotate each row with its MTF-confluence
         * overlay (domain/overlay/MtfConfluence.kt — ADDITIVE display-only, it
         * never changes the ranking). Pure.
         */
        internal fun crossRankRows(
            tfTop15: Map<String, List<SymbolTfResult>>,
            allTfResults: Map<String, List<SymbolTfResult>> = tfTop15,
        ): List<CrossRankingRow> {
            data class Stats(
                var count: Int = 0,
                var buyNss: Double = 0.0,
                var sellNss: Double = 0.0,
                var bestConf: Int = 0,
                var price: Double = 0.0,
                var regime: String = "MIXED",
                // DISPLAY-ONLY: the best-confidence TF's ATR% + the 1h TF's ATR% (preferred
                // when present — spec hint). Only feeds the RISK advisor row.
                var atrPctBest: Double? = null,
                var atrPct1h: Double? = null,
                var marketDataOpenTimeMs: Long = 0L,
                var marketDataTimeframeMs: Long = 0L,
                val perTf: MutableMap<String, TfSlotState> = mutableMapOf(),
                val accumulationByTf: MutableMap<String, AccumulationDistributionAssessment.Result> = mutableMapOf(),
            )

            val symbolStats: MutableMap<String, Stats> = mutableMapOf()
            for (tf in ALL_TFS) {
                val weight = TIME_WEIGHTS[tf] ?: 50
                for (r in tfTop15[tf] ?: emptyList()) {
                    val s = symbolStats.getOrPut(r.symbol) { Stats() }
                    s.count += 1
                    when (r.signal) {
                        Signal.STRONG_BUY, Signal.BUY -> s.buyNss += r.finalScore
                        Signal.STRONG_SELL, Signal.SELL -> s.sellNss += r.finalScore
                        else -> Unit  // NEUTRAL contributes nothing
                    }
                    if (r.confidence > s.bestConf) {
                        s.bestConf = r.confidence
                        s.price = r.price
                        s.atrPctBest = r.atrPct
                        s.regime = r.regime
                        s.marketDataOpenTimeMs = r.latestCandleOpenTimeMs
                        s.marketDataTimeframeMs = r.timeframeMs
                    }
                    if (tf == "1h" && r.atrPct != null) s.atrPct1h = r.atrPct
                    s.accumulationByTf[tf] = r.accumulation
                    s.perTf[tf] = TfSlotState(
                        signal = r.signal,
                        confidence = r.confidence,
                        timeWeight = weight,
                        finalScore = r.finalScore,
                        inTop15 = true,
                    )
                }
            }

            val structureBySymbol = allTfResults.values.flatten().groupBy { it.symbol.lowercase() }
            return symbolStats.entries
                .map { (sym, s) ->
                    val (dominantDir, netNss) = if (s.buyNss >= s.sellNss) {
                        Signal.BUY to (s.buyNss - s.sellNss)
                    } else {
                        Signal.SELL to (s.sellNss - s.buyNss)
                    }
                    val row = CrossRankingRow(
                        symbol = sym,
                        dominantDir = dominantDir,
                        netNss = netNss,
                        countHit = s.count,
                        totalTfs = ALL_TFS.size,
                        perTf = s.perTf.toMap(),
                        price = s.price,
                        // Prefer 1h ATR% when present (spec hint); otherwise best-confidence TF ATR%.
                        atrPct = s.atrPct1h ?: s.atrPctBest,
                        supportPrice = structureBySymbol[sym.lowercase()].orEmpty()
                            .mapNotNull { it.supportPrice }.filter { it < s.price }.maxOrNull(),
                        resistancePrice = structureBySymbol[sym.lowercase()].orEmpty()
                            .mapNotNull { it.resistancePrice }.filter { it > s.price }.minOrNull(),
                        marketDataOpenTimeMs = s.marketDataOpenTimeMs.takeIf { it > 0L },
                        marketDataTimeframeMs = s.marketDataTimeframeMs.takeIf { it > 0L },
                        // REGIME overlay annotation (label from the best-confidence TF).
                        regime = s.regime,
                        accumulationSummary = MultiTimeframeAccumulation.summarize(
                            ALL_TFS.mapNotNull { tf ->
                                allTfResults[tf]
                                    ?.firstOrNull { it.symbol.equals(sym, ignoreCase = true) }
                                    ?.let { MultiTimeframeAccumulation.TimeframeResult(tf, it.accumulation) }
                            }
                        ),
                    )
                    // MTF-CONFLUENCE overlay annotation: agreement score across this symbol's
                    // per-TF verdicts (higher TFs weigh more). ADDITIVE — does not re-rank.
                    val verdicts = ALL_TFS.mapNotNull { tf ->
                        s.perTf[tf]?.let { MtfConfluence.TfVerdict(tf, it.signal.name, it.confidence) }
                    }
                    val mtf = MtfConfluence.confluence(verdicts)
                    row.copy(
                        mtfScore = mtf.score,
                        mtfDirection = mtf.direction,
                        mtfGate = mtf.gate,
                        mtfLabel = mtf.label,
                    )
                }
                .sortedByDescending { it.netNss }
        }

        /**
         * Verbatim from bot_service.py:106-110 (`self._ZAK`).
         * Higher timeframe = higher weight, mirroring the trader-intuition that
         * a 1d-confirmed signal should outweigh a 1m one.
         */
        val TIME_WEIGHTS: Map<String, Int> = ScannerRanking.TIME_WEIGHTS

        // ── Whale L/S divergence (Bearish Whale Divergence) ──────────────
        /** Binance futures-data endpoints only support these 9 periods (no 1m, 3m, 8h).
         *  Divergence is computed only on these TFs; the others are 0. */
        val DIVERGENCE_TFS: List<String> = listOf(
            "5m", "15m", "30m", "1h", "2h", "4h", "6h", "12h", "1d",
        )
        /** Divergence is computed only for the top netNss candidates (rate-limit). This pool is
         *  ALSO the upper bound on all visible/eliminable coins (rankedRows = candidates),
         *  so it must comfortably cover the largest table size (20) + the elimination/backfill margin. */
        const val DIVERGENCE_CANDIDATES = 40
        /** Weight of divergence in the table ranking (0..1). Blended with netNss. */
        const val DIVERGENCE_RANK_WEIGHT = 0.35
        /** Divergence scores below this threshold are treated as "none" (noise filter). */
        const val DIVERGENCE_MIN_SHOWN = 5.0

        /** Microstructure overlay annotations are computed for at most this many
         *  survivor rows per scan (bounds the extra REST calls; display-only). */
        const val MICRO_ANNOTATION_LIMIT = 24
        /** TF → period duration (ms). Used to align the price and whale-L/S series by timestamp
         *  (tail alignment would turn a single dropped bar at 1d into a full-day shift). */
        val PERIOD_MS: Map<String, Long> = ScannerRanking.PERIOD_MS
    }
}

/** A single (symbol, TF) analysis result. */
data class SymbolTfResult(
    val symbol: String,
    val tf: String,
    val signal: Signal,
    val confidence: Int,
    val price: Double,
    val timeWeight: Int,
    val finalScore: Double,
    /** ATR(14) as a price-% from the indicator layer (`atr_filter` rawValue `atr_pct`).
     *  DISPLAY-ONLY: only feeds the RISK advisor row — it does NOT affect score/elimination/
     *  ranking (finalScore is confidence²×timeWeight; this field never enters that). */
    val atrPct: Double? = null,
    /** Nearest confirmed swing low below price; display/risk-planning only. */
    val supportPrice: Double? = null,
    /** Nearest confirmed swing high above price; display/risk-planning only. */
    val resistancePrice: Double? = null,
    /** REGIME overlay label (TREND / RANGE / MIXED) from domain/consensus/Regime.kt,
     *  detected from the already-computed ADX + Choppiness raws of this (symbol, TF).
     *  DISPLAY-ONLY annotation — never enters score/elimination/ranking. */
    val regime: String = "MIXED",
    /** OHLCV-derived accumulation/distribution evidence; descriptive only. */
    val accumulation: AccumulationDistributionAssessment.Result = AccumulationDistributionAssessment.assess(
        AccumulationDistributionAssessment.Input(emptyList(), emptyList(), emptyList(), emptyList())
    ),
    /** Exchange-provided candle open timestamp and timeframe for freshness checks. */
    val latestCandleOpenTimeMs: Long = 0L,
    val timeframeMs: Long = 0L,
)

/** A row in the scanner feed/hot list (style.css:661-688). */
data class ScannerFeedItem(
    val symbol: String,
    val rank: Int,
    val signal: Signal,
    val confidence: Int,
    val price: Double,
    val riskLevel: String,
    val error: String?,
)

/** Per-TF state inside one cross-ranking row. */
data class TfSlotState(
    val signal: Signal,
    val confidence: Int,
    val timeWeight: Int = 50,
    val finalScore: Double = 0.0,
    val inTop15: Boolean = false,
)

/** A row in the cross-timeframe ranking (style.css:976-1047). */
data class CrossRankingRow(
    val symbol: String,
    val dominantDir: Signal,
    val netNss: Double,
    val countHit: Int,
    val totalTfs: Int,
    val perTf: Map<String, TfSlotState>,
    val price: Double,
    /** Timestamp of the candle used for the selected reference price. */
    val marketDataOpenTimeMs: Long? = null,
    val marketDataTimeframeMs: Long? = null,
    /** ATR(14) price-% (from the indicator layer, 1h preferred). DISPLAY-ONLY: only feeds
     *  the RISK advisor row; it never enters score/elimination/ranking. null = no data. */
    val atrPct: Double? = null,
    /** Nearest confirmed swing low below the reference price; display-only. */
    val supportPrice: Double? = null,
    /** Nearest confirmed swing high above the reference price; display-only. */
    val resistancePrice: Double? = null,
    /** Whale L/S bearish divergence interest score (0..100). 0 = none. */
    val divergenceScore: Double = 0.0,
    /** The strongest timeframe that produced the divergence (e.g. "1d"), or null. */
    val divergenceTf: String? = null,
    /** Price rise ratio at the strongest TF (0..1). Shown in the UI as "价格 +X%". */
    val divergenceRisePct: Double = 0.0,
    /** Raw whale drop ratio at the strongest TF (0..1). Shown in the UI as "鲸鱼 −Y%". */
    val divergenceWhaleDrop: Double = 0.0,
    /** Number of usable whale-L/S TFs: -1 = was not a candidate, 0 = no data, 1..9. */
    val divergenceCoverage: Int = -1,
    /** Divergence PREDICTIVE/RANKING direction: -1 expect down, +1 expect up, 0 none. */
    val divergenceDirection: Int = 0,
    /** Divergence DESCRIPTIVE raw whale movement: -1 distribution (sell), +1 accumulation (buy), 0 none.
     *  The label/color/arrow is driven by this (NOT sign(score)); independent of the contrarian flip. */
    val divergencePatternDirection: Int = 0,

    // ── STRATEGY OVERLAY ANNOTATIONS (README's "3 overlays", now wired). ──────────
    // All three are ADDITIVE display-only fields computed alongside the scan;
    // none of them touches the parity-locked vote / ranking / elimination.

    /** [Regime] label for this symbol's best-confidence TF: TREND / RANGE / MIXED. */
    val regime: String = "MIXED",
    /** Cross-timeframe accumulation/distribution consistency; informational only. */
    val accumulationSummary: MultiTimeframeAccumulation.Summary = MultiTimeframeAccumulation.summarize(emptyList()),
    /** [MtfConfluence] agreement score across the symbol's per-TF verdicts, −100..+100. */
    val mtfScore: Double = 0.0,
    /** [MtfConfluence] dominant direction: +1 bull, −1 bear, 0 none. */
    val mtfDirection: Int = 0,
    /** [MtfConfluence] gate: the higher-TF (≥1h) stack agrees with the dominant direction. */
    val mtfGate: Boolean = false,
    /** [MtfConfluence] strength label: STRONG / WEAK / NEUTRAL. */
    val mtfLabel: String = "NEUTRAL",
    /** [Microstructure] bundle score, −100..+100 (bullish +/bearish −). null = not
     *  computed (beyond the annotated head) or the series fetch failed. */
    val microScore: Double? = null,
    /** [Microstructure] direction: +1 bull, −1 bear, 0 none. null = not computed. */
    val microDirection: Int? = null,
    /** [Microstructure] label: STRONG_BUY / BUY / NEUTRAL / SELL / STRONG_SELL / NEUTRAL.
     *  null = not computed. */
    val microLabel: String? = null,
    /** [Microstructure] number of signals with enough real data to calculate (neutral signals count).
     *  null = not computed. */
    val microActive: Int? = null,
    /** Share of the six defined microstructure signals supported by available real data. */
    val microCoveragePercent: Int? = null,
    /** Scan-to-scan lifecycle annotation; informational only, never changes score. */
    val lifecycleStatus: String = "NEW",
    val lifecycleLabel: String = "新机会",
    val lifecycleNote: String = "本轮扫描首次出现；等待后续周期确认",
    /** Immutable local ranking baseline before any optional AI nudge. */
    val localRankScore: Double = 0.0,
    /** Bounded AI ranking adjustment; never alters the local direction. */
    val aiRankDelta: Double = 0.0,
    val aiFusionStatus: String = "AI融合关闭",
    val aiFusionReason: String? = null,
    val aiFusionThesis: String? = null,
    val aiSuggestedTimeframe: String? = null,
    val aiPlanAccepted: Boolean = false,
    val aiSuggestedEntry: Double? = null,
    val aiSuggestedStop: Double? = null,
    val aiSuggestedTarget: Double? = null,
)

/** Coarse status for the progress UI. */
enum class ScanPhase { IDLE, UNIVERSE, PHASE1, PHASE2, FINALIZING }

data class ScannerUiState(
    val timeframes: List<String> = ScannerViewModel.DEFAULT_TFS,
    val activeTimeframe: String = "15m",
    /** App-ranked feed of the visible survivors (same content the table shows). */
    val hotList: List<ScannerFeedItem> = emptyList(),
    val crossRanking: List<CrossRankingRow> = emptyList(),
    /** Survivors after elimination (coins with adverse whale divergence were removed, backfilled). */
    val survivors: List<CrossRankingRow> = emptyList(),
    /** Coins eliminated because their whale divergence ran opposite the indicator. */
    val eliminated: List<CrossRankingRow> = emptyList(),
    /** Scan-to-scan lifecycle counts for the last completed run. */
    val lifecycleSummary: String = "等待首次扫描完成",
    /** Whether CONTINUOUS (back-to-back) scanning is on. */
    val continuous: Boolean = false,
    /** Table size: number of survivors to show (5/10/15/20 or Int.MAX_VALUE=All). */
    val displaySize: Int = 20,
    /** OPT-IN presentation lens: when ON, the visible survivors are sorted by |divergenceScore| desc
     *  (sub-threshold rows kept at the bottom in default order). OFF (default) =
     *  today's netNss + 0.35×div ordering. PRESENTATION only; score/elimination are UNCHANGED. */
    val divergenceSort: Boolean = false,
    /** Number of completed scan cycles (continuous mode). */
    val cycle: Int = 0,
    val scanning: Boolean = false,
    val stopRequested: Boolean = false,
    val currentSymbol: String? = null,
    val currentPhase: ScanPhase = ScanPhase.IDLE,
    val completedCount: Int = 0,
    val totalCount: Int = 0,
    /**
     * HONESTY: number of DISTINCT symbols whose kline fetch FAILED during the current
     * scan (network errors were previously swallowed silently). The UI can render
     * "N sembol taranamadı" from this. Reset per scan.
     */
    val failedCount: Int = 0,
    /** Failure causes across timeframe requests; shown to users to distinguish network errors from bad/stale candles. */
    val failureReasonCounts: Map<String, Int> = emptyMap(),
    /** Universe size (full Binance USDT-M futures set after stablecoin filter). */
    val universeSize: Int = 0,
    /** FULL-UNIVERSE MODE label for this scan: TOP20/TOP50/TOP100/TOP250/ALL. */
    val universeMode: String = "TOP50",
    /** HONEST ETA from rolling scan throughput; null = not enough samples yet. */
    val etaSeconds: Long? = null,
    val universeLoading: Boolean = false,
    val lastScanAtMs: Long? = null,
    val error: String? = null,
)
