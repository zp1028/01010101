MACD: standard EMA 12/26/9 continuous; analysis strip draws DIF+DEA+hist
