# 彩析 v2.4.4 P0 渲染层失效自愈（黑屏自动恢复）

## 🛠 修复内容

### 1. 下注后黑屏：不再依赖手动切页，自动探测并自愈
- **背景**：v2.4.3 修复弹窗线程问题后，仍偶发"下注成功提示后黑屏，切走其他导航页再回来就好"——此现象本质是 WebView 渲染层失效（DOM 活着、心跳正常，但 WebView 不再绘制）。
- **根因链条**：`WebBetScreen` 是导航栈页面，切换 Tab 时 AndroidView 将 WebView **detach**，离开时仅 `saveState()`（无 stopLoading/pauseTimers/destroy）；切回时 factory **new 全新 WebView** + restoreState 恢复——所以"切页恢复"其实是"丢弃坏实例重建"，并非窗口修复；且每次黑屏切换都泄漏一个 WebView。现有 `onRenderProcessGone` 只覆盖"渲染进程被杀"，普通渲染停滞无自愈。
- **修复**（`WebViewExecutor.kt` + `WebBetScreen.kt`）：
  - `WebViewExecutor.watchRendering(wv)`：注册 `ViewTreeObserver.OnDrawListener`，持续回报 `lastPaintedMs`，绘制恢复即清零停滞计数。
  - `WebViewExecutor.probeRender(wv)`：每轮 keep-alive（15s）后主动 `invalidate()` 请求重绘，1.5s 窗口内未收到 onDraw 回报则停滞计数 +1（区分"DOM 活"与"渲染活"）。
  - `WebViewExecutor.isRenderStalled()`：连续 2 轮无绘制回报 → 判定渲染层失效（黑屏）。
  - `WebViewExecutor.selfHeal(wv)`：主线程 `reattach + reload + heartbeat`，20s 冷却防 reload 风暴。
  - `WebBetScreen` keep-alive 循环接入：心跳正常才进入渲染探针与自愈判定，不干扰执行器可用性判定。
  - `onCreateWindow` 新建的窗口 WebView 也接管 JS 弹窗（alert/confirm/prompt/beforeunload 自动应答），杜绝新窗口弹窗卡死。

### 2. VMOS 安装启动 Room 迁移报错：bot_config 未处理"Migration didn't properly handle"
- **根因**：新库安装时 Room 直接创建版本 15（bot_config 表缺少若干列），导致应用启动时 Room 校验 bot_config 实体与库表结构不一致，抛出 `Migration didn't properly handle` 崩溃。
- **修复**（`CaiDatabase.kt`）：修改 `MIGRATION_14_15` 以 `ensureBotConfigColumns(db)` + `ensureWalletColumns(db)` + `ensureBetsColumns(db)` 兜底补齐 bot_config/wallet/bets 可能缺失的列，确保升级到版本 15 后表结构与实体定义一致。

### 3. 半透明暗屏卡死：站点 DOM modal 遮罩层残留
- **现象**：点击确认下注后页面变暗（半透明黑色覆盖层），点击无反应，无关闭按钮，切页回来恢复——实际并非渲染停滞，而是站点弹出的 DOM modal 遮罩层残留未关。
- **根因**：站点使用 div overlay 做模态弹窗（非浏览器原生 alert/confirm），下注结果弹窗内容未加载或异步关闭失败时，遮罩层留在页面上拦截所有触摸事件，表现为"半透明暗屏卡死"。
- **修复**（`cfx_inject.js`）：
  - 新增 `__cfxClearModalOverlay()`：扫描页面上同时满足以下特征的 DOM 元素 → 定位固定/绝对定位、覆盖屏幕 70% 以上、半透明黑色背景（rgba 透明度 0.3-1.0）、z-index>10、子元素极少（≤3）——即残留的 modal 遮罩层。
  - Phase3 确认下注后**立即执行** `__cfxClearModalOverlay()` 清理，返回报告中追加清除数量。
  - **延迟二次清理**：`setTimeout 900ms` 后再次扫描，处理站点异步弹出的延迟遮罩层。
  - 清理方式：设置 `display:none; visibility:hidden; pointer-events:none`，**隐藏而非删除**，避免破坏页面结构。

### 4. 附带说明
- 金额×10 相关修复保持 v2.4.3 逻辑不变（去清空 + Phase2.5 复核 + 确认前校验）。
- 版本号保持 VERSION_CODE 39，VERSION_NAME 2.4.4。

## 📦 技术说明
- 编译验证：`./gradlew :app:compileDebugKotlin` 通过（Gradle 8.9 / AGP 8.5.2），仅余既有 deprecation 警告。
- 真机表现需实测：黑屏自动恢复（约 15s 周期探测，最坏 30s 内自动 reload）；遮罩层清理在每次确认下注后自动执行。

---

# 彩析 v2.4.3 WebView 交互修复（二轮：金额×10 偶发 与 弹窗黑屏卡死）

## 🛠 修复内容

### 1. 金额输入偶发 ×10（如 1 输入成 10）
- **根因**：`__cfxSetInputValue` 旧实现先执行 `el.value=''` 清空再写入目标金额，触发站点联动校验 → 对空值做 NaN 兜底，把输入框重置为「默认档位」金额（如 1 → 10、10 → 100）；随后回读校验虽检测到不一致但只重写一次，若站点第二次联动又把值改回默认档位，则最终落单金额错误。
- **修复**（`cfx_inject.js`）：
  - `__cfxSetInputValue` **去掉 `el.value=''` 清空动作**，直接 focus + 原生 setter 写入目标金额，避免触发 NaN 兜底路径；保留 input/change 事件派发与同步回读校验（不一致重写一次）。
  - 新增 `__cfxPhase2Verify(CMD)`：Phase2 写入后延时 300ms 复核页面金额，被站点改写则重设，返回 `{ok, actual, message}`。
  - `__cfxPhase2Amount` 金额框定位增强：纳入 `label[for]`、父容器 innerText、`aria-label`；排除词扩展「倍投/翻倍/追号/期号」，杜绝命中倍数/注数框。
  - `__cfxInputAmount` 新增 `noClick` 参数：筹码模式只定位不重复点击，避免 Phase3 复核时重复触发筹码。
  - `__cfxPhase3Confirm` 点击确认前强制金额校验：若页面金额 ≠ 目标金额则**阻止确认**并返回 `blocked`，从源头杜绝错误金额落单（宁可不下单，不错下单）。
- **Kotlin 侧**（`WebViewBetExecutor.kt`）：执行链插入 Phase2.5 金额复核（Phase2 后 400ms），复核失败即中止后续流程并报错，不再带着错误金额继续点确认。
- `SiteAdapter` 接口新增 `buildPhase2VerifyScript`（默认委托 Phase2），`GenericSiteAdapter` 实现金额复核脚本；`buildPhase3Script` 增传 `amount`/`selector_amount` 供确认前校验使用。

### 2. 下注成功后弹窗提醒黑屏卡死，需刷新重进
- **根因**（`WebBetScreen.kt`）：
  - v2.4.2 已经在 `onJsAlert/onJsConfirm` 回调里接管弹窗，但 **Toast 直接在 WebKit 回调线程调用**（非主线程）→ 抛异常 → `confirm()`/`cancel()` 未执行 → 站点挂起等待 → 页面黑屏；点击「确定下注」只是表面触发点，真正挂死的是被阻塞的 JS 弹窗。
  - 站点下注成功常触发 `beforeunload` 拦截提醒，v2.4.2 未接管 `onJsBeforeUnload` → 确认框永远不消失 → 黑屏。
  - `onRenderProcessGone` 仅 reload 页面，渲染进程崩溃后恢复不可靠。
- **修复**：
  - 所有 JS 弹窗回调（`onJsAlert/onJsConfirm/onJsPrompt`）的 Toast 切到 **`mappingHandler.post` 主线程**执行并 try-catch，回调立即 `confirm()/cancel()` 应答，弹窗不再阻塞渲染。
  - 新增 **`onJsBeforeUnload` 接管**：自动 `confirm()`（允许离开），消除下注成功后的「离开页面」拦截挂死。
  - `onRenderProcessGone` 增强：WebView 失效自动 reattach 重建 + reload + 恢复心跳，崩溃不再冷启动。
- **说明**：v2.4.2 已确认页面本身是完整网页（非"没做成真网站"），黑屏是 WebView 弹窗回调线程问题，本轮彻底修掉线程与 beforeunload 两个挂死点。

## 📦 技术说明
- 编译验证：`./gradlew :app:compileDebugKotlin` 通过（Gradle 8.9 / AGP 8.5.2），JS 注入脚本 `node --check` 语法通过。
- 版本号升级：VERSION_CODE 37 → 38，VERSION_NAME 2.4.2 → 2.4.3。

---

# 彩析 v2.4.2 WebView 交互修复（网页四修）

## 🛠 修复内容

### 1. 点击"确定下注"弹窗卡黑屏
- **根因**：WebView 未实现 `onJsAlert`/`onJsConfirm`/`onJsPrompt`，站点 JS 弹窗阻塞渲染线程导致黑屏；WebView 设置不完整导致页面显示残缺。
- **修复**：
  - `WebChromeClient` 接管 JS 弹窗：alert/confirm 自动确认并在界面上以 Toast 展示弹窗内容，prompt 直接取消返回空串，弹窗不再卡黑屏。
  - 补齐 WebView 设置：mixedContent ALWAYS_ALLOW、新窗口（`javaScriptCanOpenWindowsAutomatically`）、缩放（setSupportZoom + builtInZoomControls + textZoom）、图片加载、`onCreateWindow` 将 target=_blank 转回主 WebView 页内打开。
  - WebViewClient 补 `shouldOverrideUrlLoading`（留页内）、`onRenderProcessGone`（渲染进程崩溃自动重建恢复）。

### 2. 金额输入错误（10 会输入成 100）
- **根因**：金额框定位弱匹配命中倍数/注数框，且注入后无回读校验，站点联动逻辑改写了输入值。
- **修复**（`cfx_inject.js`）：
  - `__cfxInputAmount` 强权重定位：金额词 +50/+25、倍数/注数/搜索类强排除 -80、type=number 加分，bestSc=0 阈值兜底。
  - `__cfxSetInputValue` 改为 focus + scrollIntoView + 原生 setter 写入，写入后**回读校验**，不一致则重写一次，最终返回页面真实值。
  - 结果 message 形如"已填金额10（页面显示为10）"，便于确认无 ×10 偏差。

### 3. 确定下注后重复弹出"确定"弹窗
- **根因**：`__cfxConfirmLoop` 无条件循环 4 轮点击"确认"，无完成判定、无去重。
- **修复**：重构 `__cfxConfirmLoop`——指纹去重（同一确认框不重复点）、点击后等待 900ms 检测"投注成功/下单成功/余额不足/下单失败"等 14+10 个完成/阻断文案即提前结束、按钮未变化即结束、已点过的 selector 不再点；返回真实点击次数。

### 4. WebView 容易断开连接，改为长驻
- **根因**：`checkHeartbeat` 120s 无回调即判死，`heartbeat()` 仅在 `onPageFinished` 触发一次，长驻页面 120s 后必断连。
- **修复**：
  - `HEARTBEAT_TIMEOUT_MS` 提升到 300s（5 分钟兜底）。
  - 新增 `WebViewExecutor.keepAlive(webView)`：周期性 `evaluateJavascript(document.readyState)` 真实探测，确认存活才刷新心跳。
  - `WebBetScreen` 新增 `LaunchedEffect` 每 15s 调用 keepAlive，WebView 不可用时自动 reattach 重建。
  - `WebViewBetExecutor.execute` 入口 synchronized 防重入（同命令并发时返回 DUPLICATE_COMMAND），避免重复提交命令。

## 📦 技术说明
- 编译验证：`./gradlew :app:compileDebugKotlin` 通过（Gradle 8.9 / AGP 8.5.2 / JDK 21）。
- 版本号升级：VERSION_CODE 36 → 37，VERSION_NAME 2.4.1 → 2.4.2。

---

# 彩析 v2.4.0-AI 更新日志

## 🧠 AI 大模型视觉执行（核心功能）

### 新增功能
- **AI 视觉执行器**：基于多模态 LLM 的页面理解与自动化执行
- **三种 LLM 提供商支持**：
  - OpenAI (GPT-4o / GPT-4o-mini)
  - Anthropic (Claude 3.5 Sonnet)
  - Google (Gemini 1.5 Pro / Flash)
- **智能执行模式**：AI 视觉 → WebView → 无障碍，自动降级
- **执行后校验**：截图二次确认，失败自动重试
- **AI 设置页面**：完整的 LLM 配置、测试、保存界面

### 技术架构
```
BetCommand → ExecutorManager → [AI Vision] → [WebView] → [Accessibility]
                ↓
         PerceptionEngine (截图 + Accessibility节点树)
                ↓
         LlmClient (多模态API调用)
                ↓
         AiVisionExecutor (手势执行 + 结果校验)
```

### 新增文件
| 文件 | 路径 | 说明 |
|------|------|------|
| AiVisionExecutor.kt | domain/execution/ | AI视觉执行器核心 |
| LlmClient.kt | domain/execution/ | LLM API客户端 |
| PerceptionEngine.kt | domain/execution/ | 截图+节点树提取 |
| AiPromptBuilder.kt | domain/execution/ | 多模态Prompt构建 |
| ActionParser.kt | domain/execution/ | LLM响应解析 |
| LlmConfigStore.kt | data/config/ | LLM配置本地存储 |
| AiSettingsScreen.kt | ui/screens/ | AI设置UI界面 |
| AiSettingsActivity.kt | ui/screens/ | AI设置Activity |

### 修改文件
| 文件 | 修改内容 |
|------|---------|
| accessibility_service_config.xml | 添加 canTakeScreenshot="true" |
| ExecutorManager.kt | 添加 ai_vision 优先级 |
| CaiFenXiApplication.kt | 注册AI执行器 |
| build.gradle.kts | 添加 kotlinx-datetime依赖，版本号2.4.0-AI |
| AndroidManifest.xml | 添加 AiSettingsActivity |
| MoreScreen.kt | 添加AI设置入口 |
| CaiFenXiApp.kt | 添加 ai_settings 路由 |
| SettingsScreen.kt | 添加AI设置导航 |
| README.md | 更新AI功能说明 |

### 使用说明
1. 打开「更多 → 🧠 AI 大模型设置」
2. 选择提供商并输入API Key
3. 选择模型（推荐GPT-4o-mini降低成本）
4. 选择执行模式（自动/仅AI/仅网页/仅无障碍）
5. 点击「测试连接」验证
6. 保存配置即可使用

### 成本参考
| 模型 | 单次投注 | 月费用(1000次) |
|------|---------|---------------|
| GPT-4o-mini | ~¥0.03 | ~¥30 |
| GPT-4o | ~¥0.15 | ~¥150 |
| Claude 3.5 | ~¥0.50 | ~¥500 |

### 注意事项
- AI模式需要设备联网
- 需要开启无障碍服务（用于截图和手势执行）
- Android 11+ 支持原生截图，低版本需MediaProjection授权
- API Key 请妥善保管，建议使用环境变量或加密存储

---

## 兼容性
- 最低 Android 7.0 (API 24)
- 编译 SDK 35
- Kotlin 2.0.20
- Jetpack Compose 2024.09

AI Agent V2 completed: 2026-09-05
