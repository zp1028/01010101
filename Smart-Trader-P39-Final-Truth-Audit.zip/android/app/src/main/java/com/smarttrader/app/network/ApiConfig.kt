package com.smarttrader.app.network

import android.content.Context

/**
 * Runtime backend endpoint. The value comes from deployment configuration or the
 * user's saved setting; it is intentionally not tied to an emulator address.
 */
object ApiConfig {
    private const val PREFS = "smart_trader_api"
    private const val KEY_BASE_URL = "base_url"
    private val buildConfiguredUrl: String = BuildConfig.SMART_TRADER_BACKEND_URL.trimEnd('/')
    private var configuredUrl: String = buildConfiguredUrl

    val baseUrl: String
        get() = configuredUrl

    fun init(context: Context) {
        configuredUrl = context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_BASE_URL, buildConfiguredUrl)
            ?.trim()
            ?.trimEnd('/')
            ?.ifBlank { buildConfiguredUrl }
            ?: buildConfiguredUrl
    }

    fun setBaseUrl(value: String): Boolean {
        val normalized = value.trim().trimEnd('/')
        if (!(normalized.startsWith("http://") || normalized.startsWith("https://"))) return false
        configuredUrl = normalized
        return true
    }

    fun save(context: Context) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_BASE_URL, configuredUrl).apply()
    }

    val wsUrl: String
        get() {
            val http = baseUrl.trimEnd('/')
            return when {
                http.startsWith("https://") ->
                    "wss://" + http.removePrefix("https://") + "/api/v1/ws/market"
                else ->
                    "ws://" + http.removePrefix("http://") + "/api/v1/ws/market"
            }
        }

    val healthUrl: String get() = baseUrl.trimEnd('/') + "/health"
}
