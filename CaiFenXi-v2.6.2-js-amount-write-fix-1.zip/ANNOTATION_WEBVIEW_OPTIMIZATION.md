# 标注功能 & WebView 性能优化

## 标注（MAPPING）优化
1. **更稳的 selector 生成**
   - 过滤 hash / css-module / emotion / ng- 等动态 class
   - 扩展 data-* 属性优先级（data-bet / data-num 等）
   - 短文本 + 父级锚定策略
   - 路径深度从 10 降到 6，减少脆弱长链
2. **幂等注入**
   - `__CFX_MAPPING_BOUND` 防止重复绑定监听器导致卡顿
   - `onPageStarted` 导航时重置 BOUND，保证 SPA 重注正确
3. **更准的可点击识别**
   - 支持 span/div + data-play/data-value + cursor:pointer
   - 减少点到外层容器导致的错误标注

## WebView 性能优化
1. **渲染**
   - `RenderPriority.HIGH`
   - `offscreenPreRaster = true`
   - 关闭 SafeBrowsing（减少后台扫描）
2. **远程调试**
   - 仅 debuggable 包开启，正式包关闭，降低常驻开销
3. **CORS 代理**
   - 全局共享 OkHttp 连接池，避免每个 WebView 新建客户端
   - 合理超时（connect 12s / read 15s）
4. **SPA 就绪探测**
   - 首次探测 6s → 2.5s
   - 后续间隔缩短（3~3.5s），更快进入可标注/可挂机状态
5. **网络拦截**
   - API 相关 XHR/fetch 拦截已移除，减少页面请求开销

## 使用建议
- 标注时优先点按钮本体（有文字的那个节点）
- 若 selector 过长（含多层 >），可重新标注同一按钮尝试更稳结果
- 换站或清缓存后重新走一遍标注流程
