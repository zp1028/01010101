package com.caifenxi.app.service

import android.os.Handler
import android.os.Looper
import android.webkit.WebSettings
import android.webkit.WebView
import com.caifenxi.app.domain.execution.BetAction
import com.caifenxi.app.domain.execution.BetCommand
import com.caifenxi.app.domain.execution.ExecutionResult
import com.caifenxi.app.domain.execution.ExecutionTicketStore
import com.caifenxi.app.domain.execution.GenericSiteAdapter
import com.caifenxi.app.domain.execution.SiteAdapter
import com.caifenxi.app.util.RuntimeLog

/**
 * WebView DOM 执行器：注入通用评分脚本，识别真正的大小单双并点击。
 */
class WebViewBetExecutor {

    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile
    private var webView: WebView? = null

    /** 正在执行的 cmdId，防止同一指令被重复触发（重复点确定/重复下注） */
    @Volatile
    private var runningCmdId: String? = null

    @Volatile
    var siteAdapter: SiteAdapter = GenericSiteAdapter

    val isAvailable: Boolean
        get() = webView != null

    fun attachWebView(webView: WebView) {
        initWebView(webView)
    }

    fun initWebView(webView: WebView) {
        // 始终更新引用，防止 Compose 重组后旧引用失效
        this.webView = webView
        mainHandler.post {
            try {
                val s = webView.settings
                s.javaScriptEnabled = true
                s.domStorageEnabled = true
                s.databaseEnabled = true
                s.useWideViewPort = true
                s.loadWithOverviewMode = true
                s.cacheMode = WebSettings.LOAD_CACHE_ELSE_NETWORK
                s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                // v2.6.2-fix(v47): API 29+ 彻底放开 WebView 限制，包括图片、本地文件、跨域资源
                s.loadsImagesAutomatically = true
                s.allowFileAccess = true
                s.allowContentAccess = true
                s.allowUniversalAccessFromFileURLs = true
                s.javaScriptCanOpenWindowsAutomatically = true
                s.setSupportMultipleWindows(false)
                s.mediaPlaybackRequiresUserGesture = false
                try { @Suppress("DEPRECATION") s.setRenderPriority(WebSettings.RenderPriority.HIGH) } catch (_: Exception) {}
                try { s.setSafeBrowsingEnabled(false) } catch (_: Exception) {}
                try { s.offscreenPreRaster = true } catch (_: Exception) {}
                // v2.6.3fix: 确保Cookie立即同步，避免跨域请求时token未生效
                try {
                    val cm = android.webkit.CookieManager.getInstance()
                    cm.setAcceptCookie(true)
                    cm.setAcceptThirdPartyCookies(webView, true)
                    cm.flush()
                } catch (_: Exception) {
                }
                val ua = s.userAgentString ?: ""
                if (!ua.contains("Chrome")) {
                    s.userAgentString =
                        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36"
                }
                RuntimeLog.info("WebViewBet", "WebView 已挂载并开启 JS (ref更新)")
            } catch (e: Exception) {
                RuntimeLog.warn("WebViewBet", "initWebView: ${e.message}")
            }
        }
    }

    fun clearWebView() {
        webView = null
        // v2.5.3: WebView 被 detach/Activity 销毁时，强制释放 runningCmdId，
        // 防止执行器被永久锁死（runningCmdId 残留导致所有新指令被拒绝）
        synchronized(this) { runningCmdId = null }
    }

    /** v2.5.3: 供 ResultQueryScheduler 查询余额/页面状态用 */
    internal fun getWebViewForQuery(): android.webkit.WebView? = webView

    fun execute(command: BetCommand, onResult: (ExecutionResult) -> Unit): Boolean {
        val wv = webView
        if (wv == null) {
            onResult(
                ExecutionResult.fail(
                    command.cmdId,
                    ExecutionResult.WEBVIEW_DISCONNECTED,
                    "WebView 未连接，请先打开「内置网页挂机」并加载投注站"
                )
            )
            return false
        }
        if (command.isExpired) {
            onResult(
                ExecutionResult.fail(
                    command.cmdId,
                    ExecutionResult.COMMAND_EXPIRED,
                    "指令已过期"
                )
            )
            return false
        }
        val adapter = siteAdapter
        val profile = try {
            com.caifenxi.app.domain.execution.ClickMatchConfig.load(
                com.caifenxi.app.CaiFenXiApplication.instance
            )
        } catch (_: Exception) {
            com.caifenxi.app.domain.execution.ClickMatchConfig.Profile()
        }
        val mappingError = profile.executionValidationError()
        if (mappingError != null) {
            onResult(ExecutionResult.fail(command.cmdId, ExecutionResult.CANCELLED, "网页动作标注校验失败：$mappingError，已阻止真实执行"))
            return false
        }
        if (command.issue.isBlank() || command.issue == "-") {
            onResult(ExecutionResult.fail(command.cmdId, ExecutionResult.ISSUE_MISMATCH, "执行工单缺少有效期号"))
            return false
        }
        if (command.stage !in 1..3 || command.leg < 0 || command.leg >= command.stage) {
            onResult(ExecutionResult.fail(command.cmdId, ExecutionResult.ACTION_FAILED, "一期/二期/三期工单阶段参数无效"))
            return false
        }
        val amountValue = command.amountText?.trim()?.toDoubleOrNull()
        if (amountValue == null || amountValue <= 0.0 || !amountValue.isFinite()) {
            onResult(ExecutionResult.fail(command.cmdId, ExecutionResult.ACTION_FAILED, "本期金额无效：${command.amountText}"))
            return false
        }
        // v2.6.2: 允许直选单式（CAT_NUMBER）下注，不再限制方向
        val allowedValues = setOf("大", "小", "单", "双")
        val hasDirection = command.bets.any { it.category in setOf(BetAction.CAT_DX, BetAction.CAT_DS) }
        val hasNumbers = command.bets.any { it.category == BetAction.CAT_NUMBER }
        if (command.bets.isEmpty()) {
            onResult(ExecutionResult.fail(command.cmdId, ExecutionResult.ACTION_FAILED, "挂机方向工单无效"))
            return false
        }
        if (hasDirection && command.bets.any {
                it.category in setOf(BetAction.CAT_DX, BetAction.CAT_DS) && it.value !in allowedValues
            }) {
            onResult(ExecutionResult.fail(command.cmdId, ExecutionResult.ACTION_FAILED, "挂机方向工单无效"))
            return false
        }
        val dryRun = command.options["dryRun"] == "1" || command.options["dryRun"] == "true"
        val phase1Js = try { adapter.buildInjectScript(command) } catch (e: Exception) {
            onResult(ExecutionResult.fail(command.cmdId, ExecutionResult.ACTION_FAILED, "构建脚本失败: ${e.message}"))
            return false
        }
        val phase2Js = adapter.buildPhase2Script(command)
        val phase2VerifyJs = adapter.buildPhase2VerifyScript(command)
        val phase3Js = adapter.buildPhase3Script(command)
        val balJs = adapter.balanceSnapshotScript
        val start = System.currentTimeMillis()
        RuntimeLog.info("WebViewBet", "执行(分阶段) cmdId=${command.cmdId} issue=${command.issue} bets=${command.bets.size} dryRun=$dryRun")

        // —— 防重入：同一 cmdId 已在执行中（或已完成）时直接拒绝，避免重复确定弹窗 ——
        synchronized(this) {
            val running = runningCmdId
            if (running != null) {
                RuntimeLog.warn("WebViewBet", "cmdId=${command.cmdId} 已在执行中，跳过重复触发")
                onResult(
                    ExecutionResult.fail(
                        command.cmdId,
                        ExecutionResult.DUPLICATE_COMMAND,
                        "WebView正在执行 ${running}，当前期执行被串行化拦截"
                    )
                )
                return false
            }
            runningCmdId = command.cmdId
        }

        mainHandler.post {
            try {
                    // v2.6.3fix: 设置点击上下文（供网络拦截关联）
                    val actionContext = command.bets.joinToString(",") { it.category + ":" + it.value }
                    wv.evaluateJavascript("window.__cfxSetActionContext('bet', 'click', '$actionContext');", null)
                    // 0) 每轮指令开始时重置确认指纹表，防止上一期点击记录导致本期"确认"按钮被跳过
                    wv.evaluateJavascript("window.__CFX_CONFIRMED_FPS = {};", null)
                // ① 余额前
                wv.evaluateJavascript(balJs) { beforeRaw ->
                    val before = unescapeJsResult(beforeRaw).trim().trim('"')
                    RuntimeLog.info("WebViewBet", "余额前=$before cmdId=${command.cmdId}")
                    // ② Phase1: 点击玩法按钮
                    wv.evaluateJavascript(phase1Js) { r1Raw ->
                        val r1 = unescapeJsResult(r1Raw)
                        RuntimeLog.info("WebViewBet", "Phase1(点击) cmdId=${command.cmdId} raw=${r1.take(200)}")
                        val receipt1 = adapter.parseReceipt(r1)
                        if (!receipt1.isSuccess) {
                            returnResult(wv, command, onResult, start, before, before, false, "Phase1失败: ${receipt1.message}", dryRun)
                            return@evaluateJavascript
                        }
                        // ③ 等待金额区出现（选号后才渲染倍数/输入投注金额）
                        mainHandler.postDelayed({
                            // ④ Phase2: 输入金额
                            wv.evaluateJavascript(phase2Js) { r2Raw ->
                                val r2 = unescapeJsResult(r2Raw)
                                RuntimeLog.info("WebViewBet", "Phase2(金额) cmdId=${command.cmdId} raw=${r2.take(200)}")
                                val receipt2 = adapter.parseReceipt(r2)
                                if (!receipt2.isSuccess) {
                                    returnResult(wv, command, onResult, start, before, before, false, "Phase2失败: ${receipt2.message}", dryRun)
                                    return@evaluateJavascript
                                }
                                // ⑤ 等待金额弹层/输入框出现后再写入（二期倍投依赖此步）
                                mainHandler.postDelayed({
                                    // ⑤b Phase2.5: 金额复核——再次读取页面金额框实际值，若被改写则强制重设
                                    wv.evaluateJavascript(phase2VerifyJs) { vRaw ->
                                        val v = unescapeJsResult(vRaw)
                                        RuntimeLog.info("WebViewBet", "Phase2.5(金额复核) cmdId=${command.cmdId} raw=${v.take(200)}")
                                        val vOk = v.contains("\"ok\":true") || v.contains("\"ok\": true")
                                        if (!vOk) {
                                            // 复核无法把金额稳定在期望值（站点强联动改写）→ 阻止确认，避免错单
                                            returnResult(wv, command, onResult, start, before, before, false, "金额复核失败: ${v.take(160)}", dryRun)
                                            return@evaluateJavascript
                                        }
                                        // ⑥ Phase3: 点击确认（Kotlin 侧延时驱动单轮循环，JS 内零忙等 → 不再卡黑屏）
                                        // 等待 300ms 让站点框架完成金额值的最终渲染和内部状态提交，再点确认
                                        mainHandler.postDelayed({
                                        var confirmStopped = false
                                        fun confirmRound(round: Int) {
                                            if (confirmStopped) return
                                            wv.evaluateJavascript(phase3Js) { r3Raw ->
                                                if (confirmStopped) return@evaluateJavascript
                                                val r3 = unescapeJsResult(r3Raw)
                                                RuntimeLog.info("WebViewBet", "Phase3(确认#$round) cmdId=${command.cmdId} raw=${r3.take(200)}")
                                                val receipt3 = adapter.parseReceipt(r3)
                                                val finished = r3.contains("\"finished\":true") || r3.contains("\"finished\": true")
                                                // v2.5.3: clicked 使用 receipt 结构化字段，避免字符串匹配因空格差异失效
                                                val clicked = receipt3.message.contains("已点击") || receipt3.message.contains("clicked") || r3.contains("\"clicked\":true") || r3.contains("\"clicked\": true")
                                                // v2.5.3: 确认按钮一旦真正被点击，立即永久锁定本期，
                                                // 无论后续余额校验/结果判定是 SUCCESS/FAILED/UNKNOWN，
                                                // 都绝不允许再次自动点击同一期。
                                                if (clicked) {
                                                    ExecutionTicketStore.markConfirmed(command.lotteryKey, command.issue)
                                                }
                                                if (finished || !clicked || round >= 3) {
                                                    confirmStopped = true
                                                    // ⑦ 等待 600ms 让页面处理确认
                                                    mainHandler.postDelayed({
                                                        // ⑧ 余额后
                                                        wv.evaluateJavascript(balJs) { afterRaw ->
                                                            val after = unescapeJsResult(afterRaw).trim().trim('"')
                                                            val changed = before.isNotBlank() && after.isNotBlank() && before != after && after != "null" && before != "null"
                                                            // v2.5.3: 余额兜底 — 即使 JS 回执丢失(clicked=false)，
                                                            // 只要余额减少 ≈ 下注金额，强制视为已提交。
                                                            // 关键：余额应减少（delta > 0），避免派奖/彩金入账导致误判。
                                                            val balDelta = if (changed) parseBalanceDelta(before, after) else null
                                                            val amt = command.amountText?.trim()?.toDoubleOrNull() ?: 0.0
                                                            val balanceMatchesAmount = balDelta != null && amt > 0 &&
                                                                balDelta > 0 &&  // 余额必须减少（扣款）
                                                                kotlin.math.abs(balDelta - amt) < amt * 0.15
                                                            if (balanceMatchesAmount && !clicked) {
                                                                // 余额减少≈金额但 clicked=false → 网站可能已实际下单
                                                                ExecutionTicketStore.markConfirmed(command.lotteryKey, command.issue)
                                                                RuntimeLog.info("WebViewBet", "余额兜底: 减少=$balDelta 金额=$amt → 强制视为已提交 cmdId=${command.cmdId}")
                                                            }
                                                            val verified = dryRun || changed || receipt3.message.contains("完成") || receipt3.message.contains("成功")
                                                            val ok = receipt3.isSuccess && verified
                                                            // v2.5.3: 三分支终态判断
                                                            // - 成功：receipt3.isSuccess && verified
                                                            // - 已提交未知：clicked=true 或 余额≈金额，但未能完全确认
                                                            // - 失败：确认按钮未点击且余额无变化（可重试）
                                                            val committed = clicked || balanceMatchesAmount
                                                            val uncertain = committed && !ok
                                                            val msg = "玩法→金额→确认 " + when {
                                                                ok -> "成功"
                                                                uncertain -> "已提交但结果未能确认（已永久锁定本期）"
                                                                else -> "失败"
                                                            } + " $before→$after · ${receipt3.message}"
                                                            returnResult(
                                                                wv, command, onResult, start, before, after, ok, msg, dryRun,
                                                                if (uncertain) ExecutionResult.COMMITTED_UNKNOWN else null
                                                            )
                                                        }
                                                    }, 600)
                                                } else {
                                                    mainHandler.postDelayed({ confirmRound(round + 1) }, 800)
                                                }
                                            }
                                        }
                                        confirmRound(1)
                                        }, 700)
                                    }
                                }, 900)
                            }
                        }, 1400)
                    }
                }
            } catch (e: Exception) {
                // ★ 异常时也停止遮罩守卫
                try { wv.evaluateJavascript("if(window.__cfxStopOverlayGuard) window.__cfxStopOverlayGuard();", null) } catch (_: Exception) {}
                synchronized(this) {
                    if (runningCmdId == command.cmdId) runningCmdId = null
                }
                RuntimeLog.error("WebViewBet", "execute 异常: ${e.message}")
                onResult(ExecutionResult.fail(command.cmdId, ExecutionResult.ACTION_FAILED, "执行异常: ${e.message}", System.currentTimeMillis() - start))
            }
        }
        return true
    }

    private fun returnResult(
        wv: WebView, command: BetCommand, onResult: (ExecutionResult) -> Unit,
        start: Long, before: String, after: String, ok: Boolean, msg: String, dryRun: Boolean,
        overrideErrorType: String? = null
    ) {
        // ★ 停止遮罩拦截守卫（释放 MutationObserver + rAF + timer）
        try {
            wv.evaluateJavascript("if(window.__cfxStopOverlayGuard) window.__cfxStopOverlayGuard();", null)
        } catch (_: Exception) {}
        val duration = System.currentTimeMillis() - start
        /* 同一指令执行结束，释放防重入标记 */
        synchronized(this) {
            if (runningCmdId == command.cmdId) runningCmdId = null
        }
        // v2.5.3: 状态写入区分 COMMITTED_UNKNOWN 与 FAILED，让 UI/日志可区分
        val statusStr = when {
            ok -> "SUCCESS"
            overrideErrorType == ExecutionResult.COMMITTED_UNKNOWN -> "COMMITTED_UNKNOWN"
            else -> "FAILED"
        }
        com.caifenxi.app.domain.execution.ExecutionTicketStore.updateStatus(
            command.cmdId,
            statusStr,
            msg,
            balanceBefore = before,
            balanceAfter = after
        )
        val result = if (ok) {
            ExecutionResult.ok(command.cmdId, msg, duration)
        } else if (overrideErrorType == ExecutionResult.COMMITTED_UNKNOWN) {
            ExecutionResult.committedUnknown(command.cmdId, msg, duration)
        } else if (overrideErrorType != null) {
            ExecutionResult.fail(command.cmdId, overrideErrorType, msg, duration)
        } else {
            ExecutionResult.fail(command.cmdId, ExecutionResult.ACTION_FAILED, msg, duration)
        }
        onResult(result)
    }

    fun executeWebViewBet(
        dx: String?,
        ds: String?,
        amountText: String?,
        combo: String?,
        predNumbers: List<String> = emptyList(),
        onResult: ((ExecutionResult) -> Unit)? = null
    ): Boolean {
        val bets = buildList {
            if (dx == "大" || dx == "小") {
                add(BetAction(BetAction.CAT_DX, dx))
            }
            if (ds == "单" || ds == "双") {
                add(BetAction(BetAction.CAT_DS, ds))
            }
            if (combo != null) {
                add(BetAction(BetAction.CAT_COMBO, combo))
            }
            predNumbers.forEach {
                add(BetAction(BetAction.CAT_NUMBER, it))
            }
        }
        if (bets.isEmpty()) return false
        val cmd = BetCommand(
            cmdId = "legacy-${System.currentTimeMillis()}",
            lotteryKey = "",
            issue = "",
            bets = bets,
            amountText = amountText
        )
        return execute(cmd) { r -> onResult?.invoke(r) }
    }

    /** v2.5.3: 解析余额前/后差值（支持逗号千分位、带币种符号等格式） */
    private fun parseBalanceDelta(before: String, after: String): Double? {
        val b = parseBalanceNumber(before) ?: return null
        val a = parseBalanceNumber(after) ?: return null
        return a - b
    }

    private fun parseBalanceNumber(raw: String): Double? {
        if (raw.isBlank() || raw == "null") return null
        // 去掉币种符号、千分位逗号、空格
        val cleaned = raw.replace(",", "").replace("¥", "").replace("$", "").replace("￥", "").replace(" ", "").trim()
        return cleaned.toDoubleOrNull()
    }

    private fun unescapeJsResult(raw: String?): String {
        if (raw.isNullOrBlank() || raw == "null") return ""
        var s = raw.trim()
        if (s.startsWith("\"") && s.endsWith("\"")) {
            s = s.substring(1, s.length - 1)
                .replace("\\\"", "\"")
                .replace("\\\\", "\\")
                .replace("\\n", "\n")
        }
        return s
    }
}
