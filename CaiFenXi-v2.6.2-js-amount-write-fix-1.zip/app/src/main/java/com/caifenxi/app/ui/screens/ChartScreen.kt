package com.caifenxi.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.plan.AlgoChartPlans
import com.caifenxi.app.domain.plan.NovaPlanAnalytics
import com.caifenxi.app.domain.model.LotteryType
import com.caifenxi.app.domain.model.positionDisplayName
import com.caifenxi.app.domain.model.positionIndexOf
import com.caifenxi.app.domain.model.LotteryPlayCatalog
import com.caifenxi.app.domain.plan.NovaK3PlanPool
import com.caifenxi.app.domain.plan.NovaPlanPool
import com.caifenxi.app.domain.plan.NovaYdhPlanPool
import com.caifenxi.app.domain.plan.LotteryPlanPools
import com.caifenxi.app.domain.plan.PlanPool
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.ConclusionStrip
import com.caifenxi.app.ui.components.EmptyStateBlock
import com.caifenxi.app.ui.components.LoadingBlock
import com.caifenxi.app.ui.components.UiFormat
import com.caifenxi.app.ui.components.PageHeader
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.theme.CaiTokens
import kotlin.math.roundToInt
import kotlinx.coroutines.delay

@Composable
fun ChartScreen(vm: MainViewModel) {
    // 筛选/选项在 PlanViewModel，切 Tab 再回来不丢失；仅弹窗详情用页面本地状态
    var chartDetail by remember { mutableStateOf<NovaPlanAnalytics.ChartPoint?>(null) }
    val planVM = vm.planVM
    var chartPeriods by planVM.chartPeriods
    var chartStakeText by planVM.chartStakeText
    var chartSelectedIds by planVM.chartSelectedIds
    var chartSource by planVM.chartSource
    var chartMode by planVM.chartMode
    var plansExpanded by planVM.chartPlansExpanded
    var playFilter by planVM.chartPlayFilter
    var autoRefresh by planVM.chartAutoRefresh
    var chartBetInvert by planVM.chartBetInvert
    var chartGuanguan by planVM.chartGuanguan
    var chartGuanguanTarget by planVM.chartGuanguanTarget

    val history = vm.history.value
    val lotType = vm.currentLottery.value.type
    var chartPositionFilter by remember(lotType) { mutableStateOf("全部") }
    // v2.6.3fix: remember 大列表，避免每次重组扫 600+ 计划导致卡顿
    val customSnap = vm.customPlans.value
    val generatedSnap = vm.planVM.generatedNovaPlans.value
    val customAll = remember(customSnap, lotType) {
        customSnap.map { it.toDefinition() }
            .filter {
                it.planId.startsWith("NOVA-CUSTOM-") ||
                    it.planId.startsWith("NOVA-GEN-") ||
                    it.category.startsWith("GEN-") ||
                    it.randomGenerated
            }
            .filter { LotteryPlanPools.belongsTo(it, lotType) }
    }
    val generated = remember(generatedSnap, lotType) {
        generatedSnap.filter { LotteryPlanPools.belongsTo(it, lotType) }
    }
    val novaPlans = remember(lotType, generated, customAll) {
        (LotteryPlanPools.novaPlansFor(lotType) + generated + customAll).distinctBy { it.planId }
    }
    val candidatePlans = remember(lotType) {
        when (lotType) {
            LotteryType.PKS -> NovaPlanPool.CANDIDATES
            LotteryType.YDH -> NovaYdhPlanPool.CANDIDATES
            LotteryType.K3 -> NovaK3PlanPool.CANDIDATES
            LotteryType.PC28 -> com.caifenxi.app.domain.plan.NovaPc28PlanPool.CANDIDATES
            LotteryType.LUCK20 -> com.caifenxi.app.domain.plan.NovaLuck20PlanPool.CANDIDATES
            LotteryType.GOOGLE_FF, LotteryType.SHUIGUAN_FF -> com.caifenxi.app.domain.plan.PlanPoolV2.candidates(lotType)
            else -> emptyList()
        }.filter { LotteryPlanPools.belongsTo(it, lotType) }
    }
    val modelPlans = remember(lotType) {
        if (lotType == LotteryType.YDH || lotType == LotteryType.K3) emptyList()
        else AlgoChartPlans.EXPERIENCE + AlgoChartPlans.PATTERN + AlgoChartPlans.FUSION
    }
    val allChartPlans = remember(lotType, novaPlans, candidatePlans, customAll, modelPlans) {
        (LotteryPlanPools.legacyPlansFor(lotType) + novaPlans + candidatePlans + customAll + modelPlans).distinctBy { it.planId }
    }
    val favoriteIds = vm.favoritePlanIds(vm.currentLottery.value.key)
    // 收藏计划：从全量池解析，避免只落在某一子池导致「无法选择 / 被错误分到其它来源」
    // v2.6.3fix: 补 PlanPoolV2.find，保证定位/直选单式等 NOVA-V2 计划一定能解析出来
    val favoritePlans = favoriteIds.mapNotNull { id ->
        allChartPlans.firstOrNull { it.planId == id }
            ?: LotteryPlanPools.find(id, lotType)
            ?: com.caifenxi.app.domain.plan.PlanPoolV2.find(id)?.takeIf { LotteryPlanPools.belongsTo(it, lotType) }
            ?: vm.customPlans.value.firstOrNull { it.planId == id }?.toDefinition()
            ?: vm.planRows.value.firstOrNull { it.first.planId == id }?.first
            ?: vm.planVM.novaPlanRows.value.firstOrNull { it.first.planId == id }?.first
    }.distinctBy { it.planId }
    val sourcePlansAll = when (chartSource) {
        "原计划池" -> LotteryPlanPools.legacyPlansFor(lotType)
        "新计划池" -> novaPlans
        "候选池" -> candidatePlans
        "收藏计划" -> favoritePlans
        "自定义计划" -> customAll
        "经验学习" -> if (lotType == LotteryType.YDH || lotType == LotteryType.K3) emptyList() else AlgoChartPlans.EXPERIENCE
        "形态匹配" -> if (lotType == LotteryType.YDH || lotType == LotteryType.K3) emptyList() else AlgoChartPlans.PATTERN
        "智能融合" -> if (lotType == LotteryType.YDH || lotType == LotteryType.K3) emptyList() else AlgoChartPlans.FUSION
        "原共识", "新共识" -> emptyList()
        else -> novaPlans
    }.distinctBy { it.planId }
    val sourcePlansByPlay = if (playFilter == "全部") sourcePlansAll else sourcePlansAll.filter { it.playType == playFilter }
    val positionOptions = listOf("全部") + sourcePlansByPlay.map { it.positionIndex }.filter { it >= 0 }.distinct().sorted().map { positionDisplayName(lotType, it) }
    // 禁止在 composition 中直接写 state，否则切 Tab 可能闪退
    LaunchedEffect(positionOptions, chartPositionFilter) {
        if (chartPositionFilter !in positionOptions) chartPositionFilter = "全部"
    }
    val sourcePlans = if (chartPositionFilter == "全部" || chartPositionFilter !in positionOptions) sourcePlansByPlay else {
        val idx = positionIndexOf(lotType, chartPositionFilter)
        if (idx < 0) sourcePlansByPlay else sourcePlansByPlay.filter { it.positionIndex == idx }
    }
    val consensusCategories = when (playFilter) {
        "大小", "单双", "组合" -> listOf(playFilter)
        else -> listOf("大小", "单双", "组合")
    }
    val consensusRecords = if (chartSource == "原共识") vm.planVM.consensusRecords.value else vm.planVM.novaConsensusRecords.value
    val reports = vm.planVM.novaChartReports.value
    val running = vm.planVM.novaChartRunning.value
    val stage = vm.planVM.novaChartStage.value

    fun runBacktest() {
        val stake = chartStakeText.toDoubleOrNull() ?: 10.0
        when (chartSource) {
            "原共识" -> vm.planVM.runConsensusChartBacktest(
                "原计划引擎共识", vm.planVM.consensusRecords.value, chartPeriods, stake, consensusCategories, chartBetInvert, chartGuanguan, chartGuanguanTarget
            )
            "新共识" -> vm.planVM.runConsensusChartBacktest(
                "新计划池共识", vm.planVM.novaConsensusRecords.value, chartPeriods, stake, consensusCategories, chartBetInvert, chartGuanguan, chartGuanguanTarget
            )
            else -> {
                val selected = sourcePlans.filter { it.planId in chartSelectedIds }.ifEmpty {
                    if (chartSource == "候选池") emptyList() else sourcePlans.take(1)
                }
                if (selected.isEmpty()) return
                val comboN = vm.prefs.value.comboPredCount.coerceIn(1, 4)
                val numN = vm.prefs.value.positionTopN.coerceIn(1, 10)
                // 直选单式注数档位 → 各位置候选数（全部=10×10×10=1000注）
                val directNs = if (planVM.chartDirectRange.value != "全部")
                    NovaPlanAnalytics.directTopNsForRange(planVM.chartDirectRange.value)
                else listOf(10, 10, 10)
                vm.planVM.runNovaChartBacktest(history, selected, chartPeriods, stake, chartBetInvert, comboN, numN, chartGuanguan, chartGuanguanTarget, directTopNs = directNs)
            }
        }
    }

    // 自动重算：防抖，避免连点参数时叠多个重任务；改参数会取消上一次图表 Job
    val comboPref = vm.prefs.value.comboPredCount
    val posPref = vm.prefs.value.positionTopN
    val latestIssueKey = history.lastOrNull()?.issue ?: ""
    val refreshTok = planVM.chartRefreshToken.value
    LaunchedEffect(autoRefresh, refreshTok, latestIssueKey, chartSource, chartPeriods, stage, chartSelectedIds.joinToString(), chartStakeText, playFilter, chartBetInvert, chartGuanguan, chartGuanguanTarget, comboPref, posPref, planVM.chartDirectRange.value) {
        if (!autoRefresh) return@LaunchedEffect
        delay(450)
        val canRun = when (chartSource) {
            "原共识", "新共识" -> consensusRecords.isNotEmpty()
            else -> history.size >= 6 && sourcePlans.isNotEmpty()
        }
        if (canRun) runBacktest()
    }

    if (chartDetail != null) {
        val pt = chartDetail!!
        AlertDialog(
            onDismissRequest = { chartDetail = null },
            confirmButton = { TextButton(onClick = { chartDetail = null }) { Text("关闭") } },
            title = { Text("回测节点详情") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("期号：${pt.issue}")
                    Text("预测：${pt.prediction}")
                    Text("方向：${if (chartBetInvert) "反投" else "正投"}")
                    Text("结果：${if (pt.hit) "对" else "错"}")
                    Text("单期盈亏：${chartFmtMoney(pt.periodProfit)}")
                    Text("累计盈亏：${chartFmtMoney(pt.cumulativeProfit)}")
                    Text("当时对错率：${"%.2f".format(pt.hitRate * 100)}%")
                    Text("相对50%：${chartFmtMoney((pt.hitRate - 0.5) * 100)} 百分点")
                    Text("回撤：${chartFmtMoney(pt.drawdown)}")
                }
            }
        )
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = CaiTokens.ScreenHPadding, vertical = CaiTokens.S12),
        verticalArrangement = Arrangement.spacedBy(CaiTokens.S8),
        contentPadding = PaddingValues(bottom = CaiTokens.ScreenBottom)
    ) {
        item {
            PageHeader(
                title = "图表回测",
                lotteryName = vm.currentLottery.value.name,
                playSummary = LotteryPlayCatalog.summaryText(lotType),
                subtitle = "滚动回测 · 对错率 50% 零轴 · 绿涨红跌"
            )
            CaptionMuted("绿涨红跌 · 组合1:4减成本 · 仅飞艇/赛车不对称赔率 · 其它大小单双约2倍 · 对错率50%零轴")
        }

        item {
            GlobalCard {
                Text("回测设置", fontWeight = FontWeight.Bold)
                CaptionMuted("新计划池含：系统池 + 本批生成 + 已落库 GEN；玩法筛选与当前彩种目录一致，均可回测")
                ChartFilterLine(
                    "回测来源",
                    listOf("新计划池", "原计划池", "候选池", "收藏计划", "自定义计划", "经验学习", "形态匹配", "智能融合", "原共识", "新共识"),
                    chartSource
                ) {
                    chartSource = it
                    chartSelectedIds = emptyList()
                    chartPositionFilter = "全部"
                    // 候选池极大，切过去先关掉自动回测，避免一选来源就全量构图闪退
                    if (it == "候选池") {
                        autoRefresh = false
                        playFilter = "全部"
                    }
                    // 切到收藏计划：重置玩法筛选，避免「大小」等筛选把定位/直选收藏滤空
                    if (it == "收藏计划") {
                        playFilter = "全部"
                        autoRefresh = false
                        if (favoritePlans.isNotEmpty()) {
                            chartSelectedIds = favoritePlans.take(3).map { p -> p.planId }
                        }
                    }
                }
                ChartFilterLine(
                    "图表",
                    listOf("累计收益", "单期盈亏", "对错率", "命中率", "涨跌趋势", "回撤"),
                    chartMode
                ) { chartMode = it }
                ChartFilterLine(
                    "回测",
                    listOf(100, 200, 500, 1000, 2000, 5000).map { "${it}期" },
                    "${chartPeriods}期"
                ) { chartPeriods = it.removeSuffix("期").toInt() }
                ChartFilterLine(
                    "计算口径",
                    listOf("一期", "两期", "三期"),
                    when (stage.coerceIn(1, 3)) {
                        2 -> "两期"
                        3 -> "三期"
                        else -> "一期"
                    }
                ) { v ->
                    vm.planVM.novaChartStage.value = when (v) {
                        "两期" -> 2
                        "三期" -> 3
                        else -> 1
                    }
                }
                ChartFilterLine(
                    "投注方向",
                    listOf("正投", "反投"),
                    if (chartBetInvert) "反投" else "正投"
                ) { v -> chartBetInvert = (v == "反投") }
                ChartFilterLine(
                    "投注模式",
                    listOf("普通回测", "过关斩将"),
                    if (chartGuanguan) "过关斩将" else "普通回测"
                ) { v -> chartGuanguan = (v == "过关斩将") }
                if (chartGuanguan) {
                    ChartFilterLine(
                        "过关关数",
                        (1..10).map { "${it}关" },
                        "${chartGuanguanTarget}关"
                    ) { v ->
                        v.removeSuffix("关").toIntOrNull()?.let { n ->
                            chartGuanguanTarget = n.coerceIn(1, 10)
                            planVM.chartRefreshToken.value = planVM.chartRefreshToken.value + 1
                        }
                    }
                }
                CaptionMuted(
                    if (chartGuanguan)
                        "过关斩将：可手动设置1～10关。命中后将本关实际返还额全部投入下一关。大小/单双约2倍（10→20→40，过三关净+70）；组合按真实1:4返还（10→40→160，过三关净+390，多口成本=条数×单注）。任一关错则本轮结束并恢复基础注。"
                    else if (chartBetInvert)
                        "反投：大小/单双/组合方向取反；数字/位置对错取反。二/三期倍投：组合3口+×4、2口及以下×2（与大小单双一致）；盈亏按赔率"
                    else
                        "正投：原样结算。PK10大2.2/小1.79/单1.79/双2.2；组合按条数赔率"
                )
                // 组合条数 / 位置数量：直接改全局偏好并参与回测
                val comboNUi = vm.prefs.value.comboPredCount
                val posNUi = vm.prefs.value.positionTopN
                ChartFilterLine(
                    "组合预测条数",
                    listOf("1", "2", "3", "4"),
                    comboNUi.toString()
                ) { v ->
                    v.toIntOrNull()?.let { n ->
                        vm.updatePrefs { it.copy(comboPredCount = n.coerceIn(1, 4)) }
                        planVM.chartRefreshToken.value = planVM.chartRefreshToken.value + 1
                    }
                }
                ChartFilterLine(
                    "位置/号码 TopN",
                    listOf("1", "2", "3", "5", "8", "10"),
                    posNUi.toString()
                ) { v ->
                    v.toIntOrNull()?.let { n ->
                        vm.updatePrefs { it.copy(positionTopN = n.coerceIn(1, 20), zuheTopN = n.coerceIn(1, 20)) }
                        planVM.chartRefreshToken.value = planVM.chartRefreshToken.value + 1
                    }
                }
                // v2.6.2+: 直选单式注数档位（与工作台一致；档位=每期注数区间，期内动态浮动）
                var directRangeUi by planVM.chartDirectRange
                ChartFilterLine(
                    "直选单式注数",
                    NovaPlanAnalytics.DIRECT_NOTE_RANGES.map { r ->
                        if (r == "全部") "全部(1000注)" else "${r}注"
                    },
                    if (directRangeUi == "全部") "全部(1000注)" else "${directRangeUi}注"
                ) { v ->
                    val range = when {
                        v.startsWith("全部") -> "全部"
                        v.endsWith("注") -> v.removeSuffix("注").trim()
                        else -> v
                    }
                    planVM.chartDirectRange.value = range
                    planVM.chartRefreshToken.value = planVM.chartRefreshToken.value + 1
                }
                CaptionMuted("直选单式（前三/中三/后三）按档位真实生成组合注数；只影响直选计划，其它玩法不受影响")
                CaptionMuted("条数变化会重算预测与对错率；多注成本=条数×单注（组合/数字同理）")
                if (chartSource in listOf("原共识", "新共识")) {
                    ChartFilterLine(
                        "共识分类",
                        listOf("全部", "大小", "单双", "组合"),
                        playFilter.let { if (it in listOf("全部", "大小", "单双", "组合")) it else "全部" }
                    ) { playFilter = it }
                    CaptionMuted("共识按分类分别回测：大小/单双/组合各一条曲线；选「全部」则三类一起对比。")
                } else if (chartSource !in listOf("经验学习", "形态匹配", "智能融合")) {
                    // 收藏来源：玩法筛选项以收藏实际玩法为准，保证定位/直选不会因目录差异被滤空
                    val playOpts = if (chartSource == "收藏计划") {
                        listOf("全部") + favoritePlans.map { it.playType }.distinct().sorted()
                    } else {
                        LotteryPlayCatalog.filterChipOptions(lotType)
                    }
                    val cur = if (playFilter in playOpts) playFilter else "全部"
                    ChartFilterLine("玩法筛选", playOpts, cur) {
                        playFilter = it
                        chartSelectedIds = emptyList()
                    }
                    CaptionMuted(
                        if (chartSource == "收藏计划")
                            "收藏 ${favoritePlans.size} 个 · 当前可见 ${sourcePlans.size} · 已选 ${chartSelectedIds.size.coerceAtLeast(0)}"
                        else
                            "当前筛选可选计划 ${sourcePlans.size} 个 · 已选 ${chartSelectedIds.size.coerceAtLeast(0)}"
                    )
                    if (positionOptions.size > 1) {
                        ChartFilterLine("位置筛选", positionOptions, chartPositionFilter) {
                            chartPositionFilter = it
                            chartSelectedIds = emptyList()
                        }
                    }
                }

                Row(
                    Modifier.fillMaxWidth().padding(top = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("自动更新图表", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Switch(checked = autoRefresh, onCheckedChange = { autoRefresh = it })
                }
                CaptionMuted(
                    if (autoRefresh) "已开启：改参数 / 新期同步后自动重算（防抖 450ms）"
                    else "已关闭自动：需手动点「开始回测」"
                )

                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("选择具体计划（最多5个）", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    if (favoritePlans.isNotEmpty()) TextButton(onClick = { chartSource = "收藏计划"; playFilter = "全部"; chartPositionFilter = "全部"; chartSelectedIds = favoritePlans.take(5).map { it.planId } }) { Text("选收藏") }
                    if (chartSelectedIds.isNotEmpty()) TextButton(onClick = { chartSelectedIds = emptyList() }) { Text("清空") }
                    TextButton(onClick = { plansExpanded = !plansExpanded }) {
                        Text(if (plansExpanded) "收起 ▲" else "展开 ▼")
                    }
                }

                if (plansExpanded) {
                    TextField(
                        value = chartStakeText,
                        onValueChange = { value ->
                            chartStakeText = value.filter { c -> c.isDigit() || c == '.' }.take(10)
                        },
                        label = { Text("回测单注金额") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    if (chartSource == "原共识" || chartSource == "新共识") {
                        val byCat = listOf("大小", "单双", "组合").associateWith { cat ->
                            consensusRecords.count { it.category == cat && (it.result == "对" || it.result == "错") }
                        }
                        CaptionMuted(
                            "已结算：大小 ${byCat["大小"]} · 单双 ${byCat["单双"]} · 组合 ${byCat["组合"]}（分类独立回测）"
                        )
                    } else if (sourcePlans.isEmpty()) {
                        CaptionMuted("该来源暂无可回测计划（可换筛选或来源）")
                    }
                    val visiblePlans = if (chartSource == "候选池") sourcePlans.take(80) else sourcePlans.take(120)
                    if (sourcePlans.size > visiblePlans.size) {
                        CaptionMuted("共 ${sourcePlans.size} 条，仅列出前 ${visiblePlans.size} 条。请用玩法/位置筛选缩小范围后再勾选。")
                    }
                    visiblePlans.forEach { p ->
                        val checked = p.planId in chartSelectedIds
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    chartSelectedIds = if (checked) {
                                        chartSelectedIds - p.planId
                                    } else {
                                        (chartSelectedIds + p.planId).distinct().take(5)
                                    }
                                },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = checked,
                                onCheckedChange = { on ->
                                    chartSelectedIds = if (on) {
                                        (chartSelectedIds + p.planId).distinct().take(5)
                                    } else {
                                        chartSelectedIds - p.planId
                                    }
                                }
                            )
                            Column(Modifier.weight(1f)) {
                                Text(
                                    p.planName,
                                    fontSize = 13.sp,
                                    fontWeight = if (checked) FontWeight.Bold else FontWeight.Normal
                                )
                                CaptionMuted("${p.playType} · ${p.algorithm} · ${p.window}期${if (p.positionIndex >= 0) " · ${positionDisplayName(lotType, p.positionIndex)}" else ""}")
                            }
                            IconButton(onClick = { vm.togglePlanFavorite(p.planId) }) {
                                Icon(if (p.planId in favoriteIds) Icons.Filled.Star else Icons.Filled.StarBorder, contentDescription = null)
                            }
                        }
                    }
                }

                val canRun = !running && (
                    if (chartSource == "原共识" || chartSource == "新共识") consensusRecords.isNotEmpty()
                    else history.size >= 6 && sourcePlans.isNotEmpty()
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PrimaryButton(
                        if (running) "正在回测…" else "开始回测 / 更新图表",
                        { runBacktest() },
                        Modifier.weight(1f),
                        enabled = canRun
                    )
                    OutlinedButton(
                        onClick = { vm.planVM.clearNovaChart(); chartDetail = null },
                        modifier = Modifier.weight(0.55f)
                    ) { Text("重置图表") }
                }
                if (!canRun && !running) {
                    CaptionMuted(
                        when {
                            chartSource in listOf("原共识", "新共识") && consensusRecords.isEmpty() ->
                                "暂无已结算共识，无法回测"
                            history.size < 6 -> "历史不足 6 期，无法回测"
                            sourcePlans.isEmpty() -> "无可选计划"
                            else -> ""
                        }
                    )
                }
            }
        }

        item {
            GlobalCard {
                Text("回测与计划同步", fontWeight = FontWeight.Bold)
                CaptionMuted("图表回测与计划工作台统一使用当前彩种的计划定义；原计划、新计划、候选池、自定义和收藏计划分别筛选，不跨彩种混用。")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    AssistChip(onClick = { chartSource = "收藏计划"; playFilter = "全部"; chartPositionFilter = "全部"; chartSelectedIds = favoritePlans.take(5).map { it.planId } }, label = { Text("★ 收藏 ${favoritePlans.size}") })
                    AssistChip(onClick = { plansExpanded = true }, label = { Text("选择计划") })
                    AssistChip(onClick = { vm.planVM.clearNovaChart(); chartDetail = null }, label = { Text("清空曲线") })
                }
                CaptionMuted("当前：${chartSource} · ${if (playFilter == "全部") "全部玩法" else playFilter}${if (chartPositionFilter != "全部") " · $chartPositionFilter" else ""} · ${stage.coerceIn(1, 3)}期口径 · ${if (chartBetInvert) "反投" else "正投"}")
            }
        }

        item {
            GlobalCard {
                Text("共识预测来源", fontWeight = FontWeight.Bold)
                CaptionMuted("原/新共识回测：大小、单双、组合分类分别一期一计（不再要求三类全对）。")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    val legacyCount = vm.planVM.consensusRecords.value.count { it.result == "对" || it.result == "错" }
                    val novaCount = vm.planVM.novaConsensusRecords.value.count { it.result == "对" || it.result == "错" }
                    AssistChip(onClick = {}, label = { Text("原共识 · 已结算 $legacyCount") })
                    AssistChip(onClick = {}, label = { Text("新共识 · 已结算 $novaCount") })
                }
            }
        }

        if (running) {
            item { LoadingBlock("图表回测计算中，可切换页面，完成后自动更新") }
        }
        if (reports.isEmpty() && !running) {
            item {
                GlobalCard {
                    Text("暂无曲线", fontWeight = FontWeight.Bold)
                    EmptyStateBlock(
                        title = "暂无回测曲线",
                        subtitle = "选择来源与计划后点击「开始回测」。对错率以 50% 为零轴。",
                        actionLabel = "开始回测",
                        onAction = { runBacktest() }
                    )
                }
            }
        } else {
            item {
                val lines = reports.map { r ->
                    "${r.plan.planName} · 命中${UiFormat.pct(r.hitRate)} · 高${UiFormat.pct(r.maxHitRate)}/低${UiFormat.pct(r.minHitRate)} · 盈亏${UiFormat.money(r.netProfit)} · ${r.currentTrend}"
                }
                ConclusionStrip(lines)
            }
            item {
                GlobalCard {
                    Text(
                        if (reports.size == 1) "回测曲线 · $chartMode" else "计划对比曲线 · $chartMode",
                        fontWeight = FontWeight.Bold
                    )
                    CaptionMuted(
                        when (chartMode) {
                            "对错率" -> "零轴=50%对错率；曲线在上方表示优于随机，下方表示劣于随机"
                            "累计收益" -> "绿涨红跌 · 黄虚线最大回撤 · 色带连对/连错"
                            else -> "双指缩放、拖动查看细节；点击曲线查看节点"
                        }
                    )
                    ChartCurve(reports, chartMode) { chartDetail = it }
                    // 多计划图例
                    if (reports.size > 1) {
                        Spacer(Modifier.height(6.dp))
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            reports.forEachIndexed { idx, r ->
                                val c = chartSeriesColor(idx)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(color = c, modifier = Modifier.size(10.dp), shape = MaterialTheme.shapes.extraSmall) {}
                                    Spacer(Modifier.width(4.dp))
                                    Text(r.plan.planName, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }

            item {
                GlobalCard {
                    Text("回测统计", fontWeight = FontWeight.Bold)
                    reports.forEach { r ->
                        Text(r.plan.planName, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp))
                        Text(
                            "${r.periods}期 · 对 ${r.hits} / 错 ${r.misses} · 对错率 ${(r.hitRate * 100).roundToInt()}% · 单注 ${chartFmtMoney(r.stake)}"
                        )
                        Text(
                            "最高对错率 ${(r.maxHitRate * 100).roundToInt()}% · 最低对错率 ${(r.minHitRate * 100).roundToInt()}% · 相对50% ${"%.1f".format((r.hitRate - 0.5) * 100)}pt"
                        )
                        Text(
                            "总投入 ${chartFmtMoney(r.totalStake)} · 净收益 ${chartFmtMoney(r.netProfit)} · 最大回撤 ${chartFmtMoney(r.maxDrawdown)}"
                        )
                        CaptionMuted(
                            "最高点 ${chartFmtMoney(r.maxPeak)} · 最低点 ${chartFmtMoney(r.minTrough)} · 最大连对 ${r.maxHitStreak} · 最大连错 ${r.maxMissStreak}"
                        )
                        if (r.guanguanEnabled) {
                            CaptionMuted(
                                "过关斩将：完成${r.guanguanCompleted}次 · 当前第${r.guanguanCurrentLevel + 1}关 · 历史最高${r.guanguanMaxLevel}关 · 基础注 ${chartFmtMoney(r.stake)} · 组合1:4/其它按实际赔率滚入"
                            )
                        }
                        // 分段：最近 50/100/200
                        val segs = listOf(50, 100, 200)
                        segs.forEach { n ->
                            val tail = r.points.takeLast(n)
                            if (tail.isNotEmpty()) {
                                val h = tail.count { it.hit }
                                val rate = h.toDouble() / tail.size
                                val profit = tail.sumOf { it.periodProfit }
                                CaptionMuted(
                                    "近${tail.size}期：对错率 ${(rate * 100).roundToInt()}% · 盈亏 ${chartFmtMoney(profit)}"
                                )
                            }
                        }
                    }
                }
            }

            item {
                GlobalCard {
                    Text("涨跌趋势分析", fontWeight = FontWeight.Bold)
                    reports.forEach { r ->
                        Text("${r.plan.planName}：${r.currentTrend}", fontWeight = FontWeight.SemiBold)
                        CaptionMuted(
                            "最高点 ${chartFmtMoney(r.maxPeak)} · 最低点 ${chartFmtMoney(r.minTrough)} · 当前 ${chartFmtMoney(r.points.lastOrNull()?.cumulativeProfit ?: 0.0)}"
                        )
                        CaptionMuted(
                            "距最高点 ${chartFmtMoney(r.distanceFromPeak)} · 从最低点反弹 ${chartFmtMoney(r.reboundFromTrough)} · 位置 ${"%.1f".format(r.positionPercent)}%"
                        )
                    }
                }
            }

            if (reports.size >= 2) {
                item {
                    GlobalCard {
                        Text("计划对比分析", fontWeight = FontWeight.Bold)
                        reports.sortedByDescending { it.netProfit }.forEachIndexed { idx, r ->
                            Text("${idx + 1}. ${r.plan.planName}", fontWeight = FontWeight.SemiBold)
                            Text(
                                "对错率 ${(r.hitRate * 100).roundToInt()}%（高 ${(r.maxHitRate * 100).roundToInt()}% / 低 ${(r.minHitRate * 100).roundToInt()}%） · 净收益 ${chartFmtMoney(r.netProfit)} · 回撤 ${chartFmtMoney(r.maxDrawdown)}",
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            item {
                GlobalCard {
                    Text("图表分析报告", fontWeight = FontWeight.Bold)
                    reports.forEach { r ->
                        val cur = r.points.lastOrNull()?.cumulativeProfit ?: 0.0
                        val dir = when {
                            r.netProfit > 0 -> "累计收益为正"
                            r.netProfit < 0 -> "累计收益为负"
                            else -> "累计收益持平"
                        }
                        val rateDir = when {
                            r.hitRate > 0.5 -> "对错率高于随机50%"
                            r.hitRate < 0.5 -> "对错率低于随机50%"
                            else -> "对错率接近随机50%"
                        }
                        Text(r.plan.planName, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp))
                        Text("整体：$dir；回测 ${r.periods} 个单元，对错率 ${(r.hitRate * 100).roundToInt()}%，$rateDir。")
                        Text(
                            "对错率区间：最高 ${(r.maxHitRate * 100).roundToInt()}% · 最低 ${(r.minHitRate * 100).roundToInt()}% · 终值 ${(r.hitRate * 100).roundToInt()}%。"
                        )
                        Text("收益：总投入 ${chartFmtMoney(r.totalStake)}，净收益 ${chartFmtMoney(r.netProfit)}，最高 ${chartFmtMoney(r.maxPeak)}，最低 ${chartFmtMoney(r.minTrough)}。")
                        Text("趋势：${r.currentTrend}；当前 ${chartFmtMoney(cur)}，最大回撤 ${chartFmtMoney(r.maxDrawdown)}。")
                        Text("风险：最大连对 ${r.maxHitStreak}，最大连错 ${r.maxMissStreak}。")
                    }
                }
            }

            item {
                GlobalCard {
                    Text("完整回测明细", fontWeight = FontWeight.Bold)
                    CaptionMuted("按计划/分类分开展示；玩法列显示大小·单双·组合等，避免误读成全部是大小")
                    reports.forEach { r ->
                        val play = r.plan.playType.ifBlank { "—" }
                        val dir = if (chartBetInvert) "反投" else "正投"
                        Text(
                            "${r.plan.planName} · $play · $dir",
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                        // 限制条数 + key，减轻滑动卡顿
                        r.points.asReversed().take(40).forEach { pt ->
                            Row(
                                Modifier.fillMaxWidth().padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    "${pt.issue} · [$play] ${pt.prediction} · ${if (pt.hit) "对" else "错"} · ${(pt.hitRate * 100).roundToInt()}%",
                                    fontSize = 11.sp,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(chartFmtMoney(pt.periodProfit), fontSize = 11.sp, modifier = Modifier.width(70.dp))
                                Text(chartFmtMoney(pt.cumulativeProfit), fontSize = 11.sp, modifier = Modifier.width(80.dp))
                            }
                        }
                        if (r.points.size > 40) CaptionMuted("仅显示最近 40 条，共 ${r.points.size} 条 · $play")
                    }
                }
            }
        }
    }
}
