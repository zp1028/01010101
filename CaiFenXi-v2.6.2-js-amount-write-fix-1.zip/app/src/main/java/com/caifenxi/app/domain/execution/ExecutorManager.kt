package com.caifenxi.app.domain.execution

import com.caifenxi.app.util.RuntimeLog

/**
 * 执行器统一管理器。
 *
 * 主路径：WebView DOM 执行器（selector 精确点击（未完成标注则拒绝执行））
 * 降级链：webview → accessibility → ai_vision
 *
 * 执行失败时自动降级到下一个可用执行器，直到全部失败才返回错误。
 */
object ExecutorManager {

    private val executors = LinkedHashMap<String, Executor>()

    @Volatile
    private var mode: String = "webview"

    /** 执行器降级链顺序：WebView DOM 标注点击 → 无障碍 → AI 视觉（已彻底移除 API 注入） */
    private val fallbackOrder = listOf("webview", "accessibility", "ai_vision")

    /** 不触发降级的结果码（这些错误重试别的执行器也没意义） */
    private val noFallbackErrors = setOf(
        ExecutionResult.DUPLICATE_COMMAND,
        ExecutionResult.COMMAND_EXPIRED,
        ExecutionResult.CANCELLED,
        ExecutionResult.UNKNOWN_RESULT,
        ExecutionResult.TIMEOUT,
        // v2.5.3: 确认已点击但结果未知，绝不降级（网站可能已实际下单）
        ExecutionResult.COMMITTED_UNKNOWN
    )

    /** 注册执行器（App 启动时调用） */
    fun register(executor: Executor) {
        if (executor.id.isBlank()) return
        executors[executor.id] = executor
        RuntimeLog.info("Execution", "注册执行器 ${executor.id}")
    }

    /** 注销执行器（服务销毁时调用） */
    fun unregister(executorId: String) {
        if (executors.remove(executorId) != null) {
            RuntimeLog.info("Execution", "注销执行器 $executorId")
        }
    }

    fun setMode(newMode: String) {
        // 已移除 api_inject，强制回落到 webview
        mode = if (newMode == "api_inject") "webview" else newMode
        RuntimeLog.info("Execution", "执行模式切换为 $mode")
    }

    fun getMode(): String = mode

    /** 按降级链返回当前可用的执行器列表 */
    fun pickChain(): List<Executor> = when (mode) {
        "webview" -> listOfNotNull(executors["webview"]?.takeIf { it.isAvailable })
        "accessibility" -> listOfNotNull(executors["accessibility"]?.takeIf { it.isAvailable })
        "ai_vision" -> listOfNotNull(executors["ai_vision"]?.takeIf { it.isAvailable })
        else -> fallbackOrder.mapNotNull { id -> executors[id]?.takeIf { it.isAvailable } }
    }

    /** 兼容旧调用：返回首个可用执行器 */
    fun pick(): Executor? = pickChain().firstOrNull()

    fun pickOrNull(): Executor? = pick()

    /**
     * 执行统一指令，带降级 fallback。
     *
     * 尝试顺序：webview → accessibility → ai_vision
     * 某个执行器返回失败且不属于 noFallbackErrors 时，自动降级到下一个。
     *
     * @return true 表示已受理；false 表示当前没有可用执行器。
     */
    fun execute(command: BetCommand, onResult: (ExecutionResult) -> Unit): Boolean {
        val manualTest = command.options["manualTest"] == "1" || command.options["manualTest"] == "true"
        if (!manualTest && !ExecutionSafetyGate.isArmed(command.lotteryKey)) {
            RuntimeLog.warn("SafetyGate", "统一执行入口拒绝生产工单：当前彩种挂机会话未启动 cmdId=${command.cmdId}")
            onResult(
                ExecutionResult.fail(
                    command.cmdId,
                    ExecutionResult.CANCELLED,
                    "当前彩种挂机未启动：真实执行已被安全总闸拦截"
                )
            )
            return false
        }
        if (!manualTest && !ExecutionTicketStore.claimIssue(command.lotteryKey, command.issue)) {
            RuntimeLog.warn("Execution", "同期已被占用/已完成/已确认，拒绝重复执行 ${command.lotteryKey}/${command.issue}")
            onResult(ExecutionResult.fail(command.cmdId, ExecutionResult.DUPLICATE_COMMAND, "本期已有执行任务或已完成或已确认点击，拒绝重复执行"))
            return false
        }
        // v2.5.3: 确认按钮已点击过的期号，绝对拒绝再次执行（无论何种入口）
        if (!manualTest && ExecutionTicketStore.isIssueConfirmed(command.lotteryKey, command.issue)) {
            RuntimeLog.warn("Execution", "同期已确认点击过，永久锁定拒绝执行 ${command.lotteryKey}/${command.issue}")
            onResult(ExecutionResult.fail(command.cmdId, ExecutionResult.DUPLICATE_COMMAND, "本期确认按钮已点击过，永久锁定，拒绝再次执行"))
            return false
        }
        val chain = pickChain()
        if (!manualTest && chain.isEmpty()) {
            ExecutionTicketStore.releaseIssue(command.lotteryKey, command.issue)
        }
        if (chain.isEmpty()) {
            RuntimeLog.warn("Execution", "无可用执行器 cmdId=${command.cmdId}，任务挂起等待")
            return false
        }
        RuntimeLog.info(
            "Execution",
            "执行链 [${chain.joinToString { it.id }}] cmdId=${command.cmdId} 彩种=${command.lotteryKey} 期号=${command.issue}"
        )
        executeWithFallback(command, chain, 0, onResult)
        return true
    }

    private fun executeWithFallback(
        command: BetCommand,
        chain: List<Executor>,
        index: Int,
        onResult: (ExecutionResult) -> Unit
    ) {
        if (index >= chain.size) {
            ExecutionTicketStore.releaseIssue(command.lotteryKey, command.issue)
            onResult(
                ExecutionResult.fail(
                    command.cmdId,
                    ExecutionResult.ACTION_FAILED,
                    "所有执行器均失败"
                )
            )
            return
        }

        val executor = chain[index]
        RuntimeLog.info("Execution", "尝试执行器 ${executor.id} (idx=$index) cmdId=${command.cmdId}")
        var callbackDelivered = false

        val accepted = executor.execute(command) { result ->
            callbackDelivered = true
            RuntimeLog.info(
                "Execution",
                "执行器 ${executor.id} 返回 cmdId=${result.cmdId} success=${result.success} code=${result.code} ${result.message}"
            )

            if (result.success) {
                onResult(result)
                return@execute
            }

            // v2.5.3: COMMITTED_UNKNOWN — 确认已点击但结果未知，绝不降级，不释放锁
            if (result.errorType == ExecutionResult.COMMITTED_UNKNOWN) {
                RuntimeLog.warn(
                    "Execution",
                    "${executor.id} 返回 COMMITTED_UNKNOWN，确认已点击不降级、不释放锁 cmdId=${command.cmdId}"
                )
                onResult(result)
                return@execute
            }

            // v2.5.3: 确认按钮已点击 → 本期永久锁定，绝不降级到其他执行器
            if (ExecutionTicketStore.isIssueConfirmed(command.lotteryKey, command.issue)) {
                RuntimeLog.warn(
                    "Execution",
                    "${executor.id} 返回失败但本期已确认点击，永久锁定不降级 cmdId=${command.cmdId}"
                )
                onResult(result)
                return@execute
            }

            // UNKNOWN/TIMEOUT/COMMITTED_UNKNOWN 代表可能已经提交但无法确认：保持期号锁，绝不自动换执行器/重试。
            if (result.errorType in noFallbackErrors) {
                if (result.errorType != ExecutionResult.UNKNOWN_RESULT &&
                    result.errorType != ExecutionResult.TIMEOUT &&
                    result.errorType != ExecutionResult.COMMITTED_UNKNOWN) {
                    ExecutionTicketStore.releaseIssue(command.lotteryKey, command.issue)
                }
                onResult(result)
                return@execute
            }

            if (index < chain.size - 1) {
                RuntimeLog.warn(
                    "Execution",
                    "${executor.id} 失败(${result.errorType})，降级到 ${chain[index + 1].id} cmdId=${command.cmdId}"
                )
                executeWithFallback(command, chain, index + 1, onResult)
            } else {
                ExecutionTicketStore.releaseIssue(command.lotteryKey, command.issue)
                onResult(result)
            }
        }

        // execute() 可能已经通过 callback 报告了拒绝，再返回 false；这种情况不能再次回调或重复降级。
        if (!accepted && !callbackDelivered) {
            RuntimeLog.warn(
                "Execution",
                "${executor.id} 未接受任务，降级 cmdId=${command.cmdId}"
            )
            if (index < chain.size - 1) {
                executeWithFallback(command, chain, index + 1, onResult)
            } else {
                ExecutionTicketStore.releaseIssue(command.lotteryKey, command.issue)
                onResult(
                    ExecutionResult.fail(
                        command.cmdId,
                        ExecutionResult.WEBVIEW_DISCONNECTED,
                        "无执行器接受任务"
                    )
                )
            }
        }
    }

    fun isAvailable(executorId: String): Boolean =
        executors[executorId]?.isAvailable == true

    fun availableExecutorIds(): List<String> = executors.values.filter { it.isAvailable }.map { it.id }

    fun queryState(cmdId: String): ExecutionResult? {
        for (e in executors.values) {
            e.queryState(cmdId)?.let { return it }
        }
        return null
    }

    fun cancel(cmdId: String) {
        executors.values.forEach { it.cancel(cmdId) }
    }

    fun clear() {
        executors.clear()
    }
}
