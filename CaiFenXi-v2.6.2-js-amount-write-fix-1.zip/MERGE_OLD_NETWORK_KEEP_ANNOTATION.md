# 合并说明：旧版网络路径 + 当前多套标注

## 原则
以「完整好1」能正常打开站点的 WebView 网络行为为基准，保留当前版组合/直选/数字等标注能力。

## 已对齐旧版的网络路径
- 删除 CORS 代理类、OkHttp 转发、fetch/XHR 劫持脚本
- 删除 shouldInterceptRequest（OPTIONS 伪造、data 拦截等）
- onPageStarted / onPageFinished：只更新状态 + 必要时重注标注 JS，不注入任何网络脚本
- 错误处理：仅主框架错误提示；子资源失败不自动 reload
- cacheMode：`LOAD_CACHE_ELSE_NETWORK`（与旧版一致）
- UA：Chrome 120 Mobile（与旧版一致）
- 取消首次进入 clearCache + LOAD_NO_CACHE
- minSdk 恢复 24

## 保留的当前能力
- 大小单双 / 组合 / 直选 / 数字 多套标注
- 更稳的 selector 生成与幂等标注绑定
- 无 API 注入下单
- Gradle Wrapper 完整

## versionCode
49
