# 彻底移除 API 下单功能

## 变更说明
按用户要求，已完全删除 API 注入下单相关代码，仅保留「标注点击」下单路径。

## 已删除文件
- `ApiInjectExecutor.kt` — API 注入执行器
- `ApiMappingStore.kt` — API 映射表学习与存储
- `TokenManager.kt` — Token 提取与缓存
- `NetworkLogStore.kt` — 网络请求日志（仅服务于 API 映射学习）

## 已清理代码
- `ExecutorManager`：移除 api_inject 降级链与模式
- `CaiFenXiApplication`：取消 API 执行器注册
- `WebBetScreen`：删除 API 投注开关、就绪轮询、通知弹窗、网络日志采集
- `cfx_inject.js`：移除 XHR/fetch 拦截与日志导出（改为空桩）

## 保留功能
- WebView DOM 标注点击下单（主路径）
- 无障碍点击
- AI 视觉点击
- CORS 代理（帮助 SPA 站点正常加载，与 API 下单无关）

默认执行模式固定为 `webview`（标注点击）。
