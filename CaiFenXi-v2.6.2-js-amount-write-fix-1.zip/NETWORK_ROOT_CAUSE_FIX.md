# 网络异常 —— 根因排查与修复

## 用户现象
网页执行台打开投注站后出现：
- 网路环境发生错误
- 网络异常，请重启浏览器
- 已断开网络连接
- 载入页面异常

## 排查结论（按风险排序）

### 1. 【主因】CORS 代理劫持 fetch/XHR（已禁用）
**机制**：页面加载时注入 JS，把跨域 POST/PUT/DELETE（及带 JSON 的 GET）转发到 Android `OkHttp`。

**为何会导致「网络异常」**：
- OkHttp **拿不到 WebView 的 Cookie**，登录态/会话丢失
- 不带浏览器真实 `User-Agent / Origin / Referer` 指纹
- 同步阻塞 JS 线程，超时即被站点前端判为网络失败
- 返回体被强套成 `application/json` Blob，非 JSON 接口直接坏掉

站点前端一旦接口失败，就会弹出自有文案：「网络异常 / 请重启浏览器」等。

### 2. 【主因】伪造 OPTIONS 预检响应（已移除）
`shouldInterceptRequest` 对所有 OPTIONS（以及 URL 含 `__un=`）直接返回 200，并设置：
- `Access-Control-Allow-Origin: *`
- `Access-Control-Allow-Credentials: true`

**规范上二者不能同时使用**，真实浏览器会拒绝后续带 Cookie 的跨域请求，表现为登录/下单接口「网络失败」。

### 3. 【次要，已处理过】自动 reload / 多轮 SPA 探测
短时间多次整页刷新会被风控识别。此前已改为被动探测、禁止脚本失败自动刷新。

### 4. 【次要】API 注入下单（已删除）
曾用页面内 fetch 堆积请求，加重限流与超时。

### 5. 【通常不是主因】
- UA 已模拟 Chrome 移动端
- Cookie 已允许第三方
- 硬件加速 / 调试开关
- cfx_inject 仅在下单执行时注入，不常驻劫持网络

## 本次修复
1. `CORS_PROXY_JS` → 空脚本，**不再劫持任何 fetch/XHR**
2. `shouldInterceptRequest` → **不再伪造 OPTIONS**，只保留 data URI 兼容
3. WebView 网络路径尽量接近系统浏览器

## 验证建议
1. 打开网页执行台 → 进入投注站登录页
2. 登录应不再立刻报「网络异常」
3. 若仍报错：换系统浏览器打开同一网址对比
   - 浏览器也报错 → 站点/线路/地区限制，非 App 问题
   - 仅 App 报错 → 把站点域名与是否必须跨域登录告知，再单独评估
