# 构建失败修复：GradleWrapperMain 找不到

## 错误
```
Error: Could not find or load main class org.gradle.wrapper.GradleWrapperMain
Caused by: java.lang.ClassNotFoundException: org.gradle.wrapper.GradleWrapperMain
```

## 原因
发布的源码 ZIP 中缺少完整 Gradle Wrapper 目录：
- `gradle/wrapper/gradle-wrapper.jar`（必须包含 `org.gradle.wrapper.GradleWrapperMain`）
- `gradle/wrapper/gradle-wrapper.properties`
- `gradle/libs.versions.toml`（版本目录）

仅有 `gradlew` 脚本不够，`./gradlew` 依赖上述 jar。

## 本包已补齐
- `gradle/wrapper/gradle-wrapper.jar`
- `gradle/wrapper/gradle-wrapper.properties`（Gradle 8.9）
- `gradle/libs.versions.toml`
- `app/src/main/res/**` 资源
- 此前因 ZIP 不完整可能缺失的 `util` / `domain/plan` / `domain/strategy` / `work` 源码

## CI 建议
1. 确认仓库中提交了 `gradle/wrapper/gradle-wrapper.jar`（不要被 .gitignore 忽略）
2. 或在 workflow 中在构建前执行：
   ```bash
   mkdir -p gradle/wrapper
   # 若 jar 缺失，可用 gradle-setup.sh 或 gradle wrapper 重新生成
   chmod +x gradlew
   ./gradlew assembleDebug
   ```
