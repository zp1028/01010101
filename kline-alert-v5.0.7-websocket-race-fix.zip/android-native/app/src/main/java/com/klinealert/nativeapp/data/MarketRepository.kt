package com.klinealert.nativeapp.data

import com.klinealert.nativeapp.domain.Analysis
import com.klinealert.nativeapp.domain.AnalysisEngine
import com.klinealert.nativeapp.domain.Candle
import com.klinealert.nativeapp.domain.OpportunityFusion
import com.klinealert.nativeapp.domain.SymbolOpportunity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Dispatcher
import okhttp3.Request
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.concurrent.ConcurrentHashMap

class MarketRepository {
    private val dispatcher = Dispatcher().apply { maxRequests = 64; maxRequestsPerHost = 64 }
    // Active WebSocket heartbeat: OkHttp sends Ping frames and expects Pong replies.
    // A missed Pong fails the socket so the ViewModel can enter its reconnect path.
    private val client = OkHttpClient.Builder()
        .dispatcher(dispatcher)
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()
    // Keep aggregate REST traffic below exchange weight limits during all-market scans.
    private val requestGate = Mutex()
    private var lastRequestAt = 0L
    private suspend fun throttleRequests() {
        requestGate.withLock {
            val now = System.currentTimeMillis()
            val wait = 250L - (now - lastRequestAt)
            if (wait > 0) delay(wait)
            lastRequestAt = System.currentTimeMillis()
        }
    }
    data class Instrument(val symbol: String, val market: String, val quoteVolume: Double)
    data class LivePrice(val price: Double, val changePct: Double, val eventTime: Long)
    data class ScanOutcome(val results: List<Analysis>, val failed: Int, val universeSize: Int, val symbols: List<String>)
    private val candleHistories = ConcurrentHashMap<String, List<Candle>>()
    private fun historyKey(symbol: String, market: String, timeframe: String) = "$market|$timeframe|$symbol"
    fun cachedCandles(symbol: String, market: String, timeframe: String): List<Candle> = candleHistories[historyKey(symbol, market, timeframe)].orEmpty()
    fun clearCandleCache() = candleHistories.clear()

    /**
     * Spot WebSocket host with mirror failover. stream.binance.com:9443 is often unreachable
     * on CN networks; data-stream.binance.vision is Binance's official market-data-only mirror.
     * Once a socket failure is seen we prefer the mirror until it fails in turn.
     */
    @Volatile private var preferSpotMirror = false
    private fun spotWsFailure() { preferSpotMirror = true }
    private fun spotWsHost(streamPath: String): String =
        (if (preferSpotMirror) "wss://data-stream.binance.vision" else "wss://stream.binance.com:9443") + streamPath

    private suspend fun get(url: String): String = withContext(Dispatchers.IO) {
        suspend fun executeWithRetry(target: String): String {
            var last: Exception? = null
            for (attempt in 0..2) {
                try {
                    throttleRequests()
                    val req = Request.Builder().url(target).header("User-Agent", "KlineAlertAndroid/1.0").build()
                    client.newCall(req).execute().use { response ->
                        if (response.isSuccessful) return response.body?.string() ?: error("Empty response")
                        val retryable = response.code == 418 || response.code == 429 || response.code in 500..599
                        val retryAfter = response.header("Retry-After")?.toLongOrNull()?.coerceIn(1, 5)
                        val detail = "HTTP ${response.code}: $target" + if (retryAfter != null) " (Retry-After $retryAfter s)" else ""
                        if (!retryable || attempt == 2) error(detail)
                        throw java.io.IOException(detail)
                    }
                } catch (e: CancellationException) {
                    // A foreground stop or market/timeframe switch must cancel REST work immediately.
                    throw e
                } catch (e: Exception) {
                    last = e
                    if (attempt == 2) throw e
                    val status = Regex("HTTP (\\d+)").find(e.message.orEmpty())?.groupValues?.getOrNull(1)?.toIntOrNull()
                    if (status != null && status !in listOf(418, 429) && status !in 500..599) throw e
                    val retryAfter = Regex("Retry-After (\\d+) s").find(e.message.orEmpty())?.groupValues?.getOrNull(1)?.toLongOrNull()
                    delay((retryAfter?.coerceIn(1, 5) ?: (1L shl attempt)) * 1000L)
                }
            }
            throw last ?: IllegalStateException("Request failed: $target")
        }
        try { executeWithRetry(url) } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (first: Exception) {
            // Public spot market-data mirror fallback for networks where api.binance.com is unavailable.
            if (url.startsWith("https://api.binance.com/api/v3/")) {
                executeWithRetry(url.replace("https://api.binance.com/api/v3/", "https://data-api.binance.vision/api/v3/"))
            } else throw first
        }
    }

    suspend fun instruments(market: String): List<Instrument> {
        val futures = market == "PERP"
        val infoUrl = if (futures) "https://fapi.binance.com/fapi/v1/exchangeInfo" else "https://api.binance.com/api/v3/exchangeInfo"
        val tickersUrl = if (futures) "https://fapi.binance.com/fapi/v1/ticker/24hr" else "https://api.binance.com/api/v3/ticker/24hr"
        val info = JSONObject(get(infoUrl)).getJSONArray("symbols")
        val volumes = try {
            val a = JSONArray(get(tickersUrl))
            buildMap<String, Double> {
                for (i in 0 until a.length()) {
                    val t = a.getJSONObject(i)
                    put(t.optString("symbol"), t.optString("quoteVolume").toDoubleOrNull() ?: 0.0)
                }
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            // Discovery still works when 24h ticker volume endpoint is temporarily unavailable.
            emptyMap()
        }
        val result = ArrayList<Instrument>()
        for (i in 0 until info.length()) {
            val s = info.getJSONObject(i)
            if (s.optString("status") != "TRADING") continue
            // Both markets deliberately resolve to USDT-quoted instruments only: quote volumes
            // across different quote assets are not directly comparable, and mixing them would
            // distort the liquidity ranking and cross-symbol volume-ratio signals.
            if (s.optString("quoteAsset") != "USDT") continue
            if (futures && s.optString("contractType") != "PERPETUAL") continue
            val base = s.optString("baseAsset").uppercase()
            val excludedBases = setOf("USDC", "FDUSD", "TUSD", "BUSD", "DAI", "USDP", "USD1", "USDE", "XUSD", "AEUR", "EUR", "EURI", "PYUSD", "USDY", "BSCUSD", "USDX")
            if (base.isBlank() || base in excludedBases || listOf("UP", "DOWN", "BULL", "BEAR").any { base.endsWith(it) }) continue
            val symbol = s.optString("symbol")
            result += Instrument(symbol, market, volumes[symbol] ?: 0.0)
        }
        return result.sortedByDescending { it.quoteVolume }
    }

    suspend fun candles(symbol: String, market: String, timeframe: String, limit: Int = 300): List<Candle> {
        require(timeframe in AnalysisEngine.supportedTimeframes) { "Unsupported timeframe $timeframe" }
        val futures = market == "PERP"
        val base = if (futures) "https://fapi.binance.com/fapi/v1/klines" else "https://api.binance.com/api/v3/klines"
        val json = JSONArray(get("$base?symbol=$symbol&interval=$timeframe&limit=$limit"))
        val parsed = buildList {
            for (i in 0 until json.length()) {
                val row = json.getJSONArray(i)
                add(Candle(row.getLong(0), row.getString(1).toDouble(), row.getString(2).toDouble(), row.getString(3).toDouble(), row.getString(4).toDouble(), row.getString(5).toDouble(), row.getLong(6)))
            }
        }
        candleHistories[historyKey(symbol, market, timeframe)] = parsed.takeLast(300)
        return parsed
    }

    suspend fun scan(market: String, timeframe: String, onProgress: (Int, Int) -> Unit): ScanOutcome {
        val universe = instruments(market)
        val sem = Semaphore(3)
        var finished = 0
        val firstPassFailures = java.util.concurrent.ConcurrentLinkedQueue<Instrument>()
        val out = java.util.concurrent.ConcurrentLinkedQueue<Analysis>()
        // Batch scheduling avoids creating thousands of coroutines at once and smooths API load.
        for (batch in universe.chunked(12)) {
            coroutineScope {
                batch.map { instrument -> async(Dispatchers.IO) {
                    sem.withPermit {
                        try {
                            analyze(instrument.symbol, market, timeframe)?.let(out::add)
                        } catch (e: CancellationException) {
                            throw e
                        } catch (_: Exception) {
                            firstPassFailures.add(instrument)
                        } finally {
                            val done = synchronized(this@MarketRepository) { ++finished }
                            if (done % 5 == 0 || done == universe.size) onProgress(done, universe.size)
                        }
                    }
                } }.awaitAll()
            }
            if (finished < universe.size) delay(150)
        }

        // Retry only transport/data failures once, after the first pass, so one transient
        // timeout does not silently remove a symbol from the opportunity scan.
        var failed = 0
        val retryQueue = firstPassFailures.toList()
        for (batch in retryQueue.chunked(6)) {
            coroutineScope {
                batch.map { instrument -> async(Dispatchers.IO) {
                    sem.withPermit {
                        delay(350)
                        try {
                            analyze(instrument.symbol, market, timeframe)?.let(out::add)
                        } catch (e: CancellationException) {
                            throw e
                        } catch (_: Exception) {
                            synchronized(this@MarketRepository) { failed++ }
                        }
                    }
                } }.awaitAll()
            }
            if (batch.size == 6) delay(500)
        }
        return ScanOutcome(out.toList().distinctBy { it.symbol }.sortedByDescending { it.score }, failed, universe.size, universe.map { it.symbol })
    }

    suspend fun analyze(symbol: String, market: String, timeframe: String): Analysis? =
        AnalysisEngine.analyze(symbol, market, timeframe, candles(symbol, market, timeframe))

    data class SymbolScanOutcome(
        val symbols: List<SymbolOpportunity>,
        val failedSymbols: Int,
        val universeSize: Int,
        val universe: List<String>
    )

    /**
     * 品种统一扫描：每个品种并行拉取所有所选周期的 K 线并分析，
     * 由 OpportunityFusion 融合成一张品种卡——不再按周期递进互相覆盖。
     * 失败语义：网络/HTTP 异常的品种进入二次重试，重试仍失败才计入 failedSymbols；
     * K线历史不足（新币/冷门币 analyze 返回 null）不算失败，静默跳过。
     */
    suspend fun scanSymbols(market: String, timeframes: List<String>, onProgress: (Int, Int) -> Unit, learned: Map<String, Double> = emptyMap(), patternBonus: Map<String, Int> = emptyMap()): SymbolScanOutcome {
        val universe = instruments(market)
        val tfs = timeframes.distinct().filter { it in AnalysisEngine.supportedTimeframes }.ifEmpty { listOf("15m") }
        val sem = Semaphore(4)
        var finished = 0
        val failures = java.util.concurrent.ConcurrentLinkedQueue<String>()
        val found = java.util.concurrent.ConcurrentLinkedQueue<SymbolOpportunity>()

        suspend fun scanOne(instrument: com.klinealert.nativeapp.data.MarketRepository.Instrument, isRetry: Boolean): Boolean {
            var hadError = false
            val per = LinkedHashMap<String, Analysis?>()
            for (tf in tfs) {
                per[tf] = try { analyze(instrument.symbol, market, tf) } catch (e: CancellationException) { throw e } catch (_: Exception) { hadError = true; null }
            }
            val anyAnalysis = per.values.any { it != null }
            if (anyAnalysis) {
                OpportunityFusion.fuse(instrument.symbol, market, per.filterValues { it != null }.mapValues { it.value!! }, learned, patternBonus)?.let(found::add)
                return true
            }
            // 全部周期无结果：有过网络异常 → 需要重试；纯数据不足 → 静默跳过
            return !(hadError && !isRetry)
        }

        suspend fun runPass(batchGroups: List<List<Instrument>>, passDelay: Long, isRetry: Boolean, trackRetry: (java.util.concurrent.ConcurrentLinkedQueue<Instrument>, Instrument) -> Unit = { _, _ -> }) {
            val retryQueue = java.util.concurrent.ConcurrentLinkedQueue<Instrument>()
            for (batch in batchGroups) {
                coroutineScope {
                    batch.map { instrument -> async(Dispatchers.IO) {
                        sem.withPermit {
                            if (isRetry) delay(350)
                            val ok = runCatching { scanOne(instrument, isRetry) }.getOrDefault(false)
                            if (!ok) {
                                if (!isRetry) trackRetry(retryQueue, instrument)
                                else failures.add(instrument.symbol)
                            }
                            if (!isRetry) {
                                val done = synchronized(this@MarketRepository) { ++finished }
                                if (done % 5 == 0 || done == universe.size) onProgress(done, universe.size)
                            }
                        }
                    } }.awaitAll()
                }
                if (finished < universe.size || isRetry) delay(passDelay)
            }
            if (!isRetry && retryQueue.isNotEmpty()) runPass(retryQueue.toList().chunked(6), 500, true)
        }
        runPass(universe.chunked(6), 200, false)
        return SymbolScanOutcome(
            symbols = found.toList().distinctBy { it.symbol }.sortedByDescending { it.score },
            failedSymbols = failures.size,
            universeSize = universe.size,
            universe = universe.map { it.symbol }
        )
    }

    /**
     * Foreground-only combined K-line streams for the discovered universe. Chunks are intentionally
     * bounded so one huge URL/socket is not used for thousands of instruments.
     * Callback fires for updates to the current candle; callers should analyze only on a new openTime.
     */
    fun watchUniverseKlines(
        symbols: List<String>, market: String, timeframe: String,
        onCandle: (String, Candle, List<Candle>) -> Unit,
        onError: (String) -> Unit = {}
    ): List<WebSocket> {
        require(timeframe in AnalysisEngine.supportedTimeframes)
        val host = if (market == "PERP") "wss://fstream.binance.com/stream?streams=" else spotWsHost("/stream?streams=")
        return symbols.distinct().chunked(100).mapNotNull { group ->
            if (group.isEmpty()) return@mapNotNull null
            val streams = group.joinToString("/") { "${it.lowercase()}@kline_${timeframe.lowercase()}" }
            val request = Request.Builder().url(host + streams).build()
            client.newWebSocket(request, object : WebSocketListener() {
                override fun onMessage(webSocket: WebSocket, text: String) {
                    runCatching {
                        val root = JSONObject(text)
                        val payload = root.optJSONObject("data") ?: root
                        val symbol = payload.optString("s").uppercase()
                        if (symbol.isBlank()) return
                        val k = payload.getJSONObject("k")
                        val candle = Candle(k.getLong("t"), k.getString("o").toDouble(), k.getString("h").toDouble(), k.getString("l").toDouble(), k.getString("c").toDouble(), k.getString("v").toDouble(), k.getLong("T"))
                        val key = historyKey(symbol, market, timeframe)
                        val history = candleHistories.compute(key) { _, existing ->
                            val old = existing.orEmpty()
                            when {
                                old.isEmpty() -> listOf(candle)
                                old.last().openTime == candle.openTime -> old.dropLast(1) + candle
                                candle.openTime > old.last().openTime -> (old + candle).takeLast(300)
                                else -> old
                            }
                        }.orEmpty()
                        onCandle(symbol, candle, history)
                    }.onFailure { onError("universe kline parse: ${it.message ?: "invalid payload"}") }
                }
                override fun onMessage(webSocket: WebSocket, bytes: ByteString) = Unit
                override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { onError("universe websocket closed ($code): $reason") }
                override fun onFailure(webSocket: WebSocket, t: Throwable, response: okhttp3.Response?) {
                    spotWsFailure()
                    val cause = t.message?.takeIf { it.isNotBlank() } ?: t.javaClass.simpleName
                    val http = response?.let { "; HTTP ${it.code}${it.message.takeIf(String::isNotBlank)?.let { m -> " $m" } ?: ""}" } ?: ""
                    onError("universe websocket failure: $cause$http")
                }
            })
        }
    }

    /** Combined foreground ticker stream for locally tracked positions; avoids one socket per symbol. */
    fun watchPositionTickers(
        symbols: List<String>, market: String,
        onPrice: (String, LivePrice) -> Unit,
        onError: (String) -> Unit = {}
    ): List<WebSocket> {
        val host = if (market == "PERP") "wss://fstream.binance.com/stream?streams=" else spotWsHost("/stream?streams=")
        return symbols.map { it.uppercase() }.distinct().chunked(100).mapNotNull { group ->
            if (group.isEmpty()) return@mapNotNull null
            val streams = group.joinToString("/") { "${it.lowercase()}@ticker" }
            client.newWebSocket(Request.Builder().url(host + streams).build(), object : WebSocketListener() {
                override fun onMessage(webSocket: WebSocket, text: String) {
                    runCatching {
                        val root = JSONObject(text)
                        val j = root.optJSONObject("data") ?: root
                        val symbol = j.optString("s").uppercase()
                        if (symbol.isBlank()) return
                        onPrice(symbol, LivePrice(j.getString("c").toDouble(), j.getString("P").toDouble(), j.optLong("E", System.currentTimeMillis())))
                    }.onFailure { onError("position ticker parse: ${it.message ?: "invalid payload"}") }
                }
                override fun onMessage(webSocket: WebSocket, bytes: ByteString) = Unit
                override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { onError("position ticker websocket closed ($code): $reason") }
                override fun onFailure(webSocket: WebSocket, t: Throwable, response: okhttp3.Response?) {
                    spotWsFailure()
                    val detail = t.message?.takeIf { it.isNotBlank() } ?: "${t.javaClass.simpleName}: position ticker websocket failure"
                    onError(detail)
                }
            })
        }
    }

    fun watchTicker(symbol: String, market: String, onPrice: (LivePrice) -> Unit, onError: (String) -> Unit = {}): WebSocket {
        val lower = symbol.lowercase()
        val url = if (market == "PERP") "wss://fstream.binance.com/ws/${lower}@ticker" else spotWsHost("/ws/${lower}@ticker")
        return client.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onMessage(webSocket: WebSocket, text: String) {
                runCatching {
                    val j = JSONObject(text)
                    onPrice(LivePrice(j.getString("c").toDouble(), j.getString("P").toDouble(), j.optLong("E", System.currentTimeMillis())))
                }
            }
            override fun onMessage(webSocket: WebSocket, bytes: ByteString) = Unit
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { onError("ticker websocket closed ($code): $reason") }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: okhttp3.Response?) { spotWsFailure(); onError(t.message ?: "ticker websocket failure") }
        })
    }
    fun watchKline(symbol: String, market: String, timeframe: String, onCandle: (Candle, Boolean) -> Unit, onError: (String) -> Unit = {}): WebSocket {
        require(timeframe in AnalysisEngine.supportedTimeframes)
        val lower = symbol.lowercase()
        val interval = timeframe.lowercase()
        val url = if (market == "PERP") "wss://fstream.binance.com/ws/${lower}@kline_${interval}" else spotWsHost("/ws/${lower}@kline_${interval}")
        return client.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onMessage(webSocket: WebSocket, text: String) {
                runCatching {
                    val root = JSONObject(text)
                    val k = root.getJSONObject("k")
                    val candle = Candle(k.getLong("t"), k.getString("o").toDouble(), k.getString("h").toDouble(), k.getString("l").toDouble(), k.getString("c").toDouble(), k.getString("v").toDouble(), k.getLong("T"))
                    onCandle(candle, k.optBoolean("x", false))
                }
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { onError("kline websocket closed ($code): $reason") }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: okhttp3.Response?) { spotWsFailure(); onError(t.message ?: "kline websocket failure") }
        })
    }

}
