## v5.0.18 目标分档可调可切 + 工作台统计图表（参数入口 / 单笔切档 / 台账可视化）

承接 v5.0.17「开仓即定档（稳健 2R / 进取 3R）」，本版把分档从**写死的规则**变成**可调、可切、可复盘**：参数在设置页可调并持久化、单笔持仓可一键切档重算目标、平仓台账按档位/来源/原因出图表。

- **分档参数调节入口**（设置页「目标分档」区块，全部持久化）：全局模式 **自动 / 全部稳健 / 全部进取**；稳健目标 R、进取目标 R、进取档保本线 R、进取档质量分门槛、量比门槛、ADX 门槛，六个参数实时可调 +「恢复默认」。所有输入统一经 `TargetTier.sanitize` 夹紧到安全区间（稳健 R 1–6、进取 R 1–10、保本 R 1–6、质量分 50–95、量比 1.0–3.0、ADX 10–40），越界不会写坏配置。
- **参数一致性提醒**：稳健 R ≥ 进取 R、保本线 ≥ 进取目标等自相矛盾组合会在面板顶部给出黄色提醒（不阻断，只提示），避免"进取档没有空间"这种静默失效。
- **单笔切档（持仓级覆盖）**：持仓卡新增档位徽标「稳健2R / 进取3R」与一键切档按钮。切档即重算目标价与保本线（风险距离优先取 `止损乘数×ATR`，缺失回退 `|entry-stop|`）并立即写库、同步跟单保护单；切到**进取档**会重置保本标记（重新评估 2R 保本线），切到**稳健档**保留已经发生的止损上移（绝不因切档把止损往回放）。风险距离无法确定时拒绝切档并说明原因，不写入半成品目标。
- **工作台统计图表**：新增纯函数 `LedgerStats`（按档位、按来源、按平仓原因聚合；连胜/连败、最大回撤、浮动 R、已实现 R 与 USDT 口径）与工作台「台账」面板（档位对比条 / 平仓原因分布 / 最近平仓明细），数据取自统一平仓台账 `closed_trades`；首页新增「工作台」入口。
- **档位标签修正**：稳健档止盈标签此前显示写死的 `targetMult`（3.0R），现按 `目标距离 ÷ (止损乘数×ATR)` 显示真实 R 倍数（如 2.0R），进取档保本标签同理，避免"2R 落袋却显示 3.0R"的误导。
- **修复 v5.0.17 遗留的 11 个过期单测**（BattleLoopEngineTest 入仓定价 3、EvidenceTest 定价 1、ExitStateMachineTest 延续 7）：v5.0.17 统一 R 口径后目标价从"止盈乘数×ATR"变为"止盈乘数×风险距离"，旧期望值未同步。现已按新口径更新，并为分档补齐 3 个新用例（稳健档到 2R 直接落袋、进取档到 2R 先锁保本、已保本不重复移保本）。
- **Compose/Android 层首次本地编译通过**：构建 APK 时抓出并修复 3 个此前从未被编译暴露的错误——① `MainActivity` 网络回调在 `@Composable` 里直接调 `getSystemService(...)`（Composable 无该作用域，改为先 `val ctx = LocalContext.current`）；② `fillMaxHeight` 缺 import；③ `MarketViewModel` 用对象实例访问嵌套类 `T.TierConfig()`（Kotlin 不允许，改为全限定名 `com.klinealert.nativeapp.domain.TargetTier.TierConfig()`）。修完后 **kotlinc 2.0.20 + Compose 编译器插件全量编译 0 错误**、d8 多 dex 通过。
- **安装包已出**：用内置工具链（aapt 编译资源 + kotlinc + Compose 编译器插件 + d8 + apksigner）构建并签名 **`kline-alert-v5.0.18.apk`**（12.3 MB，minSdk 26 / targetSdk 35 / versionCode 51 / versionName 5.0.18，启动页 `com.klinealert.nativeapp.MainActivity`，APK Signature Scheme v2+v3 校验通过）。产物路径 `Download/PocketCode/kline-alert-v5.0.18.apk`（另存一份在 `kline-alert-v5.0.5/android-native/kline-alert-v5.0.18.apk`）。⚠ 环境缺可用 zipalign 未对齐（不影响安装），未在真机运行验证。
- **并行安装版（解决与已装旧版签名互斥）**：`kline-alert-v5.0.18-parallel.apk`，applicationId 改为 `com.klinealert.nativeapp.v518`，组件名全限定（`com.klinealert.nativeapp.MainActivity` / `...service.BackgroundMonitorService`），标签「K线预警 5.0.18」，与旧版 `com.klinealert.nativeapp` **可同时安装**（包名不同，无签名冲突）。注意：两版数据互不相通（各自 app 私有目录），新版需重新配置跟单密钥与参数。`app/build.gradle.kts` 的 `applicationId` 已同步固化为 `com.klinealert.nativeapp.v518`（`namespace` 仍为 `com.klinealert.nativeapp`，相对组件名解析不受影响），后续 Gradle/CI 构建出的包都能覆盖安装这个并行版，不会再与旧包冲突。
- 版本：versionName **5.0.18** / versionCode **51**。
- 验证：domain 全量 **191 个单测全绿**（新增 TierSwitchTest 13 + LedgerStatsTest 10，并修复上述 11 个过期用例，无回归）+ kotlinc 全量类型检查（含真实 ExitStateMachine/TargetTier/LedgerStats）。`MarketRepositoryTest`(4) 与 data 层 `CrossCheckTest`(11) 依赖 Android 运行环境，仍需 CI `testDebugUnitTest` 复核；APK 构建同样需 Android Studio/CI。

## v5.0.17 目标分档（方案甲：整笔分档，稳健 2R 落袋 / 进取 3R 保本再跑）

解决"所有信号一刀切 3R 目标"的问题：**每笔开仓先定档，再按档位决定止盈与保本**，不拆仓、不半仓减半，全仓进全仓出。

- **`TargetTier` 分档判定（纯函数）**：4 条条件全满足才进取档——①**前方剩余空间** ≥ 进取 R × 风险距离（取最近结构 swing，看不到则视为开阔）；②**顺势结构**（趋势同向且无反向 CHoCH 确认，无结构时退化为市场阶段判断）；③**质量分** ≥ 门槛（默认 75）；④**动能确认**（量比 ≥ 1.3 或 ADX ≥ 22）。任一不满足即稳健档，并输出未过项原因（面板可见"为什么这笔是稳健档"）。
- **档位可覆盖**：单笔手动指定（`position_records.tier`）+ 全局强制（全部稳健 / 全部进取 / 自动），优先级明确（手动 > 全局强制 > 自动）。
- **分档出场**：稳健档到目标**直接落袋**（不参与延续，主打高胜率）；进取档到 **2R 先把止损移到保本**（`breakEvenDone` + 阶段 `BREAKEVEN`），最差不亏之后才按 v5.0.16 的延续判据冲 3R 及以上。
- **统一 R 口径**：目标距离 = **目标盈亏比 R × 实际风险距离**（止盈乘数 × 止损乘数 × ATR），`riskReward` 直接等于目标 R。修复此前"止损 2×ATR、止盈 3×ATR"造成卡片写 3R 实际只有 1.5R 的口径不一致（BattleLoopEngine / SymbolOpportunity / SmartLevels 同源）。
- **持久化与台账**：库版本 10→11，`position_records` 新增 `tier`、`break_even_done`；新增统一平仓台账 `closed_trades`（市场/品种/方向/周期/档位/入场/止损/目标/平仓价/杠杆/保证金/已实现 R/已实现 USDT/胜负/平仓原因/来源信号/延续次数/开平时间/持仓根数，含档位与时间索引），手动平仓、止盈、止损、移动保本、反向、轮换全部记账。
- **出场闸门接入档位**：`exitGate` 把持仓的 `tier` 与 `breakEvenDone` 传入 `ExitStateMachine.ExitConfig`，前台连续管理时档位状态随持仓走。

## v5.0.16 信号延续/出场状态机（到目标不机械平，按结构判持有·阶梯移动止损）

承接 v5.0.15「合理位置才开仓」，本版解决另一头：**信号到了第一止盈点不机械平仓，而是判断趋势是否还能延续——能延续就全仓移动止损/止盈、把利润奔跑起来并标记「延续×n」；不能延续就落袋结束；打破止损则无条件离场**。新增纯 Kotlin 模块 `ExitStateMachine`，与入场状态机对称，可单测、可回测、可一键回退。

- **出场状态机 ExitStateMachine**（与 EntryStateMachine 对称的纯函数）：持仓后按优先级判 **① 打破止损（tick 价，最优先，保护永不失效）→ ② 反向 CHoCH 结构反转提前离场 → ③ 时间止损（延续后 16 根 K 线无新进展）→ ④ 到达目标（用收盘价确认，非瞬时 tick，防插针误触）→ ⑤ 延续评分 → 移动止损/结束**。开关 `ExitConfig.continuationEnabled=false` 一键回退"到止盈/止损即平"。
- **延续判据（看结构而非只看价格）**：到目标后一票否决（出现反向 CHoCH 已确认 / 放量≥1.5×滞涨长上影 / 触及强压力且 RSI≥75，做空镜像为强支撑+RSI≤25）直接止盈；无否决再按 100 分制打分（趋势同向 40 + 顺势 BOS 20 + 收盘站稳 15 + MACD 顺向 15 + KDJ 未反向 10 + 全程无否决 10），**≥60 分才延续**。
- **阶梯移动止损（全仓移动，不做半仓减半）**：首次延续（×1）止损上移到**保本价 + 0.05% 缓冲**（覆盖双边手续费/滑点）；之后（×2、×3）取"**结构位（最近 swing 高低点 ±0.2ATR）与吊灯（极值回撤 1.5ATR）中更靠近现价的保护位**"，只单向收紧、永不放松；同时按顺势前方 swing 上移目标，要求前方至少还有 1.2R 空间，否则直接止盈。
- **延续上限 3 次**：达到 3 次后不再上移目标、只在更有利位置收紧保护（把利润锁住、避免无限追高）；每次延续都在持仓卡标「🟢延续×n·保本/结构位」。
- **全仓移动 + 跟单同步**：移动止损/止盈按全仓数量改单（不做半仓减仓，半仓减半留待 v5.0.17）；前台每次移动后调 `syncProtective` 对币安保护单**撤旧挂新**（数量不变、只改触发价），交易所服务器端保护单独立运行。
- **回测第三臂（结构延续）**：ReplayEngine 在"现价 / 价值区"之外新增第三臂"**价值区入场 + 结构延续出场**"，与价值区同点开仓、持仓中先用盘中极值判移动止损（同根保守优先），收盘再跑出场状态机；回测表格新增「延续 笔/胜率/总R」列与延续相对价值区的改善着色（trailEdgeR），结论行改为"现价→价值区→结构延续"总 R 链。
- **前后台安全分工**：信号延续的**主动评估**（移动止损/上移目标/延续×n）在 App 前台 ViewModel 执行（需要完整 K 线与结构）；后台监控服务保持固定/吊灯**硬保护**，每 60s 从库读最新持仓的 stop/target，所以前台一旦移动止损，后台自动按新保护位执行；后台到目标即止盈落袋、不强求延续。真实币安保护单始终在交易所服务器独立兜底。
- **数据持久化**：本地库版本 9→10，`position_records` 新增 `trail_count`（延续次数）、`stage`（INITIAL/TRAILING）、`last_raise_at`（上次移动时刻，时间止损锚点）三列，旧库 ALTER 升级、不丢历史持仓。
- **UI**：作战面板新增「信号延续 延续/固定」开关（默认开，持久化）；持仓卡显示「🟢延续×n·保本/结构位」标签与"延续×n/3·保护位·极值"进度行；回测表格加"延续"列。
- 验证：新增 ExitStateMachine 13 个单测（未到目标持有、首次延续保本上移、保本兜底、第二次延续、达上限只收紧、打破止损、移动后带×n、反向 CHoCH、放量长上影否决、强压力+超买否决、时间止损、做空镜像、开关关闭），全量 **180 个单测全绿**（v5.0.15 的 167 + 13，无回归）+ kotlinc 2.0.21 全量类型检查（含真实 LocalStore/后台服务/ViewModel/ReplayEngine）；MainActivity 为 Compose，APK 构建仍需 Android Studio/CI 复核。

## v5.0.15 地基模型算法（事件管道 + 回测/实盘同构 + 价值区入场）

针对"信号一出现就按现价原地开仓、追在波段中段"的核心问题，本版重构信号到开仓的地基：**方向层只出观察名单，等价格回到合理支撑/压力价值区且止跌确认后，才给"可开仓"信号**。新增 5 个纯 Kotlin domain 模块，全部可单测、可回测、可回退。

- **结构引擎 StructureEngine**：分形（左右各 2 根）+ ZigZag 严格高低交替识别 swing（确认后不重绘、无未来函数）；**BOS**（收盘破同向 swing=趋势延续）/ **CHoCH**（收盘破反向 swing=结构转变预警）；突破需**收盘价站稳 2 根（0.1ATR 缓冲）+ 量能≥1.5×**，影线刺破/一根收回判假突破（FAILED）；HH/HL、LH/LL 判趋势。
- **价值区 ValueZoneEngine**：候选来源优先级 破位回踩（BOS 阻力变支撑）> EMA20 > EMA60 > swing/前高前低；做多只取现价下方、做空只取上方，选"回踩最先触及"者，容差 0.3ATR、距现价≤3ATR 才有效；止损 2×ATR、止盈 3×ATR（盈亏比 1.5）。
- **入场状态机 EntryStateMachine**：四态 **观察 → 到位 → 可开仓 → 失效**。进入价值区后还要止跌扳机（止跌阳线/下影收回/滞涨、MACD 红绿柱收敛、KDJ 低位拐头）；回踩放量、MACD 逆向柱扩大、OBV 背离、反向 CHoCH 均为拦截；跌破价值区或 CHoCH 确认**一票否决**；盈亏比<1.5 不开。
- **统一事件管道 SignalPipeline**：Bar/Tick → 指标 → 结构 → 价值区 → 入场判定，回测逐根回放与实盘喂实时 tick 用同一内核（研究-实盘同构）；`EntryConfig.valueZoneEnabled=false` 一键回退旧现价逻辑。
- **回放器 ReplayEngine**：同一份历史 K 线并排跑"价值区 vs 现价"，Triple Barrier 结算（止盈/止损/最大持仓 16 根垂直屏障，同根同时触及保守判止损），输出胜率/总 R/平均 R/否决次数；样本不足诚实标注。固定种子趋势回放：价值区 7 笔胜率 80%/总 R +5.23，现价 8 笔胜率 66%/总 R +2.73（合成数据，仅验证接线，真实 edge 以实盘历史回放为准）。
- **自动作战接入**：`battleCandidates` 在原有 A/B 级、已确认、新鲜度、冷却、综合分≥70 之上，再叠加价值区**READY 硬门槛**（观察/到位/失效一律不自动开）；开仓价由实时价改为**支撑/压力价**（READY 时已在区内，滑点≤0.3ATR，远小于 2ATR 止损）；新增 `entryCandles` 入场 K 线快照（实盘 WS 新 K 线缓存）。
- **UI**：作战面板新增「入场模式 价值区/现价」开关（默认价值区，持久化可回退）；候补队列与三榜机会卡显示入场四态（🟢可开仓@支撑价·盈亏比 / 🟡到位待止跌 / ⏳等回踩 / ⛔失效原因）。
- **历史回测验证（实盘数据）**：作战面板新增「🧪 回测验证」按钮，对当前 A/B 级机会逐品种拉真实 K 线（各代表周期近 500 根），用同一回放器并排跑价值区 vs 现价，表格展示"笔数/胜率/总 R"与 ΔR（价值区相对现价的总 R 改善），并在顶部汇总合计总 R；样本不足（<250 根）或网络拉取失败诚实标注。参数跟随当前全局止损/止盈倍数，可改参数后重跑校准。
- 验证：新增结构/价值区/入场状态机/Triple Barrier/回放映射共 25 个单测（BOS/CHoCH、真假突破、做空镜像、价值区选取、四态转换、否决、止盈/止损/超时/同根优先、报告映射），全量 **167 个单测全绿**（无回归）+ kotlinc 2.0.21 全量类型检查（含真实 LocalStore/后台服务/ViewModel）；MainActivity 为 Compose，APK 构建仍需 Android Studio/CI 复核。

## v5.0.14 自动作战循环增强（实时补位 + 满仓轮换）

- **修复根因**：此前 `fillBattleSlots` 只在"空仓"或"刚平仓"时触发，持仓不满但非空时新出现的 A/B 确认信号不会自动入仓，只能手动点"加入持仓"。现 `battleTick` 每 tick 检查坑位：不满仓且有新鲜信号 → **自动入仓**，完整循环"信号→自动入仓→止盈止损平仓→自动补位"。
- **补位防抖**：新增补位最小间隔（30s/1m/2m/5m，默认 1m），防信号抖动高频开仓；空仓首次补位不受限。冷却/门控/单品种上限/新鲜度约束全部保留。
- **满仓轮换（默认关）**：满仓时新信号综合分 > 最差自动仓 ×1.2 且绝对差 ≥8 分 → 自动平最差换新（只轮换自动仓，不碰手动仓；轮换平仓写 miss 样本、冷却落库、跟单同步平仓）。
- 验证：新增轮换判定 2 用例，全量单测 + kotlinc 2.0.21 类型检查（含后台服务）；APK 构建仍需 Android Studio/CI 复核。

## v5.0.13 跟单统计收益率显示

- **收益率口径**：已实现收益率 = 已实现盈亏 ÷ 已平仓累计本金；浮动收益率 = 浮盈 ÷ 当前持仓本金；总收益率（含浮盈）=（已实现+浮盈）÷（已平仓+持仓）本金。
- **顶部汇总卡**新增"已实现收益率 +X%"与"浮动收益率 +Y%"（红绿着色），并列显示已平仓累计本金。
- **历史战绩行**新增"收益率 +X%"（按当前所选时间范围统计）。
- 验证：新增收益率口径 3 用例，全量单测 + kotlinc 2.0.21 类型检查；APK 构建仍需 Android Studio/CI 复核。

## v5.0.12 跟单配置增强（本金手输 + 跟随仓数手输 + 风控入口 + 滑点保护）

- **下单口径只按本金**：每笔保证金由固定 4 档改为**手动输入**（支持小数，如 15.5U）+ 快捷档 5/10/20/50/100；实时预览"本金 × 杠杆 → 名义金额"。
- **杠杆**：默认当前品种最高杠杆（保持），可切"固定杠杆"手输 1-125x；封顶档 ≤5/10/20/50 保留。
- **允许最大持仓仓位数量**（跟随仓数）：固定档 1/2/3/5/8 之外可**手输 1-50**。
- **风控入口补齐**（引擎早已生效，UI 现可改）：日开仓次数 1-100、日亏损熔断 10-1000U、品种方向冷却 30s/1m/90s/5m、跟单时窗 1m/3m/5m/10m、仅自动作战开关（手动仓也跟）。
- **滑点保护修复死配置**：不再用固定百分比，改为以**止损安全距离为界**——市价成交价距止损 ≥ 止损距离×比例（10%/20%/30%/50%，默认 30%）才安全，不逼近/不越过止损；成交价逼近或越过止损时**拒绝开仓**（已成交则立即对冲平掉）或仅记录告警（可切）。原 slipProtectPct 为死字段，本次起弃用。
- **今日进度**：跟单页顶部显示"今日已开 X/Y · 今日盈亏 ±Z U"与日亏损熔断进度条；持仓卡已有本金/数量/杠杆/均价明细。
- 验证：新增滑点判据纯函数 7 用例（LONG/SHORT 镜像、比例阈值、关闭/无效输入、拒绝原因），全量单测 + kotlinc 2.0.21 类型检查（含后台服务）；APK 构建仍需 Android Studio/CI 复核。

## v5.0.11 实时链路收尾（网络切换重建 + 前后台判定统一 + 断开标注）

- **B1 网络切换主动重建**：`MainActivity` 注册默认网络回调（`ACCESS_NETWORK_STATE` 权限已具备），网络 VALIDATED 恢复或传输通道变化时通知 ViewModel（2s 去抖）→ 立即重建实时流。此前 Wi-Fi↔蜂窝切换依赖 OkHttp pingInterval 探测，最坏要等 ~20s+；现 ~2s 内恢复。代际递增天然防幽灵，不打断全市场扫描。
- **B2 前后台价格判定统一**：后台 `positionWatchLoop` 原用 K 线收盘价判平仓（4h 周期持仓可能滞后最多一个周期，且无防插针），现优先用 **markPrice 标记价**（`MarketRepository.markPrices`，fapi `premiumIndex`，实时 + 天然抗插针，与前台口径一致），失败回退 K 线收盘价；premiumIndex 解析抽公共方法 `parsePremiumIndex`（单/多 symbol 两形态），资金费率接口同步复用。
- **B3 断连陈旧标注**：持仓行情 socket 断开时置 `stalePositions`（保留最后价并标"·已断开"黄色），重连后首个 tick 自动清除；不再把陈旧价格冒充实时价。
- 验证：新增 premiumIndex 解析 4 用例，domain 单测全绿 + kotlinc 2.0.21 全量类型检查（含 BackgroundMonitorService 真实源码编译）+ 后台服务改动纳入编译清单；APK 构建仍需 Android Studio/CI 复核。

## v5.0.10 持仓风控展示（单品种上限 + 预估强平 + 资金费率）

- **单品种仓位上限**：同品种同时最多 1 仓。自动作战候选本就按 symbol 排重；手动「加入持仓跟踪」新增同品种检查，重复建仓被拒绝并提示（堵住手动路径的缺口）。
- **预估强平价展示**：`PositionEngine.liquidationPrice`（USDT 本位简化，含维持保证金率 0.5%，LONG/SHORT 镜像），持仓卡新增「预估强平」列，红色标识风险位；标注为本地预估，实际以交易所/档位为准。
- **资金费率展示**：`MarketRepository.fundingRates` 经 fapi `premiumIndex` 批量拉取 8h 结算费率（单/多 symbol 两种返回形态都解析，失败静默降级）；ViewModel 每 15 分钟定时刷新，持仓增删/平仓后即时刷新；持仓卡新增「资金费率」列，|费率| ≥ 0.1% 标黄预警。
- 验证：新增 PositionEngine 强平价用例，domain 单测全绿 + kotlinc 2.0.21 全量类型检查通过；APK 构建仍需 Android Studio/CI 复核。

## v5.0.9 全局止盈止损乘数配置（方案 A：止损/止盈双乘数）

- 新增**全局止损倍数**（默认 2×ATR/风险距离，可选 1.0/1.5/2.0/2.5/3.0）与**全局止盈倍数**（默认 3×风险距离，可选 2/3/4/5/6），持久化到 settings（`stop_mult`/`target_mult`，重启不丢），界面实时显示联动盈亏比 = 止盈÷止损（默认 1.5）。
- **自动作战入仓**：`BattleLoopEngine.buildEntry` 本就支持 `stopMult/targetMult` 参数（此前调用处未传），现由 `MarketViewModel.fillBattleSlots` 传入全局配置——引擎零改动。
- **待命单/机会卡**：`PendingSetupEngine.build` 增加 `stopMult/targetMult` 参数，原硬编码止损 `1.5×ATR`、止盈 `3×risk`（target3R）改为全局乘数；做空 ×1.25 缓冲与结构位止损保留；风险兜底值同步改为 `stopMult×ATR`。⚠ 行为变化：待命单止损默认由 1.5×ATR 统一为 2×ATR（与自动作战一致）。
- **界面**：自动作战设置区新增两组 SegChip + 盈亏比显示；信息行与待命单标签（"止盈3R"→"止盈"）改读配置值。
- **兼容**：仅影响新机会/新入仓；已在仓的止损止盈价格落库固化不动；入场门控已核实只依赖 ATR/价格比，与乘数无关；跟单链路价格来自持仓固化值自动跟随。
- 验证：新增 BattleLoopEngine/PendingSetupEngine 乘数用例，domain 单测全绿 + kotlinc 2.0.21 全量类型检查通过；APK 构建仍需 Android Studio/CI 复核。

## v5.0.8 实时流修复合并版（v5.0.6 基座 + v5.0.7 独立代际）

- 吸收 v5.0.7（另一路修复）的**ticker / kline 独立代际计数**：原 v5.0.6 用单一 `liveGeneration` 同时守护 ticker 与 kline 两条流，现拆分为 `tickerGeneration` / `klineGeneration` 各自递增、各自校验，两条流互不干扰（ticker 断连重连不影响 kline 回调有效性，反之亦然）。`stopLive()`/`startLive()`/`onCleared()` 同步递增两个代际；`scheduleReconnect` 触发前校验"任一当前代际匹配"，等待期间切品种/周期/前后台即放弃本次重连。
- 完整保留 v5.0.6 全部修复：`pingInterval(20s)` 死连探测、Spot 镜像站阈值切换+成功回切+Canceled 不污染、重连封顶指数退避（2s→30s）与成功归零、全市场流退避成功归零、`onOpen` 建连感知、historyJob 内建 socket 前的代际检查（防旧 job 覆盖新 socket）。
- 验证：domain 106 项单测全绿；`MarketRepository`/`MarketViewModel` 与 domain/data 全量源码经 kotlinc 2.0.21 + okhttp 4.12/okio/org.json/coroutines 1.9 类型检查通过（Android 框架类以签名 stub 替代）。Android Gradle/APK 完整构建仍需 Android Studio / CI 复核。

## v5.0.6 实时行情断连根因修复（行情假死 / 一直断联）

- **P0 死连接不可感知（行情"假死"停更）**：`MarketRepository` 的 OkHttpClient 从未配置 `pingInterval`。Binance 服务器每 3 分钟发 ping、10 分钟收不到 pong 即断开；运营商 NAT/代理也会静默丢弃空闲连接。此前连接死亡时 `onMessage` 停更但 `onFailure` 不触发，重连逻辑永远不会执行，界面停留在"已连接"却不再刷新。现统一加 `pingInterval(20s)`：OkHttp 每 20s 主动 ping，20s 内未收到 pong 判定连接死亡 → 触发 `onFailure` → 走既有重连。已核实 OkHttp 4.12 `readTimeout` 不会作用于 WebSocket 帧读取，无需改动超时。
- **P0 Spot 镜像站永久粘滞 + 被主动取消污染**：旧 `spotWsFailure()` 无阈值、失败一次就永久切 `data-stream.binance.vision` 且从不回切；而 OkHttp 的 `cancel()` 会以 `IOException("Canceled")` 回调 `onFailure`——应用每次前后台切换（ON_STOP/ON_START 都会 cancel 旧 socket）都会把镜像标记打满，Spot 实时流全部跑到镜像站，镜像站一旦不可达就是永久断联循环。现改为：① `Canceled` 主动取消不计为失败；② 连续 2 次真实失败才切镜像；③ 任意主机成功建连（`onOpen`）即回主站，自动自愈。
- **P1 陈旧 socket 回调触发"幽灵重连"掐断新连接**：`stopLive()` 优雅 close 后 `onClosed` 异步回调若在下次 `startLive()` 之后到达，会通过 `foreground && isCurrent` 校验 → 2 秒后 `startLive()` 把刚建好的新 socket cancel → 抖动循环。现引入 `liveGeneration` 代际计数（与持仓/全市场流同款机制）：ticker/kline 创建时捕获代际，`onOpen/onPrice/onError/onCandle` 全部校验代际，重连任务触发前也校验代际；`stopLive()`/`onCleared()` 递增代际令旧回调全部失效。
- **P1 ticker 重连无退避轰炸**：单品种 `scheduleReconnect` 原固定 2s 无上限，主机不可达时每 2 秒无脑重连。现改为封顶指数退避 2s→4s→8s→16s→30s，建连成功（`onOpen`/首 tick）即归零；全市场流重连计数同样在收到首根 K 线时归零（此前只在切市场/周期时归零）。
- **验证**：domain 106 项单测全绿；`MarketRepository`/`MarketViewModel` 与 domain/data 全量源码经 kotlinc 2.0.21 + okhttp 4.12/okio/org.json/coroutines 1.9 类型检查通过（Android 框架类以签名 stub 替代）。Android Gradle/APK 完整构建仍需 Android Studio / CI 复核。

## v5.0 币安 U 本位全自动跟单（骨架 + P0/P1 通路）

- 完整方案见 `TRADE_SCHEME.md`。
- BinanceTradeClient / TradeBridge / trade_links / 交易页 UI / 监控挂钩。
- 默认跟单关闭；密钥本机存储。


## v4.9 盈亏口径修正（币安 U 本位）

- **P0 盈亏口径**：`LocalPosition.size` 明确为**起始保证金本金（USDT）**，数量 = 本金 × 杠杆 / 开仓价。
  - 未实现盈亏 USDT = 本金 × 杠杆 × 方向变动% / 100（例：本金1、50x、涨1% → **+0.50 USDT**）。
  - 收益率%（开仓保证金口径）= 杠杆 × 方向变动%（例：**+50%**）。
  - 修复原「方向变动百分点 × 50」把百分数当金额、放大约 100 倍的错误。
  - 统一持仓卡、工作台已平/浮盈、前台平仓提示、后台通知；`battlePnlSum` 改为累计 **USDT**。
  - 默认自动入仓仍本金 1 USDT × 杠杆 50；手动「按此执行」与自动一致。
- 止损/止盈/手续费/资金费/强平本轮不动。旧 `battlePnlSum` 历史累计若曾按错误公式展示，新会话起按 USDT 重计。
- （自动作战循环补位逻辑保持原样：空仓或刚平仓时再补，不在未满仓每轮强补。）

## v4.8 全量审计修复（功能完结后体检）

- **P0-1 双结算口径统一**：后台 `settleByPrices` 由「扫描现价近似判定」改为**优先拉真实 K 线调 `ReviewEngine.touch`**（区间高/低点触碰、同时触碰判 miss，与前台完全同口径）；K 线不可用（冷门/限流）才回退扫描现价，回退优先级与前台一致。修复同一记录前后台可能结论不一、污染胜率/学习权重/回测的问题。
- **P0-2 冷却持久化**：LocalStore DB v7→v8 新增 `battle_cooldowns` 表；VM 启动从 DB 恢复冷却；自动平仓（前台+后台）与手动删仓均写库。进程被杀/重启后冷却不丢，防同品种立即重入。
- **P0-3 双端平仓原子守卫**：新增 `reviewExists(id)`；VM/Service 的 `closeBattlePosition` 只有**首个写入方**才保存样本 + 计数 + 发通知，另一方仅删持仓——消除同 tick 并发平仓的统计/通知重复。
- **P1-1 关键路径失败可见**：自动入仓落库失败 →「⚠ 入仓落库失败」；自动平仓结算落库失败 →「⚠ 结算落库失败，请到诊断页检查样本」；其余读缓存静默降级（合理设计）。
- **P2-1 SQLite 并发**：`onCreate` 启用 WAL（前台 VM 与后台 Service 双连接并发，降低 SQLITE_BUSY）。
- **P2-2 测试补充**：BattleLoopEngineTest +6 边界（NaN/零值入仓、到价平仓、除零盈亏、冷却恰到期、新鲜度窗口边界、作战评分输入钳制）。
- **审计结论（无需改）**：限流重试（418/429/5xx + Retry-After + 指数退避 1s/2s/4s）、后台保活（前台通知 + START_STICKY + 断线重连）、AnalysisEngine 除零/NaN 防护、Double 展示口径——逐项核验已达标。
- 测试：**117/117**（kotlinc 2.0.21 全量编译 domain 16 文件 + 14 测试类，JUnit 4.13.2 全跑 OK）。交付：源码包 + 审计报告（Android 层需在有 SDK 环境 `assembleDebug` 复核）。

## v4.7 作战台新鲜度滚动榜（优中选优，不堵死）

- **作战台改「新鲜度滚动榜单」**：取消固定「主攻/候补/观察」3 卡，改为新鲜窗口内（15m→30分钟…）已确认/回踩确认信号按**作战评分**降序的榜单，最多展示 8 条；**过期自动下榜**（K 线时间超窗口即消失，哪怕分数高）——榜单持续滚动，不再被旧信号堵满；每条带 ⏱新鲜标记（刚刚确认 / N 分钟前）。
- **作战评分（优中选优，榜单与自动入仓共用）**：`BattleLoopEngine.battleScore` = 信号分×0.30 + 方向历史胜率×0.20 + 确认强度 progressAtr×0.15 + 波动健康×0.15 + **新鲜度×0.20**（≤5 分钟满分、按窗口线性衰减，`freshnessScore`）——旧高分不压新信号。
- **自动入仓收紧**：仅 **A/B 级**机会才自动入仓（C 级只展示不自动进）+ 已确认/回踩确认 + 分≥70 + 未持仓 + 未冷却 + 新鲜窗口内；每轮最多补 min(空闲坑位, 3) 个渐进建仓。
- **空位持续推荐**：坑位 > 0 时作战台持续推荐新信号（设 5 持仓 2 → 空 3 坑自动从榜首补位）；满仓才暂停推荐。
- **修 bug**：Kotlin 不以行首 `+` 续行——battleScore 原本换行书写导致只返回第一项（信号分×0.3），已用括号包裹修复（单测抓出）。
- 测试：111/111（BattleLoopEngineTest 21 项，新增新鲜度衰减、作战评分权重）。交付形态为源码包，未在本环境出 APK。

## v4.6 自动作战优化（4 项用户修改）

- **盈亏比改「止损 2 / 止盈 3」**：入仓定价改为止损距离 = 2×ATR、止盈距离 = 3×ATR（原 1×/2×）；`BattleLoopEngine` 新增 `DEFAULT_STOP_MULT=2.0` / `DEFAULT_TARGET_MULT=3.0`，EntryPlan 落 `stopMult`/`targetMult`；门控「距止损太近」按止损距离展示（默认最小止损 0.6% 价）。
- **持仓收益明细与统计**：本金固定 1、杠杆 50 倍——持仓卡新增「实际盈亏50x」= 方向变动% × 50；工作台统计区新增「已平实际盈亏 = 累计价格收益% × 50」与「当前浮盈 = Σ 方向变动% × 50」；自动入仓落库 leverage=50、size=1。
- **满仓后作战台不再推荐**：满仓时作战面板与工作台隐藏候补推荐，只显示「满仓暂停推荐」提示；`fillBattleSlots` 满仓清空候补队列；**新鲜度门槛**（`BattleLoopEngine.isFresh`，按周期 15m/30m/1h/4h → 30/60/120/480 分钟窗口）——平仓后只自动补入**新鲜**确认信号，防「落后信号顶上」。
- **后台常驻不断联**：`bg_monitor` 默认开启；`BackgroundMonitorService` 新增后台自动作战——60s 轮询全部 LIVE 持仓实时价（`repo.candles`）+ 扫描轮批量兜底 + K 线新收盘触发，止盈/止损/移动止盈与前台同引擎判定，平仓写 `auto|` 结算样本、删持仓、系统通知实际盈亏（×50）。
- **持久化**：SQLite v7 迁移——position_records 新增 stop_mult/target_mult（幂等 ALTER，默认 2.0/3.0）。
- 测试：109/109（BattleLoopEngineTest 19 项，新增自定义乘数、新鲜度窗口）。交付形态为源码包，未在本环境出 APK。

## v4.5 自动作战循环（Auto-Battle Loop）

- 新增 `BattleLoopEngine`：把「作战面板推荐 → 自动入仓 → 自动止盈止损平仓 → 循环等下一信号」闭环化（用户决策：按现价入 + 盈亏比默认 2:1 + 全自动 + 移动/固定止盈可切换）。
- **入仓**：已确认/回踩确认 + 综合分≥70 + 未持仓/未冷却的候补信号，按现价入场；止损=现价∓ATR（风险 R），止盈=现价±2R（盈亏比 2:1）；距止损太近（R<0.3% 价）或波动过大（R>5% 价）被门控拒绝，不追。
- **自动平仓**：每 500ms tick 轮询持仓实时价——防插针（交叉校验偏差>1.5% 拦截）、止损、固定止盈、移动止盈（从极值回撤 1.5×ATR 锁盈，且不劣于原始止损）四重判定；平仓即删除持仓（消失）+ 写 `auto|` 前缀 ReviewRecord 进胜率/学习/回测闭环。
- **循环**：坑位空出 → 候补队列按综合分自动顶上；同品种同方向平仓后 4h 冷却防反复进出；容量上限扩到 10（默认 10）。
- **UI**：工作台「自动作战 全自动开/关」+「止盈 固定/移动」切换 + 循环统计（入/平/胜/负/盈亏）+ 候补队列；持仓卡片显示距止损/止盈进度、移动止盈锚点、🤖自动徽标。
- **持久化**：SQLite v6 迁移——position_records 新增 status/trailing/best_price/risk_reward/atr/timeframe/evidence_score/close_price/close_reason/closed_at（幂等 ALTER）。
- 测试：107/107（新增 BattleLoopEngineTest 17 项：盈亏比定价/门控/四重平仓/移动止盈锚点/冷却/盈亏口径）。交付形态为源码包，未在本环境出 APK。

## v4.4 收尾版（回测校准框架 + 体验项）

- 新增 `BacktestAnalyzer`（#1#2#3）：把 v4.2 落库的回踩数据 + 证据分利用起来做三件事——①证据分分段胜率（<60 / 60-69 / 70-84 / ≥85，建议阈值=可靠分桶中胜率最高段下界，对照当前硬编码 85）；②回踩 vs 直接触发对比（验证 v4.1「回踩确认更优」假设）；③样本外滚动验证（时间 70% 训练 / 30% 验证，验证段胜率跌 >20pp → 提示疑似过拟合/市场漂移）。
- 设计原则：单桶样本 <15 或总样本 <40 明确标注「样本不足」，不硬给结论；只输出建议值，绝不自动改线上参数（避免噪声污染）。
- #7 样本量提示：学习权重样本 <20 标注「⚠样本不足」，回测分桶不足标注「（样本不足）」。
- #8 通知深链：触发通知 Intent 带 `deep_link_tab=latest` / `deep_link_symbol`，点击直达「最新机会」页并黄框高亮该品种 3 秒自动恢复。
- #9 待命单手动忽略：卡片右上角「✕」一键标记为过期（EXPIRED + 手动忽略）并落库，不等自动过期。
- #10 回测报告展示：诊断页「回测校准（真实样本）」区块 + 「生成/刷新回测校准报告」按钮，展示分段胜率/建议阈值/回踩对比/样本外验证结论。
- 测试：90/90 通过（新增 BacktestAnalyzerTest 10 项）。交付形态为源码包，未在本环境出 APK。

## 2026-10-12 — foreground cancellation / SQLite repair

- Propagate coroutine cancellation immediately from Binance REST retry and spot mirror fallback paths.
- Do not swallow cancellation when the optional 24-hour volume ranking endpoint fails.
- Make SQLite upgrade migration idempotently verify/create the scan cache table without deleting existing scan rows.
- Android Gradle build and APK assembly still require GitHub Actions or Android Studio; this environment cannot claim a full build passed.

## 2026-10-12 — full-market scan resilience

- Retry transient per-symbol REST/data failures once after the initial full-market pass, using smaller retry batches to avoid amplifying Binance rate-limit pressure. The final failure count now reports symbols that still fail on retry.
- Repair full-universe live monitoring for symbols whose initial K-line REST request failed: the first stream event triggers a 300-candle history backfill, with later-bar retries if the history remains too short and a per-symbol in-flight guard to avoid duplicate backfill requests.
- Changed full-universe WebSocket reconnection from a fixed 2-second loop to capped exponential backoff (2–30 seconds) while foregrounded.
- Full Android Gradle/JUnit/APK build remains unverified locally; CI and device validation are still required.

## 全市场机会筛选与结构增强
- 新增扫描周期多选，可在一次扫描任务中依次扫描 15m、30m、1h、4h 中所选周期，并按周期保存分析结果。
- 新增机会列表品种搜索与最低综合可信度筛选。
- 新增综合可信度分值，综合市场阶段、方向信号评分、支撑/承压位共振、成交量与风险收益比；不再仅显示市场阶段置信度。
- 每条机会新增最近 96 根已收盘 K 线的最高/最低点，并展示最近支撑、最近承压、支撑/承压共振数量和风险收益比。
- 注：综合可信度是规则模型的评分，不是统计校准过的真实胜率；需要历史回测后才能评估概率校准。


## 实时流生命周期修复（基于正常旧版对照）

- 修复全市场扫描在后台完成时未保存本轮 universe 的问题：扫描开始会清空旧品种，扫描完成时若 app 不在前台，原逻辑跳过 startUniverseWatch 且没有保存新品种，导致回到前台 startLive 无品种可重新订阅。现在扫描完成后先保存本轮品种/市场/周期，前台时再启动订阅。
- 全市场 WebSocket 失败日志增加异常类型与可用的 HTTP 握手状态，便于区分网络中断、握手拒绝等原因。
