Fix Modifier import + restore minPan/rightShiftBars for free viewport
