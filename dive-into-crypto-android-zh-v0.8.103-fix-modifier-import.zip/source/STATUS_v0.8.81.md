# v0.8.81 — AI model parser fallback correctness

- Fix: model entries with a blank `id` no longer hide a valid `model` or `name` field; the parser now selects the first non-blank supported identifier.
- Robustness: malformed JSON handling catches `Exception` rather than all `Throwable`, avoiding swallowing fatal runtime errors.
- Added a regression test for blank `id` values with valid fallback fields.
- Based on v0.8.80; no existing features intentionally removed.
- APK was not built. Gradle tests/build were not run in this iteration; ZIP integrity is checked separately.
