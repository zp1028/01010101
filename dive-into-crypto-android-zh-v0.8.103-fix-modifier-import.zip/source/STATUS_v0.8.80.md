# Dive Into Crypto v0.8.80 — AI model-list parsing compatibility

## Changes in this revision
- Extracted model-list response parsing from `SettingsScreen` into the pure helper `AiModelListParser`.
- Supports OpenAI-compatible `{data:[...]}`, `{models:[...]}`, `{items:[...]}`, plain arrays, and nested gateway wrappers under `result`/other supported wrapper keys.
- Supports model identifiers represented as objects with `id`, `model`, or `name`, and plain string array entries.
- Trims blank entries, removes duplicates, and sorts model IDs for stable selection.
- Adds common tests for canonical, nested, string-array, invalid-JSON, and missing-list responses.
- Preserves existing endpoint fallback and authorization request behavior.

## Validation
- Source changes and test cases added.
- ZIP integrity will be checked after packaging.
- Gradle tests/build were not run: the Gradle wrapper distribution download failed with `UnknownHostException: mirrors.cloud.tencent.com`.
- No APK was built, as requested.
