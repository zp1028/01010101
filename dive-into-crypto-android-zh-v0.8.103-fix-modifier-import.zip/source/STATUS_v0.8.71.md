# v0.8.71 — AI target isolation and stale-result guards

## Changes
- Analysis report and AI-plan text are rendered only when their target key matches the current symbol + timeframe, preventing stale content from appearing for a frame during target changes.
- `AiSessionHub.startAnalysis` now rebinds and advances the session generation on configuration and insufficient-candle early failures, so callbacks from older in-flight AI work cannot overwrite the newer failure state.
- Existing local fallback plan behavior remains: AI plan is preferred only when enabled and a target-matched plan exists.

## Preserved
- Scanner card collapse, EMA20/EMA50, chart overlays, zoom/pan, trendline and support/resistance logic remain in place.
- Source-only update. No APK was built.

## Validation
- ZIP integrity check passed.
- Attempted `./gradlew :app:allTests --no-daemon`; it could not start because the Gradle wrapper distribution download failed with `UnknownHostException: mirrors.cloud.tencent.com` in this environment. Tests and compilation therefore remain unverified.
- No device verification was performed.
