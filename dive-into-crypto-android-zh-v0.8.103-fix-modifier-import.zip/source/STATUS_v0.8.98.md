# v0.8.98 — Resumable replay pagination and expiry-boundary correctness

## Implemented in source
- Added durable replay pagination progress to the forward-plan journal (schema v4): window bounds, next cursor, accumulated closed candles, update time, completion flag, and no-progress count.
- Added a single-page Binance USDT-M historical-kline fetch method so the scanner can advance one page per replay pass and resume after process/network interruption.
- Scanner replay now restores the saved cursor/candles, deduplicates by candle open time, saves bounded progress, and clears progress after terminal target/stop/expiry outcomes.
- Progress is bounded to 24 plans and 5,000 candles per plan; archived-plan deletion also removes its progress.
- Fixed expiry coverage logic: an actual closed candle at/after the expiry boundary proves coverage; its post-expiry high/low is not allowed to produce a target/stop outcome. This avoids requiring a candle close to match an arbitrary millisecond expiry exactly.
- Added tests for progress persistence/reload/clear and for a post-expiry candle proving coverage without becoming a win.

## Validation
- Attempted `./gradlew :app:allTests --no-daemon`; failed before build because Gradle 8.10.2 could not be downloaded (`UnknownHostException: mirrors.cloud.tencent.com`).
- No claim of full-project compilation or test success.
- No APK built.
- ZIP integrity check performed after packaging.

## Remaining major acceptance work
1. Historical performance report: equity curve, maximum drawdown, and train/out-of-sample comparison wired to persisted, coverage-qualified outcomes.
2. Chart overlay integration/device regression: verify plan levels remain aligned during zoom, pan, and timeframe changes.
3. Full Gradle compilation, automated tests, and regression review of AI fusion, scanner ranking, chart overlays, and existing features.

## Known limitations
- Replay progress uses the existing JSON settings journal. It is bounded but can still enlarge the settings payload; a dedicated database table would be more appropriate if the project later adds a database migration.
- Automatic replay still runs while the scanner screen is active; reliable background scheduling remains separate work.
