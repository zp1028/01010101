# v0.8.92 — Replay coverage integrity

## Changes
- Added a bounded, time-ranged Binance USDT-M futures history API with pagination (`futuresHistoryBetween`) so replay does not rely solely on the rolling latest-1000-candle cache.
- Replay requests only the plan's decision-to-expiry window plus one timeframe of coverage, capped at 5,000 candles.
- Replay expiry is no longer settled solely because wall-clock time passed. A closed candle must cover the plan expiry boundary; otherwise the result stays unresolved and must not enter win-rate/expectancy statistics.
- Added tests for expired plans with incomplete coverage and for the expiry-coverage boundary.

## Validation limitations
- ZIP integrity and source-level inspection are performed for this delivery.
- Full Gradle/Compose compilation and automated test execution remain blocked until the configured Gradle distribution can be downloaded. Do not interpret source inspection as a full build pass.
- No APK is built.
