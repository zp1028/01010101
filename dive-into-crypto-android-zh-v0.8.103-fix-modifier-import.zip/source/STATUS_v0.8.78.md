# v0.8.78 — Chart coordinate overflow guard

## Changes
- Hardened `ChartMath.scaleY` against finite price bounds whose subtraction overflows to infinity, reversed/zero-width domains, and non-finite intermediate fractions.
- Added a finite midpoint fallback so malformed chart domains cannot emit NaN Canvas Y coordinates.
- Added regression coverage for extreme and reversed price domains.
- Preserved the v0.8.77 chart range padding guard and all prior source changes.

## Validation
- Source and regression test updated.
- ZIP integrity checked after packaging.
- Gradle tests/build were not run in this round; no APK was built. Runtime/device behavior remains unverified.
