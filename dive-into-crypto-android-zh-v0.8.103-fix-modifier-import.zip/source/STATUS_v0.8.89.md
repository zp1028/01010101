# v0.8.89 — Forward-plan history management

## Implemented in this pass
- Added an expandable plan-history manager to the scanner's Forward Plan board.
- History rows show symbol, direction/type, lifecycle state, archived status, generated/expiry timestamps, entry band, stop/target, last observed price, and latest closed-candle checkpoint.
- Added per-plan archive action. Archiving preserves the immutable snapshot, AI revisions, and lifecycle events; archived plans are excluded from `activePlans()`.
- Added explicit confirmation before permanently deleting archived plans. Deletion removes the archived plan snapshots and only their related revisions/events; non-archived plans remain untouched.
- Added journal tests for archive preservation, active-plan exclusion, and scoped deletion.

## Validation
- Source-level review completed for the changed journal and Compose UI.
- Full Gradle/Compose compilation and automated tests are still blocked/unverified because Gradle 8.10.2 download previously failed with DNS/network error. No APK built.
- ZIP integrity will be checked after packaging.

## Remaining
- Persisted replay-result repository and visual performance report.
- Actual historical candle source wired end-to-end into replay evaluation, plus no-lookahead audit.
- Chart overlay zoom/pan/timeframe regression and full project regression suite.
