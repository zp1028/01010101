# v0.8.95 — Sparse history pagination and replay checkpoint deduplication

## Changes
- Historical futures pagination no longer stops merely because a page has fewer than the requested limit. It advances from the last returned candle and continues within explicit page/candle bounds, allowing sparse ranges to be inspected for later candles rather than truncating at the first gap.
- Pagination still stops on empty response, non-advancing cursor, end-time boundary, or configured budget; evaluator continuity checks remain authoritative and sparse data is not silently treated as complete.
- Replay checkpoint de-duplication searches the bounded journal for a matching record instead of only checking the last record, avoiding duplicates when records from multiple plans are interleaved.

## Validation
- Source changes reviewed and ZIP integrity checked.
- Full Gradle/Compose tests not run; Gradle distribution download previously failed due to DNS/UnknownHostException.
- No APK built.
