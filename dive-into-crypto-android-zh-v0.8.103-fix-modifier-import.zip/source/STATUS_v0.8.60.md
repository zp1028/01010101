# v0.8.60 source changes

- Improved AnalysisMiniChart pinch zoom anchoring: the candle under the gesture centroid stays approximately fixed while zooming.
- Unified pan semantics: dragging right moves the visible window toward older candles; dragging left moves toward newer candles.
- Clamped viewport calculations for small candle sets and bounded the visible start index to the available history.
- Kept the source-only workflow; no APK build was run.

Validation: source diff reviewed and ZIP archive integrity checked. Kotlin/Compose compilation and real-device gesture behavior have not been verified.
