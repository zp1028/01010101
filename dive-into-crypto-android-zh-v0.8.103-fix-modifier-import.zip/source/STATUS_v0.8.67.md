# v0.8.67 — chart gesture state freshness

## Changes
- AnalysisMiniChart now reads the latest zoom and panFraction values inside its long-lived pointerInput gesture handler using rememberUpdatedState. This prevents the handler from continuing to calculate from viewport state captured when the gesture modifier was first created.
- Main CandleChart now reads the latest scale and panBars values in its long-lived pointerInput handler using rememberUpdatedState, avoiding stale-state pan accumulation across recompositions.
- Existing gesture keys remain stable (candle count), so the pointer handler is not needlessly restarted on every state change.

## Validation
- Source-only change; no APK/Gradle build performed as requested.
- ZIP integrity will be checked after packaging.
- Kotlin compilation and device-level pinch/pan behavior remain unverified.
