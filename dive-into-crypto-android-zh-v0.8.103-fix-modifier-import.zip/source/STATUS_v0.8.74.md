# v0.8.74 — EMA overlay gap handling

## Changes
- Updated the analysis mini-chart EMA renderer to break the polyline when a sample is missing, non-finite, or non-positive.
- Prevents EMA paths from drawing misleading diagonal segments across invalid-data gaps; valid points keep the same candle-index-based x mapping.
- Kept existing EMA20/EMA50 calculations, viewport slicing, zoom/pan behavior, and other chart overlays unchanged.

## Validation
- Source diff reviewed and ZIP integrity checked after packaging.
- Gradle compilation, unit tests, and device rendering have not been run. No APK built.
