# STATUS v0.8.44

## Implemented in source
- Persisted `aiPlanEnabled` in `SettingsStore` with a backward-compatible default of `true`.
- Analysis screen initializes the AI-plan toggle from settings and persists user changes.
- Clarified exactly which analysis areas are affected by AI results.
- Added chart-adjacent status text distinguishing an applied parsed AI plan from local-plan fallback.
- Existing behavior remains: when AI-plan priority is on and a valid AI plan exists, the chart plan, plan card and watch values use that AI plan; local technical indicators continue to be calculated from candles.

## Verification status
- Source edits and ZIP packaging completed.
- Gradle compilation, Android installation, and device-level navigation/chart tests are not yet verified in this environment.
- AI can only return a chart plan after AI is configured/enabled, analysis has candle data, the user invokes AI analysis, and the response contains a valid parseable plan.
- AI does not alter navigation controls, local indicator calculations, or execute trades.
