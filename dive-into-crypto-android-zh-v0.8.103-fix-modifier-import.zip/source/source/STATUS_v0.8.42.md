# STATUS v0.8.42

## Implemented in source
- MA20/MA50 are drawn over the candle chart when enabled; toggle is exposed as `MA20/50`.
- Analysis chart height increased from 220dp to 260dp.
- Manual symbol switching passes the target symbol directly to `runAnalyze`.
- Timeframe chip selection passes the target timeframe directly to `runAnalyze`.

## Not yet verified
- Kotlin/Gradle compilation and Android installation were not verified in this environment.
- The reported bottom-navigation click issue still requires device-level reproduction. The shell already renders bottom navigation outside the screen NavHost, but this alone does not prove the reported issue is resolved.
- Notification deep links, 15-minute trigger scans, CSV export, and data-health panel remain pending.
