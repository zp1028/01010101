# v0.8.72 — Chart geometry validation

## Changes
- `ChartMath.chartPriceRange` now admits an OHLC candle only when all four prices are finite/positive and the OHLC envelope is internally coherent.
- `ChartMath.scaleY` now prevents invalid values or non-finite geometry from propagating NaN/Infinity into Canvas coordinates, using a deterministic fallback.
- Added common unit tests for malformed OHLC envelopes and invalid scale inputs.

## Preserved
- AI request-generation guards, AI plan target isolation, scanner cards, EMA20/EMA50, and existing chart gestures/overlays remain in the source tree.
- Source-only delivery; no APK build.

## Validation
- ZIP integrity is checked after packaging. Unit tests and Gradle compilation have not been run; tests are added but not claimed as passing.
