# v0.8.50 — Favorites quick scan, CSV export, scan health

## Changes
- Added `ScannerViewModel.startWatchlistScan()`; it normalizes favorites, intersects them with Binance USDT-M futures universe, bypasses the regular universe cap, and caps phase-2 depth to the actual symbol count.
- Added a scanner toggle so the primary scan and pull-to-refresh use favorites-only mode when enabled. The existing watchlist display filter remains separate.
- Added a scan-health card with scan scope, failed symbol count, request progress, failure reasons and last completed scan time. Text explicitly distinguishes data-health checks from profitability.
- Added platform text-sharing abstraction. Android writes the CSV into app cache, shares it as a `.csv` attachment through FileProvider, and prunes exports older than 24 hours. CSV includes BOM for spreadsheet compatibility and quoted fields.
- Version bumped to 0.8.50 / versionCode 86.

## Validation
- Source-level inspection performed.
- ZIP integrity will be checked after packaging.
- Per request, no APK build was run. Kotlin compilation and device behavior remain unverified.
