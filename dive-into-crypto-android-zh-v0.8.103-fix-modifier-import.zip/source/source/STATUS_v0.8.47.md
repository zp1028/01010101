# v0.8.47 — AI session target isolation

## Changes
- AnalysisScreen now mirrors AI report text, status, running state, plan, and conversation history only when the shared AI session matches the currently selected symbol and timeframe.
- A scanner-triggered AI session for another symbol/timeframe no longer writes its report/status into the visible analysis screen.
- AI conversation history is reused only for the exact same symbol **and** timeframe; changing either starts with an empty context.
- Existing local technical indicators and local risk-plan fallback remain unchanged. AI does not execute trades.

## Validation
- Source-level diff and ZIP integrity checks performed.
- Android/Kotlin compilation and device navigation checks are not confirmed in this environment. Previous Gradle wrapper invocation could not download Gradle because the configured mirror hostname was not resolvable; do not treat this as a successful build.
