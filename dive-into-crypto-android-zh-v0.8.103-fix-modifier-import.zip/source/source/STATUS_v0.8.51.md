# v0.8.51 — Analysis chart interactions, EMA overlays, AI model discovery

## Changes
- Added pinch zoom, horizontal pan and reset-view interaction to the analysis mini chart.
- Added EMA20/EMA50 overlay calculations and display toggles to the primary panel chart; warm-up values remain undefined until enough candles exist.
- Added API-key-backed model discovery using the configured provider's `/v1/models` (or `/models` when Base already ends in `/v1`) endpoint, selectable model IDs, manual model entry fallback and error status.
- Continued chart-coordinate consistency work: visible candles and trend/pattern overlays use the same absolute candle start index; analysis-chart EMA values are calculated over the full candle history before slicing to the visible window; the plan entry price is included in vertical price bounds along with stop and target.

## Validation
- Source inspection and targeted static checks performed.
- Gradle test execution attempted but blocked before Gradle startup because the wrapper distribution is not cached and network access to `mirrors.cloud.tencent.com` failed (`UnknownHostException`).
- No APK build performed, per request. Kotlin compilation and on-device gesture/visual behavior remain unverified.
