# v0.8.79 — ChartMath compilation fix

## Changes
- Fixed an extra closing brace in `ChartMath.kt` that prematurely closed `ChartMath` before `axisDecimals`, `priceDecimalsFor`, `formatAxisPrice`, and the volume/delta helpers. This was a source-level compile blocker introduced in the prior chart-coordinate guard change.
- Kept the existing chart range and coordinate guards and their regression tests intact.

## Validation
- `kotlinc` parsing check reports unresolved project dependencies when compiling the file in isolation, but no syntax/brace errors after this fix.
- Gradle test execution was attempted (`:app:allTests --offline`) but the wrapper tried to download Gradle 8.10.2 from `mirrors.cloud.tencent.com`; DNS/network access failed (`UnknownHostException`).
- ZIP integrity checked after packaging. No APK built.
