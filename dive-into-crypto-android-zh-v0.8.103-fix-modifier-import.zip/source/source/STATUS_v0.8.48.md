# v0.8.48 — AI run generation race guard

## Changes
- Added a monotonically increasing generation to the shared AI session.
- Starting a new AI run, scanner AI request, custom question, clearing the session, or binding a different symbol/timeframe invalidates callbacks from older runs.
- Streaming deltas, final reports/plans, and errors only update the session when their generation is still current.
- Scanner/custom-question candle fetches stop before launching AI if a newer session has superseded them.
- History is reused only for the exact same symbol and timeframe.

## Validation
- Source inspection performed and ZIP integrity checked.
- Build and device tests remain pending because the Gradle distribution mirror was not resolvable in the previous build attempt.
