# Dive Into Crypto Android — v0.8.37

**versionName:** 0.8.37 · **versionCode:** 73

## 本版本（无构建/真机）

- 回测成本与 `RiskCostCalculator` 路径一致
- `BacktestAssumptions` 明确不模拟：资金费率、维持保证金、强平、历史宇宙/鲸鱼存档
- 成本与统计口径回归测试
- 排名回放 Phase1+Phase2（自 0.8.36）

## 任务对照（原 P0/P1）

| 项 | 状态 |
|----|------|
| 实时扫描器历史排名回放 | 多标的 Phase1/2 已实现；全市场 24h 宇宙需存档 |
| 回测与实盘规则一致 | 排名公式、共识 shouldTrade、成本路径已对齐 |
| 防历史泄漏 | 因果前缀 + gap + rankAtCut 校验 |
| 回测交易成本模型 | **已统一** path-aware；无 funding |
| 风险计划端到端 | Pipeline 测试已有 |
| 回测统计口径 | summarize 定义固定并有测试 |
| 行情连接完整回归 | 需真机/联调（本环境跳过） |
| Gradle/APK/真机 | 按要求跳过 |

## 仍需外部条件

- 历史 24h quoteVolume 宇宙、whale/OI/flow 存档
- 真机验收行情断线恢复
