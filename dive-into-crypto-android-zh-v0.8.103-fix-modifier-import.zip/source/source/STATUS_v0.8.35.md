# Dive Into Crypto Android — v0.8.35 状态说明

**versionName:** 0.8.35  
**versionCode:** 71  
**基于:** v0.8.34（因果断档检测）+ 阶段四排名一致性基础

## 本版本新增

1. **`ScannerRanking`** — 纯排名原语（finalScore、Phase-2 幸存者、per-TF top-N、cross-rank net_nss）
2. **`HistoricalScannerReplay`** — 因果 `rankAtCut` 契约；缺失宇宙/资金流时显式标记，禁止伪造
3. **实盘对齐** — `ScannerViewModel` 的幸存者选择与 Top-N 调用 `ScannerRanking`
4. **回测页「扫描器排名回放」** — Phase1 全标的 + Phase2 幸存者，多周期因果共识后排名

## 四阶段验收状态

| 阶段 | 状态 | 说明 |
|------|------|------|
| 一 行情生命周期与断线恢复 | 待完整回归 | 有实现，缺完整场景验收 |
| 二 指标/结构/计划一致性 | 待整体验收 | ATR/R 倍/高周期/防泄漏已有 |
| 三 风险计划与仓位管理 | 待端到端验收 | 计算有，界面贯通需验证 |
| 四 历史回测与实时扫描器一致性 | **部分完成** | 排名数学一致 + 多标的排名回放；缺历史成交额宇宙存档与 whale/OI/flow 历史 |

## 明确未完成（不夸大）

- 历史时点 24h quoteVolume 宇宙排序（需存档）
- Whale L/S、OI、taker、funding 历史回放
- 完整 Gradle / APK / 真机构建验收（环境可能无法下载 Gradle 发行包）
- 资金费率、维持保证金、强平模拟

## 回归测试（逻辑级）

- `ScannerRankingTest` / `HistoricalScannerReplayTest`
- `HistoricalCandleAlignmentTest`（因果 gap）
- `ScannerLogicTest` 中与 `ScannerRanking` 的幸存者一致性

独立逻辑测试 ≠ 完整 Android 工程验收。

## 构建提示

```bash
./gradlew :app:compileDebugKotlinAndroid
./gradlew :app:testDebugUnitTest   # 若 Android SDK / 依赖可用
```

若 `services.gradle.org` DNS 失败，需配置镜像或代理后再构建。
