# Forward plan lifecycle — v0.8.85

1. **Snapshot creation**: scanner candidates are locally generated from the completed scan snapshot. The journal stores the original plan and never edits its entry/stop/target fields.
2. **Deduplication**: an active or condition-confirmed plan with the same symbol, direction, type and primary timeframe suppresses near-identical triggers (within 0.20% of reference price). A materially changed setup may create a new snapshot.
3. **Waiting**: ticker price is informational. Crossing a trigger with a live tick does not count as confirmation.
4. **Closed-candle check**: only after live price crosses the trigger reference does the scanner request a bounded recent history sample. A candle must have `closeTime < now` and its close timestamp must be later than the plan snapshot before it can confirm the trigger.
5. **Invalidation**: expiry or excessive movement from the reference price marks the plan invalid/expired and asks for a fresh scan. A closed candle reaching the stop boundary invalidates the plan. Network failure leaves the plan waiting.
6. **Costs**: the displayed R:R uses configured fee and slippage assumptions for both entry and exit; it is an estimate, not a guarantee of realized execution cost.
7. **Persistence**: `forward_plan_journal_v1` stores up to 160 plan records and 500 recent events. History is capped to avoid unbounded settings storage growth.

The plan board is not an order-entry feature. `CONDITION_MET` means only that a later closed candle met the reference condition; it still requires manual review of current price, slippage, liquidity, and net risk/reward.
