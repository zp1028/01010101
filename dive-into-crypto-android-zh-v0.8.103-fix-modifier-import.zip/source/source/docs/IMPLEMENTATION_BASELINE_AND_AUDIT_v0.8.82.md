# Unified implementation baseline and source audit — v0.8.82

## User-approved baseline
- Preserve existing functionality; do not rewrite the app wholesale.
- AI must join the existing local analysis/ranking/plan decision path, not merely add a separate AI score or commentary.
- Keep the original local ranking as a comparison baseline.
- Add a separate forward-entry plan board, distinct from current-strength/consensus rankings.
- Candidate plan families: breakout preparation, retest preparation, reversal preparation, and trend continuation.
- A plan needs a timestamped snapshot, entry/trigger conditions, structural/ATR stop, targets, risk/reward, expiry, invalidation, status history, and revalidation after price drift.
- Add main-timeframe auto-selection, multi-timeframe conflict handling, false-breakout confirmation, constrained adaptive weights, historical evaluation, AI failure fallback, and auditability.
- No order execution; no APK build. Deliver full source, change log, actual test evidence, and explicit remaining-work list.

## Source observations confirmed by inspection
- `domain/consensus/ConsensusEngine.kt` already applies a local ADX-based regime matrix to indicator weights.
- `domain/scanner/ScannerRanking.kt`, historical replay/backtest classes, candle quality/freshness checks, risk plan calculators, opportunity lifecycle annotations, and evidence grading already exist.
- `data/ai/AiAnalysisClient.kt` provides an OpenAI-compatible analysis client with parsed plan output.
- `ai/AiSessionHub.kt` starts AI analysis for a selected symbol; the scan/ranking path inspected so far does not invoke AI as a ranking decision stage.
- `ui/scanner/ScannerScreen.kt` originally had `共识排行` and `启动排行`; `启动排行` is a presentation-only heuristic, not a persistent forward-plan lifecycle.
- Risk-plan UI calculations are reference-only and local; the existing scan lifecycle is a scan-to-scan annotation, not a durable plan record/state machine.
- `STATUS_v0.8.82.md` says full Gradle tests/build were not run because Gradle distribution download failed.

## Current passes
- `STATUS_v0.8.83.md`: local forward-plan engine and independent `前瞻计划` scanner board.
- `STATUS_v0.8.84.md`: persisted opt-in AI fusion setting and bounded AI advice integrated into the real scanner ranking chain before existing local elimination rules.

## Required remaining work
1. Persist immutable forward-plan snapshots and append-only status events; deduplicate across scans and version plans when structures change.
2. Add closed-candle trigger validation, explicit false-breakout filters, expiry enforcement independent of UI recomposition, and cost-aware revalidation at trigger time.
3. Add settings for primary timeframe policy, minimum plan quality, target R, maximum drift, plan lifetime, and AI-call budget; reuse existing settings where possible.
4. Connect persisted plan records and accepted AI reference plans to chart overlays and ensure shared timestamp/price coordinate alignment across zoom, pan, and timeframe changes.
5. Add constrained AI regime/weight advice; any adaptive weights must be bounded, replay-validated and approved out-of-sample before application.
6. Evaluate with historical replay and real-time paper observation; report sample size, trigger rate, invalidation rate, net expectancy, drawdown, adverse excursion, and improvement versus local baseline.
7. Run all available tests when the Gradle distribution can be resolved; no APK build.
