# Implementation audit baseline v0.8.87

This version continues v0.8.86; it does not replace existing scanner ranking, AI analysis, chart indicators or trading-risk checks.

## New chart behavior
The panel chart consumes `ForwardPlanJournal` snapshots. It shows up to three active/condition-met plans matching the currently selected symbol and timeframe. For each, it adds trigger, stop-loss and take-profit levels; if an accepted AI revision exists, it adds that revision's entry, stop-loss and take-profit levels. The chart's existing shared price range and y-axis transform include all reference levels, so the overlays follow the same vertical price coordinate when zooming/panning. Horizontal candle positions are not derived from plan timestamps: these are horizontal price reference levels, not timestamp-anchored event markers.

## Replay safety
`ForwardPlanReplayEvaluator` accepts a frozen plan, candles and explicit `asOfMs`. It only considers valid candles with `openTime >= generatedAtMs`, `closeTime > generatedAtMs` and `closeTime <= asOfMs`, sorted by close time and deduplicated by close time. If stop and target are both inside one OHLC candle, stop is assumed first. Output is an estimate from OHLC data and cannot reconstruct intrabar path, order-book fills, funding or exact slippage.

## Limitations
No claim is made that full Compose compilation or tests pass. Historical replay metrics, out-of-sample weight approval, plan history UI and end-to-end chart verification remain incomplete. No APK is built.
