# 国内网络访问（反向代理）

应用默认连接：

- REST: `https://fapi.binance.com`
- WebSocket: `wss://fstream.binance.com`

在中国大陆这两个域名常无法直连。请在 **设置 → 网络线路** 填写你自己的代理地址。

## 方案 A：Cloudflare Worker（免费）

1. 注册 Cloudflare，创建 Worker，粘贴：

```js
const REST = "https://fapi.binance.com";
const WS = "https://fstream.binance.com"; // Worker 升级为 WS 时用

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    // WebSocket 升级
    if (request.headers.get("Upgrade") === "websocket") {
      const target = "https://fstream.binance.com" + url.pathname + url.search;
      return fetch(target, request);
    }
    // REST：保留 /fapi/... 路径
    const target = REST + url.pathname + url.search;
    const resp = await fetch(target, {
      method: request.method,
      headers: request.headers,
      body: request.body,
    });
    return new Response(resp.body, {
      status: resp.status,
      headers: resp.headers,
    });
  },
};
```

2. 部署后得到 `https://你的worker.workers.dev`
3. 在 App 中填写：
   - REST: `https://你的worker.workers.dev`
   - WS: `wss://你的worker.workers.dev`
4. 点「保存线路」

## 方案 B：自建 Nginx（海外 VPS）

```nginx
server {
  listen 443 ssl;
  server_name proxy.example.com;
  # ssl_certificate ...

  location /fapi/ {
    proxy_pass https://fapi.binance.com;
    proxy_ssl_server_name on;
    proxy_set_header Host fapi.binance.com;
  }
  location /ws {
    proxy_pass https://fstream.binance.com;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_set_header Host fstream.binance.com;
    proxy_ssl_server_name on;
  }
}
```

App 填写：

- REST: `https://proxy.example.com`
- WS: `wss://proxy.example.com`

## 注意

- 不要使用来路不明的「币安镜像站」（钓鱼风险高）。
- 代理只转发公开行情接口，本应用不需要 API Key。
- 修改线路后立即生效；若 WebSocket 仍连不上，检查代理是否支持 Upgrade。
