# Dive Into Crypto Android — v0.8.36 状态说明

**versionName:** 0.8.36  
**versionCode:** 72  

## 本版本相对 v0.8.34/0.8.35

1. `ScannerRanking` + `HistoricalScannerReplay`（排名数学一致、因果 rankAtCut）
2. 实盘 ViewModel 使用共享排名原语
3. 回测页多标的排名回放：Phase1 → Phase2 幸存者
4. `RiskPlanPipelineTest`：计划/成本/仓位/回测统计贯通一致性
5. Gradle 发行包与 Maven 走腾讯云镜像，缓解 DNS 问题

## 四阶段

| 阶段 | 状态 |
|------|------|
| 一 行情生命周期 | 待完整回归 |
| 二 指标/结构/计划 | 待整体验收（流水线一致性测试已补） |
| 三 风险计划与仓位 | 计算链一致性测试已补；界面端到端仍待真机 |
| 四 回测↔扫描器 | 排名数学 + 多标的 Phase1/2 回放已落地；缺历史宇宙/资金流存档 |

## 未完成

- 历史 24h quoteVolume 宇宙存档
- Whale/OI/taker/funding 历史回放
- 无 Android SDK 时无法在本环境产出 APK
- 真机验收

## 构建

```bash
./gradlew :app:testDebugUnitTest
# 或
./gradlew :app:assembleDebug
```
