# v0.8.69 — Guard malformed OHLC and overlay values

## Changes
- Main chart skips malformed candles (non-finite/non-positive OHLC or inconsistent high/low) while preserving their index slots so overlays do not shift horizontally.
- Main-chart moving-average/indicator polylines break at invalid values instead of feeding invalid coordinates into Canvas.
- Analysis mini-chart applies the same malformed-OHLC guard and validates interpolated trendline prices immediately before drawing.

## Preserved
- Existing chart zoom/pan, EMA20/EMA50, trendline clipping, support/resistance and plan overlays remain in place.
- Source-only change; no APK built.

## Validation
- Source changes are packaged and ZIP integrity is checked.
- Gradle compilation, unit tests and real-device behavior have not been run; the new source changes are not claimed as runtime-validated.
