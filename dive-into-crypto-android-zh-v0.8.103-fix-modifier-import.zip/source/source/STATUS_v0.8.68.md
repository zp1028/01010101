# v0.8.68 — Chart price-domain validation

## Changes
- Hardened `ChartMath.chartPriceRange`: candle highs/lows and Bollinger-band values now enter the price domain only when finite and strictly positive.
- Added unit tests for malformed/non-positive price values and the all-invalid fallback case.
- This prevents bad market/indicator values from stretching the chart's vertical scale and flattening valid candles.

## Preserved
- Existing chart overlays, EMA20/EMA50, zoom/pan handling, trendline logic, scanner card controls, and AI settings remain in place.
- Source-only update. No APK was built.

## Validation
- ZIP integrity is checked after packaging.
- Gradle/unit tests and device behavior have not been run in this update; the new tests are added but not claimed as passed.
