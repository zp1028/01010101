# v0.8.102 — Post-scan AI unified review

- Moved AI fusion out of the local ranking phase; it now starts only after a local scan cycle has produced its final ranking snapshot.
- Expanded review from the top eight candidates to all rows in the completed cross-ranking snapshot, in chunks with concurrency limited to three requests.
- Added visible progress text for AI review and a completion count.
- AI can change the displayed long/short direction only when confidence is at least 78, fake-breakout risk is at most 55, and entry/stop/target geometry plus risk/reward checks pass. For a neutral local direction, AI needs confidence at least 78, fake-breakout risk at most 45, and a valid plan.
- Preserves the original local direction and marks AI direction changes for audit. No order-execution code was added.
- Build verification was attempted with `./gradlew :app:compileDebugKotlinAndroid --offline`, but Gradle 8.10.2 is not cached and the environment cannot resolve `mirrors.cloud.tencent.com`; compilation remains unverified.
