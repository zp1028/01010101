## v0.8.99 — Historical performance report + chart overlay regression guards
- Forward-plan replay report filters strictly to coverage-qualified target/stop outcomes; shows cumulative net-R, drawdown, win rate, expectancy, chronological train/OOS comparison and small-sample warnings.
- Weight-approval summaries now exclude resolved results without sufficient coverage.
- Centralized chart overlay price-domain expansion and added pure regression tests for entry/SL/TP alignment.
- Standalone performance and chart-scale smoke tests passed; full Gradle tests blocked by Gradle distribution DNS failure. No APK built. See `STATUS_v0.8.99.md`.

## v0.8.51
- Analysis chart pinch zoom, horizontal pan and reset view.
- EMA20/EMA50 overlays and provider API-key model discovery.
- Align analysis chart overlay indexing and calculate EMA from full candle history; include entry price in chart bounds.
- Validation blocked by unavailable Gradle wrapper download; no APK build. See `STATUS_v0.8.51.md`.

## v0.8.50 — Favorites quick scan, CSV file export & scan health

- Scanner: optional favorites-only scan bypasses the normal TOP20/TOP50 universe cap and still uses the normal scoring pipeline.
- Scanner: data-health panel reports universe size, failed symbols, request progress, failure causes and last scan time; it explicitly does not imply profitability.
- Scanner: export the currently visible/filtered rows as a UTF-8 BOM CSV file via Android share sheet, including timeframe signals, price, confidence, ATR, support/resistance and MTF fields.
- CSV files are written to app cache and old exports are pruned after 24 hours. No APK build requested/performed.

## v0.8.49 — Backtest & Alerts AI explain

- AiSessionHub.startWithQuestion: multi-TF fetch + custom prompt (shared by backtest/alerts).
- Backtest: AI 解读回测结果 button under metrics; streams interpretation of win rate / sample limits.
- Alerts digest: per-fired AI说明 with rule context; shows hub stream/report.

## v0.8.48 — Panel AI plan lines on chart + Signals AI explain

- CandleChartCard referenceLevels: dashed ENTRY/SL/TP with right labels; range expands to fit.
- Panel passes AiSessionHub lastPlan levels onto the main K-line chart for active symbol.
- Signals page: AI 解读 card — run multi-TF analysis via hub, show short + full report.

## v0.8.47 — Chart labels, scanner AI verdict, panel plan banner

- Analysis mini-chart: right-side labels SL/ENTRY/TP/S1/R1/LAST; pattern name above outline (Trend-IQ style).
- Scanner cards: show hub shortVerdict / AI 分析中 for matching symbol.
- Panel: AI plan banner above chart when hub has plan for activeSymbol.

## v0.8.46 — AiSessionHub + scanner AI + auto chart layers

- AiSessionHub (AppContainer): shared session, streaming, plan, scanner entry.
- Scanner row **AI** button → hub multi-TF analysis → navigate Analysis tab.
- Analysis AI uses hub; clear resets hub session.
- After 开始分析: auto-enable price lines, structure, trends, pattern outline, RSI, MACD (Trend-IQ-like auto overlay).

## v0.8.45 — AI settings page, stream channel, Analysis bottom tab

- Bottom bar: 面板 / 扫描 / **分析** / 信号 (OI·L/S moved to More).
- AI Base/Model/Key/enable live under Settings → 云端 AI 分析 (SettingsViewModel.updateAiSettings).
- Analysis page reads config from SettingsStore only; keeps question, multi-TF, AI plan toggle.
- Streaming: unlimited Channel + Main renderer job for incremental UI updates.

## v0.8.44 — Deep AI analysis (multi-TF, stream, follow-up, AI SL/TP)

- Multi-timeframe context: primary + up to two extra TFs (e.g. 15m/1h/4h) OHLC to the model.
- Streaming chat completions (SSE) with live text accumulation; non-stream fallback.
- Follow-up box + conversation history (last turns) for iterative analysis.
- Model must emit JSON plan; parsed into AiPlan → optional chart/card SL/TP (toggle 用AI计划 / 用引擎计划).
- Trend-IQ-style analysis prompt (direction, levels, scenarios); still research-only, no orders.

## v0.8.43 — Cloud AI market analysis (DeepSeek / OpenAI-compatible)

- User-configurable AI: base URL, model, API key (local SettingsStore), enable toggle.
- AiAnalysisClient: OpenAI-compatible /v1/chat/completions; sends recent OHLC + engine context; system prompt asks for independent technical analysis (not snapshot paraphrase).
- Analysis page: configure + 运行 AI 分析; shows full model response alongside engine plan.
- No screenshot pipeline. Engine SL/TP remain local; AI text is research-only.

## v0.8.42 — Analysis page P3 (structure stop / local explain / manual symbol)

- Structure-aware plan toggle: uses active support (long) or resistance (short) via StructureAwareRiskPlan; label shows ATR vs 结构+ATR.
- Local explain chips (non-cloud): direction / plan / tradeability / levels / pattern answers bound only to current snapshot.
- Manual symbol field + 切换 (screenshot OCR deferred; no fake image analysis).
- AnalysisExplain + AnalysisStructurePlan tests.

## v0.8.41 — Analysis page P2 (patterns / trend lines / watch)

- PatternDetector: V-reversal top/bottom, impulse fade, double top/bottom (rule-based, prefer miss over false positive).
- TrendLineBuilder: up to 2 swing segments on mini chart.
- WatchSession: arm/disarm, touch entry, hit SL/TP; updates when target-R slider changes plan.
- Analysis UI: pattern chip, outline highlight, trend lines, 图形/趋势线/轮廓 layers, 盯盘 card.
- Unit tests: PatternAndWatchTest.

## v0.8.40 — Analysis page P1 (structure / RSI·MACD / live price)

- Structure book: up to 3 confirmed supports & resistances; layer chips cycle S/R and toggle price lines.
- Mini chart draws active S/R dashed levels alongside entry/SL/TP.
- RSI(14) and MACD histogram strips with on/off chips.
- Live price from LiveTickerEngine when available (WS), else last close; live R:R updates with ticker.
- AnalysisPlanMath.structureBook / rsiSeries / macdSeries + tests.

## v0.8.39 — Analysis page P0 (chart levels + target-R slider)

- New primary route **分析** (`NavRoute.ANALYSIS`) in the More sheet; `AnalysisScreen` loads active symbol K-lines, consensus, ATR plan, mini chart with entry/SL/TP lines, signal strip, risk card, and narrative.
- **Target R slider (1.0–3.0)**: recalculates take-profit and R:R without changing entry/stop; chart levels stay in sync.
- Scanner coin card adds **分析** button next to 选择 →; navigates to Analysis with `activeSymbol` set (select still opens Panel).
- `AnalysisPlanMath` + unit tests for plan geometry and slider snap.

## v0.8.38 — Acceptance close-out (excluding device)

- Adds `StageAcceptanceIntegrationTest` covering stages 1–4 pure-logic gates: freshness/recovery, MTF eligibility, ATR plan math, cost→position→backtest summary chain, ranking parity, and causal leak rejection.
- Adds `ACCEPTANCE.md` formal matrix: pass / conditional / blocked-by-archive / excluded-device for every original checklist item.
- Archive-dependent full-market volume ranking and whale/flow historical filters remain explicitly blocked and surfaced via `HistoricalScannerReplay` limitations — not marked as passed.
- No APK or on-device verification in this release (per project decision).

## v0.8.37 — Unified path-aware backtest costs & explicit assumptions

- Aligns `RiskPlanBacktester` round-trip cost with `RiskCostCalculator`: (fee+slip)×(1+exit/entry) on known exits; 2×(fee+slip) only when exit is unknown.
- Adds `BacktestAssumptions` listing modeled vs intentionally not-modeled items (funding, liquidation, historical universe/whale archives) and a shared directional eligibility helper matching consensus confidence gates.
- Adds `BacktestAssumptionsAndCostParityTest` proving stop/target path costs match the risk cost calculator and documenting summary-stat definitions (win rate, arithmetic vs compounded return, max drawdown).
- Updates backtest UI limitation copy for ranking replay + path-aware costs. No APK/device work in this release.

## v0.8.36 — Risk-plan pipeline consistency & build mirror

- Adds `RiskPlanPipelineTest`: end-to-end checks that ATR plan → cost estimate → position sizing → backtest summary share the same stop/target/cost numbers (stop-path cost for sizing; summary stats match simulated trade nets).
- Multi-symbol scanner ranking replay on the backtest screen now runs Phase-1 across the symbol set then Phase-2 on survivors (same structure as the live scanner), not Phase-1 only.
- Points Gradle wrapper at the Tencent Cloud distribution mirror and adds Tencent Maven public mirror as a primary repository to mitigate `services.gradle.org` DNS failures.
- Does not claim full APK/device verification (Android SDK may still be absent). Historical 24h-universe and whale/flow archives remain out of scope.

## v0.8.35 — Historical scanner ranking parity foundation

- Extracts pure ranking primitives (`ScannerRanking`) shared by the live multi-TF universe scanner and historical replay: `finalScore`, phase-2 survivor selection, per-TF top-N, and cross-rank `net_nss` aggregation.
- Adds `HistoricalScannerReplay` with a causal `rankAtCut` contract: only cells whose last candle open time is strictly before the cut are accepted; missing 24h-universe ranking and whale/flow/OI archives are explicitly marked in the report instead of fabricated.
- Provides leakage-safe `causalPrefix` and gap-crossing helpers that reuse `HistoricalCandleAlignment`.
- Adds regression coverage for score formula, phase-1 survivor ordering, cross-rank buy/sell nss, universe scoping, future-cell rejection, and gap detection on historical prefixes.
- Live `ScannerViewModel` phase-2 survivor selection and per-TF top-N now call `ScannerRanking` so ranking math cannot drift from historical replay.
- Backtest screen gains a multi-symbol **扫描器排名回放** section: Phase-1 across the symbol set, Phase-2 on survivors (same structure as the live scanner), causal consensus cells, `rankAtCut`, and explicit limitation reporting when universe volume order / whale archives are absent.
- This establishes ranking-math parity and a first end-to-end ranking-replay path on public klines; it does **not** yet acquire historical 24h-volume universe archives or whale/OI/flow series. Full Gradle/APK/device verification remains pending.

## v0.8.34 — Causal candle-gap cadence estimation

- Fixes look-ahead in historical gap diagnostics: expected candle cadence is now estimated only from intervals preceding each interval under inspection, never from future candles.
- Uses a bounded 32-interval prior window and requires at least three prior intervals before classifying a cadence discontinuity, avoiding confident judgments where the available history is insufficient.
- Adds regression tests proving that future cadence changes cannot retroactively alter earlier gap classification and that a gap is detected against the prior cadence.
- This is a replay-integrity fix; it does not establish full multi-symbol scanner parity. Full Gradle/APK/device verification remains pending.

## v0.8.33 — Gap-aware historical replay

- Detects materially irregular open-time intervals using the median candle cadence and prevents backtest signals from being traded when the signal/risk lookback or next-open entry crosses a data discontinuity.
- Counts gap-affected directional signals as filtered rather than simulating fills across missing history. No synthetic candles or prices are generated.
- Adds regression coverage for regular cadence and a multi-candle time gap. This is a conservative replay guard, not full cross-market scanner parity. Full Gradle/APK/device verification remains pending.

## v0.8.32 — 统一回测与扫描器 K 线清洗规则

- SMA/指标共识历史回测现在复用 `HistoricalCandleAlignment.sanitize`，与高周期确认和数据质量报告采用同一套 OHLC、时间、成交量及重复时间戳校验。
- 修复历史回测路径与扫描器数据清洗规则不一致的问题：负成交量、NaN/无穷成交量的 K 线不会进入回测指标与成交模拟；零成交量仍保留。
- 新增回归测试：在历史序列中插入负数、NaN 和无穷成交量记录后，回测信号计数和交易结果必须与清洁样本一致。
- 不改变扫描排名或交易执行能力。独立逻辑验证不替代完整 Gradle、APK 和真机验收。

## 0.8.31 — Reject malformed volume data in historical candles
- Extends shared historical candle sanitation to reject negative or non-finite volume values, which can corrupt volume-based indicators and scanner-consensus replay even when OHLC prices look valid.
- Keeps zero-volume candles valid, since zero volume can be a legitimate market-data value.
- Adds alignment and data-quality regression tests proving invalid-volume bars are counted as discarded instead of silently entering indicator calculations.
- This improves input hygiene only; it does not add historical whale/flow reconstruction or claim full scanner replay parity. Full Gradle/APK/device verification remains pending.

## 0.8.30 — Report candles discarded by data sanitation
- Runs historical quality analysis against the closed but pre-sanitized input, and reports how many malformed or duplicate candles were discarded by the shared sanitizer.
- Keeps the replay input sanitized and leakage-safe while making silent data cleanup visible to the user.
- Adds regression coverage for malformed OHLC bars and duplicate timestamps. This does not fill missing data or claim full scanner replay parity.
- Full Gradle/APK/device verification remains pending.

## 0.8.29 — Detect off-grid historical candle intervals
- Adds an explicit count of materially irregular open-time deltas. Previously, nearest-slot rounding could make an off-grid timestamp gap look like a normal interval.
- Exposes irregular interval counts in backtest results and warns when either missing slots or off-grid intervals are present. No synthetic bars are created.
- Adds a regression test for an interval that is 1.4 times the expected timeframe, which must be surfaced as irregular rather than silently treated as a clean sequence.
- This improves historical-data diagnostics only; it does not claim full market-wide scanner replay parity. Full Gradle/APK/device verification remains pending.

## 0.8.28 — Historical coverage and gap severity
- Replaces the backtest screen's private gap counter with a shared, unit-testable historical-data quality analyzer. It sanitizes duplicate/malformed bars before counting expected slots.
- Reports estimated candle coverage percentage and the largest contiguous missing-bar run alongside total missing intervals, so a small isolated gap is distinguishable from a large data hole.
- Adds regression tests for contiguous histories, missing intervals, duplicate timestamps, and unsupported timeframe handling. No candles or prices are synthesized.
- This remains a quality diagnostic, not full scanner replay parity. Full Gradle/APK/device verification remains pending until the Gradle distribution is available.

## 0.8.27 — Historical data-gap diagnostics
- Counts expected missing candle slots in the sanitized lower-timeframe history before replay; gaps are surfaced in the result/status instead of being silently treated as a continuous sequence.
- Does not fabricate candles or prices to fill gaps, avoiding synthetic price data that could distort indicators or simulated exits.
- This is a data-quality warning only; it does not replace full scanner parity, funding-rate modeling, Gradle test execution, APK build, or device verification.

## 0.8.26 — Unified higher-timeframe candle sanitation
- Reuses the shared historical candle sanitizer for SMA higher-timeframe confirmation, including open-price and non-negative timestamp validation, rather than maintaining a weaker second validator.
- Keeps confirmation bars sorted by availability (close time) before strict-close binary lookup; same-time bars remain ineligible for a signal at that exact close time.
- Adds regression tests for invalid open prices, negative open times, and non-monotonic close-time alignment.
- This is a data-quality consistency improvement, not a claim of full scanner strategy parity. Full Gradle/APK/device verification remains pending because Gradle 8.10.2 cannot be downloaded in the current environment.

## 0.8.25 — Strict higher-timeframe close-time lookup
- Sorts higher-timeframe confirmation bars by the time they become available (close time), with open time as a deterministic tie-breaker.
- Replaces a forward-only confirmation cursor with a binary search per signal, so non-monotonic signal close times cannot accidentally reuse a future higher-timeframe bar. Bars closing exactly at the signal close remain excluded.
- Adds regression coverage for strict boundaries, equal close times, and lookup behavior across non-monotonic signal timestamps.
- This is a single-symbol historical replay correctness improvement; full market-universe ranking and flow/whale overlays remain outside the replay. Full Gradle/APK/device verification remains pending until the Gradle distribution is available.

## 0.8.24 — Resolve opening gaps before intrabar ambiguity
- Improved OHLC replay ordering: when a valid candle opens beyond a stop or target, the opening-gap event is resolved before checking the rest of the candle's high/low range.
- Stop gaps fill at the worse observed open; target gaps fill at the target price. The existing conservative stop-first rule remains for bars where both levels are touched intrabar and the open itself does not resolve the outcome.
- Added long and short regression tests for target gaps followed by a move through the stop in the same candle.
- Research-only assumptions remain simplified; real order-book fills, partial fills, funding, and market impact are not modeled. Full Gradle/APK/device verification remains pending due to unavailable Gradle distribution download.

## 0.8.23 — Backtest run configuration consistency
- Snapshot every selected backtest input before starting asynchronous history retrieval, so edits made to the form while a run is loading cannot mix symbols, timeframes, risk settings, costs, or strategy parameters in one result.
- Corrected the SMA higher-timeframe result label to display the actual configured fast/slow periods instead of a hard-coded SMA9/21 label.
- Clarified the higher-timeframe help text: scanner-consensus mode uses the same indicator consensus engine and `shouldTrade` gate on strictly earlier-closed higher-timeframe bars; SMA mode uses its configured moving-average trend filter.
- This is a UI/run-consistency hardening pass. Full Gradle tests/APK/device verification remains pending because the Gradle distribution download is unavailable in this environment.

## 0.8.22 — Historical candle alignment hardening
- Centralized historical candle sanitization for backtest inputs: invalid OHLC/time records are dropped, bars are sorted, and duplicate open-time revisions resolve deterministically to the last record.
- Scanner-consensus higher-timeframe confirmation now uses a shared strict-close alignment helper, excluding bars that close at the same instant as or after the signal candle.
- Added regression tests for unsorted inputs, duplicate revisions, malformed candles, and simultaneous/future higher-timeframe bars.
- This hardens single-symbol historical replay; full market-universe ranking and flow/whale filters are still not replayed. Full Gradle/APK/device verification remains pending because the Gradle distribution could not be downloaded in this environment.

## 0.8.21 — Consensus replay higher-timeframe confirmation
- Extended the scanner-consensus backtest mode with optional higher-timeframe confirmation using the app's own indicators and consensus engine, rather than applying the SMA-only filter used by the example strategy.
- Each lower-timeframe signal only sees higher-timeframe candles whose close time is strictly earlier than the signal candle close; the higher-timeframe consensus must have a directional signal in the same direction and pass `shouldTrade`.
- Captures the higher-timeframe toggle before launching asynchronous work, and reports which confirmation logic was used in the results.
- This remains single-symbol replay and does not reproduce full-market ranking or supplemental flow/whale filters. Full Gradle/APK/device verification remains pending due to unavailable Gradle distribution download.

## 0.8.20 — Historical scanner-consensus replay
- Added a selectable scanner-consensus replay mode that recalculates the app's configured indicator set and consensus engine on each historical candle prefix, using no candles after the signal close.
- Only directional consensus signals passing the existing `shouldTrade` gate open simulated positions; directional signals rejected by the gate are counted as filtered.
- Reuses the existing next-candle-open entry, ATR/structure risk planning, stop-first intrabar handling, cost estimates, and trade summary pipeline.
- Runs the CPU-heavy historical indicator replay on a background dispatcher to avoid blocking the UI.
- This is a single-symbol/single-timeframe consensus replay, not the full scanner universe ranking or all supplemental flow/whale/multi-timeframe filters. Full Gradle/APK/device verification remains pending.

## 0.8.17
- 修正回测参数校验：使用 ATR 动态止损/止盈时，不再错误校验未参与计算的固定百分比止损/止盈输入；固定百分比模式仍严格校验有效范围。
- 新增回归测试，验证 ATR 回测不会被无关的固定百分比字段阻断。

## 0.8.16 — Align position sizing costs with the stop-loss path


- Position-risk sizing now uses the estimated fee/slippage cost on the stop-loss exit path, rather than the larger of stop-path and target-path costs. This aligns the estimated stop loss with the same exit scenario; the UI still displays the conservative maximum round-trip cost separately.
- The estimate remains approximate and excludes funding, liquidation/maintenance margin, variable fills and market impact.
- Added a regression test for cost-path selection. Full Gradle/APK verification remains unverified until the Gradle distribution can be fetched.

## 0.8.5 — Higher-timeframe confirmation for historical replay

- Added optional higher-timeframe SMA trend confirmation to the historical backtest: 15m→1h, 30m→4h, 1h→4h, and 4h→1d.
- Confirmation uses only higher-timeframe candles whose close time is strictly earlier than the lower-timeframe signal candle close, preventing use of an unfinished or simultaneous higher-timeframe candle.
- Results now separate raw crossover events, confirmed events, and trend-filtered events; single-timeframe comparison remains available.
- Added regression tests for missing confirmation data, future higher-timeframe candles, and signal accounting.
- Still a simplified SMA example, not the scanner's full signal engine. Funding, liquidation, maintenance margin, partial fills, and market impact are not modeled. Full Gradle/APK verification remains unverified where the Gradle distribution cannot be downloaded.

## 0.8.4 — Live-data historical SMA backtest screen

- Added a reachable “历史回测” screen under the More menu, using Binance USDT-M public historical klines (no account keys and no order execution).
- Added configurable symbol, 15m/30m/1h/4h timeframe, 100/300/500 candles, fast/slow SMA periods, stop/target percentages, and per-side fee/slippage assumptions.
- Added a deterministic SMA crossover replay with one simulated position at a time, closed-candle filtering, stop-first same-candle handling, a 48-bar time limit, estimated costs, summary metrics, and recent trade outcomes.
- Added unit tests for invalid parameters, insufficient history, deterministic output, and cost accounting.
- This is an explicitly simplified example strategy, not the scanner's complete multi-timeframe signal engine. Funding, liquidation, maintenance margin, partial fills, and market impact are not simulated. Full Gradle tests/APK build remain unverified because the configured Gradle distribution could not be fetched in this environment.

## 0.8.1
- Connected confirmed non-repainting swing support/resistance levels from scanned candles to risk-plan cards.
- Main plan and conservative/standard/aggressive comparisons now use structure + ATR buffer when a valid directional level exists, otherwise clearly fall back to ATR.
- Added unit tests for nearest confirmed levels and insufficient/invalid data handling.
- Risk planning remains informational only; no order execution was added. Full Gradle validation still depends on access to the configured Gradle distribution.

## v0.7.8 — Preserve trusted lifecycle baseline across partial scans

- Opportunity lifecycle comparisons now use a dedicated last-completed snapshot instead of the visible `survivors` list, which may contain provisional preview rows.
- The trusted baseline advances only when a scan completes with full coverage; interrupted or partial scans can still show useful results but cannot reset lifecycle review state.
- Added regression coverage for reassessing a reversed direction against a new completed baseline and retaining the old baseline across partial scans.
- Risk plans remain display-only; this does not submit orders. ZIP integrity can be verified locally, but Gradle tests/APK build remain unverified because `services.gradle.org` DNS resolution failed in this environment.

## v0.7.2 — Persisted risk-plan parameters wired into live card calculations

- Connected target R, per-side fee and per-side slippage to `SettingsStore` persistence with bounded defaults.
- Risk cards now expose +/- controls for target R (0.50–5.00, 0.25 step), fee (0–1.00%, 0.01 step), and slippage (0–2.00%, 0.01 step).
- ATR-based take-profit levels and estimated net R:R recalculate from the selected settings; fee/slippage assumptions are displayed explicitly.
- Added tests for defaults and persistence across `SettingsStore` recreation.
- These are analysis-only controls; no order execution was added. Gradle/APK validation remains blocked until the Gradle distribution can be downloaded.

## v0.6.8 — Full scanned-timeframe accumulation evidence coverage

- Accumulation/distribution summaries now use every successfully scanned timeframe for each displayed symbol, not only results that entered each timeframe's Top 15.
- After timeframe backfill scans, the display-only accumulation summary is recomputed so newly available evidence is included.
- Added a regression test proving an out-of-Top-15 timeframe can contribute conflicting evidence while the original ranking score remains unchanged.
- Gradle test execution remains unverified when the Gradle distribution host cannot be resolved.

## v0.6.2 — WebSocket reconnect data freshness + gap fill

- **Panel**: after a WS quiet/stale period, the first live kline frame triggers a best-effort REST history refill when the local candle series is more than ~2 intervals behind wall-clock. REST wins on duplicate openTimes; failures leave last real data (no fabricated ticks).
- **LiveTickerEngine**: when the mini-ticker stream resumes from stale, one immediate `/ticker/24hr` REST merge runs so change% and coverage catch up without waiting for the next 60s cycle.
- Existing `reconnectingFlow` / `reconnectingKlineStream` / `reconnectingMiniTickerStream` backoff (1s→2s→4s…cap 30s, ±20% jitter, reset on first frame) unchanged.
- No change to scoring, ranking, or signal logic.

## v0.6.1 — Scan task mutual exclusion, stale-result isolation, stop cleanup

- **Prevent duplicate scans**: `startScan()` is a no-op while `scanning` is true; the active coroutine is tracked as `scanJob`.
- **Stale-result isolation**: a monotonic `scanGeneration` token is bumped on every start and on stop. Late phase updates and final result commits from an older generation are discarded, so a stopped or superseded scan cannot overwrite newer UI state.
- **Stop cleanup**: `stopDemoScan()` sets the cooperative stop flag, cancels `scanJob`, bumps generation, and immediately clears `scanning` / progress / loading / phase flags so the UI never stays in a fake running state.
- Progress, current-symbol, and failure-count updates are also gated by the current generation.
- No change to scoring, ranking, confidence, or signal logic.

## v0.6.0 — Preserve cancellation through best-effort side effects

- Alert evaluation and verdict-evidence persistence remain best-effort when ordinary failures occur.
- Explicitly rethrow `CancellationException` from both blocks so stopping a scan or cancelling its parent job cannot be mistaken for a successful completed scan.
- This is a lifecycle correctness fix; it does not change signals, confidence calculations, ranking, or trading execution.

## v0.5.9 — Bound confidence conflict calculations to expected timeframe sample

- Confidence coverage, conflict count, and conflict ratio now use the same bounded set of valid timeframe directions.
- Extra direction entries beyond `expectedTimeframes` can no longer add conflict penalties while displayed coverage is capped.
- Added a regression test for extra directions beyond the declared timeframe budget.
- This affects confidence adjustment only; underlying votes and ranking score remain unchanged. Full Gradle/APK validation is still required.

## v0.5.8 — Unified displayed confidence across scanner surfaces

- Scanner cards and shared verdict cards now use the same coverage/conflict-adjusted confidence as the feed, alert verdicts, and evidence records.
- Raw per-timeframe confidence remains visible in the timeframe cells, while the main confidence number now reflects missing timeframe coverage and directional conflicts.
- No change to the underlying cross-rank score or indicator votes.
- Full Gradle/APK validation remains dependent on a working Gradle distribution download.

## v0.5.6 — Scanner coroutine fan-out reduction

- Reduced phase-1 and phase-2 scan task allocation from one coroutine per symbol/timeframe cell to one coroutine per symbol.
- Preserved the existing semaphore limit, per-timeframe scan sequence, scoring formulas, and stop-request checks.
- This reduces peak Deferred/job allocation for ALL-universe scans; it does not claim faster network throughput or replace full Gradle validation.

## v0.5.5 — Scanner cancellation propagation

- Preserved coroutine cancellation in scanner startup, universe loading, divergence timeouts, OI alert enrichment, and per-timeframe divergence fetches. Lifecycle cancellation is no longer swallowed as a network error or partial success.
- Kept graceful degradation for ordinary auxiliary API failures and the explicit timeout fallback for optional divergence enrichment.
- No changes to indicator votes, opportunity ranking, or order execution; scanner remains analysis/alert only.

## v0.4.8 — Partial-scan lifecycle safety

- Prevented incomplete/failed scans from counting absent symbols as disappeared opportunities.
- Lifecycle summary now records coverage completeness; the scanner shows “扫描不完整，消失待确认” if any symbols failed or the scan did not cover the full target universe.
- Added regression tests for both complete and partial scan disappearance behavior.
- Analysis and presentation only; no automatic order execution.

## 0.3.2 — SMC liquidity overlays

- Added independently implemented EQH/EQL candidate liquidity levels, clustered within a configurable 0.15% price tolerance. These are chart heuristics, not claims of observed resting orders.
- Added Premium / Equilibrium / Discount shading from confirmed swing pivots, with separate chart toggles.
- Active FVG regions now extend until fully mitigated; mitigated gaps are hidden. Candidate order blocks extend across the chart and are hidden after a close through the far boundary.
- Added pure Kotlin tests for equal-high/equal-low clustering, swing-range calculation, and insufficient-history handling.
- Existing chart component retained; no order execution was added.

## 0.3.1 — Chart overlay and signal-analysis upgrade

- Added AVL average-price overlay, explicitly defined as typical price `(High + Low + Close) / 3`; it is distinct from volume-weighted VWAP.
- Added independent MACD + SMA200 strategy-condition annotations based on the supplied SMA(12/26/9) reference. Signals are visual analysis only; no orders are submitted.
- Required a fully warmed-up SMA200 before drawing SMA200 or emitting strategy signals; increased the chart analysis window to 300 candles so the 200-period filter can operate when data is available.
- Added common unit tests for AVL alignment, MACD warm-up behavior, and SMA200 signal warm-up.
- Added GitHub Actions CI for common tests and Android debug APK build; made `gradlew` executable in the archive.
- SMC overlays remain an independent implementation of generic market-structure concepts (BOS/CHoCH, FVG, and order-block approximations); no LuxAlgo source code was copied. Full LuxAlgo parity is not claimed.

## 0.8.6 — Conservative gap fills and historical candle sanitization

- Stop-loss exits now account for adverse candle-open gaps: long stops fill at the lower open when price gaps below the stop, and short stops fill at the higher open when price gaps above the stop. This avoids idealized stop fills on discontinuous candles.
- Historical replay rejects malformed candle time ranges and invalid OHLC relationships, sorts candles, and collapses duplicate open timestamps deterministically before indicators are calculated.
- Applied the same OHLC/time validation and duplicate timestamp handling to higher-timeframe confirmation candles.
- Added regression tests for long/short gap-through-stop execution and dirty historical candle inputs.
- This remains a simplified SMA strategy. Stop-gap fills use candle open as a conservative proxy; spread, order-book depth, funding, liquidation and actual exchange matching are not modeled. Full Gradle/APK verification remains unverified.

# Changelog

## v0.2.0 — 2026-09-11

**Honesty release: all random-data fabrication removed; the promised weights and overlays are actually wired.**

### Removed — nothing is synthesised anymore
- **Signals screen:** the "fallback ticker" that synthesized a price every second (`lastClose × (1 ± 0.02%)`) while the WebSocket was quiet — and silently recomputed consensus on those FAKE ticks — is deleted. Quiet streams now expose explicit staleness state (`isStale` + `dataAgeMs`) and stop feeding data.
- **Positions (OI · L/S) screen:** the simulated price fallback and the entire simulated-series injection (random OI value, long/short account & position & global ratios, taker volumes) are deleted. REST-refreshed series keep their last REAL points; staleness is labelled instead.
- A full `Random`/`nextDouble` sweep of commonMain confirms no market-data synthesis remains (the only randomness left is reconnect-backoff jitter, which is not data).

### Fixed — the "weighted consensus" was only half true
- The full **57-name weight map** was defined but never consumed: the 42 extended indicators silently scored at weight 1.0. The map is now the canonical source (`domain/consensus/Weights.kt`) wired into `SettingsStore` defaults and `ConsensusEngine` construction — core 15 keep the F2 matrix values (existing verdicts unchanged), extended 42 take their desktop-reference weights (e.g. `squeeze 2.5`, `supertrend 2.0`). User overrides in Settings still win.

### Added — overlays, resilience, live panel
- **Three strategy overlays are finally live as ADDITIVE annotations** (they never touch the parity-locked vote): Regime (`TREND/RANGE/MIXED`), MTF-confluence (score/direction/gate/label), and Microstructure (score/direction/label/active signals) — on Scanner rows and the Panel.
- **WebSocket self-healing**: `BinanceWsClient.reconnectingKlineStream` (exponential backoff 1s→2s→4s…cap 30s, ±20% jitter, reset on first frame, reconnects on graceful close too). The ViewModels' `while(true){collect}catch{delay}` restart loops are gone.
- **Panel live recompute**: verdict (multimodal + regime + microstructure + MTF) recomputes over cached candles at most every 5s or on candle close, and the state is re-emitted only when a value actually changed; the 12-TF grid refreshes on candle close.
- **Scanner honesty**: `failedCount` exposes symbols whose fetch failed (previously swallowed); per-TF cells are backfilled for ALL displayed rows (previously only the first 24); the duplicate `feed`/`hotList` state fields, unused `selectTimeframe`, and dead `MAX_PARALLEL`/`PHASE2_TOP_N`/`FINAL_TOP_N` constants are removed; the risk label logic is now one canonical `ScannerViewModel.riskFromAgreement`.

### Fixed — housekeeping
- Candle cache is a **bounded LRU (96 keys)** — it used to grow without bound in the app-scoped engine (~500 symbols × 12 TF keys).
- targetSdk 34 → 35; versionCode 2; versionName 0.2.0.
- Theme-count typo in the v0.1.0 notes below corrected: **10** presets ship, not 9.

### Tests
- Suite grown 129 → **150** unit tests (all green): WS backoff/reconnect schedule, LRU eviction, full-weights persistence + wiring, scanner cross-rank / elimination-backfill / per-TF backfill / risk bands.

## v0.1.0 — 2026-06-07

First public release.

- Binance USDT‑M perpetual‑futures consensus scanner: **15 technical indicators across 12 timeframes**.
- Two‑phase market sweep (coarse high‑timeframe pass over the whole universe, then a fine low‑timeframe pass on survivors).
- Weighted‑vote consensus with regime‑adaptive weighting, conflict override, confidence scoring, and a risk assessor.
- **Whale‑divergence filtering** from Binance top‑trader long/short positioning, with adverse‑coin elimination and back‑fill.
- Independent microstructure consensus (price state · open‑interest momentum · taker aggression) for the OI · L/S leaderboard.
- Eight screens: Scanner, Panel, Signals, Positions (OI · L/S), Performance, Network Log, Appearance, Settings.
- English UI, 10 theme presets, on‑device preferences.
- Reads only public Binance market data — no account or API keys.
- Android 8.0+ (minSdk 26), targetSdk 34. Signed release APK, ~3.6 MB.


## 0.3.4 — REST resilience and candle-cache correctness

- Added bounded retries for idempotent public Binance REST reads: transient transport failures, HTTP 408/418/429, and HTTP 5xx; cancellation and ordinary client/input errors propagate immediately.
- Applied the retry policy to spot/futures kline history, futures universe discovery, and the all-symbol 24h ticker request.
- Fixed duplicate-timestamp merge precedence so fresh REST candles override stale cached/WebSocket values.
- Added deterministic tests for retry success, attempt limits, non-retryable client errors, and cancellation.

## 0.3.5 — alert input validation

- Prevented price alerts from firing on non-finite or non-positive prices and invalid thresholds.
- Validated consensus confidence and reference price before firing verdict alerts; confidence alerts now reject thresholds outside 0–100.
- Rejected non-finite open-interest changes and hardened the OI change helper against invalid samples/overflow.
- Added deterministic regression tests for invalid price, confidence, threshold, and OI inputs.


## 0.3.6 — alert rule and symbol matching hardening

- Reject empty-symbol or empty-condition alert rules and invalid condition thresholds/directions at creation time.
- Reject negative alert coalescing windows.
- Normalize new rule symbols by trimming whitespace and uppercasing.
- Resolve ticker, scan-verdict, and OI alert inputs case-insensitively to prevent silent misses caused by symbol casing differences.
- Added a regression test for case-insensitive price-alert input matching.

## 0.3.7
- Harden alert dispatch against concurrent ticker/scan evaluations: re-check each fired event against the current rule, enabled state, and cooldown while holding the engine lock.
- Ignore duplicate or stale fired snapshots and never reintroduce removed alert rules; only accepted events are persisted, shown in the banner, and sent to the notifier.


## 0.3.8 — scanner result freshness clarity

- When a scan is in progress and previous completed results are retained on screen, show an explicit Chinese notice with the previous completion timestamp.
- Prevents users from interpreting the last completed ranking as the in-progress scan's current/final result; existing continuity behavior and prior results remain intact.


## 0.3.9 — scanner candle-quality gate

- Added a pure Kotlin OHLCV quality gate before indicator calculation: validates finite/positive prices, non-negative volume, consistent OHLC ranges, ordered unique timestamps, sufficient history, and latest-candle freshness relative to timeframe.
- Invalid/stale candle responses are excluded from consensus ranking and counted in the existing failed-symbol coverage metric instead of being presented as fresh opportunities.
- Added deterministic unit tests for valid data, stale data, duplicate timestamps, and inconsistent OHLC ranges.
- No order execution added.


## 0.4.0 — multi-timeframe confluence validation

- Collapse duplicate timeframe verdicts so repeated data cannot inflate multi-timeframe scores or agreement.
- Ignore verdicts with confidence outside 0–100 and reject invalid agreement thresholds.
- Keep the higher-timeframe confirmation gate closed until at least two distinct higher timeframes have valid directional verdicts.
- Expose valid timeframe coverage and directional conflict in the confluence result for downstream display/debugging.
- Added regression tests for partial HTF coverage, duplicate timeframe inputs, invalid confidence, and invalid gate thresholds.
- No order execution added.

## 0.4.1 — reference risk plan calculation

- Added a pure Kotlin ATR-based reference-plan calculator for long and short scenarios, producing entry, stop-loss, take-profit, stop distance, and risk/reward ratio from consistent price units.
- Rejects non-finite or non-positive entry/ATR/multipliers/target-R, stop distances that would invalidate the price, and non-finite resulting levels.
- Added deterministic tests for long/short price-level orientation, 2R reward targets, and invalid inputs.
- This is analysis-only: it does not execute or transmit orders.


## 0.4.2
- Wire the shared ATR risk-plan calculator into scanner opportunity cards.
- Display direction-aware reference entry, stop-loss, and take-profit prices for unambiguous BUY/SELL signals.
- Do not generate directional price levels for neutral/conflicting signals.
- Keep risk-plan values informational only; no order execution, and explicitly note fees, slippage, leverage and liquidation are not modeled.


## v0.4.3 — Risk-plan clarity

- The scanner risk card now labels the displayed risk/reward ratio as **gross** and explicitly states that transaction costs are excluded.
- Expanded the risk warning to name funding fees as excluded alongside commissions, slippage, leverage, and liquidation mechanics.
- Added a regression test for stop-distance percentage and reward-distance consistency.
- No order execution or position automation was added.


## v0.4.4 — MTF risk-plan conflict gate
- Added a pure Kotlin eligibility gate for directional reference risk plans.
- Suppresses directional stop/target levels when the available multi-timeframe direction explicitly conflicts with the dominant signal.
- Shows a clear Chinese conflict message; scanner ranking and signal scores remain unchanged.
- Added unit tests for neutral, aligned, unavailable, and conflicting MTF states.


## 0.4.5 — Opportunity lifecycle review
- Added scan-to-scan opportunity lifecycle classification: new, active, direction reversed, price moved materially, or invalid data.
- Added a compact lifecycle summary and per-opportunity status note to scanner results.
- Direction reversal and material price changes explicitly warn that the previous risk plan needs review.
- Added pure Kotlin regression tests for lifecycle transitions and disappeared symbols.
- Lifecycle annotations are informational only and do not change scoring, ranking, or execute orders.


## 0.4.6 — Opportunity lifecycle accuracy
- Fixed a user-facing percentage formatting bug: a 3% scan-to-scan move is now shown as 3%, not 300%.
- Validate blank symbols and invalid prior directions before lifecycle comparisons.
- Normalize symbols with trim + uppercase and deduplicate lifecycle summary rows to prevent duplicate counting across merged scan sources.
- Added regression tests for percentage text, symbol normalization, duplicate rows, and blank symbols.
- Informational lifecycle only; scanner ranking and order execution remain unchanged.

## 0.4.7
- Harden opportunity lifecycle comparison: validate previous price before classifying direction reversal.
- Require normalized symbol identity between current and previous snapshots.
- Normalize previous-snapshot lookup keys in scanner lifecycle annotations.
- Add regression tests for invalid prior prices and mismatched symbols.

## 0.4.9
- Expose scan failure causes in the scanner UI, distinguishing network/API failures from insufficient, stale, unordered, or malformed OHLCV data.
- Keep distinct-symbol failure totals separate from per-timeframe request failure reason counts so coverage warnings are more actionable.

## 0.5.0
- Discount displayed/alert/evidence confidence when the symbol has incomplete timeframe coverage or opposing non-neutral timeframe signals.
- Add pure Kotlin confidence-quality logic and regression tests. Base indicator confidence and ranking score remain unchanged.

## 0.5.1 — Microstructure missing-data honesty
- A microstructure overlay with no usable inputs now reports `INSUFFICIENT_DATA` with a null score/direction instead of a fabricated-looking neutral `0`.
- The overlay exposes coverage across its six signals; scanner tags and the Panel show when an estimate is based on partial auxiliary data.
- Scanner microstructure fetches now isolate failures per auxiliary endpoint, so missing OI/funding/taker/L-S data no longer discards all other usable auxiliary series. Primary candle history remains required for price/OI signals.
- Added regression assertions for missing data, explicit disabled state, partial coverage, and full coverage. Scanner ranking and consensus voting remain unchanged; no orders are executed.


## 0.5.2 — Preserve auxiliary time-series integrity
- Reject an auxiliary series as unavailable when it contains any non-finite sample, rather than filtering individual samples and compressing the time axis.
- Keep other independent microstructure signals usable when one source is malformed.
- Add a regression test for an interior NaN in funding data.
- No changes to consensus votes, scanner ranking, or order execution.


## 0.5.3 — Timestamp-aligned auxiliary signals
- Align open-interest with candle closes by shared hourly timestamp buckets rather than pairing equal-length tails.
- Align top-position and global long/short ratios by shared buckets before calculating their spread.
- Ignore invalid timestamps/non-finite values in alignment and use the last observation when an endpoint duplicates a bucket.
- Add regression tests for missing buckets, duplicate buckets, and invalid values.
- The microstructure overlay remains display-only; consensus, ranking, and order execution are unchanged.


## 0.5.4 — Confidence and timestamp regression coverage
- Add regression tests for timestamp-bucket matching, preserved gaps, duplicate buckets, invalid samples, and invalid bucket widths.
- Add regression tests that pin confidence discount behavior for incomplete timeframe coverage and opposing timeframe directions.
- These tests guard the existing data-quality behavior; no consensus-vote, ranking, or order-execution behavior is changed.


## 0.5.7 — Bounded fill-scan scheduling and accurate progress
- Group missing timeframe fill scans by symbol, avoiding one coroutine per missing symbol/timeframe cell.
- Add planned fill requests to the progress total before execution so progress and ETA do not undercount supplemental scans.
- Preserve stop checks between timeframes, shared request semaphore, scoring, and ranking behavior.

## v0.6.7 — OHLCV accumulation/distribution scan integration
- Wired the existing accumulation/distribution assessment into the live scanner using the actual candles fetched per symbol/timeframe (high, low, close, volume).
- Aggregated per-timeframe evidence into a conservative multi-timeframe consistency summary on cross-ranking rows.
- Added a scanner-card panel showing aligned accumulation signs, aligned distribution signs, conflicting evidence, or insufficient data; displays evidence score as a score, never as probability.
- This overlay is informational only and does not change consensus, ranking, elimination, or order execution.
- Validation limitation: Gradle compilation could not run in this environment because `services.gradle.org` could not resolve (UnknownHostException); ZIP integrity and source-level checks are run separately.

## v0.7.9 — Testable lifecycle baseline promotion
- Extracted the trusted completed-scan lifecycle baseline into a small domain component.
- Partial/interrupted scans cannot promote their provisional rows; completed scans can establish the next comparison baseline.
- Added focused tests for partial-scan retention and recovery after a direction reversal.
- Validation note: ZIP integrity is checked; Gradle tests/build still require downloading Gradle 8.10.2, unavailable in the current network environment.

## v0.8.0 — Structure-aware risk-plan core and scenario comparison

- Added a pure domain calculator that combines ATR distance with a confirmed support level for LONG plans or resistance level for SHORT plans, placing the stop beyond both the ATR distance and the structure level plus an ATR buffer. If no structure level is available, it explicitly falls back to ATR-only; invalid levels fail closed.
- Added comparable conservative / standard / aggressive scenario calculations with fee-and-slippage-adjusted net R:R.
- Wired the three ATR scenario comparisons into the risk-plan card, including ATR multiplier, target R, reference stop/target prices and estimated net R:R. The card explicitly labels these as ATR-only scenarios because the current scanner row does not carry a confirmed support/resistance level into this component yet.
- Added common tests for long/short structure-stop placement, ATR fallback, invalid structure levels, scenario profiles and invalid inputs.
- This remains informational analysis only; no order execution was added. Gradle tests and APK build still require a reachable Gradle 8.10.2 distribution and have not been verified in this environment.


## 0.8.2 — Position risk sizing and review warnings

- Added a pure position-risk calculator that derives a risk-budget-based notional ceiling from account equity, configured risk percentage, stop distance and estimated round-trip costs.
- Added configurable equity, risk-budget percentage and leverage assumptions to the risk-plan card, displaying estimated notional, initial margin, stop loss including estimated costs and exposure/equity multiple.
- Added conservative warnings when estimated margin consumes the full equity or the stop distance approaches a rough leverage-based margin buffer. The warning explicitly says actual liquidation depends on exchange maintenance margin, position tiers and margin mode.
- Added tests for risk-budget sizing, cost inclusion and invalid-input rejection. This remains reference-only and does not send orders.
- Validation note: ZIP integrity and standalone calculator checks can be run locally; full Gradle tests and Android APK build still require a reachable Gradle distribution.


## 0.8.3 — Historical risk-plan backtest core

- Added a deterministic OHLC backtest engine for pre-defined historical setups, with entry assumed at the signal candle close and evaluation beginning on the next candle to avoid look-ahead.
- Added conservative stop-first handling when both stop and target are touched within the same candle, time-limit exits, estimated round-trip fee/slippage deductions, and invalid setup rejection.
- Added summary metrics for win rate, average/total net return, profit factor and maximum drawdown.
- Added regression tests for no-lookahead behavior, ambiguous candles, costs, metrics and invalid inputs.
- Scope limitation: this is a reusable research core for supplied historical setups, not yet a live-data history screen or a full strategy backtest. It does not generate historical signals automatically and does not model funding, order-book impact, partial fills, liquidation or exchange margin tiers.
- Validation note: source-level Kotlin compilation and standalone smoke checks are separate from full Gradle tests; Android build remains unverified until Gradle can be resolved/downloaded.


## v0.8.7 — ATR 动态风险计划接入历史回测

- 历史回测新增 ATR 动态止损模式：使用信号 K 线收盘时已知的 ATR(周期可配) × 止损倍数确定风险距离，止盈按 R 倍数计算。
- 保留固定百分比止损/止盈模式，方便对照同一批历史行情。
- ATR 历史计算只使用当前及之前的 K 线，不读取后续行情；ATR 不足或风险价位无效的信号会被过滤。
- 回测页面显示当前风险计划参数，并明确提示该策略仍是均线交叉示例，尚未完整复现扫描器的支撑压力、指标共识和置信度逻辑。
- 本次没有接入交易执行接口，不会自动下单。完整 Gradle / Android 构建需在可下载 Gradle 发行版的环境中验证。


## 0.8.8 — 历史回测接入结构位 + ATR 风险计划

- 历史回测在 ATR 模式下新增可配置的结构止损开关、回看根数与 ATR 缓冲参数。
- 结构参考仅从信号 K 线之前的回看区间取低点（做多支撑参考）或高点（做空压力参考），不使用信号之后的价格；无效/不在正确方向的结构价位回退到 ATR-only。
- 风险价位复用现有 `StructureAwareRiskPlan` 计算器，止盈仍按实际止损距离 × 配置 R 倍数计算。
- 新增结构风险计划测试，检查 R 倍数、风险距离和未开启 ATR 时禁止结构止损。
- 范围说明：结构参考是固定窗口极值，不等于扫描器的确认支撑/压力检测；均线交叉仍是回测信号生成器，尚未复用完整指标共识/置信度。未新增交易执行。
- 验证说明：需要独立 Kotlin 测试和 ZIP 校验；完整 Gradle/Android 构建仍需可用的 Gradle 发行包环境。


## 0.8.9 — 回测收益统计口径明确

- 保留逐笔收益率简单相加指标，同时新增按顺序复利计算的模拟权益净收益，避免将两种不同口径混为“累计净收益”。
- 回测页面同时显示两项指标，并标注复利曲线以初始权益 100 为基准。
- 新增多笔 +10% / -10% 收益序列测试：算术和为 0%，复利结果为 -1%，确保统计口径可区分。
- 本轮不改变交易信号和风险计划；完整 Gradle / Android 构建仍需可用 Gradle 发行版验证。


## 0.8.10 — 方向一致的置信度基数

- 修复扫描结果卡片置信度基数可能取自反向周期的问题：例如当前排行方向为看涨，但最高单周期置信度来自看跌周期时，旧逻辑仍会拿看跌置信度作为看涨卡片的起点。
- 现在先选取支持主导方向的周期置信度最大值，再应用已有的周期覆盖率与方向冲突折扣；中性主导方向不再借用任一方向的高置信度。
- 增加纯逻辑测试覆盖反向高置信度、无主导方向和异常置信度边界。排行分数、指标投票和剔除规则未更改。
- 本轮不添加交易执行接口。完整 Gradle 测试和 APK 构建仍需在可获取 Gradle 发行版的环境中验证。


## 0.8.11 — 风险方案对比统一失效门控

- 修复风险计划卡片中主计划因行情过期、方向反转、价格偏移或多周期冲突而隐藏时，保守/标准/激进方案仍可能单独显示止损止盈价的问题。
- 主计划与所有方案对比现在共用同一 `planAllowed` 审核结果；审核未通过时，不展示任何方案价位，避免卡片内部出现相互矛盾的参考信息。
- 保留现有结构位、ATR、目标 R、成本估算和手动参数设置；不添加自动下单接口。
- ZIP 完整性与源码静态检查可验证；完整 Gradle 测试及 APK 构建仍未验证。


## 0.8.12 — 风险计划生命周期状态失败关闭

- 修复风险计划审核门控对未知生命周期状态默认放行的问题。现在只有 `NEW` 和 `ACTIVE` 可继续进入后续方向/多周期审核；空值或未来新增、未识别的状态一律暂停显示方向性止损/止盈价，并要求重新扫描审核。
- 已知的 `DATA_INVALID`、`DIRECTION_REVERSED`、`PRICE_MOVED` 状态继续使用各自的失效提示。
- 新增未知状态和空状态回归测试；不改变扫描排行、不增加自动下单接口。完整 Gradle 测试与 APK 构建仍需在可用 Gradle 发行包的环境验证。


## 0.8.13 — 风险审核与净盈亏比联动

- 修复风险计划被行情新鲜度、生命周期或方向审核拦截时，仍可能用回退参数计算净 R:R 并显示“成本后收益不足”等误导性结论的问题。
- 手续费、滑点和净 R:R 现在只基于当前已通过审核的主计划计算；计划不可用时明确显示“暂不可评估”，不再使用隐藏计划的估算值。
- 新增回归测试验证被拦截的计划不会继续接受净盈亏比评价；不改变行情扫描排名、不添加自动下单接口。
- 源码 ZIP 完整性与相关 Kotlin 单元逻辑可单独验证；完整 Gradle 测试和 APK 构建仍需可用的 Gradle 发行包环境验证。


## v0.8.14
- 风险审核对未知生命周期状态和未知方向资格状态统一 fail-closed，避免在绕过恢复门控的调用路径中误显示正常评估结论。
- 新增未知状态回归测试，覆盖即使输入较高净盈亏比也必须暂停评估的情况。


## v0.8.15 — 结构位异常时回退 ATR 风险计划

- 修复结构止损参考值为 NaN/非正数，或位于入场价错误一侧时，可能导致整个风险计划不可用的问题。
- 现在仅在结构价位有效且缓冲后的止损位于正确方向时使用结构位；否则明确回退到 ATR-only，并将来源标记为 `ATR_ONLY`。
- 新增异常结构位及多空方向错误结构位的回归测试；不改变扫描排序、不增加交易执行接口。
- 相关纯 Kotlin 源码将进行独立编译与烟雾验证；完整 Gradle/Android 构建仍需可用的 Gradle 发行包环境验证。


## v0.8.18 — 历史回测 OHLC 数据质量校验

- 修复回测引擎只检查最高价/最低价基本范围、却可能接受开盘价落在最高/最低价区间之外的损坏 K 线的问题。
- 入场 K 线现在也必须通过 OHLC 合理性校验；损坏的后续 K 线会被跳过，不会作为止损、止盈或时间退出成交价。
- 若回测窗口内没有任何有效后续 K 线，返回“无后续 K 线”，不再制造虚假的退出成交。
- 新增异常 OHLC、损坏入场 K 线和无有效退出 K 线回归测试。该回测仍是研究用途，不等同于交易所真实成交模拟；完整 Gradle 测试与 APK 构建仍需联网可用的 Gradle 环境验证。


## v0.8.19 — 回测入场价格避免使用已收盘信号价

- 修复 SMA 回测在观察到信号 K 线收盘后，仍假定能以该根 K 线收盘价成交的偏乐观假设。
- 现在信号在当前 K 线收盘确认，模拟入场使用下一根 K 线开盘价；止损与止盈均围绕该入场价重新计算。
- 下一根入场 K 线的高低价仍纳入止损/止盈触发检查；若同根 K 线同时触及止损和止盈，仍按保守规则优先判定止损。
- 新增回归测试，确认成交价使用下一根开盘价，且固定百分比风险价位基于实际模拟入场价计算。此回测仍不等同于真实交易所成交；完整 Gradle 测试与 APK 构建仍待验证。


## v0.8.38
- Fix analysis screen retaining stale symbol when entered from scanner or another route; synchronize to shared active symbol and rerun analysis.

## v0.8.43
- Add collapsible scan result card details.
- Add saveable AI-plan priority toggle and clarify manual AI invocation.

## v0.8.44 — AI 结果与分析页面联动
- 将“AI 计划优先”开关持久化到 SettingsStore，页面切换/重建后读取保存值，用户切换开关时同步保存。
- 明确说明 AI 结果的作用范围：AI 报告更新分析文案；解析成功的 AI 计划可在 AI 计划优先开启时驱动图表入场/止损/止盈线、计划卡与盯盘价位；本地 RSI/MACD/均线等仍由本地行情计算。
- 在图表附近增加 AI 计划应用状态说明，明确 AI 尚未返回有效计划时会继续使用本地计划，避免误认为 AI 已经影响图表。
- AI 不会动态改写导航/按钮控件，不提供自动下单能力。
- Gradle/Android 编译与实机联动仍需环境验证。
