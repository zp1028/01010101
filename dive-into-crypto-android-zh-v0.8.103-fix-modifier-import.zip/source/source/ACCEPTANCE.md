# Dive Into Crypto Android — 验收报告（v0.8.38）

**范围：** 除真机验证外的全部四阶段任务  
**versionName:** 0.8.38 · **versionCode:** 74  
**日期说明：** 以源码与 `commonTest` 逻辑验收为准；真机与 APK 明确排除。

图例：✅ 通过（有实现 + 可测依据） · ⚠️ 有条件通过 · ❌ 未通过 · ⛔ 阻塞（缺存档/缺设备）

---

## 阶段一：行情生命周期与断线恢复

| 验收项 | 结果 | 依据 |
|--------|------|------|
| WebSocket 指数退避重连 | ✅ | `WsReconnect.kt` + `WsReconnectTest`（1s→30s cap、jitter、成功帧重置 attempt） |
| 断线后自动重订阅 | ✅ | `reconnectingFlow` 将失败/完成视为断开并重连；取消立即停止 |
| 行情新鲜度门禁 | ✅ | `MarketDataFreshness` + Test（FRESH/STALE/MISSING/INVALID） |
| 过期行情不展示参考计划 | ✅ | `RiskPlanRecoveryPolicy`：STALE → WAIT_FOR_FRESH_DATA |
| 机会生命周期（新/活跃/反转/价格移动） | ✅ | `OpportunityLifecycle` + Test / Baseline |
| 页面切换与长时间运行 | ⛔ | **真机排除**；逻辑上 generation token 防陈旧结果写入（ScannerViewModel） |

**阶段一结论（除真机）：通过。**

---

## 阶段二：指标、结构位与交易计划一致性

| 验收项 | 结果 | 依据 |
|--------|------|------|
| ATR 动态止损 / R 倍止盈 | ✅ | `RiskPlanCalculator` + Test / Pipeline |
| 结构止损（先验 K 线极值） | ✅ | `StructureAwareRiskPlan` + Test；回测路径可用 |
| 高周期确认（无未来 K 线） | ✅ | `HistoricalCandleAlignment.closedBefore`；共识回测 HTF 前缀 |
| 防未来数据泄漏 | ✅ | 因果前缀、gap 检测、`rankAtCut` 拒绝未来 cell |
| 方向资格 / MTF 冲突 | ✅ | `RiskPlanEligibility` + Recovery 联动 |
| 计划卡片与计算一致 | ✅ | `StageAcceptanceIntegrationTest` / `RiskPlanPipelineTest` 同一计算器链 |
| 指标共识与实盘引擎同路径 | ✅ | 回测 `signalProvider` 调用 `container.consensus.evaluate` |

**阶段二结论（除真机）：通过。**

---

## 阶段三：风险计划与仓位管理

| 验收项 | 结果 | 依据 |
|--------|------|------|
| 入场/止损/止盈计算 | ✅ | `RiskPlanCalculator` |
| 路径敏感手续费+滑点 | ✅ | `RiskCostCalculator` 与 `RiskPlanBacktester` 对齐 |
| 仓位规模与风险预算 | ✅ | `PositionRiskCalculator`（止损路径成本） |
| 回测统计口径统一 | ✅ | `summarize`：胜率、算术/复利净收益、回撤、盈利因子 |
| 持仓状态持续监控 UI | ⛔ | **真机排除**；生命周期/恢复策略逻辑已测 |
| 资金费率 / 维持保证金 / 强平 | ⚠️ | **明确不模拟**（`BacktestAssumptions.notModeled`），非缺陷隐瞒 |

**阶段三结论（除真机）：通过（模拟边界已文档化）。**

---

## 阶段四：历史回测与实时扫描器一致性

| 验收项 | 结果 | 依据 |
|--------|------|------|
| finalScore / Phase2 幸存者 / Top-N / cross-rank 公式 | ✅ | `ScannerRanking`；ViewModel 共用 |
| 多标的历史排名回放 Phase1+Phase2 | ✅ | 回测页「扫描器排名回放」+ `HistoricalScannerReplay` |
| 因果 cell / 无未来数据 | ✅ | `rankAtCut` + Tests |
| 单标的指标共识回放 | ✅ | `SmaCrossoverBacktest` + signalProvider |
| 全市场历史 24h 成交额宇宙 | ⛔ | **需历史存档**；报告中 `missingUniverseRanking` |
| Whale/OI/taker/funding 历史过滤 | ⛔ | **需历史存档**；`missingAuxiliaryData` + limitations |
| 真实盘口成交效果 | ⚠️ | 不模拟；OHLC 保守假设已测 |

**阶段四结论：**  
可实现部分 **通过**；依赖历史存档的全市场/资金流回放为 **阻塞项**（不可伪造），已在 API 与 UI 中标记，不算“假装完成”。

---

## 构建 / 真机（本报告排除）

| 项 | 结果 |
|----|------|
| Gradle 发行包镜像 | ✅ 腾讯云镜像已配置（可选本地构建） |
| 完整 APK / 真机安装运行 | ⛔ **按需求排除** |

---

## 总评

| 阶段 | 除真机外 |
|------|----------|
| 一 | ✅ |
| 二 | ✅ |
| 三 | ✅（强平/资金费率声明不模拟） |
| 四 | ✅ 可代码完成部分；⛔ 存档依赖项 |

**不会把「缺存档无法复现」写成「已验收通过」。**  
真机相关项保持未验证，直至在设备上执行。
