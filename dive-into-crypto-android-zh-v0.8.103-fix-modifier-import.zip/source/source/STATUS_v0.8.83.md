# v0.8.83 — Forward-entry plan first pass

## Scope implemented in this pass
- Added a pure local `ForwardEntryPlanEngine` for preparatory (not yet triggered) plans.
- Added input validation for price, ATR, direction conflicts, market-data freshness, expiry, and parameter validity.
- Added bounded primary-timeframe selection based on supporting timeframe evidence.
- Added candidate scenarios for breakout preparation, retest preparation, reversal preparation when divergence evidence exists, and trend continuation near structure.
- Added structure/ATR-based reference stop and R-multiple target calculation, quality threshold, price-drift revalidation metadata, and duplicate-plan suppression.
- Added a third scanner board `前瞻计划` while retaining `共识排行` and `启动排行`.
- Added plan cards with entry zone, trigger reference, stop/target reference, R:R, trigger/invalidation rules, expiry and current-price drift warning.
- Added pure-domain regression tests for preparatory state, stale data rejection, timeframe conflict rejection, missing ATR, primary-timeframe selection, and long/short stop-target direction.

## Important limits / not yet complete
- This is the first implementation tranche, not completion of the full AI-fusion project.
- The new plan board currently uses existing local scanner row data; it does not yet call AI as part of scan ranking.
- Plan history/snapshot persistence across process restarts is not yet implemented.
- Trigger confirmation still requires a later real-time closed-candle validation step; the board deliberately labels these plans as waiting, not triggered.
- Historical no-lookahead and cost-aware forward evaluation are not yet wired to the new plan records.
- AI regime advice, constrained AI weight adjustments, adaptive-learning approval gates, and dedicated false-breakout confirmation are still pending.

## Validation
- Compiled `ForwardEntryPlanEngine.kt` with its pure dependencies using local `kotlinc` successfully.
- Manually exercised the engine with a sample snapshot; it emitted a valid preparatory breakout plan and rejected invalid/stale inputs in additional checks.
- `./gradlew :app:allTests --no-daemon` could not start because the wrapper attempted to download Gradle 8.10.2 from `mirrors.cloud.tencent.com`, and DNS/network access was unavailable (`UnknownHostException`).
- No APK was built.
