# v0.8.84 — Scanner AI fusion integration pass

## Implemented in source
- Added persisted opt-in `aiFusionEnabled` setting (default OFF), independent from the existing analysis-page AI switch.
- Added a scanner-settings toggle explaining that only four locally top-ranked directional candidates are sent to AI and that this is advisory only.
- Added a dedicated AI-fusion system prompt and structured parser; existing full analysis prompt and user-facing AI plan parsing remain on their original default path.
- Integrated the fusion stage into the actual scanner rank chain after local ranking and before the existing adverse-divergence elimination/backfill stage.
- The AI stage requests only the top four local candidates, uses closed 15m/1h/4h candles, has a short request budget, bounded concurrency and a 60-second per-symbol advice cache.
- AI rank delta is bounded; direction conflicts penalize ranking; low AI confidence has no effect; high fake-breakout risk adds a penalty; malformed/failed/timed-out AI falls back to the local score.
- Added local baseline score and AI audit fields to scanner rows. The scanner card and CSV expose fusion status, delta, rationale and any AI reference plan that passes local price/direction/RR checks.
- Local direction, adverse-divergence elimination and existing risk rules remain authoritative. No order-execution path was added.
- AI cancellation is rethrown rather than being swallowed by the analysis client fallback path.
- Added deterministic unit-test cases for alignment nudge, direction conflict penalty, low-confidence no-op, and invalid/distant plan rejection.

## Validation performed
- `AiFusionPolicy.kt` compiles with local `kotlinc`.
- `ForwardEntryPlanEngine.kt` and its pure dependencies compile with local `kotlinc`.
- Full `./gradlew :app:allTests --no-daemon` remains blocked before project configuration because Gradle 8.10.2 cannot be downloaded from `mirrors.cloud.tencent.com` (`UnknownHostException`).
- No APK was built, per user instruction.

## Still incomplete
- Full commonMain/Compose compilation and test execution, including the new `AiFusionPolicyTest`, need a working Gradle distribution/dependency cache.
- Durable forward-plan snapshots and append-only status history are not yet implemented.
- Closed-candle trigger/false-breakout lifecycle and cost-aware trigger-time revalidation are not yet connected to plan records.
- AI plan values are displayed as reference only after guardrail validation; they do not yet update the forward-plan engine's immutable plan version or chart overlays.
- Constrained AI regime/weight advice and sample-out-of-time approval for adaptive weights are not yet implemented.
- Historical replay evaluation and chart overlay coordinate/zoom regression remain outstanding.
