# v0.8.45 — AI target consistency and stale-plan protection

## Changes
- Scope the AI plan used by the analysis screen to the currently selected symbol and timeframe.
- Prevent an old AI session from changing the analysis screen's selected symbol.
- Clear screen-local AI plan/report/history when the requested symbol or timeframe changes.
- Make `AiSessionHub.bindSymbol` reset old AI output when either symbol or timeframe changes, rather than relabeling a stale plan with a new timeframe.
- Clarify that AI can update report text and structured trade-plan presentation, while RSI/MACD/moving averages remain computed from market data locally.

## Validation
- Source inspection completed.
- Gradle compile attempted (`:app:compileKotlinMetadata --offline`) but the wrapper attempted to download Gradle 8.10.2 from `mirrors.cloud.tencent.com`; DNS/network access failed (`UnknownHostException`). Compilation and device behavior remain unverified.
