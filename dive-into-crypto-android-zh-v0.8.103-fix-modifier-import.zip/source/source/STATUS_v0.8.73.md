# v0.8.73 — AI request preparation guard

## Changes
- Added an `aiPreparing` state for the multi-timeframe data-fetch phase before the shared AI session reports `running`.
- Disabled repeated AI button taps during that phase to reduce duplicate preparation and requests.
- Captured the current analysis request token and target, then aborts stale multi-timeframe preparation if symbol/timeframe changes while data is loading.
- Uses `try/finally` so the preparation state is cleared even when a fetch or launch path exits early.

## Preserved
- Existing AI session generation checks, report/plan target isolation, chart overlays, EMA20/EMA50, trendline logic, scanner card collapse, and local plan fallback remain in place.
- Source-only change; no APK built.

## Validation
- ZIP integrity checked after packaging.
- Gradle compile/unit tests and device tests were not run in this update.
