# v0.8.38 — Analysis routing fix

## Changes
- AnalysisScreen now observes the app-wide active symbol instead of only reading it once at composition.
- When scanner/navigation changes the selected symbol, the analysis input and active target synchronize and analysis is triggered for that symbol.
- Existing indicators, chart overlays, scan logic, and features are preserved.

## Verification
- Source-level patch applied to the uploaded v0.8.37 tree.
- Android Gradle build/tests have not yet been run in this environment; treat this as a source fix pending CI/device verification.
