# v0.8.82 — AI model-list candidate selection

## Changes
- Fixed model-list parsing when a gateway returns an empty earlier alias (for example `data: []`) alongside a populated later alias (`models: [...]`). The parser now prefers a populated array and uses an empty array only if no populated candidate exists.
- Added a regression test for this response shape.
- Preserves prior source changes from v0.8.81.

## Validation
- Reviewed the changed parser and regression test source.
- Full Gradle tests/build not run because the configured Gradle distribution is not available locally and prior attempts failed resolving `mirrors.cloud.tencent.com`.
- No APK built, per request.
