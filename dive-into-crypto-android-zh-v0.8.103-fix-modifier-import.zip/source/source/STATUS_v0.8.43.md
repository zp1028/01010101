# v0.8.43 — Scan card collapse and AI mode toggle

- Scan result cards keep the symbol/header visible and fold detailed evidence, timeframe grid, and action row behind an expand/collapse control.
- Expanded state is remembered per symbol while the card remains in the saveable state scope.
- Analysis AI-plan preference now uses rememberSaveable; the control label identifies AI-plan priority mode.
- Added explanatory copy distinguishing AI-plan preference from manually starting an AI analysis request.
- Build and device-level navigation persistence remain unverified in this environment.
