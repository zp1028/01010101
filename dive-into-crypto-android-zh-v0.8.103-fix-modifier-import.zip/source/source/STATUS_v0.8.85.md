# v0.8.85 — Forward-plan lifecycle and cost-aware revalidation

## Implemented in this pass
- Added `ForwardPlanJournal`, persisted as a versioned JSON blob through the existing `SettingsStore`; no new database or permissions required.
- Stores immutable plan snapshots, bounded plan history (160) and append-only lifecycle events (500), with malformed/old persisted data falling back safely to an empty journal.
- Deduplicates near-identical active plans by symbol/direction/type/timeframe/trigger so continuous scans do not flood the plan board with near-duplicates.
- Adds lifecycle transitions for expiry and excessive reference-price drift. A live ticker alone cannot confirm a trigger.
- Connects the scanner ticker stream to bounded, throttled closed-candle checks after price crosses a trigger reference. Only a later, actually closed candle can transition a plan to `CONDITION_MET`; a failed candle fetch keeps the plan waiting.
- Displays tracked plan status and the latest status-history events in the forward-plan board; the board remains informational and never places orders.
- Forward-plan risk/reward now deducts configured estimated round-trip fees and slippage. Target R and cost inputs use the existing risk settings instead of hard-coded defaults.
- Fixed AI-fusion timeout handling so per-candidate AI/K-line deadlines and the overall AI deadline fall back to the local ranking rather than treating an optional AI timeout as a user-requested scan cancellation.
- Added regression tests for journal persistence, closed-candle-only trigger confirmation, expiry, and fee/slippage impact on net R:R.

## Validation performed
- `ForwardEntryPlanEngine.kt` plus its pure dependencies compiled with local `kotlinc` (using a temporary annotation stub because Gradle/serialization artifacts are not locally available).
- Manual smoke test passed for long and short candidate generation and positive cost-adjusted R:R; observed example net R:R was approximately 1.35 after the configured 0.05% fee and 0.02% slippage per side.
- Full `./gradlew :app:allTests --offline --no-daemon` still cannot start: Gradle wrapper attempts to download Gradle 8.10.2 and fails with `UnknownHostException` for `mirrors.cloud.tencent.com`.
- No APK was built, per user instruction. Compose compilation and Gradle test execution are therefore **not verified**.

## Still incomplete
- Full project compilation and execution of common tests require a working Gradle distribution/dependency cache.
- Plan journal status history is visible in the scanner board, but there is not yet a dedicated full history/detail screen or manual archive/delete controls.
- AI advice that passes the fusion guardrail is displayed as a separate reference suggestion; it does not yet create a versioned AI-adjusted plan snapshot or update chart overlays.
- Historical replay/no-lookahead evaluation of these forward-plan records is not yet connected.
- AI regime/weight advice with out-of-sample approval gates, chart overlay coordinate/zoom regression, and final end-to-end verification remain outstanding.
