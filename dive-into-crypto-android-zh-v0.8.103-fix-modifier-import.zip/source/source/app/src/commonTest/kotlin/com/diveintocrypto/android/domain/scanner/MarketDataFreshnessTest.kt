package com.diveintocrypto.android.domain.scanner

import kotlin.test.Test
import kotlin.test.assertEquals

class MarketDataFreshnessTest {
    @Test fun freshCandleWithinTwoIntervalsIsFresh() {
        val result = MarketDataFreshness.assess(1_000_000L, 60_000L, 1_100_000L)
        assertEquals(MarketDataFreshness.Status.FRESH, result.status)
    }

    @Test fun staleCandleIsRejected() {
        val result = MarketDataFreshness.assess(1_000_000L, 60_000L, 1_200_001L)
        assertEquals(MarketDataFreshness.Status.STALE, result.status)
    }

    @Test fun missingTimestampDoesNotPass() {
        val result = MarketDataFreshness.assess(null, 60_000L, 1_100_000L)
        assertEquals(MarketDataFreshness.Status.MISSING, result.status)
    }

    @Test fun timestampFarInFutureIsRejected() {
        val result = MarketDataFreshness.assess(1_200_001L, 60_000L, 1_000_000L)
        assertEquals(MarketDataFreshness.Status.STALE, result.status)
    }
}
