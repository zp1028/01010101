package com.diveintocrypto.android.domain.scanner

import kotlin.test.Test
import kotlin.test.assertEquals

class RiskPlanAssessmentTest {
    @Test fun invalidDataBlocksPlan() {
        assertEquals(RiskPlanAssessment.Level.INVALID,
            RiskPlanAssessment.assess("DATA_INVALID", "ELIGIBLE", 1.5).level)
    }
    @Test fun directionReversalInvalidatesPlan() {
        assertEquals(RiskPlanAssessment.Level.INVALID,
            RiskPlanAssessment.assess("DIRECTION_REVERSED", "ELIGIBLE", 1.5).level)
    }
    @Test fun multiTimeframeConflictHoldsPlan() {
        assertEquals(RiskPlanAssessment.Level.HOLD,
            RiskPlanAssessment.assess("ACTIVE", "MTF_CONFLICT", 1.5).level)
    }
    @Test fun netRewardBelowOneToOneRaisesCaution() {
        assertEquals(RiskPlanAssessment.Level.CAUTION,
            RiskPlanAssessment.assess("ACTIVE", "ELIGIBLE", 0.8).level)
    }
    @Test fun largePriceMoveRequiresRecalculationReview() {
        assertEquals(RiskPlanAssessment.Level.HOLD,
            RiskPlanAssessment.assess("PRICE_MOVED", "ELIGIBLE", 1.5).level)
    }
    @Test fun reversedDirectionInvalidatesEvenWithGoodNetRatio() {
        assertEquals(RiskPlanAssessment.Level.INVALID,
            RiskPlanAssessment.assess("DIRECTION_REVERSED", "ELIGIBLE", 3.0).level)
    }

    @Test fun newOpportunityNeedsConfirmation() {
        assertEquals(RiskPlanAssessment.Level.REVIEW,
            RiskPlanAssessment.assess("NEW", "ELIGIBLE", 1.5).level)
    }
    @Test fun unknownLifecycleStatusFailsClosedEvenIfCallerProvidesGoodRatio() {
        val result = RiskPlanAssessment.assess("FUTURE_STATUS", "ELIGIBLE", 3.0)
        assertEquals(RiskPlanAssessment.Level.HOLD, result.level)
        assertEquals("状态未知，暂停评估", result.label)
    }

    @Test fun unknownEligibilityStatusFailsClosedEvenIfCallerProvidesGoodRatio() {
        val result = RiskPlanAssessment.assess("ACTIVE", "FUTURE_ELIGIBILITY", 3.0)
        assertEquals(RiskPlanAssessment.Level.HOLD, result.level)
        assertEquals("资格状态未知，暂停评估", result.label)
    }

    @Test fun blockedPlanIsNotJudgedFromFallbackRiskRewardEstimate() {
        val result = RiskPlanAssessment.assess("ACTIVE", "ELIGIBLE", 2.5, planAvailable = false)
        assertEquals(RiskPlanAssessment.Level.HOLD, result.level)
        assertEquals("暂不可评估", result.label)
    }

}
