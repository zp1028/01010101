package com.diveintocrypto.android.domain.scanner

import com.diveintocrypto.android.domain.model.Signal
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

class RiskPlanEligibilityTest {
    @Test fun neutralSignalDoesNotCreateDirectionalPlan() {
        val result = RiskPlanEligibility.evaluate(Signal.NEUTRAL, 0)
        assertNull(result.direction)
        assertEquals(RiskPlanEligibility.Status.NO_DIRECTION, result.status)
    }

    @Test fun conflictingHigherTimeframeSuppressesDirectionalPlan() {
        val result = RiskPlanEligibility.evaluate(Signal.STRONG_BUY, -1)
        assertNull(result.direction)
        assertEquals(RiskPlanEligibility.Status.MTF_CONFLICT, result.status)
    }

    @Test fun alignedOrUnavailableMtfKeepsSignalDirection() {
        assertEquals(RiskPlanEligibility.Direction.LONG, RiskPlanEligibility.evaluate(Signal.BUY, 1).direction)
        assertEquals(RiskPlanEligibility.Direction.SHORT, RiskPlanEligibility.evaluate(Signal.SELL, 0).direction)
    }
}
