package com.diveintocrypto.android.domain.scanner

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

class PositionRiskCalculatorTest {
    @Test fun sizesNotionalFromRiskBudgetAndIncludesRoundTripCost() {
        val result = PositionRiskCalculator.calculate(
            equity = 100.0, riskPct = 1.0, entryPrice = 100.0, stopPrice = 98.0,
            leverage = 10.0, stopPathCostPct = 0.2,
        )
        assertNotNull(result)
        assertEquals(1.0, result.riskBudget, 1e-9)
        assertEquals(2.0, result.stopDistancePct, 1e-9)
        assertEquals(45.454545, result.maxNotional, 1e-5)
        assertEquals(4.5454545, result.requiredInitialMargin, 1e-5)
        assertEquals(1.0, result.estimatedStopLoss, 1e-8)
    }

    @Test fun sizingUsesProvidedStopPathCostRatherThanConservativeTargetPathMaximum() {
        val stopPathCostPct = 0.1386
        val conservativeMaxRoundTripCostPct = 0.1421
        val stopPath = assertNotNull(PositionRiskCalculator.calculate(
            equity = 100.0, riskPct = 1.0, entryPrice = 100.0, stopPrice = 98.0,
            leverage = 10.0, stopPathCostPct = stopPathCostPct,
        ))
        val maxPath = assertNotNull(PositionRiskCalculator.calculate(
            equity = 100.0, riskPct = 1.0, entryPrice = 100.0, stopPrice = 98.0,
            leverage = 10.0, stopPathCostPct = conservativeMaxRoundTripCostPct,
        ))
        assertTrue(stopPath.maxNotional > maxPath.maxNotional)
        assertEquals(stopPathCostPct, stopPath.estimatedCostPct, 1e-9)
        assertEquals(conservativeMaxRoundTripCostPct, maxPath.estimatedCostPct, 1e-9)
    }

    @Test fun rejectsInvalidOrDangerousInputs() {
        assertNull(PositionRiskCalculator.calculate(0.0, 1.0, 100.0, 98.0, 10.0))
        assertNull(PositionRiskCalculator.calculate(100.0, 11.0, 100.0, 98.0, 10.0))
        assertNull(PositionRiskCalculator.calculate(100.0, 1.0, 100.0, 100.0, 10.0))
        assertNull(PositionRiskCalculator.calculate(100.0, 1.0, 100.0, 98.0, 0.5))
    }

    @Test fun flagsTightStopAndHighLeverageAsExchangeCheckRequired() {
        val result = PositionRiskCalculator.calculate(100.0, 1.0, 100.0, 99.5, 50.0)
        assertNotNull(result)
        assertTrue(result.warning.orEmpty().contains("强平价"))
    }
}
