package com.diveintocrypto.android.domain.scanner

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull

class RiskPlanBacktesterTest {
    private fun candle(i: Int, high: Double, low: Double, close: Double) =
        RiskPlanBacktester.Candle(i.toLong(), high, low, close)

    @Test fun startsOnNextCandleAndDoesNotLookAheadIntoEntryBar() {
        val candles = listOf(candle(0, 120.0, 80.0, 100.0), candle(1, 104.0, 99.0, 103.0))
        val setup = RiskPlanBacktester.Setup(0, RiskPlanCalculator.Direction.LONG, 100.0, 95.0, 105.0)
        val result = RiskPlanBacktester.simulate(candles, setup, 0.05, 0.02)
        assertEquals(RiskPlanBacktester.ExitReason.TIME_LIMIT, result.reason)
        assertEquals(1, result.exitIndex)
    }

    @Test fun ifStopAndTargetBothTouchSameCandleStopWinsConservatively() {
        val candles = listOf(candle(0, 101.0, 99.0, 100.0), candle(1, 106.0, 94.0, 100.0))
        val setup = RiskPlanBacktester.Setup(0, RiskPlanCalculator.Direction.LONG, 100.0, 95.0, 105.0)
        val result = RiskPlanBacktester.simulate(candles, setup, 0.0, 0.0)
        assertEquals(RiskPlanBacktester.ExitReason.STOP_LOSS, result.reason)
        assertEquals(-5.0, result.netReturnPct!!, 1e-9)
    }

    @Test fun feesAndSlippageReduceNetReturnAndSummaryComputesMetrics() {
        val candles = listOf(candle(0, 101.0, 99.0, 100.0), candle(1, 106.0, 99.0, 105.0))
        val setup = RiskPlanBacktester.Setup(0, RiskPlanCalculator.Direction.LONG, 100.0, 95.0, 105.0)
        val trade = RiskPlanBacktester.simulate(candles, setup, 0.05, 0.02)
        assertEquals(5.0, trade.grossReturnPct!!, 1e-9)
        // Path-aware cost: (fee+slip) * (1 + exit/entry) = 0.07 * (1 + 1.05) = 0.1435
        assertEquals(0.1435, trade.estimatedCostPct, 1e-9)
        assertEquals(4.8565, trade.netReturnPct!!, 1e-9)
        val summary = RiskPlanBacktester.summarize(listOf(trade))
        assertEquals(1, summary.closedTradeCount)
        assertEquals(100.0, summary.winRatePct!!, 1e-9)
        assertNotNull(summary.averageNetReturnPct)
        assertEquals(4.8565, summary.compoundedNetReturnPct, 1e-9)
    }

    @Test fun compoundedReturnDiffersFromArithmeticSumForMultipleTrades() {
        val first = RiskPlanBacktester.TradeResult(
            RiskPlanBacktester.Setup(0, RiskPlanCalculator.Direction.LONG, 100.0, 90.0, 110.0),
            1, 105.0, RiskPlanBacktester.ExitReason.TAKE_PROFIT, 5.0, 0.0, 10.0,
        )
        val second = first.copy(setup = first.setup.copy(entryIndex = 2), netReturnPct = -10.0)
        val summary = RiskPlanBacktester.summarize(listOf(first, second))
        assertEquals(0.0, summary.totalNetReturnPct, 1e-9)
        assertEquals(-1.0, summary.compoundedNetReturnPct, 1e-9)
    }

    @Test fun longStopGapUsesWorseCandleOpenInsteadOfIdealStopFill() {
        val candles = listOf(
            RiskPlanBacktester.Candle(0L, 101.0, 99.0, 100.0, 100.0),
            RiskPlanBacktester.Candle(1L, 97.0, 90.0, 92.0, 91.0),
        )
        val setup = RiskPlanBacktester.Setup(0, RiskPlanCalculator.Direction.LONG, 100.0, 95.0, 105.0)
        val result = RiskPlanBacktester.simulate(candles, setup, 0.0, 0.0)
        assertEquals(RiskPlanBacktester.ExitReason.STOP_LOSS, result.reason)
        assertEquals(91.0, result.exitPrice!!, 1e-9)
        assertEquals(-9.0, result.netReturnPct!!, 1e-9)
    }

    @Test fun shortStopGapUsesWorseCandleOpenInsteadOfIdealStopFill() {
        val candles = listOf(
            RiskPlanBacktester.Candle(0L, 101.0, 99.0, 100.0, 100.0),
            RiskPlanBacktester.Candle(1L, 111.0, 106.0, 109.0, 110.0),
        )
        val setup = RiskPlanBacktester.Setup(0, RiskPlanCalculator.Direction.SHORT, 100.0, 105.0, 95.0)
        val result = RiskPlanBacktester.simulate(candles, setup, 0.0, 0.0)
        assertEquals(RiskPlanBacktester.ExitReason.STOP_LOSS, result.reason)
        assertEquals(110.0, result.exitPrice!!, 1e-9)
        assertEquals(-10.0, result.netReturnPct!!, 1e-9)
    }


    @Test fun longTargetGapIsResolvedAtOpenBeforeAmbiguousIntrabarStopTouch() {
        val candles = listOf(
            RiskPlanBacktester.Candle(0L, 101.0, 99.0, 100.0, 100.0),
            // Opens beyond target, then trades down through the stop. The open happened first.
            RiskPlanBacktester.Candle(1L, 108.0, 94.0, 96.0, 107.0),
        )
        val setup = RiskPlanBacktester.Setup(0, RiskPlanCalculator.Direction.LONG, 100.0, 95.0, 105.0)
        val result = RiskPlanBacktester.simulate(candles, setup, 0.0, 0.0)
        assertEquals(RiskPlanBacktester.ExitReason.TAKE_PROFIT, result.reason)
        assertEquals(105.0, result.exitPrice!!, 1e-9)
        assertEquals(5.0, result.netReturnPct!!, 1e-9)
    }

    @Test fun shortTargetGapIsResolvedAtOpenBeforeAmbiguousIntrabarStopTouch() {
        val candles = listOf(
            RiskPlanBacktester.Candle(0L, 101.0, 99.0, 100.0, 100.0),
            // Opens below target, then trades up through the stop. The open happened first.
            RiskPlanBacktester.Candle(1L, 106.0, 92.0, 104.0, 93.0),
        )
        val setup = RiskPlanBacktester.Setup(0, RiskPlanCalculator.Direction.SHORT, 100.0, 105.0, 95.0)
        val result = RiskPlanBacktester.simulate(candles, setup, 0.0, 0.0)
        assertEquals(RiskPlanBacktester.ExitReason.TAKE_PROFIT, result.reason)
        assertEquals(95.0, result.exitPrice!!, 1e-9)
        assertEquals(5.0, result.netReturnPct!!, 1e-9)
    }

    @Test fun malformedOhlcIsSkippedAndNeverUsedAsExitFill() {
        val candles = listOf(
            RiskPlanBacktester.Candle(0L, 101.0, 99.0, 100.0, 100.0),
            // Impossible OHLC: open is above the reported high.
            RiskPlanBacktester.Candle(1L, 104.0, 99.0, 103.0, 110.0),
            RiskPlanBacktester.Candle(2L, 104.0, 99.0, 102.0, 101.0),
            // Another impossible OHLC at the end must not be used as a fill.
            RiskPlanBacktester.Candle(3L, 104.0, 99.0, 103.0, 110.0),
        )
        val setup = RiskPlanBacktester.Setup(0, RiskPlanCalculator.Direction.LONG, 100.0, 95.0, 105.0)
        val result = RiskPlanBacktester.simulate(candles, setup, 0.0, 0.0, maxHoldingBars = 3)
        assertEquals(RiskPlanBacktester.ExitReason.TIME_LIMIT, result.reason)
        assertEquals(2, result.exitIndex)
        assertEquals(102.0, result.exitPrice!!, 1e-9)
    }

    @Test fun malformedEntryCandleInvalidatesSetupAndAllInvalidFutureCandlesDoNotCreateExit() {
        val malformedEntry = listOf(
            RiskPlanBacktester.Candle(0L, 99.0, 90.0, 100.0, 100.0),
            candle(1, 101.0, 99.0, 100.0),
        )
        val setup = RiskPlanBacktester.Setup(0, RiskPlanCalculator.Direction.LONG, 100.0, 95.0, 105.0)
        assertEquals(RiskPlanBacktester.ExitReason.INVALID_SETUP,
            RiskPlanBacktester.simulate(malformedEntry, setup, 0.0, 0.0).reason)

        val validEntryOnly = listOf(candle(0, 101.0, 99.0, 100.0), candle(1, 0.0, 0.0, 0.0))
        val noExit = RiskPlanBacktester.simulate(validEntryOnly, setup, 0.0, 0.0)
        assertEquals(RiskPlanBacktester.ExitReason.NO_FUTURE_CANDLES, noExit.reason)
        assertNull(noExit.exitPrice)
    }

    @Test fun rejectsWrongDirectionPlanAndInvalidCandleIsSkipped() {
        val candles = listOf(candle(0, 101.0, 99.0, 100.0), candle(1, 0.0, 0.0, 0.0), candle(2, 102.0, 99.0, 101.0))
        val invalid = RiskPlanBacktester.Setup(0, RiskPlanCalculator.Direction.LONG, 100.0, 105.0, 95.0)
        assertEquals(RiskPlanBacktester.ExitReason.INVALID_SETUP,
            RiskPlanBacktester.simulate(candles, invalid, 0.05, 0.02).reason)
        val valid = RiskPlanBacktester.Setup(0, RiskPlanCalculator.Direction.LONG, 100.0, 95.0, 105.0)
        assertEquals(RiskPlanBacktester.ExitReason.TIME_LIMIT,
            RiskPlanBacktester.simulate(candles, valid, 0.0, 0.0, maxHoldingBars = 2).reason)
    }
}
