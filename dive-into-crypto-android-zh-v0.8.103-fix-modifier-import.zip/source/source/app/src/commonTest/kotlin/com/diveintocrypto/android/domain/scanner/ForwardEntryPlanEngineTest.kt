package com.diveintocrypto.android.domain.scanner

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class ForwardEntryPlanEngineTest {
    private fun input(
        price: Double = 100.0,
        direction: Int = 1,
        mtfDirection: Int = 1,
        support: Double? = 99.0,
        resistance: Double? = 101.0,
        regime: String = "TREND",
        mtfGate: Boolean = true,
        now: Long = 10_000_000L,
    ) = ForwardEntryPlanEngine.Input(
        symbol = "btcusdt", currentPrice = price, atrPercent = 1.0,
        support = support, resistance = resistance, dominantDirection = direction,
        mtfDirection = mtfDirection, mtfGate = mtfGate, regime = regime,
        evidence = listOf(
            ForwardEntryPlanEngine.TimeframeEvidence("15m", direction, 70, 50),
            ForwardEntryPlanEngine.TimeframeEvidence("4h", direction, 65, 80),
        ),
        candleOpenTimeMs = now - 60_000L, candleTimeframeMs = 60_000L,
        generatedAtMs = now, nowMs = now, minQuality = 40,
    )

    @Test fun createsPreparatoryPlansWithoutClaimingTriggerWasHit() {
        val result = ForwardEntryPlanEngine.generate(input())
        assertTrue(result.plans.isNotEmpty())
        assertTrue(result.plans.all { it.status == ForwardEntryPlanEngine.Status.WAITING_TRIGGER })
        assertTrue(result.plans.all { it.entryLow > 0.0 && it.entryHigh >= it.entryLow })
        assertTrue(result.plans.all { it.stopLoss < (it.entryLow + it.entryHigh) / 2.0 })
        assertTrue(result.plans.all { it.takeProfit > (it.entryLow + it.entryHigh) / 2.0 })
    }

    @Test fun rejectsStaleMarketData() {
        val stale = input(now = 10_000_000L).copy(candleOpenTimeMs = 1L)
        val result = ForwardEntryPlanEngine.generate(stale)
        assertTrue(result.plans.isEmpty())
        assertTrue(result.rejectionReasons.keys.any { it.contains("market_data") })
    }

    @Test fun rejectsOpposingTimeframeBias() {
        val result = ForwardEntryPlanEngine.generate(input(mtfDirection = -1))
        assertTrue(result.plans.isEmpty())
        assertEquals(1, result.rejectionReasons["timeframe_conflict"])
    }

    @Test fun noAtrMeansNoFabricatedPricePlan() {
        val result = ForwardEntryPlanEngine.generate(input().copy(atrPercent = null))
        assertTrue(result.plans.isEmpty())
        assertEquals(1, result.rejectionReasons["atr_missing_or_invalid"])
    }

    @Test fun primaryTimeframePrefersHigherTimeframeEvidenceSupportingDirection() {
        assertEquals("4h", ForwardEntryPlanEngine.choosePrimaryTimeframe(
            listOf(
                ForwardEntryPlanEngine.TimeframeEvidence("15m", 1, 99, 50),
                ForwardEntryPlanEngine.TimeframeEvidence("4h", 1, 60, 80),
                ForwardEntryPlanEngine.TimeframeEvidence("1d", -1, 95, 100),
            ), 1
        ))
    }

    @Test fun estimatedFeesAndSlippageReduceNetRiskReward() {
        val gross = ForwardEntryPlanEngine.generate(input().copy(feeSidePct = 0.0, slippageSidePct = 0.0))
        val net = ForwardEntryPlanEngine.generate(input().copy(feeSidePct = 0.05, slippageSidePct = 0.02))
        assertTrue(gross.plans.isNotEmpty())
        assertTrue(net.plans.isNotEmpty())
        assertTrue(net.plans.first().riskRewardRatio < gross.plans.first().riskRewardRatio)
        assertTrue(net.plans.first().validationNotes.any { it.contains("手续费") })
    }

    @Test fun shortPlanUsesStopAboveAndTargetBelowEntry() {
        val result = ForwardEntryPlanEngine.generate(input(direction = -1, mtfDirection = -1))
        assertFalse(result.plans.isEmpty())
        assertTrue(result.plans.all { it.stopLoss > (it.entryLow + it.entryHigh) / 2.0 })
        assertTrue(result.plans.all { it.takeProfit < (it.entryLow + it.entryHigh) / 2.0 })
    }
}
