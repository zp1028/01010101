package com.diveintocrypto.android.domain.scanner

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull
import kotlin.test.assertNotNull

class RiskCostCalculatorTest {
    @Test fun costUsesExitNotionalForLongPlan() {
        val result = assertNotNull(RiskCostCalculator.estimate(2.0, 3.0, 0.05, 0.02, RiskPlanCalculator.Direction.LONG))
        assertEquals(0.1386, result.stopPathCostPct, 1e-9)
        assertEquals(0.1421, result.targetPathCostPct, 1e-9)
        assertEquals(0.1421, result.roundTripCostPct, 1e-9)
        assertEquals(2.1386, result.netRiskPct, 1e-9)
        assertEquals(2.8579, result.netRewardPct, 1e-9)
        assertEquals(2.8579 / 2.1386, result.netRiskRewardRatio!!, 1e-9)
    }

    @Test fun shortPlanUsesOppositeExitNotionalFactors() {
        val result = assertNotNull(RiskCostCalculator.estimate(2.0, 3.0, 0.05, 0.02, RiskPlanCalculator.Direction.SHORT))
        assertEquals(0.1414, result.stopPathCostPct, 1e-9)
        assertEquals(0.1379, result.targetPathCostPct, 1e-9)
        assertEquals(0.1414, result.roundTripCostPct, 1e-9)
    }

    @Test fun highCostsCanMakeNetRewardNonPositive() {
        val result = assertNotNull(RiskCostCalculator.estimate(0.5, 0.1, 0.05, 0.02))
        assertEquals(null, result.netRiskRewardRatio)
    }

    @Test fun rejectsInvalidInputs() {
        assertNull(RiskCostCalculator.estimate(Double.NaN, 3.0, 0.05, 0.02))
        assertNull(RiskCostCalculator.estimate(2.0, 3.0, -0.01, 0.02))
        assertNull(RiskCostCalculator.estimate(2.0, 100.0, 0.05, 0.02))
    }
}
