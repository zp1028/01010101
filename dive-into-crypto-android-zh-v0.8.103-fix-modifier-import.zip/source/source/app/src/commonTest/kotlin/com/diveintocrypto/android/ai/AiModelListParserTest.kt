package com.diveintocrypto.android.ai

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith

class AiModelListParserTest {
    @Test
    fun parsesOpenAiDataAndSortsDeduplicatesIds() {
        assertEquals(
            listOf("gpt-a", "gpt-b"),
            AiModelListParser.parse("""{"data":[{"id":"gpt-b"},{"id":"gpt-a"},{"id":"gpt-b"}]}"""),
        )
    }

    @Test
    fun parsesNestedGatewayAndAlternateIdFields() {
        assertEquals(
            listOf("alpha", "beta"),
            AiModelListParser.parse("""{"result":{"models":[{"name":"beta"},{"model":"alpha"}]}}"""),
        )
    }

    @Test
    fun fallsBackWhenHigherPriorityIdFieldIsBlank() {
        assertEquals(
            listOf("fallback-name", "model-field"),
            AiModelListParser.parse(
                """{"data":[{"id":"","name":"fallback-name"},{"id":"   ","model":"model-field"}]}""",
            ),
        )
    }

    @Test
    fun prefersPopulatedModelArrayOverEarlierEmptyAlias() {
        assertEquals(
            listOf("model-a", "model-b"),
            AiModelListParser.parse(
                """{"data":[],"models":[{"id":"model-b"},{"id":"model-a"}]}""",
            ),
        )
    }

    @Test
    fun parsesPlainStringArrayAndDropsBlankValues() {
        assertEquals(listOf("model-x", "model-y"), AiModelListParser.parse("""["model-y", "", "model-x"]"""))
    }

    @Test
    fun reportsInvalidJsonAndMissingModelArray() {
        assertFailsWith<IllegalArgumentException> { AiModelListParser.parse("not-json") }
        assertFailsWith<IllegalArgumentException> { AiModelListParser.parse("""{"status":"ok"}""") }
    }
}
