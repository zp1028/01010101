package com.diveintocrypto.android.domain.analysis

import com.diveintocrypto.android.domain.model.Signal
import com.diveintocrypto.android.domain.scanner.RiskPlanCalculator
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

class AnalysisPlanMathTest {
    @Test
    fun targetRSliderChangesTakeProfitNotEntry() {
        val entry = 100.0
        val atr = 2.0
        val p1 = assertNotNull(AnalysisPlanMath.buildPlan(Signal.BUY, entry, atr, targetR = 1.5))
        val p2 = assertNotNull(AnalysisPlanMath.buildPlan(Signal.BUY, entry, atr, targetR = 2.5))
        assertEquals(p1.entry, p2.entry, 1e-9)
        assertEquals(p1.stopLoss, p2.stopLoss, 1e-9)
        assertTrue(p2.takeProfit > p1.takeProfit)
        assertEquals(2.5, p2.riskRewardRatio, 1e-9)
    }

    @Test
    fun shortPlanTargetBelowEntry() {
        val p = assertNotNull(AnalysisPlanMath.buildPlan(Signal.SELL, 100.0, 2.0, targetR = 2.0))
        assertTrue(p.takeProfit < p.entry)
        assertTrue(p.stopLoss > p.entry)
    }

    @Test
    fun snapTargetRSteps() {
        assertEquals(1.5, AnalysisPlanMath.snapTargetR(1.54), 1e-9)
        assertEquals(1.0, AnalysisPlanMath.snapTargetR(0.5), 1e-9)
        assertEquals(3.0, AnalysisPlanMath.snapTargetR(9.0), 1e-9)
    }

    @Test
    fun priceProgressLong() {
        val p = AnalysisPlanMath.priceProgress(
            RiskPlanCalculator.Direction.LONG,
            stop = 90.0,
            target = 110.0,
            livePrice = 100.0,
        )
        assertEquals(0.5, p, 1e-9)
    }
}

    @Test
    fun structureBookNearestFirst() {
        val highs = listOf(10.0, 11.0, 15.0, 12.0, 11.0, 14.0, 13.0, 16.0, 15.0)
        val lows = listOf(8.0, 7.0, 11.0, 10.0, 10.5, 12.0, 11.0, 13.0, 12.5)
        val book = AnalysisPlanMath.structureBook(highs, lows, currentPrice = 12.8, k = 1, maxEach = 3)
        assertTrue(book.supports.isNotEmpty() || book.resistances.isNotEmpty())
        book.supports.forEach { assertTrue(it < 12.8) }
        book.resistances.forEach { assertTrue(it > 12.8) }
    }

    @Test
    fun rsiSeriesHasWarmupNulls() {
        val closes = (1..30).map { it.toDouble() }
        val series = AnalysisPlanMath.rsiSeries(closes, period = 14)
        assertEquals(30, series.size)
        assertTrue(series.take(14).all { it == null })
        assertNotNull(series.last())
    }
