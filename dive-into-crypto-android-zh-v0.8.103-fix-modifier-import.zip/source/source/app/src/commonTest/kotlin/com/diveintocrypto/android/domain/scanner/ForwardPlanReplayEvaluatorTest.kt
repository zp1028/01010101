package com.diveintocrypto.android.domain.scanner

import com.diveintocrypto.android.domain.model.Candle
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class ForwardPlanReplayEvaluatorTest {
    private fun plan() = ForwardEntryPlanEngine.Plan(
        id = "p1", symbol = "BTCUSDT", direction = ForwardEntryPlanEngine.Direction.LONG,
        type = ForwardEntryPlanEngine.Type.BREAKOUT_PREPARATION, primaryTimeframe = "1h",
        generatedAtMs = 1_000L, expiresAtMs = 10_000L, referencePrice = 100.0,
        maxAllowedPriceMovePct = 3.0, entryLow = 99.0, entryHigh = 101.0, triggerPrice = 101.0,
        stopLoss = 98.0, takeProfit = 104.0, riskRewardRatio = 1.33, quality = 80,
        status = ForwardEntryPlanEngine.Status.WAITING_TRIGGER, triggerRule = "closed", invalidationRule = "stop",
        validationNotes = emptyList(), snapshotKey = "snap1",
    )

    @Test fun ignoresCandlesBeforeDecisionAndAfterAsOf() {
        val candles = listOf(
            Candle(0, 100.0, 110.0, 90.0, 105.0, 1.0, 900),
            Candle(1_100, 100.0, 103.0, 99.0, 102.0, 1.0, 1_900),
            Candle(9_100, 100.0, 110.0, 99.0, 108.0, 1.0, 9_900),
        )
        val result = ForwardPlanReplayEvaluator.evaluate(plan(), candles, asOfMs = 2_000)
        assertEquals(ForwardPlanReplayEvaluator.Outcome.OPEN, result.outcome)
        assertEquals(1, result.candlesConsidered)
        assertTrue(result.evaluatedThroughMs <= 2_000)
    }

    @Test fun ambiguousStopAndTargetSameCandleUsesConservativeStopFirst() {
        val result = ForwardPlanReplayEvaluator.evaluate(
            plan(), listOf(Candle(1_100, 100.0, 105.0, 97.0, 102.0, 1.0, 1_900)), asOfMs = 2_000,
        )
        assertEquals(ForwardPlanReplayEvaluator.Outcome.STOP_HIT, result.outcome)
        assertEquals("SUFFICIENT_FOR_OUTCOME", result.coverageStatus)
        assertTrue(result.grossR != null && result.grossR!! < -1.0) // round-trip costs are included
    }

    @Test fun targetHitUsesPostDecisionClosedCandle() {
        val result = ForwardPlanReplayEvaluator.evaluate(
            plan(), listOf(Candle(1_100, 100.0, 104.5, 99.0, 104.0, 1.0, 1_900)), asOfMs = 2_000,
        )
        assertEquals(ForwardPlanReplayEvaluator.Outcome.TARGET_HIT, result.outcome)
        assertTrue(result.grossR != null && result.grossR!! > 0.0)
    }
    @Test fun expiredPlanWithoutCandleCoverageThroughExpiryStaysUnresolved() {
        val result = ForwardPlanReplayEvaluator.evaluate(
            plan(), listOf(Candle(1_100, 100.0, 100.5, 99.5, 100.0, 1.0, 9_900)), asOfMs = 20_000,
        )
        assertEquals(ForwardPlanReplayEvaluator.Outcome.OPEN, result.outcome)
        assertTrue(result.notes.any { it.contains("历史覆盖不足") || it.contains("不计入胜率") })
    }

    @Test fun expiredPlanOnlySettlesAfterClosedCandleCoversExpiryBoundary() {
        val result = ForwardPlanReplayEvaluator.evaluate(
            plan(), listOf(
                Candle(1_100, 100.0, 100.5, 99.5, 100.0, 1.0, 9_900),
                Candle(9_901, 100.0, 100.5, 99.5, 100.0, 1.0, 10_900),
            ), asOfMs = 20_000,
        )
        assertEquals(ForwardPlanReplayEvaluator.Outcome.EXPIRED, result.outcome)
        assertEquals("COMPLETE_THROUGH_EXPIRY", result.coverageStatus)
    }


    @Test fun postExpiryBoundaryCandleProvesCoverageButCannotTriggerTarget() {
        val result = ForwardPlanReplayEvaluator.evaluate(
            plan(), listOf(
                Candle(1_100, 100.0, 100.5, 99.5, 100.0, 1.0, 1_900),
                Candle(9_901, 100.0, 100.5, 99.5, 100.0, 1.0, 10_900),
                // This candle closes after expiry and touches target; it must not count as a win.
                Candle(10_901, 100.0, 105.0, 99.5, 104.0, 1.0, 11_900),
            ), asOfMs = 20_000,
        )
        assertEquals(ForwardPlanReplayEvaluator.Outcome.EXPIRED, result.outcome)
        assertEquals("COMPLETE_THROUGH_EXPIRY", result.coverageStatus)
    }

    @Test fun historyGapBeforeTargetDoesNotProduceFalseWin() {
        val result = ForwardPlanReplayEvaluator.evaluate(
            plan(), listOf(
                Candle(1_100, 100.0, 100.5, 99.5, 100.0, 1.0, 1_900),
                // An 8-bar gap could hide an earlier stop; later target must not be trusted.
                Candle(9_100, 100.0, 105.0, 99.5, 104.0, 1.0, 9_900),
            ), asOfMs = 10_000, expectedIntervalMs = 1_000,
        )
        assertEquals(ForwardPlanReplayEvaluator.Outcome.OPEN, result.outcome)
        assertEquals("GAP", result.coverageStatus)
        assertTrue(result.notes.any { it.contains("时间缺口") })
    }

    @Test fun candleOpenedBeforeDecisionCanBeUsedOnlyAfterItsClose() {
        val result = ForwardPlanReplayEvaluator.evaluate(
            plan(), listOf(Candle(500, 100.0, 104.5, 99.5, 104.0, 1.0, 1_500)),
            asOfMs = 2_000, expectedIntervalMs = 1_000,
        )
        assertEquals(ForwardPlanReplayEvaluator.Outcome.TARGET_HIT, result.outcome)
        assertEquals(1_500L, result.firstOutcomeCandleCloseMs)
    }

    @Test fun expiryDoesNotSettleAcrossHistoricalCandleGap() {
        val result = ForwardPlanReplayEvaluator.evaluate(
            plan(), listOf(
                Candle(1_100, 100.0, 100.5, 99.5, 100.0, 1.0, 1_900),
                Candle(9_100, 100.0, 100.5, 99.5, 100.0, 1.0, 9_900),
                Candle(10_100, 100.0, 100.5, 99.5, 100.0, 1.0, 10_900),
            ), asOfMs = 20_000, expectedIntervalMs = 1_000,
        )
        assertEquals(ForwardPlanReplayEvaluator.Outcome.OPEN, result.outcome)
    }

}
