package com.diveintocrypto.android.domain.scanner

import com.diveintocrypto.android.domain.model.Candle
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class HistoricalCandleAlignmentTest {
    private fun candle(openTime: Long, closeTime: Long, price: Double) = Candle(
        openTime = openTime,
        open = price,
        high = price * 1.02,
        low = price * 0.98,
        close = price * 1.01,
        volume = 1.0,
        closeTime = closeTime,
    )

    @Test
    fun closedBeforeExcludesSimultaneousAndFutureBarsEvenWhenInputIsUnsorted() {
        val earlier = candle(100, 199, 10.0)
        val boundary = candle(200, 300, 20.0)
        val future = candle(301, 399, 30.0)

        val aligned = HistoricalCandleAlignment.closedBefore(listOf(future, boundary, earlier), 300)

        assertEquals(listOf(100L), aligned.map { it.openTime })
        assertTrue(aligned.all { it.closeTime < 300L })
    }

    @Test
    fun closeTimeFilteringDoesNotAssumeCloseTimesAreMonotonic() {
        val delayed = candle(100, 250, 10.0)
        val alreadyClosed = candle(200, 220, 20.0)

        val aligned = HistoricalCandleAlignment.closedBefore(listOf(delayed, alreadyClosed), 230)

        assertEquals(listOf(200L), aligned.map { it.openTime })
    }

    @Test
    fun sanitizeDropsMalformedBarsAndKeepsLastDuplicateRevision() {
        val original = candle(100, 199, 10.0)
        val revised = candle(100, 199, 12.0)
        val malformedTime = candle(200, 200, 20.0)
        val malformedRange = candle(300, 399, 30.0).copy(low = 100.0)

        val result = HistoricalCandleAlignment.sanitize(
            listOf(original, malformedTime, candle(400, 499, 40.0), revised, malformedRange),
        )

        assertEquals(listOf(100L, 400L), result.map { it.openTime })
        assertEquals(12.0, result.first().open)
    }

    @Test
    fun emptyOrInvalidBoundaryNeverReturnsBars() {
        val data = listOf(candle(100, 199, 10.0))
        assertTrue(HistoricalCandleAlignment.closedBefore(data, 0).isEmpty())
        assertTrue(HistoricalCandleAlignment.closedBefore(emptyList(), 300).isEmpty())
    }
    @Test
    fun sanitizeRejectsInvalidOpenPricesAndNegativeOpenTimes() {
        val valid = candle(100, 199, 10.0)
        val invalidOpen = valid.copy(openTime = 200, closeTime = 299, open = Double.NaN)
        val negativeTime = candle(-1, 99, 11.0)
        val invalidOpenPrice = valid.copy(openTime = 300, closeTime = 399, open = 0.0)

        val result = HistoricalCandleAlignment.sanitize(listOf(valid, invalidOpen, negativeTime, invalidOpenPrice))

        assertEquals(listOf(100L), result.map { it.openTime })
    }

    @Test
    fun sanitizeRejectsNegativeAndNonFiniteVolumesButAllowsZeroVolume() {
        val zeroVolume = candle(100, 199, 10.0).copy(volume = 0.0)
        val negativeVolume = candle(200, 299, 11.0).copy(volume = -1.0)
        val nonFiniteVolume = candle(300, 399, 12.0).copy(volume = Double.NaN)
        val infiniteVolume = candle(400, 499, 13.0).copy(volume = Double.POSITIVE_INFINITY)

        val result = HistoricalCandleAlignment.sanitize(
            listOf(zeroVolume, negativeVolume, nonFiniteVolume, infiniteVolume),
        )

        assertEquals(listOf(100L), result.map { it.openTime })
    }

    @Test
    fun strictCloseAlignmentSanitizesThenFiltersByAvailabilityTime() {
        val laterOpenButEarlierClose = candle(300, 350, 12.0)
        val earlierOpenButLaterClose = candle(200, 500, 11.0)
        val malformed = candle(400, 450, 13.0).copy(open = Double.POSITIVE_INFINITY)

        val result = HistoricalCandleAlignment.closedBefore(
            listOf(earlierOpenButLaterClose, malformed, laterOpenButEarlierClose),
            400,
        )

        assertEquals(listOf(300L), result.map { it.openTime })
    }



    @Test
    fun detectsTimeDiscontinuitiesWithoutTreatingRegularCadenceAsGap() {
        val regular = (0..9).map { i ->
            val openTime = i * 60_000L
            Candle(openTime, 10.0, 11.0, 9.0, 10.0, 1.0, openTime + 59_999L)
        }
        assertEquals(false, HistoricalCandleAlignment.hasIntervalDiscontinuity(regular, 2, 8))

        val gap = regular.mapIndexed { i, candle ->
            if (i >= 5) candle.copy(openTime = candle.openTime + 120_000L, closeTime = candle.closeTime + 120_000L) else candle
        }
        val sanitized = HistoricalCandleAlignment.sanitize(gap)
        assertEquals(true, HistoricalCandleAlignment.hasIntervalDiscontinuity(sanitized, 2, 8))
    }
    @Test
    fun gapDetectionDoesNotUseFutureCadenceToJudgeEarlierCandles() {
        val regular = (0..12).map { i ->
            val openTime = i * 60_000L
            Candle(openTime, 10.0, 11.0, 9.0, 10.0, 1.0, openTime + 59_999L)
        }
        val futureDifferentCadence = regular + (13..34).map { i ->
            val openTime = 12 * 60_000L + (i - 12) * 600_000L
            Candle(openTime, 10.0, 11.0, 9.0, 10.0, 1.0, openTime + 599_999L)
        }

        assertEquals(false, HistoricalCandleAlignment.hasIntervalDiscontinuity(regular, 3, 10))
        assertEquals(false, HistoricalCandleAlignment.hasIntervalDiscontinuity(futureDifferentCadence, 3, 10))
    }

    @Test
    fun detectsGapAgainstPriorCadenceEvenWhenFutureCadenceChanges() {
        val bars = (0..15).map { i ->
            val openTime = when {
                i < 7 -> i * 60_000L
                i == 7 -> i * 60_000L + 120_000L
                else -> 7 * 60_000L + 120_000L + (i - 7) * 600_000L
            }
            val duration = if (i <= 7) 59_999L else 599_999L
            Candle(openTime, 10.0, 11.0, 9.0, 10.0, 1.0, openTime + duration)
        }
        assertEquals(true, HistoricalCandleAlignment.hasIntervalDiscontinuity(bars, 3, 10))
    }

}
