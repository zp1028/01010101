package com.diveintocrypto.android.data.binance

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.test.runTest
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class RestRetryTest {
    @Test
    fun retriesRateLimitAndEventuallySucceeds() = runTest {
        var calls = 0
        val result = retryPublicRest(maxAttempts = 3, baseDelayMs = 0) {
            calls++
            if (calls < 3) throw IllegalStateException("Binance HTTP 429")
            "ok"
        }
        assertEquals("ok", result)
        assertEquals(3, calls)
    }

    @Test
    fun stopsAfterConfiguredAttemptLimit() = runTest {
        var calls = 0
        assertFailsWith<IllegalStateException> {
            retryPublicRest(maxAttempts = 2, baseDelayMs = 0) {
                calls++
                throw IllegalStateException("HTTP 503")
            }
        }
        assertEquals(2, calls)
    }

    @Test
    fun doesNotRetryClientInputErrors() = runTest {
        var calls = 0
        assertFailsWith<IllegalStateException> {
            retryPublicRest(maxAttempts = 3, baseDelayMs = 0) {
                calls++
                throw IllegalStateException("HTTP 400 invalid symbol")
            }
        }
        assertEquals(1, calls)
        assertFalse(isRetryablePublicRestFailure(IllegalStateException("HTTP 400 invalid symbol")))
        assertTrue(isRetryablePublicRestFailure(IllegalStateException("HTTP 429 rate limit")))
        assertTrue(isRetryablePublicRestFailure(IllegalStateException("HTTP 502 gateway")))
    }

    @Test
    fun propagatesCancellationImmediately() = runTest {
        var calls = 0
        assertFailsWith<CancellationException> {
            retryPublicRest(maxAttempts = 3, baseDelayMs = 0) {
                calls++
                throw CancellationException("scan stopped")
            }
        }
        assertEquals(1, calls)
    }
}
