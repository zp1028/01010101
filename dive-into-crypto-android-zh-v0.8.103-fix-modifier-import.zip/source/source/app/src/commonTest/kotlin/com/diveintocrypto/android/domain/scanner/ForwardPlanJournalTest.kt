package com.diveintocrypto.android.domain.scanner

import com.diveintocrypto.android.data.KeyValueStore
import com.diveintocrypto.android.data.SettingsStore
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class ForwardPlanJournalTest {
    private class MemoryKv : KeyValueStore {
        private val values = mutableMapOf<String, Any>()
        override fun getInt(key: String, default: Int) = values[key] as? Int ?: default
        override fun putInt(key: String, value: Int) { values[key] = value }
        override fun getBoolean(key: String, default: Boolean) = values[key] as? Boolean ?: default
        override fun putBoolean(key: String, value: Boolean) { values[key] = value }
        override fun getFloat(key: String, default: Float) = values[key] as? Float ?: default
        override fun putFloat(key: String, value: Float) { values[key] = value }
        override fun getString(key: String, default: String?) = values[key] as? String ?: default
        override fun putString(key: String, value: String) { values[key] = value }
    }

    private fun makePlan(): ForwardEntryPlanEngine.Plan = ForwardEntryPlanEngine.generate(
        ForwardEntryPlanEngine.Input(
            symbol = "BTCUSDT", currentPrice = 100.0, atrPercent = 1.0,
            support = 99.0, resistance = 101.0, dominantDirection = 1,
            mtfDirection = 1, mtfGate = true, regime = "TREND",
            evidence = listOf(ForwardEntryPlanEngine.TimeframeEvidence("4h", 1, 70, 80)),
            candleOpenTimeMs = 9_940_000L, candleTimeframeMs = 60_000L,
            generatedAtMs = 10_000_000L, nowMs = 10_000_000L, minQuality = 40,
        )
    ).plans.first()

    @Test fun tickerCrossingDoesNotConfirmWithoutClosedCandleEvidence() {
        val journal = ForwardPlanJournal(SettingsStore(MemoryKv()))
        val plan = makePlan()
        journal.mergeCandidates(listOf(plan), plan.generatedAtMs)
        journal.observe(plan.id, plan.triggerPrice, plan.generatedAtMs + 1_000L)
        assertEquals(ForwardEntryPlanEngine.Status.WAITING_TRIGGER, journal.data.value.plans.first().status)
    }

    @Test fun laterClosedCandleCanConfirmAndRecordEvent() {
        val journal = ForwardPlanJournal(SettingsStore(MemoryKv()))
        val plan = makePlan()
        journal.mergeCandidates(listOf(plan), plan.generatedAtMs)
        journal.observe(
            plan.id, plan.referencePrice, plan.generatedAtMs + 60_000L,
            closedCandleClose = plan.triggerPrice + 0.01,
            closedCandleTimeMs = plan.generatedAtMs + 59_999L,
        )
        assertEquals(ForwardEntryPlanEngine.Status.CONDITION_MET, journal.data.value.plans.first().status)
        assertTrue(journal.data.value.events.any { it.toStatus == "CONDITION_MET" })
    }

    @Test fun journalPersistsSnapshotsAndEventsAcrossInstances() {
        val kv = MemoryKv()
        val settings = SettingsStore(kv)
        val plan = makePlan()
        ForwardPlanJournal(settings).mergeCandidates(listOf(plan), plan.generatedAtMs)
        val restored = ForwardPlanJournal(settings).data.value
        assertEquals(plan.id, restored.plans.first().snapshot.id)
        assertEquals(plan.snapshotKey, restored.plans.first().snapshot.snapshotKey)
        assertFalse(restored.events.isEmpty())
    }

    @Test fun aiProposalIsStoredAsImmutableVersionAndCannotOverwriteLocalSnapshot() {
        val journal = ForwardPlanJournal(SettingsStore(MemoryKv()))
        val plan = makePlan()
        journal.mergeCandidates(listOf(plan), plan.generatedAtMs)
        val revision = journal.appendAiRevision(
            planId = plan.id, entry = 100.0, stop = 99.0, target = 102.0,
            createdAtMs = plan.generatedAtMs + 1_000L, rationale = "多周期趋势与结构一致",
        )
        assertTrue(revision != null)
        assertEquals(1, revision?.version)
        assertEquals(plan.stopLoss, journal.data.value.plans.first().snapshot.stopLoss)
        assertEquals(plan.takeProfit, journal.data.value.plans.first().snapshot.takeProfit)
        assertEquals(1, journal.data.value.revisions.size)
        val duplicate = journal.appendAiRevision(
            planId = plan.id, entry = 100.0, stop = 99.0, target = 102.0,
            createdAtMs = plan.generatedAtMs + 2_000L, rationale = "重复建议",
        )
        assertEquals(revision?.revisionId, duplicate?.revisionId)
        assertEquals(1, journal.data.value.revisions.size)
    }

    @Test fun aiProposalRejectsWrongDirectionAndPoorRiskReward() {
        val journal = ForwardPlanJournal(SettingsStore(MemoryKv()))
        val plan = makePlan()
        journal.mergeCandidates(listOf(plan), plan.generatedAtMs)
        assertEquals(null, journal.appendAiRevision(
            planId = plan.id, entry = 100.0, stop = 101.0, target = 102.0,
            createdAtMs = plan.generatedAtMs + 1_000L, rationale = "错误方向",
        ))
        assertEquals(null, journal.appendAiRevision(
            planId = plan.id, entry = 100.0, stop = 99.0, target = 100.5,
            createdAtMs = plan.generatedAtMs + 1_000L, rationale = "RR不足",
        ))
        assertTrue(journal.data.value.revisions.isEmpty())
    }

    @Test fun expiredPlanMovesToExpiredAndIsNotActive() {
        val journal = ForwardPlanJournal(SettingsStore(MemoryKv()))
        val plan = makePlan()
        journal.mergeCandidates(listOf(plan), plan.generatedAtMs)
        journal.observe(plan.id, plan.referencePrice, plan.expiresAtMs)
        assertEquals(ForwardEntryPlanEngine.Status.EXPIRED, journal.data.value.plans.first().status)
        assertTrue(journal.activePlans().isEmpty())
    }
    @Test fun archiveKeepsSnapshotButRemovesPlanFromActiveList() {
        val journal = ForwardPlanJournal(SettingsStore(MemoryKv()))
        val plan = makePlan()
        journal.mergeCandidates(listOf(plan), plan.generatedAtMs)
        journal.archivePlan(plan.id, plan.generatedAtMs + 1_000L)
        val tracked = journal.data.value.plans.first()
        assertTrue(tracked.archived)
        assertEquals(plan.snapshotKey, tracked.snapshot.snapshotKey)
        assertTrue(journal.activePlans().isEmpty())
        assertTrue(journal.data.value.events.any { it.reason.contains("归档") })
    }

    @Test fun deleteArchivedRemovesOnlyArchivedPlanAndRelatedHistory() {
        val journal = ForwardPlanJournal(SettingsStore(MemoryKv()))
        val plan = makePlan()
        journal.mergeCandidates(listOf(plan), plan.generatedAtMs)
        journal.appendAiRevision(
            planId = plan.id, entry = 100.0, stop = 99.0, target = 102.0,
            createdAtMs = plan.generatedAtMs + 1_000L, rationale = "测试版本",
        )
        journal.archivePlan(plan.id, plan.generatedAtMs + 2_000L)
        assertEquals(1, journal.deleteArchived())
        assertTrue(journal.data.value.plans.isEmpty())
        assertTrue(journal.data.value.events.isEmpty())
        assertTrue(journal.data.value.revisions.isEmpty())
        assertEquals(0, journal.deleteArchived())
    }


    @Test fun replayResultsArePersistedDeduplicatedAndRemovedWithArchivedPlan() {
        val settings = SettingsStore(MemoryKv())
        val journal = ForwardPlanJournal(settings)
        val plan = makePlan()
        journal.mergeCandidates(listOf(plan), plan.generatedAtMs)
        val result = ForwardPlanReplayEvaluator.Result(
            planId = plan.id,
            outcome = ForwardPlanReplayEvaluator.Outcome.TARGET_HIT,
            evaluatedThroughMs = plan.generatedAtMs + 60_000L,
            candlesConsidered = 3,
            firstOutcomeCandleCloseMs = plan.generatedAtMs + 60_000L,
            grossR = 1.8,
            notes = listOf("测试回放"),
        )
        assertTrue(journal.appendReplayResult(result, plan.generatedAtMs + 61_000L) != null)
        assertTrue(journal.appendReplayResult(result, plan.generatedAtMs + 62_000L) != null)
        assertEquals(1, journal.data.value.replayResults.size)
        val restored = ForwardPlanJournal(settings)
        assertEquals("TARGET_HIT", restored.data.value.replayResults.first().outcome)
        restored.archivePlan(plan.id, plan.generatedAtMs + 70_000L)
        restored.deleteArchived()
        assertTrue(restored.data.value.replayResults.isEmpty())
    }


    @Test fun replayPaginationProgressSurvivesJournalReloadAndCanResume() {
        val settings = SettingsStore(MemoryKv())
        val journal = ForwardPlanJournal(settings)
        val plan = makePlan()
        journal.mergeCandidates(listOf(plan), plan.generatedAtMs)
        val progress = ForwardReplayProgress(
            planId = plan.id,
            windowStartMs = plan.generatedAtMs,
            windowEndMs = plan.expiresAtMs + 60_000L,
            nextCursorMs = plan.generatedAtMs + 120_000L,
            candles = listOf(ForwardReplayCandle(
                openTime = plan.generatedAtMs, open = 100.0, high = 101.0, low = 99.0,
                close = 100.5, volume = 12.0, closeTime = plan.generatedAtMs + 59_999L,
            )),
            updatedAtMs = plan.generatedAtMs + 60_000L,
        )
        journal.saveReplayProgress(progress)
        val restored = ForwardPlanJournal(settings).replayProgress(plan.id)
        assertEquals(progress.nextCursorMs, restored?.nextCursorMs)
        assertEquals(1, restored?.candles?.size)
        assertEquals(plan.generatedAtMs, restored?.candles?.first()?.openTime)
        ForwardPlanJournal(settings).clearReplayProgress(plan.id)
        assertEquals(null, ForwardPlanJournal(settings).replayProgress(plan.id))
    }

    @Test fun replayBatchSelectorPrioritizesNeverEvaluatedPlansAndSkipsTerminalOnes() {
        val journal = ForwardPlanJournal(SettingsStore(MemoryKv()))
        val base = makePlan()
        val older = base.copy(id = "older", generatedAtMs = base.generatedAtMs - 2_000L)
        val newer = base.copy(id = "newer", generatedAtMs = base.generatedAtMs + 2_000L)
        val terminal = base.copy(id = "terminal", generatedAtMs = base.generatedAtMs - 1_000L)
        val plans = listOf(
            TrackedForwardPlan(older), TrackedForwardPlan(newer), TrackedForwardPlan(terminal),
        )
        val records = listOf(
            ForwardPlanReplayRecord(
                planId = "older", outcome = "OPEN", evaluatedThroughMs = 10L,
                candlesConsidered = 1, savedAtMs = 500L,
            ),
            ForwardPlanReplayRecord(
                planId = "terminal", outcome = "TARGET_HIT", evaluatedThroughMs = 10L,
                candlesConsidered = 1, savedAtMs = 100L,
            ),
        )
        val selected = ForwardReplayBatchSelector.select(plans, records, limit = 2).map { it.snapshot.id }
        assertFalse("terminal" in selected)
        assertEquals("newer", selected.first())
        assertTrue("older" in selected)
    }

}
