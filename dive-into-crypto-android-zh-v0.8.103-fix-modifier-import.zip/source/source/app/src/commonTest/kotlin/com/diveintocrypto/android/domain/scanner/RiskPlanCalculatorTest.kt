package com.diveintocrypto.android.domain.scanner

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

class RiskPlanCalculatorTest {
    @Test fun longPlanPlacesStopBelowAndTargetAboveEntry() {
        val result = RiskPlanCalculator.calculate(RiskPlanCalculator.Direction.LONG, 100.0, 2.0)
        assertTrue(result.valid)
        val plan = assertNotNull(result.plan)
        assertEquals(97.0, plan.stopLoss, 1e-9)
        assertEquals(106.0, plan.takeProfit, 1e-9)
        assertEquals(2.0, plan.riskRewardRatio, 1e-9)
    }

    @Test fun shortPlanPlacesStopAboveAndTargetBelowEntry() {
        val result = RiskPlanCalculator.calculate(RiskPlanCalculator.Direction.SHORT, 100.0, 2.0)
        val plan = assertNotNull(result.plan)
        assertTrue(plan.stopLoss > plan.entry)
        assertTrue(plan.takeProfit < plan.entry)
        assertEquals(2.0, plan.riskRewardRatio, 1e-9)
    }

    @Test fun stopDistancePercentUsesEntryAsDenominator() {
        val plan = assertNotNull(RiskPlanCalculator.calculate(RiskPlanCalculator.Direction.LONG, 200.0, 4.0, atrMultiplier = 1.5).plan)
        assertEquals(3.0, plan.riskPerUnit, 1e-9)
        assertEquals(1.5, plan.stopDistancePercent, 1e-9)
        assertEquals(plan.takeProfit - plan.entry, plan.rewardPerUnit, 1e-9)
    }

    @Test fun rejectsInvalidInputs() {
        assertEquals("invalid_entry", RiskPlanCalculator.calculate(RiskPlanCalculator.Direction.LONG, Double.NaN, 1.0).reason)
        assertEquals("invalid_atr", RiskPlanCalculator.calculate(RiskPlanCalculator.Direction.LONG, 100.0, 0.0).reason)
        assertEquals("invalid_target_r", RiskPlanCalculator.calculate(RiskPlanCalculator.Direction.LONG, 100.0, 1.0, targetR = Double.POSITIVE_INFINITY).reason)
        val tooWide = RiskPlanCalculator.calculate(RiskPlanCalculator.Direction.LONG, 1.0, 2.0)
        assertFalse(tooWide.valid)
        assertNull(tooWide.plan)
    }
}
