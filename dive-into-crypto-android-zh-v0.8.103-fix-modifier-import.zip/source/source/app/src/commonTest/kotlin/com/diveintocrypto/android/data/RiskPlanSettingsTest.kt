package com.diveintocrypto.android.data

import com.diveintocrypto.android.testutil.InMemoryKeyValueStore
import kotlin.test.Test
import kotlin.test.assertEquals

class RiskPlanSettingsTest {
    @Test
    fun riskPlanSettingsHaveSafeDefaults() {
        val store = SettingsStore(InMemoryKeyValueStore())
        val settings = store.getSettings()
        assertEquals(1.5, settings.riskTargetR, 0.0001)
        assertEquals(0.05, settings.riskFeeSidePct, 0.0001)
        assertEquals(0.02, settings.riskSlippageSidePct, 0.0001)
    }

    @Test
    fun riskPlanSettingsPersistAcrossStoreRecreation() {
        val backing = InMemoryKeyValueStore()
        val first = SettingsStore(backing)
        first.updateSettings(first.getSettings().copy(
            riskTargetR = 2.25,
            riskFeeSidePct = 0.08,
            riskSlippageSidePct = 0.04,
        ))

        val restored = SettingsStore(backing).getSettings()
        assertEquals(2.25, restored.riskTargetR, 0.0001)
        assertEquals(0.08, restored.riskFeeSidePct, 0.0001)
        assertEquals(0.04, restored.riskSlippageSidePct, 0.0001)
    }
}
