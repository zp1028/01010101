package com.diveintocrypto.android.data.ai

import com.diveintocrypto.android.domain.scanner.RiskPlanCalculator
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

class AiAnalysisClientTest {
    @Test
    fun chatUrlNormalizesDeepSeekAndOpenAi() {
        assertEquals(
            "https://api.deepseek.com/v1/chat/completions",
            AiAnalysisClient.chatCompletionsUrl("https://api.deepseek.com"),
        )
        assertEquals(
            "https://api.openai.com/v1/chat/completions",
            AiAnalysisClient.chatCompletionsUrl("https://api.openai.com/v1"),
        )
    }

    @Test
    fun parseAiPlanFromFencedJson() {
        val text = """
分析结论：偏多。
```json
{"direction":"LONG","entry":100.0,"stop":95.0,"target":110.0,"rr":2.0,"thesis":"回踩支撑"}
```
""".trimIndent()
        val plan = assertNotNull(AiAnalysisClient.parseAiPlan(text))
        assertEquals(RiskPlanCalculator.Direction.LONG, plan.direction)
        assertEquals(100.0, plan.entry, 1e-9)
        assertEquals(95.0, plan.stopLoss, 1e-9)
        assertEquals(110.0, plan.takeProfit, 1e-9)
        val rp = AiAnalysisClient.toRiskPlan(plan)
        assertTrue(rp.stopDistancePercent > 0)
    }

    @Test
    fun extractStreamDeltaContent() {
        val data = """{"choices":[{"delta":{"content":"你好"}}]}"""
        assertEquals("你好", AiAnalysisClient.extractStreamDelta(data))
    }
}
