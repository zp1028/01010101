package com.diveintocrypto.android.domain.scanner

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class OpportunityLifecycleBaselineTest {
    private fun snap(symbol: String, direction: Int, price: Double = 100.0) =
        OpportunityLifecycle.Snapshot(symbol, direction, price, 1.0)

    @Test fun partialScanCannotReplaceTrustedBaseline() {
        val original = listOf(snap("BTCUSDT", 1))
        val baseline = OpportunityLifecycleBaseline(original)

        assertFalse(baseline.promoteIfComplete(listOf(snap("BTCUSDT", -1)), scanComplete = false))
        assertEquals(original, baseline.snapshot())
    }

    @Test fun completeScanPromotesNewBaselineAndAllowsReassessment() {
        val baseline = OpportunityLifecycleBaseline(listOf(snap("BTCUSDT", 1)))
        val reversed = listOf(snap("BTCUSDT", -1, 100.2))

        assertTrue(baseline.promoteIfComplete(reversed, scanComplete = true))
        assertEquals(reversed, baseline.snapshot())
        assertEquals(
            OpportunityLifecycle.Status.ACTIVE,
            OpportunityLifecycle.assess(snap("BTCUSDT", -1, 100.3), baseline.snapshot().single()).status,
        )
    }

}
