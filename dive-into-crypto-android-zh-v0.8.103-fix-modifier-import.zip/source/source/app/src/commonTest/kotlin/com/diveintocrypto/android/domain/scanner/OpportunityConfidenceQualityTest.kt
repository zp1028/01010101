package com.diveintocrypto.android.domain.scanner

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class OpportunityConfidenceQualityTest {
    @Test
    fun incompleteTimeframeCoverageCannotIncreaseConfidence() {
        val full = OpportunityConfidenceQuality.adjust(80, 4, listOf(1, 1, 1, 1), 1)
        val partial = OpportunityConfidenceQuality.adjust(80, 4, listOf(1), 1)
        assertEquals(100, full.coveragePercent)
        assertEquals(25, partial.coveragePercent)
        assertTrue(partial.adjustedConfidence < full.adjustedConfidence)
    }

    @Test
    fun opposingTimeframesApplyAdditionalDiscount() {
        val aligned = OpportunityConfidenceQuality.adjust(80, 4, listOf(1, 1, 1, 0), 1)
        val conflicting = OpportunityConfidenceQuality.adjust(80, 4, listOf(1, 1, -1, 0), 1)
        assertEquals(1, conflicting.conflictingTimeframes)
        assertTrue(conflicting.adjustedConfidence < aligned.adjustedConfidence)
    }

    @Test
    fun malformedDirectionsAreIgnoredAndBaseIsClamped() {
        val result = OpportunityConfidenceQuality.adjust(150, 2, listOf(1, 9, -1), 1)
        assertEquals(88, result.adjustedConfidence)
        assertEquals(100, result.coveragePercent)
        assertEquals(1, result.conflictingTimeframes)
    }
    @Test
    fun extraDirectionsCannotPenalizeBeyondDeclaredTimeframeBudget() {
        val bounded = OpportunityConfidenceQuality.adjust(
            baseConfidence = 80,
            expectedTimeframes = 2,
            observedDirections = listOf(1, 1, -1, -1),
            dominantDirection = 1,
        )
        assertEquals(100, bounded.coveragePercent)
        assertEquals(0, bounded.conflictingTimeframes)
        assertEquals(80, bounded.adjustedConfidence)
    }

    @Test
    fun dominantConfidenceOnlyUsesVotesSupportingTheDominantDirection() {
        val votes = listOf(1 to 62, 1 to 71, -1 to 99, 0 to 100)
        assertEquals(71, OpportunityConfidenceQuality.dominantBaseConfidence(votes, 1))
        assertEquals(99, OpportunityConfidenceQuality.dominantBaseConfidence(votes, -1))
        assertEquals(0, OpportunityConfidenceQuality.dominantBaseConfidence(votes, 0))
    }

    @Test
    fun dominantConfidenceClampsMalformedConfidenceValues() {
        assertEquals(100, OpportunityConfidenceQuality.dominantBaseConfidence(listOf(1 to 140), 1))
        assertEquals(0, OpportunityConfidenceQuality.dominantBaseConfidence(listOf(1 to -5), 1))
        assertEquals(0, OpportunityConfidenceQuality.dominantBaseConfidence(listOf(1 to 90), 2))
    }

}
