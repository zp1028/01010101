package com.diveintocrypto.android.domain.scanner

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class AiFusionPolicyTest {
    private fun advice(
        direction: String = "LONG",
        confidence: Int = 90,
        fakeRisk: Int = 10,
        entry: Double? = 100.1,
        stop: Double? = 99.0,
        target: Double? = 102.0,
        rr: Double? = 1.7,
    ) = AiFusionAdvice(direction, confidence, fakeRisk, entry, stop, target, rr)

    @Test fun alignedAiOnlyProvidesSmallPositiveNudge() {
        val d = AiFusionPolicy.evaluate(1, 100.0, 1.0, advice())
        assertTrue(d.delta > 0.0)
        assertTrue(d.delta <= 0.035)
        assertEquals("ALIGNED", d.status)
        assertTrue(d.acceptedPlan)
        assertEquals(1, d.finalDirection)
    }

    @Test fun conflictingAiDoesNotChangeDirectionWhenOptInOff() {
        val d = AiFusionPolicy.evaluate(
            localDirection = 1,
            localPrice = 100.0,
            atrPct = 1.0,
            advice = advice(direction = "SHORT", entry = 99.9, stop = 101.0, target = 98.0),
            allowDirectionChange = false,
        )
        assertTrue(d.delta < 0.0)
        assertEquals("CONFLICT", d.status)
        assertFalse(d.acceptedPlan)
        assertEquals(1, d.finalDirection)
        assertTrue(d.reason.contains("允许AI改方向") || d.reason.contains("保留本地方向"))
    }

    @Test fun conflictingAiCanReverseWhenOptInOn() {
        val d = AiFusionPolicy.evaluate(
            localDirection = 1,
            localPrice = 100.0,
            atrPct = 1.0,
            advice = advice(direction = "SHORT", entry = 99.9, stop = 101.0, target = 98.0),
            allowDirectionChange = true,
        )
        assertEquals("REVERSAL", d.status)
        assertTrue(d.acceptedPlan)
        assertEquals(-1, d.finalDirection)
    }

    @Test fun lowConfidenceDoesNotAffectRanking() {
        val d = AiFusionPolicy.evaluate(1, 100.0, 1.0, advice(confidence = 59))
        assertEquals(-0.01, d.delta)
        assertEquals("LOW_CONFIDENCE", d.status)
        assertEquals(1, d.finalDirection)
    }

    @Test fun distantEntryAndWrongStopAreRejected() {
        val distant = AiFusionPolicy.evaluate(1, 100.0, 1.0, advice(entry = 105.0))
        assertFalse(distant.acceptedPlan)
        val wrongStop = AiFusionPolicy.evaluate(1, 100.0, 1.0, advice(stop = 101.0))
        assertFalse(wrongStop.acceptedPlan)
    }
}
