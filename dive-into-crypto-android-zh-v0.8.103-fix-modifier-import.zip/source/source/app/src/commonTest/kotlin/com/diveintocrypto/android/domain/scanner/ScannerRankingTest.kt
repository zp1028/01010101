package com.diveintocrypto.android.domain.scanner

import com.diveintocrypto.android.domain.model.Signal
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class ScannerRankingTest {

    private fun cell(
        symbol: String,
        tf: String,
        signal: Signal,
        confidence: Int,
        price: Double = 100.0,
    ) = ScannerRanking.RankCell(
        symbol = symbol,
        timeframe = tf,
        signal = signal,
        confidence = confidence,
        finalScore = ScannerRanking.finalScore(confidence, tf),
        price = price,
    )

    @Test
    fun finalScoreMatchesLiveFormula() {
        // confidence² × weight / 100
        // 1d weight 95, conf 80 → 80*80*95/100 = 6080
        assertEquals(6080.0, ScannerRanking.finalScore(80, "1d"), 0.0)
        // 1m weight 8, conf 50 → 50*50*8/100 = 200
        assertEquals(200.0, ScannerRanking.finalScore(50, "1m"), 0.0)
        // unknown TF falls back to weight 50
        assertEquals(500.0, ScannerRanking.finalScore(100, "unknown"), 0.0)
    }

    @Test
    fun timeWeightsAndPhaseSetsMatchDocumentedLiveValues() {
        assertEquals(listOf("1d", "12h", "8h"), ScannerRanking.PHASE1_TFS)
        assertEquals(9, ScannerRanking.PHASE2_TFS.size)
        assertEquals(12, ScannerRanking.ALL_TFS.size)
        assertEquals(95, ScannerRanking.TIME_WEIGHTS.getValue("1d"))
        assertEquals(8, ScannerRanking.TIME_WEIGHTS.getValue("1m"))
        assertEquals(86_400_000L, ScannerRanking.PERIOD_MS.getValue("1d"))
    }

    @Test
    fun selectPhase2SurvivorsOrdersByPhase1ScoreSum() {
        val cells = listOf(
            cell("AAA", "1d", Signal.STRONG_BUY, 90),
            cell("AAA", "12h", Signal.BUY, 70),
            cell("BBB", "1d", Signal.BUY, 60),
            cell("CCC", "1d", Signal.SELL, 80),
            cell("CCC", "8h", Signal.SELL, 50),
            // phase-2 TF must not affect survivor selection
            cell("DDD", "15m", Signal.STRONG_BUY, 99),
        )
        val survivors = ScannerRanking.selectPhase2Survivors(cells, depth = 2)
        // AAA phase-1 sum > CCC > BBB; DDD ignored
        assertEquals(listOf("AAA", "CCC"), survivors)
    }

    @Test
    fun selectPhase2SurvivorsRespectsDepthAndEmpty() {
        assertTrue(ScannerRanking.selectPhase2Survivors(emptyList(), 10).isEmpty())
        assertTrue(ScannerRanking.selectPhase2Survivors(listOf(cell("A", "1d", Signal.BUY, 10)), 0).isEmpty())
        val one = ScannerRanking.selectPhase2Survivors(
            listOf(cell("A", "1d", Signal.BUY, 10), cell("B", "1d", Signal.BUY, 20)),
            depth = 1,
        )
        assertEquals(listOf("B"), one)
    }

    @Test
    fun perTfTopNSortsByFinalScoreThenSymbol() {
        val cells = listOf(
            cell("ZZZ", "1h", Signal.BUY, 40),
            cell("AAA", "1h", Signal.BUY, 80),
            cell("BBB", "1h", Signal.SELL, 80), // same conf → same score; symbol tie-break
            cell("CCC", "1h", Signal.BUY, 50),
            cell("AAA", "1d", Signal.BUY, 90),
        )
        val top = ScannerRanking.perTfTopN(cells, n = 2)
        assertEquals(listOf("AAA", "BBB"), top.getValue("1h").map { it.symbol })
        assertEquals(listOf("AAA"), top.getValue("1d").map { it.symbol })
    }

    @Test
    fun crossRankAggregatesBuySellNssAndSortsByNetNss() {
        val perTf = mapOf(
            "1d" to listOf(
                cell("AAA", "1d", Signal.STRONG_BUY, 80), // score 6080
                cell("BBB", "1d", Signal.SELL, 70),
            ),
            "1h" to listOf(
                cell("AAA", "1h", Signal.BUY, 60),
                cell("BBB", "1h", Signal.STRONG_SELL, 90),
            ),
        )
        val ranked = ScannerRanking.crossRank(perTf)
        assertEquals(2, ranked.size)
        // Both have directional scores; order by |buy-sell|
        assertTrue(ranked[0].netNss >= ranked[1].netNss)
        val aaa = ranked.first { it.symbol == "AAA" }
        assertEquals(Signal.BUY, aaa.dominantDir)
        assertTrue(aaa.buyNss > aaa.sellNss)
        assertEquals(2, aaa.countHit)
        val bbb = ranked.first { it.symbol == "BBB" }
        assertEquals(Signal.SELL, bbb.dominantDir)
    }

    @Test
    fun crossRankNeutralContributesHitButZeroNss() {
        val perTf = mapOf(
            "1d" to listOf(cell("NEU", "1d", Signal.NEUTRAL, 50)),
        )
        val ranked = ScannerRanking.crossRank(perTf)
        assertEquals(1, ranked.size)
        assertEquals(Signal.NEUTRAL, ranked[0].dominantDir)
        assertEquals(0.0, ranked[0].netNss)
        assertEquals(1, ranked[0].countHit)
    }

    @Test
    fun crossRankEmptyInputYieldsEmpty() {
        assertTrue(ScannerRanking.crossRank(emptyMap()).isEmpty())
    }

    @Test
    fun rankFromCellsRunsFullPipeline() {
        val cells = listOf(
            // phase 1
            cell("TOP", "1d", Signal.STRONG_BUY, 90),
            cell("TOP", "12h", Signal.BUY, 70),
            cell("MID", "1d", Signal.BUY, 50),
            cell("LOW", "1d", Signal.SELL, 20),
            // phase 2 only for survivors
            cell("TOP", "15m", Signal.BUY, 60),
            cell("MID", "15m", Signal.SELL, 55),
            cell("LOW", "15m", Signal.BUY, 99), // should not enter ranking cells for phase-2 path when depth=2
        )
        val result = ScannerRanking.rankFromCells(cells, phase2Depth = 2, perTfTopN = 15)
        assertEquals(listOf("TOP", "MID"), result.phase2Survivors)
        // LOW phase-2 cell is excluded because LOW is not a survivor; phase-1 LOW remains
        val symbolsInTop = result.perTfTop.values.flatten().map { it.symbol }.toSet()
        assertTrue("TOP" in symbolsInTop)
        assertTrue("MID" in symbolsInTop)
        assertTrue(result.crossRank.isNotEmpty())
        assertEquals("TOP", result.crossRank.first().symbol)
    }
}
