package com.diveintocrypto.android.domain.scanner

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class ForwardPlanPerformanceTest {
    private fun result(id: String, outcome: ForwardPlanReplayEvaluator.Outcome, r: Double, time: Long) =
        ForwardPlanReplayEvaluator.Result(id, outcome, time, 2, time, r, coverageStatus = "SUFFICIENT_FOR_OUTCOME")

    @Test fun openPlansAreNotCountedAsWinsOrLosses() {
        val summary = ForwardPlanPerformance.summarize(listOf(
            result("w", ForwardPlanReplayEvaluator.Outcome.TARGET_HIT, 1.5, 1),
            result("l", ForwardPlanReplayEvaluator.Outcome.STOP_HIT, -1.0, 2),
            ForwardPlanReplayEvaluator.Result("open", ForwardPlanReplayEvaluator.Outcome.OPEN, 3, 5),
        ))
        assertEquals(2, summary.sampleCount)
        assertEquals(50.0, summary.winRatePct)
        assertEquals(0.25, summary.expectancyR)
        assertEquals(1.0, summary.maxDrawdownR)
    }

    @Test fun refusesWeightApprovalWhenOutOfSampleEvidenceIsInsufficient() {
        val one = result("w", ForwardPlanReplayEvaluator.Outcome.TARGET_HIT, 1.0, 1)
        val approval = ForwardPlanPerformance.evaluateWeightApproval(listOf(one), listOf(one), minimumSamples = 2)
        assertFalse(approval.approved)
        assertTrue(approval.reason.contains("样本不足"))
    }

    @Test fun onlyPositiveOutOfSampleExpectancyCanPassBaseGate() {
        val wins = (1..3).map { result("w$it", ForwardPlanReplayEvaluator.Outcome.TARGET_HIT, 1.2, it.toLong()) }
        val losses = (1..3).map { result("l$it", ForwardPlanReplayEvaluator.Outcome.STOP_HIT, -1.0, it.toLong()) }
        assertTrue(ForwardPlanPerformance.evaluateWeightApproval(wins, wins, 3).approved)
        assertFalse(ForwardPlanPerformance.evaluateWeightApproval(wins, losses, 3).approved)
    }


    @Test fun reportExcludesUnqualifiedOutcomesAndUsesChronologicalOutOfSampleSplit() {
        fun record(id: String, time: Long, outcome: String, netR: Double, coverage: String = "SUFFICIENT_FOR_OUTCOME") =
            ForwardPlanReplayRecord(id, outcome, time, 3, time, netR, emptyList(), time, coverage)
        val report = ForwardPlanPerformance.report(listOf(
            record("late-win", 40, "TARGET_HIT", 2.0),
            record("gap-loss", 20, "STOP_HIT", -1.0, "GAP"),
            record("early-loss", 10, "STOP_HIT", -1.0),
            record("mid-win", 30, "TARGET_HIT", 1.0),
            record("open", 50, "OPEN", 9.0),
        ), trainFraction = 0.5)
        assertEquals(3, report.qualifiedCount)
        assertEquals(2, report.excludedCount)
        assertEquals(1, report.trainSummary?.sampleCount)
        assertEquals(2, report.outOfSampleSummary?.sampleCount)
        assertEquals("early-loss", report.equityCurve.first().planId)
        assertEquals(2.0 / 3.0, report.summary.expectancyR!!, 1e-9)
        assertEquals(1.0, report.summary.maxDrawdownR)
    }

    @Test fun reportDoesNotInventOutOfSampleMetricsForOneQualifiedSample() {
        val record = ForwardPlanReplayRecord("one", "TARGET_HIT", 10, 1, 10, 1.0, emptyList(), 10, "SUFFICIENT_FOR_OUTCOME")
        val report = ForwardPlanPerformance.report(listOf(record))
        assertEquals(1, report.qualifiedCount)
        assertEquals(null, report.outOfSampleSummary)
        assertTrue(report.sampleWarning != null)
    }


    @Test fun summarizeExcludesResolvedOutcomesWithUnprovenCoverage() {
        val valid = result("valid", ForwardPlanReplayEvaluator.Outcome.TARGET_HIT, 1.0, 1)
        val gap = valid.copy(planId = "gap", outcome = ForwardPlanReplayEvaluator.Outcome.STOP_HIT, grossR = -1.0, coverageStatus = "GAP")
        val summary = ForwardPlanPerformance.summarize(listOf(valid, gap))
        assertEquals(1, summary.sampleCount)
        assertEquals(1, summary.wins)
        assertEquals(0, summary.losses)
    }
}
