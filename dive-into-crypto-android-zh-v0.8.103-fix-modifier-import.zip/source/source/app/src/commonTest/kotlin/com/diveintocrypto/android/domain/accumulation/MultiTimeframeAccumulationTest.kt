package com.diveintocrypto.android.domain.accumulation

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull
import kotlin.test.assertTrue

class MultiTimeframeAccumulationTest {
    private fun result(label: AccumulationDistributionAssessment.Label, score: Int = 50) =
        AccumulationDistributionAssessment.Result(label, AccumulationDistributionAssessment.Strength.MODERATE,
            score, 2, listOf("fixture evidence"), "fixture invalidation")

    @Test fun insufficientTimeframesNeverClaimsAlignment() {
        val summary = MultiTimeframeAccumulation.summarize(listOf(
            MultiTimeframeAccumulation.TimeframeResult("1h", result(AccumulationDistributionAssessment.Label.ACCUMULATION_SIGNS))
        ))
        assertEquals(MultiTimeframeAccumulation.Alignment.INSUFFICIENT_DATA, summary.alignment)
        assertNull(summary.averageEvidenceScore)
    }

    @Test fun alignedLabelsRequireAtLeastTwoUsableTimeframes() {
        val summary = MultiTimeframeAccumulation.summarize(listOf(
            MultiTimeframeAccumulation.TimeframeResult("1h", result(AccumulationDistributionAssessment.Label.ACCUMULATION_SIGNS, 60)),
            MultiTimeframeAccumulation.TimeframeResult("4h", result(AccumulationDistributionAssessment.Label.ACCUMULATION_SIGNS, 80)),
        ))
        assertEquals(MultiTimeframeAccumulation.Alignment.BULLISH_SIGNS_ALIGNED, summary.alignment)
        assertEquals(70, summary.averageEvidenceScore)
    }

    @Test fun oppositeEvidenceIsReportedAsConflict() {
        val summary = MultiTimeframeAccumulation.summarize(listOf(
            MultiTimeframeAccumulation.TimeframeResult("1h", result(AccumulationDistributionAssessment.Label.ACCUMULATION_SIGNS)),
            MultiTimeframeAccumulation.TimeframeResult("4h", result(AccumulationDistributionAssessment.Label.DISTRIBUTION_SIGNS)),
        ))
        assertEquals(MultiTimeframeAccumulation.Alignment.CONFLICTING, summary.alignment)
        assertTrue(summary.explanation.contains("不一致"))
    }

    @Test fun higherTimeframesSortFirst() {
        val items = listOf(
            MultiTimeframeAccumulation.TimeframeResult("15m", result(AccumulationDistributionAssessment.Label.MIXED)),
            MultiTimeframeAccumulation.TimeframeResult("1d", result(AccumulationDistributionAssessment.Label.MIXED)),
            MultiTimeframeAccumulation.TimeframeResult("4h", result(AccumulationDistributionAssessment.Label.MIXED)),
        )
        assertEquals(listOf("1d", "4h", "15m"), MultiTimeframeAccumulation.ordered(items).map { it.timeframe })
    }
}
