package com.diveintocrypto.android.domain.scanner

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

class BacktestAssumptionsAndCostParityTest {

    @Test
    fun assumptionsListFundingAndLiquidationAsNotModeled() {
        assertTrue(BacktestAssumptions.notModeled.any { it.contains("Funding", ignoreCase = true) })
        assertTrue(BacktestAssumptions.notModeled.any { it.contains("liquidation", ignoreCase = true) })
        assertTrue(BacktestAssumptions.modeled.any { it.contains("Path-aware fee", ignoreCase = true) })
        val note = BacktestAssumptions.costModelNote()
        assertTrue(note.pathAware)
        assertFalse(note.includesFunding)
        assertFalse(note.includesLiquidation)
    }

    @Test
    fun eligibilityGateMatchesConsensusThresholdSemantics() {
        assertTrue(
            BacktestAssumptions.isEligibleDirectional(
                hasDirectionalSignal = true,
                confidence = 40,
                confidenceThreshold = 25,
                minConfidenceForTrade = 30,
            ),
        )
        assertFalse(
            BacktestAssumptions.isEligibleDirectional(
                hasDirectionalSignal = true,
                confidence = 28,
                confidenceThreshold = 25,
                minConfidenceForTrade = 30,
            ),
        )
        assertFalse(
            BacktestAssumptions.isEligibleDirectional(
                hasDirectionalSignal = false,
                confidence = 90,
                confidenceThreshold = 25,
                minConfidenceForTrade = 30,
            ),
        )
    }

    @Test
    fun backtesterCostMatchesRiskCostCalculatorStopAndTargetPaths() {
        val entry = 100.0
        val stop = 97.0 // 3% stop
        val target = 106.0 // 6% target
        val fee = 0.05
        val slip = 0.02
        val side = fee + slip

        val longCost = assertNotNull(
            RiskCostCalculator.estimate(
                stopDistancePct = 3.0,
                targetDistancePct = 6.0,
                feeSidePct = fee,
                slippageSidePct = slip,
                direction = RiskPlanCalculator.Direction.LONG,
            ),
        )
        // Stop path: side + side * (stop/entry) = 0.07 + 0.07 * 0.97
        val stopPathFromBacktester = RiskPlanBacktester.estimatedRoundTripCostPct(entry, stop, fee, slip)
        assertEquals(longCost.stopPathCostPct, stopPathFromBacktester, 1e-9)
        assertEquals(side + side * (stop / entry), stopPathFromBacktester, 1e-9)

        val targetPathFromBacktester = RiskPlanBacktester.estimatedRoundTripCostPct(entry, target, fee, slip)
        assertEquals(longCost.targetPathCostPct, targetPathFromBacktester, 1e-9)
        assertEquals(side + side * (target / entry), targetPathFromBacktester, 1e-9)
    }

    @Test
    fun unknownExitFallsBackToDoubleSideCost() {
        assertEquals(0.14, RiskPlanBacktester.estimatedRoundTripCostPct(100.0, null, 0.05, 0.02), 1e-9)
    }

    @Test
    fun summaryStatsDefinitionsAreStable() {
        val win = RiskPlanBacktester.TradeResult(
            setup = RiskPlanBacktester.Setup(0, RiskPlanCalculator.Direction.LONG, 100.0, 95.0, 105.0),
            exitIndex = 1,
            exitPrice = 105.0,
            reason = RiskPlanBacktester.ExitReason.TAKE_PROFIT,
            grossReturnPct = 5.0,
            estimatedCostPct = 0.14,
            netReturnPct = 4.86,
        )
        val loss = win.copy(netReturnPct = -2.0, grossReturnPct = -1.86)
        val summary = RiskPlanBacktester.summarize(listOf(win, loss))
        assertEquals(2, summary.tradeCount)
        assertEquals(2, summary.closedTradeCount)
        assertEquals(1, summary.winCount)
        assertEquals(1, summary.lossCount)
        assertEquals(50.0, summary.winRatePct!!, 1e-9)
        assertEquals(4.86 + -2.0, summary.totalNetReturnPct, 1e-9)
        // Compounded: 100 * 1.0486 * 0.98 - 100
        val expectedEquity = 100.0 * (1.0 + 4.86 / 100.0) * (1.0 - 2.0 / 100.0)
        assertEquals(expectedEquity - 100.0, summary.compoundedNetReturnPct, 1e-9)
        assertTrue(summary.maxDrawdownPct >= 0.0)
        assertNotNull(summary.profitFactor)
    }
}
