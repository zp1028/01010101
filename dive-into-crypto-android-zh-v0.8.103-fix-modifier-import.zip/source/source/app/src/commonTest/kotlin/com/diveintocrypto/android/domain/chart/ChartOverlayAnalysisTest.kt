package com.diveintocrypto.android.domain.chart

import com.diveintocrypto.android.domain.model.Candle
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull
import kotlin.test.assertTrue

class ChartOverlayAnalysisTest {
    private fun candle(i: Int, close: Double, high: Double = close + 1, low: Double = close - 1) =
        Candle(i.toLong(), close, high, low, close, 10.0, i.toLong() + 1)

    @Test fun `AVL is typical average price and aligns one to one with candles`() {
        val candles = listOf(candle(0, 10.0, high = 13.0, low = 7.0), candle(1, 20.0))
        val avl = ChartOverlayAnalysis.avl(candles)
        assertEquals(10.0, avl[0]!!, 1e-9)
        assertEquals(20.0, avl[1]!!, 1e-9)
        assertEquals(candles.size, avl.size)
    }

    @Test fun `MACD SMA uses null warmup instead of fabricated early values`() {
        val pack = ChartOverlayAnalysis.macdSma((1..40).map { it.toDouble() })
        assertNull(pack.macd[0])
        assertNull(pack.macd[24])
        assertTrue(pack.macd[25] != null)
        assertTrue(pack.hist[33] != null)
    }

    @Test fun `MACD SMA200 strategy does not emit signals without enough candles`() {
        assertTrue(ChartOverlayAnalysis.macdSma200Signals((1..220).map { candle(it, it.toDouble()) }).isEmpty())
    }
}
