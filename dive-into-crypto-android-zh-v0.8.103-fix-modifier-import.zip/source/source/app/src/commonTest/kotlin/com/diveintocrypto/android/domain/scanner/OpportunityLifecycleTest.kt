package com.diveintocrypto.android.domain.scanner

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class OpportunityLifecycleTest {
    private fun snap(symbol: String = "BTCUSDT", direction: Int = 1, price: Double = 100.0, atr: Double? = 1.0) =
        OpportunityLifecycle.Snapshot(symbol, direction, price, atr)

    @Test fun firstAppearanceIsNew() {
        assertEquals(OpportunityLifecycle.Status.NEW, OpportunityLifecycle.assess(snap(), null).status)
    }

    @Test fun directionReversalInvalidatesPriorPlan() {
        assertEquals(OpportunityLifecycle.Status.DIRECTION_REVERSED,
            OpportunityLifecycle.assess(snap(direction = -1), snap()).status)
    }

    @Test fun largePriceMoveRequiresPlanReview() {
        val result = OpportunityLifecycle.assess(snap(price = 103.0), snap())
        assertEquals(OpportunityLifecycle.Status.PRICE_MOVED, result.status)
        // 100 -> 103 is a 3% move, not 300%; this note is shown to users.
        assertTrue(result.note.contains("3.0%"))
        assertTrue(!result.note.contains("300.0%"))
    }

    @Test fun smallMoveRemainsActive() {
        assertEquals(OpportunityLifecycle.Status.ACTIVE,
            OpportunityLifecycle.assess(snap(price = 100.2), snap()).status)
    }

    @Test fun directionReversalCanBeReassessedAgainstTheNewCompletedBaseline() {
        val reversed = snap(direction = -1, price = 100.2)
        assertEquals(OpportunityLifecycle.Status.DIRECTION_REVERSED,
            OpportunityLifecycle.assess(reversed, snap(direction = 1)).status)
        // Once the reversed direction is itself part of a completed scan, the next
        // scan can assess a fresh plan against that new direction rather than retaining
        // a permanent reversal lock.
        assertEquals(OpportunityLifecycle.Status.ACTIVE,
            OpportunityLifecycle.assess(snap(direction = -1, price = 100.3), reversed).status)
    }

    @Test fun partialScanMustNotPromoteItsRowsToTheTrustedBaseline() {
        val prior = listOf(snap(direction = 1, price = 100.0))
        val partialRows = listOf(snap(direction = -1, price = 100.2))
        val summary = OpportunityLifecycle.summarize(partialRows, prior, scanComplete = false)
        assertEquals(OpportunityLifecycle.Status.DIRECTION_REVERSED,
            OpportunityLifecycle.assess(partialRows.single(), prior.single()).status)
        assertEquals(false, summary.coverageComplete)
        assertEquals(0, summary.disappearedCount)
        // Caller must retain `prior` as baseline because the scan did not complete.
        assertEquals(OpportunityLifecycle.Status.DIRECTION_REVERSED,
            OpportunityLifecycle.assess(snap(direction = -1, price = 100.3), prior.single()).status)
    }

    @Test fun invalidPriceIsFlagged() {
        assertEquals(OpportunityLifecycle.Status.DATA_INVALID,
            OpportunityLifecycle.assess(snap(price = Double.NaN), snap()).status)
    }

    @Test fun summaryCountsDisappearedSymbols() {
        val summary = OpportunityLifecycle.summarize(listOf(snap()), listOf(snap(), snap("ETHUSDT")))
        assertEquals(1, summary.activeCount)
        assertEquals(1, summary.disappearedCount)
    }

    @Test fun summaryNormalizesSymbolsAndAvoidsDuplicateCounting() {
        val summary = OpportunityLifecycle.summarize(
            listOf(snap(" btcusdt "), snap("BTCUSDT", price = 100.1)),
            listOf(snap("BTCUSDT"), snap(" ethusdt "))
        )
        assertEquals(1, summary.activeCount)
        assertEquals(1, summary.disappearedCount)
    }

    @Test fun partialScanDoesNotCountMissingSymbolsAsDisappeared() {
        val summary = OpportunityLifecycle.summarize(
            current = listOf(snap()),
            previous = listOf(snap(), snap("ETHUSDT")),
            scanComplete = false,
        )
        assertEquals(0, summary.disappearedCount)
        assertEquals(false, summary.coverageComplete)
    }

    @Test fun completedScanCanCountDisappearedSymbols() {
        val summary = OpportunityLifecycle.summarize(
            current = listOf(snap()),
            previous = listOf(snap(), snap("ETHUSDT")),
            scanComplete = true,
        )
        assertEquals(1, summary.disappearedCount)
        assertEquals(true, summary.coverageComplete)
    }

    @Test fun invalidPreviousPriceDoesNotMasqueradeAsReversal() {
        val result = OpportunityLifecycle.assess(
            snap(direction = -1), snap(direction = 1, price = Double.NaN)
        )
        assertEquals(OpportunityLifecycle.Status.DATA_INVALID, result.status)
    }

    @Test fun previousSnapshotMustReferToSameNormalizedSymbol() {
        val result = OpportunityLifecycle.assess(
            snap(symbol = "ETHUSDT"), snap(symbol = "BTCUSDT")
        )
        assertEquals(OpportunityLifecycle.Status.DATA_INVALID, result.status)
    }

    @Test fun blankSymbolIsInvalid() {
        assertEquals(OpportunityLifecycle.Status.DATA_INVALID,
            OpportunityLifecycle.assess(snap(symbol = " "), null).status)
    }
}
