package com.diveintocrypto.android.domain.accumulation

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class AccumulationDistributionAssessmentTest {
    @Test fun insufficientCandlesNeverCreatesSignal() {
        val result = AccumulationDistributionAssessment.assess(
            AccumulationDistributionAssessment.Input(List(4) { 2.0 }, List(4) { 1.0 }, List(4) { 1.5 }, List(4) { 100.0 })
        )
        assertEquals(AccumulationDistributionAssessment.Label.INSUFFICIENT_DATA, result.label)
        assertEquals(0, result.evidenceScore)
    }

    @Test fun invalidMarketDataIsRejected() {
        val result = AccumulationDistributionAssessment.assess(
            AccumulationDistributionAssessment.Input(List(25) { 2.0 }, List(25) { 1.0 }, List(25) { if (it == 4) Double.NaN else 1.5 }, List(25) { 100.0 })
        )
        assertEquals(AccumulationDistributionAssessment.Label.INSUFFICIENT_DATA, result.label)
    }

    @Test fun evidenceScoreIsNotProbabilityAndBounded() {
        val close = (0 until 25).map { 100.0 - it * 2.0 }
        val result = AccumulationDistributionAssessment.assess(
            AccumulationDistributionAssessment.Input(
                high = close.map { it + 1.0 }, low = close.map { it - 1.0 }, close = close,
                volume = List(25) { 1000.0 }
            )
        )
        assertTrue(result.evidenceScore in 0..100)
        assertTrue(!result.reasons.any { it.contains("概率") })
    }
}
