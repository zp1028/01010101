package com.diveintocrypto.android.domain.analysis

import com.diveintocrypto.android.domain.model.Signal
import com.diveintocrypto.android.domain.scanner.RiskPlanCalculator
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

class AnalysisExplainTest {
    private val snap = AnalysisExplain.Snapshot(
        symbol = "BTCUSDT",
        timeframe = "15m",
        signal = Signal.BUY,
        confidence = 62,
        shouldTrade = true,
        entry = 100.0,
        plan = RiskPlanCalculator.Plan(
            entry = 100.0,
            stopLoss = 97.0,
            takeProfit = 106.0,
            riskPerUnit = 3.0,
            rewardPerUnit = 6.0,
            riskRewardRatio = 2.0,
            stopDistancePercent = 3.0,
        ),
        direction = RiskPlanCalculator.Direction.LONG,
        patternName = "V形反转底",
        support = 95.0,
        resistance = 110.0,
        stopSource = "结构+ATR",
        livePrice = 101.0,
    )

    @Test
    fun answersStayBoundToSnapshot() {
        val dir = AnalysisExplain.answer("为什么是这个方向？", snap)
        assertTrue(dir.contains("62") && dir.contains("偏多"))
        val plan = AnalysisExplain.answer("止损止盈怎么来的？", snap)
        assertTrue(plan.contains("止损"))
        val levels = AnalysisExplain.answer("支撑阻力在哪？", snap)
        assertTrue(levels.contains("支撑"))
        val pattern = AnalysisExplain.answer("形态说明了什么？", snap)
        assertTrue(pattern.contains("V形"))
    }

    @Test
    fun structureStopPicksSupportForLong() {
        val s = AnalysisStructurePlan.structureStopForDirection(
            RiskPlanCalculator.Direction.LONG, support = 90.0, resistance = 120.0,
        )
        assertEquals(90.0, s)
        val res = AnalysisStructurePlan.calculate(
            RiskPlanCalculator.Direction.LONG, 100.0, 2.0, 2.0, structureStop = 90.0,
        )
        assertNotNull(res.plan)
    }
}
