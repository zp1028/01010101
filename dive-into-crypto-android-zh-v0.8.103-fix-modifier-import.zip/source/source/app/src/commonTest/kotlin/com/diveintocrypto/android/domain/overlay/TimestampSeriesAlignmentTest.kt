package com.diveintocrypto.android.domain.overlay

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class TimestampSeriesAlignmentTest {
    private val hour = 3_600_000L

    @Test
    fun onlyPairsMatchingBucketsAndPreservesGaps() {
        val result = TimestampSeriesAlignment.align(
            left = listOf(0L to 10.0, hour to 11.0, 3 * hour to 13.0),
            right = listOf(0L to 100.0, 2 * hour to 102.0, 3 * hour to 103.0),
            bucketMillis = hour,
        )
        assertEquals(listOf(0L, 3 * hour), result.timestamps)
        assertEquals(listOf(10.0, 13.0), result.left)
        assertEquals(listOf(100.0, 103.0), result.right)
        assertEquals(result.timestamps.size, result.left.size)
        assertEquals(result.left.size, result.right.size)
    }

    @Test
    fun lastValidObservationWinsWithinBucket() {
        val result = TimestampSeriesAlignment.align(
            left = listOf(100L to 1.0, 200L to 2.0, 300L to Double.NaN),
            right = listOf(150L to 5.0),
            bucketMillis = hour,
        )
        assertEquals(listOf(0L), result.timestamps)
        assertEquals(listOf(2.0), result.left)
        assertEquals(listOf(5.0), result.right)
    }

    @Test
    fun invalidBucketAndInvalidOnlyInputsAreSafe() {
        assertTrue(TimestampSeriesAlignment.align(listOf(0L to 1.0), listOf(0L to 2.0), 0L).timestamps.isEmpty())
        assertTrue(
            TimestampSeriesAlignment.align(
                left = listOf(-1L to 1.0, 0L to Double.POSITIVE_INFINITY),
                right = listOf(0L to 2.0),
                bucketMillis = hour,
            ).timestamps.isEmpty()
        )
    }
}
