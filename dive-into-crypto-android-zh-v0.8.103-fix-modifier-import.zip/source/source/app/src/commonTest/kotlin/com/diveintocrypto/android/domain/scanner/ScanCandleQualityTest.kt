package com.diveintocrypto.android.domain.scanner

import com.diveintocrypto.android.domain.model.Candle
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue
import kotlin.test.assertFalse

class ScanCandleQualityTest {
    private fun candles(now: Long, count: Int = 60): List<Candle> = (0 until count).map { i ->
        val openTime = now - (count - 1 - i) * 60_000L
        Candle(openTime, 100.0, 102.0, 99.0, 101.0, 10.0, openTime + 59_999L)
    }

    @Test fun acceptsFreshOrderedCandles() {
        assertTrue(ScanCandleQuality.validate(candles(10_000_000L), 60_000L, 10_000_000L).valid)
    }

    @Test fun rejectsDuplicateOrUnorderedTimestamps() {
        val source = candles(10_000_000L).toMutableList()
        source[20] = source[19]
        assertEquals("unordered_or_duplicate_timestamps", ScanCandleQuality.validate(source, 60_000L, 10_000_000L).reason)
    }

    @Test fun rejectsStaleLatestCandle() {
        assertEquals("stale_latest_candle", ScanCandleQuality.validate(candles(10_000_000L), 60_000L, 20_000_000L).reason)
    }

    @Test fun rejectsInvalidOhlc() {
        val source = candles(10_000_000L).toMutableList()
        source[source.lastIndex] = source.last().copy(high = 98.0)
        assertFalse(ScanCandleQuality.validate(source, 60_000L, 10_000_000L).valid)
    }
}
