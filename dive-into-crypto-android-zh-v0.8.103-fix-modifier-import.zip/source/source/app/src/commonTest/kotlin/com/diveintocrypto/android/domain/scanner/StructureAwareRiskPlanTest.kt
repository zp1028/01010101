package com.diveintocrypto.android.domain.scanner

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

class StructureAwareRiskPlanTest {
    @Test fun longStopUsesTheMoreProtectiveDistanceBeyondSupport() {
        val result = StructureAwareRiskPlan.calculate(
            StructureAwareRiskPlan.Inputs(RiskPlanCalculator.Direction.LONG, 100.0, 2.0, 1.5, 2.0, structureStop = 97.0, structureBufferAtr = 0.25),
        )
        val plan = assertNotNull(result.plan)
        assertEquals(96.5, plan.stopLoss, 1e-9)
        assertEquals(107.0, plan.takeProfit, 1e-9)
        assertEquals(2.0, plan.riskRewardRatio, 1e-9)
        assertEquals(StructureAwareRiskPlan.StopSource.STRUCTURE_AND_ATR, result.stopSource)
    }

    @Test fun shortStopUsesResistancePlusBufferWhenFartherThanAtrStop() {
        val result = StructureAwareRiskPlan.calculate(
            StructureAwareRiskPlan.Inputs(RiskPlanCalculator.Direction.SHORT, 100.0, 2.0, 1.5, 2.0, structureStop = 104.0, structureBufferAtr = 0.25),
        )
        val plan = assertNotNull(result.plan)
        assertEquals(104.5, plan.stopLoss, 1e-9)
        assertEquals(91.0, plan.takeProfit, 1e-9)
    }

    @Test fun missingStructureFallsBackToAtrOnly() {
        val result = StructureAwareRiskPlan.calculate(
            StructureAwareRiskPlan.Inputs(RiskPlanCalculator.Direction.LONG, 100.0, 2.0, 1.5, 2.0),
        )
        assertEquals(StructureAwareRiskPlan.StopSource.ATR_ONLY, result.stopSource)
        assertEquals(97.0, assertNotNull(result.plan).stopLoss, 1e-9)
    }

    @Test fun invalidStructureFallsBackToAtrOnly() {
        val result = StructureAwareRiskPlan.calculate(
            StructureAwareRiskPlan.Inputs(RiskPlanCalculator.Direction.LONG, 100.0, 2.0, 1.5, 2.0, structureStop = Double.NaN),
        )
        assertTrue(result.valid)
        assertEquals(StructureAwareRiskPlan.StopSource.ATR_ONLY, result.stopSource)
        assertEquals(97.0, assertNotNull(result.plan).stopLoss, 1e-9)
    }

    @Test fun structureOnWrongSideOfEntryFallsBackToAtrOnlyForBothDirections() {
        val longResult = StructureAwareRiskPlan.calculate(
            StructureAwareRiskPlan.Inputs(RiskPlanCalculator.Direction.LONG, 100.0, 2.0, 1.5, 2.0, structureStop = 105.0),
        )
        assertEquals(StructureAwareRiskPlan.StopSource.ATR_ONLY, longResult.stopSource)
        assertEquals(97.0, assertNotNull(longResult.plan).stopLoss, 1e-9)

        val shortResult = StructureAwareRiskPlan.calculate(
            StructureAwareRiskPlan.Inputs(RiskPlanCalculator.Direction.SHORT, 100.0, 2.0, 1.5, 2.0, structureStop = 95.0),
        )
        assertEquals(StructureAwareRiskPlan.StopSource.ATR_ONLY, shortResult.stopSource)
        assertEquals(103.0, assertNotNull(shortResult.plan).stopLoss, 1e-9)
    }
}
