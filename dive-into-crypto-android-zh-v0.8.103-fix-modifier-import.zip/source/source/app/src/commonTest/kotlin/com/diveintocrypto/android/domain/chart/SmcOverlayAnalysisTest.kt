package com.diveintocrypto.android.domain.chart

import com.diveintocrypto.android.domain.model.Candle
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

class SmcOverlayAnalysisTest {
    private fun candles(highs: List<Double>, lows: List<Double>): List<Candle> = highs.indices.map { i ->
        val close = (highs[i] + lows[i]) / 2.0
        Candle(i.toLong(), close, highs[i], lows[i], close, 100.0, i.toLong() + 1)
    }

    @Test fun `equal highs and equal lows cluster into liquidity levels`() {
        val input = candles(
            highs = listOf(10.0, 12.0, 10.0, 11.0, 10.0, 12.01, 10.0, 11.0, 10.0),
            lows = listOf(6.0, 7.0, 5.0, 6.0, 5.0, 7.0, 5.01, 6.0, 5.0),
        )
        val levels = SmcOverlayAnalysis.equalLiquidityLevels(input, leftRight = 1)
        assertTrue(levels.any { it.isHigh && it.touches >= 2 && it.price in 12.0..12.01 })
        assertTrue(levels.any { !it.isHigh && it.touches >= 2 && it.price in 5.0..5.01 })
    }

    @Test fun `premium discount range uses valid swing extremes`() {
        val input = candles(
            highs = listOf(10.0, 12.0, 10.0, 11.0, 10.0, 13.0, 10.0, 9.0, 10.0),
            lows = listOf(6.0, 7.0, 5.0, 6.0, 4.0, 7.0, 7.0, 6.0, 5.0),
        )
        val range = SmcOverlayAnalysis.premiumDiscountRange(input, leftRight = 1)
        assertNotNull(range)
        assertEquals(4.0, range.low)
        assertEquals(13.0, range.high)
        assertEquals(8.5, range.equilibrium)
    }

    @Test fun `insufficient history does not fabricate a range`() {
        assertNull(SmcOverlayAnalysis.premiumDiscountRange(emptyList()))
        assertTrue(SmcOverlayAnalysis.equalLiquidityLevels(emptyList()).isEmpty())
    }
}
