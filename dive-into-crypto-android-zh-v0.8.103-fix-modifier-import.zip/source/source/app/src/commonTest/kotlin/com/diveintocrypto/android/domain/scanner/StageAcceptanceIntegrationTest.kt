package com.diveintocrypto.android.domain.scanner

import com.diveintocrypto.android.domain.model.Signal
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

/**
 * Cross-stage acceptance scenarios that do not require a device or network.
 * Maps to the four-phase checklist: lifecycle gates, plan consistency,
 * risk sizing, ranking parity, and causal replay boundaries.
 */
class StageAcceptanceIntegrationTest {

    // ── Stage 1: freshness + recovery (行情可用/不可用时计划是否展示) ─────────

    @Test
    fun stage1_staleMarketBlocksRiskPlanDisplay() {
        val recovery = RiskPlanRecoveryPolicy.evaluate(
            freshness = MarketDataFreshness.Status.STALE,
            lifecycleStatus = "ACTIVE",
            eligibilityStatus = "ELIGIBLE",
            blockedByMtfConflict = false,
        )
        assertEquals(RiskPlanRecoveryPolicy.State.WAIT_FOR_FRESH_DATA, recovery.state)
        assertFalse(recovery.allowReferenceLevels)
    }

    @Test
    fun stage1_freshEligibleAllowsRecalculateNotRestore() {
        val recovery = RiskPlanRecoveryPolicy.evaluate(
            freshness = MarketDataFreshness.Status.FRESH,
            lifecycleStatus = "ACTIVE",
            eligibilityStatus = "ELIGIBLE",
            blockedByMtfConflict = false,
        )
        assertEquals(RiskPlanRecoveryPolicy.State.READY_TO_RECALCULATE, recovery.state)
        assertTrue(recovery.allowReferenceLevels)
        assertTrue(recovery.message.contains("重新计算") || recovery.message.contains("当前数据"))
    }

    // ── Stage 2: eligibility + structure-aware plan levels ───────────────────

    @Test
    fun stage2_mtfConflictSuppressesDirectionalPlan() {
        val elig = RiskPlanEligibility.evaluate(Signal.STRONG_BUY, mtfDirection = -1)
        assertEquals(RiskPlanEligibility.Status.MTF_CONFLICT, elig.status)
        val recovery = RiskPlanRecoveryPolicy.evaluate(
            MarketDataFreshness.Status.FRESH, "ACTIVE", "MTF_CONFLICT", true,
        )
        assertFalse(recovery.allowReferenceLevels)
    }

    @Test
    fun stage2_atrPlanMatchesDisplayedStopTargetMath() {
        val plan = assertNotNull(
            RiskPlanCalculator.calculate(
                RiskPlanCalculator.Direction.LONG,
                entry = 50_000.0,
                atr = 500.0,
                atrMultiplier = 1.5,
                targetR = 2.0,
            ).plan,
        )
        assertEquals(50_000.0 - 750.0, plan.stopLoss, 1e-6)
        assertEquals(50_000.0 + 1_500.0, plan.takeProfit, 1e-6)
        assertEquals(2.0, plan.riskRewardRatio, 1e-9)
    }

    // ── Stage 3: cost + position sizing + backtest stats one chain ───────────

    @Test
    fun stage3_cardValuesMatchCalculatorChain() {
        val entry = 100.0
        val plan = assertNotNull(
            RiskPlanCalculator.calculate(
                RiskPlanCalculator.Direction.LONG, entry, atr = 2.0, atrMultiplier = 1.5, targetR = 2.0,
            ).plan,
        )
        val stopPct = plan.stopDistancePercent
        val targetPct = kotlin.math.abs(plan.takeProfit - entry) / entry * 100.0
        val cost = assertNotNull(
            RiskCostCalculator.estimate(stopPct, targetPct, 0.05, 0.02, RiskPlanCalculator.Direction.LONG),
        )
        val pos = assertNotNull(
            PositionRiskCalculator.calculate(
                equity = 10_000.0,
                riskPct = 1.0,
                entryPrice = entry,
                stopPrice = plan.stopLoss,
                leverage = 5.0,
                stopPathCostPct = cost.stopPathCostPct,
            ),
        )
        assertEquals(cost.stopPathCostPct, pos.estimatedCostPct, 1e-9)
        assertEquals(100.0, pos.riskBudget, 1e-9)
        assertEquals(pos.riskBudget, pos.estimatedStopLoss, 1e-6)

        val candles = listOf(
            RiskPlanBacktester.Candle(0L, 101.0, 99.0, 100.0, 100.0),
            RiskPlanBacktester.Candle(1L, 106.0, 100.0, 105.0, 101.0),
        )
        val trade = RiskPlanBacktester.simulate(
            candles,
            RiskPlanBacktester.Setup(0, RiskPlanCalculator.Direction.LONG, entry, plan.stopLoss, plan.takeProfit),
            0.05,
            0.02,
        )
        assertEquals(RiskPlanBacktester.ExitReason.TAKE_PROFIT, trade.reason)
        val summary = RiskPlanBacktester.summarize(listOf(trade))
        assertEquals(1, summary.closedTradeCount)
        assertEquals(trade.netReturnPct!!, summary.totalNetReturnPct, 1e-9)
    }

    // ── Stage 4: ranking parity + causal boundaries ─────────────────────────

    @Test
    fun stage4_rankingMathIsSharedAndCausalReplayRejectsLeakage() {
        val conf = 80
        assertEquals(
            ScannerRanking.finalScore(conf, "1d"),
            (conf * conf * 95.0) / 100.0,
            0.0,
        )
        val cells = listOf(
            ScannerRanking.RankCell("AAA", "1d", Signal.STRONG_BUY, 90, ScannerRanking.finalScore(90, "1d")),
            ScannerRanking.RankCell("BBB", "1d", Signal.BUY, 40, ScannerRanking.finalScore(40, "1d")),
        )
        val survivors = ScannerRanking.selectPhase2Survivors(cells, depth = 1)
        assertEquals(listOf("AAA"), survivors)

        val cut = 1_000_000L
        // Future cell must throw
        try {
            HistoricalScannerReplay.rankAtCut(
                HistoricalScannerReplay.ReplayInput(
                    cutTimeMs = cut,
                    cells = listOf(
                        HistoricalScannerReplay.CausalCell(
                            "AAA", "1d", Signal.BUY, 50, 100.0, lastCandleOpenTimeMs = cut,
                        ),
                    ),
                    phase2Depth = 5,
                ),
            )
            assertTrue(false, "expected causal violation")
        } catch (_: IllegalArgumentException) {
            // expected
        }

        val report = HistoricalScannerReplay.rankAtCut(
            HistoricalScannerReplay.ReplayInput(
                cutTimeMs = cut,
                cells = listOf(
                    HistoricalScannerReplay.CausalCell(
                        "AAA", "1d", Signal.BUY, 50, 100.0, lastCandleOpenTimeMs = cut - 1,
                    ),
                ),
                phase2Depth = 5,
                universeAtCut = null,
                auxiliaryDataMissing = true,
            ),
        )
        assertTrue(report.missingUniverseRanking)
        assertTrue(report.missingAuxiliaryData)
        assertTrue(report.limitations.isNotEmpty())
    }

    @Test
    fun stage4_assumptionsDocumentArchiveAndFundingGaps() {
        assertTrue(BacktestAssumptions.notModeled.any { it.contains("quote-volume", ignoreCase = true) || it.contains("universe", ignoreCase = true) })
        assertTrue(BacktestAssumptions.notModeled.any { it.contains("Funding", ignoreCase = true) })
        assertTrue(BacktestAssumptions.notModeled.any { it.contains("Whale", ignoreCase = true) || it.contains("whale", ignoreCase = true) })
    }
}
