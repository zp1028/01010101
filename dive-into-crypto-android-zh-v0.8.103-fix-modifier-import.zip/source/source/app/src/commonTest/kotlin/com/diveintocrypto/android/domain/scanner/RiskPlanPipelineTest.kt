package com.diveintocrypto.android.domain.scanner

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

/**
 * End-to-end consistency across the risk-plan stack used by cards and backtest:
 * ATR plan → cost estimate → position sizing → simulated trade → summary stats.
 *
 * Guarantees display-facing numbers (stop, target, risk budget, costs, net return)
 * come from the same pure calculators rather than divergent UI formulas.
 */
class RiskPlanPipelineTest {

    @Test
    fun atrPlanCostAndPositionSizingAgreeOnStopPathRisk() {
        val entry = 100.0
        val atr = 2.0
        val atrMult = 1.5
        val targetR = 2.0
        val fee = 0.05
        val slip = 0.02
        val equity = 10_000.0
        val riskPct = 1.0
        val leverage = 5.0

        val plan = assertNotNull(
            RiskPlanCalculator.calculate(
                RiskPlanCalculator.Direction.LONG,
                entry,
                atr,
                atrMultiplier = atrMult,
                targetR = targetR,
            ).plan,
        )
        assertEquals(entry - atr * atrMult, plan.stopLoss, 1e-9)
        assertEquals(entry + atr * atrMult * targetR, plan.takeProfit, 1e-9)
        assertEquals(targetR, plan.riskRewardRatio, 1e-9)

        val stopDistPct = plan.stopDistancePercent
        val targetDistPct = kotlin.math.abs(plan.takeProfit - entry) / entry * 100.0
        val cost = assertNotNull(
            RiskCostCalculator.estimate(
                stopDistancePct = stopDistPct,
                targetDistancePct = targetDistPct,
                feeSidePct = fee,
                slippageSidePct = slip,
                direction = RiskPlanCalculator.Direction.LONG,
            ),
        )
        // Position sizing must use stop-path cost (not the larger target-path cost)
        // so estimatedStopLoss matches the stop-exit scenario shown on the card.
        val position = assertNotNull(
            PositionRiskCalculator.calculate(
                equity = equity,
                riskPct = riskPct,
                entryPrice = entry,
                stopPrice = plan.stopLoss,
                leverage = leverage,
                stopPathCostPct = cost.stopPathCostPct,
            ),
        )
        assertEquals(cost.stopPathCostPct, position.estimatedCostPct, 1e-9)
        assertEquals(equity * riskPct / 100.0, position.riskBudget, 1e-9)
        // estimatedStopLoss ≈ notional × (stop% + stopPathCost%)/100 ≈ riskBudget
        assertEquals(position.riskBudget, position.estimatedStopLoss, 1e-6)
        assertTrue(position.maxNotional > 0.0)
        assertTrue(position.requiredInitialMargin < equity)
    }

    @Test
    fun backtestSummaryMatchesSimulatedTradeNetReturns() {
        val candles = listOf(
            RiskPlanBacktester.Candle(0L, 101.0, 99.0, 100.0, 100.0),
            RiskPlanBacktester.Candle(1L, 106.0, 100.0, 105.0, 101.0), // hits target 105
        )
        val setup = RiskPlanBacktester.Setup(
            entryIndex = 0,
            direction = RiskPlanCalculator.Direction.LONG,
            entryPrice = 100.0,
            stopLoss = 95.0,
            takeProfit = 105.0,
        )
        val trade = RiskPlanBacktester.simulate(candles, setup, feeSidePct = 0.05, slippageSidePct = 0.02)
        assertEquals(RiskPlanBacktester.ExitReason.TAKE_PROFIT, trade.reason)
        assertNotNull(trade.netReturnPct)

        val summary = RiskPlanBacktester.summarize(listOf(trade))
        assertEquals(1, summary.tradeCount)
        assertEquals(1, summary.winCount)
        assertEquals(0, summary.lossCount)
        assertEquals(100.0, summary.winRatePct!!, 1e-9)
        assertEquals(trade.netReturnPct!!, summary.totalNetReturnPct, 1e-9)
        assertEquals(trade.netReturnPct!!, summary.averageNetReturnPct!!, 1e-9)
        // Compounded on initial equity 100: 100 * (1 + r/100) - 100
        val expectedCompounded = 100.0 * (1.0 + trade.netReturnPct!! / 100.0) - 100.0
        assertEquals(expectedCompounded, summary.compoundedNetReturnPct, 1e-9)
        assertTrue(summary.maxDrawdownPct >= 0.0)
    }

    @Test
    fun atrPlanThenBacktestUsesSameStopAndTargetLevels() {
        val entry = 200.0
        val atr = 4.0
        val plan = assertNotNull(
            RiskPlanCalculator.calculate(
                RiskPlanCalculator.Direction.SHORT,
                entry,
                atr,
                atrMultiplier = 1.5,
                targetR = 2.0,
            ).plan,
        )
        // Entry at bar 0 open; signal known at prior close — simulator uses setup prices as-is.
        val candles = listOf(
            RiskPlanBacktester.Candle(0L, 201.0, 199.0, 200.0, 200.0),
            // Gap through stop on open for short (price up)
            RiskPlanBacktester.Candle(1L, 210.0, 205.0, 208.0, 206.5),
        )
        val setup = RiskPlanBacktester.Setup(
            entryIndex = 0,
            direction = RiskPlanCalculator.Direction.SHORT,
            entryPrice = entry,
            stopLoss = plan.stopLoss,
            takeProfit = plan.takeProfit,
        )
        val trade = RiskPlanBacktester.simulate(candles, setup, feeSidePct = 0.0, slippageSidePct = 0.0)
        assertEquals(RiskPlanBacktester.ExitReason.STOP_LOSS, trade.reason)
        // Gap open beyond stop → fill at open, not at stop (conservative gap handling)
        assertEquals(206.5, trade.exitPrice!!, 1e-9)
        assertTrue(trade.netReturnPct!! < 0.0)
    }

    @Test
    fun pipelineRejectsInvalidChainsConsistently() {
        assertTrue(
            RiskPlanCalculator.calculate(
                RiskPlanCalculator.Direction.LONG,
                entry = 100.0,
                atr = 0.0,
            ).plan == null,
        )
        assertEquals(
            null,
            RiskCostCalculator.estimate(-1.0, 2.0, 0.05, 0.02),
        )
        assertEquals(
            null,
            PositionRiskCalculator.calculate(100.0, 1.0, 100.0, 100.0, 5.0),
        )
    }
}
