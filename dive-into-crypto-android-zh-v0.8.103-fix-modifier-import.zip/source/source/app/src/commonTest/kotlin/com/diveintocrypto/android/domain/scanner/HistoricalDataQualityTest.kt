package com.diveintocrypto.android.domain.scanner

import com.diveintocrypto.android.domain.model.Candle
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

class HistoricalDataQualityTest {
    private fun candle(openTime: Long) = Candle(
        openTime = openTime, open = 100.0, high = 102.0, low = 98.0,
        close = 101.0, volume = 1.0, closeTime = openTime + 899_999L,
    )

    @Test
    fun reportsCompleteCoverageWhenBarsAreContiguous() {
        val report = HistoricalDataQuality.analyze(listOf(candle(0), candle(900_000), candle(1_800_000)), "15m")
        assertEquals(3, report.candleCount)
        assertEquals(0, report.discardedCandles)
        assertEquals(3, report.expectedSlots)
        assertEquals(0, report.missingIntervals)
        assertEquals(0, report.largestGapBars)
        assertEquals(0, report.irregularIntervals)
        assertEquals(100.0, report.coveragePercent)
    }

    @Test
    fun reportsMissingBarsAndLargestGap() {
        val report = HistoricalDataQuality.analyze(
            listOf(candle(0), candle(900_000), candle(3_600_000), candle(4_500_000)), "15m",
        )
        assertEquals(4, report.candleCount)
        assertEquals(0, report.discardedCandles)
        assertEquals(6, report.expectedSlots)
        assertEquals(2, report.missingIntervals)
        assertEquals(2, report.largestGapBars)
        assertEquals(0, report.irregularIntervals)
        assertEquals(66.66666666666666, report.coveragePercent!!, 0.000001)
    }

    @Test
    fun reportsMalformedCandlesDiscardedDuringSanitation() {
        val malformed = Candle(
            openTime = 1_800_000, open = 100.0, high = 99.0, low = 98.0,
            close = 100.0, volume = 1.0, closeTime = 2_699_999,
        )
        val report = HistoricalDataQuality.analyze(listOf(candle(0), candle(900_000), malformed), "15m")
        assertEquals(2, report.candleCount)
        assertEquals(1, report.discardedCandles)
        assertEquals(0, report.missingIntervals)
    }

    @Test
    fun reportsNegativeOrNonFiniteVolumeBarsAsDiscarded() {
        val negativeVolume = candle(900_000).copy(volume = -0.5)
        val nonFiniteVolume = candle(1_800_000).copy(volume = Double.POSITIVE_INFINITY)
        val zeroVolume = candle(2_700_000).copy(volume = 0.0)

        val report = HistoricalDataQuality.analyze(
            listOf(candle(0), negativeVolume, nonFiniteVolume, zeroVolume), "15m",
        )

        assertEquals(2, report.candleCount)
        assertEquals(2, report.discardedCandles)
        assertEquals(0, report.missingIntervals)
    }

    @Test
    fun flagsOffGridTimestampDeltasInsteadOfHidingThemByRounding() {
        val report = HistoricalDataQuality.analyze(
            listOf(candle(0), candle(1_260_000), candle(2_160_000)), "15m",
        )
        assertEquals(1, report.irregularIntervals)
        // The gap estimate is still explicit, but the irregularity is separately surfaced.
        assertEquals(0, report.missingIntervals)
    }

    @Test
    fun sanitizesDuplicatesAndRejectsUnsupportedTimeframesGracefully() {
        val duplicate = HistoricalDataQuality.analyze(listOf(candle(0), candle(0), candle(900_000)), "15m")
        assertEquals(2, duplicate.candleCount)
        assertEquals(1, duplicate.discardedCandles)
        assertEquals(0, duplicate.missingIntervals)
        assertEquals(0, duplicate.irregularIntervals)
        assertNull(HistoricalDataQuality.analyze(emptyList(), "1d").coveragePercent)
    }
}
