package com.diveintocrypto.android.domain.scanner

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class RiskPlanRecoveryPolicyTest {
    @Test fun freshDataDoesNotReviveReversedDirection() {
        val result = RiskPlanRecoveryPolicy.evaluate(
            MarketDataFreshness.Status.FRESH, "DIRECTION_REVERSED", "ELIGIBLE", false
        )
        assertEquals(RiskPlanRecoveryPolicy.State.DIRECTION_REVERSED, result.state)
        assertFalse(result.allowReferenceLevels)
    }

    @Test fun freshDataDoesNotRevivePriceMovedPlan() {
        val result = RiskPlanRecoveryPolicy.evaluate(
            MarketDataFreshness.Status.FRESH, "PRICE_MOVED", "ELIGIBLE", false
        )
        assertEquals(RiskPlanRecoveryPolicy.State.RECOMPUTE_REQUIRED, result.state)
        assertFalse(result.allowReferenceLevels)
    }

    @Test fun freshDataStillBlocksMtfConflict() {
        val result = RiskPlanRecoveryPolicy.evaluate(
            MarketDataFreshness.Status.FRESH, "ACTIVE", "MTF_CONFLICT", true
        )
        assertEquals(RiskPlanRecoveryPolicy.State.MTF_CONFLICT, result.state)
        assertFalse(result.allowReferenceLevels)
    }

    @Test fun staleDataAlwaysBlocksPlan() {
        val result = RiskPlanRecoveryPolicy.evaluate(
            MarketDataFreshness.Status.STALE, "ACTIVE", "ELIGIBLE", false
        )
        assertEquals(RiskPlanRecoveryPolicy.State.WAIT_FOR_FRESH_DATA, result.state)
        assertFalse(result.allowReferenceLevels)
    }

    @Test fun unknownLifecycleStatusFailsClosed() {
        val result = RiskPlanRecoveryPolicy.evaluate(
            MarketDataFreshness.Status.FRESH, "DISAPPEARED", "ELIGIBLE", false
        )
        assertEquals(RiskPlanRecoveryPolicy.State.RECOMPUTE_REQUIRED, result.state)
        assertFalse(result.allowReferenceLevels)
    }

    @Test fun blankLifecycleStatusFailsClosed() {
        val result = RiskPlanRecoveryPolicy.evaluate(
            MarketDataFreshness.Status.FRESH, "", "ELIGIBLE", false
        )
        assertEquals(RiskPlanRecoveryPolicy.State.RECOMPUTE_REQUIRED, result.state)
        assertFalse(result.allowReferenceLevels)
    }

    @Test fun freshDataAndValidDirectionRecalculatesRatherThanRestoresOldPlan() {
        val result = RiskPlanRecoveryPolicy.evaluate(
            MarketDataFreshness.Status.FRESH, "ACTIVE", "ELIGIBLE", false
        )
        assertEquals(RiskPlanRecoveryPolicy.State.READY_TO_RECALCULATE, result.state)
        assertTrue(result.allowReferenceLevels)
    }
}
