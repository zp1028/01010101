package com.diveintocrypto.android.domain.analysis

import com.diveintocrypto.android.domain.model.Candle
import com.diveintocrypto.android.domain.scanner.RiskPlanCalculator
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

class PatternAndWatchTest {

    private fun c(i: Int, o: Double, h: Double, l: Double, cl: Double) =
        Candle(i * 60_000L, o, h, l, cl, 1.0, i * 60_000L + 59_000L)

    @Test
    fun vTopDetectedOnSharpRiseAndFall() {
        val candles = mutableListOf<Candle>()
        // rise
        for (i in 0..8) candles.add(c(i, 100.0 + i, 101.0 + i, 99.0 + i, 100.5 + i))
        // peak
        candles.add(c(9, 110.0, 115.0, 109.0, 114.0))
        // fall
        for (i in 10..16) candles.add(c(i, 113.0 - (i - 9), 114.0 - (i - 9), 111.0 - (i - 9), 112.0 - (i - 9)))
        val hits = PatternDetector.detect(candles)
        assertTrue(hits.any { it.name.contains("V") || it.name.contains("回落") })
    }

    @Test
    fun trendLineBuilderNeedsSwings() {
        val candles = (0 until 20).map { i ->
            val base = 100.0 + i * 0.5
            c(i, base, base + 1, base - 1, base)
        }
        val segs = TrendLineBuilder.build(candles)
        // may be empty if no clear swings — just ensure no crash
        assertTrue(segs.size <= 2)
    }

    @Test
    fun watchSessionHitsStopOnLong() {
        var state = WatchSession.arm("BTCUSDT", RiskPlanCalculator.Direction.LONG, 100.0, 95.0, 110.0)
        assertEquals(WatchSession.Status.WATCHING, state.status)
        state = WatchSession.evaluate(state, 94.0)
        assertEquals(WatchSession.Status.HIT_SL, state.status)
        state = WatchSession.arm("BTCUSDT", RiskPlanCalculator.Direction.LONG, 100.0, 95.0, 110.0)
        state = WatchSession.evaluate(state, 110.5)
        assertEquals(WatchSession.Status.HIT_TP, state.status)
    }

    @Test
    fun watchUpdatePlanKeepsEntry() {
        var state = WatchSession.arm("ETHUSDT", RiskPlanCalculator.Direction.SHORT, 2000.0, 2050.0, 1900.0)
        state = WatchSession.updatePlan(state, 2060.0, 1880.0)
        assertNotNull(state.plan)
        assertEquals(2000.0, state.plan!!.entry, 1e-9)
        assertEquals(1880.0, state.plan!!.takeProfit, 1e-9)
    }
}
