package com.diveintocrypto.android.domain.scanner

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

class ConfirmedStructureLevelsTest {
    @Test fun returnsNearestConfirmedSupportAndResistance() {
        val highs = listOf(10.0, 11.0, 15.0, 12.0, 11.0, 14.0, 13.0)
        val lows = listOf(8.0, 7.0, 11.0, 10.0, 10.5, 12.0, 11.0)
        val levels = ConfirmedStructureLevels.find(highs, lows, currentPrice = 12.5, k = 1)
        assertEquals(10.0, levels.support)
        assertEquals(14.0, levels.resistance)
    }

    @Test fun insufficientOrInvalidSeriesReturnsNoLevels() {
        val short = ConfirmedStructureLevels.find(listOf(1.0, 2.0), listOf(0.5, 1.0), currentPrice = 1.5)
        assertNull(short.support)
        assertNull(short.resistance)
        val invalid = ConfirmedStructureLevels.find(listOf(1.0, 2.0, 3.0), listOf(0.5, 1.0, 1.5), currentPrice = Double.NaN)
        assertNull(invalid.support)
        assertNull(invalid.resistance)
    }
}
