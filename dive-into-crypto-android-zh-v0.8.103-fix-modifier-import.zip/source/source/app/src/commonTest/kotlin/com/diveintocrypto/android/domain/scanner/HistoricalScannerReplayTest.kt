package com.diveintocrypto.android.domain.scanner

import com.diveintocrypto.android.domain.model.Candle
import com.diveintocrypto.android.domain.model.Signal
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class HistoricalScannerReplayTest {

    private fun causal(
        symbol: String,
        tf: String,
        signal: Signal,
        confidence: Int,
        lastOpen: Long,
        price: Double = 100.0,
    ) = HistoricalScannerReplay.CausalCell(
        symbol = symbol,
        timeframe = tf,
        signal = signal,
        confidence = confidence,
        price = price,
        lastCandleOpenTimeMs = lastOpen,
    )

    private fun candle(open: Long, close: Long = open + 59_999L) =
        Candle(open, 10.0, 11.0, 9.0, 10.5, 1.0, close)

    @Test
    fun rankAtCutRejectsFutureCells() {
        val cut = 1_000_000L
        val input = HistoricalScannerReplay.ReplayInput(
            cutTimeMs = cut,
            cells = listOf(causal("AAA", "1d", Signal.BUY, 50, lastOpen = cut)), // equal is leak
            phase2Depth = 10,
        )
        assertFailsWith<IllegalArgumentException> {
            HistoricalScannerReplay.rankAtCut(input)
        }
    }

    @Test
    fun rankAtCutMarksMissingUniverseAndAuxiliary() {
        val cut = 10_000_000L
        val report = HistoricalScannerReplay.rankAtCut(
            HistoricalScannerReplay.ReplayInput(
                cutTimeMs = cut,
                cells = listOf(
                    causal("AAA", "1d", Signal.STRONG_BUY, 80, lastOpen = cut - 1),
                    causal("BBB", "1d", Signal.SELL, 60, lastOpen = cut - 1),
                ),
                phase2Depth = 5,
                universeAtCut = null,
                auxiliaryDataMissing = true,
            ),
        )
        assertTrue(report.missingUniverseRanking)
        assertTrue(report.missingAuxiliaryData)
        assertTrue(report.limitations.isNotEmpty())
        assertEquals(2, report.symbolsEvaluated)
        assertEquals(2, report.cellsUsed)
        assertTrue(report.ranking.crossRank.isNotEmpty())
    }

    @Test
    fun rankAtCutRespectsHistoricalUniverseOrderScope() {
        val cut = 10_000_000L
        val report = HistoricalScannerReplay.rankAtCut(
            HistoricalScannerReplay.ReplayInput(
                cutTimeMs = cut,
                cells = listOf(
                    causal("IN", "1d", Signal.BUY, 90, lastOpen = cut - 1),
                    causal("OUT", "1d", Signal.STRONG_BUY, 99, lastOpen = cut - 1),
                ),
                phase2Depth = 10,
                universeAtCut = listOf("IN"), // OUT not in historical universe snapshot
                auxiliaryDataMissing = false,
            ),
        )
        assertFalse(report.missingUniverseRanking)
        assertFalse(report.missingAuxiliaryData)
        assertEquals(1, report.symbolsEvaluated)
        assertEquals(listOf("IN"), report.ranking.phase2Survivors)
        assertTrue(report.ranking.crossRank.none { it.symbol == "OUT" })
    }

    @Test
    fun rankAtCutProducesSameOrderAsScannerRanking() {
        val cut = 5_000_000L
        val cells = listOf(
            causal("TOP", "1d", Signal.STRONG_BUY, 90, lastOpen = cut - 100),
            causal("TOP", "12h", Signal.BUY, 70, lastOpen = cut - 100),
            causal("MID", "1d", Signal.BUY, 50, lastOpen = cut - 100),
            causal("TOP", "15m", Signal.BUY, 60, lastOpen = cut - 50),
            causal("MID", "15m", Signal.SELL, 55, lastOpen = cut - 50),
        )
        val report = HistoricalScannerReplay.rankAtCut(
            HistoricalScannerReplay.ReplayInput(
                cutTimeMs = cut,
                cells = cells,
                phase2Depth = 2,
                universeAtCut = listOf("TOP", "MID", "OTHER"),
                auxiliaryDataMissing = true,
            ),
        )
        assertEquals(listOf("TOP", "MID"), report.ranking.phase2Survivors)
        assertEquals("TOP", report.ranking.crossRank.first().symbol)
    }

    @Test
    fun causalPrefixExcludesBarsNotClosedBeforeCut() {
        val bars = listOf(
            candle(open = 1_000L, close = 1_999L),
            candle(open = 2_000L, close = 2_999L),
            candle(open = 3_000L, close = 3_999L),
        )
        val prefix = HistoricalScannerReplay.causalPrefix(bars, cutTimeMs = 3_000L)
        assertEquals(listOf(1_000L, 2_000L), prefix.map { it.openTime })
    }

    @Test
    fun causalPrefixReturnsEmptyForNonPositiveCut() {
        assertTrue(HistoricalScannerReplay.causalPrefix(listOf(candle(100)), 0L).isEmpty())
    }

    @Test
    fun signalCrossesGapDetectsDiscontinuityInLookback() {
        val regular = (0..9).map { i ->
            val open = i * 60_000L
            candle(open = open, close = open + 59_999L)
        }
        assertFalse(
            HistoricalScannerReplay.signalCrossesGap(regular, signalIndex = 5, lookbackBars = 3),
        )

        val gapped = regular.mapIndexed { i, c ->
            if (i >= 5) c.copy(openTime = c.openTime + 180_000L, closeTime = c.closeTime + 180_000L)
            else c
        }
        val sanitized = HistoricalCandleAlignment.sanitize(gapped)
        assertTrue(
            HistoricalScannerReplay.signalCrossesGap(sanitized, signalIndex = 6, lookbackBars = 3),
        )
    }

    @Test
    fun buildCausalCellRejectsEmptyOrNonCausalPrefix() {
        val cut = 10_000L
        assertEquals(null, HistoricalScannerReplay.buildCausalCell("AAA", "1h", Signal.BUY, 50, emptyList(), cut))
        val late = listOf(candle(open = 9_500L, close = 10_500L)) // closes after cut
        assertEquals(null, HistoricalScannerReplay.buildCausalCell("AAA", "1h", Signal.BUY, 50, late, cut))
        val ok = listOf(candle(open = 8_000L, close = 8_999L))
        val cell = HistoricalScannerReplay.buildCausalCell("AAA", "1h", Signal.BUY, 50, ok, cut)
        assertEquals("AAA", cell!!.symbol)
        assertEquals(8_000L, cell.lastCandleOpenTimeMs)
        assertEquals(50, cell.confidence)
    }

}
