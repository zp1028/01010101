package com.diveintocrypto.android.domain.scanner

import com.diveintocrypto.android.domain.model.Candle
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertTrue

class SmaCrossoverBacktestTest {
    private fun candles(closes: List<Double>): List<Candle> = closes.mapIndexed { i, close ->
        Candle(i.toLong() * 60_000L, close, close * 1.01, close * 0.99, close, 1.0, (i + 1L) * 60_000L - 1L)
    }

    @Test
    fun rejectsInvalidMovingAveragePeriods() {
        assertFailsWith<IllegalArgumentException> {
            SmaCrossoverBacktest.run(candles((1..30).map { it.toDouble() }), SmaCrossoverBacktest.Config(fastPeriod = 10, slowPeriod = 10))
        }
    }

    @Test
    fun insufficientHistoryProducesEmptySummary() {
        val result = SmaCrossoverBacktest.run(candles(listOf(1.0, 2.0, 3.0)), SmaCrossoverBacktest.Config(fastPeriod = 2, slowPeriod = 5))
        assertEquals(0, result.signalCount)
        assertEquals(0, result.summary.tradeCount)
    }

    @Test
    fun strictCloseLookupHandlesOutOfOrderSignalTimesAndEqualCloseBoundary() {
        val sortedCloseTimes = listOf(100L, 200L, 200L, 350L, 500L)
        assertEquals(-1, SmaCrossoverBacktest.lastStrictlyClosedIndex(sortedCloseTimes, 100L))
        assertEquals(0, SmaCrossoverBacktest.lastStrictlyClosedIndex(sortedCloseTimes, 150L))
        assertEquals(0, SmaCrossoverBacktest.lastStrictlyClosedIndex(sortedCloseTimes, 200L))
        assertEquals(2, SmaCrossoverBacktest.lastStrictlyClosedIndex(sortedCloseTimes, 351L))
        assertEquals(4, SmaCrossoverBacktest.lastStrictlyClosedIndex(sortedCloseTimes, 501L))
    }

    @Test
    fun higherTimeframeFilterRejectsSignalsWithoutPreviouslyClosedConfirmationBars() {
        val prices = listOf(10.0, 9.0, 8.0, 7.0, 8.0, 9.0, 10.0, 11.0, 10.0, 9.0, 8.0, 7.0, 8.0, 9.0, 10.0, 11.0)
        val base = SmaCrossoverBacktest.Config(
            fastPeriod = 2, slowPeriod = 3, stopPct = 5.0, targetPct = 5.0,
            feeSidePct = 0.0, slippageSidePct = 0.0,
        )
        val filtered = SmaCrossoverBacktest.run(candles(prices), base.copy(
            requireHigherTimeframeConfirmation = true,
            confirmationCandles = emptyList(),
            confirmationFastPeriod = 2,
            confirmationSlowPeriod = 3,
        ))
        assertTrue(filtered.signalCount > 0)
        assertEquals(0, filtered.confirmedSignalCount)
        assertEquals(filtered.signalCount, filtered.filteredSignalCount)
        assertEquals(0, filtered.summary.tradeCount)
    }

    @Test
    fun higherTimeframeBarsThatCloseAfterSignalCannotConfirmIt() {
        val prices = listOf(10.0, 9.0, 8.0, 7.0, 8.0, 9.0, 10.0, 11.0, 10.0, 9.0, 8.0, 7.0, 8.0, 9.0, 10.0, 11.0)
        val futureBars = (0..30).map { i ->
            val openTime = 10_000_000L + i * 10_000L
            Candle(openTime, 200.0 + i, 202.0 + i, 198.0 + i, 200.0 + i, 1.0, openTime + 9_999L)
        }
        val result = SmaCrossoverBacktest.run(candles(prices), SmaCrossoverBacktest.Config(
            fastPeriod = 2, slowPeriod = 3, stopPct = 5.0, targetPct = 5.0,
            feeSidePct = 0.0, slippageSidePct = 0.0,
            confirmationCandles = futureBars,
            requireHigherTimeframeConfirmation = true,
            confirmationFastPeriod = 2,
            confirmationSlowPeriod = 3,
        ))
        assertTrue(result.signalCount > 0)
        assertEquals(0, result.confirmedSignalCount)
        assertEquals(result.signalCount, result.filteredSignalCount)
    }

    @Test
    fun signalAccountingSeparatesConfirmedAndFilteredEvents() {
        val prices = listOf(10.0, 9.0, 8.0, 7.0, 8.0, 9.0, 10.0, 11.0, 10.0, 9.0, 8.0, 7.0, 8.0, 9.0, 10.0, 11.0)
        val result = SmaCrossoverBacktest.run(candles(prices), SmaCrossoverBacktest.Config(
            fastPeriod = 2, slowPeriod = 3, stopPct = 5.0, targetPct = 5.0,
            feeSidePct = 0.0, slippageSidePct = 0.0,
            requireHigherTimeframeConfirmation = true,
            confirmationCandles = (0..80).map { i ->
                val openTime = i * 10_000L
                val close = 100.0 + i
                Candle(openTime, close, close * 1.01, close * 0.99, close, 1.0, openTime + 9_999L)
            },
            confirmationFastPeriod = 2,
            confirmationSlowPeriod = 3,
        ))
        assertEquals(result.signalCount, result.confirmedSignalCount + result.filteredSignalCount)
    }

    @Test
    fun malformedTimeRangesAndDuplicateOpenTimesAreSanitizedBeforeReplay() {
        val base = candles(listOf(10.0, 9.0, 8.0, 7.0, 8.0, 9.0, 10.0, 11.0, 10.0, 9.0, 8.0, 7.0, 8.0, 9.0, 10.0, 11.0))
        val duplicate = base[5].copy(close = 9.5, high = 9.6, low = 8.9)
        val malformed = base[6].copy(closeTime = base[6].openTime)
        val dirty = SmaCrossoverBacktest.run(base + duplicate + malformed, SmaCrossoverBacktest.Config(fastPeriod = 2, slowPeriod = 3, feeSidePct = 0.0, slippageSidePct = 0.0))
        assertEquals(dirty.signalCount, dirty.confirmedSignalCount + dirty.filteredSignalCount)
        assertTrue(dirty.summary.trades.all { it.netReturnPct == null || it.netReturnPct!!.isFinite() })
    }

    @Test
    fun replayUsesSharedSanitizerAndDiscardsInvalidVolumeCandles() {
        val base = candles(listOf(10.0, 9.0, 8.0, 7.0, 8.0, 9.0, 10.0, 11.0, 10.0, 9.0, 8.0, 7.0, 8.0, 9.0, 10.0, 11.0))
        val invalidVolumeRows = listOf(
            base[0].copy(openTime = 30_000L, closeTime = 59_999L, volume = -1.0),
            base[1].copy(openTime = 90_000L, closeTime = 119_999L, volume = Double.NaN),
            base[2].copy(openTime = 150_000L, closeTime = 179_999L, volume = Double.POSITIVE_INFINITY),
        )
        val config = SmaCrossoverBacktest.Config(
            fastPeriod = 2, slowPeriod = 3, feeSidePct = 0.0, slippageSidePct = 0.0,
        )

        val cleanResult = SmaCrossoverBacktest.run(base, config)
        val dirtyResult = SmaCrossoverBacktest.run(base + invalidVolumeRows, config)

        assertEquals(cleanResult.signalCount, dirtyResult.signalCount)
        assertEquals(cleanResult.confirmedSignalCount, dirtyResult.confirmedSignalCount)
        assertEquals(cleanResult.filteredSignalCount, dirtyResult.filteredSignalCount)
        assertEquals(cleanResult.summary.tradeCount, dirtyResult.summary.tradeCount)
        assertEquals(cleanResult.summary.trades.map { it.netReturnPct }, dirtyResult.summary.trades.map { it.netReturnPct })
    }

    @Test
    fun returnsDeterministicResultsAndIncludesTradingCosts() {
        val prices = listOf(10.0, 9.0, 8.0, 7.0, 8.0, 9.0, 10.0, 11.0, 10.0, 9.0, 8.0, 7.0, 8.0, 9.0, 10.0, 11.0)
        val cfg = SmaCrossoverBacktest.Config(fastPeriod = 2, slowPeriod = 3, stopPct = 5.0, targetPct = 5.0, feeSidePct = 0.05, slippageSidePct = 0.02)
        val resultA = SmaCrossoverBacktest.run(candles(prices), cfg)
        val resultB = SmaCrossoverBacktest.run(candles(prices), cfg)
        assertEquals(resultA.signalCount, resultB.signalCount)
        assertEquals(resultA.summary.tradeCount, resultB.summary.tradeCount)
        assertTrue(resultA.summary.trades.all { it.estimatedCostPct > 0.0 })
    }

    @Test
    fun atrRiskPlanUsesOnlyPastAndCurrentCandleRanges() {
        val prices = listOf(10.0, 9.0, 8.0, 7.0, 8.0, 9.0, 10.0, 11.0, 10.0, 9.0, 8.0, 7.0, 8.0, 9.0, 10.0, 11.0, 12.0)
        val history = candles(prices)
        val result = SmaCrossoverBacktest.run(history, SmaCrossoverBacktest.Config(
            fastPeriod = 2, slowPeriod = 3, stopPct = 1.0, targetPct = 2.0,
            feeSidePct = 0.0, slippageSidePct = 0.0,
            useAtrRiskPlan = true, atrPeriod = 3, atrMultiplier = 1.5, targetR = 2.0,
        ))
        assertTrue(result.summary.trades.isNotEmpty())
        result.summary.trades.forEach { trade ->
            val setup = trade.setup
            val expectedRisk = if (setup.direction == RiskPlanCalculator.Direction.LONG) setup.entryPrice - setup.stopLoss else setup.stopLoss - setup.entryPrice
            val expectedReward = if (setup.direction == RiskPlanCalculator.Direction.LONG) setup.takeProfit - setup.entryPrice else setup.entryPrice - setup.takeProfit
            assertTrue(expectedRisk > 0.0)
            assertTrue(kotlin.math.abs(expectedReward / expectedRisk - 2.0) < 1e-8)
        }
    }

    @Test
    fun structureAwareAtrStopUsesPriorCandlesAndPreservesConfiguredRMultiple() {
        val prices = listOf(10.0, 9.0, 8.0, 7.0, 8.0, 9.0, 10.0, 11.0, 10.0, 9.0, 8.0, 7.0, 8.0, 9.0, 10.0, 11.0, 12.0)
        val history = candles(prices)
        val atrOnly = SmaCrossoverBacktest.run(history, SmaCrossoverBacktest.Config(
            fastPeriod = 2, slowPeriod = 3, feeSidePct = 0.0, slippageSidePct = 0.0,
            useAtrRiskPlan = true, atrPeriod = 3, atrMultiplier = 1.0, targetR = 2.0,
        ))
        val structure = SmaCrossoverBacktest.run(history, SmaCrossoverBacktest.Config(
            fastPeriod = 2, slowPeriod = 3, feeSidePct = 0.0, slippageSidePct = 0.0,
            useAtrRiskPlan = true, atrPeriod = 3, atrMultiplier = 1.0, targetR = 2.0,
            useStructureStop = true, structureLookback = 5, structureBufferAtr = 0.15,
        ))
        assertTrue(structure.confirmedSignalCount > 0)
        assertTrue(structure.summary.trades.isNotEmpty())
        structure.summary.trades.forEach { trade ->
            val setup = trade.setup
            val risk = if (setup.direction == RiskPlanCalculator.Direction.LONG) setup.entryPrice - setup.stopLoss else setup.stopLoss - setup.entryPrice
            val reward = if (setup.direction == RiskPlanCalculator.Direction.LONG) setup.takeProfit - setup.entryPrice else setup.entryPrice - setup.takeProfit
            assertTrue(risk > 0.0)
            assertTrue(kotlin.math.abs(reward / risk - 2.0) < 1e-8)
        }
        // The shared structure calculator must never place the stop closer than its ATR-only baseline.
        val baselineByIndex = atrOnly.summary.trades.associateBy { it.setup.entryIndex }
        structure.summary.trades.forEach { trade ->
            val baseline = baselineByIndex[trade.setup.entryIndex] ?: return@forEach
            val baselineRisk = kotlin.math.abs(baseline.setup.entryPrice - baseline.setup.stopLoss)
            val structureRisk = kotlin.math.abs(trade.setup.entryPrice - trade.setup.stopLoss)
            assertTrue(structureRisk + 1e-8 >= baselineRisk)
        }
    }

    @Test
    fun structureStopCannotBeEnabledWithoutAtrRiskPlan() {
        assertFailsWith<IllegalArgumentException> {
            SmaCrossoverBacktest.run(candles((1..30).map { it.toDouble() }), SmaCrossoverBacktest.Config(
                fastPeriod = 2, slowPeriod = 3, useStructureStop = true, useAtrRiskPlan = false,
            ))
        }
    }

    @Test
    fun entriesUseNextCandleOpenRatherThanSignalCandleClose() {
        val closes = listOf(10.0, 9.0, 8.0, 7.0, 8.0, 9.0, 10.0, 11.0, 10.0, 9.0, 8.0, 7.0, 8.0, 9.0, 10.0, 11.0, 12.0)
        val history = candles(closes).mapIndexed { index, candle ->
            // Shift the open while keeping it inside the candle's OHLC range.
            candle.copy(open = candle.close * 1.003, high = candle.high * 1.01)
        }
        val result = SmaCrossoverBacktest.run(history, SmaCrossoverBacktest.Config(
            fastPeriod = 2, slowPeriod = 3, stopPct = 1.0, targetPct = 2.0,
            feeSidePct = 0.0, slippageSidePct = 0.0,
        ))
        assertTrue(result.summary.trades.isNotEmpty())
        result.summary.trades.forEach { trade ->
            val signalIndex = trade.setup.entryIndex
            assertTrue(signalIndex + 1 < history.size)
            assertEquals(history[signalIndex + 1].open, trade.setup.entryPrice, 1e-9)
            assertTrue(trade.setup.entryPrice != history[signalIndex].close)
        }
    }

    @Test
    fun fixedRiskLevelsAreAnchoredToNextOpenFill() {
        val closes = listOf(10.0, 9.0, 8.0, 7.0, 8.0, 9.0, 10.0, 11.0, 10.0, 9.0, 8.0, 7.0, 8.0, 9.0, 10.0, 11.0, 12.0)
        val history = candles(closes).map { candle -> candle.copy(open = candle.close * 1.002, high = candle.high * 1.01) }
        val result = SmaCrossoverBacktest.run(history, SmaCrossoverBacktest.Config(
            fastPeriod = 2, slowPeriod = 3, stopPct = 1.0, targetPct = 2.0,
            feeSidePct = 0.0, slippageSidePct = 0.0,
        ))
        assertTrue(result.summary.trades.isNotEmpty())
        result.summary.trades.forEach { trade ->
            val entry = history[trade.setup.entryIndex + 1].open
            assertEquals(entry, trade.setup.entryPrice, 1e-9)
            when (trade.setup.direction) {
                RiskPlanCalculator.Direction.LONG -> {
                    assertEquals(entry * 0.99, trade.setup.stopLoss, 1e-8)
                    assertEquals(entry * 1.02, trade.setup.takeProfit, 1e-8)
                }
                RiskPlanCalculator.Direction.SHORT -> {
                    assertEquals(entry * 1.01, trade.setup.stopLoss, 1e-8)
                    assertEquals(entry * 0.98, trade.setup.takeProfit, 1e-8)
                }
            }
        }
    }

    @Test
    fun atrRiskPlanDoesNotValidateUnusedFixedPercentageInputs() {
        val prices = listOf(10.0, 9.0, 8.0, 7.0, 8.0, 9.0, 10.0, 11.0, 10.0, 9.0, 8.0, 7.0, 8.0, 9.0, 10.0, 11.0, 12.0)
        val result = SmaCrossoverBacktest.run(candles(prices), SmaCrossoverBacktest.Config(
            fastPeriod = 2,
            slowPeriod = 3,
            stopPct = Double.NaN,
            targetPct = -1.0,
            feeSidePct = 0.0,
            slippageSidePct = 0.0,
            useAtrRiskPlan = true,
            atrPeriod = 3,
            atrMultiplier = 1.5,
            targetR = 2.0,
        ))
        assertTrue(result.confirmedSignalCount > 0)
        assertTrue(result.summary.trades.isNotEmpty())
    }

    @Test
    fun atrRiskPlanRejectsInvalidAtrParameters() {
        assertFailsWith<IllegalArgumentException> {
            SmaCrossoverBacktest.run(candles((1..20).map { it.toDouble() }), SmaCrossoverBacktest.Config(
                fastPeriod = 2, slowPeriod = 3, useAtrRiskPlan = true, atrPeriod = 1,
            ))
        }
    }

    @Test
    fun injectedScannerSignalProviderReceivesOnlyClosedPrefixAndUsesSharedRiskReplay() {
        val history = candles((1..40).map { 100.0 + it * 0.2 })
        val seenSizes = mutableListOf<Int>()
        val result = SmaCrossoverBacktest.run(history, SmaCrossoverBacktest.Config(
            // These are unused in injected-signal mode and must not block the scanner replay.
            fastPeriod = 0,
            slowPeriod = -5,
            stopPct = 1.0,
            targetPct = 2.0,
            feeSidePct = 0.0,
            slippageSidePct = 0.0,
            signalProvider = { prefix, signalIndex ->
                seenSizes += prefix.size
                assertEquals(signalIndex + 1, prefix.size, "provider must not receive future candles")
                SmaCrossoverBacktest.HistoricalSignalDecision(
                    direction = RiskPlanCalculator.Direction.LONG,
                    hasDirectionalSignal = true,
                    eligible = true,
                )
            },
        ))
        assertTrue(seenSizes.isNotEmpty())
        assertTrue(result.signalCount > 0)
        assertTrue(result.summary.trades.isNotEmpty())
        assertEquals(result.signalCount, result.confirmedSignalCount + result.filteredSignalCount)
    }

    @Test
    fun injectedDirectionalSignalsRejectedByQualityGateAreCountedAsFiltered() {
        val result = SmaCrossoverBacktest.run(candles((1..40).map { 100.0 + it * 0.2 }), SmaCrossoverBacktest.Config(
            fastPeriod = 2,
            slowPeriod = 3,
            feeSidePct = 0.0,
            slippageSidePct = 0.0,
            signalProvider = { _, _ ->
                SmaCrossoverBacktest.HistoricalSignalDecision(
                    direction = RiskPlanCalculator.Direction.LONG,
                    hasDirectionalSignal = true,
                    eligible = false,
                )
            },
        ))
        assertTrue(result.signalCount > 0)
        assertEquals(0, result.confirmedSignalCount)
        assertEquals(result.signalCount, result.filteredSignalCount)
        assertEquals(0, result.summary.tradeCount)
    }



    @Test
    fun signalsWhoseLookbackOrNextOpenCrossesDataGapAreFiltered() {
        val history = (0..45).map { i ->
            val openTime = i * 60_000L + if (i >= 23) 120_000L else 0L
            val price = 100.0 + (i % 7) - 3.0
            Candle(openTime, price, price + 2.0, price - 2.0, price, 10.0, openTime + 59_999L)
        }
        val config = SmaCrossoverBacktest.Config(
            fastPeriod = 2, slowPeriod = 5, stopPct = 1.0, targetPct = 2.0,
            feeSidePct = 0.0, slippageSidePct = 0.0,
            signalProvider = { _, _ -> SmaCrossoverBacktest.HistoricalSignalDecision(
                direction = RiskPlanCalculator.Direction.LONG, hasDirectionalSignal = true, eligible = true,
            ) },
        )
        val result = SmaCrossoverBacktest.run(history, config)
        assertTrue(result.signalCount > 0)
        assertTrue(result.filteredSignalCount > 0)
        assertEquals(result.signalCount, result.confirmedSignalCount + result.filteredSignalCount)
    }
}
