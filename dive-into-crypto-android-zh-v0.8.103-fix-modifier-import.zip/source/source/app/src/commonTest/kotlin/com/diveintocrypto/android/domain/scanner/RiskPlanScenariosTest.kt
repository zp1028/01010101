package com.diveintocrypto.android.domain.scanner

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

class RiskPlanScenariosTest {
    @Test fun exposesThreeComparableProfilesWithNetCostAssessment() {
        val scenarios = RiskPlanScenarios.evaluate(
            direction = RiskPlanCalculator.Direction.LONG,
            entry = 100.0,
            atr = 1.0,
            feeSidePct = 0.05,
            slippageSidePct = 0.02,
        )
        assertEquals(listOf("稳健", "标准", "积极"), scenarios.map { it.profile.label })
        assertTrue(scenarios.all { it.plan != null })
        assertTrue(scenarios.all { it.netRiskRewardRatio != null })
        assertEquals(1.5, assertNotNull(scenarios[0].plan).riskRewardRatio, 1e-9)
        assertEquals(2.0, assertNotNull(scenarios[1].plan).riskRewardRatio, 1e-9)
        assertEquals(2.5, assertNotNull(scenarios[2].plan).riskRewardRatio, 1e-9)
    }

    @Test fun invalidInputsRemainExplicitAcrossProfiles() {
        val scenarios = RiskPlanScenarios.evaluate(RiskPlanCalculator.Direction.LONG, 0.0, 1.0, 0.05, 0.02)
        assertTrue(scenarios.all { it.plan == null && it.reason == "invalid_entry" })
    }
}
