package com.diveintocrypto.android.data.binance

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay

/**
 * Small bounded retry policy for idempotent public-market-data REST reads.
 *
 * Retries transient network failures, HTTP 408/418/429, and HTTP 5xx responses.
 * Does not retry ordinary HTTP 4xx errors (bad symbol/interval/parameters), and
 * always propagates coroutine cancellation immediately. This is deliberately
 * bounded: it is a resilience fallback, not a substitute for respecting rate limits.
 */
internal suspend fun <T> retryPublicRest(
    maxAttempts: Int = 4,
    baseDelayMs: Long = 350L,
    operation: suspend () -> T,
): T {
    require(maxAttempts >= 1) { "maxAttempts must be at least 1" }
    require(baseDelayMs >= 0L) { "baseDelayMs cannot be negative" }

    var attempt = 1
    while (true) {
        try {
            return operation()
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (failure: Throwable) {
            if (attempt >= maxAttempts || !isRetryablePublicRestFailure(failure)) throw failure
            val msg = failure.message.orEmpty().uppercase()
            // Binance/Cloudflare 418/429: back off much harder after a full-universe scan.
            val rateLimited = msg.contains("HTTP 418") || msg.contains("HTTP 429")
            val delayMs = if (rateLimited) {
                (2_000L * (1L shl (attempt - 1).coerceAtMost(4))).coerceAtMost(16_000L)
            } else {
                baseDelayMs * (1L shl (attempt - 1).coerceAtMost(10))
            }
            delay(delayMs)
            attempt++
        }
    }
}

/** Exposed internally so retry classification can be tested without network access. */
internal fun isRetryablePublicRestFailure(failure: Throwable): Boolean {
    val message = generateSequence(failure) { it.cause }
        .mapNotNull { it.message }
        .joinToString(" ")
        .uppercase()
    val status = Regex("HTTP\\s+(\\d{3})").find(message)?.groupValues?.getOrNull(1)?.toIntOrNull()
    if (status != null) {
        return status == 408 || status == 418 || status == 429 || status in 500..599
    }
    // Most transport exceptions do not have an HTTP status. Don't retry obvious
    // programmer/input errors; transient DNS/socket/timeouts remain retryable.
    if (failure is IllegalArgumentException) return false
    if (message.contains("UNKNOWN SYMBOL") || message.contains("INVALID INTERVAL") ||
        message.contains("BAD REQUEST") || message.contains("HTTP 400") ||
        message.contains("HTTP 401") || message.contains("HTTP 403") ||
        message.contains("HTTP 404") || message.contains("HTTP 422")) return false
    return true
}
