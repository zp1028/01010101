package com.diveintocrypto.android.domain.scanner

/** Conservative position-size estimate for review only; not an exchange margin/liquidation simulator. */
object PositionRiskCalculator {
    data class Result(
        val riskBudget: Double,
        val stopDistancePct: Double,
        val estimatedCostPct: Double,
        val maxNotional: Double,
        val estimatedStopLoss: Double,
        val requiredInitialMargin: Double,
        val exposureToEquity: Double,
        val warning: String?,
    )

    fun calculate(
        equity: Double,
        riskPct: Double,
        entryPrice: Double,
        stopPrice: Double,
        leverage: Double,
        stopPathCostPct: Double = 0.0,
    ): Result? {
        if (!equity.isFinite() || equity <= 0.0) return null
        if (!riskPct.isFinite() || riskPct <= 0.0 || riskPct > 10.0) return null
        if (!entryPrice.isFinite() || entryPrice <= 0.0) return null
        if (!stopPrice.isFinite() || stopPrice <= 0.0 || stopPrice == entryPrice) return null
        if (!leverage.isFinite() || leverage < 1.0 || leverage > 125.0) return null
        if (!stopPathCostPct.isFinite() || stopPathCostPct < 0.0 || stopPathCostPct >= 100.0) return null

        val stopPct = kotlin.math.abs(entryPrice - stopPrice) / entryPrice * 100.0
        if (!stopPct.isFinite() || stopPct <= 0.0 || stopPct >= 100.0) return null
        val totalRiskPct = stopPct + stopPathCostPct
        if (totalRiskPct <= 0.0 || totalRiskPct >= 100.0) return null
        val budget = equity * riskPct / 100.0
        val notional = budget / (totalRiskPct / 100.0)
        if (!notional.isFinite() || notional <= 0.0) return null
        val margin = notional / leverage
        val estimatedLoss = notional * totalRiskPct / 100.0
        val warning = when {
            margin >= equity -> "所需初始保证金达到或超过账户权益；该仓位规模不适合当前参数。"
            stopPct >= (100.0 / leverage) * 0.8 -> "止损距离接近或超过杠杆对应的粗略保证金缓冲；强平可能先于止损触发，必须在交易所核对实际强平价。"
            else -> "仅为止损预算估算；未模拟维持保证金、资金费率、滑点突增或强平。"
        }
        return Result(
            riskBudget = budget,
            stopDistancePct = stopPct,
            estimatedCostPct = stopPathCostPct,
            maxNotional = notional,
            estimatedStopLoss = estimatedLoss,
            requiredInitialMargin = margin,
            exposureToEquity = notional / equity,
            warning = warning,
        )
    }
}
