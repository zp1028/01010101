package com.diveintocrypto.android.domain.scanner

import kotlin.math.abs

/**
 * Produces a reference-only ATR-based risk plan for the analysis UI.
 * It never places, modifies, or closes an order.
 */
object RiskPlanCalculator {
    enum class Direction { LONG, SHORT }

    data class Plan(
        val entry: Double,
        val stopLoss: Double,
        val takeProfit: Double,
        val riskPerUnit: Double,
        val rewardPerUnit: Double,
        val riskRewardRatio: Double,
        val stopDistancePercent: Double,
        val valid: Boolean = true,
    )

    data class Result(val plan: Plan? = null, val reason: String? = null) {
        val valid: Boolean get() = plan != null && reason == null
    }

    /**
     * [atr] and [entry] must use the same quote units. [atrMultiplier] controls
     * stop distance; [targetR] controls reward in multiples of initial risk.
     */
    fun calculate(
        direction: Direction,
        entry: Double,
        atr: Double,
        atrMultiplier: Double = 1.5,
        targetR: Double = 2.0,
    ): Result {
        if (!entry.isFinite() || entry <= 0.0) return Result(reason = "invalid_entry")
        if (!atr.isFinite() || atr <= 0.0) return Result(reason = "invalid_atr")
        if (!atrMultiplier.isFinite() || atrMultiplier <= 0.0) return Result(reason = "invalid_atr_multiplier")
        if (!targetR.isFinite() || targetR <= 0.0) return Result(reason = "invalid_target_r")

        val risk = atr * atrMultiplier
        if (!risk.isFinite() || risk <= 0.0 || risk >= entry) return Result(reason = "invalid_risk_distance")
        val reward = risk * targetR
        if (!reward.isFinite() || reward <= 0.0) return Result(reason = "invalid_reward_distance")

        val stop = if (direction == Direction.LONG) entry - risk else entry + risk
        val target = if (direction == Direction.LONG) entry + reward else entry - reward
        if (!stop.isFinite() || !target.isFinite() || stop <= 0.0 || target <= 0.0) {
            return Result(reason = "invalid_price_levels")
        }
        val actualRisk = abs(entry - stop)
        val actualReward = abs(target - entry)
        val ratio = actualReward / actualRisk
        if (!ratio.isFinite() || ratio <= 0.0) return Result(reason = "invalid_risk_reward_ratio")

        return Result(
            plan = Plan(
                entry = entry,
                stopLoss = stop,
                takeProfit = target,
                riskPerUnit = actualRisk,
                rewardPerUnit = actualReward,
                riskRewardRatio = ratio,
                stopDistancePercent = actualRisk / entry * 100.0,
            ),
        )
    }
}
