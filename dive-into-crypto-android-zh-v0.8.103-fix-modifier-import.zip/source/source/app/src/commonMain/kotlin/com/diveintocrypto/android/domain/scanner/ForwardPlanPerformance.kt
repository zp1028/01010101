package com.diveintocrypto.android.domain.scanner

/** Summary of deterministic replay results. Open/expired/invalid-without-outcome results are not wins or losses. */
object ForwardPlanPerformance {
    data class Summary(
        val sampleCount: Int,
        val wins: Int,
        val losses: Int,
        val winRatePct: Double?,
        val expectancyR: Double?,
        val maxDrawdownR: Double?,
        val targetHitRatePct: Double?,
        val stopHitRatePct: Double?,
    )

    data class WeightApproval(
        val approved: Boolean,
        val reason: String,
        val sampleCount: Int,
        val inSampleExpectancyR: Double?,
        val outOfSampleExpectancyR: Double?,
    )

    data class EquityPoint(val index: Int, val planId: String, val timeMs: Long, val netR: Double, val cumulativeR: Double)

    data class Report(
        val summary: Summary,
        val qualifiedCount: Int,
        val excludedCount: Int,
        val trainSummary: Summary?,
        val outOfSampleSummary: Summary?,
        val equityCurve: List<EquityPoint>,
        val splitDescription: String,
        val sampleWarning: String?,
    )

    /** A record is eligible only when its outcome and coverage are both proven by replay. */
    fun report(records: List<ForwardPlanReplayRecord>, trainFraction: Double = 0.70): Report {
        val eligible = records.asSequence()
            .filter { it.coverageStatus == "SUFFICIENT_FOR_OUTCOME" }
            .filter { it.outcome == "TARGET_HIT" || it.outcome == "STOP_HIT" }
            .filter { it.netR?.isFinite() == true }
            .sortedWith(compareBy<ForwardPlanReplayRecord> { it.evaluatedThroughMs }.thenBy { it.planId })
            .toList()
        val fraction = trainFraction.takeIf { it.isFinite() }?.coerceIn(0.50, 0.90) ?: 0.70
        val splitIndex = if (eligible.size >= 2) (eligible.size * fraction).toInt().coerceIn(1, eligible.lastIndex) else 0
        val train = eligible.take(splitIndex)
        val out = if (eligible.size >= 2) eligible.drop(splitIndex) else emptyList()
        var cumulative = 0.0
        val curve = eligible.mapIndexed { index, record ->
            val net = record.netR!!
            cumulative += net
            EquityPoint(index + 1, record.planId, record.evaluatedThroughMs, net, cumulative)
        }
        val warning = when {
            eligible.isEmpty() -> "暂无覆盖充分的止盈/止损样本；未决、过期和数据缺口记录均已排除"
            eligible.size < 10 -> "样本量很小（${eligible.size}）；胜率、回撤和样本外结果仅作描述，不宜据此调参"
            eligible.size < 30 -> "有效样本少于 30；样本外比较仍可能不稳定"
            else -> null
        }
        return Report(
            summary = summarizeRecords(eligible),
            qualifiedCount = eligible.size,
            excludedCount = records.size - eligible.size,
            trainSummary = if (train.isNotEmpty()) summarizeRecords(train) else null,
            outOfSampleSummary = if (out.isNotEmpty()) summarizeRecords(out) else null,
            equityCurve = curve,
            splitDescription = if (eligible.size >= 2) "按结算时间排序：前 ${(fraction * 100).toInt()}% 训练段 / 后 ${100 - (fraction * 100).toInt()}% 样本外段；不是随机切分" else "有效样本不足 2 条，暂不切分训练/样本外",
            sampleWarning = warning,
        )
    }

    private fun summarizeRecords(records: List<ForwardPlanReplayRecord>): Summary {
        val values = records.mapNotNull { it.netR?.takeIf(Double::isFinite) }
        if (values.isEmpty()) return Summary(0, 0, 0, null, null, null, null, null)
        val wins = records.count { it.outcome == "TARGET_HIT" }
        val losses = records.count { it.outcome == "STOP_HIT" }
        var equity = 0.0
        var peak = 0.0
        var maxDrawdown = 0.0
        values.forEach { r ->
            equity += r
            if (equity > peak) peak = equity
            maxDrawdown = maxOf(maxDrawdown, peak - equity)
        }
        return Summary(values.size, wins, losses, wins * 100.0 / values.size, values.average(), maxDrawdown,
            wins * 100.0 / values.size, losses * 100.0 / values.size)
    }

    fun summarize(results: List<ForwardPlanReplayEvaluator.Result>): Summary {
        val resolved = results.filter {
            it.coverageStatus == "SUFFICIENT_FOR_OUTCOME" &&
                (it.outcome == ForwardPlanReplayEvaluator.Outcome.TARGET_HIT || it.outcome == ForwardPlanReplayEvaluator.Outcome.STOP_HIT) &&
                it.grossR != null && it.grossR.isFinite()
        }.sortedBy { it.firstOutcomeCandleCloseMs ?: it.evaluatedThroughMs }
        if (resolved.isEmpty()) return Summary(0, 0, 0, null, null, null, null, null)
        val wins = resolved.count { it.outcome == ForwardPlanReplayEvaluator.Outcome.TARGET_HIT }
        val losses = resolved.size - wins
        val values = resolved.mapNotNull { it.grossR }
        val expectancy = values.average()
        var equity = 0.0
        var peak = 0.0
        var maxDrawdown = 0.0
        values.forEach { r ->
            equity += r
            if (equity > peak) peak = equity
            val drawdown = peak - equity
            if (drawdown > maxDrawdown) maxDrawdown = drawdown
        }
        return Summary(
            sampleCount = resolved.size,
            wins = wins,
            losses = losses,
            winRatePct = wins * 100.0 / resolved.size,
            expectancyR = expectancy,
            maxDrawdownR = maxDrawdown,
            targetHitRatePct = wins * 100.0 / resolved.size,
            stopHitRatePct = losses * 100.0 / resolved.size,
        )
    }

    /** Weight changes are never auto-applied. Both samples and positive out-of-sample expectancy are required. */
    fun evaluateWeightApproval(
        inSample: List<ForwardPlanReplayEvaluator.Result>,
        outOfSample: List<ForwardPlanReplayEvaluator.Result>,
        minimumSamples: Int = 30,
    ): WeightApproval {
        val ins = summarize(inSample)
        val oos = summarize(outOfSample)
        val reason = when {
            minimumSamples < 1 -> "最小样本门槛无效"
            ins.sampleCount < minimumSamples -> "训练样本不足：${ins.sampleCount}/$minimumSamples"
            oos.sampleCount < minimumSamples -> "样本外样本不足：${oos.sampleCount}/$minimumSamples"
            ins.expectancyR == null || ins.expectancyR <= 0.0 -> "训练集净期望收益非正"
            oos.expectancyR == null || oos.expectancyR <= 0.0 -> "样本外净期望收益非正，拒绝权重变更"
            else -> "通过基础样本门槛；仍需人工批准，系统不会自动应用权重"
        }
        return WeightApproval(
            approved = ins.sampleCount >= minimumSamples && oos.sampleCount >= minimumSamples &&
                (ins.expectancyR ?: Double.NEGATIVE_INFINITY) > 0.0 &&
                (oos.expectancyR ?: Double.NEGATIVE_INFINITY) > 0.0,
            reason = reason,
            sampleCount = oos.sampleCount,
            inSampleExpectancyR = ins.expectancyR,
            outOfSampleExpectancyR = oos.expectancyR,
        )
    }
}
