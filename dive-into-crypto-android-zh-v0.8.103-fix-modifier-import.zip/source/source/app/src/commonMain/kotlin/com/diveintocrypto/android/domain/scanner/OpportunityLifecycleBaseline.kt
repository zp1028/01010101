package com.diveintocrypto.android.domain.scanner

/**
 * Holds the last trusted, fully completed lifecycle snapshot.
 * Provisional or partially failed scans may be displayed, but cannot replace this baseline.
 * This is display/risk-review state only; it never submits trades.
 */
class OpportunityLifecycleBaseline(
    initial: List<OpportunityLifecycle.Snapshot> = emptyList(),
) {
    private var trustedSnapshots: List<OpportunityLifecycle.Snapshot> = initial.toList()

    fun snapshot(): List<OpportunityLifecycle.Snapshot> = trustedSnapshots.toList()

    /** Returns true only when the baseline was promoted. */
    fun promoteIfComplete(
        snapshots: List<OpportunityLifecycle.Snapshot>,
        scanComplete: Boolean,
    ): Boolean {
        if (!scanComplete) return false
        trustedSnapshots = snapshots.toList()
        return true
    }
}
