package com.diveintocrypto.android.domain.scanner

/** Exchange-candle freshness guard for display-only risk plans.
 * Uses the candle open timestamp and its own timeframe, not the local fetch time.
 */
object MarketDataFreshness {
    enum class Status { FRESH, STALE, MISSING, INVALID }
    data class Assessment(val status: Status, val ageMs: Long?, val message: String)

    fun assess(candleOpenTimeMs: Long?, timeframeMs: Long?, nowMs: Long, graceMs: Long = 30_000L): Assessment {
        if (candleOpenTimeMs == null || timeframeMs == null || candleOpenTimeMs <= 0L || timeframeMs <= 0L) {
            return Assessment(Status.MISSING, null, "缺少行情时间戳，暂停显示参考价位")
        }
        val age = nowMs - candleOpenTimeMs
        if (age < -timeframeMs || age > timeframeMs * 2L + graceMs) {
            return Assessment(Status.STALE, age, "行情时间戳过期，暂停显示参考价位")
        }
        if (age < 0L) return Assessment(Status.INVALID, age, "行情时间戳晚于当前时间，请复核数据源")
        return Assessment(Status.FRESH, age, "行情时间戳在允许范围内")
    }
}
