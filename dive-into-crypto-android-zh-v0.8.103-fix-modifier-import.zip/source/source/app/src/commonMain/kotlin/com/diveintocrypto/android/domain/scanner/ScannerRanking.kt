package com.diveintocrypto.android.domain.scanner

import com.diveintocrypto.android.domain.model.Signal

/**
 * Pure ranking primitives shared by the live multi-TF universe scanner and any
 * historical scanner-replay path.
 *
 * These functions contain **no network, no ViewModel state, and no time source**.
 * Given the same per-(symbol, timeframe) analysis results they produce the same
 * phase-2 survivor set, per-TF top-N lists, and cross-rank order as the live
 * scanner. Overlay annotations (regime, accumulation, MTF confluence,
 * microstructure, whale divergence elimination) are intentionally left to the
 * caller so historical replay can mark missing auxiliary data instead of
 * inventing it.
 *
 * Contract (parity with ScannerViewModel algorithm comments):
 *  1. finalScore = confidence² × timeWeight / 100
 *  2. Phase-1 survivors = top [phase2Depth] symbols by Σ phase-1 finalScore
 *  3. Per-TF top-N = sort by finalScore desc, take N (live uses 15)
 *  4. Cross-rank netNss = |buyNss − sellNss| where buy/sell only sum finalScore
 *     of directional signals that appear in the supplied top-N sets
 *  5. Dominant direction is the larger of buyNss / sellNss; ties → NEUTRAL
 */
object ScannerRanking {

    /** Phase 1 covers the high-time-weight timeframes that filter the universe fast. */
    val PHASE1_TFS: List<String> = listOf("1d", "12h", "8h")

    /** Phase 2 covers the rest — only run against phase-1 survivors. */
    val PHASE2_TFS: List<String> = listOf(
        "1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h",
    )

    val ALL_TFS: List<String> = listOf(
        "1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "8h", "12h", "1d",
    )

    /**
     * Timeframe weights used by finalScore. Higher TF signals dominate ranking.
     * Must stay identical to the live scanner companion map.
     */
    val TIME_WEIGHTS: Map<String, Int> = mapOf(
        "1d" to 95, "12h" to 90, "8h" to 85, "6h" to 80, "4h" to 75,
        "2h" to 65, "1h" to 58, "30m" to 48, "15m" to 38, "5m" to 25,
        "3m" to 15, "1m" to 8,
    )

    val PERIOD_MS: Map<String, Long> = mapOf(
        "1m" to 60_000L, "3m" to 180_000L, "5m" to 300_000L, "15m" to 900_000L,
        "30m" to 1_800_000L, "1h" to 3_600_000L, "2h" to 7_200_000L,
        "4h" to 14_400_000L, "6h" to 21_600_000L, "8h" to 28_800_000L,
        "12h" to 43_200_000L, "1d" to 86_400_000L,
    )

    /** Live scanner keeps the top 15 per timeframe before cross-ranking. */
    const val DEFAULT_PER_TF_TOP_N: Int = 15

    /**
     * Score used for ranking and phase-1 aggregation.
     * Identical formula to the live scanner: confidence² × timeWeight / 100.
     */
    fun finalScore(confidence: Int, timeframe: String): Double {
        val weight = TIME_WEIGHTS[timeframe] ?: 50
        val c = confidence.toDouble()
        return (c * c * weight) / 100.0
    }

    fun finalScore(confidence: Int, timeWeight: Int): Double {
        val c = confidence.toDouble()
        return (c * c * timeWeight) / 100.0
    }

    /**
     * Minimal analysis cell needed for ranking. Callers map their richer
     * SymbolTfResult / historical evaluation into this structure.
     */
    data class RankCell(
        val symbol: String,
        val timeframe: String,
        val signal: Signal,
        val confidence: Int,
        val finalScore: Double,
        val price: Double = 0.0,
    )

    /**
     * Phase-2 survivor selection: aggregate phase-1 finalScore per symbol and
     * keep the top [depth] symbols (stable sort by score desc, then symbol).
     *
     * Only cells whose timeframe is in [PHASE1_TFS] contribute. Symbols with
     * zero phase-1 contribution are excluded.
     */
    fun selectPhase2Survivors(
        phase1Cells: List<RankCell>,
        depth: Int,
    ): List<String> {
        if (depth <= 0 || phase1Cells.isEmpty()) return emptyList()
        val scores = linkedMapOf<String, Double>()
        for (cell in phase1Cells) {
            if (cell.timeframe !in PHASE1_TFS) continue
            val key = cell.symbol.trim().uppercase()
            if (key.isEmpty()) continue
            scores[key] = (scores[key] ?: 0.0) + cell.finalScore
        }
        return scores.entries
            .sortedWith(
                compareByDescending<Map.Entry<String, Double>> { it.value }
                    .thenBy { it.key },
            )
            .take(depth.coerceAtLeast(1))
            .map { it.key }
    }

    /**
     * Per-timeframe top-N by finalScore descending (symbol ascending as tie-break).
     * Returns a map timeframe → ordered top-N cells.
     */
    fun perTfTopN(
        cells: List<RankCell>,
        n: Int = DEFAULT_PER_TF_TOP_N,
    ): Map<String, List<RankCell>> {
        if (n <= 0) return emptyMap()
        return cells
            .groupBy { it.timeframe }
            .mapValues { (_, list) ->
                list.sortedWith(
                    compareByDescending<RankCell> { it.finalScore }
                        .thenBy { it.symbol.uppercase() },
                ).take(n)
            }
    }

    data class CrossRankEntry(
        val symbol: String,
        val dominantDir: Signal,
        val netNss: Double,
        val buyNss: Double,
        val sellNss: Double,
        val countHit: Int,
        val bestConfidence: Int,
        val price: Double,
        /** Timeframes that contributed a top-N directional or neutral cell. */
        val hitTimeframes: Set<String>,
    )

    /**
     * Cross-rank aggregation over the per-TF top-N sets.
     *
     * For every symbol that appears in any top-N list:
     *  - buyNss  = Σ finalScore where signal ∈ {BUY, STRONG_BUY}
     *  - sellNss = Σ finalScore where signal ∈ {SELL, STRONG_SELL}
     *  - netNss  = |buy − sell|
     *  - dominantDir = side with the larger absolute contribution (NEUTRAL on tie)
     *
     * Result is sorted by netNss descending, then symbol ascending.
     * Neutral cells still increment countHit but add zero to either nss bucket.
     */
    fun crossRank(
        perTfTop: Map<String, List<RankCell>>,
        expectedTimeframes: Int = ALL_TFS.size,
    ): List<CrossRankEntry> {
        data class Acc(
            var buy: Double = 0.0,
            var sell: Double = 0.0,
            var hits: Int = 0,
            var bestConf: Int = 0,
            var price: Double = 0.0,
            val tfs: MutableSet<String> = mutableSetOf(),
        )

        val bySymbol = linkedMapOf<String, Acc>()
        for ((tf, cells) in perTfTop) {
            for (cell in cells) {
                val key = cell.symbol.trim().uppercase()
                if (key.isEmpty()) continue
                val acc = bySymbol.getOrPut(key) { Acc() }
                acc.hits += 1
                acc.tfs += tf
                when (cell.signal) {
                    Signal.STRONG_BUY, Signal.BUY -> acc.buy += cell.finalScore
                    Signal.STRONG_SELL, Signal.SELL -> acc.sell += cell.finalScore
                    Signal.NEUTRAL -> Unit
                }
                if (cell.confidence > acc.bestConf) {
                    acc.bestConf = cell.confidence
                    acc.price = cell.price
                }
            }
        }

        return bySymbol.entries
            .map { (symbol, acc) ->
                // Live scanner: dominant side is whichever nss sum is larger.
                // Strength (STRONG_*) is display detail from the best-confidence
                // TF and is not required for ranking parity.
                val dominant = when {
                    acc.buy > acc.sell && acc.buy > 0.0 -> Signal.BUY
                    acc.sell > acc.buy && acc.sell > 0.0 -> Signal.SELL
                    else -> Signal.NEUTRAL
                }
                CrossRankEntry(
                    symbol = symbol,
                    dominantDir = dominant,
                    netNss = kotlin.math.abs(acc.buy - acc.sell),
                    buyNss = acc.buy,
                    sellNss = acc.sell,
                    countHit = acc.hits,
                    bestConfidence = acc.bestConf,
                    price = acc.price,
                    hitTimeframes = acc.tfs.toSet(),
                )
            }
            .sortedWith(
                compareByDescending<CrossRankEntry> { it.netNss }
                    .thenBy { it.symbol },
            )
    }

    /**
     * Convenience: phase-1 cells → survivors → (caller supplies full cells for
     * survivors) → per-TF top-N → cross-rank. Useful for historical replay once
     * all RankCells at a cut time are known.
     */
    fun rankFromCells(
        allCells: List<RankCell>,
        phase2Depth: Int,
        perTfTopN: Int = DEFAULT_PER_TF_TOP_N,
    ): RankResult {
        val survivors = selectPhase2Survivors(
            phase1Cells = allCells.filter { it.timeframe in PHASE1_TFS },
            depth = phase2Depth,
        )
        val survivorSet = survivors.toSet()
        // Live path only runs phase-2 TFs on survivors; phase-1 results for the
        // whole universe remain. For ranking we keep every cell that either:
        //  - belongs to a phase-1 TF, or
        //  - belongs to a survivor symbol (phase-2 results).
        val rankingCells = allCells.filter { cell ->
            cell.timeframe in PHASE1_TFS || cell.symbol.trim().uppercase() in survivorSet
        }
        val top = perTfTopN(rankingCells, perTfTopN)
        val ranked = crossRank(top)
        return RankResult(
            phase2Survivors = survivors,
            perTfTop = top,
            crossRank = ranked,
        )
    }

    data class RankResult(
        val phase2Survivors: List<String>,
        val perTfTop: Map<String, List<RankCell>>,
        val crossRank: List<CrossRankEntry>,
    )
}
