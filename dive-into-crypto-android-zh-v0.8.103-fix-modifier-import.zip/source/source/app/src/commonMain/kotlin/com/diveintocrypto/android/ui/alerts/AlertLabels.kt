package com.diveintocrypto.android.ui.alerts

import com.diveintocrypto.android.domain.alerts.AlertKind
import com.diveintocrypto.android.domain.alerts.AlertRule
import com.diveintocrypto.android.platform.format
import com.diveintocrypto.android.ui.panel.components.ChartMath

/**
 * PURE alert-UI helpers (no Compose, no clock, no I/O — unit-tested in
 * commonTest): Turkish kind/direction labels, fired-history line building,
 * threshold parsing/formatting/stepping, and the honest ETA / universe labels
 * used by the Scanner depth row. The screens stay dumb renderers.
 */
object AlertLabels {

    // ── Kind / direction labels (TR, matching the app's label style) ──

    fun kindLabel(kind: AlertKind): String = when (kind) {
        AlertKind.VERDICT -> "裁决方向"
        AlertKind.CONFIDENCE_ABOVE -> "置信度高于"
        AlertKind.PRICE_ABOVE -> "价格高于"
        AlertKind.PRICE_BELOW -> "价格低于"
        AlertKind.OI_SPIKE_PCT -> "OI 激增"
    }

    fun directionLabel(direction: String): String = when (direction) {
        AlertRule.DIRECTION_ANY -> "全部"
        AlertRule.DIRECTION_LONG -> "LONG"
        AlertRule.DIRECTION_SHORT -> "SHORT"
        else -> direction
    }

    /**
     * One-line rule description for rule rows, fired history and the banner,
     * e.g. "做多裁决" · "置信度 ≥ 87" · "价格 ≥ 65000.00" · "OI ≥ +5%".
     * Reads the RULE config (not the English engine message) so history stays
     * readable even when the rule was deleted (null → kind label only).
     */
    fun ruleLineLabel(rule: AlertRule?): String {
        if (rule == null) return "规则已删除"
        return when (rule.kind) {
            AlertKind.VERDICT -> when (rule.direction) {
                AlertRule.DIRECTION_LONG -> "做多裁决"
                AlertRule.DIRECTION_SHORT -> "做空裁决"
                else -> "裁决 · 全部"
            }
            AlertKind.CONFIDENCE_ABOVE -> "置信度 ≥ ${rule.threshold.format(0)}"
            AlertKind.PRICE_ABOVE -> "价格 ≥ ${formatPrice(rule.threshold)}"
            AlertKind.PRICE_BELOW -> "价格 ≤ ${formatPrice(rule.threshold)}"
            AlertKind.OI_SPIKE_PCT -> "OI ≥ +${rule.threshold.format(0)}%"
        }
    }

    /** Price with magnitude-adaptive decimals (no grouping — parser-friendly). */
    fun formatPrice(value: Double): String = value.format(ChartMath.priceDecimalsFor(value))

    // ── Threshold parsing / stepping (add-sheet) ──────────────────────

    /**
     * Parses the threshold text field: trims, accepts ',' or '.' as the decimal
     * separator, rejects blank/NaN/infinite/negative-free garbage (null).
     */
    fun parseThreshold(raw: String): Double? {
        val cleaned = raw.trim().replace(',', '.')
        if (cleaned.isEmpty()) return null
        val v = cleaned.toDoubleOrNull() ?: return null
        if (v.isNaN() || v.isInfinite()) return null
        return v
    }

    /** Default threshold text when the user switches kind in the add-sheet. */
    fun defaultThresholdText(kind: AlertKind, livePrice: Double?): String = when (kind) {
        AlertKind.VERDICT -> "0"
        AlertKind.CONFIDENCE_ABOVE -> "60"
        AlertKind.OI_SPIKE_PCT -> "5"
        AlertKind.PRICE_ABOVE, AlertKind.PRICE_BELOW ->
            livePrice?.let { formatPrice(it) } ?: "0"
    }

    /**
     * Stepper increment per kind: confidence moves in 5-point steps, OI in
     * 1-point steps, price in magnitude-adaptive steps (0.0005 for a $0.003
     * coin up to 100 for a $20k coin).
     */
    fun priceStepFor(price: Double): Double = when {
        price <= 0.0 -> 1.0
        price < 0.01 -> 0.0005
        price < 0.1 -> 0.005
        price < 1.0 -> 0.05
        price < 10.0 -> 0.5
        price < 100.0 -> 1.0
        price < 1000.0 -> 10.0
        price < 10000.0 -> 50.0
        else -> 100.0
    }

    fun thresholdStepFor(kind: AlertKind, current: Double): Double = when (kind) {
        AlertKind.VERDICT -> 1.0
        AlertKind.CONFIDENCE_ABOVE -> 5.0
        AlertKind.OI_SPIKE_PCT -> 1.0
        AlertKind.PRICE_ABOVE, AlertKind.PRICE_BELOW -> priceStepFor(current)
    }

    /** Clamps a threshold into the kind's valid band (confidence 0..100 etc.). */
    fun clampThreshold(kind: AlertKind, value: Double): Double = when (kind) {
        AlertKind.VERDICT -> 0.0
        AlertKind.CONFIDENCE_ABOVE -> value.coerceIn(0.0, 100.0)
        AlertKind.OI_SPIKE_PCT -> value.coerceIn(0.0, 1000.0)
        AlertKind.PRICE_ABOVE, AlertKind.PRICE_BELOW -> value.coerceAtLeast(0.0)
    }

    /** A rule needs a positive threshold for every kind except VERDICT. */
    fun thresholdRequired(kind: AlertKind): Boolean = kind != AlertKind.VERDICT

    // ── Scanner depth row (honest ETA / universe labels) ─────────────

    /** "—" when null (not enough samples yet — never a fake 0). */
    fun etaLabel(seconds: Long?): String {
        if (seconds == null || seconds < 0) return "—"
        return when {
            seconds < 60 -> "~$seconds 秒"
            seconds < 3600 -> "~${(seconds + 59) / 60} 分钟"
            else -> "~${(seconds + 3599) / 3600} 小时"
        }
    }

    // ── v2: cooldown chips + condition summary ───────────────────────────

    /**
     * One cooldown chip preset. [coalesceMs] is the rule's re-fire window;
     * [oneShot] chips ignore it ("once" = auto-disable after first fire).
     */
    data class CooldownChip(val label: String, val coalesceMs: Long, val oneShot: Boolean)

    /** The 4 cooldown chips: 1 DK / 15 DK / 1 SA / TEK ATIŞ (engine constants). */
    val COOLDOWN_CHIPS: List<CooldownChip> = listOf(
        CooldownChip("1 分钟", AlertRule.COALESCE_1M, oneShot = false),
        CooldownChip("15 分钟", AlertRule.COALESCE_15M, oneShot = false),
        CooldownChip("1 小时", AlertRule.COALESCE_1H, oneShot = false),
        CooldownChip("一次性", coalesceMs = 0L, oneShot = true),
    )

    /** The chip matching a rule's cooldown config (default → the 1 DK chip). */
    fun selectedCooldownChip(oneShot: Boolean, coalesceMs: Long): CooldownChip =
        COOLDOWN_CHIPS.firstOrNull { chip ->
            chip.oneShot == oneShot && (oneShot || chip.coalesceMs == coalesceMs)
        } ?: COOLDOWN_CHIPS.first()

    /** Cooldown display for a rule: oneShot wins; unmatched windows render honestly ("N dk"). */
    fun cooldownLabel(oneShot: Boolean, coalesceMs: Long): String = when {
        oneShot -> "一次性"
        coalesceMs == AlertRule.COALESCE_1M -> "1 DK"
        coalesceMs == AlertRule.COALESCE_15M -> "15 DK"
        coalesceMs == AlertRule.COALESCE_1H -> "1 SA"
        coalesceMs > 0 -> "${coalesceMs / 60_000} dk"
        else -> "默认"
    }

    /**
     * One-line v2 summary for rule cards, e.g.
     * "2 条件 · 裁决方向(LONG)+置信度高于 · 15 DK". v1 rules (empty
     * [AlertRule.conditions]) fold into exactly ONE condition — migration is
     * display-only and automatic.
     */
    fun conditionSummaryLabel(rule: AlertRule): String {
        val conds = rule.effectiveConditions
        val kinds = conds.map { c ->
            val base = kindLabel(c.kind)
            if (c.kind == AlertKind.VERDICT && c.direction != AlertRule.DIRECTION_ANY) {
                "$base(${directionLabel(c.direction)})"
            } else base
        }
        val shown = if (kinds.size > 2) {
            kinds.take(2).joinToString("+") + "+${kinds.size - 2}"
        } else kinds.joinToString("+")
        return "${conds.size} 条件 · $shown · ${cooldownLabel(rule.oneShot, rule.coalesceMs)}"
    }

    /** [ScanUniverseMode] label → display ("ALL" → "全部"); unknown passes through. */
    fun universeLabel(mode: String): String = if (mode == "ALL") "全部" else mode

    /** true for the full-universe mode (inline "约500个交易对 · 需数分钟" warning). */
    fun isFullUniverse(mode: String): Boolean = mode == "ALL"
}
