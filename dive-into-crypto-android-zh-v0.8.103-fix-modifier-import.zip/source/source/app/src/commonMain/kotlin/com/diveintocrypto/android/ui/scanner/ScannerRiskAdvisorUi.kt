package com.diveintocrypto.android.ui.scanner

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.diveintocrypto.android.platform.format
import com.diveintocrypto.android.platform.nowMillis
import com.diveintocrypto.android.ui.theme.DiveColors
import com.diveintocrypto.android.ui.theme.DiveFonts

/**
 * 风险计划参考卡（展示层；不自动下单）。
 * 从 ScannerScreen 抽出以降乱。
 */

@Composable
internal fun RiskAdvisorBlock(
    entryPrice: Double,
    atrPct: Double,
    supportPrice: Double? = null,
    resistancePrice: Double? = null,
    marketDataOpenTimeMs: Long? = null,
    marketDataTimeframeMs: Long? = null,
    direction: com.diveintocrypto.android.domain.scanner.RiskPlanCalculator.Direction?,
    blockedByMtfConflict: Boolean = false,
    lifecycleStatus: String = "NEW",
    eligibilityStatus: String = "NO_DIRECTION",
    targetR: Double = 1.5,
    feeSidePct: Double = 0.05,
    slippageSidePct: Double = 0.02,
    onTargetRChange: (Double) -> Unit = {},
    onFeeSidePctChange: (Double) -> Unit = {},
    onSlippageSidePctChange: (Double) -> Unit = {},
    /** When set, risk panel shows AI-authored levels instead of local structure engine. */
    aiOverrideEntry: Double? = null,
    aiOverrideStop: Double? = null,
    aiOverrideTarget: Double? = null,
    planSourceLabel: String = "本地计划",
) {
    // atrPct is expressed in percentage points (e.g. 1.2 means 1.2%). Convert it
    // to quote-price units before invoking the shared domain calculator.
    val atrPrice = entryPrice * atrPct / 100.0
    // Freshness uses wall clock; recompute each composition is cheap vs structure math.
    val freshness = com.diveintocrypto.android.domain.scanner.MarketDataFreshness.assess(
        candleOpenTimeMs = marketDataOpenTimeMs,
        timeframeMs = marketDataTimeframeMs,
        nowMs = nowMillis(),
    )
    val recovery = remember(freshness.status, lifecycleStatus, eligibilityStatus, blockedByMtfConflict) {
        com.diveintocrypto.android.domain.scanner.RiskPlanRecoveryPolicy.evaluate(
            freshness = freshness.status,
            lifecycleStatus = lifecycleStatus,
            eligibilityStatus = eligibilityStatus,
            blockedByMtfConflict = blockedByMtfConflict,
        )
    }
    val planAllowed = recovery.allowReferenceLevels
    // Heavy structure / cost / scenario math is keyed so LazyColumn scroll does not
    // recompute every frame when inputs are unchanged.
    val plan = remember(planAllowed, direction, entryPrice, atrPrice, targetR, supportPrice, resistancePrice) {
        if (!planAllowed) null
        else direction?.let {
            com.diveintocrypto.android.domain.scanner.StructureAwareRiskPlan.calculate(
                com.diveintocrypto.android.domain.scanner.StructureAwareRiskPlan.Inputs(
                    direction = it,
                    entry = entryPrice,
                    atr = atrPrice,
                    atrMultiplier = 2.5,
                    targetR = targetR,
                    structureStop = when (it) {
                        com.diveintocrypto.android.domain.scanner.RiskPlanCalculator.Direction.LONG -> supportPrice
                        com.diveintocrypto.android.domain.scanner.RiskPlanCalculator.Direction.SHORT -> resistancePrice
                    },
                ),
            ).plan
        }
    }
    val useAiLevels = aiOverrideEntry != null && aiOverrideStop != null && aiOverrideTarget != null &&
        aiOverrideEntry!! > 0.0 && aiOverrideStop!! > 0.0 && aiOverrideTarget!! > 0.0
    val displayEntry = if (useAiLevels) aiOverrideEntry!! else (plan?.entry ?: entryPrice)
    val displayStop = if (useAiLevels) aiOverrideStop!! else plan?.stopLoss
    val displayTarget = if (useAiLevels) aiOverrideTarget!! else plan?.takeProfit
    val stopPct = if (useAiLevels) {
        kotlin.math.abs(displayEntry - displayStop!!) / displayEntry * 100.0
    } else {
        plan?.stopDistancePercent ?: (2.5 * atrPct)
    }
    val targetPct = if (useAiLevels) {
        kotlin.math.abs(displayTarget!! - displayEntry) / displayEntry * 100.0
    } else {
        plan?.let { it.rewardPerUnit / it.entry * 100.0 } ?: (stopPct * targetR)
    }
    val costEstimate = remember(plan, direction, feeSidePct, slippageSidePct) {
        plan?.let { currentPlan ->
            direction?.let { planDirection ->
                com.diveintocrypto.android.domain.scanner.RiskCostCalculator.estimate(
                    stopDistancePct = currentPlan.stopDistancePercent,
                    targetDistancePct = currentPlan.rewardPerUnit / currentPlan.entry * 100.0,
                    feeSidePct = feeSidePct,
                    slippageSidePct = slippageSidePct,
                    direction = planDirection,
                )
            }
        }
    }
    val netRr = costEstimate?.netRiskRewardRatio
    val scenarioComparisons = remember(planAllowed, direction, entryPrice, atrPrice, feeSidePct, slippageSidePct, supportPrice, resistancePrice) {
        if (!planAllowed) emptyList()
        else direction?.let { planDirection ->
            com.diveintocrypto.android.domain.scanner.RiskPlanScenarios.evaluate(
                direction = planDirection,
                entry = entryPrice,
                atr = atrPrice,
                feeSidePct = feeSidePct,
                slippageSidePct = slippageSidePct,
                structureStop = when (planDirection) {
                    com.diveintocrypto.android.domain.scanner.RiskPlanCalculator.Direction.LONG -> supportPrice
                    com.diveintocrypto.android.domain.scanner.RiskPlanCalculator.Direction.SHORT -> resistancePrice
                },
            )
        }.orEmpty()
    }
    val riskAssessment = remember(lifecycleStatus, eligibilityStatus, netRr, plan != null) {
        com.diveintocrypto.android.domain.scanner.RiskPlanAssessment.assess(
            lifecycleStatus = lifecycleStatus,
            eligibilityStatus = eligibilityStatus,
            netRiskRewardRatio = netRr,
            planAvailable = plan != null,
        )
    }
    var sizingEquity by rememberSaveable { mutableStateOf(15.0) }
    var sizingRiskPct by rememberSaveable { mutableStateOf(1.0) }
    var sizingLeverage by rememberSaveable { mutableStateOf(5.0) }
    val positionRisk = remember(plan, sizingEquity, sizingRiskPct, sizingLeverage, costEstimate?.stopPathCostPct) {
        plan?.let { currentPlan ->
            com.diveintocrypto.android.domain.scanner.PositionRiskCalculator.calculate(
                equity = sizingEquity,
                riskPct = sizingRiskPct,
                entryPrice = currentPlan.entry,
                stopPrice = currentPlan.stopLoss,
                leverage = sizingLeverage,
                stopPathCostPct = costEstimate?.stopPathCostPct ?: 0.0,
            )
        }
    }
    val amber = DiveColors.Warn
    var detailsExpanded by rememberSaveable { mutableStateOf(false) }
    val assessmentColor = if (freshness.status != com.diveintocrypto.android.domain.scanner.MarketDataFreshness.Status.FRESH) {
        amber
    } else when (riskAssessment.level) {
        com.diveintocrypto.android.domain.scanner.RiskPlanAssessment.Level.INVALID,
        com.diveintocrypto.android.domain.scanner.RiskPlanAssessment.Level.HOLD,
        com.diveintocrypto.android.domain.scanner.RiskPlanAssessment.Level.CAUTION -> DiveColors.Warn
        com.diveintocrypto.android.domain.scanner.RiskPlanAssessment.Level.REVIEW -> DiveColors.TextMuted
    }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(DiveColors.BgCardHover)
            .border(1.dp, DiveColors.Border, RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        // ── Header: title + status chip + short disclaimer ──
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = "风险计划",
                color = amber,
                fontSize = 11.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 0.6.sp,
                fontFamily = DiveFonts.body,
            )
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(assessmentColor.copy(alpha = 0.18f))
                    .padding(horizontal = 6.dp, vertical = 2.dp),
            ) {
                Text(riskAssessment.label, color = assessmentColor, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.weight(1f))
            Text("仅供参考", color = DiveColors.TextDim, fontSize = 10.sp)
        }

        if (freshness.status != com.diveintocrypto.android.domain.scanner.MarketDataFreshness.Status.FRESH) {
            Text("行情：${freshness.message}", color = amber, fontSize = 10.sp, lineHeight = 13.sp)
        }

        if (plan != null || useAiLevels) {
            val side = if (direction == com.diveintocrypto.android.domain.scanner.RiskPlanCalculator.Direction.LONG) "多" else "空"
            val stopSource = if (
                (direction == com.diveintocrypto.android.domain.scanner.RiskPlanCalculator.Direction.LONG && supportPrice != null) ||
                (direction == com.diveintocrypto.android.domain.scanner.RiskPlanCalculator.Direction.SHORT && resistancePrice != null)
            ) "结构+ATR" else "ATR"

            // ── Primary: ENTRY / SL / TP grid ──
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                RiskPriceCell(label = "${side}入场", value = displayEntry.format(6), accent = DiveColors.Text, modifier = Modifier.weight(1f))
                RiskPriceCell(label = "止损", value = (displayStop ?: plan?.stopLoss ?: 0.0).format(6), accent = Color(0xFFCC6666), modifier = Modifier.weight(1f))
                RiskPriceCell(label = "止盈", value = (displayTarget ?: plan?.takeProfit ?: 0.0).format(6), accent = Color(0xFF66BB88), modifier = Modifier.weight(1f))
            }

            // ── Primary metrics row ──
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                RiskMetricChip("风险", "${stopPct.format(2)}%")
                RiskMetricChip("毛 R:R", "${(if (useAiLevels && stopPct > 0) targetPct / stopPct else plan?.riskRewardRatio ?: 0.0).format(2)}:1")
                RiskMetricChip("净 R:R", netRr?.let { "${it.format(2)}:1" } ?: "—")
                RiskMetricChip("成本", "${costEstimate?.roundTripCostPct?.format(2) ?: "—"}%")
            }

            // ── Target R (most-used control, always visible) ──
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("目标 R", color = DiveColors.TextMuted, fontSize = 10.sp)
                TextButton(
                    onClick = { onTargetRChange((targetR - 0.25).coerceAtLeast(0.5)) },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                ) { Text("−", fontSize = 13.sp) }
                Text("${targetR.format(2)}R", color = DiveColors.Text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                TextButton(
                    onClick = { onTargetRChange((targetR + 0.25).coerceAtMost(5.0)) },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                ) { Text("+", fontSize = 13.sp) }
                Spacer(Modifier.weight(1f))
                Text(if (useAiLevels) "止损 来源：AI方案 · $planSourceLabel" else "止损 $stopSource", color = DiveColors.TextDim, fontSize = 10.sp)
            }

            // ── Expandable details ──
            TextButton(
                onClick = { detailsExpanded = !detailsExpanded },
                contentPadding = PaddingValues(horizontal = 0.dp, vertical = 0.dp),
            ) {
                Text(
                    if (detailsExpanded) "收起详细设置 ▴" else "详细设置 · 仓位 / 成本 / 方案 ▾",
                    color = DiveColors.Accent,
                    fontSize = 11.sp,
                )
            }
            if (detailsExpanded) {
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(
                        "结构：支撑 ${supportPrice?.format(6) ?: "—"} · 压力 ${resistancePrice?.format(6) ?: "—"} · 目标 ${targetPct.format(2)}%",
                        color = DiveColors.TextMuted,
                        fontSize = 10.sp,
                        lineHeight = 13.sp,
                    )
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("手续费 ${feeSidePct.format(3)}%", color = DiveColors.TextMuted, fontSize = 10.sp)
                        TextButton(onClick = { onFeeSidePctChange((feeSidePct - 0.01).coerceAtLeast(0.0)) }, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)) { Text("−", fontSize = 11.sp) }
                        TextButton(onClick = { onFeeSidePctChange((feeSidePct + 0.01).coerceAtMost(1.0)) }, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)) { Text("+", fontSize = 11.sp) }
                        Spacer(Modifier.width(6.dp))
                        Text("滑点 ${slippageSidePct.format(3)}%", color = DiveColors.TextMuted, fontSize = 10.sp)
                        TextButton(onClick = { onSlippageSidePctChange((slippageSidePct - 0.01).coerceAtLeast(0.0)) }, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)) { Text("−", fontSize = 11.sp) }
                        TextButton(onClick = { onSlippageSidePctChange((slippageSidePct + 0.01).coerceAtMost(2.0)) }, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)) { Text("+", fontSize = 11.sp) }
                    }
                    Text("持仓估算（只影响本卡数字，不代表交易所参数）", color = DiveColors.Text, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("权益 ${sizingEquity.format(0)}", color = DiveColors.TextMuted, fontSize = 10.sp)
                        TextButton(onClick = { sizingEquity = (sizingEquity - 5.0).coerceAtLeast(5.0) }, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)) { Text("−", fontSize = 11.sp) }
                        TextButton(onClick = { sizingEquity = (sizingEquity + 5.0).coerceAtMost(100000.0) }, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)) { Text("+", fontSize = 11.sp) }
                        Text("风险 ${sizingRiskPct.format(1)}%", color = DiveColors.TextMuted, fontSize = 10.sp)
                        TextButton(onClick = { sizingRiskPct = (sizingRiskPct - 0.25).coerceAtLeast(0.25) }, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)) { Text("−", fontSize = 11.sp) }
                        TextButton(onClick = { sizingRiskPct = (sizingRiskPct + 0.25).coerceAtMost(5.0) }, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)) { Text("+", fontSize = 11.sp) }
                        Text("${sizingLeverage.format(0)}×", color = DiveColors.TextMuted, fontSize = 10.sp)
                        TextButton(onClick = { sizingLeverage = (sizingLeverage - 1.0).coerceAtLeast(1.0) }, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)) { Text("−", fontSize = 11.sp) }
                        TextButton(onClick = { sizingLeverage = (sizingLeverage + 1.0).coerceAtMost(125.0) }, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)) { Text("+", fontSize = 11.sp) }
                    }
                    if (positionRisk != null) {
                        Text(
                            "预算 ${positionRisk.riskBudget.format(2)} · 名义上限 ${positionRisk.maxNotional.format(1)} · 保证金 ${positionRisk.requiredInitialMargin.format(1)} · 止损亏约 ${positionRisk.estimatedStopLoss.format(2)}",
                            color = DiveColors.TextMuted,
                            fontSize = 10.sp,
                            lineHeight = 13.sp,
                        )
                        positionRisk.warning?.let {
                            Text(it, color = DiveColors.Warn, fontSize = 10.sp, lineHeight = 13.sp)
                        }
                    }
                    if (scenarioComparisons.isNotEmpty()) {
                        Text("方案对比", color = DiveColors.Text, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                        scenarioComparisons.forEach { scenario ->
                            val scenarioPlan = scenario.plan
                            Text(
                                text = if (scenarioPlan == null) {
                                    "${scenario.profile.label}：不可用（${scenario.reason ?: "数据不足"}）"
                                } else {
                                    "${scenario.profile.label} · ${scenario.profile.targetR.format(1)}R · SL ${scenarioPlan.stopLoss.format(6)} · TP ${scenarioPlan.takeProfit.format(6)} · 净R ${scenario.netRiskRewardRatio?.format(2) ?: "—"}"
                                },
                                color = if (scenarioPlan == null || scenario.netRiskRewardRatio == null) DiveColors.Warn else DiveColors.TextMuted,
                                fontSize = 10.sp,
                                lineHeight = 13.sp,
                            )
                        }
                    }
                    Text(
                        "净 R:R 含手续费 ${feeSidePct.format(3)}% + 滑点 ${slippageSidePct.format(3)}%；未计资金费率与强平。",
                        color = DiveColors.TextDim,
                        fontSize = 9.sp,
                        lineHeight = 12.sp,
                    )
                }
            }
        } else {
            Text(
                text = when {
                    lifecycleStatus == "DATA_INVALID" -> "行情或方向数据无效，已隐藏止损/止盈；请重新扫描。"
                    lifecycleStatus == "DIRECTION_REVERSED" -> "信号方向已反转，旧计划已失效；请按新信号重新评估。"
                    lifecycleStatus == "PRICE_MOVED" -> "参考价变化较大，旧计划已隐藏；刷新后重新计算。"
                    blockedByMtfConflict -> "多周期方向冲突，暂不生成止损/止盈。"
                    else -> "方向不明确，暂无计划。ATR ${atrPct.format(2)}%"
                },
                color = DiveColors.TextMuted,
                fontSize = 11.sp,
                lineHeight = 14.sp,
            )
            if (recovery.message.isNotBlank()) {
                Text(recovery.message, color = assessmentColor, fontSize = 10.sp, lineHeight = 13.sp)
            }
        }
    }
}

@Composable
internal fun RiskPriceCell(label: String, value: String, accent: Color, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(DiveColors.BgCard)
            .padding(horizontal = 6.dp, vertical = 6.dp),
    ) {
        Text(label, color = DiveColors.TextMuted, fontSize = 10.sp)
        Text(value, color = accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
internal fun RiskMetricChip(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = DiveColors.TextDim, fontSize = 9.sp)
        Text(value, color = DiveColors.Text, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}
