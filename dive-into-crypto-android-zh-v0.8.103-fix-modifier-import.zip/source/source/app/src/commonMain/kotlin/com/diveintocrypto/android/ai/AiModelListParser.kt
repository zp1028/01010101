package com.diveintocrypto.android.ai

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

/** Parses common OpenAI-compatible model-list response shapes without network/UI dependencies. */
object AiModelListParser {
    private val json = Json { ignoreUnknownKeys = true }
    private val arrayKeys = listOf("data", "models", "items", "result")
    private val idKeys = listOf("id", "model", "name")

    fun parse(body: String): List<String> {
        val root = try {
            json.parseToJsonElement(body)
        } catch (error: Exception) {
            throw IllegalArgumentException("模型接口返回的不是有效 JSON", error)
        }
        val array = findModelArray(root)
            ?: throw IllegalArgumentException("接口已响应，但未找到 data/models/items/result 模型数组")
        return array.mapNotNull(::modelId)
            .map(String::trim)
            .filter(String::isNotBlank)
            .distinct()
            .sorted()
    }

    private fun findModelArray(element: JsonElement, depth: Int = 0): JsonArray? {
        if (element is JsonArray) return element
        if (depth >= 3 || element !is JsonObject) return null
        // Some gateways return several synonymous fields, e.g. an empty `data`
        // array alongside the actual populated `models` array. Prefer a populated
        // candidate and only return an empty array when no populated candidate exists.
        var emptyCandidate: JsonArray? = null
        for (key in arrayKeys) {
            val child = element[key] ?: continue
            val direct = runCatching { child.jsonArray }.getOrNull()
            if (direct != null) {
                if (direct.isNotEmpty()) return direct
                if (emptyCandidate == null) emptyCandidate = direct
                continue
            }
            val nested = findModelArray(child, depth + 1)
            if (nested != null) {
                if (nested.isNotEmpty()) return nested
                if (emptyCandidate == null) emptyCandidate = nested
            }
        }
        return emptyCandidate
    }

    private fun modelId(element: JsonElement): String? {
        return when (element) {
            is JsonObject -> idKeys.firstNotNullOfOrNull { key ->
                element[key]
                    ?.let { value -> runCatching { value.jsonPrimitive.content }.getOrNull() }
                    ?.trim()
                    ?.takeIf(String::isNotBlank)
            }
            else -> runCatching { element.jsonPrimitive.content }.getOrNull()
        }
    }
}
