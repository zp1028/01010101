package com.diveintocrypto.android.domain.scanner

import kotlin.math.abs

/** Structure-aware, reference-only risk plans. No order execution is performed. */
object StructureAwareRiskPlan {
    data class Inputs(
        val direction: RiskPlanCalculator.Direction,
        val entry: Double,
        val atr: Double,
        val atrMultiplier: Double,
        val targetR: Double,
        /** Confirmed support for LONG or resistance for SHORT; null means unavailable. */
        val structureStop: Double? = null,
        /** Buffer beyond the structure level, expressed as a multiple of ATR. */
        val structureBufferAtr: Double = 0.15,
    )

    data class Result(
        val plan: RiskPlanCalculator.Plan?,
        val stopSource: StopSource,
        val reason: String? = null,
    ) {
        val valid: Boolean get() = plan != null && reason == null
    }

    enum class StopSource { ATR_ONLY, STRUCTURE_AND_ATR }

    fun calculate(input: Inputs): Result {
        val entry = input.entry
        val atr = input.atr
        if (!entry.isFinite() || entry <= 0.0) return Result(null, StopSource.ATR_ONLY, "invalid_entry")
        if (!atr.isFinite() || atr <= 0.0) return Result(null, StopSource.ATR_ONLY, "invalid_atr")
        if (!input.atrMultiplier.isFinite() || input.atrMultiplier <= 0.0) return Result(null, StopSource.ATR_ONLY, "invalid_atr_multiplier")
        if (!input.targetR.isFinite() || input.targetR <= 0.0) return Result(null, StopSource.ATR_ONLY, "invalid_target_r")
        if (!input.structureBufferAtr.isFinite() || input.structureBufferAtr < 0.0) return Result(null, StopSource.ATR_ONLY, "invalid_structure_buffer")

        val atrStop = when (input.direction) {
            RiskPlanCalculator.Direction.LONG -> entry - atr * input.atrMultiplier
            RiskPlanCalculator.Direction.SHORT -> entry + atr * input.atrMultiplier
        }
        if (!atrStop.isFinite() || atrStop <= 0.0) return Result(null, StopSource.ATR_ONLY, "invalid_atr_stop")

        val structureStop = input.structureStop
        val bufferedStructureStop = structureStop
            ?.takeIf { it.isFinite() && it > 0.0 }
            ?.let { level ->
                when (input.direction) {
                    RiskPlanCalculator.Direction.LONG -> level - atr * input.structureBufferAtr
                    RiskPlanCalculator.Direction.SHORT -> level + atr * input.structureBufferAtr
                }
            }
        // A missing, malformed, or directionally invalid structure level must not
        // suppress an otherwise valid ATR plan. Use structure only when its buffered
        // stop is on the correct side of entry; otherwise fall back to ATR-only.
        val usableStructureStop = bufferedStructureStop?.takeIf { buffered ->
            buffered.isFinite() && when (input.direction) {
                RiskPlanCalculator.Direction.LONG -> buffered < entry
                RiskPlanCalculator.Direction.SHORT -> buffered > entry
            }
        }
        val chosenStop = when {
            usableStructureStop == null -> atrStop
            input.direction == RiskPlanCalculator.Direction.LONG -> minOf(atrStop, usableStructureStop)
            else -> maxOf(atrStop, usableStructureStop)
        }
        val stopSource = if (usableStructureStop == null) StopSource.ATR_ONLY else StopSource.STRUCTURE_AND_ATR
        val riskDistance = abs(entry - chosenStop)
        if (!riskDistance.isFinite() || riskDistance <= 0.0 || riskDistance >= entry) {
            return Result(null, stopSource, "invalid_combined_stop_distance")
        }
        val rewardDistance = riskDistance * input.targetR
        val target = when (input.direction) {
            RiskPlanCalculator.Direction.LONG -> entry + rewardDistance
            RiskPlanCalculator.Direction.SHORT -> entry - rewardDistance
        }
        if (!target.isFinite() || target <= 0.0) return Result(null, stopSource, "invalid_target")

        return Result(
            plan = RiskPlanCalculator.Plan(
                entry = entry,
                stopLoss = chosenStop,
                takeProfit = target,
                riskPerUnit = riskDistance,
                rewardPerUnit = rewardDistance,
                riskRewardRatio = rewardDistance / riskDistance,
                stopDistancePercent = riskDistance / entry * 100.0,
            ),
            stopSource = stopSource,
        )
    }
}
