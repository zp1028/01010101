package com.diveintocrypto.android.domain.scanner

import com.diveintocrypto.android.data.SettingsStore
import com.diveintocrypto.android.domain.model.Candle
import com.diveintocrypto.android.platform.synchronized
import kotlinx.atomicfu.locks.SynchronizedObject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import kotlin.math.abs

/** Persisted, append-only history around immutable forward-plan snapshots. */
@Serializable
data class ForwardPlanEvent(
    val planId: String,
    val atMs: Long,
    val fromStatus: String,
    val toStatus: String,
    val reason: String,
    val observedPrice: Double? = null,
    val closedCandleTimeMs: Long? = null,
)

@Serializable
data class TrackedForwardPlan(
    val snapshot: ForwardEntryPlanEngine.Plan,
    val status: ForwardEntryPlanEngine.Status = snapshot.status,
    val lastEvaluatedAtMs: Long = snapshot.generatedAtMs,
    val lastObservedPrice: Double? = null,
    val lastClosedCandleTimeMs: Long? = null,
    val archived: Boolean = false,
)

/** Immutable, separately versioned AI proposal. It never mutates the original local plan snapshot. */
@Serializable
data class ForwardPlanRevision(
    val revisionId: String,
    val planId: String,
    val version: Int,
    val createdAtMs: Long,
    val source: String = "AI_FUSION",
    val entry: Double,
    val stop: Double,
    val target: Double,
    val riskRewardRatio: Double,
    val rationale: String,
)

@Serializable
data class ForwardPlanReplayRecord(
    val planId: String,
    val outcome: String,
    val evaluatedThroughMs: Long,
    val candlesConsidered: Int,
    val firstOutcomeCandleCloseMs: Long? = null,
    val netR: Double? = null,
    val notes: List<String> = emptyList(),
    val savedAtMs: Long,
    /** Coverage classification is not a trade outcome; defaults preserve old journal compatibility. */
    val coverageStatus: String = "UNKNOWN",
)

@Serializable
data class ForwardReplayCandle(
    val openTime: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double,
    val closeTime: Long,
) {
    fun toCandle() = Candle(openTime, open, high, low, close, volume, closeTime)
    companion object { fun from(c: Candle) = ForwardReplayCandle(c.openTime, c.open, c.high, c.low, c.close, c.volume, c.closeTime) }
}

/** Durable page cursor plus accumulated candles for resumable replay after app/network restarts. */
@Serializable
data class ForwardReplayProgress(
    val planId: String,
    val windowStartMs: Long,
    val windowEndMs: Long,
    val nextCursorMs: Long,
    val candles: List<ForwardReplayCandle> = emptyList(),
    val updatedAtMs: Long,
    val complete: Boolean = false,
    val noProgressPages: Int = 0,
)

@Serializable
data class ForwardPlanJournalData(
    val schemaVersion: Int = 4,
    val plans: List<TrackedForwardPlan> = emptyList(),
    val events: List<ForwardPlanEvent> = emptyList(),
    val revisions: List<ForwardPlanRevision> = emptyList(),
    val replayResults: List<ForwardPlanReplayRecord> = emptyList(),
    val replayProgress: List<ForwardReplayProgress> = emptyList(),
)

/**
 * Small JSON-backed journal using the app's existing SettingsStore. Original plan snapshots
 * are never rewritten; only the tracked lifecycle envelope changes. Trigger confirmation is
 * accepted only from a later, explicitly closed candle supplied by the caller.
 */
class ForwardPlanJournal(private val settingsStore: SettingsStore) {
    companion object {
        const val KEY = "forward_plan_journal_v1"
        const val MAX_PLANS = 160
        const val MAX_EVENTS = 500
        const val MAX_REPLAY_RESULTS = 1000
        const val MAX_PROGRESS_PLANS = 24
        const val MAX_CANDLES_PER_PROGRESS = 5000
        private const val DEDUPE_TRIGGER_PCT = 0.20
        val ACTIVE_STATUSES = setOf(ForwardEntryPlanEngine.Status.PREPARING, ForwardEntryPlanEngine.Status.WAITING_TRIGGER)
        val VISIBLE_STATUSES = ACTIVE_STATUSES + ForwardEntryPlanEngine.Status.CONDITION_MET
    }

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val lock = SynchronizedObject()
    private val _data = MutableStateFlow(load())
    val data: StateFlow<ForwardPlanJournalData> = _data.asStateFlow()

    /** Add new immutable snapshots; retain an existing active snapshot for near-identical setups. */
    fun mergeCandidates(candidates: List<ForwardEntryPlanEngine.Plan>, nowMs: Long) = synchronized(lock) {
        var current = _data.value
        val plans = current.plans.toMutableList()
        val events = current.events.toMutableList()
        candidates.forEach { candidate ->
            val equivalent = plans.firstOrNull { tracked ->
                !tracked.archived && tracked.status in VISIBLE_STATUSES &&
                    tracked.snapshot.symbol == candidate.symbol &&
                    tracked.snapshot.direction == candidate.direction &&
                    tracked.snapshot.type == candidate.type &&
                    tracked.snapshot.primaryTimeframe == candidate.primaryTimeframe &&
                    abs(tracked.snapshot.triggerPrice - candidate.triggerPrice) /
                        candidate.referencePrice.coerceAtLeast(1e-12) * 100.0 <= DEDUPE_TRIGGER_PCT
            }
            if (equivalent == null && plans.none { it.snapshot.id == candidate.id }) {
                plans.add(0, TrackedForwardPlan(candidate))
                events.add(ForwardPlanEvent(candidate.id, nowMs, "NONE", candidate.status.name, "创建不可变计划快照", candidate.referencePrice))
            }
        }
        val pruned = plans.sortedByDescending { it.snapshot.generatedAtMs }.take(MAX_PLANS)
        val keepIds = pruned.map { it.snapshot.id }.toSet()
        current = ForwardPlanJournalData(
            schemaVersion = 4,
            plans = pruned,
            events = events.filter { it.planId in keepIds }.takeLast(MAX_EVENTS),
            revisions = current.revisions.filter { it.planId in keepIds }.takeLast(MAX_EVENTS),
            replayResults = current.replayResults.filter { it.planId in keepIds }.takeLast(MAX_REPLAY_RESULTS),
            replayProgress = current.replayProgress.filter { it.planId in keepIds }.takeLast(MAX_PROGRESS_PLANS),
        )
        publish(current)
    }

    /**
     * Append a guarded AI proposal as a new immutable version. The local plan remains the
     * authority and is never overwritten. A proposal must match the plan direction, stay close
     * to the reference price, and provide a valid minimum risk/reward ratio.
     */
    fun appendAiRevision(
        planId: String,
        entry: Double?,
        stop: Double?,
        target: Double?,
        createdAtMs: Long,
        rationale: String,
        maxEntryDriftPct: Double = 1.5,
    ): ForwardPlanRevision? = synchronized(lock) {
        val current = _data.value
        val tracked = current.plans.firstOrNull { it.snapshot.id == planId } ?: return@synchronized null
        val plan = tracked.snapshot
        val e = entry?.takeIf { it.isFinite() && it > 0.0 } ?: return@synchronized null
        val sl = stop?.takeIf { it.isFinite() && it > 0.0 } ?: return@synchronized null
        val tp = target?.takeIf { it.isFinite() && it > 0.0 } ?: return@synchronized null
        if (tracked.status !in ACTIVE_STATUSES || createdAtMs < plan.generatedAtMs || createdAtMs >= plan.expiresAtMs) return@synchronized null
        if (kotlin.math.abs(e - plan.referencePrice) / plan.referencePrice * 100.0 > maxEntryDriftPct) return@synchronized null
        val directional = if (plan.direction == ForwardEntryPlanEngine.Direction.LONG) sl < e && tp > e else sl > e && tp < e
        if (!directional) return@synchronized null
        val risk = kotlin.math.abs(e - sl)
        val reward = kotlin.math.abs(tp - e)
        if (risk <= 0.0 || !risk.isFinite() || !reward.isFinite() || reward / risk < 1.2) return@synchronized null
        val rr = reward / risk
        val fingerprint = listOf(planId, e.toString(), sl.toString(), tp.toString()).joinToString("|")
        if (current.revisions.any { it.revisionId == fingerprint }) return@synchronized current.revisions.first { it.revisionId == fingerprint }
        val version = (current.revisions.filter { it.planId == planId }.maxOfOrNull { it.version } ?: 0) + 1
        val revision = ForwardPlanRevision(
            revisionId = fingerprint, planId = planId, version = version, createdAtMs = createdAtMs,
            entry = e, stop = sl, target = tp, riskRewardRatio = rr,
            rationale = rationale.take(600),
        )
        publish(current.copy(schemaVersion = 4, revisions = (current.revisions + revision).takeLast(MAX_EVENTS)))
        revision
    }

    /**
     * Evaluate a plan with live price and (optionally) a confirmed closed candle. A ticker tick
     * alone can never move a plan to CONDITION_MET. Old/out-of-order candle observations are ignored.
     */
    fun observe(
        planId: String,
        price: Double,
        atMs: Long,
        closedCandleClose: Double? = null,
        closedCandleTimeMs: Long? = null,
    ) = synchronized(lock) {
        if (!price.isFinite() || price <= 0.0 || atMs <= 0L) return@synchronized
        val current = _data.value
        val index = current.plans.indexOfFirst { it.snapshot.id == planId }
        if (index < 0) return@synchronized
        val tracked = current.plans[index]
        if (tracked.status !in VISIBLE_STATUSES || atMs < tracked.lastEvaluatedAtMs) return@synchronized
        val plan = tracked.snapshot
        var next = tracked.status
        var reason: String? = null
        val movePct = abs(price - plan.referencePrice) / plan.referencePrice * 100.0
        when {
            atMs >= plan.expiresAtMs -> { next = ForwardEntryPlanEngine.Status.EXPIRED; reason = "计划超过有效期" }
            movePct > plan.maxAllowedPriceMovePct -> { next = ForwardEntryPlanEngine.Status.INVALID; reason = "价格偏离快照${movePct.toFixed2()}%，超过${plan.maxAllowedPriceMovePct.toFixed2()}%上限，需重新扫描" }
            closedCandleClose != null && closedCandleTimeMs != null &&
                closedCandleClose.isFinite() && closedCandleClose > 0.0 &&
                closedCandleTimeMs > plan.generatedAtMs && closedCandleTimeMs > (tracked.lastClosedCandleTimeMs ?: 0L) -> {
                val triggered = if (plan.direction == ForwardEntryPlanEngine.Direction.LONG)
                    closedCandleClose >= plan.triggerPrice else closedCandleClose <= plan.triggerPrice
                val invalidated = if (plan.direction == ForwardEntryPlanEngine.Direction.LONG)
                    closedCandleClose <= plan.stopLoss else closedCandleClose >= plan.stopLoss
                when {
                    invalidated -> { next = ForwardEntryPlanEngine.Status.INVALID; reason = "已收盘K线触及计划失效边界" }
                    triggered -> { next = ForwardEntryPlanEngine.Status.CONDITION_MET; reason = "后续已收盘K线满足触发参考；仍需复核追价、手续费与风险收益比" }
                }
            }
        }
        val newClosedCandle = closedCandleTimeMs != null && closedCandleTimeMs > (tracked.lastClosedCandleTimeMs ?: 0L)
        // Avoid serializing the entire journal on every ticker tick. Persist only meaningful
        // lifecycle changes or a new closed-candle checkpoint.
        if (next == tracked.status && !newClosedCandle) return@synchronized
        val updated = tracked.copy(
            status = next,
            lastEvaluatedAtMs = atMs,
            lastObservedPrice = price,
            lastClosedCandleTimeMs = closedCandleTimeMs?.takeIf { it > (tracked.lastClosedCandleTimeMs ?: 0L) } ?: tracked.lastClosedCandleTimeMs,
        )
        val plans = current.plans.toMutableList().also { it[index] = updated }
        val events = current.events.toMutableList()
        if (next != tracked.status && reason != null) {
            events.add(ForwardPlanEvent(planId, atMs, tracked.status.name, next.name, reason, price, closedCandleTimeMs))
        }
        publish(current.copy(plans = plans, events = events.takeLast(MAX_EVENTS)))
    }

    /** Persist a deterministic replay result without replacing the immutable plan snapshot. */
    fun appendReplayResult(result: ForwardPlanReplayEvaluator.Result, savedAtMs: Long): ForwardPlanReplayRecord? = synchronized(lock) {
        val current = _data.value
        if (current.plans.none { it.snapshot.id == result.planId }) return@synchronized null
        if (savedAtMs <= 0L || result.evaluatedThroughMs <= 0L || result.candlesConsidered < 0) return@synchronized null
        val normalizedR = result.grossR?.takeIf { it.isFinite() }
        // Search the full bounded journal, not only its tail: interleaved plans may have
        // appended records after an identical checkpoint was first saved.
        val duplicate = current.replayResults.firstOrNull {
            it.planId == result.planId && it.outcome == result.outcome.name &&
                it.evaluatedThroughMs == result.evaluatedThroughMs && it.candlesConsidered == result.candlesConsidered &&
                it.coverageStatus == result.coverageStatus
        }
        if (duplicate != null) return@synchronized duplicate
        val record = ForwardPlanReplayRecord(
            planId = result.planId,
            outcome = result.outcome.name,
            evaluatedThroughMs = result.evaluatedThroughMs,
            candlesConsidered = result.candlesConsidered,
            firstOutcomeCandleCloseMs = result.firstOutcomeCandleCloseMs,
            netR = normalizedR,
            notes = result.notes.take(8).map { it.take(240) },
            savedAtMs = savedAtMs,
            coverageStatus = result.coverageStatus,
        )
        publish(current.copy(schemaVersion = 4, replayResults = (current.replayResults + record).takeLast(MAX_REPLAY_RESULTS)))
        record
    }

    /** Archive a plan without altering its immutable snapshot or event history. */
    fun archivePlan(planId: String, atMs: Long) = synchronized(lock) {
        val current = _data.value
        val index = current.plans.indexOfFirst { it.snapshot.id == planId }
        if (index < 0) return@synchronized
        val tracked = current.plans[index]
        if (tracked.archived) return@synchronized
        val plans = current.plans.toMutableList().also { it[index] = tracked.copy(archived = true) }
        val events = (current.events + ForwardPlanEvent(
            planId, atMs, tracked.status.name, tracked.status.name, "用户归档计划（不删除快照）", tracked.lastObservedPrice,
            tracked.lastClosedCandleTimeMs,
        )).takeLast(MAX_EVENTS)
        publish(current.copy(plans = plans, events = events))
    }

    /** Permanently remove archived snapshots and their related events/revisions only. */
    fun deleteArchived(): Int = synchronized(lock) {
        val current = _data.value
        val removedIds = current.plans.filter { it.archived }.map { it.snapshot.id }.toSet()
        if (removedIds.isEmpty()) return@synchronized 0
        publish(current.copy(
            plans = current.plans.filterNot { it.snapshot.id in removedIds },
            events = current.events.filterNot { it.planId in removedIds },
            revisions = current.revisions.filterNot { it.planId in removedIds },
            replayResults = current.replayResults.filterNot { it.planId in removedIds },
            replayProgress = current.replayProgress.filterNot { it.planId in removedIds },
        ))
        removedIds.size
    }

    fun replayProgress(planId: String): ForwardReplayProgress? = _data.value.replayProgress.firstOrNull { it.planId == planId }

    /** Save bounded, deduplicated page progress. The immutable plan and terminal results are untouched. */
    fun saveReplayProgress(progress: ForwardReplayProgress) = synchronized(lock) {
        val current = _data.value
        if (current.plans.none { it.snapshot.id == progress.planId && !it.archived }) return@synchronized
        val validCandles = progress.candles.distinctBy { it.openTime }.sortedBy { it.openTime }
            .takeLast(MAX_CANDLES_PER_PROGRESS)
        val normalized = progress.copy(candles = validCandles, updatedAtMs = progress.updatedAtMs.coerceAtLeast(1L))
        val others = current.replayProgress.filterNot { it.planId == progress.planId }
        publish(current.copy(schemaVersion = 4, replayProgress = (others + normalized)
            .sortedByDescending { it.updatedAtMs }.take(MAX_PROGRESS_PLANS)))
    }

    fun clearReplayProgress(planId: String) = synchronized(lock) {
        val current = _data.value
        val next = current.replayProgress.filterNot { it.planId == planId }
        if (next.size != current.replayProgress.size) publish(current.copy(schemaVersion = 4, replayProgress = next))
    }

    fun activePlans(): List<TrackedForwardPlan> = _data.value.plans.filter { !it.archived && it.status in ACTIVE_STATUSES }

    private fun load(): ForwardPlanJournalData {
        val raw = runCatching { settingsStore.getRaw(KEY) }.getOrNull() ?: return ForwardPlanJournalData()
        return runCatching { json.decodeFromString<ForwardPlanJournalData>(raw) }
            .getOrElse { ForwardPlanJournalData() }
            .let { if (it.schemaVersion < 4) it.copy(schemaVersion = 4) else it }
    }

    private fun publish(data: ForwardPlanJournalData) {
        _data.value = data
        runCatching { settingsStore.putRaw(KEY, json.encodeToString(ForwardPlanJournalData.serializer(), data)) }
    }

    private fun Double.toFixed2(): String = (kotlin.math.round(this * 100.0) / 100.0).toString()

}
