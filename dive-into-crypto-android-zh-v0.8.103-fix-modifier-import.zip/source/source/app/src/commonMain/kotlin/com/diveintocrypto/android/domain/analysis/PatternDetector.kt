package com.diveintocrypto.android.domain.analysis

import com.diveintocrypto.android.domain.model.Candle
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Rule-based pattern hits for the Analysis chart (P2). Prefer empty over false positives.
 */
object PatternDetector {

    data class Hit(
        val id: String,
        val name: String,
        val oneLiner: String,
        /** Inclusive index range in the provided candle list for outline highlight. */
        val fromIndex: Int,
        val toIndex: Int,
        val confidence: Double,
    )

    fun detect(candles: List<Candle>, maxHits: Int = 5): List<Hit> {
        if (candles.size < 12) return emptyList()
        val hits = mutableListOf<Hit>()
        detectVReversalTop(candles)?.let { hits.add(it) }
        detectVReversalBottom(candles)?.let { hits.add(it) }
        detectImpulseFade(candles)?.let { hits.add(it) }
        detectDoubleTop(candles)?.let { hits.add(it) }
        detectDoubleBottom(candles)?.let { hits.add(it) }
        return hits.sortedByDescending { it.confidence }.take(maxHits)
    }

    private fun detectVReversalTop(candles: List<Candle>): Hit? {
        val n = candles.size
        val window = min(24, n)
        val start = n - window
        val slice = candles.subList(start, n)
        val peakIdx = slice.indices.maxByOrNull { slice[it].high } ?: return null
        if (peakIdx < 3 || peakIdx > slice.lastIndex - 2) return null
        val left = slice.subList(0, peakIdx)
        val right = slice.subList(peakIdx + 1, slice.size)
        val leftRise = left.last().close - left.first().close
        val rightDrop = right.first().close - right.last().close
        val peak = slice[peakIdx].high
        if (leftRise <= 0 || rightDrop <= 0) return null
        val risePct = leftRise / left.first().close
        val dropPct = rightDrop / peak
        if (risePct < 0.008 || dropPct < 0.006) return null
        // Sharp: most of the rise in the last third before peak
        val conf = (min(risePct, dropPct) * 40.0 + 0.35).coerceIn(0.35, 0.9)
        val absPeak = start + peakIdx
        return Hit(
            id = "v_top_$absPeak",
            name = "V形反转顶",
            oneLiner = "急涨后急速回落",
            fromIndex = start + max(0, peakIdx - 4),
            toIndex = min(n - 1, absPeak + 4),
            confidence = conf,
        )
    }

    private fun detectVReversalBottom(candles: List<Candle>): Hit? {
        val n = candles.size
        val window = min(24, n)
        val start = n - window
        val slice = candles.subList(start, n)
        val troughIdx = slice.indices.minByOrNull { slice[it].low } ?: return null
        if (troughIdx < 3 || troughIdx > slice.lastIndex - 2) return null
        val left = slice.subList(0, troughIdx)
        val right = slice.subList(troughIdx + 1, slice.size)
        val leftDrop = left.first().close - left.last().close
        val rightRise = right.last().close - right.first().close
        val trough = slice[troughIdx].low
        if (leftDrop <= 0 || rightRise <= 0) return null
        val dropPct = leftDrop / left.first().close
        val risePct = rightRise / trough
        if (dropPct < 0.008 || risePct < 0.006) return null
        val conf = (min(dropPct, risePct) * 40.0 + 0.35).coerceIn(0.35, 0.9)
        val absTrough = start + troughIdx
        return Hit(
            id = "v_bot_$absTrough",
            name = "V形反转底",
            oneLiner = "急跌后急速反弹",
            fromIndex = start + max(0, troughIdx - 4),
            toIndex = min(n - 1, absTrough + 4),
            confidence = conf,
        )
    }

    private fun detectImpulseFade(candles: List<Candle>): Hit? {
        val n = candles.size
        if (n < 10) return null
        val last = candles.takeLast(10)
        val first = last.first().close
        val mid = last[4].close
        val end = last.last().close
        val upThenDown = mid > first * 1.012 && end < mid * 0.994
        val downThenUp = mid < first * 0.988 && end > mid * 1.006
        return when {
            upThenDown -> Hit(
                id = "fade_up_${n - 1}",
                name = "急涨后回落",
                oneLiner = "短线冲高动能减弱",
                fromIndex = n - 10,
                toIndex = n - 1,
                confidence = 0.45,
            )
            downThenUp -> Hit(
                id = "fade_dn_${n - 1}",
                name = "急跌后反弹",
                oneLiner = "短线杀跌后修复",
                fromIndex = n - 10,
                toIndex = n - 1,
                confidence = 0.45,
            )
            else -> null
        }
    }

    private fun detectDoubleTop(candles: List<Candle>): Hit? {
        val n = candles.size
        val window = min(40, n)
        val start = n - window
        val slice = candles.subList(start, n)
        val pivots = mutableListOf<Pair<Int, Double>>()
        for (i in 2 until slice.lastIndex - 1) {
            val h = slice[i].high
            if (h >= slice[i - 1].high && h >= slice[i - 2].high &&
                h >= slice[i + 1].high && h >= slice[i + 2].high
            ) {
                pivots.add(i to h)
            }
        }
        if (pivots.size < 2) return null
        val a = pivots[pivots.size - 2]
        val b = pivots.last()
        if (b.first - a.first < 3) return null
        val rel = abs(a.second - b.second) / max(a.second, b.second)
        if (rel > 0.012) return null
        val midLow = slice.subList(a.first, b.first + 1).minOf { it.low }
        if (midLow >= min(a.second, b.second) * 0.985) return null
        return Hit(
            id = "dtop_${start + b.first}",
            name = "双顶",
            oneLiner = "两次冲高接近同一阻力",
            fromIndex = start + a.first,
            toIndex = start + b.first,
            confidence = 0.55,
        )
    }

    private fun detectDoubleBottom(candles: List<Candle>): Hit? {
        val n = candles.size
        val window = min(40, n)
        val start = n - window
        val slice = candles.subList(start, n)
        val pivots = mutableListOf<Pair<Int, Double>>()
        for (i in 2 until slice.lastIndex - 1) {
            val l = slice[i].low
            if (l <= slice[i - 1].low && l <= slice[i - 2].low &&
                l <= slice[i + 1].low && l <= slice[i + 2].low
            ) {
                pivots.add(i to l)
            }
        }
        if (pivots.size < 2) return null
        val a = pivots[pivots.size - 2]
        val b = pivots.last()
        if (b.first - a.first < 3) return null
        val rel = abs(a.second - b.second) / max(a.second, 1e-9)
        if (rel > 0.012) return null
        val midHigh = slice.subList(a.first, b.first + 1).maxOf { it.high }
        if (midHigh <= max(a.second, b.second) * 1.015) return null
        return Hit(
            id = "dbot_${start + b.first}",
            name = "双底",
            oneLiner = "两次探底接近同一支撑",
            fromIndex = start + a.first,
            toIndex = start + b.first,
            confidence = 0.55,
        )
    }
}
