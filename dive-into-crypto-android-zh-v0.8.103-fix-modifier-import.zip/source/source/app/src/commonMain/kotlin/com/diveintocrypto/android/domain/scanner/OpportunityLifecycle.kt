package com.diveintocrypto.android.domain.scanner

import kotlin.math.abs

/** Pure lifecycle comparison between completed scan snapshots. Display/triage only;
 * it never changes the underlying scanner score or submits an order. */
object OpportunityLifecycle {
    enum class Status { NEW, ACTIVE, DIRECTION_REVERSED, PRICE_MOVED, DATA_INVALID }
    data class Snapshot(val symbol: String, val direction: Int, val price: Double, val atrPct: Double?)
    data class Assessment(val status: Status, val label: String, val note: String)
    data class Summary(val newCount: Int, val activeCount: Int, val reversedCount: Int,
                       val movedCount: Int, val invalidCount: Int, val disappearedCount: Int,
                       val coverageComplete: Boolean)

    fun assess(current: Snapshot, previous: Snapshot?): Assessment {
        if (current.symbol.isBlank() || !current.price.isFinite() || current.price <= 0.0 || current.direction !in -1..1) {
            return Assessment(Status.DATA_INVALID, "数据需复核", "当前币种、价格或方向数据无效，暂不应依赖该机会")
        }
        if (previous == null) return Assessment(Status.NEW, "新机会", "本轮扫描首次出现；等待后续周期确认")
        if (previous.symbol.isBlank() || !previous.symbol.trim().equals(current.symbol.trim(), ignoreCase = true) || previous.direction !in -1..1) {
            return Assessment(Status.DATA_INVALID, "数据需复核", "上一轮币种或方向数据无效，无法可靠比较变化")
        }
        // Validate the previous price before interpreting a direction change. A bad
        // prior snapshot must never make an old plan look definitively reversed.
        if (!previous.price.isFinite() || previous.price <= 0.0) {
            return Assessment(Status.DATA_INVALID, "数据需复核", "上一轮参考价格无效，无法可靠比较变化")
        }
        if (previous.direction != 0 && current.direction != 0 && previous.direction != current.direction) {
            return Assessment(Status.DIRECTION_REVERSED, "方向反转", "与上轮扫描方向相反，原风险计划应视为失效并重新评估")
        }
        val movePct = abs(current.price - previous.price) / previous.price * 100.0
        if (!movePct.isFinite()) {
            return Assessment(Status.DATA_INVALID, "数据需复核", "价格变化率计算异常，暂不应沿用旧风险计划")
        }
        val validAtr = current.atrPct?.takeIf { it.isFinite() && it > 0.0 }
        val threshold = maxOf(1.0, (validAtr ?: 0.0) * 1.5)
        if (movePct >= threshold) {
            val roundedMovePct = (movePct * 100.0).toLong() / 100.0
            return Assessment(Status.PRICE_MOVED, "价格变化较大", "参考价较上轮变化约 $roundedMovePct%；请复核入场、止损和止盈，不沿用旧价位")
        }
        return Assessment(Status.ACTIVE, "持续跟踪", "方向未反转且价格变化未达到复核阈值；仍需结合最新行情判断")
    }

    fun summarize(current: List<Snapshot>, previous: List<Snapshot>, scanComplete: Boolean = true): Summary {
        fun key(symbol: String) = symbol.trim().uppercase()
        val oldBySymbol = previous.filter { it.symbol.isNotBlank() }.associateBy { key(it.symbol) }
        var fresh = 0; var active = 0; var reversed = 0; var moved = 0; var invalid = 0
        // Duplicate rows can appear when a scan merges multiple data sources; count each symbol once.
        current.filter { it.symbol.isNotBlank() }.distinctBy { key(it.symbol) }.forEach { item -> when (assess(item, oldBySymbol[key(item.symbol)]).status) {
            Status.NEW -> fresh++
            Status.ACTIVE -> active++
            Status.DIRECTION_REVERSED -> reversed++
            Status.PRICE_MOVED -> moved++
            Status.DATA_INVALID -> invalid++
        } }
        val currentSymbols = current.filter { it.symbol.isNotBlank() }.map { key(it.symbol) }.toSet()
        val disappeared = if (scanComplete) {
            previous.filter { it.symbol.isNotBlank() }.map { key(it.symbol) }.distinct().count { it !in currentSymbols }
        } else 0 // Partial scans must not turn fetch failures into false disappearances.
        return Summary(fresh, active, reversed, moved, invalid, disappeared, scanComplete)
    }
}
