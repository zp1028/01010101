package com.diveintocrypto.android.ai

import com.diveintocrypto.android.data.SettingsStore
import com.diveintocrypto.android.data.ai.AiAnalysisClient
import com.diveintocrypto.android.domain.model.Candle
import com.diveintocrypto.android.domain.model.Signal
import com.diveintocrypto.android.domain.scanner.RiskPlanCalculator
import com.diveintocrypto.android.engine.MarketDataEngine
import com.diveintocrypto.android.domain.scanner.HistoricalCandleAlignment
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.flow.updateAndGet
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * App-scoped AI session hub — shared by Analysis, Scanner, and future pages.
 */
class AiSessionHub(
    private val settingsStore: SettingsStore,
    private val repository: MarketDataEngine,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    data class Session(
        val symbol: String = "",
        val timeframe: String = "15m",
        val history: List<Pair<String, String>> = emptyList(),
        val lastReport: String? = null,
        val lastPlan: AiAnalysisClient.AiPlan? = null,
        val streamingText: String = "",
        val running: Boolean = false,
        val status: String = "",
        val source: String = "Analysis",
        val shortVerdict: String? = null,
        // Monotonic generation invalidates callbacks from superseded AI runs.
        val generation: Long = 0L,
    )

    private val _session = MutableStateFlow(Session())
    val session: StateFlow<Session> = _session.asStateFlow()

    fun clear(symbol: String? = null) {
        val sym = symbol?.uppercase()
        _session.update {
            if (sym == null || it.symbol.equals(sym, true)) Session(symbol = sym.orEmpty(), generation = it.generation + 1L)
            else it
        }
    }

    fun bindSymbol(symbol: String, timeframe: String) {
        val s = symbol.uppercase()
        _session.update {
            if (it.symbol == s && it.timeframe.equals(timeframe, ignoreCase = true)) it
            else Session(symbol = s, timeframe = timeframe, status = "已切换分析目标，旧 AI 结果已清除", generation = it.generation + 1L)
        }
    }

    /**
     * Full or follow-up analysis. Updates [session] with streaming text and optional plan.
     */
    fun startAnalysis(
        symbol: String,
        timeframe: String,
        primaryCandles: List<Candle>,
        multiTf: List<AiAnalysisClient.TfSlice>,
        signal: Signal,
        confidence: Int,
        shouldTrade: Boolean,
        enginePlan: RiskPlanCalculator.Plan?,
        support: Double?,
        resistance: Double?,
        patternName: String?,
        livePrice: Double?,
        userQuestion: String?,
        source: String,
        appendHistory: Boolean = true,
        // Optional generation token for callers that fetch data asynchronously.
        // If the target was superseded while data was loading, discard the result.
        expectedGeneration: Long? = null,
    ) {
        val cfg = settingsStore.getSettings()
        val sym = symbol.uppercase()
        if (!cfg.aiEnabled || cfg.aiApiKey.isBlank()) {
            // Rebind and advance generation even on early failure. This prevents a
            // previous in-flight response from updating a now-invalid AI session.
            _session.update { current ->
                if (expectedGeneration != null && current.generation != expectedGeneration) current
                else Session(
                    symbol = sym,
                    timeframe = timeframe,
                    status = "请在设置中启用 AI 并填写 API Key",
                    source = source,
                    generation = current.generation + 1L,
                )
            }
            return
        }
        if (primaryCandles.size < 10) {
            _session.update { current ->
                if (expectedGeneration != null && current.generation != expectedGeneration) current
                else Session(
                    symbol = sym,
                    timeframe = timeframe,
                    status = "K 线不足",
                    source = source,
                    generation = current.generation + 1L,
                )
            }
            return
        }
        val startedSession = _session.updateAndGet { current ->
            if (expectedGeneration != null && current.generation != expectedGeneration) {
                current
            } else {
                // Conversation history is reusable only for the exact symbol + timeframe.
                val reusableHistory = if (current.symbol.equals(sym, ignoreCase = true) &&
                    current.timeframe.equals(timeframe, ignoreCase = true) && appendHistory
                ) current.history else emptyList()
                Session(
                    symbol = sym,
                    timeframe = timeframe,
                    history = reusableHistory,
                    running = true,
                    status = "流式分析中…",
                    streamingText = "",
                    lastReport = null,
                    lastPlan = null,
                    source = source,
                    generation = current.generation + 1L,
                )
            }
        }
        // A stale asynchronous fetch must not start a new AI generation.
        if (expectedGeneration != null && startedSession.generation == expectedGeneration) return
        val generation = startedSession.generation
        val hist = startedSession.history
        scope.launch {
            val deltaChan = Channel<String>(Channel.UNLIMITED)
            val renderJob = launch(Dispatchers.Main) {
                val sb = StringBuilder()
                try {
                    for (d in deltaChan) {
                        sb.append(d)
                        _session.update { s ->
                            if (s.generation == generation) s.copy(streamingText = sb.toString()) else s
                        }
                    }
                } catch (_: Throwable) {
                }
            }
            try {
                val ctx = AiAnalysisClient.MarketContext(
                    symbol = sym,
                    timeframe = timeframe,
                    candles = primaryCandles,
                    multiTf = multiTf.ifEmpty { listOf(AiAnalysisClient.TfSlice(timeframe, primaryCandles)) },
                    signal = signal,
                    confidence = confidence,
                    shouldTrade = shouldTrade,
                    enginePlan = enginePlan,
                    support = support,
                    resistance = resistance,
                    patternName = patternName,
                    livePrice = livePrice,
                    userQuestion = userQuestion,
                    history = hist,
                )
                val result = withContext(Dispatchers.IO) {
                    AiAnalysisClient.analyzeStreaming(
                        AiAnalysisClient.Config(
                            baseUrl = cfg.aiApiBaseUrl,
                            apiKey = cfg.aiApiKey,
                            model = cfg.aiModel.ifBlank { "deepseek-chat" },
                        ),
                        ctx,
                    ) { delta -> deltaChan.trySend(delta) }
                }
                deltaChan.close()
                renderJob.join()
                if (result.ok) {
                    val qLabel = userQuestion?.takeIf { it.isNotBlank() } ?: "请分析"
                    val newHist = hist + ("user" to qLabel) + ("assistant" to result.text)
                    val short = result.text.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.take(3).joinToString(" ")
                    _session.update {
                        if (it.generation != generation) it else it.copy(
                            running = false,
                            lastReport = result.text,
                            streamingText = result.text,
                            lastPlan = result.plan,
                            history = newHist,
                            status = buildString {
                                append("完成 · ${result.latencyMs}ms")
                                if (result.plan != null) append(" · 已解析计划")
                            },
                            shortVerdict = short.take(160),
                        )
                    }
                } else {
                    _session.update {
                        if (it.generation == generation) it.copy(running = false, status = "失败：${result.error}") else it
                    }
                }
            } catch (t: Throwable) {
                deltaChan.close()
                _session.update {
                    if (it.generation == generation) it.copy(running = false, status = "失败：${t.message ?: t::class.simpleName}") else it
                }
            }
        }
    }

    /**
     * Scanner quick path: fetch multi-TF candles then analyze.
     */
    fun startFromScanner(symbol: String, timeframe: String = "15m") {
        val sym = symbol.uppercase()
        val scanSession = _session.updateAndGet {
            it.copy(symbol = sym, timeframe = timeframe, running = true, status = "拉取多周期…", source = "Scanner", generation = it.generation + 1L)
        }
        val scanGeneration = scanSession.generation
        scope.launch {
            try {
                val tfs = listOf(timeframe, "1h", "4h").distinct()
                val slices = mutableListOf<AiAnalysisClient.TfSlice>()
                var primary = emptyList<Candle>()
                for (tf in tfs) {
                    val raw = withContext(Dispatchers.IO) {
                        runCatching { repository.futuresHistory(sym, tf, limit = 120) }.getOrDefault(emptyList())
                    }
                    val cleaned = HistoricalCandleAlignment.sanitize(raw)
                    if (cleaned.size >= 10) {
                        val take = cleaned.takeLast(80)
                        slices.add(AiAnalysisClient.TfSlice(tf, take))
                        if (tf == timeframe) primary = take
                    }
                }
                // The primary series must match the requested timeframe. Never silently
                // relabel 1h/4h candles as 15m (or another requested primary timeframe).
                if (primary.size < 10) {
                    _session.update {
                        if (it.generation == scanGeneration) it.copy(
                            running = false,
                            status = "主周期 ${timeframe} K 线不足（至少需要 10 根），已停止分析；未用其他周期替代",
                        ) else it
                    }
                    return@launch
                }
                if (_session.value.generation != scanGeneration) return@launch
                startAnalysis(
                    symbol = sym,
                    timeframe = timeframe,
                    primaryCandles = primary,
                    multiTf = slices,
                    signal = Signal.NEUTRAL,
                    confidence = 0,
                    shouldTrade = false,
                    enginePlan = null,
                    support = null,
                    resistance = null,
                    patternName = null,
                    livePrice = primary.lastOrNull()?.close,
                    userQuestion = "这是扫描排行榜候选。请做多周期技术分析，给出方向、关键位与入场止损止盈 JSON。",
                    source = "Scanner",
                    appendHistory = false,
                    expectedGeneration = scanGeneration,
                )
            } catch (t: Throwable) {
                _session.update {
                    if (it.generation == scanGeneration) it.copy(running = false, status = "失败：${t.message ?: t::class.simpleName}") else it
                }
            }
        }
    }

    /**
     * Custom question with multi-TF candles (backtest explain, alert explain, etc.).
     */
    fun startWithQuestion(symbol: String, timeframe: String, question: String, source: String) {
        val sym = symbol.uppercase()
        val q = question.trim()
        if (q.isEmpty()) {
            _session.update { it.copy(status = "问题为空") }
            return
        }
        val questionSession = _session.updateAndGet {
            it.copy(symbol = sym, timeframe = timeframe, running = true, status = "拉取数据…", source = source, generation = it.generation + 1L)
        }
        val questionGeneration = questionSession.generation
        scope.launch {
            try {
                val tfs = listOf(timeframe, "1h", "4h").distinct()
                val slices = mutableListOf<AiAnalysisClient.TfSlice>()
                var primary = emptyList<Candle>()
                for (tf in tfs) {
                    val raw = withContext(Dispatchers.IO) {
                        runCatching { repository.futuresHistory(sym, tf, limit = 120) }.getOrDefault(emptyList())
                    }
                    val cleaned = HistoricalCandleAlignment.sanitize(raw)
                    if (cleaned.size >= 10) {
                        val take = cleaned.takeLast(80)
                        slices.add(AiAnalysisClient.TfSlice(tf, take))
                        if (tf == timeframe) primary = take
                    }
                }
                // Keep candle data and the timeframe label truthful: secondary-timeframe
                // candles are context only and cannot substitute for the primary series.
                if (primary.size < 10) {
                    _session.update {
                        if (it.generation == questionGeneration) it.copy(
                            running = false,
                            status = "主周期 ${timeframe} K 线不足（至少需要 10 根），已停止分析；未用其他周期替代",
                        ) else it
                    }
                    return@launch
                }
                if (_session.value.generation != questionGeneration) return@launch
                startAnalysis(
                    symbol = sym,
                    timeframe = timeframe,
                    primaryCandles = primary,
                    multiTf = slices,
                    signal = Signal.NEUTRAL,
                    confidence = 0,
                    shouldTrade = false,
                    enginePlan = null,
                    support = null,
                    resistance = null,
                    patternName = null,
                    livePrice = primary.lastOrNull()?.close,
                    userQuestion = q,
                    source = source,
                    appendHistory = false,
                    expectedGeneration = questionGeneration,
                )
            } catch (t: Throwable) {
                _session.update {
                    if (it.generation == questionGeneration) it.copy(running = false, status = "失败：${t.message ?: t::class.simpleName}") else it
                }
            }
        }
    }
}
