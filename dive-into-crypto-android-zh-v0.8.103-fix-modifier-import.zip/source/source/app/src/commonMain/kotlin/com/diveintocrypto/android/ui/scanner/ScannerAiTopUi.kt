package com.diveintocrypto.android.ui.scanner

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.diveintocrypto.android.platform.format
import com.diveintocrypto.android.ui.theme.DiveColors

/**
 * AI 十佳 / 观察名单决策卡 + 融合状态文案。
 * 从 ScannerScreen 抽出以降乱；同包 internal，行为不变。
 */

@Composable
internal fun AiTopPickCard(
    row: CrossRankingRow,
    rank: Int,
    confidence: Int,
    fromFusion: Boolean,
    watchMode: Boolean = false,
    onAnalyze: () -> Unit,
    onSelect: () -> Unit,
) {
    val dirLabel = when {
        row.dominantDir.score > 0 -> "做多"
        row.dominantDir.score < 0 -> "做空"
        else -> "中性"
    }
    val dirColor = when {
        row.dominantDir.score > 0 -> DiveColors.Green
        row.dominantDir.score < 0 -> DiveColors.Red
        else -> DiveColors.TextMuted
    }
    val thesis = row.aiFusionThesis?.takeIf { it.isNotBlank() }
        ?: row.aiFusionReason?.takeIf { it.isNotBlank() }
        ?: "本地多周期共识 · ${row.countHit}/${row.totalTfs} 共振"
    val entry = row.aiSuggestedEntry?.takeIf { it > 0 } ?: row.price.takeIf { it > 0 }
    val stop = row.aiSuggestedStop?.takeIf { it > 0 }
    val target = row.aiSuggestedTarget?.takeIf { it > 0 }
    val statusHint = when {
        watchMode -> "观察 · ${aiFusionStatusLabel(row)}"
        fromFusion -> aiFusionStatusLabel(row)
        else -> "本地精选"
    }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(DiveColors.BgCard)
            .border(
                1.dp,
                if (watchMode) DiveColors.Border else DiveColors.Accent.copy(alpha = 0.35f),
                RoundedCornerShape(12.dp),
            )
            .clickable(onClick = onSelect)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("#$rank", color = DiveColors.Accent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(row.symbol, color = DiveColors.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    dirLabel,
                    color = dirColor,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(dirColor.copy(alpha = 0.15f))
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                val aiConf = row.aiConfidence
                if (fromFusion && aiConf != null) {
                    Text("AI $aiConf", color = DiveColors.Accent, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Text("本地 $confidence", color = DiveColors.TextDim, fontSize = 10.sp)
                } else {
                    Text("置信 $confidence", color = DiveColors.TextMuted, fontSize = 12.sp)
                }
            }
        }
        Text(
            text = thesis,
            color = DiveColors.TextMuted,
            fontSize = 12.sp,
            lineHeight = 16.sp,
            maxLines = 2,
        )
        if (fromFusion && row.aiFakeBreakoutRisk != null) {
            val fr = row.aiFakeBreakoutRisk
            val rr = row.aiRiskRewardRatio
            Text(
                text = buildString {
                    append("假突破风险 $fr")
                    rr?.let { append(" · AI R:R ${it.format(2)}") }
                    row.aiSuggestedTimeframe?.let { append(" · 主周期 $it") }
                },
                color = DiveColors.TextDim,
                fontSize = 10.sp,
            )
        }
        if (entry != null || stop != null || target != null) {
            Text(
                text = buildString {
                    append(if (row.aiPlanAccepted || (row.aiSuggestedEntry != null)) "AI参考 " else "本地参考 ")
                    entry?.let { append("入 ${it.format(6)}  ") }
                    stop?.let { append("止 ${it.format(6)}  ") }
                    target?.let { append("盈 ${it.format(6)}") }
                }.trim(),
                color = DiveColors.TextDim,
                fontSize = 11.sp,
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(statusHint, color = DiveColors.TextDim, fontSize = 10.sp)
            TextButton(onClick = onAnalyze) {
                Text("看分析", color = DiveColors.Accent, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

/** Map internal AI fusion codes to short Chinese labels for the card surface. */
internal fun aiFusionStatusLabel(row: CrossRankingRow): String = when {
    row.aiDirectionChanged -> "AI 已反转"
    row.aiFusionStatus == "CONFLICT" -> "AI 冲突"
    row.aiFusionStatus == "LOCAL_FALLBACK" -> "AI 回退本地"
    row.aiFusionStatus == "ALIGNED" -> "AI 一致"
    row.aiFusionStatus == "REVERSAL" || row.aiFusionStatus == "AI-DIRECTION-SET" -> "AI 改方向"
    row.aiFusionStatus == "LOW_CONFIDENCE" -> "AI 低置信"
    row.aiFusionStatus == "AI-NEUTRAL" -> "AI 中性"
    row.aiFusionStatus.contains("关闭") -> "AI 关闭"
    row.aiFusionStatus.contains("未启用") || row.aiFusionStatus.contains("未配置") -> "AI 未就绪"
    row.aiFusionStatus.contains("超时") || row.aiFusionStatus.contains("未返回") -> "AI 未返回"
    else -> "AI 已复核"
}

internal fun aiFusionStatusColor(row: CrossRankingRow): Color = when {
    row.aiDirectionChanged -> DiveColors.Accent
    row.aiFusionStatus == "CONFLICT" || row.aiFusionStatus == "LOCAL_FALLBACK" -> DiveColors.Warn
    row.aiFusionStatus.contains("关闭") || row.aiFusionStatus.contains("未启用") || row.aiFusionStatus.contains("未配置") -> DiveColors.TextDim
    else -> DiveColors.Green
}
