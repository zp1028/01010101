package com.diveintocrypto.android.domain.scanner

import com.diveintocrypto.android.domain.model.Candle
import com.diveintocrypto.android.domain.model.Signal

/**
 * Historical multi-symbol scanner replay contract and pure helpers.
 *
 * Goal (Stage 4 P0): at a chosen historical cut time T, reproduce the **same
 * ranking structure** the live scanner would have produced if it had only seen
 * data available at T:
 *  - Phase-1 high-TF scores across the universe snapshot
 *  - Phase-2 survivor pool of size [phase2Depth]
 *  - Per-TF top-15 and cross-rank by net_nss
 *
 * What this module guarantees today
 * ---------------------------------
 *  - Ranking math is identical to [ScannerRanking] / live ScannerViewModel
 *  - Candle prefixes are leakage-safe via [HistoricalCandleAlignment.closedBefore]
 *  - Missing auxiliary series (whale L/S, OI, taker flow, 24h quote-volume
 *    ranking of the universe at T) are **explicitly marked**, never fabricated
 *
 * What still requires external historical archives (not inventable)
 * -----------------------------------------------------------------
 *  - The ordered universe at T (live uses current 24h quoteVolume ranking)
 *  - Whale long/short ratio history, open interest, taker buy/sell ratios
 *  - Funding-rate series used by microstructure overlays
 *
 * When those archives are absent the replay still returns a ranking based on
 * indicator consensus alone and sets [ReplayReport.missingAuxiliaryData] so
 * callers cannot treat the result as full live-scanner parity.
 */
object HistoricalScannerReplay {

    /**
     * One symbol × timeframe evaluation that was produced from candles closed
     * strictly before the replay cut time.
     */
    data class CausalCell(
        val symbol: String,
        val timeframe: String,
        val signal: Signal,
        val confidence: Int,
        val price: Double,
        /** Open time of the last candle used (must be < cutTime). */
        val lastCandleOpenTimeMs: Long,
        val finalScore: Double = ScannerRanking.finalScore(confidence, timeframe),
    )

    data class ReplayInput(
        /** Cut time in epoch millis. Only information available before this instant may be used. */
        val cutTimeMs: Long,
        /**
         * Pre-computed causal cells. Callers must build each cell from
         * [HistoricalCandleAlignment.closedBefore] prefixes only.
         */
        val cells: List<CausalCell>,
        /** Phase-2 survivor depth (live default: settings.scanDepthTop, typically 50). */
        val phase2Depth: Int = 50,
        /** Per-TF top-N before cross-rank (live: 15). */
        val perTfTopN: Int = ScannerRanking.DEFAULT_PER_TF_TOP_N,
        /**
         * Optional ordered universe at the cut time (highest 24h quote volume first).
         * When null, ranking proceeds over whatever symbols appear in [cells] and
         * [missingUniverseRanking] is set true in the report.
         */
        val universeAtCut: List<String>? = null,
        /** True when whale / flow / OI series for the cut window were unavailable. */
        val auxiliaryDataMissing: Boolean = true,
    )

    data class ReplayReport(
        val cutTimeMs: Long,
        val ranking: ScannerRanking.RankResult,
        /** Symbols that had at least one causal cell. */
        val symbolsEvaluated: Int,
        val cellsUsed: Int,
        val missingUniverseRanking: Boolean,
        val missingAuxiliaryData: Boolean,
        /**
         * Human-readable limitations. Empty only when universe ranking and
         * auxiliary series were both supplied and used.
         */
        val limitations: List<String>,
    )

    /**
     * Rank a historical snapshot. Pure: no I/O, no clocks, no future candles.
     *
     * Preconditions the caller must uphold:
     *  - Every [CausalCell.lastCandleOpenTimeMs] < [ReplayInput.cutTimeMs]
     *  - Cells were computed only from closed-before prefixes
     *  - No synthetic candles were inserted across gaps
     */
    fun rankAtCut(input: ReplayInput): ReplayReport {
        require(input.cutTimeMs > 0L) { "cutTimeMs must be positive" }
        require(input.phase2Depth >= 1) { "phase2Depth must be at least 1" }

        val leak = input.cells.filter { it.lastCandleOpenTimeMs >= input.cutTimeMs }
        require(leak.isEmpty()) {
            "causal violation: ${leak.size} cell(s) have lastCandleOpenTimeMs >= cutTimeMs"
        }

        val rankCells = input.cells.map {
            ScannerRanking.RankCell(
                symbol = it.symbol,
                timeframe = it.timeframe,
                signal = it.signal,
                confidence = it.confidence,
                finalScore = it.finalScore,
                price = it.price,
            )
        }

        // When a historical universe order is supplied, restrict phase-1
        // aggregation to that ordered set (mirrors live: scan the volume-ranked
        // universe). Symbols outside the universe snapshot are ignored.
        val scoped = if (input.universeAtCut != null) {
            val allowed = input.universeAtCut.map { it.trim().uppercase() }.toSet()
            rankCells.filter { it.symbol.trim().uppercase() in allowed }
        } else {
            rankCells
        }

        val ranking = ScannerRanking.rankFromCells(
            allCells = scoped,
            phase2Depth = input.phase2Depth,
            perTfTopN = input.perTfTopN,
        )

        val limitations = mutableListOf<String>()
        val missingUniverse = input.universeAtCut == null
        if (missingUniverse) {
            limitations += "Universe at cut time was not supplied; ranking uses only symbols present in causal cells (not the live 24h quoteVolume order)."
        }
        if (input.auxiliaryDataMissing) {
            limitations += "Whale L/S, open-interest, taker flow and funding series were not available for this cut; adverse-divergence elimination and microstructure overlays are not replayed."
        }
        if (scoped.isEmpty()) {
            limitations += "No causal cells remained after universe scoping; ranking is empty."
        }

        return ReplayReport(
            cutTimeMs = input.cutTimeMs,
            ranking = ranking,
            symbolsEvaluated = scoped.map { it.symbol.trim().uppercase() }.toSet().size,
            cellsUsed = scoped.size,
            missingUniverseRanking = missingUniverse,
            missingAuxiliaryData = input.auxiliaryDataMissing,
            limitations = limitations,
        )
    }

    /**
     * Build a leakage-safe candle prefix for one symbol/TF at [cutTimeMs].
     * Convenience wrapper around [HistoricalCandleAlignment]; does not invent bars.
     */
    fun causalPrefix(candles: List<Candle>, cutTimeMs: Long): List<Candle> {
        if (cutTimeMs <= 0L) return emptyList()
        val sanitized = HistoricalCandleAlignment.sanitize(candles)
        // Prefer close-time availability; fall back to open-time when closeTime
        // is missing/zero so callers with partial records still stay causal.
        return sanitized.filter { c ->
            val availableAt = when {
                c.closeTime > 0L -> c.closeTime
                else -> c.openTime
            }
            availableAt < cutTimeMs
        }
    }

    /**
     * Returns true when the lookback window that would be used for a signal at
     * [signalIndex] (or the next-open entry) crosses a detected cadence gap.
     * Historical replay should filter such signals rather than simulate fills
     * across missing history (same policy as gap-aware single-symbol backtest).
     */
    fun signalCrossesGap(
        candles: List<Candle>,
        signalIndex: Int,
        lookbackBars: Int,
    ): Boolean {
        if (signalIndex < 0 || signalIndex >= candles.size) return false
        val from = (signalIndex - lookbackBars).coerceAtLeast(0)
        // Include the interval that would be used for next-open entry when present.
        val to = (signalIndex + 1).coerceAtMost(candles.lastIndex)
        return HistoricalCandleAlignment.hasIntervalDiscontinuity(candles, from, to)
    }

    /**
     * Build one causal cell from an already-evaluated consensus result and the
     * last candle of the causal prefix. Caller must ensure [prefix] was produced
     * by [causalPrefix] for [cutTimeMs].
     */
    fun buildCausalCell(
        symbol: String,
        timeframe: String,
        signal: Signal,
        confidence: Int,
        prefix: List<Candle>,
        cutTimeMs: Long,
    ): CausalCell? {
        if (prefix.isEmpty()) return null
        val last = prefix.last()
        val availableAt = when {
            last.closeTime > 0L -> last.closeTime
            else -> last.openTime
        }
        if (availableAt >= cutTimeMs) return null
        return CausalCell(
            symbol = symbol,
            timeframe = timeframe,
            signal = signal,
            confidence = confidence,
            price = last.close,
            lastCandleOpenTimeMs = last.openTime,
        )
    }
}
