package com.diveintocrypto.android.domain.analysis

import com.diveintocrypto.android.domain.math.Series
import com.diveintocrypto.android.domain.model.Candle
import com.diveintocrypto.android.domain.model.Signal
import com.diveintocrypto.android.domain.scanner.RiskPlanCalculator
import kotlin.math.abs

/**
 * Pure helpers for the Analysis screen risk card and chart levels (P0).
 * Target-R slider only changes plan geometry; entry anchor stays fixed until re-analyze.
 */
object AnalysisPlanMath {

    const val DEFAULT_ATR_PERIOD: Int = 14
    const val DEFAULT_ATR_MULTIPLIER: Double = 1.5
    const val TARGET_R_MIN: Double = 1.0
    const val TARGET_R_MAX: Double = 3.0
    const val TARGET_R_STEP: Double = 0.1

    fun directionFromSignal(signal: Signal): RiskPlanCalculator.Direction? = when (signal) {
        Signal.STRONG_BUY, Signal.BUY -> RiskPlanCalculator.Direction.LONG
        Signal.STRONG_SELL, Signal.SELL -> RiskPlanCalculator.Direction.SHORT
        Signal.NEUTRAL -> null
    }

    fun signalHeadline(signal: Signal, entry: Double?): String {
        val entryStr = entry?.let { formatPrice(it) } ?: "—"
        return when (signal) {
            Signal.STRONG_BUY, Signal.BUY -> "看涨，回踩 $entryStr 入场"
            Signal.STRONG_SELL, Signal.SELL -> "看跌，反弹 $entryStr 入场"
            Signal.NEUTRAL -> "观望，暂无方向性计划"
        }
    }

    /** Simple ATR average of true range over [period] bars ending at last index. */
    fun atr(candles: List<Candle>, period: Int = DEFAULT_ATR_PERIOD): Double? {
        if (period < 2 || candles.size < period) return null
        val end = candles.lastIndex
        var total = 0.0
        val start = end - period + 1
        for (index in start..end) {
            val c = candles[index]
            val prevClose = if (index > 0) candles[index - 1].close else c.open
            val tr = maxOf(c.high - c.low, abs(c.high - prevClose), abs(c.low - prevClose))
            if (!tr.isFinite() || tr < 0.0) return null
            total += tr
        }
        val v = total / period
        return v.takeIf { it.isFinite() && it > 0.0 }
    }

    fun buildPlan(
        signal: Signal,
        entry: Double,
        atrValue: Double,
        targetR: Double,
        atrMultiplier: Double = DEFAULT_ATR_MULTIPLIER,
    ): RiskPlanCalculator.Plan? {
        val direction = directionFromSignal(signal) ?: return null
        val r = targetR.coerceIn(TARGET_R_MIN, TARGET_R_MAX)
        return RiskPlanCalculator.calculate(
            direction = direction,
            entry = entry,
            atr = atrValue,
            atrMultiplier = atrMultiplier,
            targetR = r,
        ).plan
    }

    /**
     * Live reward/risk using current price vs fixed stop/target.
     * Returns null when geometry is invalid or price is on the wrong side of the plan.
     */
    fun liveRiskReward(
        direction: RiskPlanCalculator.Direction,
        entry: Double,
        stop: Double,
        target: Double,
        livePrice: Double,
    ): Double? {
        if (!entry.isFinite() || !stop.isFinite() || !target.isFinite() || !livePrice.isFinite()) return null
        val risk = abs(entry - stop)
        if (risk <= 0.0) return null
        val reward = when (direction) {
            RiskPlanCalculator.Direction.LONG -> target - livePrice
            RiskPlanCalculator.Direction.SHORT -> livePrice - target
        }
        // Remaining reward to target from live; if already past target, still report ratio using abs distances
        val remainingToTarget = when (direction) {
            RiskPlanCalculator.Direction.LONG -> target - livePrice
            RiskPlanCalculator.Direction.SHORT -> livePrice - target
        }
        val riskFromLive = when (direction) {
            RiskPlanCalculator.Direction.LONG -> livePrice - stop
            RiskPlanCalculator.Direction.SHORT -> stop - livePrice
        }
        if (riskFromLive <= 0.0) return null
        val rr = remainingToTarget / riskFromLive
        return rr.takeIf { it.isFinite() }
    }

    /** 0..1 position of [livePrice] between stop and target (direction-aware axis). */
    fun priceProgress(
        direction: RiskPlanCalculator.Direction,
        stop: Double,
        target: Double,
        livePrice: Double,
    ): Double {
        val span = abs(target - stop)
        if (span <= 0.0 || !livePrice.isFinite()) return 0.5
        val raw = when (direction) {
            RiskPlanCalculator.Direction.LONG -> (livePrice - stop) / span
            RiskPlanCalculator.Direction.SHORT -> (stop - livePrice) / span
        }
        return raw.coerceIn(0.0, 1.0)
    }

    fun snapTargetR(raw: Double): Double {
        val stepped = (raw / TARGET_R_STEP).toInt() * TARGET_R_STEP
        return (kotlin.math.round(stepped * 10.0) / 10.0).coerceIn(TARGET_R_MIN, TARGET_R_MAX)
    }

    fun formatPrice(value: Double): String {
        if (!value.isFinite()) return "—"
        return when {
            value >= 1000 -> ((kotlin.math.round(value * 100.0) / 100.0)).toString()
            value >= 1 -> ((kotlin.math.round(value * 10000.0) / 10000.0)).toString()
            else -> ((kotlin.math.round(value * 1e6) / 1e6)).toString()
        }
    }

    fun defaultNarrative(
        signal: Signal,
        confidence: Int,
        timeframe: String,
        shouldTrade: Boolean,
    ): List<String> {
        val dir = when (signal) {
            Signal.STRONG_BUY, Signal.BUY -> "偏多"
            Signal.STRONG_SELL, Signal.SELL -> "偏空"
            Signal.NEUTRAL -> "中性"
        }
        return listOf(
            "指标共识方向 $dir，置信度 ${confidence}%（$timeframe）。",
            if (shouldTrade) "已通过 shouldTrade 门槛，可展示参考计划价位。"
            else "未通过交易门槛或方向不明确，计划价位仅作研究参考或已隐藏。",
            "止损按 ATR×倍数，止盈随目标 R 滑块调整；不模拟资金费率与强平。",
        )
    }


    data class StructureBook(
        val supports: List<Double>,
        val resistances: List<Double>,
    )

    /**
     * Collect confirmed pivot highs/lows (same confirmation rule as ConfirmedStructureLevels)
     * and return up to [maxEach] supports below price and resistances above, nearest first.
     */
    fun structureBook(
        highs: List<Double>,
        lows: List<Double>,
        currentPrice: Double,
        k: Int = 2,
        maxEach: Int = 3,
    ): StructureBook {
        if (!currentPrice.isFinite() || currentPrice <= 0.0 || k < 1 ||
            highs.size != lows.size || highs.size < 2 * k + 1
        ) {
            return StructureBook(emptyList(), emptyList())
        }
        val supports = mutableListOf<Double>()
        val resistances = mutableListOf<Double>()
        for (i in k until highs.size - k) {
            val high = highs[i]
            val low = lows[i]
            if (!high.isFinite() || !low.isFinite() || high <= 0.0 || low <= 0.0 || high < low) continue
            var pivotHigh = true
            var pivotLow = true
            for (d in 1..k) {
                if (!(high > highs[i - d] && high > highs[i + d])) pivotHigh = false
                if (!(low < lows[i - d] && low < lows[i + d])) pivotLow = false
                if (!pivotHigh && !pivotLow) break
            }
            if (pivotLow && low < currentPrice) supports.add(low)
            if (pivotHigh && high > currentPrice) resistances.add(high)
        }
        val uniqueS = supports.distinct().sortedByDescending { it }.take(maxEach)
        val uniqueR = resistances.distinct().sortedBy { it }.take(maxEach)
        return StructureBook(uniqueS, uniqueR)
    }

    /** Simple period-SMA RSI series aligned to closes (NaN-like nulls for warm-up). */
    fun rsiSeries(closes: List<Double>, period: Int = 14): List<Double?> {
        if (period < 2 || closes.size <= period) return List(closes.size) { null }
        val out = MutableList<Double?>(closes.size) { null }
        for (end in period until closes.size) {
            var gain = 0.0
            var loss = 0.0
            for (i in (end - period + 1)..end) {
                val d = closes[i] - closes[i - 1]
                if (d >= 0) gain += d else loss -= d
            }
            val avgG = gain / period
            val avgL = loss / period
            val rsi = when {
                avgG == 0.0 && avgL == 0.0 -> 50.0
                avgL == 0.0 -> 100.0
                avgG == 0.0 -> 0.0
                else -> 100.0 - 100.0 / (1.0 + avgG / avgL)
            }
            out[end] = rsi
        }
        return out
    }

    data class MacdPoint(val macd: Double?, val signal: Double?, val hist: Double?)

    fun macdSeries(closes: List<Double>, fast: Int = 12, slow: Int = 26, signalPeriod: Int = 9): List<MacdPoint> {
        if (closes.size < 2) return List(closes.size) { MacdPoint(null, null, null) }
        val emaFast = Series.ewmAdjustFalse(closes, fast.coerceAtLeast(1))
        val emaSlow = Series.ewmAdjustFalse(closes, slow.coerceAtLeast(1))
        val macdLine = List(closes.size) { i -> emaFast[i] - emaSlow[i] }
        val signalLine = Series.ewmAdjustFalse(macdLine, signalPeriod.coerceAtLeast(1))
        return List(closes.size) { i ->
            val m = macdLine[i]
            val s = signalLine[i]
            MacdPoint(
                macd = if (m.isFinite()) m else null,
                signal = if (s.isFinite()) s else null,
                hist = if (m.isFinite() && s.isFinite()) m - s else null,
            )
        }
    }

    private fun ema(values: List<Double>, period: Int): List<Double?> {
        if (period < 1 || values.size < period) return List(values.size) { null }
        val k = 2.0 / (period + 1)
        val out = MutableList<Double?>(values.size) { null }
        var sum = 0.0
        for (i in 0 until period) sum += values[i]
        var prev = sum / period
        out[period - 1] = prev
        for (i in period until values.size) {
            prev = values[i] * k + prev * (1 - k)
            out[i] = prev
        }
        return out
    }

    private fun emaNullable(values: List<Double?>, period: Int): List<Double?> {
        val out = MutableList<Double?>(values.size) { null }
        val solid = values.mapIndexedNotNull { i, v -> v?.let { i to it } }
        if (solid.size < period) return out
        val k = 2.0 / (period + 1)
        var sum = 0.0
        for (j in 0 until period) sum += solid[j].second
        var prev = sum / period
        out[solid[period - 1].first] = prev
        for (j in period until solid.size) {
            prev = solid[j].second * k + prev * (1 - k)
            out[solid[j].first] = prev
        }
        return out
    }
}
