package com.diveintocrypto.android.domain.scanner

import com.diveintocrypto.android.domain.model.Candle

/** Deterministic historical strategy replay over candles. The default signal source is SMA crossover;
 * callers may inject a causal signal provider to replay the same indicator consensus used by the scanner.
 * Signals are evaluated at candle close and entry is simulated at the next candle open.
 */
object SmaCrossoverBacktest {
    data class HistoricalSignalDecision(
        val direction: RiskPlanCalculator.Direction?,
        /** True when the provider found a directional signal, even if quality/risk filters reject it. */
        val hasDirectionalSignal: Boolean,
        val eligible: Boolean = true,
    )
    data class Config(
        val fastPeriod: Int = 9,
        val slowPeriod: Int = 21,
        val stopPct: Double = 1.0,
        val targetPct: Double = 2.0,
        val feeSidePct: Double = 0.05,
        val slippageSidePct: Double = 0.02,
        val maxHoldingBars: Int = 48,
        /** Optional higher-timeframe candles. Only candles closed strictly before the signal candle are eligible. */
        val confirmationCandles: List<Candle> = emptyList(),
        val requireHigherTimeframeConfirmation: Boolean = false,
        val confirmationFastPeriod: Int = 9,
        val confirmationSlowPeriod: Int = 21,
        /** When enabled, stop distance is ATR(atrPeriod) * atrMultiplier and target is targetR times that risk. */
        val useAtrRiskPlan: Boolean = false,
        val atrPeriod: Int = 14,
        val atrMultiplier: Double = 1.5,
        val targetR: Double = 2.0,
        /** Use prior-candle rolling structure extreme with the shared structure-aware risk calculator. Requires ATR mode. */
        val useStructureStop: Boolean = false,
        val structureLookback: Int = 20,
        val structureBufferAtr: Double = 0.15,
        /** Optional causal signal provider. Receives only candles through signalIndex, never future bars. */
        val signalProvider: ((candlesThroughSignal: List<Candle>, signalIndex: Int) -> HistoricalSignalDecision)? = null,
    )

    data class Result(
        /** All raw directional signal events before eligibility / higher-timeframe filtering. */
        val signalCount: Int,
        val confirmedSignalCount: Int,
        val filteredSignalCount: Int,
        val summary: RiskPlanBacktester.Summary,
    )

    fun run(candles: List<Candle>, config: Config): Result {
        if (config.signalProvider == null) {
            require(config.fastPeriod > 0 && config.slowPeriod > config.fastPeriod) {
                "slowPeriod must be greater than positive fastPeriod"
            }
        }
        // Fixed-percentage values are irrelevant in ATR mode. Validate only the active
        // risk-plan inputs so stale/unused UI values cannot block an ATR backtest.
        if (!config.useAtrRiskPlan) {
            require(config.stopPct.isFinite() && config.stopPct > 0.0 && config.stopPct < 100.0 &&
                config.targetPct.isFinite() && config.targetPct > 0.0 && config.targetPct < 100.0) {
                "stop and target percentages must be between 0 and 100"
            }
        }
        require(config.feeSidePct.isFinite() && config.feeSidePct >= 0.0 &&
            config.slippageSidePct.isFinite() && config.slippageSidePct >= 0.0) { "cost assumptions must be non-negative" }
        require(config.maxHoldingBars >= 1) { "maxHoldingBars must be positive" }
        if (config.requireHigherTimeframeConfirmation) {
            require(config.confirmationFastPeriod > 0 && config.confirmationSlowPeriod > config.confirmationFastPeriod) {
                "confirmation slow period must be greater than positive fast period"
            }
        }
        if (config.useAtrRiskPlan) {
            require(config.atrPeriod >= 2) { "atrPeriod must be at least 2" }
            require(config.atrMultiplier.isFinite() && config.atrMultiplier > 0.0) { "atrMultiplier must be positive" }
            require(config.targetR.isFinite() && config.targetR > 0.0) { "targetR must be positive" }
            if (config.useStructureStop) {
                require(config.structureLookback >= 2) { "structureLookback must be at least 2" }
                require(config.structureBufferAtr.isFinite() && config.structureBufferAtr >= 0.0) { "structureBufferAtr must be non-negative" }
            }
        }
        require(!config.useStructureStop || config.useAtrRiskPlan) { "structure stop requires ATR risk plan" }

        // Use the same sanitizer as the scanner's higher-timeframe alignment and data-quality
        // report. Keeping one validation path prevents invalid volume records from surviving
        // this replay while being discarded by the scanner, and keeps duplicate-time semantics
        // identical across historical features.
        val usable = HistoricalCandleAlignment.sanitize(candles)
        val warmupBars = if (config.signalProvider == null) config.slowPeriod else 1
        if (usable.size <= warmupBars) return Result(0, 0, 0, RiskPlanBacktester.summarize(emptyList()))

        val closes = usable.map { it.close }
        val replayCandles = usable.map { RiskPlanBacktester.Candle(it.openTime, it.high, it.low, it.close, it.open) }
        // Use the same strict OHLC/time validation as the scanner-consensus alignment path.
        // This also validates open price and non-negative open time, which are needed for
        // consistent history sanitation even though the SMA filter itself uses closes only.
        val higher = HistoricalCandleAlignment.sanitize(config.confirmationCandles)
            // Confirmation bars must be ordered by when their information becomes available,
            // not merely by openTime. Equal close times remain separate entries but are both
            // excluded at an equal signal-close boundary by lastStrictlyClosedIndex().
            .sortedWith(compareBy<Candle> { it.closeTime }.thenBy { it.openTime })
        val higherCloses = higher.map { it.close }
        val higherCloseTimes = higher.map { it.closeTime }
        val trades = mutableListOf<RiskPlanBacktester.TradeResult>()
        var signals = 0
        var confirmedSignals = 0
        var filteredSignals = 0
        var i = warmupBars
        while (i < usable.lastIndex) {
            val decision = config.signalProvider?.invoke(usable.subList(0, i + 1), i)
            val direction = if (config.signalProvider != null) decision?.direction else {
                val fastNow = sma(closes, i, config.fastPeriod)
                val slowNow = sma(closes, i, config.slowPeriod)
                val fastPrev = sma(closes, i - 1, config.fastPeriod)
                val slowPrev = sma(closes, i - 1, config.slowPeriod)
                when {
                    fastPrev <= slowPrev && fastNow > slowNow -> RiskPlanCalculator.Direction.LONG
                    fastPrev >= slowPrev && fastNow < slowNow -> RiskPlanCalculator.Direction.SHORT
                    else -> null
                }
            }
            val hasSignal = if (config.signalProvider != null) decision?.hasDirectionalSignal == true else direction != null
            if (!hasSignal) {
                i++
                continue
            }
            signals++
            // Do not replay a signal as if candles were continuous when its indicator/risk
            // lookback crosses a material time gap. Include the next candle because entry is
            // simulated at its open; a gap between signal close and entry is not a valid adjacent fill.
            val gapLookback = maxOf(
                config.slowPeriod,
                if (config.requireHigherTimeframeConfirmation) config.confirmationSlowPeriod else 1,
                if (config.useAtrRiskPlan) config.atrPeriod else 1,
                if (config.useStructureStop) config.structureLookback else 1,
            )
            val gapWindowStart = maxOf(1, i - gapLookback + 1)
            if (HistoricalCandleAlignment.hasIntervalDiscontinuity(usable, gapWindowStart, i + 1)) {
                filteredSignals++
                i++
                continue
            }
            if (decision != null && (!decision.eligible || direction == null)) {
                filteredSignals++
                i++
                continue
            }
            if (direction == null) {
                filteredSignals++
                i++
                continue
            }
            val activeDirection = direction
            if (config.requireHigherTimeframeConfirmation) {
                // Binary search per signal avoids assuming signal closeTime is monotonic
                // and strictly excludes higher-timeframe bars closing at the same instant.
                val htfIndex = lastStrictlyClosedIndex(higherCloseTimes, usable[i].closeTime)
                if (htfIndex < config.confirmationSlowPeriod - 1) {
                    filteredSignals++
                    i++
                    continue
                }
                val htfFast = sma(higherCloses, htfIndex, config.confirmationFastPeriod)
                val htfSlow = sma(higherCloses, htfIndex, config.confirmationSlowPeriod)
                val trendAllows = when (activeDirection) {
                    RiskPlanCalculator.Direction.LONG -> htfFast > htfSlow
                    RiskPlanCalculator.Direction.SHORT -> htfFast < htfSlow
                }
                if (!trendAllows) {
                    filteredSignals++
                    i++
                    continue
                }
            }
            // The crossover is only known after candle i closes. A realistic bar-based
            // replay therefore enters at candle i+1 open, not at the already-observed
            // signal close. The simulator still evaluates candle i+1's high/low for exits.
            val entry = usable[i + 1].open
            if (!entry.isFinite() || entry <= 0.0) {
                filteredSignals++
                i++
                continue
            }
            // ATR uses only fully closed data available at the signal; risk levels are
            // anchored to the actual simulated next-open entry price.
            val atrValue = if (config.useAtrRiskPlan) atr(usable, i, config.atrPeriod) else null
            if (config.useAtrRiskPlan && (atrValue == null || !atrValue.isFinite() || atrValue <= 0.0)) {
                filteredSignals++
                i++
                continue
            }
            val riskPlan = if (config.useAtrRiskPlan) {
                val atr = requireNotNull(atrValue)
                val structureStop = if (config.useStructureStop && i >= 1) {
                    val from = maxOf(0, i - config.structureLookback)
                    val prior = usable.subList(from, i) // strictly prior candles; signal candle is excluded
                    when (activeDirection) {
                        RiskPlanCalculator.Direction.LONG -> prior.minOfOrNull { it.low }?.takeIf { it < entry }
                        RiskPlanCalculator.Direction.SHORT -> prior.maxOfOrNull { it.high }?.takeIf { it > entry }
                    }
                } else null
                StructureAwareRiskPlan.calculate(
                    StructureAwareRiskPlan.Inputs(
                        direction = activeDirection,
                        entry = entry,
                        atr = atr,
                        atrMultiplier = config.atrMultiplier,
                        targetR = config.targetR,
                        structureStop = structureStop,
                        structureBufferAtr = config.structureBufferAtr,
                    ),
                ).plan
            } else {
                val riskDistance = entry * config.stopPct / 100.0
                val rewardDistance = entry * config.targetPct / 100.0
                val stopPrice = if (direction == RiskPlanCalculator.Direction.LONG) entry - riskDistance else entry + riskDistance
                val targetPrice = if (direction == RiskPlanCalculator.Direction.LONG) entry + rewardDistance else entry - rewardDistance
                if (stopPrice <= 0.0 || targetPrice <= 0.0 || !stopPrice.isFinite() || !targetPrice.isFinite()) null else
                    RiskPlanCalculator.Plan(entry, stopPrice, targetPrice, riskDistance, rewardDistance, rewardDistance / riskDistance, riskDistance / entry * 100.0)
            }
            if (riskPlan == null) {
                filteredSignals++
                i++
                continue
            }
            confirmedSignals++
            // entryIndex denotes the signal candle; simulate() begins checking exits on
            // the next candle, which is also where the entry is filled at its open.
            val setup = RiskPlanBacktester.Setup(i, activeDirection, entry, riskPlan.stopLoss, riskPlan.takeProfit)
            val trade = RiskPlanBacktester.simulate(
                replayCandles, setup, config.feeSidePct, config.slippageSidePct, config.maxHoldingBars,
            )
            if (trade.reason != RiskPlanBacktester.ExitReason.INVALID_SETUP) trades += trade
            // One position at a time: skip candles consumed by this simulated trade.
            i = maxOf(i + 1, (trade.exitIndex ?: i) + 1)
        }
        return Result(signals, confirmedSignals, filteredSignals, RiskPlanBacktester.summarize(trades))
    }

    /** Simple-average true range; only candles up to and including the signal close are used. */
    private fun atr(candles: List<Candle>, endInclusive: Int, period: Int): Double? {
        if (period < 2 || endInclusive + 1 < period || endInclusive >= candles.size) return null
        var total = 0.0
        val start = endInclusive - period + 1
        for (index in start..endInclusive) {
            val candle = candles[index]
            val previousClose = if (index > 0) candles[index - 1].close else candle.open
            val trueRange = maxOf(candle.high - candle.low, kotlin.math.abs(candle.high - previousClose), kotlin.math.abs(candle.low - previousClose))
            if (!trueRange.isFinite() || trueRange < 0.0) return null
            total += trueRange
        }
        return total / period
    }

    /** Returns the last index whose close time is strictly earlier than the signal close time. */
    internal fun lastStrictlyClosedIndex(sortedCloseTimes: List<Long>, signalCloseTime: Long): Int {
        var low = 0
        var high = sortedCloseTimes.size - 1
        var answer = -1
        while (low <= high) {
            val mid = low + (high - low) / 2
            if (sortedCloseTimes[mid] < signalCloseTime) {
                answer = mid
                low = mid + 1
            } else {
                high = mid - 1
            }
        }
        return answer
    }

    private fun sma(values: List<Double>, endInclusive: Int, period: Int): Double {
        val start = endInclusive - period + 1
        if (start < 0 || endInclusive >= values.size || period <= 0) return Double.NaN
        var sum = 0.0
        for (i in start..endInclusive) sum += values[i]
        return sum / period
    }
}
