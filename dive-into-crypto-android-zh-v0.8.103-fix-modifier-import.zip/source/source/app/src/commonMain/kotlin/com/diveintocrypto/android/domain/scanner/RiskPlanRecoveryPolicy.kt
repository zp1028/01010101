package com.diveintocrypto.android.domain.scanner

/**
 * Deterministic recovery gate for display-only risk plans.
 * A fresh quote alone never revives a previously invalidated plan: lifecycle,
 * direction eligibility and multi-timeframe agreement must also be acceptable.
 */
object RiskPlanRecoveryPolicy {
    enum class State {
        WAIT_FOR_FRESH_DATA,
        INVALID_DATA,
        DIRECTION_REVERSED,
        RECOMPUTE_REQUIRED,
        MTF_CONFLICT,
        NO_DIRECTION,
        READY_TO_RECALCULATE,
    }

    data class Result(val state: State, val allowReferenceLevels: Boolean, val message: String)

    fun evaluate(
        freshness: MarketDataFreshness.Status,
        lifecycleStatus: String,
        eligibilityStatus: String,
        blockedByMtfConflict: Boolean,
    ): Result {
        // A stale/missing quote always blocks reference levels, regardless of other flags.
        if (freshness != MarketDataFreshness.Status.FRESH) {
            return Result(
                State.WAIT_FOR_FRESH_DATA,
                false,
                "行情未通过新鲜度检查；刷新有效 K 线后重新审核，不能直接恢复旧计划。"
            )
        }
        // Fresh data does not revive a plan invalidated by a changed thesis/price.
        // Fail closed for unknown lifecycle labels too: new enum values must not
        // silently become permission to display directional price levels.
        when (lifecycleStatus) {
            "DATA_INVALID" -> return Result(State.INVALID_DATA, false, "行情或方向数据无效；请重新扫描，不沿用旧计划。")
            "DIRECTION_REVERSED" -> return Result(State.DIRECTION_REVERSED, false, "方向已反转；旧计划失效，必须按新方向重新评估。")
            "PRICE_MOVED" -> return Result(State.RECOMPUTE_REQUIRED, false, "参考价变化较大；请用当前价格和 ATR 重新计算计划。")
            "NEW", "ACTIVE" -> Unit
            else -> return Result(State.RECOMPUTE_REQUIRED, false, "机会状态未知或尚未确认；暂停显示方向性价位，请重新扫描审核。")
        }
        if (blockedByMtfConflict || eligibilityStatus == "MTF_CONFLICT") {
            return Result(State.MTF_CONFLICT, false, "多周期仍有冲突；即使行情已恢复，也暂不显示方向性价位。")
        }
        if (eligibilityStatus != "ELIGIBLE") {
            return Result(State.NO_DIRECTION, false, "当前方向尚未通过审核；等待信号明确后再计算计划。")
        }
        return Result(State.READY_TO_RECALCULATE, true, "行情有效且当前方向通过基础审核；按当前数据重新计算参考计划，不恢复旧价位。")
    }
}
