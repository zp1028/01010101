package com.diveintocrypto.android.domain.scanner

/**
 * Reference-only percentage cost estimate. Percent inputs are percentage points
 * (0.05 means 0.05%). Entry costs are applied to entry notional; exit costs are
 * scaled by the estimated stop/target exit notional. This is not an exchange fill
 * simulator and excludes funding, liquidation, tiered fees and market impact.
 */
object RiskCostCalculator {
    data class Estimate(
        /** Conservative displayed cost: the larger of stop-path and target-path costs. */
        val roundTripCostPct: Double,
        val netRiskPct: Double,
        val netRewardPct: Double,
        val netRiskRewardRatio: Double?,
        val stopPathCostPct: Double,
        val targetPathCostPct: Double,
    )

    fun estimate(
        stopDistancePct: Double,
        targetDistancePct: Double,
        feeSidePct: Double,
        slippageSidePct: Double,
        direction: RiskPlanCalculator.Direction = RiskPlanCalculator.Direction.LONG,
    ): Estimate? {
        if (!stopDistancePct.isFinite() || stopDistancePct <= 0.0 || stopDistancePct >= 100.0) return null
        if (!targetDistancePct.isFinite() || targetDistancePct <= 0.0 || targetDistancePct >= 100.0) return null
        if (!feeSidePct.isFinite() || feeSidePct < 0.0) return null
        if (!slippageSidePct.isFinite() || slippageSidePct < 0.0) return null

        val sideCost = feeSidePct + slippageSidePct
        val stopExitNotionalFactor = when (direction) {
            RiskPlanCalculator.Direction.LONG -> 1.0 - stopDistancePct / 100.0
            RiskPlanCalculator.Direction.SHORT -> 1.0 + stopDistancePct / 100.0
        }
        val targetExitNotionalFactor = when (direction) {
            RiskPlanCalculator.Direction.LONG -> 1.0 + targetDistancePct / 100.0
            RiskPlanCalculator.Direction.SHORT -> 1.0 - targetDistancePct / 100.0
        }
        val stopPathCost = sideCost + sideCost * stopExitNotionalFactor
        val targetPathCost = sideCost + sideCost * targetExitNotionalFactor
        val netRisk = stopDistancePct + stopPathCost
        val netReward = targetDistancePct - targetPathCost
        val ratio = if (netRisk > 0.0 && netReward > 0.0) netReward / netRisk else null
        return Estimate(
            roundTripCostPct = maxOf(stopPathCost, targetPathCost),
            netRiskPct = netRisk,
            netRewardPct = netReward,
            netRiskRewardRatio = ratio,
            stopPathCostPct = stopPathCost,
            targetPathCostPct = targetPathCost,
        )
    }
}
