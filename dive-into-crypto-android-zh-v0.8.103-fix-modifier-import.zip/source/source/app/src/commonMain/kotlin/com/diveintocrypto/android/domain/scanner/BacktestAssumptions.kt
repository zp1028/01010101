package com.diveintocrypto.android.domain.scanner

/**
 * Explicit research-mode boundaries for historical replay and risk simulation.
 * Callers (UI, reports) should surface these so results are never mistaken for
 * exchange-accurate fills or live scanner parity when archives are missing.
 */
object BacktestAssumptions {

    /** What the OHLC backtester and risk calculators DO model. */
    val modeled: List<String> = listOf(
        "Next-bar open entry after signal close (no same-bar look-ahead)",
        "Conservative stop-first when stop and target both touch the same bar",
        "Gap open beyond stop/target resolved at open before intrabar high/low",
        "Path-aware fee + slippage aligned with RiskCostCalculator (entry + exit notional)",
        "ATR / structure stop and R-multiple targets from RiskPlanCalculator",
        "Causal candle prefixes and gap-aware signal filtering via HistoricalCandleAlignment",
        "Scanner consensus shouldTrade / confidence gates when signalProvider is used",
        "Ranking math identical to live scanner via ScannerRanking when cells are supplied",
    )

    /** What is intentionally NOT simulated — must not be fabricated. */
    val notModeled: List<String> = listOf(
        "Funding rate accruals between entry and exit",
        "Maintenance margin and liquidation price",
        "Tiered exchange fees, maker/taker distinction, and partial fills",
        "Order-book impact and queue position",
        "Historical 24h quote-volume universe ranking (requires archive)",
        "Whale L/S, open interest, taker flow series (requires archive)",
        "Live WebSocket reconnect / gap-fill of the market-data connection itself",
    )

    data class CostModelNote(
        val pathAware: Boolean,
        val includesFunding: Boolean,
        val includesLiquidation: Boolean,
        val summary: String,
    )

    fun costModelNote(): CostModelNote = CostModelNote(
        pathAware = true,
        includesFunding = false,
        includesLiquidation = false,
        summary = "Round-trip cost = (fee+slip) × (1 + exit/entry). Funding and liquidation are excluded.",
    )

    /**
     * Shared eligibility gate for directional consensus signals.
     * Mirrors ConsensusEngine.shouldTrade semantics so backtest signalProvider
     * and live scan do not diverge on confidence thresholds when both use the
     * engine output; this helper is for pure tests and non-engine paths.
     */
    fun isEligibleDirectional(
        hasDirectionalSignal: Boolean,
        confidence: Int,
        confidenceThreshold: Int,
        minConfidenceForTrade: Int,
    ): Boolean {
        if (!hasDirectionalSignal) return false
        if (confidence < confidenceThreshold) return false
        if (confidence < minConfidenceForTrade) return false
        return true
    }
}
