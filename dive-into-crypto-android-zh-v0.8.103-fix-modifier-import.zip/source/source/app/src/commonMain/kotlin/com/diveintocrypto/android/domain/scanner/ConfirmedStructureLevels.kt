package com.diveintocrypto.android.domain.scanner

/** Confirmed, non-repainting swing levels for reference-only risk planning. */
object ConfirmedStructureLevels {
    data class Levels(val support: Double?, val resistance: Double?)

    /**
     * Finds the nearest confirmed pivot low below and pivot high above current price.
     * A pivot is confirmed only after [k] candles on its right exist. Invalid or
     * insufficient series produce null levels rather than fabricated values.
     */
    fun find(highs: List<Double>, lows: List<Double>, currentPrice: Double, k: Int = 2): Levels {
        if (!currentPrice.isFinite() || currentPrice <= 0.0 || k < 1 || highs.size != lows.size || highs.size < 2 * k + 1) {
            return Levels(null, null)
        }
        var support: Double? = null
        var resistance: Double? = null
        for (i in k until highs.size - k) {
            val high = highs[i]
            val low = lows[i]
            if (!high.isFinite() || !low.isFinite() || high <= 0.0 || low <= 0.0 || high < low) continue
            var pivotHigh = true
            var pivotLow = true
            for (d in 1..k) {
                if (!(high > highs[i - d] && high > highs[i + d])) pivotHigh = false
                if (!(low < lows[i - d] && low < lows[i + d])) pivotLow = false
                if (!pivotHigh && !pivotLow) break
            }
            if (pivotLow && low < currentPrice && (support == null || low > support)) support = low
            if (pivotHigh && high > currentPrice && (resistance == null || high < resistance)) resistance = high
        }
        return Levels(support, resistance)
    }
}
