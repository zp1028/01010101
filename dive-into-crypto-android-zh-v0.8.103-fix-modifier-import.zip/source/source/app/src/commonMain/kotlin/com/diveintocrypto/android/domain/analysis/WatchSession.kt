package com.diveintocrypto.android.domain.analysis

import kotlin.math.abs

import com.diveintocrypto.android.domain.scanner.RiskPlanCalculator

/**
 * Local plan watch state machine for Analysis page (P2). No exchange orders.
 */
object WatchSession {

    enum class Status {
        IDLE,
        WATCHING,
        TOUCHED_ENTRY,
        HIT_SL,
        HIT_TP,
        INVALIDATED,
    }

    data class ArmedPlan(
        val symbol: String,
        val direction: RiskPlanCalculator.Direction,
        val entry: Double,
        val stopLoss: Double,
        val takeProfit: Double,
        val touchTolerancePct: Double = 0.05,
    )

    data class State(
        val enabled: Boolean,
        val status: Status,
        val message: String,
        val plan: ArmedPlan?,
    ) {
        companion object {
            val Idle = State(false, Status.IDLE, "未盯盘", null)
        }
    }

    fun arm(
        symbol: String,
        direction: RiskPlanCalculator.Direction,
        entry: Double,
        stopLoss: Double,
        takeProfit: Double,
    ): State {
        if (!entry.isFinite() || !stopLoss.isFinite() || !takeProfit.isFinite()) {
            return State(false, Status.INVALIDATED, "计划价位无效，无法盯盘", null)
        }
        val plan = ArmedPlan(symbol.uppercase(), direction, entry, stopLoss, takeProfit)
        return State(
            enabled = true,
            status = Status.WATCHING,
            message = "盯盘中 · ${plan.symbol} @ ${AnalysisPlanMath.formatPrice(entry)}",
            plan = plan,
        )
    }

    fun disarm(): State = State.Idle

    fun evaluate(current: State, livePrice: Double?): State {
        if (!current.enabled || current.plan == null) return current
        if (livePrice == null || !livePrice.isFinite() || livePrice <= 0.0) return current
        val p = current.plan
        val tol = p.touchTolerancePct / 100.0
        fun near(a: Double, b: Double) = abs(a - b) / b <= tol

        val hitSl = when (p.direction) {
            RiskPlanCalculator.Direction.LONG -> livePrice <= p.stopLoss || near(livePrice, p.stopLoss)
            RiskPlanCalculator.Direction.SHORT -> livePrice >= p.stopLoss || near(livePrice, p.stopLoss)
        }
        val hitTp = when (p.direction) {
            RiskPlanCalculator.Direction.LONG -> livePrice >= p.takeProfit || near(livePrice, p.takeProfit)
            RiskPlanCalculator.Direction.SHORT -> livePrice <= p.takeProfit || near(livePrice, p.takeProfit)
        }
        if (hitSl) {
            return current.copy(
                status = Status.HIT_SL,
                message = "已触发止损 ${AnalysisPlanMath.formatPrice(p.stopLoss)}（现价 ${AnalysisPlanMath.formatPrice(livePrice)}）",
            )
        }
        if (hitTp) {
            return current.copy(
                status = Status.HIT_TP,
                message = "已触发止盈 ${AnalysisPlanMath.formatPrice(p.takeProfit)}（现价 ${AnalysisPlanMath.formatPrice(livePrice)}）",
            )
        }
        val touchedEntry = when (p.direction) {
            RiskPlanCalculator.Direction.LONG -> livePrice <= p.entry * (1 + tol) && livePrice >= p.stopLoss
            RiskPlanCalculator.Direction.SHORT -> livePrice >= p.entry * (1 - tol) && livePrice <= p.stopLoss
        } || near(livePrice, p.entry)

        if (touchedEntry && current.status == Status.WATCHING) {
            return current.copy(
                status = Status.TOUCHED_ENTRY,
                message = "已触及入场位 ${AnalysisPlanMath.formatPrice(p.entry)}，等待动能确认。",
            )
        }
        if (current.status == Status.TOUCHED_ENTRY) {
            return current.copy(
                message = "已触及入场位 ${AnalysisPlanMath.formatPrice(p.entry)}，现价 ${AnalysisPlanMath.formatPrice(livePrice)}",
            )
        }
        return current.copy(
            status = Status.WATCHING,
            message = "盯盘中 · ${p.symbol} @ ${AnalysisPlanMath.formatPrice(livePrice)}",
        )
    }

    /** When user changes target R while watching, re-arm TP/SL on same entry. */
    fun updatePlan(current: State, stopLoss: Double, takeProfit: Double): State {
        val p = current.plan ?: return current
        if (!current.enabled) return current
        val next = p.copy(stopLoss = stopLoss, takeProfit = takeProfit)
        return current.copy(
            plan = next,
            message = "盯盘计划已更新 · SL ${AnalysisPlanMath.formatPrice(stopLoss)} / TP ${AnalysisPlanMath.formatPrice(takeProfit)}",
        )
    }
}
