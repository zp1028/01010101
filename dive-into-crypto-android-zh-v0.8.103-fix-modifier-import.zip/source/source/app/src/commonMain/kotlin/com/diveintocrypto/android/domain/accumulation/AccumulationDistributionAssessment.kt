package com.diveintocrypto.android.domain.accumulation

import kotlin.math.abs

/**
 * Evidence-based, descriptive accumulation/distribution assessment.
 * This is deliberately NOT a claim about identifiable actors or a probability of profit.
 * Inputs must be chronological (oldest -> newest) and from the same timeframe.
 */
object AccumulationDistributionAssessment {
    enum class Label { ACCUMULATION_SIGNS, DISTRIBUTION_SIGNS, MIXED, INSUFFICIENT_DATA }
    enum class Strength { WEAK, MODERATE, STRONG, UNAVAILABLE }

    data class Input(
        val high: List<Double>,
        val low: List<Double>,
        val close: List<Double>,
        val volume: List<Double>,
        /** Optional top-trader long/short ratio series; this is a proxy, not verified wallet flow. */
        val whaleLongShortRatio: List<Double>? = null,
    )

    data class Result(
        val label: Label,
        val strength: Strength,
        /** 0..100 evidence score, not a probability. */
        val evidenceScore: Int,
        val evidenceCount: Int,
        val reasons: List<String>,
        val invalidation: String,
    )

    fun assess(input: Input, lookback: Int = 20): Result {
        val n = minOf(input.high.size, input.low.size, input.close.size, input.volume.size)
        if (lookback < 5 || n < lookback + 1) return unavailable("K线数量不足：至少需要 ${lookback + 1} 根有效K线")
        val h = input.high.takeLast(n)
        val l = input.low.takeLast(n)
        val c = input.close.takeLast(n)
        val v = input.volume.takeLast(n)
        if ((0 until n).any { !h[it].isFinite() || !l[it].isFinite() || !c[it].isFinite() || !v[it].isFinite() || h[it] < l[it] || c[it] <= 0 || v[it] < 0 }) {
            return unavailable("行情数据包含无效值")
        }
        val start = n - lookback
        val first = c[start]
        val last = c[n - 1]
        val priceChange = (last - first) / first
        val avgVol = v.subList(start, n - 1).average().coerceAtLeast(1e-12)
        val recentVol = v[n - 1]
        val volumeRatio = recentVol / avgVol
        // Close Location Value weighted by volume: positive means closes tend toward candle highs.
        val clvVolume = (start until n).sumOf { i ->
            val range = (h[i] - l[i]).coerceAtLeast(1e-12)
            (((2.0 * c[i] - h[i] - l[i]) / range).coerceIn(-1.0, 1.0)) * v[i]
        }
        val totalVolume = v.subList(start, n).sum().coerceAtLeast(1e-12)
        val flow = clvVolume / totalVolume
        val rangeHigh = h.subList(start, n).maxOrNull() ?: last
        val rangeLow = l.subList(start, n).minOrNull() ?: last
        val position = ((last - rangeLow) / (rangeHigh - rangeLow).coerceAtLeast(1e-12)).coerceIn(0.0, 1.0)
        val reasons = mutableListOf<String>()
        var bull = 0
        var bear = 0
        if (priceChange <= -0.03 && flow >= 0.08) { bull++; reasons += "价格回落但成交量加权收盘位置偏强（潜在承接，尚未确认反转）" }
        if (priceChange >= 0.03 && flow <= -0.08) { bear++; reasons += "价格上涨但成交量加权收盘位置偏弱（潜在派发压力）" }
        if (position >= 0.70 && flow > 0.05) { bull++; reasons += "收盘位于观察区间上部，资金流代理指标为正" }
        if (position <= 0.30 && flow < -0.05) { bear++; reasons += "收盘位于观察区间下部，资金流代理指标为负" }
        if (volumeRatio >= 1.5 && abs(flow) >= 0.12) {
            if (flow > 0) { bull++; reasons += "最新K线放量且收盘位置偏强" }
            else { bear++; reasons += "最新K线放量且收盘位置偏弱" }
        }
        input.whaleLongShortRatio?.let { series ->
            if (series.size >= lookback + 1) {
                val a = series[series.size - lookback - 1]
                val b = series.last()
                if (a.isFinite() && b.isFinite() && a > 0.0) {
                    val delta = (b - a) / a
                    if (priceChange < -0.03 && delta >= 0.05) reasons += "价格下跌而大户多空比上升：仅作为背离线索，不代表真实买入"
                    if (priceChange > 0.03 && delta <= -0.05) reasons += "价格上涨而大户多空比下降：仅作为背离线索，不代表真实卖出"
                }
            }
        }
        val total = bull + bear
        if (total == 0) return Result(Label.MIXED, Strength.WEAK, 0, 0, listOf("当前没有足够一致的吸筹或派发证据"), "若价格结构或成交量证据反向，撤销当前观察")
        val score = ((maxOf(bull, bear).toDouble() / 3.0) * 100).toInt().coerceIn(0, 100)
        val label = when { bull > bear -> Label.ACCUMULATION_SIGNS; bear > bull -> Label.DISTRIBUTION_SIGNS; else -> Label.MIXED }
        val strength = when { score >= 90 && total >= 3 -> Strength.STRONG; score >= 60 -> Strength.MODERATE; else -> Strength.WEAK }
        val invalidation = when (label) {
            Label.ACCUMULATION_SIGNS -> "若价格有效跌破观察区间低点，吸筹假设失效；等待收盘确认"
            Label.DISTRIBUTION_SIGNS -> "若价格有效突破观察区间高点，派发假设失效；等待收盘确认"
            else -> "证据冲突时不据此单独开仓；等待价格结构确认"
        }
        return Result(label, strength, score, total, reasons.distinct(), invalidation)
    }

    private fun unavailable(reason: String) = Result(Label.INSUFFICIENT_DATA, Strength.UNAVAILABLE, 0, 0, listOf(reason), "数据恢复且满足最小K线数量后再评估")
}
