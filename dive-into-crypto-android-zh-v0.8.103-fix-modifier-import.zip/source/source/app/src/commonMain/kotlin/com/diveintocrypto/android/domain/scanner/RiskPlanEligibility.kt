package com.diveintocrypto.android.domain.scanner

import com.diveintocrypto.android.domain.model.Signal

/** Determines whether a directional reference risk plan is appropriate to display.
 * This is a UI safety gate only; it does not alter scanner scores or ranking.
 */
object RiskPlanEligibility {
    enum class Direction { LONG, SHORT }
    enum class Status { ELIGIBLE, NO_DIRECTION, MTF_CONFLICT }
    data class Result(val direction: Direction?, val status: Status)

    fun evaluate(dominantSignal: Signal, mtfDirection: Int): Result {
        val direction = when (dominantSignal) {
            Signal.BUY, Signal.STRONG_BUY -> Direction.LONG
            Signal.SELL, Signal.STRONG_SELL -> Direction.SHORT
            Signal.NEUTRAL -> null
        }
        if (direction == null) return Result(null, Status.NO_DIRECTION)
        val signalDirection = if (direction == Direction.LONG) 1 else -1
        if (mtfDirection != 0 && mtfDirection != signalDirection) {
            return Result(null, Status.MTF_CONFLICT)
        }
        return Result(direction, Status.ELIGIBLE)
    }
}
