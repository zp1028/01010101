package com.diveintocrypto.android.domain.scanner

/** Display-only risk triage. It does not change ranking or execute trades. */
object RiskPlanAssessment {
    enum class Level { REVIEW, CAUTION, HOLD, INVALID }
    data class Result(val level: Level, val label: String, val explanation: String)

    fun assess(
        lifecycleStatus: String,
        eligibilityStatus: String,
        netRiskRewardRatio: Double?,
        planAvailable: Boolean = true,
    ): Result {
        if (lifecycleStatus == "DATA_INVALID") {
            return Result(Level.INVALID, "数据无效", "价格或方向数据异常；不要沿用此风险计划")
        }
        if (lifecycleStatus == "DIRECTION_REVERSED") {
            return Result(Level.INVALID, "计划失效", "扫描方向已反转；原入场、止损和止盈需要重新评估")
        }
        if (lifecycleStatus == "PRICE_MOVED") {
            return Result(Level.HOLD, "需要重算", "参考价格变化较大；旧计划价位可能已不适用")
        }
        if (eligibilityStatus == "MTF_CONFLICT") {
            return Result(Level.HOLD, "周期冲突", "多周期方向不一致；暂不生成方向性执行结论")
        }
        if (eligibilityStatus == "NO_DIRECTION") {
            return Result(Level.HOLD, "方向不明确", "当前信号没有明确方向；等待更多确认")
        }
        // Fail closed when a future/unknown status reaches assessment directly. The UI
        // normally applies RiskPlanRecoveryPolicy first, but this domain boundary must
        // remain safe when reused by another caller.
        if (lifecycleStatus != "NEW" && lifecycleStatus != "ACTIVE") {
            return Result(Level.HOLD, "状态未知，暂停评估", "机会生命周期状态未知；重新扫描并通过审核前，不给出风险结论")
        }
        if (eligibilityStatus != "ELIGIBLE") {
            return Result(Level.HOLD, "资格状态未知，暂停评估", "方向资格状态未知；重新审核前，不给出风险结论")
        }
        // Never judge the economics of a fallback estimate when the current plan is
        // blocked by freshness, an unknown lifecycle state, or another eligibility gate.
        if (!planAvailable) {
            return Result(Level.HOLD, "暂不可评估", "当前风险计划未通过审核；先刷新行情并重新扫描，不使用隐藏计划的估算结果")
        }
        if (netRiskRewardRatio == null || !netRiskRewardRatio.isFinite() || netRiskRewardRatio <= 0.0) {
            return Result(Level.CAUTION, "成本后收益不足", "估算交易成本后目标净收益不为正；应重新评估")
        }
        if (netRiskRewardRatio < 1.0) {
            return Result(Level.CAUTION, "净盈亏比偏低", "扣除估算成本后的净盈亏比低于 1:1")
        }
        if (lifecycleStatus == "NEW") {
            return Result(Level.REVIEW, "等待确认", "新出现的机会尚缺少持续性验证；检查数据时效与结构位")
        }
        return Result(Level.REVIEW, "仍需人工审核", "净盈亏比达到基础门槛不代表策略有正期望；检查结构位、流动性及强平风险")
    }
}
