package com.diveintocrypto.android.domain.scanner

import com.diveintocrypto.android.domain.model.Candle

/** Utilities for building leakage-safe historical prefixes from exchange candles. */
object HistoricalCandleAlignment {
    /**
     * Removes malformed OHLC/time records, sorts by open time and collapses duplicate open times.
     * The last record for a duplicate timestamp wins, matching REST/WebSocket merge semantics.
     */
    fun sanitize(candles: List<Candle>): List<Candle> = candles.asSequence()
        .filter(::isValid)
        .sortedBy { it.openTime }
        .groupBy { it.openTime }
        .values
        .map { it.last() }
        .sortedBy { it.openTime }


    /**
     * Detects materially irregular open-time deltas without looking at future candles.
     * For each interval being checked, expected cadence is estimated from up to 32
     * immediately preceding intervals only. At least three prior intervals are required
     * before an interval can be classified. A delta deviating by more than 20% is a gap.
     */
    internal fun hasIntervalDiscontinuity(candles: List<Candle>, fromIndex: Int, toIndex: Int): Boolean {
        if (candles.size < 5 || fromIndex < 1 || toIndex <= fromIndex) return false
        val start = fromIndex.coerceAtLeast(1)
        val end = toIndex.coerceAtMost(candles.lastIndex)
        for (index in start..end) {
            // Causal baseline: only deltas ending before this candle. Never include this
            // interval or any later interval in the expected-cadence estimate.
            val priorStart = maxOf(1, index - 32)
            val priorDeltas = (priorStart until index)
                .map { candles[it].openTime - candles[it - 1].openTime }
                .filter { it > 0L }
                .sorted()
            if (priorDeltas.size < 3) continue
            val expected = priorDeltas[priorDeltas.size / 2].toDouble()
            if (expected <= 0.0) continue
            val delta = (candles[index].openTime - candles[index - 1].openTime).toDouble()
            if (kotlin.math.abs(delta - expected) > expected * 0.20) return true
        }
        return false
    }

    /** Returns only bars that were fully closed strictly before [signalCloseTime]. */
    fun closedBefore(candles: List<Candle>, signalCloseTime: Long): List<Candle> {
        if (signalCloseTime <= 0L || candles.isEmpty()) return emptyList()
        // Filter rather than takeWhile: malformed-but-valid-looking timestamp ordering must
        // not hide an earlier-closed bar that appears later in open-time order.
        return sanitize(candles).filter { it.closeTime < signalCloseTime }
    }

    private fun isValid(candle: Candle): Boolean =
        candle.openTime >= 0L && candle.closeTime > candle.openTime &&
            candle.open.isFinite() && candle.open > 0.0 &&
            candle.close.isFinite() && candle.close > 0.0 &&
            candle.high.isFinite() && candle.high > 0.0 &&
            candle.low.isFinite() && candle.low > 0.0 &&
            candle.volume.isFinite() && candle.volume >= 0.0 &&
            candle.high >= candle.low &&
            candle.high >= maxOf(candle.open, candle.close) &&
            candle.low <= minOf(candle.open, candle.close)
}
