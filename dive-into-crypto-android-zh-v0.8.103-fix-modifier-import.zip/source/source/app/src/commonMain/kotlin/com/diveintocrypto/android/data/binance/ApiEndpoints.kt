package com.diveintocrypto.android.data.binance

/**
 * Runtime-swappable Binance endpoint hosts.
 *
 * Mainland China often cannot reach `*.binance.com` without a tunnel. Users can
 * set a reverse-proxy base (e.g. Cloudflare Worker / self-hosted nginx) that
 * forwards `/fapi/...` and `/ws` paths to the official hosts. Defaults are the
 * official public endpoints.
 *
 * Change via Settings → 网络线路; takes effect on the next request (no restart).
 */
object ApiEndpoints {
    const val OFFICIAL_FUTURES_REST = "https://fapi.binance.com"
    const val OFFICIAL_SPOT_REST = "https://api.binance.com"
    const val OFFICIAL_FUTURES_WS = "wss://fstream.binance.com"

    /** Preset: Binance market-data-only host (spot REST only; may help some regions). */
    const val VISION_SPOT_REST = "https://data-api.binance.vision"

    @Volatile
    var futuresRest: String = OFFICIAL_FUTURES_REST

    @Volatile
    var spotRest: String = OFFICIAL_SPOT_REST

    @Volatile
    var futuresWs: String = OFFICIAL_FUTURES_WS

    fun applyFromSettings(restBase: String, wsBase: String, spotBase: String = OFFICIAL_SPOT_REST) {
        futuresRest = restBase.trim().trimEnd('/').ifEmpty { OFFICIAL_FUTURES_REST }
        futuresWs = wsBase.trim().trimEnd('/').ifEmpty { OFFICIAL_FUTURES_WS }
        spotRest = spotBase.trim().trimEnd('/').ifEmpty { OFFICIAL_SPOT_REST }
    }

    /** Built-in presets shown in Settings. */
    data class Preset(val id: String, val label: String, val rest: String, val ws: String)

    val PRESETS: List<Preset> = listOf(
        Preset("official", "官方（需可访问 Binance）", OFFICIAL_FUTURES_REST, OFFICIAL_FUTURES_WS),
        Preset("custom", "自定义代理", "", ""),
    )
}
