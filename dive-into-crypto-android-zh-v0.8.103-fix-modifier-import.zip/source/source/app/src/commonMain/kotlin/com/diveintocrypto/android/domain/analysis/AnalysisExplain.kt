package com.diveintocrypto.android.domain.analysis

import com.diveintocrypto.android.domain.model.Signal
import com.diveintocrypto.android.domain.scanner.RiskPlanCalculator
import com.diveintocrypto.android.domain.scanner.StructureAwareRiskPlan

/**
 * Local, non-LLM answers bound only to the current analysis snapshot (P3).
 */
object AnalysisExplain {

    data class Snapshot(
        val symbol: String,
        val timeframe: String,
        val signal: Signal,
        val confidence: Int,
        val shouldTrade: Boolean,
        val entry: Double?,
        val plan: RiskPlanCalculator.Plan?,
        val direction: RiskPlanCalculator.Direction?,
        val patternName: String?,
        val support: Double?,
        val resistance: Double?,
        val stopSource: String?,
        val livePrice: Double?,
    )

    data class Qa(val question: String, val answer: String)

    fun presetQuestions(): List<String> = listOf(
        "为什么是这个方向？",
        "止损止盈怎么来的？",
        "现在能不能做？",
        "支撑阻力在哪？",
        "形态说明了什么？",
    )

    fun answer(question: String, snap: Snapshot): String {
        val q = question.trim()
        return when {
            q.contains("方向") || q.contains("为什么") -> whyDirection(snap)
            q.contains("止损") || q.contains("止盈") || q.contains("计划") -> whyPlan(snap)
            q.contains("能不能") || q.contains("可以做") || q.contains("交易") -> canTrade(snap)
            q.contains("支撑") || q.contains("阻力") -> levels(snap)
            q.contains("形态") -> pattern(snap)
            else -> fallback(snap)
        }
    }

    fun allAnswers(snap: Snapshot): List<Qa> =
        presetQuestions().map { Qa(it, answer(it, snap)) }

    private fun whyDirection(s: Snapshot): String {
        val dir = when (s.signal) {
            Signal.STRONG_BUY, Signal.BUY -> "偏多"
            Signal.STRONG_SELL, Signal.SELL -> "偏空"
            Signal.NEUTRAL -> "中性"
        }
        return "当前 ${s.symbol}（${s.timeframe}）指标共识为 $dir，置信度 ${s.confidence}%。" +
            if (s.shouldTrade) "已通过 shouldTrade 门槛。" else "未通过交易门槛，方向仅供研究。"
    }

    private fun whyPlan(s: Snapshot): String {
        val p = s.plan ?: return "暂无有效方向计划（观望、数据过期或未分析）。"
        val src = s.stopSource ?: "ATR"
        return "入场锚定 ${AnalysisPlanMath.formatPrice(p.entry)}；止损 ${AnalysisPlanMath.formatPrice(p.stopLoss)}（来源：$src）；" +
            "止盈 ${AnalysisPlanMath.formatPrice(p.takeProfit)}（按目标 R=${AnalysisPlanMath.formatPrice(p.riskRewardRatio)} 推算）。" +
            "不模拟资金费率与强平。"
    }

    private fun canTrade(s: Snapshot): String {
        if (s.plan == null) return "当前无展示中的方向计划，不建议当作可执行信号。"
        if (!s.shouldTrade) return "共识未过交易门槛，页面计划仅为研究参考。"
        val live = s.livePrice?.let { "现价 ${AnalysisPlanMath.formatPrice(it)}。" } ?: ""
        return "系统仅提供参考价位，不会下单。$live 请自行判断风险与仓位。"
    }

    private fun levels(s: Snapshot): String {
        val parts = mutableListOf<String>()
        s.support?.let { parts.add("近端支撑 ${AnalysisPlanMath.formatPrice(it)}") }
        s.resistance?.let { parts.add("近端阻力 ${AnalysisPlanMath.formatPrice(it)}") }
        return if (parts.isEmpty()) "当前未识别到可用的已确认支撑/阻力。"
        else parts.joinToString("；") + "。切换图层可浏览多档结构位。"
    }

    private fun pattern(s: Snapshot): String {
        val name = s.patternName
        return if (name.isNullOrBlank()) "当前规则引擎未命中形态（宁缺毋滥）。"
        else "当前高亮形态：$name。形态为规则识别，非保证反转。"
    }

    private fun fallback(s: Snapshot): String =
        "请从预设问题中选择，或围绕方向/计划/结构/形态提问。当前标的 ${s.symbol} ${s.timeframe}，信号 ${s.signal.name}。"
}

/** Helpers to build structure-aware plans for the analysis page. */
object AnalysisStructurePlan {
    fun calculate(
        direction: RiskPlanCalculator.Direction,
        entry: Double,
        atr: Double,
        targetR: Double,
        structureStop: Double?,
        atrMultiplier: Double = AnalysisPlanMath.DEFAULT_ATR_MULTIPLIER,
    ): StructureAwareRiskPlan.Result {
        return StructureAwareRiskPlan.calculate(
            StructureAwareRiskPlan.Inputs(
                direction = direction,
                entry = entry,
                atr = atr,
                atrMultiplier = atrMultiplier,
                targetR = targetR,
                structureStop = structureStop,
            ),
        )
    }

    fun structureStopForDirection(
        direction: RiskPlanCalculator.Direction,
        support: Double?,
        resistance: Double?,
    ): Double? = when (direction) {
        RiskPlanCalculator.Direction.LONG -> support
        RiskPlanCalculator.Direction.SHORT -> resistance
    }
}
