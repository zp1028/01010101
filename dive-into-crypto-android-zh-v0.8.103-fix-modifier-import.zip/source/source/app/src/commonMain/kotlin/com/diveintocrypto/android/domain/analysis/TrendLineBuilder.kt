package com.diveintocrypto.android.domain.analysis

import com.diveintocrypto.android.domain.model.Candle

/** Simple swing-based trend segments for Analysis chart overlays (P2). */
object TrendLineBuilder {

    data class Segment(
        val fromIndex: Int,
        val toIndex: Int,
        val fromPrice: Double,
        val toPrice: Double,
        val rising: Boolean,
    )

    fun build(candles: List<Candle>, maxSegments: Int = 2): List<Segment> {
        if (candles.size < 8) return emptyList()
        val highs = swingHighs(candles, k = 2)
        val lows = swingLows(candles, k = 2)
        val out = mutableListOf<Segment>()
        // Rising: last two swing lows
        if (lows.size >= 2) {
            val a = lows[lows.size - 2]
            val b = lows.last()
            if (b.second > a.second && b.first > a.first) {
                out.add(Segment(a.first, b.first, a.second, b.second, rising = true))
            }
        }
        // Falling: last two swing highs
        if (highs.size >= 2) {
            val a = highs[highs.size - 2]
            val b = highs.last()
            if (b.second < a.second && b.first > a.first) {
                out.add(Segment(a.first, b.first, a.second, b.second, rising = false))
            }
        }
        return out.take(maxSegments)
    }

    private fun swingHighs(candles: List<Candle>, k: Int): List<Pair<Int, Double>> {
        val out = mutableListOf<Pair<Int, Double>>()
        for (i in k until candles.size - k) {
            val h = candles[i].high
            var ok = true
            for (d in 1..k) {
                if (!(h > candles[i - d].high && h > candles[i + d].high)) {
                    ok = false
                    break
                }
            }
            if (ok) out.add(i to h)
        }
        return out
    }

    private fun swingLows(candles: List<Candle>, k: Int): List<Pair<Int, Double>> {
        val out = mutableListOf<Pair<Int, Double>>()
        for (i in k until candles.size - k) {
            val l = candles[i].low
            var ok = true
            for (d in 1..k) {
                if (!(l < candles[i - d].low && l < candles[i + d].low)) {
                    ok = false
                    break
                }
            }
            if (ok) out.add(i to l)
        }
        return out
    }
}
