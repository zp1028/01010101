package com.diveintocrypto.android.domain.overlay

/**
 * Aligns two timestamped market series to the same fixed time buckets.
 * Timestamps are epoch milliseconds. If an endpoint returns duplicate samples
 * inside one bucket, the chronologically last sample wins. The result contains
 * only buckets present in both sources, preventing tail-truncation from pairing
 * observations from different times.
 */
object TimestampSeriesAlignment {
    data class PairSeries(val timestamps: List<Long>, val left: List<Double>, val right: List<Double>)

    fun align(
        left: List<Pair<Long, Double>>,
        right: List<Pair<Long, Double>>,
        bucketMillis: Long = 3_600_000L,
    ): PairSeries {
        if (bucketMillis <= 0L) return PairSeries(emptyList(), emptyList(), emptyList())

        fun bucketLast(points: List<Pair<Long, Double>>): Map<Long, Double> {
            val ordered = points.filter { it.first >= 0L && it.second.isFinite() }.sortedBy { it.first }
            val result = linkedMapOf<Long, Double>()
            ordered.forEach { (timestamp, value) -> result[timestamp / bucketMillis * bucketMillis] = value }
            return result
        }

        val a = bucketLast(left)
        val b = bucketLast(right)
        val common = a.keys.intersect(b.keys).sorted()
        return PairSeries(common, common.mapNotNull(a::get), common.mapNotNull(b::get))
    }
}
