package com.diveintocrypto.android.domain.outcomes

import com.diveintocrypto.android.data.SettingsStore
import com.diveintocrypto.android.data.ai.AiAnalysisClient
import com.diveintocrypto.android.domain.alerts.AlertKind
import com.diveintocrypto.android.domain.alerts.AlertRule
import com.diveintocrypto.android.domain.alerts.FiredAlert
import com.diveintocrypto.android.domain.model.Candle
import com.diveintocrypto.android.domain.scanner.RiskPlanCalculator
import com.diveintocrypto.android.engine.MarketDataEngine
import com.diveintocrypto.android.platform.nowMillis
import com.diveintocrypto.android.platform.synchronized
import kotlinx.atomicfu.locks.SynchronizedObject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/**
 * Outcome journal — the "signals → verified results" closed loop.
 *
 * Records two kinds of events and follows what actually happened afterwards,
 * using the same futures kline feed the app already consumes:
 *
 *  1. **Fired alerts** (from [AlertEngine]): for direction-known alerts (VERDICT
 *     LONG/SHORT, PRICE_ABOVE/BELOW) tracks the forward move vs the price at fire
 *     time. Within a 24h horizon a favorable move of +3% (or −3% for SHORT) counts
 *     as [AlertTrackState.WON], an adverse move of the same size as
 *     [AlertTrackState.LOST]; neither within the horizon → [AlertTrackState.EXPIRED].
 *     Alerts without a determinable direction (CONFIDENCE_ABOVE / OI_SPIKE_PCT)
 *     are recorded as [AlertTrackState.NA] — never graded.
 *
 *  2. **AI plans** (from [AiAnalysisClient.AiPlan] via the AI session): follows the
 *     entry/SL/TP state machine — [PlanTrackState.WAITING_ENTRY] → entry touched →
 *     [PlanTrackState.ENTERED] → whichever of TP/SL is touched first →
 *     [PlanTrackState.TP_HIT] / [PlanTrackState.SL_HIT]; the 24h horizon expiring
 *     without resolution → [PlanTrackState.EXPIRED].
 *
 * The journal is deliberately INFORMATIONAL (like the rest of the app): it never
 * places orders; it only measures, and surfaces the measured quality of the
 * signals the app produces. Persistence mirrors [AlertEngine] (JSON blob in
 * [SettingsStore], no Room). All grading is pure ([resolveAlert]/[resolvePlan])
 * and the network pass is bounded ([MAX_FETCHES_PER_CYCLE] per refresh).
 */
class OutcomeJournal(
    private val settingsStore: SettingsStore,
    /** Lazily resolves the market-data engine so constructing the journal is cheap. */
    private val repositoryProvider: () -> MarketDataEngine,
    /** Resolves a rule by id at record time (rules may be deleted later). */
    private val rulesProvider: () -> List<AlertRule>,
    /** Live last-price snapshot at fire time (best effort; null → kline open fallback). */
    private val tickerPrice: (String) -> Double?,
    /** Fired-alert ring — replayed on collect, deduplicated by (ruleId, symbol, firedTs). */
    private val firedHistoryFlow: StateFlow<List<FiredAlert>>,
    /** AI session — replayed on collect; plans deduplicated by (symbol, entry, stop, target). */
    private val sessionFlow: StateFlow<com.diveintocrypto.android.ai.AiSessionHub.Session>,
    refreshIntervalMs: Long = REFRESH_INTERVAL_MS,
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default),
) {

    companion object {
        const val KEY = "outcome_journal_v1"

        /** Forward-look horizon for both alerts and plans. */
        const val ALERT_HORIZON_MS = 24L * 60 * 60 * 1000
        const val PLAN_HORIZON_MS = 24L * 60 * 60 * 1000

        /** Directional move (%) that counts as 达标 / 止损 for alert grading. */
        const val ALERT_TARGET_PCT = 3.0
        const val ALERT_STOP_PCT = 3.0
        const val ALERT_INTERVAL = "1h"
        const val ALERT_FETCH_LIMIT = 28

        const val REFRESH_INTERVAL_MS = 15L * 60 * 1000
        const val MIN_REFRESH_GAP_MS = 60_000L
        const val MAX_FETCHES_PER_CYCLE = 10
        const val MAX_ALERTS = 200
        const val MAX_PLANS = 100
    }

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val lock = SynchronizedObject()
    private val _data = MutableStateFlow(load())
    val data: StateFlow<OutcomeJournalData> = _data.asStateFlow()

    init {
        // Delayed collectors keep app startup cheap; the flows replay their
        // current value so nothing recorded before the journal starts is lost.
        scope.launch {
            delay(2_000)
            firedHistoryFlow.collect { history -> recordAlerts(history) }
        }
        scope.launch {
            delay(2_000)
            sessionFlow.collect { s ->
                s.lastPlan?.let { plan -> recordPlan(plan, s.symbol, s.timeframe) }
            }
        }
        scope.launch {
            while (isActive) {
                refresh()
                delay(refreshIntervalMs)
            }
        }
    }

    // ── Recording ──────────────────────────────────────────────────────────

    /** Records one fired alert (deduplicated by ruleId + symbol + firedTs). */
    fun recordAlert(fired: FiredAlert) = recordAlerts(listOf(fired))

    private fun recordAlerts(firedList: List<FiredAlert>) {
        var added = false
        synchronized(lock) {
            val d = _data.value
            var list = d.alerts
            for (fired in firedList) {
                val sym = fired.symbol.uppercase()
                if (list.any { it.ruleId == fired.ruleId && it.symbol == sym && it.firedTs == fired.firedTs }) continue
                val direction = directionOf(fired)
                val price = tickerPrice(sym)?.takeIf { it.isFinite() && it > 0.0 }
                list = (listOf(
                    AlertTrack(
                        ruleId = fired.ruleId,
                        symbol = sym,
                        kind = fired.kind.name,
                        direction = direction,
                        firedTs = fired.firedTs,
                        priceAtFire = price,
                        state = if (direction == 0) AlertTrackState.NA else AlertTrackState.TRACKING,
                        updatedAt = nowMillis(),
                    ),
                ) + list).take(MAX_ALERTS)
                added = true
            }
            if (added) {
                _data.value = OutcomeJournalData(list, d.plans)
                persist()
            }
        }
        if (added) scheduleRefresh()
    }

    /** Records one AI plan (deduplicated while an identical plan is still open). */
    fun recordPlan(plan: AiAnalysisClient.AiPlan, symbol: String, timeframe: String) {
        val sym = symbol.uppercase()
        val direction = when (plan.direction) {
            RiskPlanCalculator.Direction.LONG -> 1
            RiskPlanCalculator.Direction.SHORT -> -1
        }
        var added = false
        synchronized(lock) {
            val d = _data.value
            val stillOpen = d.plans.any {
                it.symbol == sym && it.entry == plan.entry && it.stop == plan.stopLoss && it.target == plan.takeProfit &&
                    (it.state == PlanTrackState.WAITING_ENTRY || it.state == PlanTrackState.ENTERED)
            }
            if (!stillOpen) {
                val entry = PlanTrack(
                    symbol = sym,
                    timeframe = timeframe.ifBlank { "15m" },
                    direction = direction,
                    entry = plan.entry,
                    stop = plan.stopLoss,
                    target = plan.takeProfit,
                    createdAt = nowMillis(),
                    state = PlanTrackState.WAITING_ENTRY,
                    updatedAt = nowMillis(),
                )
                _data.value = OutcomeJournalData(d.alerts, (listOf(entry) + d.plans).take(MAX_PLANS))
                persist()
                added = true
            }
        }
        if (added) scheduleRefresh()
    }

    // ── Refresh ────────────────────────────────────────────────────────────

    /**
     * Fetches futures klines for all still-open items (bounded:
     * [MAX_FETCHES_PER_CYCLE] (symbol, interval) pairs per pass) and grades them.
     * No-op when nothing is open or a refresh just ran.
     */
    suspend fun refresh() {
        if (refreshing) return
        val snapshot = _data.value
        val openAlerts = snapshot.alerts.filter { it.state == AlertTrackState.TRACKING && it.direction != 0 }
        val openPlans = snapshot.plans.filter {
            it.state == PlanTrackState.WAITING_ENTRY || it.state == PlanTrackState.ENTERED
        }
        if (openAlerts.isEmpty() && openPlans.isEmpty()) return
        if (nowMillis() - lastRefresh < MIN_REFRESH_GAP_MS) return
        refreshing = true
        try {
            lastRefresh = nowMillis()
            val engine = repositoryProvider()
            val pairs = mutableListOf<Pair<String, String>>()
            openAlerts.forEach { pairs.add(it.symbol to ALERT_INTERVAL) }
            openPlans.forEach { pairs.add(it.symbol to it.timeframe) }
            val unique = pairs.distinct().take(MAX_FETCHES_PER_CYCLE)
            var changed = false
            for ((symbol, interval) in unique) {
                val limit = if (interval.equals(ALERT_INTERVAL, ignoreCase = true)) ALERT_FETCH_LIMIT
                else planFetchLimit(interval)
                val candles = runCatching { engine.futuresHistory(symbol, interval, limit) }.getOrNull()
                if (candles == null || candles.isEmpty()) continue
                val now = nowMillis()
                synchronized(lock) {
                    val d = _data.value
                    val a2 = d.alerts.map {
                        if (it.symbol == symbol && it.state == AlertTrackState.TRACKING && it.direction != 0) resolveAlert(it, candles, now)
                        else it
                    }
                    val p2 = d.plans.map {
                        if (it.symbol == symbol &&
                            (it.state == PlanTrackState.WAITING_ENTRY || it.state == PlanTrackState.ENTERED)
                        ) resolvePlan(it, candles, now) else it
                    }
                    if (a2 != d.alerts || p2 != d.plans) {
                        changed = true
                        _data.value = OutcomeJournalData(a2, p2)
                    }
                }
            }
            if (changed) persist()
        } finally {
            refreshing = false
        }
    }

    /** Non-suspending refresh trigger (record-time and UI convenience). */
    fun refreshAsync() {
        if (nowMillis() - lastRefresh < MIN_REFRESH_GAP_MS) return
        scope.launch { refresh() }
    }

    // ── Grading (pure) ─────────────────────────────────────────────────────

    /** Direction known? +1 LONG-biased, −1 SHORT-biased, 0 = cannot grade. */
    private fun directionOf(fired: FiredAlert): Int = when (fired.kind) {
        AlertKind.VERDICT -> {
            val rule = rulesProvider().firstOrNull { it.id == fired.ruleId }
            when (rule?.direction) {
                AlertRule.DIRECTION_LONG -> 1
                AlertRule.DIRECTION_SHORT -> -1
                else -> 0
            }
        }
        AlertKind.PRICE_ABOVE -> 1
        AlertKind.PRICE_BELOW -> -1
        else -> 0
    }

    internal fun resolveAlert(t: AlertTrack, candles: List<Candle>, now: Long): AlertTrack {
        val after = candles.filter { it.openTime >= t.firedTs }
        if (after.isEmpty()) return t
        val price = t.priceAtFire ?: after.first().open
        if (price <= 0.0 || !price.isFinite()) return t
        val base = t.copy(priceAtFire = t.priceAtFire ?: price)
        val maxHigh = after.maxOfOrNull { it.high }
        val minLow = after.minOfOrNull { it.low }
        val latest = after.last().close
        val d = base.direction
        val targetPx = if (d > 0) price * (1 + ALERT_TARGET_PCT / 100.0) else price * (1 - ALERT_TARGET_PCT / 100.0)
        val stopPx = if (d > 0) price * (1 - ALERT_STOP_PCT / 100.0) else price * (1 + ALERT_STOP_PCT / 100.0)
        var state = base.state
        var decidedAt = base.decidedAt
        if (d > 0) {
            val hitTarget = after.indexOfFirst { it.high >= targetPx }
            val hitStop = after.indexOfFirst { it.low <= stopPx }
            when {
                hitTarget >= 0 && (hitStop < 0 || hitTarget < hitStop) -> { state = AlertTrackState.WON; decidedAt = after[hitTarget].openTime }
                hitStop >= 0 -> { state = AlertTrackState.LOST; decidedAt = after[hitStop].openTime }
            }
        } else {
            val hitTarget = after.indexOfFirst { it.low <= targetPx }
            val hitStop = after.indexOfFirst { it.high >= stopPx }
            when {
                hitTarget >= 0 && (hitStop < 0 || hitTarget < hitStop) -> { state = AlertTrackState.WON; decidedAt = after[hitTarget].openTime }
                hitStop >= 0 -> { state = AlertTrackState.LOST; decidedAt = after[hitStop].openTime }
            }
        }
        if (state == AlertTrackState.TRACKING && now - base.firedTs >= ALERT_HORIZON_MS) {
            state = AlertTrackState.EXPIRED
            decidedAt = now
        }
        val forward = if (price > 0.0) (latest - price) / price * 100.0 * d else null
        return base.copy(
            state = state,
            maxHigh = maxHigh,
            minLow = minLow,
            latestPrice = latest,
            forwardPct = forward,
            decidedAt = decidedAt,
            updatedAt = now,
        )
    }

    internal fun resolvePlan(p: PlanTrack, candles: List<Candle>, now: Long): PlanTrack {
        val after = candles.filter { it.openTime >= p.createdAt }
        if (after.isEmpty()) return p
        val latest = after.last().close
        val d = p.direction
        return when (p.state) {
            PlanTrackState.WAITING_ENTRY -> {
                val hit = if (d > 0) after.indexOfFirst { it.low <= p.entry }
                else after.indexOfFirst { it.high >= p.entry }
                when {
                    hit >= 0 -> p.copy(state = PlanTrackState.ENTERED, enteredAt = after[hit].openTime, latestPrice = latest, updatedAt = now)
                    now - p.createdAt >= PLAN_HORIZON_MS -> p.copy(state = PlanTrackState.EXPIRED, decidedAt = now, latestPrice = latest, updatedAt = now)
                    else -> p.copy(latestPrice = latest, updatedAt = now)
                }
            }
            PlanTrackState.ENTERED -> {
                val from = if (p.enteredAt != null) after.filter { it.openTime >= p.enteredAt } else after
                if (from.isEmpty()) return p.copy(latestPrice = latest, updatedAt = now)
                val hitT = if (d > 0) from.indexOfFirst { it.high >= p.target }
                else from.indexOfFirst { it.low <= p.target }
                val hitS = if (d > 0) from.indexOfFirst { it.low <= p.stop }
                else from.indexOfFirst { it.high >= p.stop }
                val decided: Pair<PlanTrackState, Long>? = when {
                    hitT >= 0 && (hitS < 0 || hitT < hitS) -> PlanTrackState.TP_HIT to from[hitT].openTime
                    hitS >= 0 -> PlanTrackState.SL_HIT to from[hitS].openTime
                    now - p.createdAt >= PLAN_HORIZON_MS -> PlanTrackState.EXPIRED to now
                    else -> null
                }
                if (decided != null) {
                    p.copy(state = decided.first, decidedAt = decided.second, latestPrice = latest, updatedAt = now)
                } else p.copy(latestPrice = latest, updatedAt = now)
            }
            else -> p
        }
    }

    // ── Persistence ────────────────────────────────────────────────────────

    private fun persist() {
        runCatching { settingsStore.putRaw(KEY, json.encodeToString(OutcomeJournalData.serializer(), _data.value)) }
    }

    private fun load(): OutcomeJournalData = runCatching {
        val raw = settingsStore.getRaw(KEY) ?: return OutcomeJournalData()
        if (raw.isBlank()) OutcomeJournalData()
        else json.decodeFromString(OutcomeJournalData.serializer(), raw)
    }.getOrDefault(OutcomeJournalData())

    private fun intervalMs(interval: String): Long = when (interval.lowercase()) {
        "1m" -> 60_000L
        "3m" -> 3 * 60_000L
        "5m" -> 5 * 60_000L
        "15m" -> 15 * 60_000L
        "30m" -> 30 * 60_000L
        "1h" -> 3_600_000L
        "2h" -> 2 * 3_600_000L
        "4h" -> 4 * 3_600_000L
        "6h" -> 6 * 3_600_000L
        "8h" -> 8 * 3_600_000L
        "12h" -> 12 * 3_600_000L
        "1d" -> 86_400_000L
        else -> 3_600_000L
    }

    private fun planFetchLimit(interval: String): Int {
        val ms = intervalMs(interval)
        return (((PLAN_HORIZON_MS + ms - 1) / ms) + 2).toInt().coerceAtMost(1500)
    }

    @Volatile private var refreshing = false
    @Volatile private var lastRefresh = 0L

    private fun scheduleRefresh() {
        if (nowMillis() - lastRefresh < MIN_REFRESH_GAP_MS) return
        scope.launch { refresh() }
    }
}

/** Grading state for a fired alert. */
@Serializable
enum class AlertTrackState { TRACKING, WON, LOST, EXPIRED, NA }

/** Grading state for an AI plan. */
@Serializable
enum class PlanTrackState { WAITING_ENTRY, ENTERED, TP_HIT, SL_HIT, EXPIRED, NA }

/** One tracked fired alert. */
@Serializable
data class AlertTrack(
    val ruleId: String,
    val symbol: String,
    val kind: String,
    /** +1 LONG-biased, −1 SHORT-biased, 0 = not gradable (NA). */
    val direction: Int,
    val firedTs: Long,
    val priceAtFire: Double? = null,
    val state: AlertTrackState = AlertTrackState.TRACKING,
    val maxHigh: Double? = null,
    val minLow: Double? = null,
    val latestPrice: Double? = null,
    /** Direction-signed forward return vs [priceAtFire] (%), >0 = favorable. */
    val forwardPct: Double? = null,
    val decidedAt: Long? = null,
    val updatedAt: Long = 0,
)

/** One tracked AI plan. */
@Serializable
data class PlanTrack(
    val symbol: String,
    val timeframe: String,
    val direction: Int,
    val entry: Double,
    val stop: Double,
    val target: Double,
    val createdAt: Long,
    val state: PlanTrackState = PlanTrackState.WAITING_ENTRY,
    val enteredAt: Long? = null,
    val latestPrice: Double? = null,
    val decidedAt: Long? = null,
    val updatedAt: Long = 0,
)

/** Persisted journal payload (JSON blob under [OutcomeJournal.KEY]). */
@Serializable
data class OutcomeJournalData(
    val alerts: List<AlertTrack> = emptyList(),
    val plans: List<PlanTrack> = emptyList(),
)
