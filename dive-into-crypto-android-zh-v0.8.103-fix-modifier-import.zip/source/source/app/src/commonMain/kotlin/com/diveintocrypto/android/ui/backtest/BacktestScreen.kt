package com.diveintocrypto.android.ui.backtest

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.diveintocrypto.android.AppContainer
import com.diveintocrypto.android.domain.scanner.HistoricalCandleAlignment
import com.diveintocrypto.android.domain.scanner.HistoricalDataQuality
import com.diveintocrypto.android.domain.scanner.RiskPlanBacktester
import com.diveintocrypto.android.domain.scanner.SmaCrossoverBacktest
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.async
import com.diveintocrypto.android.domain.scanner.ScannerRanking
import com.diveintocrypto.android.domain.scanner.HistoricalScannerReplay
import com.diveintocrypto.android.platform.nowMillis
import com.diveintocrypto.android.ui.theme.DiveColors
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Historical, public-market-data-only strategy replay. It never submits orders. */
@Composable
fun BacktestScreen(container: AppContainer) {
    val aiSession by container.aiSessionHub.session.collectAsState()
    var symbol by remember { mutableStateOf(container.activeSymbol.value) }
    var timeframe by remember { mutableStateOf("1h") }
    var candleCount by remember { mutableStateOf(300) }
    var fastPeriod by remember { mutableStateOf(9) }
    var slowPeriod by remember { mutableStateOf(21) }
    var useHigherTimeframe by remember { mutableStateOf(true) }
    var useScannerConsensus by remember { mutableStateOf(false) }
    var useAtrRiskPlan by remember { mutableStateOf(true) }
    var atrPeriod by remember { mutableStateOf("14") }
    var atrMultiplier by remember { mutableStateOf("1.5") }
    var targetR by remember { mutableStateOf("2.0") }
    var useStructureStop by remember { mutableStateOf(true) }
    var structureLookback by remember { mutableStateOf("20") }
    var structureBufferAtr by remember { mutableStateOf("0.15") }
    var stopPct by remember { mutableStateOf("1.0") }
    var targetPct by remember { mutableStateOf("2.0") }
    var feeSidePct by remember { mutableStateOf("0.05") }
    var slippageSidePct by remember { mutableStateOf("0.02") }
    var isLoading by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("选择参数后点击“运行回测”。将从币安 USDT 永续公开接口读取历史 K 线。") }
    var result by remember { mutableStateOf<BacktestOutput?>(null) }
    var rankingSymbols by remember { mutableStateOf("BTCUSDT,ETHUSDT,SOLUSDT,BNBUSDT,XRPUSDT") }
    var rankingLoading by remember { mutableStateOf(false) }
    var rankingStatus by remember { mutableStateOf("输入多个交易对，按当前公开 K 线在「最近已收盘」时点做扫描器排名回放（不含历史成交额宇宙与资金流存档）。") }
    var rankingReport by remember { mutableStateOf<HistoricalScannerReplay.ReplayReport?>(null) }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier.fillMaxSize().background(DiveColors.RootBg)
            .verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("历史回测（研究模式）", fontWeight = FontWeight.Bold, color = DiveColors.Text)
        Text("仅使用币安公开历史行情；不连接账户、不下单。可选择 SMA 示例策略，或逐根重算扫描器指标共识进行历史回放。", color = DiveColors.TextMuted)

        // ── Multi-symbol scanner ranking replay (Stage 4 foundation) ──────────
        Text("扫描器排名回放（多标的）", fontWeight = FontWeight.Bold, color = DiveColors.Text)
        Text(
            "对输入交易对在 Phase1 周期（1d/12h/8h）上做因果共识评估，再用与实盘相同的 ScannerRanking 产生 phase-2 幸存者与 cross-rank。无历史 24h 成交额宇宙与 whale/资金流存档时会在结果中标明限制。",
            color = DiveColors.TextMuted,
        )
        OutlinedTextField(
            value = rankingSymbols,
            onValueChange = { rankingSymbols = it },
            label = { Text("交易对（逗号分隔）") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Button(
            onClick = {
                if (rankingLoading) return@Button
                rankingLoading = true
                rankingReport = null
                rankingStatus = "正在按公开 K 线做因果排名回放…"
                val symbols = rankingSymbols.split(Regex("[,\\s]+"))
                    .map { it.trim().uppercase() }
                    .filter { it.isNotEmpty() }
                    .distinct()
                    .take(20)
                scope.launch {
                    try {
                        if (symbols.isEmpty()) {
                            rankingStatus = "请至少输入一个交易对。"
                            return@launch
                        }
                        suspend fun evalCell(sym: String, tf: String): HistoricalScannerReplay.CausalCell? {
                            val raw = try {
                                container.repository.futuresHistory(sym, tf, limit = 300)
                            } catch (_: Throwable) {
                                emptyList()
                            }
                            if (raw.isEmpty()) return null
                            val sanitized = HistoricalCandleAlignment.sanitize(raw)
                            if (sanitized.size < 30) return null
                            val cut = sanitized.last().closeTime.takeIf { it > 0L }
                                ?: (sanitized.last().openTime + 1)
                            val prefix = HistoricalScannerReplay.causalPrefix(sanitized, cut)
                            if (prefix.size < 30) return null
                            val indicatorOuts = container.indicators.map { it.calculate(prefix) }
                            val consensus = container.consensus.evaluate(indicatorOuts)
                            return HistoricalScannerReplay.buildCausalCell(
                                symbol = sym,
                                timeframe = tf,
                                signal = consensus.finalSignal,
                                confidence = consensus.confidence,
                                prefix = prefix,
                                cutTimeMs = cut,
                            )
                        }
                        // Phase 1: all symbols × high-weight TFs (mirrors live scanner)
                        val phase1Cells = coroutineScope {
                            symbols.flatMap { sym ->
                                ScannerRanking.PHASE1_TFS.map { tf ->
                                    async { evalCell(sym, tf) }
                                }
                            }.awaitAll().filterNotNull()
                        }
                        if (phase1Cells.isEmpty()) {
                            rankingStatus = "未能得到有效因果 cell（网络、交易对或 K 线不足）。"
                            return@launch
                        }
                        val survivors = ScannerRanking.selectPhase2Survivors(
                            phase1Cells.map {
                                ScannerRanking.RankCell(it.symbol, it.timeframe, it.signal, it.confidence, it.finalScore, it.price)
                            },
                            depth = minOf(10, symbols.size),
                        )
                        // Phase 2: survivors × remaining TFs (same optimization as live scan)
                        val phase2Cells = coroutineScope {
                            survivors.flatMap { sym ->
                                ScannerRanking.PHASE2_TFS.map { tf ->
                                    async { evalCell(sym, tf) }
                                }
                            }.awaitAll().filterNotNull()
                        }
                        val cells = phase1Cells + phase2Cells
                        val cutMs = cells.maxOf { it.lastCandleOpenTimeMs } + 1
                        val report = HistoricalScannerReplay.rankAtCut(
                            HistoricalScannerReplay.ReplayInput(
                                cutTimeMs = cutMs,
                                cells = cells,
                                phase2Depth = minOf(10, symbols.size),
                                universeAtCut = symbols, // user order — not live 24h quoteVolume
                                auxiliaryDataMissing = true,
                            ),
                        )
                        rankingReport = report
                        rankingStatus = "排名回放完成：评估 ${report.symbolsEvaluated} 个交易对、${report.cellsUsed} 个 cell。" +
                            if (report.limitations.isNotEmpty()) " 存在限制，见下方说明。" else ""
                    } catch (t: Throwable) {
                        rankingStatus = "排名回放失败：${t.message ?: t::class.simpleName}"
                    } finally {
                        rankingLoading = false
                    }
                }
            },
            enabled = !rankingLoading,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text(if (rankingLoading) "排名回放中…" else "运行扫描器排名回放")
        }
        Text(rankingStatus, color = DiveColors.TextMuted)
        rankingReport?.let { report ->
            Card(colors = CardDefaults.cardColors(containerColor = DiveColors.BgCard), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Phase-2 幸存者（前 ${report.ranking.phase2Survivors.size}）", fontWeight = FontWeight.SemiBold, color = DiveColors.Text)
                    Text(report.ranking.phase2Survivors.joinToString(", ").ifEmpty { "—" }, color = DiveColors.TextMuted)
                    Text("Cross-rank（net_nss）", fontWeight = FontWeight.SemiBold, color = DiveColors.Text)
                    report.ranking.crossRank.take(12).forEachIndexed { idx, row ->
                        Text(
                            "${idx + 1}. ${row.symbol}  ${row.dominantDir.name}  net=${fmt(row.netNss)}  hits=${row.countHit}",
                            color = DiveColors.Text,
                        )
                    }
                    if (report.limitations.isNotEmpty()) {
                        Text("限制说明", fontWeight = FontWeight.SemiBold, color = DiveColors.Text)
                        report.limitations.forEach { Text("• $it", color = DiveColors.TextMuted) }
                    }
                }
            }
        }

        Text("信号来源", color = DiveColors.Text)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            TextButton(onClick = { useScannerConsensus = false }) {
                Text(if (!useScannerConsensus) "✓ SMA 交叉示例" else "SMA 交叉示例")
            }
            TextButton(onClick = { useScannerConsensus = true }) {
                Text(if (useScannerConsensus) "✓ 扫描器指标共识" else "扫描器指标共识")
            }
        }
        Text(
            if (useScannerConsensus) "共识模式：每根信号 K 线只使用截至该根收盘的数据，复用应用内指标列表与共识引擎；只有方向明确且 shouldTrade 通过的信号才开模拟仓。它不包含扫描器的跨币种排名、资金流/鲸鱼额外标注或完整多周期筛选。"
            else "SMA 模式：快慢均线交叉生成方向信号，可额外开启高周期均线确认。",
            color = DiveColors.TextMuted,
        )

        OutlinedTextField(
            value = symbol,
            onValueChange = { symbol = it.uppercase().filter { ch -> ch.isLetterOrDigit() }.take(24) },
            label = { Text("合约交易对") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
        )
        Text("K 线周期", color = DiveColors.Text)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("15m", "30m", "1h", "4h").forEach { tf ->
                TextButton(onClick = { timeframe = tf }) {
                    Text(if (timeframe == tf) "✓ $tf" else tf)
                }
            }
        }
        Text("历史 K 线数量", color = DiveColors.Text)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(100, 300, 500).forEach { n ->
                TextButton(onClick = { candleCount = n }) {
                    Text(if (candleCount == n) "✓ $n 根" else "$n 根")
                }
            }
        }
        Text("均线交叉参数（快线 / 慢线）", color = DiveColors.Text)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(5, 9, 12).forEach { n ->
                TextButton(onClick = { fastPeriod = n }) { Text(if (fastPeriod == n) "✓ 快$n" else "快$n") }
            }
            listOf(20, 21, 50).forEach { n ->
                TextButton(onClick = { slowPeriod = n }) { Text(if (slowPeriod == n) "✓ 慢$n" else "慢$n") }
            }
        }
        Text("高周期趋势确认", color = DiveColors.Text)
        TextButton(onClick = { useHigherTimeframe = !useHigherTimeframe }) {
            Text(if (useHigherTimeframe) "✓ 开启高周期确认" else "关闭高周期确认（仅单周期对照）")
        }
        Text(
            if (useScannerConsensus) "共识模式：高周期使用相同指标集合和共识引擎；方向必须一致且高周期 shouldTrade 通过。"
            else "SMA 模式：做多要求高周期快均线高于慢均线，做空要求快线低于慢线。两种模式都只使用信号 K 线收盘前已完整收盘的高周期数据。",
            color = DiveColors.TextMuted,
        )
        Text("风险计划方式", color = DiveColors.Text)
        TextButton(onClick = { useAtrRiskPlan = !useAtrRiskPlan }) {
            Text(if (useAtrRiskPlan) "✓ ATR 动态止损 + R 倍数止盈" else "固定百分比止损 / 止盈")
        }
        if (useAtrRiskPlan) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = atrPeriod, onValueChange = { atrPeriod = it.filter { ch -> ch.isDigit() }.take(2) }, label = { Text("ATR 周期") }, singleLine = true, modifier = Modifier.weight(1f))
                OutlinedTextField(value = atrMultiplier, onValueChange = { atrMultiplier = it }, label = { Text("止损 ATR 倍数") }, singleLine = true, modifier = Modifier.weight(1f))
                OutlinedTextField(value = targetR, onValueChange = { targetR = it }, label = { Text("止盈 R 倍数") }, singleLine = true, modifier = Modifier.weight(1f))
            }
            TextButton(onClick = { useStructureStop = !useStructureStop }) {
                Text(if (useStructureStop) "✓ 使用前序 K 线结构位辅助止损" else "仅使用 ATR 止损")
            }
            if (useStructureStop) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = structureLookback, onValueChange = { structureLookback = it.filter { ch -> ch.isDigit() }.take(3) }, label = { Text("结构回看根数") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = structureBufferAtr, onValueChange = { structureBufferAtr = it }, label = { Text("结构缓冲 ATR") }, singleLine = true, modifier = Modifier.weight(1f))
                }
            }
            Text("ATR 只使用信号 K 线收盘时已知的数据。结构止损只读取信号之前的 K 线：做多取回看区间最低点作为支撑参考，做空取最高点作为压力参考，再由共享风险计划计算器与 ATR 止损取更保守位置；若无有效结构位则回退 ATR。", color = DiveColors.TextMuted)
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = stopPct, onValueChange = { stopPct = it }, label = { Text("止损 %") }, singleLine = true, modifier = Modifier.weight(1f))
                OutlinedTextField(value = targetPct, onValueChange = { targetPct = it }, label = { Text("止盈 %") }, singleLine = true, modifier = Modifier.weight(1f))
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = feeSidePct, onValueChange = { feeSidePct = it }, label = { Text("单边手续费 %") }, singleLine = true, modifier = Modifier.weight(1f))
            OutlinedTextField(value = slippageSidePct, onValueChange = { slippageSidePct = it }, label = { Text("单边滑点 %") }, singleLine = true, modifier = Modifier.weight(1f))
        }
        Text("费用按进出场各计一次；默认手续费 0.05%/边、滑点 0.02%/边，仅为估算值，请按自己的实际费率修改。", color = DiveColors.TextMuted)

        Button(
            onClick = {
                val scannerConsensusMode = useScannerConsensus
                val stop = stopPct.toDoubleOrNull()
                val target = targetPct.toDoubleOrNull()
                val atrLen = atrPeriod.toIntOrNull()
                val atrMult = atrMultiplier.toDoubleOrNull()
                val rMultiple = targetR.toDoubleOrNull()
                val structureBars = structureLookback.toIntOrNull()
                val structureBuffer = structureBufferAtr.toDoubleOrNull()
                val fee = feeSidePct.toDoubleOrNull()
                val slip = slippageSidePct.toDoubleOrNull()
                when {
                    symbol.isBlank() || !symbol.endsWith("USDT") -> status = "请输入有效的 USDT 交易对，例如 BTCUSDT。"
                    (!scannerConsensusMode && fastPeriod >= slowPeriod) -> status = "快线周期必须小于慢线周期。"
                    (!useAtrRiskPlan && (stop == null || target == null || stop <= 0 || stop >= 100 || target <= 0 || target >= 100)) ||
                        (useAtrRiskPlan && (atrLen == null || atrLen < 2 || atrMult == null || !atrMult.isFinite() || atrMult <= 0 || rMultiple == null || !rMultiple.isFinite() || rMultiple <= 0 ||
                            (useStructureStop && (structureBars == null || structureBars < 2 || structureBuffer == null || !structureBuffer.isFinite() || structureBuffer < 0)))) ||
                        fee == null || slip == null || fee < 0 || slip < 0 -> status = "请检查风险参数：固定百分比需在 0–100% 之间；ATR 周期至少为 2，倍数须大于 0；手续费和滑点不能为负数。"
                    else -> {
                        // Freeze every input for this run. The form remains editable while history is loading,
                        // so asynchronous work must not mix settings from different UI states.
                        val runSymbol = symbol
                        val runTimeframe = timeframe
                        val runCandleCount = candleCount
                        val runFastPeriod = fastPeriod
                        val runSlowPeriod = slowPeriod
                        val higherTimeframeEnabled = useHigherTimeframe
                        val runUseAtrRiskPlan = useAtrRiskPlan
                        val runUseStructureStop = useStructureStop
                        val runStructureBars = structureBars ?: 20
                        val runStructureBuffer = structureBuffer ?: 0.15
                        val runAtrLen = atrLen ?: 14
                        val runAtrMult = atrMult ?: 1.5
                        val runRMultiple = rMultiple ?: 2.0
                        val runStopPct = stop ?: 1.0
                        val runTargetPct = target ?: 2.0
                        val runFee = fee!!
                        val runSlip = slip!!
                        scope.launch {
                        isLoading = true
                        result = null
                        status = "正在读取 $runSymbol $runTimeframe 历史数据…"
                        try {
                            val raw = container.repository.futuresHistory(runSymbol, runTimeframe, runCandleCount)
                            // Keep the pre-sanitized closed set for diagnostics so invalid bars and duplicate
                            // timestamps are visible instead of disappearing silently from the quality report.
                            val cutoff = nowMillis()
                            val rawClosed = raw.filter { it.closeTime < cutoff }
                            val closed = HistoricalCandleAlignment.sanitize(rawClosed)
                            if (closed.size < (if (scannerConsensusMode) 4 else runSlowPeriod + 3)) {
                                status = "有效已收盘 K 线不足（${closed.size} 根）；请增加历史数量或更换交易对。"
                            } else {
                                val dataQuality = HistoricalDataQuality.analyze(rawClosed, runTimeframe)
                                val confirmationTimeframe = higherTimeframeFor(runTimeframe)
                                val confirmationCandles = if (higherTimeframeEnabled) {
                                    HistoricalCandleAlignment.sanitize(
                                        container.repository.futuresHistory(runSymbol, confirmationTimeframe, 300),
                                    ).filter { it.closeTime < nowMillis() }
                                } else emptyList()
                                val backtestConfig = SmaCrossoverBacktest.Config(
                                        fastPeriod = runFastPeriod,
                                        slowPeriod = runSlowPeriod,
                                        stopPct = runStopPct,
                                        targetPct = runTargetPct,
                                        feeSidePct = runFee,
                                        slippageSidePct = runSlip,
                                        maxHoldingBars = 48,
                                        confirmationCandles = confirmationCandles,
                                        requireHigherTimeframeConfirmation = higherTimeframeEnabled && !scannerConsensusMode,
                                        useAtrRiskPlan = runUseAtrRiskPlan,
                                        atrPeriod = runAtrLen,
                                        atrMultiplier = runAtrMult,
                                        targetR = runRMultiple,
                                        useStructureStop = runUseAtrRiskPlan && runUseStructureStop,
                                        structureLookback = runStructureBars,
                                        structureBufferAtr = runStructureBuffer,
                                        signalProvider = if (scannerConsensusMode) { candlesThroughSignal, _ ->
                                            val indicatorResults = container.indicators.map { it.calculate(candlesThroughSignal) }
                                            val consensus = container.consensus.evaluate(indicatorResults)
                                            val direction = consensus.finalSignal.toBacktestDirection()
                                            var higherTimeframeAllows = true
                                            if (higherTimeframeEnabled) {
                                                // Strictly exclude higher-timeframe candles that close at or after
                                                // the signal candle close; this prevents look-ahead at boundaries.
                                                val signalCloseTime = candlesThroughSignal.last().closeTime
                                                val higherPrefix = HistoricalCandleAlignment.closedBefore(confirmationCandles, signalCloseTime)
                                                if (higherPrefix.isEmpty()) {
                                                    higherTimeframeAllows = false
                                                } else {
                                                    val higherResults = container.indicators.map { it.calculate(higherPrefix) }
                                                    val higherConsensus = container.consensus.evaluate(higherResults)
                                                    val higherDirection = higherConsensus.finalSignal.toBacktestDirection()
                                                    higherTimeframeAllows = higherConsensus.shouldTrade && higherDirection != null && higherDirection == direction
                                                }
                                            }
                                            com.diveintocrypto.android.domain.scanner.SmaCrossoverBacktest.HistoricalSignalDecision(
                                                direction = direction,
                                                hasDirectionalSignal = direction != null,
                                                eligible = consensus.shouldTrade && higherTimeframeAllows,
                                            )
                                        } else null,
                                )
                                val strategy = withContext(Dispatchers.Default) {
                                    SmaCrossoverBacktest.run(closed, backtestConfig)
                                }
                                result = BacktestOutput(runSymbol, runTimeframe, closed.size, runFastPeriod, runSlowPeriod, runStopPct, runTargetPct, higherTimeframeEnabled, confirmationTimeframe, strategy.signalCount, strategy.confirmedSignalCount, strategy.filteredSignalCount, strategy.summary, runUseAtrRiskPlan, runAtrLen, runAtrMult, runRMultiple, runUseAtrRiskPlan && runUseStructureStop, runStructureBars, runStructureBuffer, dataQuality.discardedCandles, dataQuality.missingIntervals, dataQuality.coveragePercent, dataQuality.largestGapBars, dataQuality.irregularIntervals, if (scannerConsensusMode) "扫描器指标共识" else "SMA${runFastPeriod}/${runSlowPeriod} 交叉")
                                status = when {
                                    strategy.summary.tradeCount == 0 -> "数据读取成功，但没有形成有效模拟交易。请检查历史数据、ATR 参数和高周期过滤设置。"
                                    dataQuality.missingIntervals > 0 || dataQuality.irregularIntervals > 0 -> "回测完成，但历史 K 线存在缺口或时间间隔异常；收益结果需谨慎解读。"
                                    else -> "回测完成。结果只反映所选样本与简化成交假设。"
                                }
                            }
                        } catch (t: Throwable) {
                            status = "回测失败：${t.message ?: t::class.simpleName ?: "未知错误"}。请检查网络、交易对和币安公开接口可用性。"
                        } finally {
                            isLoading = false
                        }
                        }
                    }
                }
            },
            enabled = !isLoading,
            modifier = Modifier.fillMaxWidth(),
        ) {
            if (isLoading) CircularProgressIndicator() else Text("运行回测")
        }
        Text(status, color = DiveColors.TextMuted)
        result?.let { output ->
            Card(colors = CardDefaults.cardColors(containerColor = DiveColors.BgCard), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("${output.symbol} · ${output.timeframe} · ${output.candleCount} 根已收盘 K 线", fontWeight = FontWeight.Bold, color = DiveColors.Text)
                    Text("历史数据覆盖率：${output.coveragePercent?.let { fmt(it) + "%" } ?: "无法计算"}；${if (output.missingIntervals == 0) "未检测到明显缺口" else "约 ${output.missingIntervals} 根 K 线缺失"}。最大单段缺口：${output.largestGapBars} 根；异常时间间隔：${output.irregularIntervals} 处；清洗剔除：${output.discardedCandles} 根（无效或重复）。不会自动补造价格。", color = DiveColors.TextMuted)
                    Text("策略：${output.strategyName}；最长持有 48 根。", color = DiveColors.TextMuted)
                    Text(if (output.useAtrRiskPlan) "风险计划：ATR(${output.atrPeriod}) × ${output.atrMultiplier} 止损，止盈 ${output.targetR}R${if (output.useStructureStop) "；结构回看 ${output.structureLookback} 根、缓冲 ATR×${output.structureBufferAtr}" else "；不使用结构位"}" else "风险计划：止损 ${output.stopPct}% / 止盈 ${output.targetPct}%", color = DiveColors.TextMuted)
                    Text(
                        if (output.useHigherTimeframe) "高周期确认：${output.confirmationTimeframe} ${if (output.strategyName.startsWith("扫描器")) "指标共识同向 + shouldTrade" else "SMA${output.fastPeriod}/${output.slowPeriod} 趋势过滤"} 已开启"
                        else "高周期确认：关闭（单周期对照）",
                        color = DiveColors.TextMuted,
                    )
                    Metric(if (output.strategyName.startsWith("扫描器")) "原始方向信号" else "原始交叉信号", output.signalCount.toString())
                    if (output.useHigherTimeframe || output.useAtrRiskPlan || output.strategyName.startsWith("扫描器")) {
                        Metric("通过过滤的信号", output.confirmedSignalCount.toString())
                        Metric("被过滤的信号", output.filteredSignalCount.toString())
                    }
                    Metric("模拟交易次数", output.summary.tradeCount.toString())
                    Metric("胜率", output.summary.winRatePct?.let { "${fmt(it)}%" } ?: "—")
                    Button(
                        onClick = {
                            val s = output.summary
                            val q = buildString {
                                append("请解读以下历史回测结果（研究参考，非投资建议，勿编造未提供的成交）。")
                                append("标的${output.symbol} 周期${output.timeframe} 样本${output.candleCount}根。")
                                append("策略：${output.strategyName}。")
                                append("交易次数${s.tradeCount} 胜率${s.winRatePct}% 净收益简单相加${s.totalNetReturnPct}%。")
                                append("请分析统计意义、过拟合风险、与实盘差异（费用/滑点/缺口/未模拟资金费率）。")
                            }
                            container.aiSessionHub.startWithQuestion(output.symbol, output.timeframe, q, "Backtest")
                        },
                        enabled = !aiSession.running,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text(if (aiSession.running && aiSession.source == "Backtest") "AI 解读中…" else "AI 解读回测结果") }
                    if (aiSession.source == "Backtest" && (aiSession.streamingText.isNotBlank() || aiSession.lastReport != null)) {
                        Text("AI 回测解读", fontWeight = FontWeight.SemiBold, color = DiveColors.Accent)
                        Text(aiSession.streamingText.ifBlank { aiSession.lastReport.orEmpty() }, color = DiveColors.Text)
                        Text(aiSession.status, color = DiveColors.TextMuted)
                    }

                    Metric("逐笔收益率简单相加（非账户复利）", "${fmt(output.summary.totalNetReturnPct)}%")
                    Metric("模拟权益复利净收益（初始权益 100）", "${fmt(output.summary.compoundedNetReturnPct)}%")
                    Metric("平均单笔净收益", output.summary.averageNetReturnPct?.let { "${fmt(it)}%" } ?: "—")
                    Metric("盈利因子", output.summary.profitFactor?.let { if (it.isInfinite()) "∞（样本内无亏损单）" else fmt(it) } ?: "—")
                    Metric("最大回撤（按逐笔复利权益）", "${fmt(output.summary.maxDrawdownPct)}%")
                    Metric("盈利 / 亏损笔数", "${output.summary.winCount} / ${output.summary.lossCount}")
                }
            }
            Text("最近交易（最多 12 笔）", fontWeight = FontWeight.Bold, color = DiveColors.Text)
            output.summary.trades.takeLast(12).asReversed().forEach { trade ->
                Card(colors = CardDefaults.cardColors(containerColor = DiveColors.BgCard), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("${if (trade.setup.direction == com.diveintocrypto.android.domain.scanner.RiskPlanCalculator.Direction.LONG) "做多" else "做空"} · ${trade.reason.label()} · 入场 ${fmt(trade.setup.entryPrice)}", fontWeight = FontWeight.SemiBold, color = DiveColors.Text)
                        Text("出场 ${trade.exitPrice?.let { fmt(it) } ?: "—"} · 毛收益 ${trade.grossReturnPct?.let { "${fmt(it)}%" } ?: "—"} · 估算成本 ${fmt(trade.estimatedCostPct)}% · 净收益 ${trade.netReturnPct?.let { "${fmt(it)}%" } ?: "—"}", color = DiveColors.TextMuted)
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("重要限制：单标的共识回放会在每根历史 K 线前缀上重算指标与共识阈值；上方「扫描器排名回放」可对多标的做 Phase1+Phase2 排名（与实盘 ScannerRanking 相同公式），但仍缺历史 24h 成交额宇宙与资金流/鲸鱼存档。结构参考为固定回看区间极值，不等同于扫描器已确认结构位。成本为路径敏感手续费+滑点（与 RiskCostCalculator 一致），不模拟资金费率、盘口冲击、部分成交、维持保证金或强平，不代表未来表现。", color = DiveColors.TextMuted)
    }
}

private data class BacktestOutput(
    val symbol: String, val timeframe: String, val candleCount: Int,
    val fastPeriod: Int, val slowPeriod: Int, val stopPct: Double, val targetPct: Double,
    val useHigherTimeframe: Boolean, val confirmationTimeframe: String,
    val signalCount: Int, val confirmedSignalCount: Int, val filteredSignalCount: Int,
    val summary: RiskPlanBacktester.Summary,
    val useAtrRiskPlan: Boolean,
    val atrPeriod: Int,
    val atrMultiplier: Double,
    val targetR: Double,
    val useStructureStop: Boolean,
    val structureLookback: Int,
    val structureBufferAtr: Double,
    val discardedCandles: Int,
    val missingIntervals: Int,
    val coveragePercent: Double?,
    val largestGapBars: Int,
    val irregularIntervals: Int,
    val strategyName: String,
)

@Composable
private fun Metric(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = DiveColors.TextMuted)
        Text(value, fontWeight = FontWeight.SemiBold, color = DiveColors.Text)
    }
}

private fun fmt(value: Double): String = if (!value.isFinite()) "—" else {
    val rounded = kotlin.math.round(value * 100.0) / 100.0
    rounded.toString()
}

private fun RiskPlanBacktester.ExitReason.label(): String = when (this) {
    RiskPlanBacktester.ExitReason.STOP_LOSS -> "止损"
    RiskPlanBacktester.ExitReason.TAKE_PROFIT -> "止盈"
    RiskPlanBacktester.ExitReason.TIME_LIMIT -> "时间退出"
    RiskPlanBacktester.ExitReason.NO_FUTURE_CANDLES -> "无后续K线"
    RiskPlanBacktester.ExitReason.INVALID_SETUP -> "无效计划"
}

private fun com.diveintocrypto.android.domain.model.Signal.toBacktestDirection(): com.diveintocrypto.android.domain.scanner.RiskPlanCalculator.Direction? = when (this) {
    com.diveintocrypto.android.domain.model.Signal.STRONG_BUY,
    com.diveintocrypto.android.domain.model.Signal.BUY -> com.diveintocrypto.android.domain.scanner.RiskPlanCalculator.Direction.LONG
    com.diveintocrypto.android.domain.model.Signal.STRONG_SELL,
    com.diveintocrypto.android.domain.model.Signal.SELL -> com.diveintocrypto.android.domain.scanner.RiskPlanCalculator.Direction.SHORT
    com.diveintocrypto.android.domain.model.Signal.NEUTRAL -> null
}

private fun higherTimeframeFor(timeframe: String): String = when (timeframe) {
    "15m" -> "1h"
    "30m" -> "4h"
    "1h" -> "4h"
    "4h" -> "1d"
    else -> "4h"
}
