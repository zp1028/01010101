package com.diveintocrypto.android.domain.scanner

import com.diveintocrypto.android.domain.model.Candle
import kotlin.math.roundToLong

/** Coverage diagnostics for time-based historical candles; never fabricates missing prices. */
object HistoricalDataQuality {
    data class Report(
        val candleCount: Int,
        val discardedCandles: Int,
        val expectedSlots: Int,
        val missingIntervals: Int,
        val largestGapBars: Int,
        val irregularIntervals: Int,
        val coveragePercent: Double?,
    )

    fun analyze(candles: List<Candle>, timeframe: String): Report {
        val ordered = HistoricalCandleAlignment.sanitize(candles)
        val discarded = (candles.size - ordered.size).coerceAtLeast(0)
        val intervalMs = intervalMillis(timeframe)
            ?: return Report(ordered.size, discarded, ordered.size, 0, 0, 0, if (ordered.isEmpty()) null else 100.0)
        if (ordered.isEmpty()) return Report(0, discarded, 0, 0, 0, 0, null)
        if (ordered.size == 1) return Report(1, discarded, 1, 0, 0, 0, 100.0)

        var missing = 0L
        var largestGap = 0
        var irregularIntervals = 0
        for (index in 1 until ordered.size) {
            val delta = ordered[index].openTime - ordered[index - 1].openTime
            if (delta <= 0L) continue
            // Round to the nearest slot so small timestamp jitter does not become a false gap.
            val ratio = delta.toDouble() / intervalMs.toDouble()
            val slots = ratio.roundToLong().coerceAtLeast(1L)
            // Open times from exchange klines should lie on timeframe boundaries.
            // Count materially off-grid deltas separately instead of silently presenting
            // a rounded slot estimate as fully trustworthy coverage.
            val alignedDelta = slots.toDouble() * intervalMs.toDouble()
            if (kotlin.math.abs(delta.toDouble() - alignedDelta) > intervalMs * 0.05) {
                irregularIntervals++
            }
            val absent = (slots - 1L).coerceAtLeast(0L)
            missing += absent
            largestGap = maxOf(largestGap, absent.coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
        }
        val expected = (ordered.size.toLong() + missing).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        val coverage = if (expected <= 0) null else (ordered.size.toDouble() / expected * 100.0).coerceIn(0.0, 100.0)
        return Report(ordered.size, discarded, expected, missing.coerceAtMost(Int.MAX_VALUE.toLong()).toInt(), largestGap, irregularIntervals, coverage)
    }

    fun intervalMillis(timeframe: String): Long? = when (timeframe) {
        "15m" -> 15L * 60L * 1000L
        "30m" -> 30L * 60L * 1000L
        "1h" -> 60L * 60L * 1000L
        "4h" -> 4L * 60L * 60L * 1000L
        else -> null
    }
}
