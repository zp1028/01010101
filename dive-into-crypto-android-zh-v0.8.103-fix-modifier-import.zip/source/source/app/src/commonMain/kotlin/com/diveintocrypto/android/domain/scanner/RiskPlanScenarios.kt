package com.diveintocrypto.android.domain.scanner

/** Comparable risk-plan profiles; they are analysis scenarios, not trade instructions. */
object RiskPlanScenarios {
    enum class Profile(val label: String, val atrMultiplier: Double, val targetR: Double) {
        CONSERVATIVE("稳健", 3.0, 1.5),
        STANDARD("标准", 2.0, 2.0),
        AGGRESSIVE("积极", 1.25, 2.5),
    }

    data class Scenario(
        val profile: Profile,
        val plan: RiskPlanCalculator.Plan?,
        val netRiskRewardRatio: Double?,
        val reason: String? = null,
    )

    fun evaluate(
        direction: RiskPlanCalculator.Direction,
        entry: Double,
        atr: Double,
        feeSidePct: Double,
        slippageSidePct: Double,
        structureStop: Double? = null,
        structureBufferAtr: Double = 0.15,
    ): List<Scenario> = Profile.values().map { profile ->
        val result = StructureAwareRiskPlan.calculate(
            StructureAwareRiskPlan.Inputs(
                direction = direction,
                entry = entry,
                atr = atr,
                atrMultiplier = profile.atrMultiplier,
                targetR = profile.targetR,
                structureStop = structureStop,
                structureBufferAtr = structureBufferAtr,
            ),
        )
        val plan = result.plan
        val cost = plan?.let {
            RiskCostCalculator.estimate(
                stopDistancePct = it.stopDistancePercent,
                targetDistancePct = it.rewardPerUnit / it.entry * 100.0,
                feeSidePct = feeSidePct,
                slippageSidePct = slippageSidePct,
                direction = direction,
            )
        }
        Scenario(profile, plan, cost?.netRiskRewardRatio, result.reason)
    }
}
