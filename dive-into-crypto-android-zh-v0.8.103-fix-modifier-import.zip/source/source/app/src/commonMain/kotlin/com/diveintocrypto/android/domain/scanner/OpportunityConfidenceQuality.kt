package com.diveintocrypto.android.domain.scanner

import kotlin.math.roundToInt

/**
 * Conservative display/alert confidence adjustment based on actual timeframe coverage.
 * This does not alter the underlying indicator votes or scanner ranking score.
 */
object OpportunityConfidenceQuality {
    data class Result(
        val adjustedConfidence: Int,
        val coveragePercent: Int,
        val conflictingTimeframes: Int,
        val observedTimeframes: Int,
    )

    /**
     * Selects the strongest confidence that actually supports the dominant direction.
     * A neutral dominant direction has no directional confidence and returns zero.
     * Each pair is (direction, confidence), where direction is -1/0/+1.
     */
    fun dominantBaseConfidence(directionConfidence: List<Pair<Int, Int>>, dominantDirection: Int): Int {
        if (dominantDirection !in listOf(-1, 1)) return 0
        return directionConfidence.asSequence()
            .filter { (direction, _) -> direction == dominantDirection }
            .maxOfOrNull { (_, confidence) -> confidence.coerceIn(0, 100) } ?: 0
    }

    /** Directions must be -1 (bearish), 0 (neutral/unknown), or +1 (bullish). */
    fun adjust(
        baseConfidence: Int,
        expectedTimeframes: Int,
        observedDirections: List<Int>,
        dominantDirection: Int,
    ): Result {
        val base = baseConfidence.coerceIn(0, 100)
        val expected = expectedTimeframes.coerceAtLeast(0)
        // Ignore malformed directions first, then cap the sample to the declared
        // timeframe budget. Coverage, conflict count, and conflict ratio must all
        // describe the same observed sample; otherwise extra entries can inflate
        // conflict penalties while the displayed coverage remains capped.
        val validDirections = observedDirections.filter { it in -1..1 }
        val sample = if (expected > 0) validDirections.take(expected) else validDirections
        val observed = sample.size
        val coverage = if (expected <= 0) 100 else ((observed * 100.0) / expected).roundToInt().coerceIn(0, 100)
        val direction = dominantDirection.takeIf { it in -1..1 } ?: 0
        val conflicts = if (direction == 0) 0 else sample.count { it != 0 && it != direction }
        val conflictRatio = if (sample.isEmpty()) 0.0 else conflicts.toDouble() / sample.size
        // Coverage can reduce confidence by at most 40%; opposite non-neutral TFs by up to 25%.
        val coverageFactor = if (expected <= 0) 1.0 else 0.60 + 0.40 * (coverage / 100.0)
        val conflictFactor = 1.0 - 0.25 * conflictRatio
        val adjusted = (base * coverageFactor * conflictFactor).roundToInt().coerceIn(0, 100)
        return Result(adjusted, coverage, conflicts, observed)
    }
}
