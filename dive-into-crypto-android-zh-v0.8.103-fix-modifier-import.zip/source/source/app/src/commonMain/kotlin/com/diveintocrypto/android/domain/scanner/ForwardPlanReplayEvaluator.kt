package com.diveintocrypto.android.domain.scanner

import com.diveintocrypto.android.domain.model.Candle

/**
 * Deterministic, no-lookahead evaluation of a frozen plan against candles that were fully
 * closed after the plan decision time. This is an evaluator, not a prediction or execution engine.
 */
object ForwardPlanReplayEvaluator {
    enum class Outcome { OPEN, TARGET_HIT, STOP_HIT, EXPIRED, NO_VALID_CANDLES }

    data class Result(
        val planId: String,
        val outcome: Outcome,
        val evaluatedThroughMs: Long,
        val candlesConsidered: Int,
        val firstOutcomeCandleCloseMs: Long? = null,
        val grossR: Double? = null,
        val notes: List<String> = emptyList(),
        /** Data-coverage quality, separate from the trading outcome. */
        val coverageStatus: String = "UNKNOWN",
    )

    fun evaluate(
        plan: ForwardEntryPlanEngine.Plan,
        candles: List<Candle>,
        asOfMs: Long,
        feeAndSlippagePctRoundTrip: Double = 0.14,
        expectedIntervalMs: Long? = null,
    ): Result {
        if (asOfMs < plan.generatedAtMs || !feeAndSlippagePctRoundTrip.isFinite() || feeAndSlippagePctRoundTrip < 0.0) {
            return Result(plan.id, Outcome.NO_VALID_CANDLES, asOfMs, 0, notes = listOf("评估时间或成本参数无效"), coverageStatus = "INVALID_INPUT")
        }
        // Only bars whose close timestamp is after the frozen decision and no later than asOf
        // can be considered. Sorting and deduping make replay deterministic under shuffled input.
        val eligible = candles.asSequence()
            // A candle may have opened before the decision but is still valid evidence if it
            // closed after the decision. Never use its high/low until that close timestamp.
            .filter { it.closeTime > plan.generatedAtMs && it.closeTime <= asOfMs }
            .filter { c -> c.open.isFinite() && c.high.isFinite() && c.low.isFinite() && c.close.isFinite() &&
                c.open > 0.0 && c.high >= c.low && c.high > 0.0 && c.low > 0.0 && c.close > 0.0 }
            .distinctBy { it.closeTime }
            .sortedBy { it.closeTime }
            .toList()
        if (eligible.isEmpty()) {
            // Expiration by wall clock is not enough to settle a replay: the history feed
            // must contain a closed candle covering the expiry boundary, otherwise coverage
            // may simply be missing (API gap, delisting, or paging failure).
            return Result(plan.id, Outcome.NO_VALID_CANDLES, asOfMs, 0,
                notes = listOf("未发现决策时点之后、评估截止时点之前已收盘的有效K线；历史覆盖不足，不结算"), coverageStatus = "NO_DATA")
        }
        val intervalMs = expectedIntervalMs?.takeIf { it > 0L }
        val direction = plan.direction
        val risk = kotlin.math.abs(plan.referencePrice - plan.stopLoss)
        if (!risk.isFinite() || risk <= 0.0) {
            return Result(plan.id, Outcome.NO_VALID_CANDLES, asOfMs, eligible.size, notes = listOf("计划风险距离无效"), coverageStatus = "INVALID_INPUT")
        }
        val costR = (plan.referencePrice * feeAndSlippagePctRoundTrip / 100.0) / risk
        var previousCloseMs: Long? = null
        for (candle in eligible) {
            if (candle.closeTime > plan.expiresAtMs) break
            if (intervalMs != null) {
                val previous = previousCloseMs
                val gapTooLarge = if (previous == null) {
                    candle.closeTime - plan.generatedAtMs > intervalMs * 2L
                } else {
                    candle.closeTime - previous > intervalMs * 3L / 2L
                }
                if (gapTooLarge) {
                    return Result(
                        plan.id, Outcome.OPEN, previous ?: plan.generatedAtMs,
                        eligible.count { it.closeTime <= (previous ?: plan.generatedAtMs) },
                        notes = listOf("历史K线存在时间缺口，无法证明缺口期间未触及止损/止盈；保持未决，不计入统计"),
                        coverageStatus = "GAP",
                    )
                }
            }
            val stopTouched = if (direction == ForwardEntryPlanEngine.Direction.LONG) candle.low <= plan.stopLoss else candle.high >= plan.stopLoss
            val targetTouched = if (direction == ForwardEntryPlanEngine.Direction.LONG) candle.high >= plan.takeProfit else candle.low <= plan.takeProfit
            // Conservative OHLC ambiguity rule: if both levels occur in one candle, assume stop first.
            if (stopTouched) {
                return Result(plan.id, Outcome.STOP_HIT, candle.closeTime, eligible.count { it.closeTime <= candle.closeTime }, candle.closeTime, -1.0 - costR,
                    listOf(if (targetTouched) "同一根K线同时覆盖止损和止盈，按保守规则记为止损先触发" else "止损触及；未模拟成交价保证"), coverageStatus = "SUFFICIENT_FOR_OUTCOME")
            }
            if (targetTouched) {
                val gross = kotlin.math.abs(plan.takeProfit - plan.referencePrice) / risk
                return Result(plan.id, Outcome.TARGET_HIT, candle.closeTime, eligible.count { it.closeTime <= candle.closeTime }, candle.closeTime, gross - costR,
                    listOf("止盈触及；净R为基于往返手续费/滑点的估算值"), coverageStatus = "SUFFICIENT_FOR_OUTCOME")
            }
            previousCloseMs = candle.closeTime
        }
        val lastEligibleClose = eligible.lastOrNull { it.closeTime <= plan.expiresAtMs }?.closeTime ?: plan.generatedAtMs
        // The expiry boundary may fall between candle closes. Require the first closed candle
        // at or after expiry as coverage evidence; do not require a candle close to equal an
        // arbitrary millisecond expiry timestamp, and do not use that post-expiry candle's OHLC
        // to trigger a stop/target outcome.
        val boundaryCandle = eligible.firstOrNull { it.closeTime >= plan.expiresAtMs }
        val barsThroughBoundary = boundaryCandle?.let { boundary -> eligible.filter { it.closeTime <= boundary.closeTime } }.orEmpty()
        val coverageThroughExpiry = asOfMs >= plan.expiresAtMs && boundaryCandle != null &&
            (intervalMs == null || barsThroughBoundary.zipWithNext().all { (a, b) -> b.closeTime - a.closeTime <= intervalMs * 3L / 2L })
        val outcome = if (coverageThroughExpiry) Outcome.EXPIRED else Outcome.OPEN
        val coverageNote = if (asOfMs >= plan.expiresAtMs && !coverageThroughExpiry) {
            "计划已到期，但历史K线未连续覆盖到期边界；回放保持未决，不计入胜率"
        } else {
            "仅使用已收盘历史K线；未发生止损/止盈则保持未决"
        }
        return Result(plan.id, outcome, lastEligibleClose.coerceAtMost(asOfMs), eligible.count { it.closeTime <= lastEligibleClose },
            notes = listOf(coverageNote, "OHLC回放无法还原盘口、成交滑点或同一根K线内的真实路径"),
            coverageStatus = if (coverageThroughExpiry) "COMPLETE_THROUGH_EXPIRY" else if (asOfMs >= plan.expiresAtMs) "PARTIAL" else "IN_PROGRESS")
    }
}
