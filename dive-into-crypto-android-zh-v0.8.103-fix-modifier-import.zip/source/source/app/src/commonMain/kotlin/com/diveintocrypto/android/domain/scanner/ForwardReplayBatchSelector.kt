package com.diveintocrypto.android.domain.scanner

/** Fair bounded scheduler for replay work; oldest/never-evaluated plans are considered first. */
object ForwardReplayBatchSelector {
    private val terminalOutcomes = setOf(
        ForwardPlanReplayEvaluator.Outcome.TARGET_HIT.name,
        ForwardPlanReplayEvaluator.Outcome.STOP_HIT.name,
        ForwardPlanReplayEvaluator.Outcome.EXPIRED.name,
    )

    fun select(
        plans: List<TrackedForwardPlan>,
        replayRecords: List<ForwardPlanReplayRecord>,
        limit: Int = 12,
    ): List<TrackedForwardPlan> {
        if (limit <= 0) return emptyList()
        val latestByPlan = replayRecords.groupBy { it.planId }
            .mapValues { (_, records) -> records.maxByOrNull { it.savedAtMs } }
        val terminalPlanIds = replayRecords.asSequence()
            .filter { it.outcome in terminalOutcomes }
            .map { it.planId }
            .toSet()
        return plans.asSequence()
            .filter { !it.archived && it.status in ForwardPlanJournal.VISIBLE_STATUSES }
            .filter { it.snapshot.id !in terminalPlanIds }
            .sortedWith(compareBy<TrackedForwardPlan> {
                latestByPlan[it.snapshot.id]?.savedAtMs ?: Long.MIN_VALUE
            }.thenBy { it.snapshot.generatedAtMs })
            .take(limit)
            .toList()
    }
}
