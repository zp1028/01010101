package com.diveintocrypto.android.domain.chart

import com.diveintocrypto.android.domain.model.Candle
import kotlin.math.abs

/** Lightweight, independently implemented SMC-style chart overlays. */
data class EqualLiquidityLevel(val price: Double, val isHigh: Boolean, val touches: Int)
data class PremiumDiscountRange(val low: Double, val high: Double) {
    val equilibrium: Double get() = (low + high) / 2.0
}

object SmcOverlayAnalysis {
    private data class Pivot(val index: Int, val price: Double, val isHigh: Boolean)

    /** Confirmed pivots only: a pivot is not available until [leftRight] bars have closed to its right. */
    private fun pivots(candles: List<Candle>, leftRight: Int): List<Pivot> {
        if (leftRight < 1 || candles.size < leftRight * 2 + 1) return emptyList()
        val result = mutableListOf<Pivot>()
        for (i in leftRight until candles.size - leftRight) {
            val high = candles[i].high
            val low = candles[i].low
            var isHigh = high.isFinite()
            var isLow = low.isFinite()
            for (offset in 1..leftRight) {
                if (candles[i - offset].high >= high || candles[i + offset].high >= high) isHigh = false
                if (candles[i - offset].low <= low || candles[i + offset].low <= low) isLow = false
            }
            if (isHigh) result += Pivot(i, high, true)
            if (isLow) result += Pivot(i, low, false)
        }
        return result.takeLast(24)
    }

    /**
     * Candidate EQH/EQL liquidity pools. Swing prices within 0.15% are clustered;
     * this is a chart heuristic, not a claim that resting orders are observable.
     */
    fun equalLiquidityLevels(candles: List<Candle>, leftRight: Int = 3, tolerancePct: Double = 0.15): List<EqualLiquidityLevel> {
        if (tolerancePct <= 0.0 || !tolerancePct.isFinite()) return emptyList()
        val all = pivots(candles, leftRight)
        val result = mutableListOf<EqualLiquidityLevel>()
        for (isHigh in listOf(true, false)) {
            val points = all.filter { it.isHigh == isHigh }
            val consumed = mutableSetOf<Int>()
            for (i in points.indices) {
                if (i in consumed) continue
                val anchor = points[i].price
                if (!anchor.isFinite() || anchor <= 0.0) continue
                val tolerance = anchor * tolerancePct / 100.0
                val cluster = points.indices.filter { j -> j !in consumed && abs(points[j].price - anchor) <= tolerance }
                if (cluster.size >= 2) {
                    result += EqualLiquidityLevel(cluster.map { points[it].price }.average(), isHigh, cluster.size)
                    consumed.addAll(cluster)
                }
            }
        }
        return result.takeLast(6)
    }

    /** Recent confirmed swing high/low range for premium/discount visualization. */
    fun premiumDiscountRange(candles: List<Candle>, leftRight: Int = 3): PremiumDiscountRange? {
        val all = pivots(candles, leftRight)
        val high = all.filter { it.isHigh }.maxByOrNull { it.index } ?: return null
        val low = all.filter { !it.isHigh }.maxByOrNull { it.index } ?: return null
        if (!high.price.isFinite() || !low.price.isFinite() || high.price <= low.price) return null
        return PremiumDiscountRange(low.price, high.price)
    }
}
