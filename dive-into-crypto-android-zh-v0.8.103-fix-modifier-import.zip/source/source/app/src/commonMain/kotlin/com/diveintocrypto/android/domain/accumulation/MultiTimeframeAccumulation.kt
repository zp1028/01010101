package com.diveintocrypto.android.domain.accumulation

/**
 * Conservative aggregation of already-computed timeframe assessments.
 * The output is an evidence-consistency summary, not a probability or trade signal.
 */
object MultiTimeframeAccumulation {
    data class TimeframeResult(val timeframe: String, val result: AccumulationDistributionAssessment.Result)

    enum class Alignment { BULLISH_SIGNS_ALIGNED, BEARISH_SIGNS_ALIGNED, CONFLICTING, INSUFFICIENT_DATA }

    data class Summary(
        val alignment: Alignment,
        val usableTimeframes: Int,
        val accumulationTimeframes: Int,
        val distributionTimeframes: Int,
        val mixedTimeframes: Int,
        val averageEvidenceScore: Int?,
        val explanation: String,
    )

    private val priority = listOf("1d", "4h", "1h", "30m", "15m", "5m", "3m", "1m")

    fun summarize(items: List<TimeframeResult>, minimumUsable: Int = 2): Summary {
        val usable = items.filter { it.result.label != AccumulationDistributionAssessment.Label.INSUFFICIENT_DATA }
        if (minimumUsable < 1 || usable.size < minimumUsable) {
            return Summary(Alignment.INSUFFICIENT_DATA, usable.size, 0, 0, 0, null,
                "有效周期不足（${usable.size}/$minimumUsable）；不要据此判断吸筹或派发")
        }
        val accumulation = usable.count { it.result.label == AccumulationDistributionAssessment.Label.ACCUMULATION_SIGNS }
        val distribution = usable.count { it.result.label == AccumulationDistributionAssessment.Label.DISTRIBUTION_SIGNS }
        val mixed = usable.size - accumulation - distribution
        val alignment = when {
            accumulation >= minimumUsable && distribution == 0 && mixed == 0 -> Alignment.BULLISH_SIGNS_ALIGNED
            distribution >= minimumUsable && accumulation == 0 && mixed == 0 -> Alignment.BEARISH_SIGNS_ALIGNED
            else -> Alignment.CONFLICTING
        }
        val score = usable.map { it.result.evidenceScore }.average().toInt().coerceIn(0, 100)
        val explanation = when (alignment) {
            Alignment.BULLISH_SIGNS_ALIGNED -> "多个周期均出现吸筹迹象；仍需价格企稳/突破确认，不代表上涨概率"
            Alignment.BEARISH_SIGNS_ALIGNED -> "多个周期均出现派发迹象；仍需支撑破位确认，不代表下跌概率"
            Alignment.CONFLICTING -> "周期证据不一致或包含混合信号；降低判断等级，等待价格结构确认"
            Alignment.INSUFFICIENT_DATA -> "有效周期不足；不作方向判断"
        }
        return Summary(alignment, usable.size, accumulation, distribution, mixed, score, explanation)
    }

    /** Stable display order: high timeframe first, unknown periods last. */
    fun ordered(items: List<TimeframeResult>): List<TimeframeResult> = items.sortedWith(
        compareBy<TimeframeResult> { priority.indexOf(it.timeframe).let { index -> if (index < 0) Int.MAX_VALUE else index } }
            .thenBy { it.timeframe }
    )
}
