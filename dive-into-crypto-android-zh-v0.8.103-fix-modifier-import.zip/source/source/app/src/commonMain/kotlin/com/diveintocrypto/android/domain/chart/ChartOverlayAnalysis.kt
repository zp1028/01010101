package com.diveintocrypto.android.domain.chart

import com.diveintocrypto.android.domain.math.Series
import com.diveintocrypto.android.domain.model.Candle

/**
 * Independent chart overlay calculations. No TradingView/LuxAlgo source is copied.
 * AVL here means the per-candle average price line (H + L + C) / 3; it is not VWAP.
 */
object ChartOverlayAnalysis {
    data class MacdSmaSignal(val index: Int, val bullish: Boolean, val triggerPrice: Double)
    data class MacdPack(val macd: List<Double?>, val signal: List<Double?>, val histogram: List<Double?>)

    fun avl(candles: List<Candle>): List<Double?> = candles.map { candle ->
        if (candle.high.isFinite() && candle.low.isFinite() && candle.close.isFinite())
            (candle.high + candle.low + candle.close) / 3.0
        else null
    }

    /** ChartArt reference formula: SMA(close,12)-SMA(close,26), then SMA(MACD,9). */
    fun macdSma(closes: List<Double>, fast: Int = 12, slow: Int = 26, signalPeriod: Int = 9): MacdPack {
        if (closes.isEmpty() || fast < 1 || slow < 1 || signalPeriod < 1) {
            return MacdPack(emptyList(), emptyList(), emptyList())
        }
        val fastSma = Series.rollingMean(closes, fast)
        val slowSma = Series.rollingMean(closes, slow)
        val macd = closes.indices.map { i ->
            val f = fastSma.getOrNull(i)
            val s = slowSma.getOrNull(i)
            if (f != null && s != null) f - s else null
        }
        val filled = macd.map { it ?: 0.0 }
        val rawSignal = Series.rollingMean(filled, signalPeriod)
        val warmup = slow + signalPeriod - 2
        val signal = macd.indices.map { i -> if (i >= warmup && macd[i] != null) rawSignal[i] else null }
        val hist = macd.indices.map { i ->
            val m = macd[i]; val s = signal[i]
            if (m != null && s != null) m - s else null
        }
        return MacdPack(macd, signal, hist)
    }

    /**
     * Confirmed-close signals based on the supplied reference strategy.
     * SMA200 is a hard warm-up requirement; no signal is emitted before it exists.
     * The historical close filter follows the source's close[slowLength] semantics.
     */
    fun macdSma200Signals(candles: List<Candle>): List<MacdSmaSignal> {
        if (candles.size < 200 + 26 + 9) return emptyList()
        val closes = candles.map { it.close }
        val fast = Series.rollingMean(closes, 12)
        val slow = Series.rollingMean(closes, 26)
        val sma200 = Series.rollingMean(closes, 200)
        val pack = macdSma(closes)
        val out = mutableListOf<MacdSmaSignal>()
        for (i in 1 until candles.size) {
            val h0 = pack.histogram.getOrNull(i - 1) ?: continue
            val h1 = pack.histogram.getOrNull(i) ?: continue
            val m = pack.macd.getOrNull(i) ?: continue
            val f = fast.getOrNull(i) ?: continue
            val s = slow.getOrNull(i) ?: continue
            val longTrend = sma200.getOrNull(i) ?: continue
            val historicalClose = closes.getOrNull(i - 26) ?: continue
            val shortTrend = s < longTrend
            val long = h0 <= 0.0 && h1 > 0.0 && m > 0.0 && f > s && historicalClose > longTrend && !shortTrend
            val short = h0 >= 0.0 && h1 < 0.0 && m < 0.0 && f < s && historicalClose < longTrend && s > longTrend
            if (long) out += MacdSmaSignal(i, true, candles[i].low)
            if (short) out += MacdSmaSignal(i, false, candles[i].high)
        }
        return out
    }
}
