package com.diveintocrypto.android.domain.scanner

import kotlin.math.max

/**
 * Deterministic OHLC backtest for already-defined historical setups.
 * A setup is assumed to become available at the close of entryIndex; simulation starts
 * on the next candle to avoid looking into the entry candle's future. If stop and target
 * are both touched in one candle, stop is chosen first (conservative OHLC assumption).
 * Cost model: round-trip fee+slippage is path-aware and matches [RiskCostCalculator]
 * (entry side + exit side scaled by exit/entry notional). Funding, maintenance margin,
 * liquidation, and tiered exchange fees are intentionally not simulated.
 * This is research-only and is not a prediction or exchange fill simulator.
 */
object RiskPlanBacktester {
    data class Candle(val openTimeMs: Long, val high: Double, val low: Double, val close: Double, val open: Double? = null)
    data class Setup(
        val entryIndex: Int,
        val direction: RiskPlanCalculator.Direction,
        val entryPrice: Double,
        val stopLoss: Double,
        val takeProfit: Double,
    )
    enum class ExitReason { STOP_LOSS, TAKE_PROFIT, TIME_LIMIT, NO_FUTURE_CANDLES, INVALID_SETUP }
    data class TradeResult(
        val setup: Setup,
        val exitIndex: Int?,
        val exitPrice: Double?,
        val reason: ExitReason,
        val grossReturnPct: Double?,
        val estimatedCostPct: Double,
        val netReturnPct: Double?,
    )
    data class Summary(
        val tradeCount: Int,
        val closedTradeCount: Int,
        val winCount: Int,
        val lossCount: Int,
        val winRatePct: Double?,
        /** Arithmetic sum of individual trade returns; useful for attribution, not account growth. */
        val totalNetReturnPct: Double,
        /** Compounded return of a normalized 100-unit equity curve using sequential trade returns. */
        val compoundedNetReturnPct: Double,
        val averageNetReturnPct: Double?,
        val profitFactor: Double?,
        val maxDrawdownPct: Double,
        val trades: List<TradeResult>,
    )

    fun simulate(
        candles: List<Candle>,
        setup: Setup,
        feeSidePct: Double,
        slippageSidePct: Double,
        maxHoldingBars: Int = 48,
    ): TradeResult {
        val invalid = !setup.entryPrice.isFinite() || setup.entryPrice <= 0.0 ||
            !setup.stopLoss.isFinite() || setup.stopLoss <= 0.0 ||
            !setup.takeProfit.isFinite() || setup.takeProfit <= 0.0 ||
            setup.stopLoss == setup.entryPrice || setup.takeProfit == setup.entryPrice ||
            !feeSidePct.isFinite() || feeSidePct < 0.0 ||
            !slippageSidePct.isFinite() || slippageSidePct < 0.0 || maxHoldingBars < 1 ||
            setup.entryIndex < 0 || setup.entryIndex >= candles.size ||
            (setup.entryIndex >= 0 && setup.entryIndex < candles.size && !isUsableCandle(candles[setup.entryIndex])) ||
            (setup.direction == RiskPlanCalculator.Direction.LONG && !(setup.stopLoss < setup.entryPrice && setup.takeProfit > setup.entryPrice)) ||
            (setup.direction == RiskPlanCalculator.Direction.SHORT && !(setup.stopLoss > setup.entryPrice && setup.takeProfit < setup.entryPrice))
        if (invalid) return result(setup, null, null, ExitReason.INVALID_SETUP, feeSidePct, slippageSidePct)

        val endExclusive = minOf(candles.size, setup.entryIndex + 1 + maxHoldingBars)
        if (setup.entryIndex + 1 >= endExclusive) {
            return result(setup, null, null, ExitReason.NO_FUTURE_CANDLES, feeSidePct, slippageSidePct)
        }
        for (index in (setup.entryIndex + 1) until endExclusive) {
            val candle = candles[index]
            if (!isUsableCandle(candle)) continue
            // The open is the first observable price of a bar. If it gaps beyond a
            // stop/target, resolve that event before applying the conservative
            // stop-first assumption to ambiguous intrabar high/low touches.
            val open = candle.open?.takeIf { it.isFinite() && it > 0.0 }
            when (setup.direction) {
                RiskPlanCalculator.Direction.LONG -> {
                    if (open != null && open <= setup.stopLoss) {
                        return result(setup, index, open, ExitReason.STOP_LOSS, feeSidePct, slippageSidePct)
                    }
                    if (open != null && open >= setup.takeProfit) {
                        return result(setup, index, setup.takeProfit, ExitReason.TAKE_PROFIT, feeSidePct, slippageSidePct)
                    }
                }
                RiskPlanCalculator.Direction.SHORT -> {
                    if (open != null && open >= setup.stopLoss) {
                        return result(setup, index, open, ExitReason.STOP_LOSS, feeSidePct, slippageSidePct)
                    }
                    if (open != null && open <= setup.takeProfit) {
                        return result(setup, index, setup.takeProfit, ExitReason.TAKE_PROFIT, feeSidePct, slippageSidePct)
                    }
                }
            }
            val stopHit: Boolean
            val targetHit: Boolean
            when (setup.direction) {
                RiskPlanCalculator.Direction.LONG -> {
                    stopHit = candle.low <= setup.stopLoss
                    targetHit = candle.high >= setup.takeProfit
                }
                RiskPlanCalculator.Direction.SHORT -> {
                    stopHit = candle.high >= setup.stopLoss
                    targetHit = candle.low <= setup.takeProfit
                }
            }
            if (stopHit) {
                // A stop-market order can slip through its trigger on a gap. Use the open
                // when it is worse than the stop, rather than granting an impossible fill.
                val stopFill = when (setup.direction) {
                    RiskPlanCalculator.Direction.LONG -> if (open != null && open < setup.stopLoss) open else setup.stopLoss
                    RiskPlanCalculator.Direction.SHORT -> if (open != null && open > setup.stopLoss) open else setup.stopLoss
                }
                return result(setup, index, stopFill, ExitReason.STOP_LOSS, feeSidePct, slippageSidePct)
            }
            if (targetHit) return result(setup, index, setup.takeProfit, ExitReason.TAKE_PROFIT, feeSidePct, slippageSidePct)
        }
        // Never use a malformed trailing candle as a time-limit fill. If the end of the
        // window is missing/corrupt, use the latest valid close actually observed in-window.
        val lastValidIndex = (setup.entryIndex + 1 until endExclusive)
            .lastOrNull { isUsableCandle(candles[it]) }
        val lastClose = lastValidIndex?.let { candles[it].close }
        return if (lastValidIndex != null && lastClose != null) {
            result(setup, lastValidIndex, lastClose, ExitReason.TIME_LIMIT, feeSidePct, slippageSidePct)
        } else result(setup, null, null, ExitReason.NO_FUTURE_CANDLES, feeSidePct, slippageSidePct)
    }

    private fun isUsableCandle(candle: Candle): Boolean {
        if (!candle.high.isFinite() || !candle.low.isFinite() || !candle.close.isFinite() ||
            candle.high <= 0.0 || candle.low <= 0.0 || candle.close <= 0.0 || candle.high < candle.low) return false
        val open = candle.open
        if (open != null && (!open.isFinite() || open <= 0.0 || candle.high < maxOf(open, candle.close) || candle.low > minOf(open, candle.close))) return false
        return candle.high >= candle.close && candle.low <= candle.close
    }

    fun summarize(trades: List<TradeResult>): Summary {
        val closed = trades.filter { it.netReturnPct != null && it.netReturnPct.isFinite() }
        val returns = closed.map { it.netReturnPct!! }
        val wins = returns.count { it > 0.0 }
        val losses = returns.count { it < 0.0 }
        val grossWins = returns.filter { it > 0.0 }.sum()
        val grossLosses = -returns.filter { it < 0.0 }.sum()
        var equity = 100.0
        var peak = equity
        var maxDrawdown = 0.0
        for (tradeReturn in returns) {
            equity *= (1.0 + tradeReturn / 100.0).coerceAtLeast(0.0)
            peak = max(peak, equity)
            if (peak > 0.0) maxDrawdown = max(maxDrawdown, (peak - equity) / peak * 100.0)
        }
        return Summary(
            tradeCount = trades.size,
            closedTradeCount = closed.size,
            winCount = wins,
            lossCount = losses,
            winRatePct = if (closed.isEmpty()) null else wins.toDouble() / closed.size * 100.0,
            totalNetReturnPct = returns.sum(),
            compoundedNetReturnPct = equity - 100.0,
            averageNetReturnPct = if (returns.isEmpty()) null else returns.average(),
            profitFactor = if (grossLosses > 0.0) grossWins / grossLosses else if (grossWins > 0.0) Double.POSITIVE_INFINITY else null,
            maxDrawdownPct = maxDrawdown,
            trades = trades.toList(),
        )
    }

    private fun result(
        setup: Setup,
        exitIndex: Int?,
        exitPrice: Double?,
        reason: ExitReason,
        feeSidePct: Double,
        slippageSidePct: Double,
    ): TradeResult {
        val gross = if (exitPrice != null && setup.entryPrice.isFinite() && setup.entryPrice > 0.0 && exitPrice.isFinite() && exitPrice > 0.0) {
            when (setup.direction) {
                RiskPlanCalculator.Direction.LONG -> (exitPrice - setup.entryPrice) / setup.entryPrice * 100.0
                RiskPlanCalculator.Direction.SHORT -> (setup.entryPrice - exitPrice) / setup.entryPrice * 100.0
            }
        } else null
        val cost = estimatedRoundTripCostPct(setup.entryPrice, exitPrice, feeSidePct, slippageSidePct)
        return TradeResult(setup, exitIndex, exitPrice, reason, gross, cost, gross?.minus(cost))
    }

    /**
     * Path-aware round-trip cost aligned with [RiskCostCalculator]:
     * entry side cost on entry notional + exit side cost scaled by exit/entry price.
     * When exit is unknown, falls back to 2 × (fee + slip) on entry notional.
     * Does not include funding, liquidation, or tiered fees.
     */
    internal fun estimatedRoundTripCostPct(
        entryPrice: Double,
        exitPrice: Double?,
        feeSidePct: Double,
        slippageSidePct: Double,
    ): Double {
        if (!feeSidePct.isFinite() || feeSidePct < 0.0 || !slippageSidePct.isFinite() || slippageSidePct < 0.0) return 0.0
        val side = feeSidePct + slippageSidePct
        if (exitPrice != null && exitPrice.isFinite() && exitPrice > 0.0 && entryPrice.isFinite() && entryPrice > 0.0) {
            val exitNotionalFactor = exitPrice / entryPrice
            return side + side * exitNotionalFactor
        }
        return 2.0 * side
    }
}
