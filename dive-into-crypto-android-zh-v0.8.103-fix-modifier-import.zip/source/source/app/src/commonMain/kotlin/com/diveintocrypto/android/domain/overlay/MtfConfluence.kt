package com.diveintocrypto.android.domain.overlay

import kotlin.math.abs

/**
 * Multi-Timeframe Confluence — additive analysis overlay.
 *
 * Duplicate timeframe entries are collapsed (last supplied verdict wins), invalid
 * confidence inputs are ignored, and the higher-timeframe gate stays closed unless
 * at least two distinct higher timeframes have valid directional verdicts. This
 * avoids treating a partial scan as strong multi-timeframe confirmation.
 */
object MtfConfluence {

    data class TfVerdict(val tf: String, val signal: String, val confidence: Int)

    data class Result(
        val score: Double,
        val direction: Int,
        val gate: Boolean,
        val htfAgree: Double,
        val label: String,
        val validTimeframes: Int = 0,
        val validHigherTimeframes: Int = 0,
        val hasConflict: Boolean = false,
    )

    private val TF_WEIGHT = mapOf(
        "1m" to 1, "3m" to 1, "5m" to 2, "15m" to 3, "30m" to 4, "1h" to 6,
        "2h" to 7, "4h" to 9, "6h" to 10, "8h" to 11, "12h" to 12, "1d" to 14,
    )
    private val HTF = setOf("1h", "2h", "4h", "6h", "8h", "12h", "1d")

    private fun normalizedTf(tf: String): String = tf.trim().lowercase()

    private fun dir(sig: String): Int = when {
        sig.contains("BUY", ignoreCase = true) -> 1
        sig.contains("SELL", ignoreCase = true) -> -1
        else -> 0
    }

    fun confluence(multiTf: List<TfVerdict>, minGate: Double = 0.6): Result {
        if (multiTf.isEmpty()) return Result(0.0, 0, false, 0.0, "NEUTRAL")

        // A repeated TF should not gain extra weight simply because it was emitted twice.
        val unique = linkedMapOf<String, TfVerdict>()
        for (item in multiTf) {
            val tf = normalizedTf(item.tf)
            if (tf.isBlank() || item.confidence !in 0..100) continue
            unique[tf] = item.copy(tf = tf)
        }

        var wsum = 0.0
        var acc = 0.0
        val htfDirs = ArrayList<Int>()
        var anyBull = false
        var anyBear = false
        for (m in unique.values) {
            val d = dir(m.signal)
            val w = (TF_WEIGHT[m.tf] ?: 1).toDouble()
            acc += d * w * (0.5 + 0.5 * m.confidence / 100.0)
            wsum += w
            if (m.tf in HTF && d != 0) htfDirs += d
            if (d > 0) anyBull = true
            if (d < 0) anyBear = true
        }
        if (wsum == 0.0) return Result(0.0, 0, false, 0.0, "NEUTRAL", unique.size, htfDirs.size, anyBull && anyBear)

        val score = kotlin.math.round(acc / wsum * 1000.0) / 10.0
        val dom = if (score > 0) 1 else if (score < 0) -1 else 0
        val nonzero = htfDirs
        val htfAgree = if (nonzero.isEmpty() || dom == 0) 0.0
            else nonzero.count { it == dom }.toDouble() / nonzero.size
        val thresholdValid = minGate.isFinite() && minGate in 0.0..1.0
        val gate = thresholdValid && nonzero.size >= 2 && htfAgree >= minGate && dom != 0
        val mag = abs(score)
        val label = if (mag >= 55) "STRONG" else if (mag >= 20) "WEAK" else "NEUTRAL"
        return Result(
            score = score,
            direction = dom,
            gate = gate,
            htfAgree = kotlin.math.round(htfAgree * 100.0) / 100.0,
            label = label,
            validTimeframes = unique.size,
            validHigherTimeframes = nonzero.size,
            hasConflict = anyBull && anyBear,
        )
    }
}
