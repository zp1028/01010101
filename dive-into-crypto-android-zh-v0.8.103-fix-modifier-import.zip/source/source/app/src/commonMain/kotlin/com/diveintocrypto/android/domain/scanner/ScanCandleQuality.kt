package com.diveintocrypto.android.domain.scanner

import com.diveintocrypto.android.domain.model.Candle

/** Guards the scanner against malformed or stale OHLCV responses before indicators run. */
object ScanCandleQuality {
    data class Result(val valid: Boolean, val reason: String? = null)

    fun validate(candles: List<Candle>, timeframeMs: Long, nowMs: Long): Result {
        if (timeframeMs <= 0L) return Result(false, "invalid_timeframe")
        if (candles.size < 50) return Result(false, "insufficient_history")
        var previousOpen = Long.MIN_VALUE
        for (candle in candles) {
            if (candle.openTime <= previousOpen) return Result(false, "unordered_or_duplicate_timestamps")
            previousOpen = candle.openTime
            if (candle.openTime < 0L || candle.closeTime < candle.openTime) return Result(false, "invalid_timestamp")
            val values = listOf(candle.open, candle.high, candle.low, candle.close, candle.volume)
            if (values.any { !it.isFinite() }) return Result(false, "non_finite_ohlcv")
            if (candle.open <= 0.0 || candle.high <= 0.0 || candle.low <= 0.0 || candle.close <= 0.0 || candle.volume < 0.0) {
                return Result(false, "invalid_ohlcv_range")
            }
            if (candle.high < maxOf(candle.open, candle.close, candle.low) ||
                candle.low > minOf(candle.open, candle.close, candle.high)) {
                return Result(false, "inconsistent_ohlc")
            }
        }
        val age = nowMs - candles.last().openTime
        // The latest candle may still be forming; allow up to two full intervals plus 30s.
        if (age < -timeframeMs || age > timeframeMs * 2L + 30_000L) return Result(false, "stale_latest_candle")
        return Result(true)
    }
}
