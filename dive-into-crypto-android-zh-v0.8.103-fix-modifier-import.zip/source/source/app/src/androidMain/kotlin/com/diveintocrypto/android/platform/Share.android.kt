package com.diveintocrypto.android.platform

import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import com.diveintocrypto.android.share.ShareVerdictRow
import com.diveintocrypto.android.share.shareVerdict
import kotlinx.coroutines.launch

/**
 * Android actual: converts the common payload into a [ShareVerdictRow] and
 * fires the system share sheet. The render + PNG write run ASYNC on
 * Dispatchers.IO (inside [shareVerdict]) so the UI lane never blocks on disk
 * I/O; the returned lambda launches that job on the composition's scope and
 * returns immediately.
 *
 * true = the async share job was dispatched (legacy callers keep compiling;
 * the synchronous render success signal no longer exists). Failures inside the
 * job are swallowed by [shareVerdict]'s honest null envelope and never crash
 * the UI.
 */
@Composable
actual fun rememberShareVerdict(): (ShareVerdictPayload) -> Boolean {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    return { payload ->
        scope.launch {
            shareVerdict(
                context,
                ShareVerdictRow(
                    symbol = payload.symbol,
                    verdict = payload.verdict,
                    confidence = payload.confidence,
                    perTf = payload.perTf,
                    timestampMs = payload.timestampMs,
                ),
            )
        }
        true
    }
}


@Composable
actual fun rememberShareText(): (title: String, text: String) -> Boolean {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    return { title, text ->
        scope.launch {
            runCatching {
                val file = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    val dir = java.io.File(context.cacheDir, "exports").apply { mkdirs() }
                    dir.listFiles()?.filter { it.isFile && it.name.endsWith(".csv") &&
                        System.currentTimeMillis() - it.lastModified() > 24 * 60 * 60 * 1000L
                    }?.forEach { it.delete() }
                    val safeName = title.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "scan_results.csv" }
                    val output = java.io.File(dir, "${System.currentTimeMillis()}_$safeName")
                    output.writeText(text, Charsets.UTF_8)
                    output
                }
                val uri = androidx.core.content.FileProvider.getUriForFile(
                    context, "${context.packageName}.fileprovider", file,
                )
                val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                    type = "text/csv"
                    putExtra(android.content.Intent.EXTRA_SUBJECT, title)
                    putExtra(android.content.Intent.EXTRA_STREAM, uri)
                    addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(android.content.Intent.createChooser(send, "导出扫描结果").apply {
                    addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                })
            }
        }
        true
    }
}
