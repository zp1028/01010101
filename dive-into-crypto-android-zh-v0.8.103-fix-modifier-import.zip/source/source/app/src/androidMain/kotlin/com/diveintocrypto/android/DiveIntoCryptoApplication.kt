package com.diveintocrypto.android

import android.app.Application
import com.diveintocrypto.android.data.createAppContainer
import com.diveintocrypto.android.domain.alerts.AndroidAlertNotifier

class DiveIntoCryptoApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        // Register the alert notification channel + app context up front. The
        // notifier itself no-ops when POST_NOTIFICATIONS is not granted.
        AndroidAlertNotifier.init(this)
        container = createAppContainer(this)
        // Start the outcome journal (alert/AI-plan forward tracking) with the app.
        // Its collectors are delayed and its refresh loop is bounded, so startup
        // stays cheap; without this reference tracking would only start when the
        // Alerts screen opens (lazy container val).
        container.outcomeJournal
    }
}
