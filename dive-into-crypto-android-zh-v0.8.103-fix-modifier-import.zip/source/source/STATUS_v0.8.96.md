# v0.8.96 — Replay fairness and retry backoff

- Replay batches now prioritize never-evaluated plans and the oldest checkpoint instead of repeatedly selecting the newest 12.
- Terminal replay outcomes are excluded by a pure scheduler helper.
- Transient history-fetch failures use bounded per-plan exponential retry backoff (1/2/4/8/15 minutes).
- Added scheduler regression test. Full Gradle/Compose verification remains unavailable due to Gradle distribution DNS failure; no APK built.
