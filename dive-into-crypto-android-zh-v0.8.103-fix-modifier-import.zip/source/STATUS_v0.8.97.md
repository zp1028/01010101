# v0.8.97 — Replay coverage observability

## Implemented
- Added a separate `coverageStatus` to replay evaluator results and persisted replay records. This separates market outcome from data coverage and remains backward-compatible through a default value for older JSON records.
- Classifies replay coverage as `NO_DATA`, `INVALID_INPUT`, `GAP`, `IN_PROGRESS`, `PARTIAL`, `SUFFICIENT_FOR_OUTCOME`, or `COMPLETE_THROUGH_EXPIRY`.
- Scanner forward-plan history summary now displays sufficient-coverage, gap/partial/no-data, and open-checkpoint counts.
- Win-rate and average-net-R display only includes target/stop results explicitly marked `SUFFICIENT_FOR_OUTCOME`.
- Replay-record dedupe includes coverage status so a later coverage-quality change is not silently collapsed into an older checkpoint.
- Added assertions for coverage classification to replay evaluator tests.

## Verification
- Source edits and structural review completed; ZIP integrity check is required after packaging.
- Full Gradle/Compose test suite has not been run because the prior environment could not download Gradle 8.10.2 (DNS `UnknownHostException`). Do not treat this as a successful full-project build.
- No APK built, as requested.

## Remaining work
1. Persist resumable history-pagination cursors and validate retries against real Binance responses.
2. Add a dedicated historical-performance report with equity curve, drawdown and sample-out-of-sample comparison.
3. Verify chart overlay alignment during zoom, pan and timeframe changes on the actual Compose project/device.
4. Complete full Gradle compile, automated tests and regression review of existing AI, scanner and chart functionality.
