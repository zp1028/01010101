# v0.8.87 — Forward-plan chart overlay and no-lookahead replay evaluator

## Implemented in this pass
- Panel chart now reads the same persisted `ForwardPlanJournal` as the scanner and filters plans by exact symbol and primary timeframe.
- Draws immutable local-plan trigger/stop/target levels and the latest accepted AI revision entry/stop/target through the chart's existing `referenceLevels` overlay path. Those levels are included in the same shared vertical price domain as candles/indicators, so zoom/pan uses the same coordinate transform rather than a separate scale.
- Adds a visible overlay caption clarifying that only current symbol/timeframe plans are shown.
- Added `ForwardPlanReplayEvaluator`: evaluates only fully closed candles after the frozen plan decision time and at/before `asOfMs`; deterministic sorting/deduping; conservative stop-first treatment when OHLC touches stop and target in the same candle; fee/slippage estimate for target outcome; no order execution.
- Added replay tests for pre-decision / post-as-of candle exclusion, conservative same-candle ambiguity and target outcomes.

## Validation
- v0.8.86 ZIP was validated before edits; this version is packaged from that complete source tree with the project structure preserved.
- Source changes inspected. Full Gradle/Compose compile and common tests are still blocked/unverified because Gradle 8.10.2 could not be downloaded in the prior environment due DNS/network failure. Do not treat test source as passing until Gradle test execution succeeds.
- No APK built.

## Remaining
- Add a dedicated plan history/detail/archive interface and aggregate replay metrics / sample-out-of-sample approval gate.
- Full compile, unit tests, UI regression and zoom/pan visual verification in a working Gradle environment.
