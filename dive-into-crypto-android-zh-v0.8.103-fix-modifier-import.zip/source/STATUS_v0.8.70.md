# v0.8.70 — AI plan target isolation

## Changes
- Added an explicit target key for the analysis screen's local AI plan cache (`symbol|timeframe`).
- The local AI plan is now eligible for display/use only when its recorded target matches the currently selected symbol and timeframe.
- Clears the target key when switching targets or clearing the AI conversation, and records the current target when a matching shared AI session supplies a plan.
- This closes a stale-plan race where a previous instrument's AI plan could briefly be used before asynchronous target-change cleanup runs.

## Preserved
- Existing local fallback plan, AI-plan toggle persistence, scanner-card behavior, chart overlays and gesture handling remain unchanged.
- Source-only update; no APK was built.

## Validation
- Source edits were applied to `AnalysisScreen.kt` and status note added.
- ZIP integrity is checked after packaging.
- Gradle compilation, unit tests, and device verification have not been run; do not treat this as a verified runtime fix yet.
