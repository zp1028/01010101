# v0.8.94 — Replay checkpoints and bounded re-evaluation

## Changes
- The scanner now persists non-terminal `OPEN` replay results as checkpoints, without treating them as settled performance outcomes.
- The scanner reads the latest checkpoint per plan and avoids downloading/replaying the entire plan window again until another timeframe interval could have closed.
- Terminal `TARGET_HIT`, `STOP_HIT`, and fully covered `EXPIRED` outcomes remain immutable and stop further replay for that plan.
- Existing no-lookahead and candle-continuity checks remain in place.

## Validation
- Reviewed scanner replay call path and checkpoint gating statically.
- ZIP integrity checked after packaging.
- Full Gradle/Compose tests remain unverified because Gradle distribution download previously failed with DNS/UnknownHostException.
- No APK built.
