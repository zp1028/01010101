# Dive Into Crypto v0.8.59 source status

- Corrected analysis mini-chart horizontal pan direction to match the main chart's data-window semantics: rightward finger drag reduces `panFraction` and reveals older candles.
- Fixed pattern overlay clipping so a pattern wholly outside the visible candle window is not falsely clamped and drawn at the viewport edge; partially visible patterns are clipped to the actual visible indices.
- Preserved the existing EMA20/EMA50 full-series calculations, trend-line clipping, support/resistance levels, AI model endpoint handling, and reset controls.
- No APK was built. ZIP integrity is checked; Android compilation and on-device gesture/overlay behavior remain unverified.
