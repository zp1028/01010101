# Dive Into Crypto v0.8.56 — Source-only fixes

Base: user-provided `dive-into-crypto-android-zh-v0.8.55-chart-reset-ema-ai-source.zip`.

## Changes in this revision

1. Analysis chart support/resistance range: both active support and active resistance now contribute to both price-range bounds, preventing valid levels from being clipped when they sit on the unexpected side of the candle-only range.
2. Analysis EMA20/EMA50: calculate each full-history EMA series once per candle-list update and slice it to the exact visible candle window. This reduces repeated calculations during gestures and keeps the seed independent of viewport changes.
3. AI model list lookup: normalize common pasted endpoint suffixes (`/chat/completions`, `/responses`, `/models`); try the canonical OpenAI-compatible `/v1/models` or `/models` endpoint and fall back to the root-level `/models` path on HTTP 404/405. Improve malformed-JSON and unsupported-response messages.

## Validation

- ZIP integrity checked with `unzip -t`.
- Source edits inspected with targeted text checks.
- Android/Gradle compilation and device behavior were not tested.
- No APK was built, as requested.
- Provider-specific model endpoints may still require custom handling when they are not OpenAI-compatible.
