# Dive Into Crypto v0.8.64 — analysis reference-price range

## Changes
- Analysis chart vertical price range now includes valid positive finite LAST/live price and plan ENTRY/SL/TP levels.
- Active support/resistance levels are checked for finite positive values before they affect the price scale.
- The shared horizontal level renderer ignores invalid/non-positive prices and guards invalid price-domain values.
- Preserves prior source changes from v0.8.63, including EMA20/EMA50, chart zoom/pan/reset, trend-line clipping, FVG/order-block viewport clipping, and AI model-list parsing changes.

## Validation
- Source-only update; no APK/Gradle build performed by request.
- ZIP integrity check should be run after packaging.
- Compose compilation and real-device chart alignment remain unverified.
