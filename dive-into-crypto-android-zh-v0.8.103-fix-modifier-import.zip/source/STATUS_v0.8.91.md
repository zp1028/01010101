# v0.8.91 — automatic historical replay integration

## Implemented
- Scanner screen now runs a bounded replay worker while visible, polling every 60 seconds.
- It fetches real Binance USDT-M futures candles through the existing `MarketDataEngine.futuresHistory` API (up to 1000 bars) for the plan's own symbol/timeframe.
- Replay uses `ForwardPlanReplayEvaluator`, which filters candles after the frozen decision time and no later than `asOfMs`, sorts/deduplicates, and applies conservative stop-first handling when OHLC touches both levels.
- Only terminal outcomes (target, stop, expired) are persisted to the existing replay journal; open outcomes are not repeatedly written.
- Missing candle coverage is skipped rather than incorrectly classifying a plan as expired.
- The worker is bounded to the newest 12 visible non-archived plans per cycle and does not invoke any order/trading API.

## Limitations / verification
- Replay is currently foreground/scanner-screen scoped; it is not a background worker and does not run when the scanner screen is not active.
- Binance REST history is limited to the latest 1000 bars; older plans may not have full post-decision coverage. Such plans are skipped when no eligible candles are available.
- A persisted terminal replay result is de-duplicated by plan ID for the automatic worker. If a user intentionally wants to re-run an evaluation with different cost assumptions, a separate explicit re-evaluation workflow is still needed.
- Full Gradle/Compose compile and tests have not been run due to prior Gradle distribution DNS/download failure. No APK built.
