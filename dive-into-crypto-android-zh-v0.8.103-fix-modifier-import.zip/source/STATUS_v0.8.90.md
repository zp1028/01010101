# v0.8.90 — Replay persistence and cost accounting

## Changes
- Added schema v3 replay-result records to the existing forward-plan journal.
- Added `appendReplayResult` with plan existence validation, bounded history, duplicate suppression, finite-R checks, and persisted result notes.
- Replay records are removed only when their owning archived plan is explicitly deleted; archiving itself preserves the audit trail.
- Scanner history summary now reports saved replay counts and resolved win/loss/net-R summaries, and explicitly states when no resolved replay sample exists.
- Corrected replay accounting so stop outcomes include estimated round-trip costs as well as target outcomes.
- Corrected the replay cutoff summary to avoid reporting candles after the plan expiry as the last evaluated candle.
- Added regression test source for replay persistence, duplicate suppression, reload, and cleanup with archived plans.

## Validation
- Independent Kotlin compilation of Candle, Format, MarketDataFreshness, ForwardEntryPlanEngine, ForwardPlanReplayEvaluator and ForwardPlanPerformance passed using a temporary `Serializable` annotation stub. This validates syntax for those pure-domain files only; it is not a Gradle build.
- Manual replay check passed: an ambiguous stop/target candle resolves conservatively to stop and includes estimated costs.
- ZIP integrity checked after packaging.
- Full Gradle/Compose compilation and unit tests remain unverified because the Gradle distribution download previously failed with DNS/network errors.
- No APK was built.

## Remaining
- The app does not yet fetch historical candles and automatically run/store replay results end-to-end. The journal persistence API and summary display are now ready for that integration.
- Full chart overlay regression, historical data adapter integration, out-of-sample evaluation workflow, and complete project tests remain outstanding.
