# v0.8.93 — Replay candle continuity safeguards

## Changes
- Replay accepts a candle whose open time precedes the plan decision only when its close timestamp is strictly after the decision; no high/low is evaluated before that close.
- Added optional expected timeframe interval to replay evaluation.
- With interval metadata, a missing initial window or gap between closed candles prevents later target/stop candles from being trusted, because a missing candle could contain an earlier outcome.
- Expiry settlement now requires continuous candle coverage through the expiry boundary when interval metadata is available.
- Scanner replay passes the plan timeframe's expected interval.
- Added tests for gaps before target, pre-decision candle open with post-decision close, and expiry across a gap.

## Validation
- Source and tests updated. Full Gradle/Compose verification remains blocked by the existing Gradle distribution DNS/download issue; no APK built.
