# v0.8.75 — AI asynchronous fetch generation guard

## Changes
- Added an optional expected-generation token to `AiSessionHub.startAnalysis`.
- Scanner and custom-question workflows pass the generation captured before multi-timeframe fetches.
- The token is checked atomically when binding the new AI session, so a fetch that finishes after a newer target has replaced it cannot start an obsolete AI request.
- Early configuration/K-line failure paths also avoid overwriting a newer session when an expected generation is supplied.

## Preserved
- Existing report streaming, conversation history behavior, plan parsing, chart overlays, scanner features, and AI configuration remain in place.
- Source-only update; no APK build.

## Validation
- Source-level changes reviewed and ZIP integrity checked after packaging.
- Gradle compilation, unit tests, and device validation were not run; do not treat them as passed.
