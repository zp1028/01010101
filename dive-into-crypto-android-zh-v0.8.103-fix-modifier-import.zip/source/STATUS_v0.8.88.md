# v0.8.88 — Forward-plan history and performance gate

## Implemented in this pass
- Expanded the forward-plan scanner summary to show persisted snapshot count, AI revision count, status distribution (waiting, condition met, invalid/expired), and up to eight recent lifecycle events.
- Added `ForwardPlanPerformance`, a deterministic aggregator for resolved replay outcomes: resolved sample count, wins/losses, hit rates, average net R and cumulative-curve maximum drawdown in R. Open/unresolved/expired-without-outcome records are excluded from win/loss statistics.
- Added a conservative weight-approval gate requiring minimum resolved samples in both in-sample and out-of-sample sets and positive expectancy in both. It explicitly does not apply weights automatically.
- Added common tests for unresolved-result exclusion, expectancy/drawdown, insufficient out-of-sample evidence, and non-positive out-of-sample expectancy.

## Validation
- ZIP structure and integrity checked after packaging.
- Full Gradle/Compose build and common tests remain unverified because the prior Gradle 8.10.2 distribution download failed with DNS/network error. No APK built.

## Still incomplete
- Dedicated plan-detail/archive/clear UI and persistent replay-result storage/visual analytics.
- Actual historical candle data plumbing into replay evaluation and an end-to-end no-lookahead audit.
- Live chart overlay zoom/pan regression and full project build/test verification.
