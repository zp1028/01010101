# v0.8.99 — Historical performance report and final source regression pass

## Completed in source
- Retained the v0.8.98 resumable historical-replay pagination and expiry-boundary correction.
- Completed the forward-plan historical performance report using only records whose coverage is `SUFFICIENT_FOR_OUTCOME`, outcome is `TARGET_HIT` or `STOP_HIT`, and net R is finite. Open, expired, partial, gap, no-data, and invalid records do not enter win-rate, expectancy, drawdown, or equity-curve metrics.
- Report includes qualified/excluded sample counts, target/stop rates, win rate, average net R, maximum drawdown, chronological 70/30 train/out-of-sample comparison, sample-size warnings, and cumulative net-R sparkline.
- Plan/AI entry, stop-loss, and take-profit reference levels are integrated into the chart's shared price domain and filtered to the active symbol/timeframe. Candles, indicators, structure overlays, and reference levels share the same y transform. Zoom/pan uses the visible candle slice, with a reset control.
- Existing unit tests cover report eligibility and chronological split, chart scale and overlay bounds, replay coverage integrity, pagination persistence, and expiry-boundary behavior.

## Validation
- Source-level inspection confirms the performance report is connected to the scanner history panel and chart plan levels are connected to `CandleChartCard`.
- ZIP integrity and static source checks are run for this version.
- Full Gradle compilation and `:app:allTests` remain blocked unless the Gradle 8.10.2 wrapper distribution can be downloaded; the prior attempt failed on DNS resolution for `mirrors.cloud.tencent.com`. Therefore this version does **not** claim full compile/test success.
- No APK was built, as requested.

## Remaining acceptance status
- Source implementation for the three tracked workstreams (historical report, chart overlay integration, and regression review) is complete to the extent possible offline.
- Remaining external verification: run `./gradlew :app:allTests --no-daemon` in an environment with Gradle distribution/network access, then visually verify pinch zoom/pan and timeframe switching on a real Android device. These are verification gates, not known source tasks that can be truthfully marked passed here.
- Historical replay still runs while the scanner screen is active; background scheduling is outside this change. Replay progress is intentionally bounded (24 plans / 5,000 candles per plan) in the existing JSON journal.
