# v0.8.77 — Chart range padding hardening

## Changes
- Hardened `ChartMath.chartPriceRange` against invalid padding values (`NaN`, infinities, negative values, and excessive values).
- Bounds the accepted padding fraction to 0–25%; invalid values use the normal 6% default.
- Avoids introducing infinite padding if subtracting extreme finite prices overflows.
- Added a regression test for invalid/excessive padding values.

## Validation
- Source and regression test added.
- ZIP integrity checked after packaging.
- Gradle tests attempted but could not start: the Gradle wrapper tried to download Gradle 8.10.2 from `mirrors.cloud.tencent.com`; network DNS failed (`UnknownHostException`). No APK was built, per request. Runtime/device behavior remains unverified.
