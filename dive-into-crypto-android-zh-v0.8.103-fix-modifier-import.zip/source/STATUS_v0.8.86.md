# v0.8.86 — Immutable AI plan revisions

## Implemented in this pass
- Added schema-v2 journal support with backward-compatible defaults for existing schema-v1 persisted journals.
- Added `ForwardPlanRevision`, an append-only version record for AI fusion suggestions. Original local plan snapshots and lifecycle status envelopes are not overwritten by AI proposals.
- Added guardrails before a revision can be recorded: plan must still be active and unexpired, entry must remain within the configured reference-price drift limit, stop/target must be directionally valid, and gross reward/risk must be at least 1.2.
- Scanner page now appends accepted AI proposals against the matching active local plan and shows the latest revision number, entry/stop/target, R:R and rationale on the forward-plan card.
- Added regression tests for immutable local snapshots, duplicate revision idempotency, invalid direction and insufficient R:R.
- Retained local ranking and local plan as authoritative; no order execution added.

## Validation
- Source-level inspection and ZIP integrity checks are performed for this version.
- Full Gradle/Compose compilation and common tests are not verified because the environment previously failed to download Gradle 8.10.2 due to DNS/network failure.
- No APK built, per user instruction.

## Still incomplete
- Chart overlay for local plan + AI revision with zoom/pan coordinate regression.
- Historical replay/no-lookahead evaluation and out-of-sample weight approval gate.
- Dedicated plan history/detail/archive UI and complete end-to-end regression run.
