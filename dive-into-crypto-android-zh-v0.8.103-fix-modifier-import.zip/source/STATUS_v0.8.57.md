# Dive Into Crypto v0.8.57 — Source-only continuation

Base: user-provided v0.8.55 source archive, including the v0.8.56 source edits.

## Changes in this revision

1. Analysis chart trend-line rendering now clips a segment to the visible candle-index window and interpolates endpoint prices. A trend segment is no longer hidden merely because one pivot endpoint is outside the current zoom/pan viewport.
2. AI model list parsing now accepts common response shapes: OpenAI-compatible `data`, gateway-style `models` or `items`, and a bare JSON array. Model identifiers may be supplied as `id`, `model`, or `name`.
3. Kept the existing EMA20/EMA50 full-series caching, chart reset control, support/resistance price-range inclusion, and model endpoint fallback behavior from v0.8.56.

## Validation

- ZIP archive integrity checked with `unzip -t`.
- Targeted source inspection performed for trend-line clipping and model response parsing.
- Android/Gradle compilation and device behavior were not tested.
- No APK was built, as requested.
