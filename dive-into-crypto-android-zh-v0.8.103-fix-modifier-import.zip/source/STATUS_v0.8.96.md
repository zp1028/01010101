# v0.8.96 — Replay fairness and retry backoff

## Changes
- Added `ForwardReplayBatchSelector` to choose bounded replay work fairly: never-evaluated plans and plans with the oldest checkpoint are considered first; terminal replay plans are excluded.
- Replaced newest-first selection of the first 12 active plans, which could starve older plans, with the fair selector.
- Added per-plan exponential retry backoff after transient history request failures (1, 2, 4, 8, then 15 minutes), so a failing symbol/endpoint does not trigger a request every minute indefinitely.
- Backoff is intentionally in-memory; persisted replay checkpoints remain durable and a process restart retries safely.
- Added a unit test for fair selection and terminal-plan exclusion.

## Validation
- Source edits and targeted static review performed.
- Full Gradle/Compose tests remain blocked by prior Gradle distribution DNS failure; no claim of full project compilation.
- No APK built.
