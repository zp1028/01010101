Chart: Binance-style horizontal pan only; remove free vertical drag
