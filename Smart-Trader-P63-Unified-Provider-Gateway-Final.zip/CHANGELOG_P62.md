# P62 Change Log

- Added unified `CryptoProviderGateway` with Binance → OKX → Bybit ordered failover.
- Made crypto market discovery and quotes source-coherent in one provider attempt.
- Added provider/source/error metadata to the market response.
- Routed crypto OHLCV through the same gateway.
- Removed direct Binance/OKX/Bybit URLs from Android `RestClient.kt`.
- Preserved analysis-only behavior and truthful unavailable-field handling.
- Added provider failover regression tests.
- Backend test result: 109 passed.
