from fastapi import APIRouter, HTTPException, Query

from app.services.market_universe import MarketUniverseService, UniverseItem
from app.services.market_coverage import MarketCoverageService
from app.services.market_data_status import MarketDataStatusService
from app.services.crypto_provider_gateway import crypto_gateway

router = APIRouter(tags=["markets"])
universe = MarketUniverseService()
coverage = MarketCoverageService(universe)
data_status = MarketDataStatusService()


@router.get("/markets")
async def markets(
    market: str | None = Query(None, description="crypto/us/hk/commodities"),
    q: str | None = Query(None, description="symbol/name search"),
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0, le=1000000),
    sort: str = Query("symbol", description="symbol|name"),
):
    market_key = market.lower() if market else None
    crypto_provider = None
    crypto_errors: list[dict] = []

    # Crypto universe and quotes are obtained from the SAME provider attempt.
    # This prevents a cached OKX universe from being paired with a fresh
    # Binance quote set (or vice versa).
    if market_key == "crypto":
        raw_items, quote_map, crypto_errors = await crypto_gateway.discover()
        crypto_provider = next((qv.get("provider") for qv in quote_map.values() if qv.get("provider")), None)
        items = [UniverseItem(x["symbol"], x.get("name", x["symbol"]), "crypto", "crypto",
                               x.get("venue", "unknown"), x.get("currency", "USDT"), x.get("metadata", {}))
                 for x in raw_items]
    elif market_key == "us":
        items = await universe.us()
    elif market_key == "hk":
        items = await universe.hk()
    elif market_key == "commodities":
        items = await universe.commodities()
    else:
        # The all-market endpoint keeps crypto truthful too; other asset
        # classes retain their configured/static provider semantics.
        raw_items, quote_map, crypto_errors = await crypto_gateway.discover()
        crypto_provider = next((qv.get("provider") for qv in quote_map.values() if qv.get("provider")), None)
        crypto_items = [UniverseItem(x["symbol"], x.get("name", x["symbol"]), "crypto", "crypto",
                                      x.get("venue", "unknown"), x.get("currency", "USDT"), x.get("metadata", {}))
                        for x in raw_items]
        others = await __import__("asyncio").gather(universe.us(), universe.hk(), universe.commodities())
        items = crypto_items + [x for group in others for x in group]

    if q:
        needle = q.lower()
        items = [x for x in items if needle in x.symbol.lower() or needle in x.name.lower()]
    items = sorted(items, key=lambda x: (x.name.lower(), x.symbol.lower()) if sort == "name" else x.symbol.lower())
    total = len(items)
    page = items[offset:offset + limit]

    # For crypto, quote_map is paired with the same discovery result above.
    # Other markets intentionally expose no synthetic crypto quote.
    if market_key not in (None, "crypto"):
        quote_map = {}
    rows = []
    for x in page:
        row = x.__dict__.copy() if hasattr(x, "__dict__") else {
            "symbol": x.symbol, "name": x.name, "market": x.market,
            "asset_type": x.asset_type, "venue": x.venue, "currency": x.currency,
            "metadata": x.metadata or {},
        }
        quote = quote_map.get(str(x.symbol).upper().replace("/", "")) if x.market == "crypto" else None
        if quote:
            row.update(quote)
            row["quote_status"] = "live"
            meta = row.get("metadata") or {}
            row["contract_type"] = quote.get("contract_type") or meta.get("contract_type", "")
            row["market_data_type"] = quote.get("market_data_type") or ""
        else:
            row["quote_status"] = "provider_unavailable"
        rows.append(row)
    return {
        "analysis_only": True,
        "provider": crypto_provider if market_key in (None, "crypto") else None,
        "provider_errors": crypto_errors if market_key in (None, "crypto") else [],
        "count": len(page), "total": total, "offset": offset, "limit": limit,
        "has_more": offset + limit < total, "markets": rows,
    }


@router.get("/markets/coverage")
async def market_coverage():
    return await coverage.snapshot()


@router.get("/markets/data-status")
async def market_data_status():
    return data_status.snapshot()


@router.get("/markets/{symbol}")
async def market(symbol: str):
    items = await universe.all()
    raw = symbol.upper().replace("/", "")
    found = next((x for x in items if x.symbol.upper().replace("/", "") == raw or x.symbol.upper() == symbol.upper()), None)
    if not found:
        # Crypto detail uses the same provider gateway as the market list.
        raw_items, _, provider_errors = await crypto_gateway.discover()
        raw = raw.upper().replace("/", "")
        matched = next((x for x in raw_items if str(x.get("symbol", "")).upper().replace("/", "") == raw), None)
        if matched:
            return {"analysis_only": True, "symbol": matched["symbol"], "name": matched.get("name", matched["symbol"]),
                    "market": "crypto", "asset_type": "crypto", "venue": matched.get("venue", "unknown"),
                    "currency": matched.get("currency", "USDT"), "metadata": matched.get("metadata", {}),
                    "provider_errors": provider_errors}
        raise HTTPException(404, "instrument not found in current provider universe")
    return {
        "analysis_only": True,
        "symbol": found.symbol,
        "name": found.name,
        "market": found.market,
        "asset_type": found.asset_type,
        "venue": found.venue,
        "currency": found.currency,
        "metadata": found.metadata or {},
    }
