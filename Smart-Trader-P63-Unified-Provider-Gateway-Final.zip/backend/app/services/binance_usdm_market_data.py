from __future__ import annotations

"""Legacy USD-M quote facade backed by the unified crypto provider gateway."""

from typing import Any
import httpx  # kept for compatibility with existing tests/integrations
from app.services.crypto_provider_gateway import CryptoProviderGateway


class BinanceUsdMMarketData:
    """Compatibility facade; provider selection and REST endpoints live in the gateway."""
    def __init__(self, base_url: str | None = None, timeout: float = 8.0, ttl: float = 5.0):
        self.timeout = timeout
        self.gateway = CryptoProviderGateway(timeout=timeout, providers=["binance", "okx", "bybit"])
        self._cache: tuple[float, dict[str, dict[str, Any]]] = (0.0, {})
        self.ttl = ttl

    async def quotes(self) -> dict[str, dict[str, Any]]:
        import time
        now = time.monotonic()
        if now - self._cache[0] < self.ttl and self._cache[1]:
            return self._cache[1]
        universe, quotes, _ = await self.gateway.discover()
        provider_name = next((x.get("venue") for x in universe if x.get("venue")), None)
        if provider_name == "binance":
            p = next(x for x in self.gateway.providers if x.name == "binance")
            mark = await self.gateway._call(p, "/fapi/v1/premiumIndex")
            book = await self.gateway._call(p, "/fapi/v1/ticker/bookTicker")
            marks = {str(x.get("symbol", "")).upper(): x for x in mark if isinstance(x, dict)} if isinstance(mark, list) else {}
            books = {str(x.get("symbol", "")).upper(): x for x in book if isinstance(x, dict)} if isinstance(book, list) else {}
            for symbol, row in quotes.items():
                m, b = marks.get(symbol, {}), books.get(symbol, {})
                if m:
                    row.update({"mark_price": self._float(m.get("markPrice")), "index_price": self._float(m.get("indexPrice")),
                                "funding_rate": self._float(m.get("lastFundingRate")), "next_funding_time": m.get("nextFundingTime"), "mark_data_time": m.get("time")})
                if b:
                    row.update({"bid": self._float(b.get("bidPrice")), "bid_size": self._float(b.get("bidQty")),
                                "ask": self._float(b.get("askPrice")), "ask_size": self._float(b.get("askQty")), "book_data_time": b.get("time")})
                row["market_type"] = "USD-M"
        if quotes:
            self._cache = (now, quotes)
        return quotes or self._cache[1]

    async def symbol_quote(self, symbol: str):
        return (await self.quotes()).get(symbol.replace("/", "").replace("-", "").upper())

    @staticmethod
    def _float(value):
        try: return float(value) if value is not None else None
        except (TypeError, ValueError): return None
