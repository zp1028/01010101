from __future__ import annotations

"""Cross-provider comparison view built on the unified provider gateway."""

import asyncio
from app.services.crypto_provider_gateway import crypto_gateway


class CryptoMultiExchangeService:
    def __init__(self, timeout: float = 8.0):
        self.timeout = timeout

    @staticmethod
    def normalize(symbol: str) -> str:
        return crypto_gateway.normalize(symbol)

    @staticmethod
    def _okx_inst(symbol: str) -> str:
        return crypto_gateway.okx_inst(symbol)

    async def _provider_derivatives(self, name: str, symbol: str):
        gw = type(crypto_gateway)(timeout=self.timeout, providers=[name])
        d = await gw.derivatives(symbol, "1h")
        m = d.get("mark_index") or {}
        f = d.get("funding", {}).get("latest") or {}
        oi = d.get("open_interest", {}).get("latest") or {}
        return {"provider": name, "available": bool(d.get("available")),
                "mark_price": m.get("mark_price"), "index_price": m.get("index_price"),
                "funding_rate": m.get("last_funding_rate") or f.get("fundingRate"),
                "open_interest": oi.get("open_interest"),
                "long_short": d.get("long_short", {}).get("latest")}

    async def _binance(self, client=None, s=None):
        return await self._provider_derivatives("binance", s)

    async def _okx(self, client=None, s=None):
        return await self._provider_derivatives("okx", s)

    async def _bybit(self, client=None, s=None):
        return await self._provider_derivatives("bybit", s)

    async def snapshot(self, symbol: str):
        s = self.normalize(symbol)
        rows = await asyncio.gather(
            self._binance(None, s), self._okx(None, s), self._bybit(None, s),
            return_exceptions=True,
        )
        normalized=[]
        for name, row in zip(("binance","okx","bybit"), rows):
            if isinstance(row, Exception):
                normalized.append({"provider":name,"available":False,"reason":str(row)})
            else:
                normalized.append(row)
        available = [r for r in normalized if r.get("available")]
        def avg(key):
            vals=[r[key] for r in available if r.get(key) is not None]
            return sum(vals)/len(vals) if vals else None
        return {"symbol":symbol,"normalized_symbol":s,"read_only":True,
                "providers":normalized,"available_provider_count":len(available),
                "consensus":{"mark_price_mean":avg("mark_price"),"funding_rate_mean":avg("funding_rate"),"open_interest_mean":avg("open_interest")},
                "divergence":{"funding_rate_spread":self._spread(available,"funding_rate"),"mark_price_spread_pct":self._pct_spread(available,"mark_price")},
                "analysis_only":True}

    @staticmethod
    def _spread(rows, key):
        vals=[r[key] for r in rows if r.get(key) is not None]
        return max(vals)-min(vals) if len(vals)>=2 else None

    @staticmethod
    def _pct_spread(rows, key):
        vals=[r[key] for r in rows if r.get(key) is not None]
        return (max(vals)-min(vals))/min(vals)*100 if len(vals)>=2 and min(vals)!=0 else None
