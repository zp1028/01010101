"""Compatibility name for the unified read-only derivatives gateway."""
from app.services.crypto_provider_gateway import crypto_gateway


class BinanceDerivativesService:
    """Legacy service name; public derivatives data now uses provider failover."""
    def __init__(self, timeout: float = 12.0):
        self.timeout = timeout

    async def snapshot(self, symbol: str, period: str = "1h"):
        return await crypto_gateway.derivatives(symbol, period)
