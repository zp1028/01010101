from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any
import httpx

from app.services.crypto_provider_gateway import crypto_gateway


@dataclass(frozen=True, slots=True)
class UniverseItem:
    symbol: str
    name: str
    market: str
    asset_type: str
    venue: str
    currency: str | None = None
    metadata: dict[str, Any] | None = None


class MarketUniverseService:
    """Analysis-only universe. Crypto discovery is provider-registry driven."""

    def __init__(self) -> None:
        self._cache: dict[str, tuple[float, list[UniverseItem]]] = {}
        self._ttl = 3600.0

    async def crypto(self) -> list[UniverseItem]:
        cached = self._cached("crypto")
        if cached is not None and cached:
            return cached
        rows, _, errors = await crypto_gateway.discover()
        out = [UniverseItem(x["symbol"], x.get("name", x["symbol"]), "crypto", "crypto",
                            x.get("venue", "unknown"), x.get("currency", "USDT"), x.get("metadata", {}))
               for x in rows]
        if out:
            return self._put("crypto", out)
        # Do not cache provider failure as a healthy empty universe.
        return []

    async def us(self) -> list[UniverseItem]:
        cached = self._cached("us")
        if cached is not None:
            return cached
        url = "https://www.sec.gov/files/company_tickers.json"
        headers = {"User-Agent": "SmartTrader/1.0 analysis app contact=local"}
        async with httpx.AsyncClient(timeout=20, headers=headers) as client:
            r = await client.get(url); r.raise_for_status(); data = r.json()
        out = [UniverseItem(symbol=v["ticker"], name=v["title"], market="us", asset_type="stock",
                            venue="sec", currency="USD", metadata={"cik": str(v["cik_str"]).zfill(10)})
               for v in data.values() if v.get("ticker")]
        return self._put("us", out)

    async def hk(self) -> list[UniverseItem]:
        import os
        url = os.getenv("SMART_TRADER_HK_UNIVERSE_URL", "").strip()
        if not url:
            return []
        cached = self._cached("hk")
        if cached is not None:
            return cached
        async with httpx.AsyncClient(timeout=20) as client:
            r = await client.get(url); r.raise_for_status(); data = r.json()
        out = []
        for x in data if isinstance(data, list) else data.get("items", []):
            symbol = str(x.get("symbol", "")).strip()
            if symbol:
                out.append(UniverseItem(symbol, x.get("name", symbol), "hk", "stock", x.get("venue", "hkex"), x.get("currency", "HKD"), x))
        return self._put("hk", out)

    async def commodities(self) -> list[UniverseItem]:
        import os
        url = os.getenv("SMART_TRADER_COMMODITY_UNIVERSE_URL", "").strip()
        if not url:
            return []
        cached = self._cached("commodities")
        if cached is not None:
            return cached
        async with httpx.AsyncClient(timeout=20) as client:
            r = await client.get(url); r.raise_for_status(); data = r.json()
        items = data if isinstance(data, list) else data.get("items", [])
        out = [UniverseItem(str(x.get("symbol", "")), x.get("name", x.get("symbol", "")), "commodities", "future",
                            x.get("venue", "futures"), x.get("currency", "USD"), {**x, "universe_source": "configured_provider"})
               for x in items if str(x.get("symbol", "")).strip()]
        return self._put("commodities", out)

    def _cached(self, key: str):
        hit = self._cache.get(key)
        if hit and time.monotonic() - hit[0] < self._ttl:
            return hit[1]
        return None

    def _put(self, key: str, value):
        self._cache[key] = (time.monotonic(), value)
        return value

    async def all(self):
        import asyncio
        groups = await asyncio.gather(self.crypto(), self.us(), self.hk(), self.commodities())
        return [x for g in groups for x in g]
