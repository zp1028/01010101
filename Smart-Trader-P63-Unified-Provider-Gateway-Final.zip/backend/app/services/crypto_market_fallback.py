"""Backward-compatible facade over the unified crypto provider gateway."""
from __future__ import annotations
from app.services.crypto_provider_gateway import crypto_gateway


class CryptoMarketFallbackService:
    @staticmethod
    def _norm(symbol: str) -> str:
        return crypto_gateway.normalize(symbol)

    @staticmethod
    def _okx_inst(symbol: str) -> str:
        return crypto_gateway.okx_inst(symbol)

    @staticmethod
    def _pct(last, prev):
        try:
            a,b=float(last),float(prev)
            return (a-b)/b*100 if b else 0.0
        except (TypeError,ValueError):
            return 0.0
