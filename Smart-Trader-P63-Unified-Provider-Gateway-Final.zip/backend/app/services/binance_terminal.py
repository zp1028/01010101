import httpx
"""Compatibility name for the unified read-only crypto terminal gateway."""
from app.services.crypto_provider_gateway import crypto_gateway


class BinanceUsdMTerminalService:
    """Legacy service name; implementation is provider-agnostic and failover based."""
    def __init__(self, base_url: str | None = None, timeout: float = 12.0):
        self.timeout = timeout

    async def snapshot(self, symbol: str, interval: str = "15m", depth_limit: int = 20, trade_limit: int = 20):
        return await crypto_gateway.terminal(symbol, interval, depth_limit, trade_limit)
