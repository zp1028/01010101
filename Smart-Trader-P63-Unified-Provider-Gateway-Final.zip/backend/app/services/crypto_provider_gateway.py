from __future__ import annotations

"""Unified, read-only crypto market-data gateway.

All exchange-specific HTTP endpoints live here. Higher layers select a
logical crypto operation and receive normalized data plus the provider that
actually supplied it. Failover never mixes a failed provider's partial data
with another provider's successful snapshot.
"""

import asyncio
import time
from dataclasses import dataclass
from typing import Any

import httpx


@dataclass(frozen=True, slots=True)
class CryptoProviderSpec:
    name: str
    rest_base: str
    priority: int


class CryptoProviderGateway:
    INTERVALS = {
        "1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "8h",
        "12h", "1d", "3d", "1w",
    }
    PERIODS = {"5m", "15m", "30m", "1h", "2h", "4h", "6h", "12h", "1d"}

    def __init__(self, timeout: float = 12.0, providers: list[str] | None = None):
        self.timeout = timeout
        specs = {
            "binance": CryptoProviderSpec("binance", "https://fapi.binance.com", 10),
            "okx": CryptoProviderSpec("okx", "https://www.okx.com", 20),
            "bybit": CryptoProviderSpec("bybit", "https://api.bybit.com", 30),
        }
        names = providers or ["binance", "okx", "bybit"]
        self.providers = [specs[x] for x in names if x in specs]

    @staticmethod
    def normalize(symbol: str) -> str:
        return symbol.replace("/", "").replace("-", "").replace("_", "").upper()

    @staticmethod
    def okx_inst(symbol: str) -> str:
        raw = CryptoProviderGateway.normalize(symbol)
        base = raw[:-4] if raw.endswith("USDT") else raw
        return f"{base}-USDT-SWAP"

    async def _json(self, client: httpx.AsyncClient, provider: CryptoProviderSpec, path: str,
                    params: dict[str, Any] | None = None) -> Any:
        url = provider.rest_base + path
        try:
            response = await client.get(url, params=params)
        except TypeError:
            # Small compatibility path for lightweight test clients that only
            # implement get(url); real httpx always accepts params.
            if params:
                from urllib.parse import urlencode
                url += ("&" if "?" in url else "?") + urlencode(params)
            response = await client.get(url)
        response.raise_for_status()
        return response.json()

    async def _call(self, provider: CryptoProviderSpec, path: str,
                    params: dict[str, Any] | None = None) -> Any:
        async with httpx.AsyncClient(timeout=self.timeout, headers={"User-Agent": "SmartTrader/1.0 analysis"}) as client:
            return await self._json(client, provider, path, params)

    async def _parallel(self, provider: CryptoProviderSpec, calls: dict[str, tuple[str, dict[str, Any]]]) -> dict[str, Any]:
        async with httpx.AsyncClient(timeout=self.timeout, headers={"User-Agent": "SmartTrader/1.0 analysis"}) as client:
            tasks = {name: self._json(client, provider, path, params) for name, (path, params) in calls.items()}
            values = await asyncio.gather(*tasks.values(), return_exceptions=True)
        return {name: value for name, value in zip(tasks, values)}

    async def discover(self) -> tuple[list[dict[str, Any]], dict[str, dict[str, Any]], list[dict[str, Any]]]:
        errors: list[dict[str, Any]] = []
        for provider in self.providers:
            try:
                universe, quotes = await self._discover_provider(provider)
                if universe and quotes:
                    return universe, quotes, errors
                if not universe:
                    errors.append({"provider": provider.name, "reason": "empty universe"})
                else:
                    errors.append({"provider": provider.name, "reason": "empty quotes"})
            except Exception as exc:
                errors.append({"provider": provider.name, "reason": str(exc)})
        return [], {}, errors

    async def _discover_provider(self, provider: CryptoProviderSpec):
        if provider.name == "binance":
            info, tickers = await asyncio.gather(
                self._call(provider, "/fapi/v1/exchangeInfo"),
                self._call(provider, "/fapi/v1/ticker/24hr"),
            )
            ticker_map = {str(x.get("symbol", "")).upper(): x for x in tickers if isinstance(x, dict)}
            universe, quotes = [], {}
            for x in info.get("symbols", []) if isinstance(info, dict) else []:
                if not isinstance(x, dict) or x.get("status") != "TRADING":
                    continue
                if x.get("contractType") not in {"PERPETUAL", "CURRENT_QUARTER", "NEXT_QUARTER"}:
                    continue
                if str(x.get("quoteAsset", "")).upper() not in {"USDT", "USDC"}:
                    continue
                symbol = str(x.get("symbol", "")).upper()
                if not symbol:
                    continue
                universe.append({"symbol": symbol, "name": x.get("pair", symbol), "market": "crypto",
                                 "asset_type": "crypto", "venue": "binance", "currency": x.get("quoteAsset"),
                                 "metadata": {"base": x.get("baseAsset"), "contract_type": x.get("contractType"),
                                              "market_type": "futures", "provider": "binance"}})
                t = ticker_map.get(symbol, {})
                if t.get("lastPrice"):
                    quotes[symbol] = self._quote_binance(t)
            return universe, quotes

        if provider.name == "okx":
            instruments, tickers = await asyncio.gather(
                self._call(provider, "/api/v5/public/instruments", {"instType": "SWAP"}),
                self._call(provider, "/api/v5/market/tickers", {"instType": "SWAP"}),
            )
            rows = instruments.get("data", []) if isinstance(instruments, dict) else []
            ticker_map = {str(x.get("instId", "")).upper(): x for x in (tickers.get("data", []) if isinstance(tickers, dict) else [])}
            universe, quotes = [], {}
            for x in rows:
                if not isinstance(x, dict) or str(x.get("state", "")).lower() != "live":
                    continue
                inst = str(x.get("instId", "")).upper()
                if not inst.endswith("-USDT-SWAP"):
                    continue
                symbol = inst.replace("-", "")
                universe.append({"symbol": symbol, "name": inst, "market": "crypto", "asset_type": "crypto",
                                 "venue": "okx", "currency": "USDT",
                                 "metadata": {"base": x.get("ctValCcy") or symbol[:-4], "contract_type": "PERPETUAL",
                                              "market_type": "SWAP", "provider": "okx"}})
                t = ticker_map.get(inst, {})
                if t.get("last"):
                    quotes[symbol] = self._quote_okx(t)
            return universe, quotes

        instruments, tickers = await asyncio.gather(
            self._call(provider, "/v5/market/instruments-info", {"category": "linear", "limit": "1000"}),
            self._call(provider, "/v5/market/tickers", {"category": "linear"}),
        )
        rows = ((instruments.get("result") or {}).get("list") or []) if isinstance(instruments, dict) else []
        ticker_map = {str(x.get("symbol", "")).upper(): x for x in (((tickers.get("result") or {}).get("list") or []) if isinstance(tickers, dict) else [])}
        universe, quotes = [], {}
        for x in rows:
            if not isinstance(x, dict) or str(x.get("status", "")).upper() != "TRADING":
                continue
            symbol = str(x.get("symbol", "")).upper()
            if not symbol.endswith("USDT"):
                continue
            universe.append({"symbol": symbol, "name": symbol, "market": "crypto", "asset_type": "crypto",
                             "venue": "bybit", "currency": "USDT",
                             "metadata": {"base": x.get("baseCoin") or symbol[:-4], "contract_type": "PERPETUAL",
                                          "market_type": "linear", "provider": "bybit"}})
            t = ticker_map.get(symbol, {})
            if t.get("lastPrice"):
                quotes[symbol] = self._quote_bybit(t)
        return universe, quotes

    async def candles(self, symbol: str, interval: str = "15m", limit: int = 300) -> tuple[list[dict[str, Any]], str, list[dict[str, Any]]]:
        if interval not in self.INTERVALS:
            raise ValueError(f"unsupported interval {interval}")
        raw = self.normalize(symbol)
        limit = max(10, min(limit, 1500))
        errors: list[dict[str, Any]] = []
        for provider in self.providers:
            try:
                bars = await self._candles_provider(provider, raw, interval, limit)
                if bars:
                    return bars, provider.name, errors
                errors.append({"provider": provider.name, "reason": "empty candles"})
            except Exception as exc:
                errors.append({"provider": provider.name, "reason": str(exc)})
        return [], "unavailable", errors

    async def _candles_provider(self, p: CryptoProviderSpec, raw: str, interval: str, limit: int):
        if p.name == "binance":
            data = await self._call(p, "/fapi/v1/klines", {"symbol": raw, "interval": interval, "limit": limit})
            return [self._bar(x) for x in data if isinstance(x, list) and len(x) >= 7]
        if p.name == "okx":
            bar = {"1m":"1m","3m":"3m","5m":"5m","15m":"15m","30m":"30m","1h":"1H","2h":"2H","4h":"4H","6h":"6H","8h":"8H","12h":"12H","1d":"1D","3d":"3D","1w":"1W"}[interval]
            data = await self._call(p, "/api/v5/market/candles", {"instId": self.okx_inst(raw), "bar": bar, "limit": min(limit, 300)})
            return list(reversed([{"open_time": int(x[0]), "open": float(x[1]), "high": float(x[2]), "low": float(x[3]), "close": float(x[4]), "volume": float(x[5]), "close_time": int(x[0])} for x in (data.get("data", []) if isinstance(data, dict) else []) if isinstance(x, list) and len(x) >= 6]))
        iv = {"1m":"1","3m":"3","5m":"5","15m":"15","30m":"30","1h":"60","2h":"120","4h":"240","6h":"360","8h":"480","12h":"720","1d":"D","3d":"D","1w":"W"}[interval]
        data = await self._call(p, "/v5/market/kline", {"category":"linear", "symbol":raw, "interval":iv, "limit":min(limit,1000)})
        rows = ((data.get("result") or {}).get("list") or []) if isinstance(data, dict) else []
        return list(reversed([{"open_time": int(x[0]), "open": float(x[1]), "high": float(x[2]), "low": float(x[3]), "close": float(x[4]), "volume": float(x[5]), "close_time": int(x[0])} for x in rows if isinstance(x, list) and len(x) >= 6]))

    async def terminal(self, symbol: str, interval: str = "15m", depth_limit: int = 20, trade_limit: int = 20) -> dict[str, Any]:
        raw = self.normalize(symbol)
        if interval not in self.INTERVALS:
            raise ValueError("unsupported interval")
        depth_limit = max(5, min(depth_limit, 100))
        trade_limit = max(5, min(trade_limit, 100))
        errors = []
        for provider in self.providers:
            try:
                snapshot = await self._terminal_provider(provider, raw, interval, depth_limit, trade_limit)
                if snapshot and snapshot.get("quote", {}).get("last_price") is not None:
                    snapshot["provider_attempt_errors"] = errors
                    return snapshot
                errors.append({"provider": provider.name, "reason": "terminal quote unavailable"})
            except Exception as exc:
                errors.append({"provider": provider.name, "reason": str(exc)})
        raise RuntimeError("crypto terminal unavailable: " + "; ".join(f"{x['provider']}: {x['reason']}" for x in errors))

    async def _terminal_provider(self, p: CryptoProviderSpec, raw: str, interval: str, depth_limit: int, trade_limit: int) -> dict[str, Any]:
        now = int(time.time() * 1000)
        if p.name == "binance":
            data = await self._parallel(p, {
                "ticker": ("/fapi/v1/ticker/24hr", {"symbol": raw}),
                "book": ("/fapi/v1/ticker/bookTicker", {"symbol": raw}),
                "depth": ("/fapi/v1/depth", {"symbol": raw, "limit": depth_limit}),
                "trades": ("/fapi/v1/trades", {"symbol": raw, "limit": trade_limit}),
                "premium": ("/fapi/v1/premiumIndex", {"symbol": raw}),
                "klines": ("/fapi/v1/klines", {"symbol": raw, "interval": interval, "limit": 180}),
            })
            ticker = data.get("ticker") if isinstance(data.get("ticker"), dict) else {}
            book = data.get("book") if isinstance(data.get("book"), dict) else {}
            depth = data.get("depth") if isinstance(data.get("depth"), dict) else {}
            trades = data.get("trades") if isinstance(data.get("trades"), list) else []
            premium = data.get("premium") if isinstance(data.get("premium"), dict) else {}
            klines = data.get("klines") if isinstance(data.get("klines"), list) else []
            if not isinstance(ticker, dict) or not ticker.get("symbol"):
                return {}
            return self._terminal_result(raw, "Binance USD-M Futures", "USD-M", now,
                {"last_price": self._float(ticker.get("lastPrice")), "price_change": self._float(ticker.get("priceChange")), "change_pct": self._float(ticker.get("priceChangePercent")), "high_24h": self._float(ticker.get("highPrice")), "low_24h": self._float(ticker.get("lowPrice")), "volume": self._float(ticker.get("volume")), "quote_volume": self._float(ticker.get("quoteVolume")), "trades": int(ticker.get("count", 0) or 0), "data_time": ticker.get("closeTime")},
                {"mark_price": self._float(premium.get("markPrice")), "index_price": self._float(premium.get("indexPrice")), "funding_rate": self._float(premium.get("lastFundingRate")), "next_funding_time": premium.get("nextFundingTime"), "data_time": premium.get("time")},
                {"bid": self._float(book.get("bidPrice")), "bid_size": self._float(book.get("bidQty")), "ask": self._float(book.get("askPrice")), "ask_size": self._float(book.get("askQty")), "data_time": book.get("time")},
                {"last_update_id": depth.get("lastUpdateId") if isinstance(depth, dict) else None, "bids": self._levels(depth.get("bids", []) if isinstance(depth, dict) else []), "asks": self._levels(depth.get("asks", []) if isinstance(depth, dict) else [])},
                self._trades_binance(trades), self._candles_binance(klines))

        inst = self.okx_inst(raw) if p.name == "okx" else raw
        if p.name == "okx":
            bar = {"1m":"1m","3m":"3m","5m":"5m","15m":"15m","30m":"30m","1h":"1H","2h":"2H","4h":"4H","6h":"6H","8h":"8H","12h":"12H","1d":"1D","3d":"3D","1w":"1W"}[interval]
            data = await self._parallel(p, {
                "ticker": ("/api/v5/market/ticker", {"instId": inst}), "mark": ("/api/v5/public/mark-price", {"instType":"SWAP","instId":inst}),
                "book": ("/api/v5/market/books", {"instId":inst,"sz":depth_limit}), "trades": ("/api/v5/market/trades", {"instId":inst,"limit":trade_limit}),
                "candles": ("/api/v5/market/candles", {"instId":inst,"bar":bar,"limit":180}),
            })
            t = self._first(data.get("ticker")); m = self._first(data.get("mark")); b = self._first(data.get("book"))
            if not t.get("last"): return {}
            bids = b.get("bids", []) if isinstance(b, dict) else []; asks = b.get("asks", []) if isinstance(b, dict) else []
            return self._terminal_result(raw, "OKX SWAP public market data", "SWAP", now,
                {"last_price":self._float(t.get("last")),"price_change":self._pct_change(t.get("last"),t.get("open24h")),"change_pct":self._pct(t.get("last"),t.get("open24h")),"high_24h":self._float(t.get("high24h")),"low_24h":self._float(t.get("low24h")),"volume":self._float(t.get("vol24h")),"quote_volume":self._float(t.get("volCcy24h")),"trades":None,"data_time":self._int(t.get("ts"))},
                {"mark_price":self._float(m.get("markPx")),"index_price":None,"funding_rate":None,"next_funding_time":None,"data_time":self._int(m.get("ts"))},
                {"bid":self._level_value(bids,0),"bid_size":self._level_value(bids,1),"ask":self._level_value(asks,0),"ask_size":self._level_value(asks,1),"data_time":self._int(b.get("ts"))},
                {"last_update_id":None,"bids":self._levels(bids),"asks":self._levels(asks)}, self._trades_okx(data.get("trades")), self._candles_okx(data.get("candles")))

        data = await self._parallel(p, {
            "ticker": ("/v5/market/tickers", {"category":"linear","symbol":raw}), "mark": ("/v5/market/tickers", {"category":"linear","symbol":raw}),
            "book": ("/v5/market/orderbook", {"category":"linear","symbol":raw,"limit":depth_limit}), "trades": ("/v5/market/recent-trade", {"category":"linear","symbol":raw,"limit":trade_limit}),
            "candles": ("/v5/market/kline", {"category":"linear","symbol":raw,"interval":self._bybit_interval(interval),"limit":180}),
        })
        t = self._first(((data.get("ticker") or {}).get("result",{}).get("list",[])) if isinstance(data.get("ticker"),dict) else [])
        b = self._first(((data.get("book") or {}).get("result",{}).get("b",[])) if isinstance(data.get("book"),dict) else [])
        if not t.get("lastPrice"): return {}
        result_book = data.get("book") or {}; book_result = result_book.get("result",{}) if isinstance(result_book,dict) else {}
        return self._terminal_result(raw, "Bybit Linear public market data", "linear", now,
            {"last_price":self._float(t.get("lastPrice")),"price_change":self._pct_change(t.get("lastPrice"),t.get("prevPrice24h")),"change_pct":self._pct(t.get("lastPrice"),t.get("prevPrice24h")),"high_24h":self._float(t.get("highPrice24h")),"low_24h":self._float(t.get("lowPrice24h")),"volume":self._float(t.get("volume24h")),"quote_volume":self._float(t.get("turnover24h")),"trades":None,"data_time":self._int(t.get("time"))},
            {"mark_price":self._float(t.get("markPrice")),"index_price":self._float(t.get("indexPrice")),"funding_rate":self._float(t.get("fundingRate")),"next_funding_time":self._int(t.get("nextFundingTime")),"data_time":self._int(t.get("time"))},
            {"bid":self._float(b.get("price")),"bid_size":self._float(b.get("size")),"ask":self._float(book_result.get("a",[[None,None]])[0][0] if book_result.get("a") else None),"ask_size":self._float(book_result.get("a",[[None,None]])[0][1] if book_result.get("a") else None),"data_time":self._int(book_result.get("ts"))},
            {"last_update_id":None,"bids":self._levels_bybit(book_result.get("b",[])),"asks":self._levels_bybit(book_result.get("a",[]))}, self._trades_bybit(data.get("trades")), self._candles_bybit(data.get("candles")))

    async def derivatives(self, symbol: str, period: str = "1h") -> dict[str, Any]:
        if period not in self.PERIODS:
            raise ValueError(f"unsupported period {period}")
        raw = self.normalize(symbol)
        errors = []
        for provider in self.providers:
            try:
                result = await self._derivatives_provider(provider, raw, period)
                if result.get("available"):
                    result["provider_attempt_errors"] = errors
                    return result
                errors.append({"provider":provider.name,"reason":"derivatives unavailable"})
            except Exception as exc:
                errors.append({"provider":provider.name,"reason":str(exc)})
        return {"symbol":raw,"provider":"unavailable","available":False,"read_only":True,"analysis_only":True,"provider_attempt_errors":errors,
                "funding":{"latest":None,"history":[]},"open_interest":{"latest":None,"history":[],"latest_history":None},"mark_index":None,
                "long_short":{"latest":None,"history":[]},"taker_flow":{"latest":None,"history":[]},"basis":{"latest":None,"history":[]},"liquidations":{"latest":None,"history":[]},
                "capabilities":{"funding_rate":False,"open_interest":False,"mark_index":False,"long_short_ratio":False,"taker_flow":False,"basis":False,"liquidations":False}}

    async def _derivatives_provider(self, p: CryptoProviderSpec, s: str, period: str) -> dict[str, Any]:
        if p.name == "binance":
            data = await self._parallel(p, {
                "premium":("/fapi/v1/premiumIndex",{"symbol":s}), "open_interest":("/fapi/v1/openInterest",{"symbol":s}),
                "funding_history":("/fapi/v1/fundingRate",{"symbol":s,"limit":30}), "long_short":("/futures/data/globalLongShortAccountRatio",{"symbol":s,"period":period,"limit":30}),
                "oi_history":("/futures/data/openInterestHist",{"symbol":s,"period":period,"limit":30}), "taker_flow":("/futures/data/takerlongshortRatio",{"symbol":s,"period":period,"limit":30}),
                "basis":("/futures/data/basis",{"pair":s,"contractType":"PERPETUAL","period":period,"limit":30}), "liquidations":("/fapi/v1/allForceOrders",{"symbol":s,"limit":50}),
            })
            premium = data.get("premium") if isinstance(data.get("premium"),dict) else {}; oi=data.get("open_interest") if isinstance(data.get("open_interest"),dict) else {}
            p = {"available":bool(premium.get("markPrice")),"mark_price":self._float(premium.get("markPrice")),"index_price":self._float(premium.get("indexPrice")),"last_funding_rate":self._float(premium.get("lastFundingRate")),"next_funding_time":premium.get("nextFundingTime"),"time":premium.get("time")}
            o = {"available":bool(oi.get("openInterest")),"open_interest":self._float(oi.get("openInterest")),"time":oi.get("time")}
            return self._derivatives_result(s, "Binance USD-M public market data", p, o, data)
        if p.name == "okx":
            inst=self.okx_inst(s)
            data=await self._parallel(p,{"ticker":("/api/v5/market/ticker",{"instId":inst}),"funding":("/api/v5/public/funding-rate",{"instId":inst}),"oi":("/api/v5/public/open-interest",{"instType":"SWAP","instId":inst}),"funding_history":("/api/v5/public/funding-rate-history",{"instId":inst,"limit":30})})
            t=self._first(data.get("ticker")); f=self._first(data.get("funding")); o=self._first(data.get("oi")); fh=data.get("funding_history")
            p={"available":bool(t.get("last")),"mark_price":self._float(t.get("last")),"index_price":None,"last_funding_rate":self._float(f.get("fundingRate")),"next_funding_time":self._int(f.get("fundingTime")),"time":self._int(t.get("ts"))}
            oi={"available":bool(o.get("oi")),"open_interest":self._float(o.get("oi")),"time":self._int(o.get("ts"))}
            return self._derivatives_result(s,"OKX SWAP public derivatives",p,oi,{"funding_history":fh})
        data=await self._parallel(p,{"ticker":("/v5/market/tickers",{"category":"linear","symbol":s}),"funding":("/v5/market/funding/history",{"category":"linear","symbol":s,"limit":30}),"oi":("/v5/market/open-interest",{"category":"linear","symbol":s,"intervalTime":period,"limit":30})})
        t=self._first(((data.get("ticker") or {}).get("result",{}).get("list",[])) if isinstance(data.get("ticker"),dict) else [])
        f=((data.get("funding") or {}).get("result",{}).get("list",[])) if isinstance(data.get("funding"),dict) else []
        o=((data.get("oi") or {}).get("result",{}).get("list",[])) if isinstance(data.get("oi"),dict) else []
        latest_f=self._first(f); latest_o=self._first(o)
        p={"available":bool(t.get("lastPrice")),"mark_price":self._float(t.get("markPrice")),"index_price":self._float(t.get("indexPrice")),"last_funding_rate":self._float(t.get("fundingRate")),"next_funding_time":self._int(t.get("nextFundingTime")),"time":self._int(t.get("time"))}
        oi={"available":bool(latest_o.get("openInterest")),"open_interest":self._float(latest_o.get("openInterest")),"time":self._int(latest_o.get("timestamp"))}
        return self._derivatives_result(s,"Bybit Linear public derivatives",p,oi,{"funding_history":f,"oi_history":o})

    def _derivatives_result(self,s,provider,premium,oi,data):
        funding=self._rows(data.get("funding_history"),("fundingTime","fundingRate","markPrice"),("ts","fundingRate","markPx"))
        ls=self._rows(data.get("long_short"),("timestamp","longShortRatio","longAccount","shortAccount"),())
        oi_hist=self._rows(data.get("oi_history"),("timestamp","sumOpenInterest","sumOpenInterestValue"),("timestamp","openInterest"))
        taker=self._rows(data.get("taker_flow"),("timestamp","buyVol","sellVol","buySellRatio"),())
        basis=self._rows(data.get("basis"),("timestamp","basis","basisRate","annualizedBasisRate","futuresPrice","indexPrice"),())
        liq=self._rows(data.get("liquidations"),("time","price","origQty","executedQty","averagePrice"),("time","price","qty","execQty","avgPrice"))
        return {"symbol":s,"provider":provider,"available":bool(premium.get("available") or oi.get("available")),"read_only":True,"analysis_only":True,
                "funding":{"latest":funding[-1] if funding else ({"fundingRate":premium.get("last_funding_rate")} if premium.get("last_funding_rate") is not None else None),"history":funding},
                "open_interest":{"latest":oi if oi.get("available") else None,"history":oi_hist,"latest_history":oi_hist[-1] if oi_hist else None},
                "mark_index":premium if premium.get("available") else None,
                "long_short":{"latest":ls[-1] if ls else None,"history":ls},"taker_flow":{"latest":taker[-1] if taker else None,"history":taker},
                "basis":{"latest":basis[-1] if basis else None,"history":basis},"liquidations":{"latest":liq[-1] if liq else None,"history":liq},
                "capabilities":{"funding_rate":bool(funding or premium.get("last_funding_rate") is not None),"open_interest":bool(oi.get("available") or oi_hist),"mark_index":bool(premium.get("mark_price") is not None),"long_short_ratio":bool(ls),"taker_flow":bool(taker),"basis":bool(basis),"liquidations":bool(liq)}}

    @classmethod
    def _rows(cls, rows, primary, alternate):
        if not isinstance(rows, list): return []
        fields = primary if rows and isinstance(rows[0],dict) and any(k in rows[0] for k in primary) else alternate
        out=[]
        for row in rows:
            if not isinstance(row,dict): continue
            item={}
            for f in fields:
                if f in row:
                    try: item[f]=float(row[f]) if f not in {"timestamp","fundingTime","time","ts"} else int(row[f])
                    except (TypeError,ValueError): item[f]=row[f]
            if item: out.append(item)
        return out

    @staticmethod
    def _terminal_result(symbol, provider, market_type, now, quote, mark, book, depth, trades, candles):
        return {"analysis_only":True,"read_only":True,"symbol":symbol,"provider":provider,"market_data_type":market_type,"server_time":now,"quote":quote,"mark":mark,"book":book,"depth":depth,"trades":trades,"candles":candles,
                "freshness":{"quote_ms":CryptoProviderGateway._age(now,quote.get("data_time")),"mark_ms":CryptoProviderGateway._age(now,mark.get("data_time")),"book_ms":CryptoProviderGateway._age(now,book.get("data_time")),"status":"live" if CryptoProviderGateway._age(now,quote.get("data_time")) is not None and CryptoProviderGateway._age(now,quote.get("data_time")) < 15000 else "stale"}}

    @staticmethod
    def _first(value):
        if isinstance(value,list): return value[0] if value and isinstance(value[0],dict) else {}
        if isinstance(value,dict):
            data=value.get("data")
            if isinstance(data,list) and data and isinstance(data[0],dict): return data[0]
        return {}

    @staticmethod
    def _float(v):
        try: return float(v) if v not in (None,"") else None
        except (TypeError,ValueError): return None

    @staticmethod
    def _int(v):
        try: return int(v) if v not in (None,"") else None
        except (TypeError,ValueError): return None

    @staticmethod
    def _pct(last, prev):
        a,b=CryptoProviderGateway._float(last),CryptoProviderGateway._float(prev)
        return (a-b)/b*100 if a is not None and b else None

    @staticmethod
    def _pct_change(last, prev):
        a,b=CryptoProviderGateway._float(last),CryptoProviderGateway._float(prev)
        return a-b if a is not None and b is not None else None

    @staticmethod
    def _age(now, ts):
        try: return max(0,now-int(ts)) if ts is not None else None
        except (TypeError,ValueError): return None

    @classmethod
    def _levels(cls, rows):
        out=[]
        for row in rows if isinstance(rows,list) else []:
            if isinstance(row,list) and len(row)>=2:
                p,q=cls._float(row[0]),cls._float(row[1])
                if p is not None and q is not None: out.append({"price":p,"qty":q})
        return out

    @classmethod
    def _levels_bybit(cls, rows): return cls._levels(rows)

    @classmethod
    def _level_value(cls, rows, index):
        if not rows or not isinstance(rows[0],list) or len(rows[0])<=index: return None
        return cls._float(rows[0][index])

    @classmethod
    def _trades_binance(cls, rows):
        return [{"id":r.get("id"),"price":cls._float(r.get("price")),"qty":cls._float(r.get("qty")),"buyer_maker":r.get("isBuyerMaker"),"time":r.get("time")} for r in rows if isinstance(r,dict)] if isinstance(rows,list) else []

    @classmethod
    def _trades_okx(cls, value):
        rows=value.get("data",[]) if isinstance(value,dict) else []
        return [{"id":r.get("tradeId"),"price":cls._float(r.get("px")),"qty":cls._float(r.get("sz")),"buyer_maker":str(r.get("side","")).lower()=="sell","time":cls._int(r.get("ts"))} for r in rows if isinstance(r,dict)]

    @classmethod
    def _trades_bybit(cls, value):
        rows=((value or {}).get("result",{}).get("list",[])) if isinstance(value,dict) else []
        return [{"id":r.get("execId"),"price":cls._float(r.get("price")),"qty":cls._float(r.get("size")),"buyer_maker":str(r.get("side","")).lower()=="sell","time":cls._int(r.get("time"))} for r in rows if isinstance(r,dict)]

    @classmethod
    def _candles_binance(cls, rows):
        return [{"open_time":r[0],"open":cls._float(r[1]),"high":cls._float(r[2]),"low":cls._float(r[3]),"close":cls._float(r[4]),"volume":cls._float(r[5]),"close_time":r[6]} for r in rows if isinstance(r,list) and len(r)>=7] if isinstance(rows,list) else []

    @classmethod
    def _candles_okx(cls, value):
        rows=value.get("data",[]) if isinstance(value,dict) else []
        return list(reversed([{"open_time":cls._int(r[0]),"open":cls._float(r[1]),"high":cls._float(r[2]),"low":cls._float(r[3]),"close":cls._float(r[4]),"volume":cls._float(r[5]),"close_time":cls._int(r[0])} for r in rows if isinstance(r,list) and len(r)>=6]))

    @classmethod
    def _candles_bybit(cls, value):
        rows=((value or {}).get("result",{}).get("list",[])) if isinstance(value,dict) else []
        return list(reversed([{"open_time":cls._int(r[0]),"open":cls._float(r[1]),"high":cls._float(r[2]),"low":cls._float(r[3]),"close":cls._float(r[4]),"volume":cls._float(r[5]),"close_time":cls._int(r[0])} for r in rows if isinstance(r,list) and len(r)>=6]))

    @staticmethod
    def _bybit_interval(interval):
        return {"1m":"1","3m":"3","5m":"5","15m":"15","30m":"30","1h":"60","2h":"120","4h":"240","6h":"360","8h":"480","12h":"720","1d":"D","3d":"D","1w":"W"}[interval]

    @staticmethod
    def _bar(x):
        return {"open_time":int(x[0]),"open":float(x[1]),"high":float(x[2]),"low":float(x[3]),"close":float(x[4]),"volume":float(x[5]),"close_time":int(x[6])}

    @staticmethod
    def _quote_binance(t):
        return {"price":float(t["lastPrice"]),"previous_close":float(t.get("prevClosePrice") or t["lastPrice"]),"change_pct":float(t.get("priceChangePercent") or 0),"volume":float(t.get("volume") or 0),"quote_volume":float(t.get("quoteVolume") or 0),"source":"Binance USD-M","market_data_type":"USD-M","quote_currency":t.get("symbol","")[-4:],"pair":t.get("symbol"),"contract_type":"PERPETUAL","market_type":"futures","data_time":t.get("closeTime"),"quote_status":"live","provider":"binance"}

    @staticmethod
    def _quote_okx(t):
        last=float(t["last"]); prev=float(t.get("open24h") or last)
        return {"price":last,"previous_close":prev,"change_pct":(last-prev)/prev*100 if prev else 0.0,"volume":float(t.get("vol24h") or 0),"quote_volume":float(t.get("volCcy24h") or 0),"source":"OKX SWAP","market_data_type":"SWAP","quote_currency":"USDT","pair":t.get("instId"),"contract_type":"PERPETUAL","market_type":"SWAP","data_time":int(t.get("ts")) if str(t.get("ts","")).isdigit() else None,"quote_status":"live","provider":"okx"}

    @staticmethod
    def _quote_bybit(t):
        last=float(t["lastPrice"]); prev=float(t.get("prevPrice24h") or last)
        return {"price":last,"previous_close":prev,"change_pct":(last-prev)/prev*100 if prev else 0.0,"volume":float(t.get("volume24h") or 0),"quote_volume":float(t.get("turnover24h") or 0),"source":"Bybit Linear","market_data_type":"linear","quote_currency":"USDT","pair":t.get("symbol"),"contract_type":"PERPETUAL","market_type":"linear","data_time":int(t.get("time")) if str(t.get("time","")).isdigit() else None,"quote_status":"live","provider":"bybit"}


crypto_gateway = CryptoProviderGateway()
