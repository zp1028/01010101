"""Compatibility wrapper for the unified crypto provider gateway."""
from __future__ import annotations
from typing import Any
from app.services.crypto_provider_gateway import crypto_gateway

SUPPORTED_INTERVALS = crypto_gateway.INTERVALS

async def fetch_binance_klines(symbol: str, interval: str = "15m", limit: int = 200) -> list[dict[str, Any]]:
    bars, provider, errors = await crypto_gateway.candles(symbol, interval, limit)
    if not bars:
        reason = "; ".join(f"{x['provider']}: {x['reason']}" for x in errors) or "no provider available"
        raise RuntimeError(f"crypto candles unavailable: {reason}")
    return bars
