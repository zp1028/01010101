"""Unified analysis-only OHLCV provider for crypto, US/HK equities and commodities."""
from __future__ import annotations
import time
from typing import Any
import httpx
from app.data.klines import SUPPORTED_INTERVALS
from app.services.crypto_provider_gateway import crypto_gateway

YAHOO_CHART = "https://query1.finance.yahoo.com/v8/finance/chart/{symbol}"
YAHOO_INTERVALS = {"1m":"1m","3m":"5m","5m":"5m","15m":"15m","30m":"30m","1h":"1h","1d":"1d","1w":"1wk"}

def yahoo_symbol(symbol: str, market: str) -> str:
    raw=symbol.strip().upper()
    if market == "commodities": return raw if raw.endswith("=F") else raw+"=F"
    if market == "hk":
        if raw.endswith(".HK"): return raw
        return raw.zfill(4)+".HK"
    return raw

async def fetch_yahoo_klines(symbol: str, market: str, interval: str, limit: int=300) -> list[dict[str,Any]]:
    if interval not in SUPPORTED_INTERVALS: raise ValueError(f"unsupported interval {interval}")
    # Yahoo intraday limits are provider-specific. Request a safe range and let the API cap it.
    yint=YAHOO_INTERVALS.get(interval)
    if yint:
        ranges={"1m":"7d","5m":"60d","15m":"60d","30m":"60d","1h":"730d","1d":"10y","1w":"20y"}
        params={"interval":yint,"range":ranges.get(yint,"2y"),"includePrePost":"true","events":"div,splits"}
        async with httpx.AsyncClient(timeout=20,headers={"User-Agent":"SmartTrader/1.0 analysis"}) as client:
            r=await client.get(YAHOO_CHART.format(symbol=yahoo_symbol(symbol,market)),params=params); r.raise_for_status(); data=r.json()
        result=(data.get("chart") or {}).get("result") or []
        if not result: raise ValueError("provider returned no chart data")
        res=result[0]; q=(res.get("indicators") or {}).get("quote") or [{}]; q=q[0]
        ts=res.get("timestamp") or []; opens=q.get("open") or []; highs=q.get("high") or []; lows=q.get("low") or []; closes=q.get("close") or []; vols=q.get("volume") or []
        bars=[]
        for i,t in enumerate(ts):
            if i>=len(closes) or closes[i] is None: continue
            bars.append({"open_time":int(t*1000),"open":float(opens[i] if opens[i] is not None else closes[i]),"high":float(highs[i] if highs[i] is not None else closes[i]),"low":float(lows[i] if lows[i] is not None else closes[i]),"close":float(closes[i]),"volume":float(vols[i] or 0),"close_time":int(t*1000)})
        return bars[-max(10,min(limit,1500)):]
    # Aggregate from hourly Yahoo bars for 2h/4h/6h/12h.
    base=await fetch_yahoo_klines(symbol,market,"1h",min(1500,limit*12))
    hours={"2h":2,"4h":4,"6h":6,"12h":12}[interval]; out=[]
    bucket=[]
    for b in base:
        bucket.append(b)
        if len(bucket)==hours:
            out.append({"open_time":bucket[0]["open_time"],"open":bucket[0]["open"],"high":max(x["high"] for x in bucket),"low":min(x["low"] for x in bucket),"close":bucket[-1]["close"],"volume":sum(x["volume"] for x in bucket),"close_time":bucket[-1]["close_time"]}); bucket=[]
    return out[-limit:]

async def fetch_market_klines(symbol: str, market: str|None, interval: str="15m", limit: int=300):
    m=(market or "").lower()
    raw=symbol.upper().replace("/","").replace("-","")
    if not m:
        if raw.endswith("USDT") or raw.endswith("USDC"): m="crypto"
        elif raw.endswith("=F"): m="commodities"
        elif raw.endswith(".HK") or raw.isdigit(): m="hk"
        else: m="us"
    if m=="crypto":
        bars, provider, errors = await crypto_gateway.candles(raw, interval, limit)
        if not bars:
            reason = "; ".join(f"{x['provider']}: {x['reason']}" for x in errors) or "no crypto provider available"
            raise RuntimeError(f"crypto candles unavailable: {reason}")
        return bars
    return await fetch_yahoo_klines(symbol,m,interval,limit)
