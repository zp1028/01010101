import pytest

from app.services.crypto_provider_gateway import CryptoProviderGateway


@pytest.mark.asyncio
async def test_discovery_fails_over_without_mixing_provider_data(monkeypatch):
    gateway = CryptoProviderGateway(providers=["binance", "okx", "bybit"])

    async def fake(provider):
        if provider.name == "binance":
            raise RuntimeError("HTTP 451")
        return ([{"symbol": "BTCUSDT", "name": "BTC-USDT-SWAP", "venue": provider.name, "currency": "USDT", "metadata": {"provider": provider.name}}],
                {"BTCUSDT": {"price": 123.0, "provider": provider.name}})

    monkeypatch.setattr(gateway, "_discover_provider", fake)
    universe, quotes, errors = await gateway.discover()
    assert universe[0]["venue"] == "okx"
    assert quotes["BTCUSDT"]["provider"] == "okx"
    assert errors[0]["provider"] == "binance"


@pytest.mark.asyncio
async def test_candles_failover_preserves_selected_provider(monkeypatch):
    gateway = CryptoProviderGateway(providers=["binance", "bybit"])

    async def fake(provider, raw, interval, limit):
        if provider.name == "binance":
            raise TimeoutError("dns timeout")
        return [{"open_time": 1, "open": 1.0, "high": 2.0, "low": 0.5, "close": 1.5, "volume": 10.0, "close_time": 2}]

    monkeypatch.setattr(gateway, "_candles_provider", fake)
    bars, provider, errors = await gateway.candles("BTCUSDT", "15m", 20)
    assert provider == "bybit"
    assert bars[0]["close"] == 1.5
    assert errors[0]["provider"] == "binance"

@pytest.mark.asyncio
async def test_terminal_failover_returns_selected_provider(monkeypatch):
    gateway = CryptoProviderGateway(providers=["binance", "okx"])

    async def fake(provider, raw, interval, depth_limit, trade_limit):
        if provider.name == "binance":
            raise RuntimeError("HTTP 451")
        return {
            "analysis_only": True,
            "symbol": raw,
            "provider": "OKX SWAP public market data",
            "quote": {"last_price": 100.0, "data_time": 123},
            "mark": {}, "book": {}, "depth": {}, "trades": [], "candles": {},
        }

    monkeypatch.setattr(gateway, "_terminal_provider", fake)
    out = await gateway.terminal("BTC/USDT", "15m")
    assert out["symbol"] == "BTCUSDT"
    assert out["provider"].startswith("OKX")
    assert out["provider_attempt_errors"][0]["provider"] == "binance"


@pytest.mark.asyncio
async def test_derivatives_failover_preserves_truthful_capabilities(monkeypatch):
    gateway = CryptoProviderGateway(providers=["binance", "bybit"])

    async def fake(provider, raw, period):
        if provider.name == "binance":
            raise TimeoutError("dns timeout")
        return {
            "symbol": raw, "provider": "Bybit Linear public derivatives", "available": True,
            "read_only": True, "analysis_only": True,
            "funding": {"latest": {"fundingRate": 0.001}, "history": []},
            "open_interest": {"latest": {"open_interest": 10.0}, "history": [], "latest_history": None},
            "mark_index": {"available": True, "mark_price": 100.0, "index_price": 99.9, "last_funding_rate": 0.001},
            "long_short": {"latest": None, "history": []}, "taker_flow": {"latest": None, "history": []},
            "basis": {"latest": None, "history": []}, "liquidations": {"latest": None, "history": []},
            "capabilities": {"funding_rate": True, "open_interest": True, "mark_index": True,
                              "long_short_ratio": False, "taker_flow": False, "basis": False, "liquidations": False},
        }

    monkeypatch.setattr(gateway, "_derivatives_provider", fake)
    out = await gateway.derivatives("BTCUSDT", "1h")
    assert out["provider"].startswith("Bybit")
    assert out["capabilities"]["funding_rate"] is True
    assert out["capabilities"]["liquidations"] is False
    assert out["provider_attempt_errors"][0]["provider"] == "binance"

@pytest.mark.asyncio
async def test_discovery_fails_over_when_provider_universe_has_no_quotes(monkeypatch):
    gateway = CryptoProviderGateway(providers=["binance", "okx"])

    async def fake(provider):
        if provider.name == "binance":
            return ([{"symbol": "BTCUSDT", "name": "BTCUSDT", "venue": "binance"}], {})
        return ([{"symbol": "BTCUSDT", "name": "BTC-USDT-SWAP", "venue": "okx"}],
                {"BTCUSDT": {"price": 100.0, "provider": "okx"}})

    monkeypatch.setattr(gateway, "_discover_provider", fake)
    universe, quotes, errors = await gateway.discover()
    assert universe[0]["venue"] == "okx"
    assert quotes["BTCUSDT"]["provider"] == "okx"
    assert errors[0]["reason"] == "empty quotes"
