import os

import pytest

from app.core.config import Settings
from app.services.market_universe import MarketUniverseService, UniverseItem


def test_default_symbol_configuration_is_not_hard_coded():
    settings = Settings(_env_file=None)
    assert settings.symbols == []


@pytest.mark.asyncio
async def test_crypto_universe_uses_provider_symbols(monkeypatch):
    service = MarketUniverseService()

    async def discover():
        return ([{
            "symbol": "LIVEUSDT", "name": "LIVEUSDT", "venue": "binance",
            "currency": "USDT", "metadata": {"provider": "binance"}
        }], {"LIVEUSDT": {"price": 123.0, "provider": "binance"}}, [])

    monkeypatch.setattr("app.services.market_universe.crypto_gateway.discover", discover)
    items = await service.crypto()
    symbols = {x.symbol for x in items}
    assert symbols == {"LIVEUSDT"}
    assert "BTCUSDT" not in symbols
    assert "NEWUSDT" not in symbols
