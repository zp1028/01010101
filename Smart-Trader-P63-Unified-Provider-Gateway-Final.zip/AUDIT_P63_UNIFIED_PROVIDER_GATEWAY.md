# P63 Unified Provider Gateway Audit

## 1. 目标
解决 Binance HTTP 451 / DNS / 网络不可达导致市场页 0 品种的问题，并避免“Binance universe + OKX/Bybit quote”这类跨 Provider 混配。

## 2. 统一入口
`backend/app/services/crypto_provider_gateway.py`

负责：
- universe + quotes
- OHLCV candles
- terminal snapshot
- derivatives snapshot
- provider 顺序与 failover
- provider error provenance

默认顺序：
1. Binance
2. OKX
3. Bybit

## 3. Failover 规则
Provider 只有同时返回：
- 非空交易品种 universe
- 至少一个真实 quote

才视为该 Provider 的 discovery 成功。

如果出现：
- HTTP 451
- DNS failure
- timeout
- empty universe
- empty quotes

则记录 provider error 并尝试下一个 Provider。

## 4. 数据一致性
市场列表和 quote 来自同一次 Provider discovery，不再把一个交易所的 universe 与另一个交易所的 quote 强行拼接。

K线、终端、衍生数据同样按 Provider 尝试顺序 failover，并返回实际 provider。

## 5. Truth 规则
- 不支持的字段保持 unavailable/null。
- 不使用 0、默认值或模拟价格填补 provider 缺失。
- `analysis_only=true`、`read_only=true` 保持。

## 6. Android
Android `RestClient.kt` 只调用后端 API；未发现 Binance/OKX/Bybit REST URL。

## 7. 兼容性
以下旧类名保留，避免现有调用方破坏：
- `BinanceUsdMMarketData`
- `BinanceUsdMTerminalService`
- `BinanceDerivativesService`

这些类现在都是 facade，内部调用统一 Gateway。

## 8. 自动化验证
Backend：**112 passed**。

覆盖包括：
- Binance 失败 → OKX discovery failover
- Binance timeout → Bybit candle failover
- universe 非空但 quote 为空 → fallback
- terminal provider failover
- derivatives provider failover
- legacy adapter compatibility
- cross-exchange aggregation compatibility

Android 本地 Gradle 验证受当前环境 DNS 限制，无法下载 Gradle 8.9；没有伪报成功。
