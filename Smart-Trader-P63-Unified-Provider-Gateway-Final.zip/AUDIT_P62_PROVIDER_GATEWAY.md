# Smart Trader P62 — Unified Crypto Provider Gateway / Failover Audit

## Baseline
- Input: `Smart-Trader-P61-Market-Live-Failover.zip`
- Baseline SHA-256: `51b7aa7bcd977fa5f4b9b6390381560941cad2ea983206c5dbb750d319888563`
- Scope: analysis-only market data. No order/account/paper-trading/execution API added.

## Implemented

### 1. Unified crypto provider gateway
Added `backend/app/services/crypto_provider_gateway.py`.

Provider order:
1. Binance USD-M
2. OKX SWAP
3. Bybit Linear

The gateway owns provider URLs, symbol normalization, discovery, quotes, and OHLCV failover.

### 2. Coherent market universe + quote source
`GET /api/v1/markets?market=crypto` now performs one provider discovery attempt and uses the resulting universe and quote map together.

This prevents the previous mismatch where an OKX/Bybit universe could be paired with a separate Binance quote response.

Response now exposes:
- `provider`
- `provider_errors[]`
- per-row `provider`
- per-row `quote_status`

No provider response means no synthetic price is generated.

### 3. OHLCV failover
Crypto candles now use the same gateway for:
- 5m
- 15m
- 30m
- 1h
- 4h
- 1d
- 1w
and the broader supported interval set.

Failure path is provider ordered and source-preserving.

### 4. Android provider isolation
`RestClient.kt` no longer contains direct Binance/OKX/Bybit market URLs.

Android market and candle requests now go through the Smart Trader backend gateway. This removes the previous split-brain behavior where Android could independently hit a blocked exchange endpoint after the backend had already selected another provider.

### 5. Truth / analysis-only rules preserved
- No mock prices.
- No default/fake quote substitution.
- Provider source is retained.
- Unsupported fields remain unavailable.
- No account credentials, order placement, cancellation, or execution endpoints were introduced.

## Verification
- Python `compileall`: PASS
- Backend pytest: **109 passed**
- Added gateway failover tests covering:
  - Binance HTTP 451 → OKX fallback
  - Binance timeout/DNS failure → Bybit candle fallback
  - provider source preservation
- Android Gradle compile: **not completed locally** because this runtime could not resolve `services.gradle.org` while downloading Gradle 8.9. The source was statically scanned and all direct exchange URLs were removed from Android `RestClient.kt`.

## Remaining provider-specific code
The backend still contains provider-specific adapters for terminal/derivatives and Binance WebSocket operation. These are backend-internal provider adapters; they are not exposed to Android as direct exchange URLs. The new gateway is the authoritative REST universe/quote/OHLCV path.
