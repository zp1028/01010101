# P63 Change Log — Unified Crypto Provider Gateway Completion

## 本次完成
- 将 crypto 市场列表、行情、K线、终端快照、合约衍生数据统一收口到 `CryptoProviderGateway`。
- Provider 顺序固定为 Binance → OKX → Bybit，可按实例覆盖。
- 修复“Provider 有交易对但行情为空仍被视为健康”的故障：必须同时存在 universe + live quote 才能作为成功 Provider。
- 终端快照支持 Provider 级 failover，并保留实际数据来源与失败尝试信息。
- 衍生品数据支持 Provider 级 failover；不同交易所不支持的字段保持 unavailable，不用 0/默认值伪造。
- `CryptoMultiExchangeService` 改为调用统一 Gateway 的单 Provider 实例，继续提供跨交易所对比，不再复制 REST URL。
- `BinanceUsdMMarketData`、`BinanceUsdMTerminalService`、`BinanceDerivativesService` 保留旧类名作为兼容 facade，实际实现均走统一 Gateway。
- Android `RestClient.kt` 不包含 Binance/OKX/Bybit REST URL；Android 只访问 Smart Trader 后端 API。
- 删除已无调用的 `binance_rest_url` 配置项，REST provider URL 只保留在 Gateway。
- 保留 Binance WebSocket 配置作为现有实时 WS 连接的独立基础设施；本次不把 WS 重写成 REST failover。

## Truth / Analysis-only 约束
- 仅使用公开市场数据。
- 不加入账户、钱包、模拟盘、下单、撤单或执行接口。
- Provider 失败时记录 provider + reason。
- Provider 未提供某字段时保持 `null`/unavailable。
- 终端与衍生数据返回 `analysis_only=true` / `read_only=true`。

## 验证
- Python `compileall`: PASS
- Backend pytest: **112 passed**
- Android `:app:compileDebugKotlin`: 未能启动 Gradle 构建；当前运行环境无法解析 `services.gradle.org`（`UnknownHostException`）。因此没有宣称 Android 编译通过。
- Runtime REST URL 扫描：除统一 `crypto_provider_gateway.py` 外，Backend 不再包含 Binance/OKX/Bybit REST URL；Android 源码不包含这些 provider REST URL。
