from pathlib import Path

from app.services.analysis_feedback import AnalysisFeedbackService


def test_feedback_evaluation_long_and_short(tmp_path: Path):
    svc = AnalysisFeedbackService(str(tmp_path / "feedback.json"))
    long_r = {"price_at_report": 100.0, "direction": "long"}
    assert svc._evaluate(long_r, 102.0)[0] == "validated"
    assert svc._evaluate(long_r, 98.0)[0] == "invalidated"
    short_r = {"price_at_report": 100.0, "direction": "short"}
    assert svc._evaluate(short_r, 98.0)[0] == "validated"
    assert svc._evaluate(short_r, 102.0)[0] == "invalidated"


def test_report_ids_are_immutable_and_feedback_persists(tmp_path: Path):
    svc = AnalysisFeedbackService(str(tmp_path / "feedback.json"))
    snapshot = {
        "report_id": "R-TEST", "key": "crypto:BTC/USDT:15m", "symbol": "BTC/USDT",
        "market": "crypto", "timeframe": "15m", "generated_at": 1,
        "price_at_report": 100.0, "direction": "long", "confidence": .8,
        "state": "tracking", "summary": "test", "narrative": "",
        "feedback": {"state": "waiting", "summary": "waiting", "evaluated_at": 1},
    }
    svc._reports[snapshot["report_id"]] = snapshot
    out = svc.feedback_for("BTC/USDT", "crypto", "15m", 102.0)
    assert out["history"][0]["report_id"] == "R-TEST"
    assert out["history"][0]["feedback_state"] == "validated"
    assert svc._reports["R-TEST"]["summary"] == "test"
