package com.smarttrader.app.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.smarttrader.app.data.MarketItem
import com.smarttrader.app.data.MarketCache
import com.smarttrader.app.data.SignalItem
import com.smarttrader.app.data.Watchlist
import com.smarttrader.app.network.AdviceDto
import com.smarttrader.app.network.ApiConfig
import com.smarttrader.app.network.IndicatorDto
import com.smarttrader.app.network.InstrumentAnalysisSnapshotDto
import com.smarttrader.app.network.LiveAttention
import com.smarttrader.app.network.LiveSignal
import com.smarttrader.app.network.LiveTick
import com.smarttrader.app.network.MultiTimeframeDto
import com.smarttrader.app.network.ReportCatalogItemDto
import com.smarttrader.app.network.ReportResultDto
import com.smarttrader.app.network.UnifiedReportDto
import com.smarttrader.app.network.CandleDto
import com.smarttrader.app.network.MarketWsClient
import com.smarttrader.app.network.RestClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.DecimalFormat

class AppState : ViewModel() {
    private val cached = MarketCache.load()
    var markets by mutableStateOf(cached.first)
    var marketCategory by mutableStateOf("crypto")
        private set
    var signals by mutableStateOf<List<SignalItem>>(emptyList())
        private set
    var connectionStatus by mutableStateOf("未连接后端")
        private set
    var backendOnline by mutableStateOf(false)
        private set
    var live by mutableStateOf(false)
        private set
    var loading by mutableStateOf(false)
        private set
    var errorMessage by mutableStateOf<String?>(null)
    var cacheSavedAt by mutableStateOf(cached.second)
        private set

    var selectedSymbol by mutableStateOf<String?>(null)
        private set
    var timeframe by mutableStateOf("15m")
        private set
    var indicator by mutableStateOf<IndicatorDto?>(null)
        private set
    var advice by mutableStateOf<AdviceDto?>(null)
        private set
    var detailLoading by mutableStateOf(false)
        private set
    var multiTimeframe by mutableStateOf<MultiTimeframeDto?>(null)
        private set
    var lastAnalysisRefreshAt by mutableStateOf(0L)
        private set
    var unifiedReport by mutableStateOf<UnifiedReportDto?>(null)
    var instrumentAnalysisSnapshot by mutableStateOf<InstrumentAnalysisSnapshotDto?>(null)
    var candles by mutableStateOf<List<CandleDto>>(emptyList())
        private set
    var derivatives by mutableStateOf<com.smarttrader.app.network.DerivativesDto?>(null)
        private set
    var multiExchange by mutableStateOf<com.smarttrader.app.network.MultiExchangeDto?>(null)
        private set
    var marketSearch by mutableStateOf("")
    var marketSort by mutableStateOf("change")
    var marketView by mutableStateOf("table")
    var marketFilter by mutableStateOf("all")
    var hasMoreMarkets by mutableStateOf(false)
        private set
    var loadingMoreMarkets by mutableStateOf(false)
        private set
    var favorites by mutableStateOf<Set<String>>(emptySet())
        private set
    var reportCatalog by mutableStateOf<List<ReportCatalogItemDto>>(emptyList())
        private set
    var selectedReport by mutableStateOf<ReportResultDto?>(null)
        private set
    var reportLoading by mutableStateOf(false)
        private set
    var analysisFeed by mutableStateOf<com.smarttrader.app.network.AnalysisFeedDto?>(null)
        private set
    var analysisFeedback by mutableStateOf<com.smarttrader.app.network.AnalysisFeedbackDto?>(null)
        private set

    private var detailRefreshJob: Job? = null
    private var ws: MarketWsClient? = null
    private val priceFmt = DecimalFormat("#,##0.####")

    init {
        checkBackend()
        loadUniverse("crypto")
        favorites = MarketCache.loadFavorites()
        loadReportCatalog()
        loadAnalysisFeed()
    }

    fun checkBackend() {
        viewModelScope.launch {
            loading = true
            val ok = RestClient.health()
            backendOnline = ok
            connectionStatus = if (ok) "后端在线 ${ApiConfig.baseUrl}" else if (cacheSavedAt > 0L) "后端离线 · 显示最近缓存" else "后端离线 · ${ApiConfig.baseUrl}"
            loading = false
        }
    }

    fun loadUniverse(category: String, query: String? = null) {
        marketCategory = category
        marketSearch = query ?: marketSearch
        viewModelScope.launch {
            RestClient.fetchMarketsPage(category, query, 250, 0).onSuccess { page ->
                markets = page.items
                hasMoreMarkets = page.hasMore
            }
            if (query.isNullOrBlank()) loadAnalysisFeed(category)
        }
    }

    fun loadMoreMarkets() {
        if (loadingMoreMarkets || !hasMoreMarkets) return
        loadingMoreMarkets = true
        val category = marketCategory
        val query = marketSearch.ifBlank { null }
        viewModelScope.launch {
            RestClient.fetchMarketsPage(category, query, 250, markets.size).onSuccess { page ->
                val existing = markets.map { it.symbol }.toHashSet()
                markets = markets + page.items.filterNot { it.symbol in existing }
                hasMoreMarkets = page.hasMore
            }
            loadingMoreMarkets = false
        }
    }

    fun toggleFavorite(symbol: String) {
        favorites = if (symbol in favorites) favorites - symbol else favorites + symbol
        MarketCache.saveFavorites(favorites)
    }

    fun openDetail(symbol: String, market: String? = null) {
        selectedSymbol = symbol
        if (!market.isNullOrBlank()) marketCategory = market.lowercase()
        loadDetail(symbol, timeframe)
    }

    fun closeDetail() {
        selectedSymbol = null
        detailRefreshJob?.cancel()
        detailRefreshJob = null
        indicator = null
        multiTimeframe = null
        advice = null
        unifiedReport = null
        instrumentAnalysisSnapshot = null
        candles = emptyList()
        derivatives = null
        multiExchange = null
        selectedReport = null
        analysisFeedback = null
        errorMessage = null
    }

    fun setTimeframe(tf: String) {
        timeframe = tf
        selectedSymbol?.let { loadDetail(it, tf) }
    }

    fun loadDetail(symbol: String, tf: String) {
        detailRefreshJob?.cancel()
        detailRefreshJob = viewModelScope.launch {
            var adviceCounter = 0
            while (isActive && selectedSymbol == symbol && timeframe == tf) {
                refreshDetail(symbol, tf, first = adviceCounter == 0)
                adviceCounter = (adviceCounter + 1) % 4
                delay(15_000L)
            }
        }
    }

    private suspend fun refreshDetail(symbol: String, tf: String, first: Boolean) {
        detailLoading = first
        if (first) errorMessage = null
        val unified = RestClient.fetchUnifiedReport(symbol, tf, marketCategory)
        val instrumentSnapshot = RestClient.fetchInstrumentAnalysisSnapshot(symbol, tf, marketCategory)
        val ind = RestClient.fetchIndicators(symbol, tf, marketCategory)
        val mtf = RestClient.fetchMultiTimeframe(symbol, tf, marketCategory)
        val candleResult = RestClient.fetchCandles(symbol, tf, marketCategory, 180)
        val adv = if (first) RestClient.fetchAdvice(symbol, tf, marketCategory) else Result.success(advice)
        val derivativesResult = if (marketCategory == "crypto") RestClient.fetchDerivatives(symbol, if (tf == "1w") "1d" else tf) else Result.success(null)
        val exchangeResult = if (marketCategory == "crypto") RestClient.fetchMultiExchange(symbol) else Result.success(null)
        val manifest = if (first) RestClient.fetchInstrumentReportManifest(symbol, tf, marketCategory) else Result.success(reportCatalog)
        val feedback = RestClient.fetchAnalysisFeedback(symbol, marketCategory, tf)
        unified.onSuccess { unifiedReport = it }.onFailure { if (first) errorMessage = "统一报告: ${it.message}" }
        instrumentSnapshot.onSuccess { instrumentAnalysisSnapshot = it }.onFailure { if (first) errorMessage = listOfNotNull(errorMessage, "数据能力: ${it.message}").joinToString(" / ") }
        ind.onSuccess {
            indicator = it
            it.lastPrice?.let { px -> markets = markets.map { m -> if (m.symbol == symbol) m.copy(price = priceFmt.format(px)) else m } }
        }.onFailure { if (first) errorMessage = "指标: ${it.message}" }
        candleResult.onSuccess { candles = it }.onFailure { if (first) errorMessage = listOfNotNull(errorMessage, "K线: ${it.message}").joinToString(" / ") }
        mtf.onSuccess { multiTimeframe = it }.onFailure { if (first) errorMessage = listOfNotNull(errorMessage, "多周期: ${it.message}").joinToString(" / ") }
        adv.onSuccess { if (it != null) advice = it }.onFailure { if (first) errorMessage = listOfNotNull(errorMessage, "建议: ${it.message}").joinToString(" / ") }
        derivativesResult.onSuccess { if (it != null) derivatives = it }.onFailure { if (first && marketCategory == "crypto") errorMessage = listOfNotNull(errorMessage, "合约数据: ${it.message}").joinToString(" / ") }
        exchangeResult.onSuccess { if (it != null) multiExchange = it }.onFailure { if (first && marketCategory == "crypto") errorMessage = listOfNotNull(errorMessage, "交易所聚合: ${it.message}").joinToString(" / ") }
        manifest.onSuccess { if (it.isNotEmpty()) reportCatalog = it }.onFailure { if (first) errorMessage = listOfNotNull(errorMessage, "报告状态: ${it.message}").joinToString(" / ") }
        feedback.onSuccess { analysisFeedback = it }.onFailure { if (first) errorMessage = listOfNotNull(errorMessage, "历史反馈: ${it.message}").joinToString(" / ") }
        detailLoading = false
        lastAnalysisRefreshAt = System.currentTimeMillis()
        if (unified.isSuccess || instrumentSnapshot.isSuccess || ind.isSuccess || mtf.isSuccess || adv.isSuccess) { backendOnline = true; connectionStatus = "后端在线 · 分析实时刷新" }
    }

    fun loadAnalysisFeed(category: String = marketCategory) {
        viewModelScope.launch {
            RestClient.fetchAnalysisFeed(category, timeframe, 8).onSuccess { analysisFeed = it }
        }
    }

    fun loadReportCatalog() {
        viewModelScope.launch {
            RestClient.fetchReportCatalog().onSuccess { reportCatalog = it }
        }
    }

    fun openReport(reportKey: String) {
        val symbol = selectedSymbol ?: return
        reportLoading = true
        viewModelScope.launch {
            RestClient.fetchReport(reportKey, symbol, timeframe, marketCategory)
                .onSuccess { selectedReport = it }
                .onFailure { errorMessage = "报告: ${it.message}" }
            reportLoading = false
        }
    }

    fun startLive() {
        if (ws != null) return
        live = true
        connectionStatus = "WS 连接中…"
        ws = MarketWsClient(
            onTick = { tick -> viewModelScope.launch(Dispatchers.Main) { applyTick(tick) } },
            onSignal = { sig -> viewModelScope.launch(Dispatchers.Main) { applySignal(sig) } },
            onAttention = { att -> viewModelScope.launch(Dispatchers.Main) { applyAttention(att) } },
            onStatus = { s -> viewModelScope.launch(Dispatchers.Main) { connectionStatus = "WS: $s" } },
        ).also { it.connect() }
    }

    fun stopLive() {
        detailRefreshJob?.cancel()
        detailRefreshJob = null
        ws?.disconnect()
        ws = null
        live = false
        connectionStatus = if (backendOnline) "后端在线" else "未连接"
    }

    private fun applyTick(tick: LiveTick) {
        val last = tick.last ?: return
        val sym = normalizeSymbol(tick.symbol)
        markets = markets.map { m ->
            if (m.symbol == sym || m.symbol.replace("/", "") == tick.symbol.replace("/", "")) {
                val prev = parsePrice(m.price)
                val chg = if (prev > 0) (last - prev) / prev * 100.0 else m.changePct
                m.copy(price = priceFmt.format(last), changePct = chg)
            } else m
        }.let { list ->
            if (list.none { it.symbol == sym }) {
                list + MarketItem(sym, sym, priceFmt.format(last), 0.0, 0.0, "live")
            } else list
        }.also { updated ->
            MarketCache.save(updated)
            cacheSavedAt = System.currentTimeMillis()
        }
    }

    private fun applySignal(sig: LiveSignal) {
        val item = SignalItem(
            symbol = normalizeSymbol(sig.symbol),
            name = sig.name,
            direction = sig.direction,
            strength = sig.strength,
            timeframe = sig.timeframe,
        )
        signals = (listOf(item) + signals.filterNot { it.symbol == item.symbol && it.name == item.name }).take(30)
    }

    private fun applyAttention(att: LiveAttention) {
        val sym = normalizeSymbol(att.symbol)
        markets = markets.map { m ->
            if (m.symbol == sym) m.copy(attention = att.score, regime = att.regime ?: m.regime) else m
        }.also { updated ->
            MarketCache.save(updated)
            cacheSavedAt = System.currentTimeMillis()
        }
    }

    private fun normalizeSymbol(raw: String): String {
        val u = raw.uppercase().replace("/", "")
        return if (u.endsWith("USDT") && u.length > 4) u.dropLast(4) + "/USDT" else raw
    }

    private fun parsePrice(s: String): Double = s.replace(",", "").toDoubleOrNull() ?: 0.0

    override fun onCleared() {
        stopLive()
        super.onCleared()
    }

    companion object {
        fun backendHint(): String = "Backend: ${ApiConfig.baseUrl}"
        val timeframes = listOf("5m", "15m", "30m", "1h", "4h", "1d", "1w")
    }
}
