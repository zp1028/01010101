package com.caifenxi.app.domain.btc.polymarket

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Polymarket public data:
 * - Gamma API: market discovery
 * - CLOB API: order book / price
 * Order placement requires auth + wallet; [PolymarketClobBroker] is a stub until keys injected.
 */
class PolymarketRepository(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()
) {
    private val gammaBases = listOf("https://gamma-api.polymarket.com")
    private val clobBases = listOf("https://clob.polymarket.com")

    suspend fun searchCryptoMarkets(limit: Int = 20): List<PolyMarket> = withContext(Dispatchers.IO) {
        var lastError: Exception? = null
        for (gamma in gammaBases) {
            try {
                val url = "$gamma/events?active=true&closed=false&limit=$limit"
                val arr = getArray(url)
                val list = buildList {
                    for (i in 0 until arr.length()) {
                        val ev = arr.getJSONObject(i)
                        val markets = ev.optJSONArray("markets") ?: continue
                        for (j in 0 until markets.length()) {
                            parseMarket(markets.getJSONObject(j))?.let { add(it) }
                        }
                    }
                }.filter {
                    val q = it.question.lowercase()
                    q.contains("bitcoin") || q.contains("btc") || q.contains("crypto") || q.contains("ethereum")
                }
                if (list.isNotEmpty()) return@withContext list
            } catch (e: Exception) {
                lastError = e
            }
        }
        return@withContext emptyList()
    }

    suspend fun orderBook(tokenId: String): PolyOrderBook = withContext(Dispatchers.IO) {
        var lastError: Exception? = null
        for (clob in clobBases) {
            try {
                val o = getObject("$clob/book?token_id=$tokenId")
                fun levels(key: String): List<PolyBookLevel> {
                    val a = o.optJSONArray(key) ?: return emptyList()
                    return buildList {
                        for (i in 0 until a.length()) {
                            val x = a.getJSONObject(i)
                            add(PolyBookLevel(x.optString("price", "0").toDoubleOrNull() ?: 0.0, x.optString("size", "0").toDoubleOrNull() ?: 0.0))
                        }
                    }
                }
                return@withContext PolyOrderBook(
                    tokenId = tokenId,
                    bids = levels("bids"),
                    asks = levels("asks"),
                    tickSize = o.optString("tick_size", "0.01").toDoubleOrNull() ?: 0.01,
                    minOrderSize = o.optString("min_order_size", "1").toDoubleOrNull() ?: 1.0,
                    negRisk = o.optBoolean("neg_risk", false)
                )
            } catch (e: Exception) {
                lastError = e
            }
        }
        return@withContext PolyOrderBook(tokenId = tokenId)
    }

    private fun parseMarket(m: JSONObject): PolyMarket? {
        val tokensRaw = m.optString("clobTokenIds", "")
        val tokens = try {
            JSONArray(tokensRaw)
        } catch (_: Exception) {
            return null
        }
        if (tokens.length() < 2) return null
        val outcomes = try { JSONArray(m.optString("outcomes", "[\"Yes\",\"No\"]")) } catch (_: Exception) { JSONArray("[\"Yes\",\"No\"]") }
        val prices = try { JSONArray(m.optString("outcomePrices", "[\"0.5\",\"0.5\"]")) } catch (_: Exception) { JSONArray("[\"0.5\",\"0.5\"]") }
        val yesP = prices.optString(0, "0.5").toDoubleOrNull() ?: 0.5
        val noP = prices.optString(1, "0.5").toDoubleOrNull() ?: 0.5
        val end = m.optString("endDateIso").ifBlank { m.optString("endDate") }
        val endMs = runCatching { java.time.Instant.parse(end).toEpochMilli() }.getOrNull()
        return PolyMarket(
            conditionId = m.optString("conditionId", m.optString("id")),
            question = m.optString("question", m.optString("title")),
            slug = m.optString("slug"),
            yesTokenId = tokens.optString(0),
            noTokenId = tokens.optString(1),
            yesPrice = yesP,
            noPrice = noP,
            endDateMs = endMs,
            closed = m.optBoolean("closed", false),
            enableOrderBook = m.optBoolean("enableOrderBook", true),
            negRisk = m.optBoolean("negRisk", false)
        )
    }

    private fun getObject(url: String): JSONObject {
        val req = Request.Builder().url(url).get().build()
        client.newCall(req).execute().use { r ->
            val body = r.body?.string().orEmpty()
            if (!r.isSuccessful) error("HTTP ${r.code} ${body.take(120)}")
            return JSONObject(body)
        }
    }

    private fun getArray(url: String): JSONArray {
        val req = Request.Builder().url(url).get().build()
        client.newCall(req).execute().use { r ->
            val body = r.body?.string().orEmpty()
            if (!r.isSuccessful) error("HTTP ${r.code} ${body.take(120)}")
            return JSONArray(body)
        }
    }
}
