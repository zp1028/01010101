package com.caifenxi.app.domain.btc.runtime

import com.caifenxi.app.domain.btc.BinanceDerivativesRepository
import com.caifenxi.app.domain.btc.BinanceMarketRepository
import com.caifenxi.app.domain.btc.BtcPlanEngine
import com.caifenxi.app.domain.btc.BtcSignalFactory
import com.caifenxi.app.domain.btc.DerivativesFeatureEngine
import com.caifenxi.app.domain.btc.news.CryptoNewsRepository
import com.caifenxi.app.domain.btc.ai.AiBrain
import com.caifenxi.app.domain.btc.ai.AiPolicy
import com.caifenxi.app.domain.btc.ai.AiPolicyConfig
import com.caifenxi.app.domain.btc.broker.PerpBroker
import com.caifenxi.app.domain.btc.risk.BtcRiskEngine
import com.caifenxi.app.domain.btc.plan.BtcLivePlanPerformance
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope

/** P2 runtime loop + P3 derivatives features. Default PAPER; TESTNET needs injected broker. */
class BtcRuntimeController(
    private val market: BinanceMarketRepository = BinanceMarketRepository(),
    private val derivatives: BinanceDerivativesRepository = BinanceDerivativesRepository(),
    private val newsRepo: CryptoNewsRepository = CryptoNewsRepository(),
    private val aiBrain: AiBrain = AiBrain(),
    private val aiPolicy: AiPolicyConfig = AiPolicyConfig(allowLiveAiOrders = false),
    private val engine: BtcPlanEngine = BtcPlanEngine(),
    private val signalFactory: BtcSignalFactory = BtcSignalFactory(),
    private val risk: BtcRiskEngine = BtcRiskEngine(),
    private val store: BtcRuntimeStore,
    private val broker: PerpBroker? = null,
    private val gate: BtcExecutionGate = BtcExecutionGate(),
    private val livePerformance: BtcLivePlanPerformance = BtcLivePlanPerformance(),
    /** 云控制面：默认 Noop（不联网、零副作用）；接入真实实现后可远程停市/恢复。 */
    private val controlPlane: BtcControlPlane = NoopBtcControlPlane
) {
    /** 本节点标识（云端控制面按节点分发命令；Noop 实现忽略该值）。 */
    companion object {
        private const val NODE_ID = "btc-quant-default"
    }

    suspend fun runOnce() {
        val cfg = store.config()
        if (!cfg.enabled || store.state().killSwitch) return
        // 云控制面：拉取远程命令并执行（KILL/RESUME/STOP 等安全控制）。
        // Noop 返回空列表，任何远程异常都不影响本地执行主循环。
        runCatching {
            val commands = controlPlane.pullCommands(NODE_ID)
            if (commands.isNotEmpty()) {
                val processor = BtcRemoteCommandProcessor(store)
                commands.forEach { cmd ->
                    val ok = processor.apply(cmd)
                    controlPlane.ack(cmd.commandId, ok)
                }
            }
        }
        if (!store.config().enabled || store.state().killSwitch) return
        coroutineScope {
            val candlesDef = async { runCatching { market.loadKlines(cfg.symbol, cfg.timeframe, 300) }.getOrDefault(emptyList()) }
            val fundingDef = async {
                runCatching { derivatives.fundingHistory(cfg.symbol, 100) }.getOrDefault(emptyList())
            }
            val oiDef = async {
                runCatching { derivatives.openInterestHistory(cfg.symbol, cfg.timeframe.ifBlank { "15m" }, 100) }
                    .getOrDefault(emptyList())
            }
            val snapDef = async {
                runCatching { derivatives.snapshot(cfg.symbol) }.getOrNull()
            }
            val candles = candlesDef.await()
            if (candles.isEmpty()) return@coroutineScope
            // Only make a decision from a completed candle. Binance may return the
            // currently-forming candle as the last item; using it would make the
            // signal change intrabar and can create inconsistent execution.
            val decisionIndex = candles.indexOfLast { it.openTime + timeframeMillis(cfg.timeframe) <= System.currentTimeMillis() }
            if (decisionIndex < 0) return@coroutineScope
            val decisionCandles = candles.subList(0, decisionIndex + 1)
            val last = decisionCandles.last()
            val current = store.state()
            // Paper account is stateful and survives process death. Mark the open
            // position before deciding whether this bar is already processed.
            if (cfg.runMode == BtcRunMode.PAPER) {
                val paper = store.paperLedger()
                paper.mark(last.close)
                if (paper.shouldCloseAt(last.close)) {
                    paper.close(last.close)
                    store.update { it.copy(lastError = null, lastHeartbeatAt = System.currentTimeMillis()) }
                }
            }
            if (current.lastBarId == last.openTime) {
                store.update {
                    it.copy(status = BtcRuntimeStatus.RUNNING, lastHeartbeatAt = System.currentTimeMillis())
                }
                return@coroutineScope
            }
            val funding = fundingDef.await()
            val oi = oiDef.await()
            val snap = snapDef.await()
            val prev = decisionCandles.getOrNull(decisionCandles.lastIndex - 1)
            val deriv = DerivativesFeatureEngine.build(
                barTime = last.openTime,
                close = last.close,
                prevClose = prev?.close,
                fundingHistory = funding,
                oiHistory = oi,
                snapshot = snap
            )
            val news = runCatching { newsRepo.snapshot() }.getOrNull()
            // Refresh plan performance once per completed bar. This makes the
            // registry/lifecycle/dynamic-weight stack actually influence live decisions.
            val perf = livePerformance.get(decisionCandles, deriv)
            val (basePlans, baseConsensus) = engine.evaluate(decisionCandles, deriv, perf = perf)
            val aiCand = aiBrain.generateCandidate(decisionCandles, basePlans, baseConsensus, news, deriv)
            if (news?.blackSwan == true && aiPolicy.haltOnBlackSwan) {
                store.update { it.copy(
                    status = BtcRuntimeStatus.PAUSED,
                    lastError = "新闻黑天鹅熔断",
                    lastHeartbeatAt = System.currentTimeMillis(),
                    lastBarId = last.openTime
                ) }
                return@coroutineScope
            }
            val aiPlan = AiPolicy.toPlanSignal(aiCand, aiPolicy)
            val (plans, consensus) = if (aiPlan != null) {
                engine.evaluate(decisionCandles, deriv, perf = perf, extraSignals = listOf(aiPlan))
            } else basePlans to baseConsensus
            val signal = if (consensus != null) {
                signalFactory.buildPerpSignal(cfg.symbol, decisionCandles, plans, consensus, cfg.maxPositionQty)
            } else null
            // Publish the latest signal/market diagnostics first, but DO NOT
            // advance lastBarId yet. A failed broker call must remain retryable.
            store.update {
                it.copy(
                    status = BtcRuntimeStatus.RUNNING,
                    lastHeartbeatAt = System.currentTimeMillis(),
                    lastSignal = consensus?.direction,
                    lastError = null,
                    lastFundingRate = deriv.fundingRate,
                    lastOiChangePct = deriv.oiChangePct,
                    lastDerivScore = deriv.derivativesScore
                )
            }
            if (signal == null || consensus == null) {
                store.update {
                    it.copy(
                        lastBarId = last.openTime,
                        processedBars = it.processedBars + 1
                    )
                }
                return@coroutineScope
            }
            val decision = risk.authorize(consensus, dailyPnlPct = 0.0, currentDrawdownPct = 0.0, requestedNotionalPct = 5.0)
            if (!decision.allowed) {
                store.update { it.copy(status = BtcRuntimeStatus.PAUSED, lastError = decision.reason) }
                return@coroutineScope
            }
            if (!gate.claimBar(signal.symbol, cfg.timeframe, signal.barId)) return@coroutineScope
            val executionKey = gate.key(signal.symbol, cfg.timeframe, signal.barId)
            try {
                val result = when (cfg.runMode) {
                    BtcRunMode.PAPER -> {
                        val paper = store.paperLedger()
                        val opened = paper.open(
                            symbol = signal.symbol,
                            direction = signal.direction,
                            entry = signal.entry,
                            quantity = signal.positionSize,
                            leverage = signal.leverageCap,
                            stopLoss = signal.stopLoss,
                            takeProfit = signal.takeProfit
                        )
                        com.caifenxi.app.domain.btc.broker.BrokerOrderResult(
                            success = opened,
                            orderId = null,
                            clientOrderId = "PAPER-${signal.symbol}-${signal.barId}",
                            status = if (opened) "PAPER_FILLED" else "PAPER_REJECTED",
                            message = if (opened) "paper position opened" else "paper position already active"
                        )
                    }
                    BtcRunMode.TESTNET, BtcRunMode.LIVE -> {
                        val b = broker ?: run {
                            store.update { it.copy(
                                status = BtcRuntimeStatus.ERROR,
                                lastError = "Broker 未注入，未标记本 bar 已处理"
                            ) }
                            gate.release(executionKey)
                            return@coroutineScope
                        }
                        b.place(signal, "BTC-${signal.symbol}-${signal.barId}-${signal.direction.name}")
                    }
                }

                if (result.success) {
                    store.update {
                        it.copy(
                            status = BtcRuntimeStatus.RUNNING,
                            lastBarId = last.openTime,
                            processedBars = it.processedBars + 1,
                            lastOrderClientId = result.clientOrderId,
                            lastError = null
                        )
                    }
                } else {
                    // Release the idempotency claim so a later tick can retry.
                    gate.release(executionKey)
                    store.update {
                        it.copy(
                            status = BtcRuntimeStatus.ERROR,
                            lastError = "订单失败: ${result.status} ${result.message}".trim()
                        )
                    }
                }
            } catch (e: Exception) {
                gate.release(executionKey)
                store.update {
                    it.copy(status = BtcRuntimeStatus.ERROR, lastError = e.message ?: "runtime execution failed")
                }
            }
        }
        // 云控制面：每次执行结束上报心跳（Noop 忽略，不影响本地主循环）。
        runCatching {
            val s = store.state()
            controlPlane.heartbeat(
                BtcHeartbeat(
                    nodeId = NODE_ID,
                    status = s.status.name,
                    symbol = cfg.symbol,
                    timeframe = cfg.timeframe,
                    lastBarId = s.lastBarId,
                    lastHeartbeatAt = System.currentTimeMillis(),
                    killSwitch = s.killSwitch
                )
            )
        }
    }

    private fun timeframeMillis(timeframe: String): Long {
        val m = Regex("(\\d+)([mhdwM])").matchEntire(timeframe)
            ?: return 5L * 60_000L
        val n = m.groupValues[1].toLongOrNull()?.coerceAtLeast(1L) ?: 5L
        return when (m.groupValues[2]) {
            "m" -> n * 60_000L
            "h" -> n * 3_600_000L
            "d" -> n * 86_400_000L
            "w" -> n * 7L * 86_400_000L
            "M" -> n * 30L * 86_400_000L
            else -> 5L * 60_000L
        }
    }
}
