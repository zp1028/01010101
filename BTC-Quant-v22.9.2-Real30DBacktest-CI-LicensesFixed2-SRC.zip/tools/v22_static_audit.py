#!/usr/bin/env python3
from pathlib import Path
import re, json
ROOT=Path(__file__).resolve().parents[1]/"app/src/main/java/com/caifenxi/app"
files=list(ROOT.rglob("*.kt"))
result={"kotlin_files":len(files),"direct_order_writes_outside_gateway_or_broker":[],"plaintext_credential_fallback":[],"ui_direct_start_service":[],"gateway_present":False}
for p in files:
    s=p.read_text(errors="ignore")
    rel=p.relative_to(ROOT).as_posix()
    if p.name=="UnifiedExecutionGateway.kt": result["gateway_present"]=True
    if "/broker/" not in rel and p.name!="UnifiedExecutionGateway.kt":
        if re.search(r"\.(place|submitOrder|createOrder|postOrder)\s*\(",s):
            result["direct_order_writes_outside_gateway_or_broker"].append(rel)
    if p.name=="BrokerCredentials.kt" and "btc_broker_creds_secure" in s and "fail-closed" in s.lower():
        pass
    if p.name=="BtcQuantViewModel.kt" and re.search(r"\bapp\.startService\s*\(",s):
        result["ui_direct_start_service"].append(rel)
print(json.dumps(result,ensure_ascii=False,indent=2))
raise SystemExit(0 if result["gateway_present"] and not result["direct_order_writes_outside_gateway_or_broker"] and not result["ui_direct_start_service"] else 2)
