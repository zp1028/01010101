# BTC Quant v20.5.0
Production Integrity: Room migration safety, Binance private-stream event ordering/expiry recovery, unified release build path, execution queue/impact primitives, factor quality gate, and cancel/replace lifecycle states.
