package com.caifenxi.app.domain.btc.polymarket

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Polymarket public data:
 * - Gamma API: market discovery
 * - CLOB API: order book / price
 * Order placement is intentionally separated into [PolymarketClobBroker], which exposes an explicit signer/auth capability state rather than pretending an unsigned request is live trading.
 */
class PolymarketRepository(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(6, TimeUnit.SECONDS)
        .callTimeout(8, TimeUnit.SECONDS)
        .build()
) {
    private val gammaBases = listOf("https://gamma-api.polymarket.com")
    private val clobBases = listOf("https://clob.polymarket.com")

    suspend fun searchCryptoMarkets(limit: Int = 20): List<PolyMarket> = withContext(Dispatchers.IO) {
        var lastError: Exception? = null
        for (gamma in gammaBases) {
            try {
                val url = "$gamma/events?active=true&closed=false&limit=$limit"
                val arr = getArray(url)
                val list = buildList {
                    for (i in 0 until arr.length()) {
                        val ev = arr.getJSONObject(i)
                        val markets = ev.optJSONArray("markets") ?: continue
                        for (j in 0 until markets.length()) {
                            parseMarket(markets.getJSONObject(j))?.let { add(it) }
                        }
                    }
                }.filter {
                    val q = it.question.lowercase()
                    q.contains("bitcoin") || q.contains("btc") || q.contains("crypto") || q.contains("ethereum")
                }
                if (list.isNotEmpty()) return@withContext list
            } catch (e: Exception) {
                lastError = e
            }
        }
        return@withContext emptyList()
    }

    suspend fun marketById(marketId: String): PolyMarket? = withContext(Dispatchers.IO) {
        runCatching { parseMarket(getObject("${gammaBases.first()}/markets/${java.net.URLEncoder.encode(marketId, "UTF-8")}")) }.getOrNull()
    }

    suspend fun orderBook(tokenId: String): PolyOrderBook = withContext(Dispatchers.IO) {
        var lastError: Exception? = null
        for (clob in clobBases) {
            try {
                val o = getObject("$clob/book?token_id=$tokenId")
                fun levels(key: String): List<PolyBookLevel> {
                    val a = o.optJSONArray(key) ?: return emptyList()
                    return buildList {
                        for (i in 0 until a.length()) {
                            val x = a.getJSONObject(i)
                            add(PolyBookLevel(x.optString("price", "0").toDoubleOrNull() ?: 0.0, x.optString("size", "0").toDoubleOrNull() ?: 0.0))
                        }
                    }
                }
                return@withContext PolyOrderBook(
                    tokenId = tokenId,
                    bids = levels("bids"),
                    asks = levels("asks"),
                    tickSize = o.optString("tick_size", "0.01").toDoubleOrNull() ?: 0.01,
                    minOrderSize = o.optString("min_order_size", "1").toDoubleOrNull() ?: 1.0,
                    negRisk = o.optBoolean("neg_risk", false)
                )
            } catch (e: Exception) {
                lastError = e
            }
        }
        return@withContext PolyOrderBook(
            tokenId = tokenId,
            bids = emptyList(),
            asks = emptyList(),
            tickSize = 0.01,
            minOrderSize = 1.0,
            negRisk = false
        )
    }

    private fun parseMarket(m: JSONObject): PolyMarket? {
        val tokens = when (val raw = m.opt("clobTokenIds")) {
            is JSONArray -> raw
            is String -> runCatching { JSONArray(raw) }.getOrNull()
            else -> null
        } ?: return null
        if (tokens.length() < 2) return null
        val outcomes = try { JSONArray(m.optString("outcomes", "[\"Yes\",\"No\"]")) } catch (_: Exception) { JSONArray("[\"Yes\",\"No\"]") }
        val prices = try { JSONArray(m.optString("outcomePrices", "[\"0.5\",\"0.5\"]")) } catch (_: Exception) { JSONArray("[\"0.5\",\"0.5\"]") }
        val yesP = prices.optString(0, "0.5").toDoubleOrNull() ?: 0.5
        val noP = prices.optString(1, "0.5").toDoubleOrNull() ?: 0.5
        val start = m.optString("startDateIso").ifBlank { m.optString("startDate") }
        val end = m.optString("endDateIso").ifBlank { m.optString("endDate") }
        val startMs = runCatching { java.time.Instant.parse(start).toEpochMilli() }.getOrNull()
        val endMs = runCatching { java.time.Instant.parse(end).toEpochMilli() }.getOrNull()
        val question = m.optString("question", m.optString("title"))
        val description = m.optString("description", "")
        val priceToBeat = extractPriceToBeat(question, description)
        val explicitResolution = sequenceOf(
            m.optString("resolvedOutcome"),
            m.optString("resolution"),
            m.optString("winner"),
            m.optString("winningOutcome")
        ).firstOrNull { it.isNotBlank() }?.trim()?.uppercase()
        val resolvedOutcome = explicitResolution?.let(::normalizeOutcome)
            ?: if (m.optBoolean("closed", false)) {
                when {
                    yesP >= 0.995 && noP <= 0.005 -> "YES"
                    noP >= 0.995 && yesP <= 0.005 -> "NO"
                    else -> null
                }
            } else null
        return PolyMarket(
            conditionId = m.optString("conditionId", m.optString("id")),
            question = question,
            slug = m.optString("slug"),
            description = description,
            priceToBeat = priceToBeat,
            startDateMs = startMs,
            yesTokenId = tokens.optString(0),
            noTokenId = tokens.optString(1),
            yesPrice = yesP,
            noPrice = noP,
            endDateMs = endMs,
            closed = m.optBoolean("closed", false),
            enableOrderBook = m.optBoolean("enableOrderBook", true),
            negRisk = m.optBoolean("negRisk", false),
            resolvedOutcome = resolvedOutcome
        )
    }


    private fun normalizeOutcome(raw: String): String? = when (raw.uppercase()) {
        "YES", "Y", "1", "TRUE", "UP", "BULL", "BULLISH" -> "YES"
        "NO", "N", "0", "FALSE", "DOWN", "BEAR", "BEARISH" -> "NO"
        else -> null
    }

    private fun extractPriceToBeat(question: String, description: String): Double? {
        val text = "$question\n$description"
        val patterns = listOf(
            Regex("""(?:above|below|at|than|price to beat|starting price)[^$\d]{0,30}\$\s*([\d,]+(?:\.\d+)?)""", RegexOption.IGNORE_CASE),
            Regex("""\$\s*([\d,]+(?:\.\d+)?)""")
        )
        return patterns.asSequence().mapNotNull { re -> re.find(text)?.groupValues?.getOrNull(1)?.replace(",", "")?.toDoubleOrNull() }.firstOrNull()
    }

    private fun getObject(url: String): JSONObject {
        val req = Request.Builder().url(url).get().build()
        client.newCall(req).execute().use { r ->
            val body = r.body?.string().orEmpty()
            if (!r.isSuccessful) error("HTTP ${r.code} ${body.take(120)}")
            return JSONObject(body)
        }
    }

    private fun getArray(url: String): JSONArray {
        val req = Request.Builder().url(url).get().build()
        client.newCall(req).execute().use { r ->
            val body = r.body?.string().orEmpty()
            if (!r.isSuccessful) error("HTTP ${r.code} ${body.take(120)}")
            return JSONArray(body)
        }
    }
}
