package com.caifenxi.app.domain.btc.polymarket

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * Polymarket public market-channel stream.
 * Keeps the latest full book per asset and rejects duplicate/stale events.
 * REST remains the recovery path when the stream is unavailable.
 */
class PolymarketWebSocketClient(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build(),
    private val url: String = "wss://ws-subscriptions-clob.polymarket.com/ws/market"
) {
    interface Listener {
        fun onConnected() {}
        fun onBook(book: PolyOrderBook, marketId: String, timestampMs: Long) {}
        fun onPriceChange(assetId: String, marketId: String, price: Double, size: Double, side: String, bestBid: Double?, bestAsk: Double?, timestampMs: Long) {}
        fun onTrade(assetId: String, marketId: String, price: Double, size: Double, side: String, timestampMs: Long) {}
        fun onResolved(marketId: String, winningAssetId: String, winningOutcome: String, timestampMs: Long) {}
        fun onError(message: String, throwable: Throwable? = null) {}
        fun onClosed() {}
    }

    private val sockets = ConcurrentHashMap<String, WebSocket>()
    private val lastEvent = ConcurrentHashMap<String, Long>()

    fun connect(assetIds: Collection<String>, listener: Listener): WebSocket? {
        val ids = assetIds.filter { it.isNotBlank() }.distinct()
        if (ids.isEmpty()) return null
        val request = Request.Builder().url(url).build()
        val ws = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                sockets[ids.joinToString(",")] = webSocket
                webSocket.send(JSONObject().apply {
                    put("assets_ids", JSONArray(ids))
                    put("type", "market")
                }.toString())
                listener.onConnected()
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (text.equals("PONG", true) || text.equals("pong", true)) return
                runCatching { JSONObject(text) }
                    .onSuccess { handle(it, listener) }
                    .onFailure { listener.onError("Polymarket WS JSON parse failed", it) }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                listener.onError("Polymarket WS failure: ${t.message}", t)
                sockets.entries.removeIf { it.value == webSocket }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                sockets.entries.removeIf { it.value == webSocket }
                listener.onClosed()
            }
        })
        return ws
    }

    fun subscribe(webSocket: WebSocket, assetIds: Collection<String>): Boolean {
        val ids = assetIds.filter { it.isNotBlank() }.distinct()
        if (ids.isEmpty()) return false
        return webSocket.send(JSONObject().apply {
            put("operation", "subscribe")
            put("assets_ids", JSONArray(ids))
        }.toString())
    }

    fun unsubscribe(webSocket: WebSocket, assetIds: Collection<String>): Boolean {
        val ids = assetIds.filter { it.isNotBlank() }.distinct()
        if (ids.isEmpty()) return false
        return webSocket.send(JSONObject().apply {
            put("operation", "unsubscribe")
            put("assets_ids", JSONArray(ids))
        }.toString())
    }

    fun ping(webSocket: WebSocket): Boolean = webSocket.send("PING")

    fun closeAll() {
        sockets.values.toSet().forEach { it.close(1000, "client shutdown") }
        sockets.clear()
    }

    private fun handle(o: JSONObject, listener: Listener) {
        val type = o.optString("event_type").lowercase()
        val ts = o.optLong("timestamp", System.currentTimeMillis()).let { if (it < 10_000_000_000L) it * 1000 else it }
        val key = when (type) {
            "price_change" -> "price:${o.optString("market")}:${o.optLong("timestamp", ts)}:${o.optString("hash")}" 
            "book" -> "book:${o.optString("asset_id")}:${o.optLong("timestamp", ts)}:${o.optString("hash")}"
            "last_trade_price" -> "trade:${o.optString("asset_id")}:${o.optLong("timestamp", ts)}:${o.optString("transaction_hash")}"
            else -> "$type:${o.optString("market")}:$ts:${o.optString("id")}"
        }
        val previous = lastEvent.putIfAbsent(key, ts)
        if (previous != null) return

        when (type) {
            "book" -> listener.onBook(parseBook(o), o.optString("market"), ts)
            "price_change" -> {
                val changes = o.optJSONArray("price_changes") ?: return
                for (i in 0 until changes.length()) {
                    val c = changes.optJSONObject(i) ?: continue
                    listener.onPriceChange(
                        c.optString("asset_id"), o.optString("market"),
                        c.optDouble("price", 0.0), c.optDouble("size", 0.0), c.optString("side"),
                        c.optString("best_bid").toDoubleOrNull(), c.optString("best_ask").toDoubleOrNull(), ts
                    )
                }
            }
            "last_trade_price" -> listener.onTrade(o.optString("asset_id"), o.optString("market"), o.optDouble("price"), o.optDouble("size"), o.optString("side"), ts)
            "market_resolved" -> listener.onResolved(o.optString("market"), o.optString("winning_asset_id"), o.optString("winning_outcome"), ts)
        }
        if (lastEvent.size > 5000) {
            lastEvent.entries.sortedBy { it.value }.take(1000).forEach { lastEvent.remove(it.key, it.value) }
        }
    }

    private fun parseBook(o: JSONObject): PolyOrderBook {
        fun levels(name: String): List<PolyBookLevel> {
            val a = o.optJSONArray(name) ?: return emptyList()
            return buildList {
                for (i in 0 until a.length()) {
                    val x = a.optJSONObject(i) ?: continue
                    val p = x.optString("price").toDoubleOrNull() ?: continue
                    val s = x.optString("size").toDoubleOrNull() ?: continue
                    if (p > 0 && s > 0) add(PolyBookLevel(p, s))
                }
            }
        }
        return PolyOrderBook(
            tokenId = o.optString("asset_id"),
            bids = levels("bids"),
            asks = levels("asks"),
            tickSize = 0.01,
            minOrderSize = 1.0,
            negRisk = false
        )
    }
}
