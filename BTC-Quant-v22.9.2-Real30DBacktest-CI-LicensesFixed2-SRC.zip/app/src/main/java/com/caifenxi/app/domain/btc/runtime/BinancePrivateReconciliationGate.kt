package com.caifenxi.app.domain.btc.runtime

import java.util.concurrent.atomic.AtomicBoolean

/**
 * Bridges realtime private-stream health to the execution loop.
 * A detected stream gap never attempts to guess missing state: it requests a REST
 * reconciliation and keeps the request latched until the runtime consumes it.
 */
class BinancePrivateReconciliationGate {
    private val requested = AtomicBoolean(false)
    @Volatile private var reason: String = ""
    @Volatile private var requestedAt: Long = 0L

    fun request(reason: String, atMs: Long = System.currentTimeMillis()) {
        this.reason = reason
        this.requestedAt = atMs
        requested.set(true)
    }

    fun consume(): Request? = if (requested.compareAndSet(true, false))
        Request(reason, requestedAt)
    else null

    fun isRequested(): Boolean = requested.get()

    data class Request(val reason: String, val requestedAt: Long)
}
