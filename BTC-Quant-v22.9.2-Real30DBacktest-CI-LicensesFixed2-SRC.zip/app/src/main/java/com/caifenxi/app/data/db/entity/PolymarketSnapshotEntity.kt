package com.caifenxi.app.data.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Point-in-time Polymarket CLOB observation. One row per strategy candidate. */
@Entity(tableName = "polymarket_snapshots")
data class PolymarketSnapshotEntity(
    @PrimaryKey(autoGenerate = true) val rowId: Long = 0,
    val marketId: String,
    val capturedAtMs: Long,
    val startDateMs: Long?,
    val endDateMs: Long?,
    val currentBtc: Double?,
    val priceToBeat: Double?,
    val yesBid: Double?,
    val yesAsk: Double?,
    val noBid: Double?,
    val noAsk: Double?,
    val yesDepth: Double,
    val noDepth: Double,
    val yesVolumeProxy: Double = 0.0,
    val noVolumeProxy: Double = 0.0,
    val modelYes: Double?,
    val spread: Double,
    val strategyId: String?,
    val strategyScore: Double?,
    val signalOutcome: String?,
    val signalEdge: Double?,
    val resolvedOutcome: String? = null,
    val source: String = "POLYMARKET_CLOB"
)
