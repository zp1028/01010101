package com.caifenxi.app.domain.btc.hs

import android.content.Context
import com.caifenxi.app.data.db.CaiDatabase
import com.caifenxi.app.data.db.entity.HsShadowClosedEntity
import com.caifenxi.app.data.db.entity.HsShadowOpenEntity
import com.caifenxi.app.domain.btc.BtcDirection
import org.json.JSONArray
import org.json.JSONObject
import java.util.ArrayDeque

/**
 * 影子盘账本 —— 优先 Room，无 Context 时内存；启动时从旧 prefs 迁移。
 */
class HsShadowTradingStore(context: Context? = null, private val maxRecords: Int = 1500) {
    data class Open(
        val id: String, val timeframe: String, val barId: Long, val entry: Double,
        val direction: BtcDirection, val probability: Double, val modelVersion: String
    )
    data class Closed(
        val id: String, val timeframe: String, val direction: BtcDirection, val probability: Double,
        val outcome: Boolean, val returnPct: Double, val mfePct: Double, val maePct: Double,
        val modelVersion: String, val closedAt: Long = System.currentTimeMillis()
    )
    data class Stats(
        val closed: Int, val wins: Int, val hitRate: Double,
        val avgReturnPct: Double, val avgMfePct: Double, val avgMaePct: Double
    )

    private val appCtx = context?.applicationContext
    private val dao = appCtx?.let { runCatching { CaiDatabase.getInstance(it).hsShadowDao() }.getOrNull() }
    private val openMem = LinkedHashMap<String, Open>()
    private val closedMem = ArrayDeque<Closed>()
    private val prefs = appCtx?.getSharedPreferences("btc_hs_shadow_v2", Context.MODE_PRIVATE)

    init {
        migrateFromPrefsIfNeeded()
        if (dao == null) loadMemFromPrefs()
    }

    @Synchronized
    fun observe(
        id: String, timeframe: String, barId: Long, entry: Double,
        direction: BtcDirection, probability: Double, modelVersion: String
    ) {
        if (direction == BtcDirection.FLAT || entry <= 0) return
        val databaseDao = dao
        if (databaseDao != null) {
            runCatching {
                if (databaseDao.getOpen(id) != null) return
                databaseDao.upsertOpen(
                    HsShadowOpenEntity(
                        id, timeframe, barId, entry, direction.name,
                        probability.coerceIn(0.0, 1.0), modelVersion
                    )
                )
                databaseDao.trimOpen(300)
            }.onFailure {
                // Room 异常时降级内存，不阻断看板
            }
        } else {
            if (openMem.containsKey(id)) return
            openMem[id] = Open(id, timeframe, barId, entry, direction, probability.coerceIn(0.0, 1.0), modelVersion)
            while (openMem.size > 300) openMem.remove(openMem.keys.first())
            persistMem()
        }
    }

    @Synchronized
    fun settle(id: String, high: Double, low: Double, close: Double): Closed? {
        if (high <= 0 || low <= 0 || close <= 0) return null
        val o = if (dao != null) {
            val e = dao.getOpen(id) ?: return null
            Open(e.id, e.timeframe, e.barId, e.entry, BtcDirection.valueOf(e.direction), e.probability, e.modelVersion)
        } else {
            openMem[id] ?: return null
        }
        if (o.entry <= 0) return null
        val mfe = if (o.direction == BtcDirection.UP) high / o.entry - 1 else 1 - low / o.entry
        val mae = if (o.direction == BtcDirection.UP) low / o.entry - 1 else 1 - high / o.entry
        val ret = if (o.direction == BtcDirection.UP) close / o.entry - 1 else 1 - close / o.entry
        val r = Closed(o.id, o.timeframe, o.direction, o.probability, ret > 0, ret * 100, mfe * 100, mae * 100, o.modelVersion)
        if (dao != null) {
            dao.deleteOpen(id)
            dao.insertClosed(
                HsShadowClosedEntity(
                    r.id, r.timeframe, r.direction.name, r.probability, r.outcome,
                    r.returnPct, r.mfePct, r.maePct, r.modelVersion, r.closedAt
                )
            )
            dao.trimClosed(maxRecords)
        } else {
            openMem.remove(id)
            closedMem.addLast(r)
            while (closedMem.size > maxRecords) closedMem.removeFirst()
            persistMem()
        }
        return r
    }

    @Synchronized
    fun stats(timeframe: String? = null): Stats {
        val rows = recent(500).filter { timeframe == null || it.timeframe == timeframe }
        if (rows.isEmpty()) return Stats(0, 0, 0.0, 0.0, 0.0, 0.0)
        val w = rows.count { it.outcome }
        return Stats(
            rows.size, w, w.toDouble() / rows.size,
            rows.map { it.returnPct }.average(),
            rows.map { it.mfePct }.average(),
            rows.map { it.maePct }.average()
        )
    }

    @Synchronized
    fun recent(limit: Int = 20): List<Closed> {
        dao?.let { d ->
            return runCatching {
                d.recentClosed(limit).map {
                    Closed(
                        it.id, it.timeframe, BtcDirection.valueOf(it.direction), it.probability,
                        it.outcome, it.returnPct, it.mfePct, it.maePct, it.modelVersion, it.closedAt
                    )
                }.reversed()
            }.getOrDefault(emptyList())
        }
        return closedMem.toList().takeLast(limit)
    }

    private fun migrateFromPrefsIfNeeded() {
        val p = prefs ?: return
        val d = dao ?: return
        if (p.getBoolean("migrated_to_room_v1", false)) return
        runCatching {
            val oa = JSONArray(p.getString("open", "[]") ?: "[]")
            for (i in 0 until oa.length()) {
                val o = oa.getJSONObject(i)
                d.upsertOpen(
                    HsShadowOpenEntity(
                        o.getString("id"), o.getString("tf"), o.getLong("bar"), o.getDouble("entry"),
                        o.getString("dir"), o.getDouble("p"), o.getString("model")
                    )
                )
            }
            val a = JSONArray(p.getString("closed", "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                d.insertClosed(
                    HsShadowClosedEntity(
                        o.getString("id"), o.getString("tf"), o.getString("dir"), o.getDouble("p"),
                        o.getBoolean("win"), o.getDouble("ret"), o.getDouble("mfe"), o.getDouble("mae"),
                        o.getString("model"), o.optLong("at")
                    )
                )
            }
            d.trimClosed(maxRecords)
            p.edit().putBoolean("migrated_to_room_v1", true).remove("open").remove("closed").apply()
        }
    }

    private fun loadMemFromPrefs() {
        runCatching {
            val oa = JSONArray(prefs?.getString("open", "[]") ?: "[]")
            for (i in 0 until oa.length()) {
                val o = oa.getJSONObject(i)
                openMem[o.getString("id")] = Open(
                    o.getString("id"), o.getString("tf"), o.getLong("bar"), o.getDouble("entry"),
                    BtcDirection.valueOf(o.getString("dir")), o.getDouble("p"), o.getString("model")
                )
            }
            val a = JSONArray(prefs?.getString("closed", "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                closedMem.addLast(
                    Closed(
                        o.getString("id"), o.getString("tf"), BtcDirection.valueOf(o.getString("dir")),
                        o.getDouble("p"), o.getBoolean("win"), o.getDouble("ret"), o.getDouble("mfe"),
                        o.getDouble("mae"), o.getString("model"), o.optLong("at")
                    )
                )
            }
        }
    }

    private fun persistMem() {
        val p = prefs ?: return
        val oa = JSONArray()
        openMem.values.forEach { r ->
            oa.put(JSONObject().apply {
                put("id", r.id); put("tf", r.timeframe); put("bar", r.barId); put("entry", r.entry)
                put("dir", r.direction.name); put("p", r.probability); put("model", r.modelVersion)
            })
        }
        val a = JSONArray()
        closedMem.forEach { r ->
            a.put(JSONObject().apply {
                put("id", r.id); put("tf", r.timeframe); put("dir", r.direction.name); put("p", r.probability)
                put("win", r.outcome); put("ret", r.returnPct); put("mfe", r.mfePct); put("mae", r.maePct)
                put("model", r.modelVersion); put("at", r.closedAt)
            })
        }
        p.edit().putString("open", oa.toString()).putString("closed", a.toString()).apply()
    }
}
