package com.caifenxi.app.domain.btc.polymarket.strategy

import com.caifenxi.app.data.db.entity.PolymarketSnapshotEntity
import kotlin.math.sqrt

/** Measures directional co-movement so correlated strategies do not consume duplicate risk. */
object PolymarketStrategyCorrelationEngine {
    fun pearson(a: List<Double>, b: List<Double>): Double {
        val n = minOf(a.size, b.size)
        if (n < 4) return 0.0
        val aa = a.takeLast(n); val bb = b.takeLast(n)
        val ma = aa.average(); val mb = bb.average()
        var num = 0.0; var da = 0.0; var db = 0.0
        for (i in 0 until n) { val x = aa[i] - ma; val y = bb[i] - mb; num += x*y; da += x*x; db += y*y }
        val den = sqrt(da*db)
        return if (den <= 1e-12) 0.0 else (num/den).coerceIn(-1.0, 1.0)
    }

    fun redundancyPenalty(correlation: Double, threshold: Double = 0.80): Double {
        val a = kotlin.math.abs(correlation)
        if (a <= threshold) return 1.0
        return (1.0 - (a - threshold) / (1.0 - threshold) * 0.70).coerceIn(0.30, 1.0)
    }

    fun fromSnapshots(rows: List<PolymarketSnapshotEntity>): Map<Pair<String,String>,Double> {
        val byTime = rows.filter { it.strategyId != null && it.signalOutcome != null }
            .groupBy { it.capturedAtMs }
        val vectors = mutableMapOf<String, MutableList<Double>>()
        byTime.toSortedMap().values.forEach { batch ->
            val one = batch.associate { it.strategyId!! to if (it.signalOutcome.equals("YES", true)) 1.0 else -1.0 }
            val ids = rows.mapNotNull { it.strategyId }.distinct()
            ids.forEach { id -> vectors.getOrPut(id) { mutableListOf() }.add(one[id] ?: 0.0) }
        }
        return matrix(vectors)
    }

    fun matrix(history: Map<String, List<Double>>): Map<Pair<String,String>,Double> {
        val ids = history.keys.toList(); val out = mutableMapOf<Pair<String,String>,Double>()
        for (i in ids.indices) for (j in i+1 until ids.size) out[ids[i] to ids[j]] = pearson(history[ids[i]].orEmpty(), history[ids[j]].orEmpty())
        return out
    }
}
