package com.caifenxi.app.domain.btc

import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicReference

/** Realtime account/order cache. REST reconciliation remains authoritative after restart. */
class BinancePrivateEventStore {
    private val orders = ConcurrentHashMap<Long, BinancePrivateUserDataStream.OrderUpdate>()
    private val account = AtomicReference<BinancePrivateUserDataStream.AccountUpdate?>(null)
    @Volatile var lastEventTime: Long = 0L
        private set

    fun onOrder(update: BinancePrivateUserDataStream.OrderUpdate) { orders[update.orderId] = update; lastEventTime = maxOf(lastEventTime, update.eventTime) }
    fun onAccount(update: BinancePrivateUserDataStream.AccountUpdate) { account.set(update); lastEventTime = maxOf(lastEventTime, update.eventTime) }
    fun latestOrder(orderId: Long): BinancePrivateUserDataStream.OrderUpdate? = orders[orderId]
    fun latestOrders(): List<BinancePrivateUserDataStream.OrderUpdate> = orders.values.sortedByDescending { it.eventTime }.take(100)
    fun latestAccount(): BinancePrivateUserDataStream.AccountUpdate? = account.get()
    fun clear() { orders.clear(); account.set(null); lastEventTime = 0L }
}
