package com.caifenxi.app.service.btc

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.caifenxi.app.R
import com.caifenxi.app.domain.btc.broker.BrokerCredentialStore
import com.caifenxi.app.domain.btc.broker.BrokerFactory
import com.caifenxi.app.domain.btc.broker.DailyPnlStore
import com.caifenxi.app.domain.btc.broker.BinanceFuturesEndpoint
import com.caifenxi.app.domain.btc.broker.PaperPerpBroker
import com.caifenxi.app.domain.btc.futures.FuturesQuantConfigStore
import com.caifenxi.app.domain.btc.futures.FuturesExchangePositionStore
import com.caifenxi.app.domain.btc.runtime.BtcRunMode
import com.caifenxi.app.domain.btc.runtime.BtcRuntimeController
import com.caifenxi.app.domain.btc.runtime.BtcRuntimeStore
import com.caifenxi.app.domain.btc.runtime.BtcRuntimeStatus
import com.caifenxi.app.domain.btc.runtime.LiveUnattendedGuard
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Isolated background runtime for the Quant Futures page. It does not share binary-prediction runtime state. */
class FuturesQuantRuntimeService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var loopJob: Job? = null
    private lateinit var store: BtcRuntimeStore
    private lateinit var credStore: BrokerCredentialStore
    private lateinit var dailyPnl: DailyPnlStore
    private lateinit var futuresConfigStore: FuturesQuantConfigStore
    private lateinit var exchangePositionStore: FuturesExchangePositionStore

    override fun onCreate() {
        super.onCreate()
        store = BtcRuntimeStore(this, "btc_futures_runtime")
        credStore = BrokerCredentialStore(this)
        dailyPnl = DailyPnlStore(this)
        futuresConfigStore = FuturesQuantConfigStore(this)
        exchangePositionStore = FuturesExchangePositionStore(this)
        createChannel()
        startForeground(NOTIFICATION_ID, notification("BTC Quant · 合约初始化"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopRuntime()
            ACTION_KILL -> { store.setKillSwitch(true); stopRuntime() }
            ACTION_RESUME -> { store.setKillSwitch(false); startRuntime() }
            else -> startRuntime()
        }
        return START_STICKY
    }

    private fun startRuntime() {
        val cfg = store.config()
        val futuresCfg = futuresConfigStore.load()
        if (!cfg.enabled || futuresCfg.autoMode.not()) { stopRuntime(); return }
        val creds = credStore.load()
        val startGate = LiveUnattendedGuard.authorizeStart(cfg, creds, store.state())
        if (!startGate.allowed && cfg.runMode != BtcRunMode.PAPER) {
            store.update { it.copy(status = BtcRuntimeStatus.ERROR, lastError = startGate.reason) }
            updateNotification("启动拒绝: ${startGate.reason}")
            stopRuntime(); return
        }
        if (loopJob?.isActive == true) return
        store.update { it.copy(status = BtcRuntimeStatus.RUNNING, lastError = null, consecutiveErrors = 0) }
        val broker = when (cfg.runMode) {
            BtcRunMode.PAPER -> PaperPerpBroker()
            BtcRunMode.TESTNET, BtcRunMode.LIVE -> {
                val expected = if (cfg.runMode == BtcRunMode.TESTNET) BinanceFuturesEndpoint.TESTNET else BinanceFuturesEndpoint.MAINNET
                if (creds.binanceEndpoint != expected) {
                    store.update { it.copy(status = BtcRuntimeStatus.ERROR, lastError = "${cfg.runMode.name} 模式 endpoint 不匹配") }
                    stopRuntime(); return
                }
                runCatching { BrokerFactory.perp(creds) }.getOrElse { e ->
                    store.update { it.copy(status = BtcRuntimeStatus.ERROR, lastError = e.message ?: "Broker 初始化失败") }
                    stopRuntime(); return
                }
            }
        }
        loopJob = scope.launch {
            val controller = BtcRuntimeController(
                store = store,
                broker = broker,
                dayRealizedPnlProvider = { dailyPnl.realizedPnlToday() },
                futuresConfigProvider = { futuresConfigStore.load() }
            )
            while (isActive && !store.state().killSwitch && store.config().enabled && futuresConfigStore.load().autoMode) {
                // Reconcile the exchange position before strategy execution. This makes the
                // exchange the source of truth after app restart, network loss, manual exchange
                // trades, partial fills, or an external close.
                val reconciliationOk = runCatching {
                    val risk = broker.fetchPositionRisk(futuresCfg.symbol)
                    val source = if (cfg.runMode == BtcRunMode.PAPER) "PAPER" else cfg.runMode.name
                    exchangePositionStore.save(risk, source)
                    true
                }.getOrElse { e ->
                    store.update {
                        it.copy(
                            status = if (cfg.runMode == BtcRunMode.PAPER) it.status else BtcRuntimeStatus.PAUSED,
                            lastError = "仓位对账失败，执行已阻断：${e.message ?: "unknown"}",
                            consecutiveErrors = it.consecutiveErrors + 1
                        )
                    }
                    updateNotification("执行阻断 · 仓位对账失败")
                    false
                }
                if (!reconciliationOk && cfg.runMode != BtcRunMode.PAPER) {
                    val st = store.state()
                    if (st.consecutiveErrors >= store.config().maxConsecutiveErrors) {
                        store.setKillSwitch(true)
                        updateNotification("合约熔断: ${st.lastError ?: "连续对账失败"}")
                        break
                    }
                    delay(store.config().pollSeconds.coerceIn(5L, 120L) * 1000L)
                    continue
                }
                runCatching { controller.runOnce() }.onFailure { e ->
                    store.update { it.copy(lastError = e.message ?: "futures loop error", consecutiveErrors = it.consecutiveErrors + 1) }
                }
                runCatching {
                    val risk = broker.fetchPositionRisk(futuresCfg.symbol)
                    val source = if (cfg.runMode == BtcRunMode.PAPER) "PAPER" else cfg.runMode.name
                    exchangePositionStore.save(risk, source)
                }
                val st = store.state()
                val c = store.config()
                if (st.killSwitch || (st.consecutiveErrors >= c.maxConsecutiveErrors && c.runMode != BtcRunMode.PAPER)) {
                    store.setKillSwitch(true)
                    updateNotification("合约熔断: ${st.lastError ?: "连续失败"}")
                    break
                }
                delay(c.pollSeconds.coerceIn(5L, 120L) * 1000L)
            }
            stopRuntime()
        }
        updateNotification("BTC Quant · 合约挂机 · ${futuresCfg.symbol} · ${futuresCfg.leverage}x · ${cfg.runMode.name}")
    }

    private fun stopRuntime() {
        loopJob?.cancel(); loopJob = null
        val killed = store.state().killSwitch
        store.update { it.copy(status = if (killed) BtcRuntimeStatus.KILLED else BtcRuntimeStatus.STOPPED) }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { loopJob?.cancel(); scope.cancel(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "BTC Quant Futures", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }
    private fun notification(text: String): Notification = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(R.drawable.ic_launcher).setContentTitle("BTC Quant · 合约").setContentText(text)
        .setOngoing(true).setCategory(NotificationCompat.CATEGORY_SERVICE).build()
    private fun updateNotification(text: String) = getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(text))

    companion object {
        const val ACTION_STOP = "com.caifenxi.btcquant.FUTURES_STOP"
        const val ACTION_KILL = "com.caifenxi.btcquant.FUTURES_KILL"
        const val ACTION_RESUME = "com.caifenxi.btcquant.FUTURES_RESUME"
        private const val CHANNEL_ID = "btc_quant_futures_runtime"
        private const val NOTIFICATION_ID = 4202
    }
}
