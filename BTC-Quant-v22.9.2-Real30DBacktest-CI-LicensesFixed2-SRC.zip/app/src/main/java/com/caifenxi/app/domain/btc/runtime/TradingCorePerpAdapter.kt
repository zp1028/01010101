package com.caifenxi.app.domain.btc.runtime

import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.TradingSignal
import com.caifenxi.app.domain.btc.broker.BrokerOrderResult

/**
 * Canonical v22.5/v22.6 bridge from TradingCore to the venue execution gateway.
 * The gateway remains the only venue-write boundary; this adapter makes TradingCore
 * the actual authorization/dispatch entry point instead of a documentation-only layer.
 */
class TradingCorePerpAdapter(
    override val mode: TradingMode,
    private val gateway: UnifiedExecutionGateway
) : TradingCoreAdapter {
    override suspend fun submit(intent: TradingCoreIntent): ExecutionResult {
        val direction = if (intent.side == OrderSide.BUY) BtcDirection.UP else BtcDirection.DOWN
        val signal = TradingSignal.ContractSignal(
            planId = intent.metadata["planId"] ?: "TRADING-CORE",
            barId = intent.metadata["barId"]?.toLongOrNull() ?: System.currentTimeMillis(),
            symbol = intent.symbol,
            direction = direction,
            probability = intent.metadata["probability"]?.toDoubleOrNull() ?: 0.5,
            expectedMovePct = intent.metadata["expectedMovePct"]?.toDoubleOrNull() ?: 0.0,
            entry = intent.price,
            stopLoss = intent.metadata["stopLoss"]?.toDoubleOrNull() ?: intent.price,
            takeProfit = intent.metadata["takeProfit"]?.toDoubleOrNull() ?: intent.price,
            horizonBars = intent.metadata["horizonBars"]?.toIntOrNull() ?: 1,
            positionSize = intent.quantity,
            leverageCap = intent.metadata["leverage"]?.toIntOrNull() ?: 1,
            confidence = intent.metadata["confidence"]?.toDoubleOrNull() ?: 0.5,
            reasonPlanIds = listOfNotNull(intent.metadata["planId"])
        )
        return map(gateway.placePerp(signal, intent.clientId), intent)
    }

    private fun map(result: BrokerOrderResult, intent: TradingCoreIntent): ExecutionResult {
        val status = when {
            result.status.equals("UNKNOWN", true) -> OrderStatus.UNKNOWN
            result.status.contains("CANCEL", true) -> OrderStatus.CANCELED
            result.status.contains("REJECT", true) || !result.success -> OrderStatus.REJECTED
            result.status.contains("PARTIAL", true) -> OrderStatus.PARTIAL
            result.status.contains("FILLED", true) || result.status.contains("PAPER_FILLED", true) -> OrderStatus.FILLED
            else -> OrderStatus.OPEN
        }
        return ExecutionResult(
            status = status,
            clientId = intent.clientId,
            orderId = result.orderId?.toString() ?: "UNKNOWN-${intent.clientId}",
            message = result.message.ifBlank { result.status }
        )
    }
}
