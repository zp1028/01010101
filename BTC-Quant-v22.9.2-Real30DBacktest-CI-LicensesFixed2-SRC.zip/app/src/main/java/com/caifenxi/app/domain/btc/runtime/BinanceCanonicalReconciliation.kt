package com.caifenxi.app.domain.btc.runtime

import com.caifenxi.app.domain.btc.BinancePrivateEventStore
import com.caifenxi.app.domain.btc.broker.PerpBroker

/**
 * Single bridge from Binance private WS/REST observations into the canonical order state.
 * WS accelerates state projection; REST recovery remains authoritative when state is uncertain.
 */
class BinanceCanonicalReconciliation(
    private val journal: BinanceExecutionJournal,
    private val privateEvents: BinancePrivateEventStore? = null
) {
    fun applyPrivateEvents() {
        val store = privateEvents ?: return
        journal.all().forEach { entry ->
            val update = entry.orderId?.let { store.latestOrder(it) }
                ?: store.latestOrders().firstOrNull { it.clientOrderId == entry.clientOrderId }
                ?: return@forEach
            val mapped = when (update.status.uppercase()) {
                "NEW", "ACCEPTED" -> CanonicalOrderState.OPEN
                "PARTIALLY_FILLED" -> CanonicalOrderState.PARTIAL
                "FILLED" -> CanonicalOrderState.FILLED
                "CANCELED" -> CanonicalOrderState.CANCELED
                "EXPIRED" -> CanonicalOrderState.EXPIRED
                "REJECTED" -> CanonicalOrderState.REJECTED
                "PENDING_CANCEL" -> CanonicalOrderState.CANCEL_REQUESTED
                else -> CanonicalOrderState.UNKNOWN
            }
            if (mapped != CanonicalOrderState.UNKNOWN) {
                journal.updateState(entry.clientOrderId, mapped, update.orderId, "privateWS:${update.status}/${update.executionType}")
            }
        }
    }

    suspend fun reconcileUnknowns(broker: PerpBroker, uncertainty: ExecutionUncertaintyStore): Boolean {
        var clean = true
        journal.all().forEach { entry ->
            if (entry.state != CanonicalOrderState.UNKNOWN && entry.state != CanonicalOrderState.SUBMITTING) return@forEach
            val result = runCatching { broker.queryOrderStatus(entry.symbol, entry.orderId, entry.clientOrderId) }.getOrNull()
            if (result == null) { clean = false; return@forEach }
            val mapped = when (result.status.uppercase()) {
                "NEW", "OPEN", "ACCEPTED" -> CanonicalOrderState.OPEN
                "PARTIALLY_FILLED", "PARTIAL" -> CanonicalOrderState.PARTIAL
                "FILLED", "PAPER_FILLED" -> CanonicalOrderState.FILLED
                "CANCELED", "CANCELLED" -> CanonicalOrderState.CANCELED
                "EXPIRED" -> CanonicalOrderState.EXPIRED
                "REJECTED" -> CanonicalOrderState.REJECTED
                else -> CanonicalOrderState.UNKNOWN
            }
            if (mapped == CanonicalOrderState.UNKNOWN) {
                clean = false
            } else {
                journal.updateState(entry.clientOrderId, mapped, result.orderId, result.message)
                if (mapped != CanonicalOrderState.UNKNOWN) uncertainty.resolve(entry.clientOrderId)
                if (mapped == CanonicalOrderState.FILLED || mapped == CanonicalOrderState.OPEN || mapped == CanonicalOrderState.PARTIAL) clean = false
            }
        }
        return clean
    }
}
