package com.caifenxi.app.domain.btc.runtime

import java.util.UUID
import java.util.concurrent.CopyOnWriteArrayList

data class TradingEventEnvelope(
    val eventId: String = UUID.randomUUID().toString(),
    val eventType: String,
    val source: String,
    val timestampMs: Long,
    val sequence: Long,
    val correlationId: String? = null,
    val causationId: String? = null,
    val symbol: String? = null,
    val account: String? = null,
    val mode: TradingMode = TradingMode.PAPER,
    val payload: Map<String, String> = emptyMap()
)

class TradingEventLedger(private val limit: Int = 1000) {
    private val events = ArrayDeque<TradingEventEnvelope>()
    private var sequence = 0L
    private val listeners = CopyOnWriteArrayList<(TradingEventEnvelope) -> Unit>()
    @Synchronized fun append(event: TradingEventEnvelope): TradingEventEnvelope {
        val normalized = if (event.sequence <= sequence) event.copy(sequence = sequence + 1) else event
        sequence = normalized.sequence
        events.addLast(normalized)
        while (events.size > limit.coerceAtLeast(10)) events.removeFirst()
        listeners.forEach { it(normalized) }
        return normalized
    }
    fun subscribe(listener: (TradingEventEnvelope) -> Unit): () -> Unit { listeners += listener; return { listeners -= listener } }
    @Synchronized fun recent(count: Int = 100): List<TradingEventEnvelope> = events.takeLast(count.coerceIn(1, limit))
}
