package com.caifenxi.app.domain.btc.polymarket.strategy

import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.factor.QuantFactorEngine
import com.caifenxi.app.domain.btc.polymarket.PolyMarket
import com.caifenxi.app.domain.btc.polymarket.PolyOrderBook
import kotlin.math.abs

/**
 * Polymarket strategy registry. Public GitHub strategy ideas are reimplemented
 * natively and kept as provenance metadata; no repository source files are copied.
 */
object PolymarketStrategyPool {
    private val runtimeWeights = java.util.concurrent.ConcurrentHashMap<String, Double>()
    private val runtimeStatuses = java.util.concurrent.ConcurrentHashMap<String, Status>()
    enum class Status { CANDIDATE, SHADOW, ACTIVE, DOWNWEIGHT, RETIRED }
    enum class Family { BTC_MOMENTUM, ARBITRAGE, ORDERBOOK, MARKET_MAKING, CONVERGENCE, FLOW, CROSS_MARKET }

    data class Definition(
        val id: String,
        val name: String,
        val family: Family,
        val sourceRepo: String,
        val sourceCommit: String,
        val sourceLicense: String,
        val status: Status = Status.CANDIDATE,
        val baseWeight: Double = 1.0,
        val requiredFactors: List<String> = emptyList(),
        val implementation: String = "NATIVE_REIMPLEMENTATION"
    )

    data class Signal(
        val strategyId: String,
        val marketId: String,
        val outcome: String,
        val direction: BtcDirection,
        val modelProbability: Double,
        val marketPrice: Double,
        val edge: Double,
        val spread: Double,
        val liquidity: Double,
        val score: Double,
        val reason: String,
        val windowId: String = ""
    )

    private const val RADIOMAN = "radioman/polymarket-arbitrage-trading-bot"
    private const val EMMANUEL = "emmanuelwestra/Polymarket-Trading-Bot"
    private const val HUMMINGBOT = "hummingbot/hummingbot"
    private const val FREQTRADE = "freqtrade/freqtrade"

    // Pinned public revisions used as provenance references for the reimplemented rules.
    private const val RADIOMAN_COMMIT = "5de61adfe65f4689987e5e8997577148d986ad64"
    private const val EMMANUEL_COMMIT = "54e80a6b6ac6551db458380e14d10b14d777ce3c"
    private const val HUMMINGBOT_COMMIT = "2bfaccc48dd49e71a5b6d9b3011808e127dd00cd"
    private const val FREQTRADE_COMMIT = "eec4eb074bd919d405fb60be8eaee49d3a49b511"

    val definitions: List<Definition> = listOf(
        Definition("PM-BTC-MOMENTUM", "BTC Momentum", Family.BTC_MOMENTUM, RADIOMAN, RADIOMAN_COMMIT, "Flat Earth License", Status.SHADOW, 1.0, listOf("RET-5", "RET-20", "MOMENTUM-COMPOSITE")),
        Definition("PM-BTC-AND-ODDS", "BTC + Odds Agreement", Family.BTC_MOMENTUM, RADIOMAN, RADIOMAN_COMMIT, "Flat Earth License", Status.SHADOW, 1.0),
        Definition("PM-BTC-OR-ODDS", "BTC or Odds", Family.BTC_MOMENTUM, RADIOMAN, RADIOMAN_COMMIT, "Flat Earth License", Status.SHADOW, 0.8),
        Definition("PM-BTC-MEAN-REVERT", "BTC Mean Revert", Family.BTC_MOMENTUM, RADIOMAN, RADIOMAN_COMMIT, "Flat Earth License", Status.SHADOW, 0.9, listOf("MEAN-REVERSION", "PRICE-Z-30")),
        Definition("PM-ODDS-FAVORITE", "Odds Favorite", Family.CONVERGENCE, RADIOMAN, RADIOMAN_COMMIT, "Flat Earth License", Status.SHADOW, 0.9),
        Definition("PM-CONTRARIAN", "Contrarian", Family.CONVERGENCE, RADIOMAN, RADIOMAN_COMMIT, "Flat Earth License", Status.SHADOW, 0.7),
        Definition("PM-CROSS-MARKET-ARB", "Cross Market Arbitrage", Family.ARBITRAGE, EMMANUEL, EMMANUEL_COMMIT, "UNVERIFIED", Status.CANDIDATE, 1.2),
        Definition("PM-MISPRICING-ARB", "Mispricing Arbitrage", Family.ARBITRAGE, EMMANUEL, EMMANUEL_COMMIT, "UNVERIFIED", Status.SHADOW, 1.1),
        Definition("PM-COMPLEMENT-ARB", "YES/NO Complement", Family.ARBITRAGE, EMMANUEL, EMMANUEL_COMMIT, "UNVERIFIED", Status.SHADOW, 1.1),
        Definition("PM-HIGH-PROB-CONVERGENCE", "High Probability Convergence", Family.CONVERGENCE, EMMANUEL, EMMANUEL_COMMIT, "UNVERIFIED", Status.SHADOW, 0.9),
        Definition("PM-PRICE-CONVERGENCE", "Price Convergence", Family.CONVERGENCE, EMMANUEL, EMMANUEL_COMMIT, "UNVERIFIED", Status.CANDIDATE, 0.8),
        Definition("PM-TIME-DECAY", "Time Decay", Family.CONVERGENCE, EMMANUEL, EMMANUEL_COMMIT, "UNVERIFIED", Status.CANDIDATE, 0.8),
        Definition("PM-SPREAD", "Spread Capture", Family.ORDERBOOK, EMMANUEL, EMMANUEL_COMMIT, "UNVERIFIED", Status.SHADOW, 0.7),
        Definition("PM-DEPTH", "Depth Pressure", Family.ORDERBOOK, EMMANUEL, EMMANUEL_COMMIT, "UNVERIFIED", Status.SHADOW, 0.8),
        Definition("PM-IMBALANCE", "Orderbook Imbalance", Family.ORDERBOOK, EMMANUEL, EMMANUEL_COMMIT, "UNVERIFIED", Status.SHADOW, 1.0),
        Definition("PM-MICROPRICE", "Microprice", Family.ORDERBOOK, EMMANUEL, EMMANUEL_COMMIT, "UNVERIFIED", Status.SHADOW, 1.0),
        Definition("PM-ORDERFLOW", "Orderflow Pressure", Family.ORDERBOOK, EMMANUEL, EMMANUEL_COMMIT, "UNVERIFIED", Status.CANDIDATE, 0.8),
        Definition("PM-TRADE-VELOCITY", "Trade Velocity", Family.FLOW, EMMANUEL, EMMANUEL_COMMIT, "UNVERIFIED", Status.CANDIDATE, 0.7),
        Definition("PM-MARKET-MAKER", "Market Maker", Family.MARKET_MAKING, HUMMINGBOT, HUMMINGBOT_COMMIT, "Apache-2.0", Status.CANDIDATE, 0.6),
        Definition("PM-DYNAMIC-SPREAD", "Dynamic Spread", Family.MARKET_MAKING, HUMMINGBOT, HUMMINGBOT_COMMIT, "Apache-2.0", Status.CANDIDATE, 0.7),
        Definition("PM-INVENTORY-MM", "Inventory Aware MM", Family.MARKET_MAKING, HUMMINGBOT, HUMMINGBOT_COMMIT, "Apache-2.0", Status.CANDIDATE, 0.6),
        Definition("PM-ADAPTIVE-QUOTE", "Adaptive Quote", Family.MARKET_MAKING, HUMMINGBOT, HUMMINGBOT_COMMIT, "Apache-2.0", Status.CANDIDATE, 0.6),
        Definition("PM-WHALE-FOLLOW", "Whale Follow", Family.FLOW, EMMANUEL, EMMANUEL_COMMIT, "UNVERIFIED", Status.CANDIDATE, 0.6),
        Definition("PM-WHALE-INVERSE", "Whale Inverse", Family.FLOW, EMMANUEL, EMMANUEL_COMMIT, "UNVERIFIED", Status.CANDIDATE, 0.5),
        Definition("PM-WHALE-CLUSTER", "Whale Cluster", Family.FLOW, EMMANUEL, EMMANUEL_COMMIT, "UNVERIFIED", Status.CANDIDATE, 0.5),
        Definition("PM-LARGE-TRADE-FLOW", "Large Trade Flow", Family.FLOW, EMMANUEL, EMMANUEL_COMMIT, "UNVERIFIED", Status.CANDIDATE, 0.6),
        Definition("PM-WALLET-CONSENSUS", "Wallet Consensus", Family.FLOW, EMMANUEL, EMMANUEL_COMMIT, "UNVERIFIED", Status.CANDIDATE, 0.5),
        Definition("PM-BINANCE-FAIR-VALUE", "Binance Fair Value", Family.CROSS_MARKET, FREQTRADE, FREQTRADE_COMMIT, "GPL-3.0", Status.SHADOW, 1.0),
        Definition("PM-BINANCE-ORDERBOOK", "Binance Orderbook Gap", Family.CROSS_MARKET, HUMMINGBOT, HUMMINGBOT_COMMIT, "Apache-2.0", Status.SHADOW, 0.9),
        Definition("PM-BINANCE-FUNDING", "Funding Regime Gap", Family.CROSS_MARKET, FREQTRADE, FREQTRADE_COMMIT, "GPL-3.0", Status.SHADOW, 0.8),
        Definition("PM-BINANCE-OI", "Open Interest Gap", Family.CROSS_MARKET, FREQTRADE, FREQTRADE_COMMIT, "GPL-3.0", Status.SHADOW, 0.8)
    )

    fun activeDefinitions(): List<Definition> = definitions.filter {
        val status = runtimeStatuses[it.id] ?: it.status
        status == Status.ACTIVE || status == Status.SHADOW
    }

    fun applyLifecycle(decisions: List<com.caifenxi.app.domain.btc.polymarket.research.PolymarketStrategyLifecycleEngine.Decision>) {
        decisions.forEach { d ->
            runtimeStatuses[d.strategyId] = d.status
            runtimeWeights[d.strategyId] = d.weightMultiplier.coerceIn(0.0, 3.0)
        }
    }

    fun runtimeWeight(definition: Definition): Double =
        definition.baseWeight * (runtimeWeights[definition.id] ?: 1.0)

    fun evaluate(
        market: PolyMarket,
        yesBook: PolyOrderBook,
        noBook: PolyOrderBook?,
        factors: QuantFactorEngine.Snapshot,
        externalModelYes: Double? = null,
        currentBtc: Double? = null,
        nowMs: Long = System.currentTimeMillis(),
        btcReturn15m: Double = 0.0,
        volumeRatio: Double = 1.0
    ): List<Signal> {
        val modelYes = (externalModelYes ?: modelFromFactors(factors)).coerceIn(0.01, 0.99)
        val yesAsk = yesBook.bestAsk ?: market.yesPrice
        val noAsk = noBook?.bestAsk ?: market.noPrice
        val yes = outcomeSignal("YES", market.yesTokenId, yesBook, modelYes, market, factors, nowMs)
        val no = noBook?.let { outcomeSignal("NO", market.noTokenId, it, 1.0 - modelYes, market, factors, nowMs) }
        val upPrice = (yesBook.mid ?: market.yesPrice).coerceIn(0.0, 1.0)
        val downPrice = (noBook?.mid ?: market.noPrice).coerceIn(0.0, 1.0)
        val elapsed = market.startDateMs?.let { ((nowMs - it) / 1000L).coerceAtLeast(0L) }
        val remaining = market.endDateMs?.let { ((it - nowMs) / 1000L).coerceAtLeast(0L) }
        val ctx = PolymarketGithubStrategyLogic.Context(
            currentBtc = currentBtc,
            priceToBeat = market.priceToBeat,
            elapsedSec = elapsed,
            remainingSec = remaining,
            upPrice = upPrice,
            downPrice = downPrice,
            btcReturn15m = btcReturn15m,
            volumeRatio = volumeRatio,
            orderbookImbalance = orderbookImbalance(yesBook),
            spread = yesBook.spread
        )
        val cfg = PolymarketGithubStrategyLogic.Config()
        val inWindow = PolymarketGithubStrategyLogic.entryWindowOpen(ctx, cfg)
        val windowId = "${market.conditionId}:${market.startDateMs ?: 0L}"
        val out = mutableListOf<Signal>()

        fun emit(defId: String, decision: PolymarketGithubStrategyLogic.Decision?, candidate: Signal?) {
            val def = definitions.firstOrNull { it.id == defId } ?: return
            val status = runtimeStatuses[def.id] ?: def.status
            // CANDIDATE/RETIRED remain research-only. DOWNWEIGHT is also removed from
            // automatic entry until a later OOS refresh promotes it back to SHADOW/ACTIVE.
            if (status != Status.ACTIVE && status != Status.SHADOW) return
            if (decision == null || candidate == null) return
            if (!inWindow && def.family != Family.ARBITRAGE && def.family != Family.ORDERBOOK) return
            val target = if (decision.direction == BtcDirection.UP) candidateForDirection(yes, yes) else candidateForDirection(no, no)
            if (target == null) return
            val maxEntry = cfg.maxEntryOdds
            if (target.marketPrice > maxEntry && def.family != Family.ARBITRAGE) return
            val factorBias = familyFactorBias(def.family, factors, yesBook)
            val aligned = if ((target.direction == BtcDirection.UP && factorBias >= 0) || (target.direction == BtcDirection.DOWN && factorBias < 0)) abs(factorBias) else 0.0
            val score = (target.edge * runtimeWeight(def) + decision.ruleScore * 0.10 + aligned * 0.05).coerceAtLeast(0.0)
            out += target.copy(strategyId = def.id, score = score, reason = "${def.name}: ${decision.reason}; ${target.reason}", windowId = windowId)
        }

        emit("PM-BTC-MOMENTUM", PolymarketGithubStrategyLogic.btcMomentum(ctx, cfg), yes)
        emit("PM-BTC-AND-ODDS", PolymarketGithubStrategyLogic.btcAndOdds(ctx, cfg), yes)
        emit("PM-BTC-OR-ODDS", PolymarketGithubStrategyLogic.btcOrOdds(ctx, cfg), yes)
        emit("PM-BTC-MEAN-REVERT", PolymarketGithubStrategyLogic.btcMeanRevert(ctx, cfg), yes)
        emit("PM-ODDS-FAVORITE", PolymarketGithubStrategyLogic.oddsFavorite(ctx, cfg), yes)
        emit("PM-CONTRARIAN", PolymarketGithubStrategyLogic.contrarian(ctx, cfg), yes)
        emit("PM-HIGH-PROB-CONVERGENCE", PolymarketGithubStrategyLogic.highProbabilityConvergence(ctx, cfg), yes)
        emit("PM-MISPRICING-ARB", PolymarketGithubStrategyLogic.mispricing(yesAsk, noAsk), yes)
        emit("PM-COMPLEMENT-ARB", PolymarketGithubStrategyLogic.mispricing(yesAsk, noAsk), yes)
        emit("PM-MARKET-MAKER", marketMakerDecision(ctx), yes)
        emit("PM-DYNAMIC-SPREAD", marketMakerDecision(ctx), yes)
        emit("PM-INVENTORY-MM", marketMakerDecision(ctx), yes)
        emit("PM-ADAPTIVE-QUOTE", marketMakerDecision(ctx), yes)
        emit("PM-BINANCE-FAIR-VALUE", crossMarketDecision(factors, modelYes), yes)
        emit("PM-BINANCE-ORDERBOOK", crossMarketDecision(factors, modelYes), yes)
        emit("PM-BINANCE-FUNDING", crossMarketDecision(factors, modelYes), yes)
        emit("PM-BINANCE-OI", crossMarketDecision(factors, modelYes), yes)

        return out.sortedByDescending { it.score }
    }

    private fun candidateForDirection(signal: Signal?, fallback: Signal?): Signal? = signal ?: fallback

    private fun outcomeSignal(outcome: String, tokenId: String, book: PolyOrderBook, modelP: Double, market: PolyMarket, factors: QuantFactorEngine.Snapshot, nowMs: Long): Signal {
        val ask = book.bestAsk ?: if (outcome == "YES") market.yesPrice else market.noPrice
        val depth = book.bids.take(5).sumOf { it.size } + book.asks.take(5).sumOf { it.size }
        val liquidity = (depth / 500.0).coerceIn(0.0, 1.0)
        val edge = modelP - ask - book.spread * 0.5
        val direction = if (outcome == "YES") BtcDirection.UP else BtcDirection.DOWN
        return Signal("BASE", market.conditionId, outcome, direction, modelP, ask, edge, book.spread, liquidity, abs(edge) * (0.5 + liquidity * 0.5), "model=${"%.3f".format(modelP)} ask=${"%.3f".format(ask)} edge=${"%.3f".format(edge)}")
    }

    private fun familyFactorBias(family: Family, f: QuantFactorEngine.Snapshot, book: PolyOrderBook): Double = when (family) {
        Family.BTC_MOMENTUM -> f.value("MOMENTUM-COMPOSITE")
        Family.CONVERGENCE -> -f.value("MEAN-REVERSION")
        Family.ORDERBOOK -> orderbookImbalance(book)
        Family.ARBITRAGE -> f.value("DERIVATIVES-COMPOSITE")
        Family.MARKET_MAKING -> (1.0 - book.spread * 10.0).coerceIn(0.0, 1.0)
        Family.FLOW -> f.value("VOLUME-Z-30")
        Family.CROSS_MARKET -> f.composite
    }

    private fun marketMakerDecision(ctx: PolymarketGithubStrategyLogic.Context): PolymarketGithubStrategyLogic.Decision? {
        if (ctx.spread <= 0.0 || ctx.spread > 0.06) return null
        return if (ctx.orderbookImbalance >= 0.10) PolymarketGithubStrategyLogic.Decision(BtcDirection.UP, "market-making inventory skew +imbalance", 0.35)
        else if (ctx.orderbookImbalance <= -0.10) PolymarketGithubStrategyLogic.Decision(BtcDirection.DOWN, "market-making inventory skew -imbalance", 0.35)
        else null
    }

    private fun crossMarketDecision(f: QuantFactorEngine.Snapshot, modelYes: Double): PolymarketGithubStrategyLogic.Decision? {
        return when {
            f.composite > 0.18 && modelYes >= 0.55 -> PolymarketGithubStrategyLogic.Decision(BtcDirection.UP, "Binance fair-value factor gap", 0.45)
            f.composite < -0.18 && modelYes <= 0.45 -> PolymarketGithubStrategyLogic.Decision(BtcDirection.DOWN, "Binance fair-value factor gap", 0.45)
            else -> null
        }
    }

    private fun modelFromFactors(f: QuantFactorEngine.Snapshot): Double = (0.5 + f.composite * 0.28).coerceIn(0.05, 0.95)

    private fun orderbookImbalance(book: PolyOrderBook): Double {
        val bid = book.bids.take(10).sumOf { it.size }
        val ask = book.asks.take(10).sumOf { it.size }
        return if (bid + ask <= 0) 0.0 else (bid - ask) / (bid + ask)
    }
}
