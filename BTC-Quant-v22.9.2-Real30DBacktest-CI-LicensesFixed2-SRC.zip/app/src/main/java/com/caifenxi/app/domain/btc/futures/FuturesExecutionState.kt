package com.caifenxi.app.domain.btc.futures

/**
 * Exchange reconciliation state for one strategy execution cycle.
 * Exchange data is authoritative; local state is only a cache.
 */
enum class FuturesExecutionState {
    FLAT,
    ENTRY_PENDING,
    OPEN_UNPROTECTED,
    PROTECTED,
    PARTIAL_PROTECTION,
    EXIT_PENDING,
    CLOSED,
    ORPHAN_PROTECTION,
    DRIFT,
    STALE,
    ERROR
}

data class FuturesExecutionSnapshot(
    val state: FuturesExecutionState = FuturesExecutionState.FLAT,
    val symbol: String = "BTCUSDT",
    val positionQty: Double = 0.0,
    val positionSide: PositionSide = PositionSide.EMPTY,
    val entryPrice: Double = 0.0,
    val markPrice: Double = 0.0,
    val notional: Double = 0.0,
    val unrealizedPnl: Double = 0.0,
    val liquidationPrice: Double = 0.0,
    val leverage: Int = 1,
    val slOrderIds: List<Long> = emptyList(),
    val tpOrderIds: List<Long> = emptyList(),
    val trailingOrderIds: List<Long> = emptyList(),
    val lastSyncAt: Long = 0L,
    val lastError: String? = null
)

object FuturesExecutionStateMachine {
    fun from(
        position: PositionRiskInfo?,
        orders: List<FuturesOpenOrder>,
        reconciliation: PositionReconciliation,
        now: Long = System.currentTimeMillis()
    ): FuturesExecutionSnapshot {
        if (reconciliation.state == ReconciliationState.ERROR) {
            return FuturesExecutionSnapshot(state = FuturesExecutionState.ERROR, lastSyncAt = now, lastError = reconciliation.error)
        }
        if (reconciliation.state == ReconciliationState.STALE) {
            return FuturesExecutionSnapshot(state = FuturesExecutionState.STALE, lastSyncAt = reconciliation.lastSuccessfulSyncAt)
        }
        val protective = orders.filter { it.reduceOnly && it.type != FuturesOrderType.MARKET }
        if (position == null || !position.isOpen) {
            return FuturesExecutionSnapshot(
                state = if (protective.isEmpty()) FuturesExecutionState.FLAT else FuturesExecutionState.ORPHAN_PROTECTION,
                symbol = position?.symbol ?: "BTCUSDT",
                slOrderIds = protective.filter { it.type == FuturesOrderType.STOP_MARKET }.map { it.orderId },
                tpOrderIds = protective.filter { it.type == FuturesOrderType.TAKE_PROFIT_MARKET }.map { it.orderId },
                trailingOrderIds = protective.filter { it.type == FuturesOrderType.TRAILING_STOP_MARKET }.map { it.orderId },
                lastSyncAt = now
            )
        }
        val qty = kotlin.math.abs(position.positionAmt)
        val sl = protective.filter { it.type == FuturesOrderType.STOP_MARKET }
        val tp = protective.filter { it.type == FuturesOrderType.TAKE_PROFIT_MARKET }
        val trail = protective.filter { it.type == FuturesOrderType.TRAILING_STOP_MARKET }
        val hasSl = sl.any { it.origQty + 0.0000005 >= qty }
        val hasTp = tp.any { it.origQty + 0.0000005 >= qty } || trail.any { it.origQty + 0.0000005 >= qty }
        val state = when {
            reconciliation.state == ReconciliationState.DRIFT -> FuturesExecutionState.DRIFT
            hasSl && hasTp -> FuturesExecutionState.PROTECTED
            protective.isNotEmpty() -> FuturesExecutionState.PARTIAL_PROTECTION
            else -> FuturesExecutionState.OPEN_UNPROTECTED
        }
        return FuturesExecutionSnapshot(
            state = state,
            symbol = position.symbol,
            positionQty = qty,
            positionSide = when {
                position.positionAmt > 0.0 -> PositionSide.LONG
                position.positionAmt < 0.0 -> PositionSide.SHORT
                else -> PositionSide.EMPTY
            },
            entryPrice = position.entryPrice,
            markPrice = position.markPrice,
            notional = kotlin.math.abs(position.notional),
            unrealizedPnl = position.unRealizedProfit,
            liquidationPrice = position.liquidationPrice,
            leverage = position.leverage.toIntOrNull()?.coerceAtLeast(1) ?: 1,
            slOrderIds = sl.map { it.orderId },
            tpOrderIds = tp.map { it.orderId },
            trailingOrderIds = trail.map { it.orderId },
            lastSyncAt = now
        )
    }
}
