package com.caifenxi.app.domain.btc.hs

import com.caifenxi.app.domain.btc.BtcCandle
import kotlin.math.abs
import kotlin.math.max

/** v18.4: attributes degradation to observable feature, model, strategy and regime drift.
 * Recovery is evidence based: a source cannot recover from a timer alone; it needs fresh OOS feedback.
 */
object FusionDriftAttributionEngine {
    enum class State { STABLE, WATCH, DEGRADED, RECOVERING }
    data class Result(
        val state: State,
        val featureDrift: Double,
        val modelDrift: Double,
        val strategyDrift: Double,
        val regimeDrift: Double,
        val confidence: Double,
        val reason: String
    )

    fun evaluate(
        candles: List<BtcCandle>,
        metrics: FusionFeedbackStore.Metrics,
        components: FusionFeedbackStore.ComponentMetrics,
        currentRegime: String,
        baselineRegime: String? = null,
        minSamples: Int = 30
    ): Result {
        if (candles.size < 40 || metrics.samples < minSamples) {
            return Result(State.WATCH, 0.0, 0.0, 0.0, if (baselineRegime != null && baselineRegime != currentRegime) .12 else 0.0,
                0.35, "fresh OOS feedback insufficient")
        }
        val featureDrift = featureDrift(candles)
        val modelDrift = (metrics.recentBrier - metrics.baselineBrier).coerceIn(-.25, .5).let { max(0.0, it) }
        val strategyDrift = max(0.0, components.strategyBrier - metrics.baselineBrier).coerceIn(0.0, .5)
        val regimeDrift = if (baselineRegime != null && baselineRegime != currentRegime) .12 else 0.0
        val total = (featureDrift * .35 + modelDrift * .35 + strategyDrift * .20 + regimeDrift * .10).coerceIn(0.0, 1.0)
        val recoveryEvidence = metrics.recentBrier + .03 < metrics.baselineBrier && metrics.hitRate >= .53 && total < .08
        val state = when {
            total >= .16 || modelDrift >= .12 -> State.DEGRADED
            total >= .08 -> State.WATCH
            recoveryEvidence -> State.RECOVERING
            else -> State.STABLE
        }
        val confidence = (0.45 + metrics.samples / 200.0).coerceIn(.45, .95)
        return Result(state, featureDrift, modelDrift, strategyDrift, regimeDrift, confidence,
            "${state.name}; feature=${"%.3f".format(featureDrift)} model=${"%.3f".format(modelDrift)} strategy=${"%.3f".format(strategyDrift)} regime=${"%.3f".format(regimeDrift)}")
    }

    /** Compare recent 20 bars with the preceding 20 using robust bounded distribution shifts. */
    private fun featureDrift(c: List<BtcCandle>): Double {
        val a = c.takeLast(40).take(20)
        val b = c.takeLast(20)
        if (a.size < 20 || b.size < 20) return 0.0
        fun ret(rows: List<BtcCandle>) = rows.mapIndexedNotNull { i, x ->
            if (i == 0 || rows[i - 1].close <= 0.0) null else x.close / rows[i - 1].close - 1.0
        }
        fun vol(rows: List<BtcCandle>) = rows.map { if (it.close > 0) (it.high - it.low) / it.close else 0.0 }
        fun volume(rows: List<BtcCandle>) = rows.map { it.volume.coerceAtLeast(0.0) }
        fun normalizedMean(xs: List<Double>): Double = if (xs.isEmpty()) 0.0 else xs.average()
        fun shift(x: List<Double>, y: List<Double>): Double {
            if (x.isEmpty() || y.isEmpty()) return 0.0
            val mx = normalizedMean(x); val my = normalizedMean(y)
            val sx = (x.map { (it - mx) * (it - mx) }.average()).let { kotlin.math.sqrt(it) }.coerceAtLeast(1e-9)
            val sy = (y.map { (it - my) * (it - my) }.average()).let { kotlin.math.sqrt(it) }.coerceAtLeast(1e-9)
            return ((abs(mx - my) / (sx + sy)) + abs(sx - sy) / (sx + sy)).coerceIn(0.0, 1.0)
        }
        val vr = shift(ret(a), ret(b))
        val vv = shift(vol(a), vol(b))
        val av = normalizedMean(volume(a)); val bv = normalizedMean(volume(b))
        val volumeShift = abs(av - bv) / (av + bv + 1e-9)
        return (vr * .45 + vv * .35 + volumeShift.coerceIn(0.0, 1.0) * .20).coerceIn(0.0, 1.0)
    }

    fun adjustWeights(base: FusionFeedbackStore.Weights, result: Result): FusionFeedbackStore.Weights {
        val featurePenalty = 1.0 - result.featureDrift * .45
        val modelPenalty = 1.0 - result.modelDrift * .70
        val strategyPenalty = 1.0 - result.strategyDrift * .55
        val regimePenalty = 1.0 - result.regimeDrift * .40
        val m = base.model * modelPenalty * regimePenalty
        val f = base.factor * featurePenalty * regimePenalty
        val s = base.strategy * strategyPenalty * regimePenalty
        val raw = listOf(m.coerceAtLeast(.05), f.coerceAtLeast(.05), s.coerceAtLeast(.05))
        val clipped = raw.map { it.coerceIn(.18, .58) }
        val sum = clipped.sum().coerceAtLeast(1e-9)
        return FusionFeedbackStore.Weights(clipped[0] / sum, clipped[1] / sum, clipped[2] / sum)
    }
}
