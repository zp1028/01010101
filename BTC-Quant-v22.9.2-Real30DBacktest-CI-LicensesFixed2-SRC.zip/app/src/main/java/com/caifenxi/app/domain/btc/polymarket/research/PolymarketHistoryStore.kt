package com.caifenxi.app.domain.btc.polymarket.research

import android.content.Context
import com.caifenxi.app.data.db.CaiDatabase
import com.caifenxi.app.data.db.entity.PolymarketSnapshotEntity
import com.caifenxi.app.domain.btc.polymarket.PolyMarket
import com.caifenxi.app.domain.btc.polymarket.PolyOrderBook
import com.caifenxi.app.domain.btc.polymarket.strategy.PolymarketStrategyPool

/** Point-in-time CLOB recorder. Every candidate strategy gets its own research row. */
class PolymarketHistoryStore(context: Context) {
    private val dao = CaiDatabase.getInstance(context).polymarketSnapshotDao()

    suspend fun record(
        market: PolyMarket,
        yesBook: PolyOrderBook,
        noBook: PolyOrderBook?,
        currentBtc: Double?,
        modelYes: Double?,
        candidates: List<PolymarketStrategyPool.Signal>,
        capturedAtMs: Long = System.currentTimeMillis()
    ) {
        val yesDepth = yesBook.bids.take(10).sumOf { it.size } + yesBook.asks.take(10).sumOf { it.size }
        val noDepth = noBook?.let { it.bids.take(10).sumOf { l -> l.size } + it.asks.take(10).sumOf { l -> l.size } } ?: 0.0
        val rows = if (candidates.isEmpty()) listOf(null) else candidates
        dao.insertAll(rows.map { signal ->
            PolymarketSnapshotEntity(
                marketId = market.conditionId,
                capturedAtMs = capturedAtMs,
                startDateMs = market.startDateMs,
                endDateMs = market.endDateMs,
                currentBtc = currentBtc,
                priceToBeat = market.priceToBeat,
                yesBid = yesBook.bestBid,
                yesAsk = yesBook.bestAsk,
                noBid = noBook?.bestBid,
                noAsk = noBook?.bestAsk,
                yesDepth = yesDepth,
                noDepth = noDepth,
                modelYes = modelYes,
                spread = yesBook.spread,
                strategyId = signal?.strategyId,
                strategyScore = signal?.score,
                signalOutcome = signal?.outcome,
                signalEdge = signal?.edge
            )
        })
    }

    suspend fun settle(marketId: String, outcome: String) = dao.settleMarket(marketId, outcome)
    suspend fun history(marketId: String) = dao.history(marketId)
    suspend fun historyForAllStrategies() = dao.range(0L, Long.MAX_VALUE)
    suspend fun strategyHistory(strategyId: String) = dao.strategyHistory(strategyId)
    suspend fun count() = dao.count()
    suspend fun pruneBefore(cutoffMs: Long) = dao.pruneBefore(cutoffMs)
}
