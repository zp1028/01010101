package com.caifenxi.app.domain.btc.futures

/** Presentation-agnostic workstation projection: one source for terminal, automation and audit UI. */
data class FuturesWorkstationSnapshot(
    val symbol: String = "BTCUSDT",
    val markPrice: Double = 0.0,
    val indexPrice: Double = 0.0,
    val fundingRate: Double = 0.0,
    val openInterest: Double = 0.0,
    val position: FuturesPosition = FuturesPosition.empty(symbol),
    val execution: FuturesExecutionSnapshot = FuturesExecutionSnapshot(symbol = symbol),
    val availableBalance: Double = 0.0,
    val equity: Double = 0.0,
    val realizedPnl: Double = 0.0,
    val unrealizedPnl: Double = 0.0,
    val drawdownPct: Double = 0.0,
    val health: String = "UNKNOWN",
    val lastUpdateMs: Long = 0L
)

enum class FuturesWorkspaceMode { MONITOR, MANUAL, BOT, RISK }
