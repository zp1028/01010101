package com.caifenxi.app.domain.btc.recovery

import com.caifenxi.app.domain.btc.broker.EventMarketBroker
import com.caifenxi.app.domain.btc.broker.PolymarketClobBroker
import com.caifenxi.app.domain.btc.broker.PolymarketPrivateOrder
import com.caifenxi.app.domain.btc.broker.PolymarketPrivateTrade
import com.caifenxi.app.domain.btc.runtime.PolymarketSubmissionJournal

/**
 * Restart/reconnect recovery for Polymarket CLOB submissions.
 * Unknown writes are resolved from venue state before the strategy may submit
 * the same intent again. User WS is an acceleration path; REST remains authoritative.
 */
class PolymarketRecoveryCenter(
    private val broker: EventMarketBroker,
    private val journal: PolymarketSubmissionJournal
) {
    enum class Resolution { CONFIRMED, NOT_FOUND, STILL_UNKNOWN, SKIPPED }

    data class Result(
        val resolution: Resolution,
        val intentKey: String,
        val orderId: String? = null,
        val status: String = "",
        val filledSize: Double = 0.0,
        val message: String = ""
    )

    suspend fun recoverPending(): List<Result> {
        if (broker !is PolymarketClobBroker) {
            return journal.recent().map { Result(Resolution.SKIPPED, it.intentKey, message = "broker does not expose authenticated reconciliation") }
        }
        val ordersResult = broker.listPrivateOrders()
        val tradesResult = broker.listPrivateTrades()
        val orders = ordersResult.getOrDefault(emptyList())
        val trades = tradesResult.getOrDefault(emptyList())
        return journal.recent().map { pending ->
            val exactStatus = pending.orderId?.let { id -> broker.getOrderStatus(id) }
            if (exactStatus != null && exactStatus.ok) {
                journal.resolve(pending.intentKey)
                return@map Result(Resolution.CONFIRMED, pending.intentKey, pending.orderId, exactStatus.status, exactStatus.filledSize, "single-order REST reconciliation")
            }
            val matched = pending.orderId?.let { id -> orders.firstOrNull { it.id.equals(id, ignoreCase = true) } }
                ?: trades.firstOrNull { t -> pending.orderId != null && t.orderId.equals(pending.orderId, ignoreCase = true) }?.let { trade ->
                    orders.firstOrNull { it.id.equals(trade.orderId, ignoreCase = true) }
                }
                ?: orders.firstOrNull { matchesIntent(it, pending) }
            if (matched != null) {
                journal.resolve(pending.intentKey)
                val filled = matched.matchedSize.coerceAtLeast(
                    trades.filter { t ->
                        (pending.orderId != null && t.orderId.equals(pending.orderId, ignoreCase = true)) ||
                            (t.marketId.equals(pending.marketId, true) && t.outcome.equals(pending.outcome, true))
                    }.sumOf { it.size }
                )
                Result(Resolution.CONFIRMED, pending.intentKey, matched.id, matched.status, filled,
                    "venue order found; uncertain intent resolved")
            } else {
                Result(Resolution.NOT_FOUND, pending.intentKey,
                    message = "no matching private order found; intent remains unresolved until explicit policy/recheck")
            }
        }
    }

    suspend fun recoverOrder(orderId: String): Result {
        val status = broker.getOrderStatus(orderId)
        return if (status.ok) {
            Result(Resolution.CONFIRMED, "order:$orderId", orderId, status.status, status.filledSize, status.message)
        } else {
            Result(Resolution.STILL_UNKNOWN, "order:$orderId", orderId, status.status, status.filledSize, status.message)
        }
    }

    private fun matchesIntent(order: PolymarketPrivateOrder, pending: com.caifenxi.app.domain.btc.runtime.PolymarketSubmissionUncertainty): Boolean {
        if (!order.marketId.equals(pending.marketId, ignoreCase = true)) return false
        if (pending.outcome.isNotBlank() && order.outcome.isNotBlank() && !order.outcome.equals(pending.outcome, ignoreCase = true)) return false
        if (pending.requestedPrice > 0.0 && kotlin.math.abs(order.price - pending.requestedPrice) > 0.000001) return false
        // Journal size is USDC notional; CLOB original_size is fixed-point shares.
        // Normalize before comparing so same-market orders at the same price do not
        // get confused with each other.
        if (pending.requestedSize > 0.0 && pending.requestedPrice > 0.0 && order.originalSize > 0.0) {
            val expectedShares = pending.requestedSize / pending.requestedPrice
            val actualShares = order.originalSize / 1_000_000.0
            val tolerance = kotlin.math.max(0.00001, expectedShares * 0.01)
            if (kotlin.math.abs(actualShares - expectedShares) > tolerance) return false
        }
        val ageMs = if (order.createdAt > 0L) kotlin.math.abs(System.currentTimeMillis() - order.createdAt * 1000L) else 0L
        if (ageMs > 30 * 60_000L) return false
        return true
    }
}
