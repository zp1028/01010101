package com.caifenxi.app.domain.btc.cloud

import com.caifenxi.app.domain.btc.runtime.BtcHeartbeat
import com.caifenxi.app.domain.btc.runtime.BtcRemoteCommand

/** v22.7 cloud execution node contract. Secrets stay on the execution node. */
interface CloudExecutionTransport {
    suspend fun publishHeartbeat(heartbeat: BtcHeartbeat)
    suspend fun pullCommands(nodeId: String): List<BtcRemoteCommand>
    suspend fun acknowledge(commandId: String, success: Boolean, message: String? = null)
}

class CloudExecutionNode(
    private val nodeId: String,
    private val transport: CloudExecutionTransport,
    private val commandHandler: suspend (BtcRemoteCommand) -> Boolean
) {
    suspend fun heartbeat(snapshot: BtcHeartbeat) {
        require(snapshot.nodeId == nodeId) { "heartbeat nodeId mismatch" }
        transport.publishHeartbeat(snapshot)
    }

    suspend fun pollOnce(nowMs: Long = System.currentTimeMillis()) {
        transport.pullCommands(nodeId).forEach { command ->
            if (command.expiresAt < nowMs) {
                transport.acknowledge(command.commandId, false, "expired")
            } else {
                val ok = runCatching { commandHandler(command) }.getOrDefault(false)
                transport.acknowledge(command.commandId, ok, if (ok) null else "handler rejected")
            }
        }
    }
}

/** Bridge for the existing runtime controller control-plane interface. */
class TransportBtcControlPlane(
    private val transport: CloudExecutionTransport
) : com.caifenxi.app.domain.btc.runtime.BtcControlPlane {
    override suspend fun heartbeat(heartbeat: BtcHeartbeat) = transport.publishHeartbeat(heartbeat)
    override suspend fun pullCommands(nodeId: String): List<BtcRemoteCommand> = transport.pullCommands(nodeId)
    override suspend fun ack(commandId: String, success: Boolean, message: String?) =
        transport.acknowledge(commandId, success, message)
}
