package com.caifenxi.app.domain.btc.backtest

/**
 * Leakage-resistant walk-forward splitter. Samples whose label horizon overlaps
 * the test window are purged from train; an additional embargo is applied after
 * every test window.
 */
object PurgedEmbargoWalkForward {
    data class Fold(val id: Int, val train: IntRange, val test: IntRange, val purged: Int, val embargoed: Int)

    fun split(size: Int, trainBars: Int, testBars: Int, labelHorizonBars: Int = 1, embargoBars: Int = 0): List<Fold> {
        if (size <= 0 || trainBars <= 0 || testBars <= 0) return emptyList()
        val out = mutableListOf<Fold>(); var testStart = trainBars; var id = 0
        while (testStart < size) {
            val testEnd = (testStart + testBars - 1).coerceAtMost(size - 1)
            val purgeStart = (testStart - labelHorizonBars + 1).coerceAtLeast(0)
            val trainEnd = purgeStart - 1
            val trainStart = (trainEnd - trainBars + 1).coerceAtLeast(0)
            val embargoEnd = (testEnd + embargoBars).coerceAtMost(size - 1)
            if (trainStart <= trainEnd && testStart <= testEnd) {
                out += Fold(id++, trainStart..trainEnd, testStart..testEnd, testStart - purgeStart, embargoEnd - testEnd)
            }
            testStart += testBars
        }
        return out
    }
}
