package com.caifenxi.app.domain.btc.strategy

import android.content.Context
import org.json.JSONObject

/** Persists strategy quality weights produced by WFO; values are bounded and versioned. */
class StrategyRuntimeWeightStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("btc_strategy_runtime_weights_v1", Context.MODE_PRIVATE)
    fun save(weights: Map<String, Double>, artifactId: String, cutoffMs: Long) {
        val o = JSONObject().apply { weights.forEach { (k,v) -> put(k, v.coerceIn(0.0, 1.0)) }; put("artifactId", artifactId); put("cutoffMs", cutoffMs) }
        prefs.edit().putString("weights", o.toString()).apply()
    }
    fun load(): Map<String, Double> = runCatching {
        val o = JSONObject(prefs.getString("weights", "{}")); buildMap { o.keys().forEach { k -> if (k != "artifactId" && k != "cutoffMs") put(k, o.optDouble(k, 1.0)) } }
    }.getOrDefault(emptyMap())
}
