package com.caifenxi.app.domain.btc.runtime

/** Deterministic queue/impact model used by replay and live pre-trade estimation. */
data class QueueFillEstimate(
    val queueAhead: Double,
    val displayedDepth: Double,
    val expectedFillRatio: Double,
    val expectedFilledSize: Double
)

object ExecutionImpactModel {
    fun estimateMarketImpact(orderSize: Double, displayedDepth: Double, volatility: Double = 0.0): Double {
        if (orderSize <= 0.0 || displayedDepth <= 0.0) return 0.0
        val participation = (orderSize / displayedDepth).coerceIn(0.0, 1.0)
        return (participation * (1.0 + volatility.coerceAtLeast(0.0))).coerceAtMost(1.0)
    }

    fun estimateQueueFill(queueAhead: Double, displayedDepth: Double, orderSize: Double): QueueFillEstimate {
        if (orderSize <= 0.0 || displayedDepth <= 0.0) return QueueFillEstimate(queueAhead, displayedDepth, 0.0, 0.0)
        val available = (displayedDepth - queueAhead).coerceAtLeast(0.0)
        val ratio = (available / orderSize).coerceIn(0.0, 1.0)
        return QueueFillEstimate(queueAhead, displayedDepth, ratio, orderSize * ratio)
    }
}

/** Feature trust gate: low-quality live features cannot silently become high-confidence signals. */
data class FactorQuality(
    val missingRate: Double,
    val outlierRate: Double,
    val stability: Double,
    val distributionShift: Double,
    val icir: Double
) {
    val score: Double
        get() = (0.25 * (1.0 - missingRate.coerceIn(0.0, 1.0)) +
                0.20 * (1.0 - outlierRate.coerceIn(0.0, 1.0)) +
                0.25 * stability.coerceIn(0.0, 1.0) +
                0.15 * (1.0 - distributionShift.coerceIn(0.0, 1.0)) +
                0.15 * (icir / (1.0 + kotlin.math.abs(icir))).coerceIn(0.0, 1.0))
}

object FactorQualityGate {
    fun multiplier(q: FactorQuality): Double = when {
        q.score < 0.30 -> 0.0
        q.score < 0.50 -> 0.50
        q.score < 0.70 -> 0.80
        else -> 1.0
    }
}
