package com.caifenxi.app.domain.btc.polymarket

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Read-only connection/auth diagnostics. Never logs secrets. */
class PolymarketConnectionDiagnostics(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build(),
    private val baseUrl: String = "https://clob.polymarket.com"
) {
    data class Result(
        val publicOk: Boolean,
        val protocol: PolymarketOrderProtocol,
        val l2Configured: Boolean,
        val signerAddressMatches: Boolean,
        val privateOrderAuthCheckPerformed: Boolean,
        val message: String
    )

    suspend fun check(address: String, apiKey: String, secret: String, passphrase: String, privateKey: String): Result = withContext(Dispatchers.IO) {
        val public = runCatching {
            client.newCall(Request.Builder().url(baseUrl.trimEnd('/') + "/version").get().build()).execute().use { r ->
                if (!r.isSuccessful) return@runCatching false to PolymarketOrderProtocol.UNKNOWN
                val raw = r.body?.string().orEmpty()
                val v = runCatching { JSONObject(raw).optString("version", raw) }.getOrDefault(raw)
                true to when {
                    v.contains("3") -> PolymarketOrderProtocol.V3
                    v.contains("2") -> PolymarketOrderProtocol.V2
                    v.contains("1") -> PolymarketOrderProtocol.V1
                    else -> PolymarketOrderProtocol.UNKNOWN
                }
            }
        }.getOrElse { false to PolymarketOrderProtocol.UNKNOWN }

        val l2 = apiKey.isNotBlank() && secret.isNotBlank() && passphrase.isNotBlank() && address.isNotBlank()
        val signerMatches = runCatching {
            privateKey.isNotBlank() && address.isNotBlank() &&
                PolymarketEip712Signer.deriveAddress(privateKey).equals(address, ignoreCase = true)
        }.getOrDefault(false)

        // This class intentionally does not duplicate the broker HMAC implementation.
        // Authenticated verification is performed by the broker's heartbeat/order query.
        val privateAuthCheckPerformed = false

        val msg = when {
            !public.first -> "CLOB public endpoint unavailable"
            public.second == PolymarketOrderProtocol.V3 -> "CLOB V3 detected; current token-backed execution path is not enabled"
            !l2 -> "L2 credentials incomplete"
            privateKey.isNotBlank() && !signerMatches -> "private key does not match POLY_ADDRESS"
            else -> "public CLOB/protocol checks passed; authenticated order check requires broker heartbeat/order query"
        }
        Result(public.first, public.second, l2, signerMatches, privateAuthCheckPerformed, msg)
    }
}
