package com.caifenxi.app.domain.btc.runtime

import android.content.Context
import org.json.JSONObject

/** Persistent Binance submission journal. A live submission is never forgotten on exception. */
class BinanceExecutionJournal(context: Context) {
    data class Entry(
        val clientOrderId: String,
        val decisionId: String,
        val symbol: String,
        val mode: String,
        val requestedQty: Double,
        val side: String,
        val createdAt: Long,
        val orderId: Long? = null,
        val state: CanonicalOrderState = CanonicalOrderState.UNKNOWN,
        val message: String = ""
    )

    private val prefs = context.applicationContext.getSharedPreferences("btc_binance_submission_journal_v22", Context.MODE_PRIVATE)

    @Synchronized fun put(entry: Entry) {
        val o = JSONObject().apply {
            put("clientOrderId", entry.clientOrderId); put("decisionId", entry.decisionId)
            put("symbol", entry.symbol); put("mode", entry.mode); put("requestedQty", entry.requestedQty)
            put("side", entry.side); put("createdAt", entry.createdAt)
            put("orderId", entry.orderId ?: JSONObject.NULL); put("state", entry.state.name); put("message", entry.message)
        }
        prefs.edit().putString(entry.clientOrderId, o.toString()).apply()
    }

    @Synchronized fun all(): List<Entry> = prefs.all.values.mapNotNull { raw -> parse(raw as? String) }
    @Synchronized fun get(clientOrderId: String): Entry? = parse(prefs.getString(clientOrderId, null))
    @Synchronized fun resolve(clientOrderId: String) { prefs.edit().remove(clientOrderId).apply() }
    @Synchronized fun updateState(clientOrderId: String, state: CanonicalOrderState, orderId: Long? = null, message: String = "") {
        val current = get(clientOrderId) ?: return
        val next = if (CanonicalOrderStateMachine.canTransition(current.state, state)) state else CanonicalOrderState.UNKNOWN
        put(current.copy(state = next, orderId = orderId ?: current.orderId, message = message.ifBlank { current.message }))
    }

    private fun parse(raw: String?): Entry? = runCatching {
        if (raw.isNullOrBlank()) return null
        val o = JSONObject(raw)
        Entry(
            clientOrderId = o.optString("clientOrderId"), decisionId = o.optString("decisionId"), symbol = o.optString("symbol"),
            mode = o.optString("mode"), requestedQty = o.optDouble("requestedQty", 0.0), side = o.optString("side"),
            createdAt = o.optLong("createdAt", 0L), orderId = o.optLong("orderId", 0L).takeIf { it > 0 },
            state = runCatching { CanonicalOrderState.valueOf(o.optString("state", "UNKNOWN")) }.getOrDefault(CanonicalOrderState.UNKNOWN),
            message = o.optString("message")
        )
    }.getOrNull()
}
