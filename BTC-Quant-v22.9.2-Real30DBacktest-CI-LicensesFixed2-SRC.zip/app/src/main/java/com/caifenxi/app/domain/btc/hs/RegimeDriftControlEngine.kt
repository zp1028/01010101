package com.caifenxi.app.domain.btc.hs

import com.caifenxi.app.domain.btc.MarketRegime
import kotlin.math.max

/** v18.3: runtime drift gate. It changes exposure/ensemble weights only; it never places orders. */
object RegimeDriftControlEngine {
    enum class State { STABLE, WATCH, DEGRADED, RECOVERING }
    data class Result(
        val state: State,
        val multiplier: Double,
        val recentBrier: Double,
        val baselineBrier: Double,
        val degradation: Double,
        val regime: MarketRegime,
        val reason: String
    )

    fun evaluate(
        metrics: FusionFeedbackStore.Metrics,
        regime: MarketRegime,
        minSamples: Int = 20
    ): Result {
        if (metrics.samples < minSamples) {
            return Result(State.WATCH, 0.70, metrics.recentBrier, metrics.baselineBrier, 0.0, regime, "反馈样本不足，保护性降权")
        }
        val degradation = (metrics.recentBrier - metrics.baselineBrier).coerceIn(-0.25, 0.50)
        val regimePenalty = when (regime) {
            MarketRegime.HIGH_VOLATILITY -> 0.12
            MarketRegime.RANGE -> 0.04
            else -> 0.0
        }
        val effective = degradation + regimePenalty
        val state = when {
            effective >= 0.12 -> State.DEGRADED
            effective >= 0.05 -> State.WATCH
            degradation < -0.03 && metrics.hitRate >= 0.53 -> State.RECOVERING
            else -> State.STABLE
        }
        val multiplier = when (state) {
            State.STABLE -> 1.0
            State.RECOVERING -> 0.92
            State.WATCH -> 0.78
            State.DEGRADED -> 0.55
        }
        return Result(state, multiplier, metrics.recentBrier, metrics.baselineBrier, degradation, regime,
            "${state.name}; regime=${regime.name}; recentBrier=${"%.4f".format(metrics.recentBrier)} baseline=${"%.4f".format(metrics.baselineBrier)} degradation=${"%+.4f".format(degradation)}")
    }

    fun adjustWeights(base: FusionFeedbackStore.Weights, control: Result): FusionFeedbackStore.Weights {
        val m = base.model * (0.85 + 0.15 * control.multiplier)
        val f = base.factor * (0.95 + 0.05 * control.multiplier)
        val s = base.strategy * (0.90 + 0.10 * control.multiplier)
        val sum = max(1e-9, m + f + s)
        return FusionFeedbackStore.Weights(m / sum, f / sum, s / sum)
    }
}
