package com.caifenxi.app.domain.btc.broker

import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.TradingSignal
import com.caifenxi.app.domain.btc.futures.ClosePositionRequest
import com.caifenxi.app.domain.btc.futures.FuturesOrderType
import com.caifenxi.app.domain.btc.futures.LeverageResult
import com.caifenxi.app.domain.btc.futures.MarginMode
import com.caifenxi.app.domain.btc.futures.PositionRiskInfo
import com.caifenxi.app.domain.btc.futures.FuturesOpenOrder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

enum class BinanceFuturesEndpoint(val baseUrl: String, val label: String) {
    /** Binance Futures Demo Trading */
    DEMO("https://demo-fapi.binance.com", "demo"),
    /** Classic USDⓈ-M testnet */
    TESTNET("https://testnet.binancefuture.com", "testnet"),
    /** Production — only when user explicitly enables LIVE */
    MAINNET("https://fapi.binance.com", "mainnet")
}

/**
 * Signed USDⓈ-M Futures REST adapter.
 * Keys MUST be injected at runtime (EncryptedSharedPreferences / server), never baked into APK.
 */
class BinanceFuturesBroker(
    private val apiKey: String,
    private val secretKey: String,
    private val endpoint: BinanceFuturesEndpoint = BinanceFuturesEndpoint.DEMO,
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()
) : PerpBroker {

    override suspend fun place(signal: TradingSignal.ContractSignal, clientOrderId: String): BrokerOrderResult =
        withContext(Dispatchers.IO) {
            try {
                require(apiKey.isNotBlank() && secretKey.isNotBlank()) { "缺少 API Key" }
                require(clientOrderId.length in 1..36) { "clientOrderId 长度非法" }
                require(signal.direction != BtcDirection.FLAT) { "FLAT 不可下单" }
                val side = if (signal.direction == BtcDirection.UP) "BUY" else "SELL"
                val qty = formatQty(signal.symbol, signal.positionSize)
                val params = linkedMapOf(
                    "symbol" to signal.symbol.uppercase(),
                    "side" to side,
                    "type" to "MARKET",
                    "quantity" to qty,
                    "newClientOrderId" to clientOrderId.take(36),
                    "newOrderRespType" to "RESULT",
                    "timestamp" to System.currentTimeMillis().toString(),
                    "recvWindow" to "5000"
                )
                // reduceOnly not set — one-way mode open
                val json = signed("POST", "/fapi/v1/order", params)
                BrokerOrderResult(
                    success = true,
                    orderId = json.optLong("orderId").takeIf { it != 0L },
                    clientOrderId = json.optString("clientOrderId", clientOrderId),
                    status = json.optString("status", "UNKNOWN"),
                    message = "ok ${endpoint.label}"
                )
            } catch (e: Exception) {
                BrokerOrderResult(false, null, clientOrderId, "ERROR", e.message ?: "place failed")
            }
        }

    override suspend fun cancel(symbol: String, orderId: Long?, clientOrderId: String?): BrokerOrderResult =
        withContext(Dispatchers.IO) {
            try {
                val params = linkedMapOf(
                    "symbol" to symbol.uppercase(),
                    "timestamp" to System.currentTimeMillis().toString(),
                    "recvWindow" to "5000"
                )
                orderId?.let { params["orderId"] = it.toString() }
                clientOrderId?.let { params["origClientOrderId"] = it }
                val json = signed("DELETE", "/fapi/v1/order", params)
                BrokerOrderResult(
                    true,
                    json.optLong("orderId").takeIf { it != 0L },
                    json.optString("clientOrderId", clientOrderId.orEmpty()),
                    json.optString("status", "CANCELED")
                )
            } catch (e: Exception) {
                BrokerOrderResult(false, null, clientOrderId.orEmpty(), "ERROR", e.message ?: "cancel failed")
            }
        }

    override suspend fun accountSnapshot(): BrokerAccountSnapshot = withContext(Dispatchers.IO) {
        runCatching {
            val json = signed("GET", "/fapi/v2/account", linkedMapOf(
                "timestamp" to System.currentTimeMillis().toString(),
                "recvWindow" to "5000"
            ))
            BrokerAccountSnapshot(
                availableBalance = json.optString("availableBalance", "0").toDoubleOrNull() ?: 0.0,
                totalWalletBalance = json.optString("totalWalletBalance", "0").toDoubleOrNull() ?: 0.0,
                unrealizedPnl = json.optString("totalUnrealizedProfit", "0").toDoubleOrNull() ?: 0.0
            )
        }.getOrElse { BrokerAccountSnapshot(0.0, 0.0, 0.0) }
    }

    override suspend fun setLeverage(symbol: String, leverage: Int): LeverageResult =
        withContext(Dispatchers.IO) {
            try {
                require(leverage in 1..125) { "leverage out of range: $leverage" }
                val params = linkedMapOf(
                    "symbol" to symbol.uppercase(),
                    "leverage" to leverage.toString(),
                    "timestamp" to System.currentTimeMillis().toString(),
                    "recvWindow" to "5000"
                )
                val json = signed("POST", "/fapi/v1/leverage", params)
                LeverageResult(
                    success = true,
                    leverage = json.optInt("leverage", leverage),
                    maxNotionalValue = json.optString("maxNotionalValue", "0").toDoubleOrNull() ?: 0.0,
                    message = "leverage set to ${json.optInt("leverage", leverage)}x ${endpoint.label}"
                )
            } catch (e: Exception) {
                LeverageResult(false, leverage, 0.0, e.message ?: "setLeverage failed")
            }
        }

    override suspend fun setMarginMode(symbol: String, mode: MarginMode): BrokerOrderResult =
        withContext(Dispatchers.IO) {
            try {
                val params = linkedMapOf(
                    "symbol" to symbol.uppercase(),
                    "marginType" to mode.binanceValue,
                    "timestamp" to System.currentTimeMillis().toString(),
                    "recvWindow" to "5000"
                )
                val json = signed("POST", "/fapi/v1/marginType", params)
                BrokerOrderResult(
                    success = true,
                    clientOrderId = "",
                    status = json.optString("msg", "ok"),
                    message = "marginType=${mode.binanceValue} ${endpoint.label}"
                )
            } catch (e: Exception) {
                // No-change response code -1104 is expected when already set
                val msg = e.message.orEmpty()
                if (msg.contains("-4046") || msg.contains("No need to change")) {
                    BrokerOrderResult(true, null, "", "NO_CHANGE", "already ${mode.binanceValue}")
                } else {
                    BrokerOrderResult(false, null, "", "ERROR", msg.ifEmpty { "setMarginMode failed" })
                }
            }
        }

    override suspend fun fetchPositionRisk(symbol: String): PositionRiskInfo? =
        withContext(Dispatchers.IO) {
            try {
                val params = linkedMapOf(
                    "symbol" to symbol.uppercase(),
                    "timestamp" to System.currentTimeMillis().toString(),
                    "recvWindow" to "5000"
                )
                val arr = signedArray("GET", "/fapi/v2/positionRisk", params)
                if (arr.length() == 0) return@withContext null
                val row = arr.optJSONObject(0) ?: return@withContext null
                val posAmt = row.optString("positionAmt", "0").toDoubleOrNull() ?: 0.0
                if (posAmt == 0.0) return@withContext null
                PositionRiskInfo(
                    symbol = row.optString("symbol", symbol),
                    positionAmt = posAmt,
                    entryPrice = row.optString("entryPrice", "0").toDoubleOrNull() ?: 0.0,
                    markPrice = row.optString("markPrice", "0").toDoubleOrNull() ?: 0.0,
                    unRealizedProfit = row.optString("unRealizedProfit", "0").toDoubleOrNull() ?: 0.0,
                    liquidationPrice = row.optString("liquidationPrice", "0").toDoubleOrNull() ?: 0.0,
                    leverage = row.optString("leverage", "1"),
                    maxNotionalValue = row.optString("maxNotionalValue", "0"),
                    marginType = row.optString("marginType", "isolated"),
                    notional = row.optString("notional", "0").toDoubleOrNull() ?: 0.0,
                    isolatedWallet = row.optString("isolatedWallet", "0").toDoubleOrNull() ?: 0.0,
                    updateTime = row.optLong("updateTime", System.currentTimeMillis())
                )
            } catch (e: Exception) {
                null
            }
        }

    override suspend fun queryOrderStatus(symbol: String, orderId: Long?, clientOrderId: String?): BrokerOrderResult =
        withContext(Dispatchers.IO) {
            require(orderId != null || !clientOrderId.isNullOrBlank()) { "orderId or clientOrderId required" }
            val params = linkedMapOf(
                "symbol" to symbol.uppercase(),
                "timestamp" to System.currentTimeMillis().toString(),
                "recvWindow" to "5000"
            )
            orderId?.let { params["orderId"] = it.toString() }
            if (orderId == null) clientOrderId?.let { params["origClientOrderId"] = it }
            try {
                val json = signed("GET", "/fapi/v1/order", params)
                BrokerOrderResult(
                    success = true,
                    orderId = json.optLong("orderId", 0L).takeIf { it > 0L },
                    clientOrderId = json.optString("clientOrderId", clientOrderId.orEmpty()),
                    status = json.optString("status", "UNKNOWN"),
                    message = "order recovery ${endpoint.label}"
                )
            } catch (e: Exception) {
                throw IllegalStateException("Binance order recovery failed: ${e.message ?: "unknown"}", e)
            }
        }

    override suspend fun fetchOpenOrders(symbol: String): List<FuturesOpenOrder> =
        withContext(Dispatchers.IO) {
            try {
                val params = linkedMapOf(
                    "symbol" to symbol.uppercase(),
                    "timestamp" to System.currentTimeMillis().toString(),
                    "recvWindow" to "5000"
                )
                val arr = signedArray("GET", "/fapi/v1/openOrders", params)
                buildList {
                    for (i in 0 until arr.length()) {
                        val o = arr.optJSONObject(i) ?: continue
                        val type = runCatching {
                            FuturesOrderType.valueOf(o.optString("type", "MARKET"))
                        }.getOrDefault(FuturesOrderType.MARKET)
                        add(FuturesOpenOrder(
                            symbol = o.optString("symbol", symbol),
                            orderId = o.optLong("orderId", 0L),
                            clientOrderId = o.optString("clientOrderId", ""),
                            side = o.optString("side", ""),
                            type = type,
                            status = o.optString("status", "UNKNOWN"),
                            origQty = o.optString("origQty", "0").toDoubleOrNull() ?: 0.0,
                            executedQty = o.optString("executedQty", "0").toDoubleOrNull() ?: 0.0,
                            stopPrice = o.optString("stopPrice", "0").toDoubleOrNull()?.takeIf { it > 0.0 },
                            reduceOnly = o.optBoolean("reduceOnly", false),
                            updateTime = o.optLong("updateTime", System.currentTimeMillis())
                        ))
                    }
                }
            } catch (e: Exception) {
                throw IllegalStateException("openOrders sync failed: ${e.message ?: "unknown"}", e)
            }
        }

    override suspend fun placeConditionalOrder(
        symbol: String,
        side: String,
        type: FuturesOrderType,
        quantity: Double,
        stopPrice: Double?,
        trailingDelta: Double?,
        reduceOnly: Boolean,
        clientOrderId: String
    ): BrokerOrderResult = withContext(Dispatchers.IO) {
        try {
            require(clientOrderId.length in 1..36) { "clientOrderId length invalid" }
            require(type != FuturesOrderType.MARKET && type != FuturesOrderType.LIMIT) {
                "use place() for MARKET/LIMIT; this is for conditional orders only"
            }
            val params = linkedMapOf(
                "symbol" to symbol.uppercase(),
                "side" to side,
                "type" to type.binanceValue,
                "quantity" to formatQty(symbol, quantity),
                "newClientOrderId" to clientOrderId.take(36),
                "newOrderRespType" to "RESULT",
                "timestamp" to System.currentTimeMillis().toString(),
                "recvWindow" to "5000"
            )
            stopPrice?.let { params["stopPrice"] = formatPrice(symbol, it) }
            trailingDelta?.let { params["trailingDelta"] = "%.0f".format(it) }
            if (reduceOnly) params["reduceOnly"] = "true"
            // TRAILING_STOP_MARKET uses workingType=MARK_PRICE by default; STOP_MARKET needs stopPrice
            if (type == FuturesOrderType.STOP_MARKET || type == FuturesOrderType.TAKE_PROFIT_MARKET) {
                require(stopPrice != null) { "$type requires stopPrice" }
                params["workingType"] = "MARK_PRICE"
            }
            val json = signed("POST", "/fapi/v1/order", params)
            BrokerOrderResult(
                success = true,
                orderId = json.optLong("orderId").takeIf { it != 0L },
                clientOrderId = json.optString("clientOrderId", clientOrderId),
                status = json.optString("status", "NEW"),
                message = "${type.binanceValue} ${endpoint.label}"
            )
        } catch (e: Exception) {
            BrokerOrderResult(false, null, clientOrderId, "ERROR", e.message ?: "conditional order failed")
        }
    }

    override suspend fun closePosition(request: ClosePositionRequest): BrokerOrderResult =
        withContext(Dispatchers.IO) {
            try {
                // Fetch current position to determine side and qty
                val risk = fetchPositionRisk(request.symbol)
                if (risk == null || risk.positionAmt == 0.0) {
                    return@withContext BrokerOrderResult(
                        true, null, "", "NO_POSITION", "no open position for ${request.symbol}"
                    )
                }
                val closeSide = if (risk.positionAmt > 0.0) "SELL" else "BUY"
                val closeQty = formatQty(request.symbol, kotlin.math.abs(risk.positionAmt))
                val params = linkedMapOf(
                    "symbol" to request.symbol.uppercase(),
                    "side" to closeSide,
                    "type" to "MARKET",
                    "quantity" to closeQty,
                    "newClientOrderId" to "close-${System.currentTimeMillis()}".take(36),
                    "newOrderRespType" to "RESULT",
                    "timestamp" to System.currentTimeMillis().toString(),
                    "recvWindow" to "5000"
                )
                if (request.reduceOnly) params["reduceOnly"] = "true"
                val json = signed("POST", "/fapi/v1/order", params)
                BrokerOrderResult(
                    success = true,
                    orderId = json.optLong("orderId").takeIf { it != 0L },
                    clientOrderId = json.optString("clientOrderId", ""),
                    status = json.optString("status", "FILLED"),
                    message = "closed ${request.symbol} ${closeSide} qty=$closeQty reason=${request.reason}"
                )
            } catch (e: Exception) {
                BrokerOrderResult(false, null, "", "ERROR", e.message ?: "closePosition failed")
            }
        }

    /** Public connectivity check (no signature). */
    suspend fun ping(): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val req = Request.Builder().url("${endpoint.baseUrl}/fapi/v1/ping").get().build()
            client.newCall(req).execute().use { it.isSuccessful }
        }.getOrDefault(false)
    }

    /**
     * 拉取 exchangeInfo 并写入 [ExchangeFilters] 运行时表。
     * @return true 表示至少解析成功一次
     */
    suspend fun loadSymbolFilters(symbol: String = "BTCUSDT"): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val url = "${endpoint.baseUrl}/fapi/v1/exchangeInfo?symbol=${symbol.uppercase()}"
            val req = Request.Builder().url(url).get().build()
            client.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) return@use false
                ExchangeFilters.updateFromExchangeInfoJson(body, preferSymbol = symbol)
            }
        }.getOrDefault(false)
    }

    private fun signedArray(method: String, path: String, params: LinkedHashMap<String, String>): JSONArray {
        val query = params.entries.joinToString("&") { "${enc(it.key)}=${enc(it.value)}" }
        val signature = hmac(query, secretKey)
        val url = "${endpoint.baseUrl}$path?$query&signature=$signature"
        val b = Request.Builder().url(url).header("X-MBX-APIKEY", apiKey)
        when (method) {
            "POST" -> b.post(FormBody.Builder().build())
            "DELETE" -> b.delete()
            else -> b.get()
        }
        client.newCall(b.build()).execute().use { resp ->
            val body = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) error("Binance ${endpoint.label} ${resp.code}: ${body.take(300)}")
            return JSONArray(body)
        }
    }

    private fun signed(method: String, path: String, params: LinkedHashMap<String, String>): JSONObject {
        val query = params.entries.joinToString("&") { "${enc(it.key)}=${enc(it.value)}" }
        val signature = hmac(query, secretKey)
        val url = "${endpoint.baseUrl}$path?$query&signature=$signature"
        val b = Request.Builder().url(url).header("X-MBX-APIKEY", apiKey)
        when (method) {
            "POST" -> b.post(FormBody.Builder().build())
            "DELETE" -> b.delete()
            else -> b.get()
        }
        client.newCall(b.build()).execute().use { resp ->
            val body = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) error("Binance ${endpoint.label} ${resp.code}: ${body.take(300)}")
            return JSONObject(body)
        }
    }

    private fun formatQty(symbol: String, q: Double): String =
        ExchangeFilters.formatQty(symbol, q)

    private fun formatPrice(symbol: String, p: Double): String =
        ExchangeFilters.formatPrice(symbol, p)

    private fun enc(s: String) = URLEncoder.encode(s, Charsets.UTF_8.name())
    private fun hmac(data: String, secret: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        return mac.doFinal(data.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
    }
}

/** No network; for PAPER mode. Tracks positions in memory for UI monitoring. */
class PaperPerpBroker : PerpBroker {
    private var paperLeverage = 3
    private var paperMarginMode = MarginMode.ISOLATED
    private var paperBalance = 10_000.0
    private val paperPositions = mutableMapOf<String, PositionRiskInfo>()
    private val paperOrders = mutableListOf<String>()

    override suspend fun place(signal: TradingSignal.ContractSignal, clientOrderId: String): BrokerOrderResult {
        val sym = signal.symbol.uppercase()
        val signedQty = when (signal.direction) {
            BtcDirection.UP -> signal.positionSize
            BtcDirection.DOWN -> -signal.positionSize
            BtcDirection.FLAT -> 0.0
        }
        if (signedQty == 0.0) {
            return BrokerOrderResult(false, null, clientOrderId, "REJECTED", "FLAT cannot open")
        }
        val existing = paperPositions[sym]
        val newAmt = (existing?.positionAmt ?: 0.0) + signedQty
        val entry = if (existing != null && existing.positionAmt != 0.0 &&
            existing.positionAmt.sign == newAmt.sign
        ) {
            // 同向加仓：加权均价
            val total = kotlin.math.abs(existing.positionAmt) * existing.entryPrice +
                kotlin.math.abs(signedQty) * signal.entry
            total / kotlin.math.abs(newAmt).coerceAtLeast(1e-12)
        } else {
            signal.entry
        }
        if (kotlin.math.abs(newAmt) < 1e-12) {
            paperPositions.remove(sym)
        } else {
            paperPositions[sym] = PositionRiskInfo(
                symbol = sym,
                positionAmt = newAmt,
                entryPrice = entry,
                markPrice = signal.entry,
                unRealizedProfit = 0.0,
                liquidationPrice = 0.0,
                leverage = paperLeverage.toString(),
                maxNotionalValue = "0",
                marginType = paperMarginMode.binanceValue.lowercase()
            )
        }
        paperOrders += "FILL $clientOrderId ${signal.direction} qty=${signal.positionSize} @${signal.entry}"
        return BrokerOrderResult(
            true, System.currentTimeMillis(), clientOrderId, "PAPER_FILLED",
            "paper ${signal.direction} qty=${signal.positionSize} entry=${signal.entry}"
        )
    }

    override suspend fun cancel(symbol: String, orderId: Long?, clientOrderId: String?) =
        BrokerOrderResult(true, orderId, clientOrderId.orEmpty(), "PAPER_CANCELED")

    override suspend fun accountSnapshot() = BrokerAccountSnapshot(paperBalance, paperBalance, 0.0)

    override suspend fun setLeverage(symbol: String, leverage: Int): LeverageResult {
        paperLeverage = leverage.coerceIn(1, 125)
        return LeverageResult(true, paperLeverage, 50000.0, "paper leverage set to ${paperLeverage}x")
    }

    override suspend fun setMarginMode(symbol: String, mode: MarginMode): BrokerOrderResult {
        paperMarginMode = mode
        return BrokerOrderResult(true, null, "", "PAPER_OK", "paper marginType=${mode.binanceValue}")
    }

    override suspend fun fetchPositionRisk(symbol: String): PositionRiskInfo? = paperPositions[symbol.uppercase()]

    override suspend fun fetchOpenOrders(symbol: String): List<FuturesOpenOrder> = emptyList()

    override suspend fun placeConditionalOrder(
        symbol: String,
        side: String,
        type: FuturesOrderType,
        quantity: Double,
        stopPrice: Double?,
        trailingDelta: Double?,
        reduceOnly: Boolean,
        clientOrderId: String
    ): BrokerOrderResult {
        paperOrders += "COND $clientOrderId ${type.binanceValue} $side qty=$quantity stop=$stopPrice"
        return BrokerOrderResult(
            true, System.currentTimeMillis(), clientOrderId, "PAPER_NEW",
            "paper ${type.binanceValue} side=$side qty=$quantity stop=$stopPrice reduceOnly=$reduceOnly"
        )
    }

    override suspend fun closePosition(request: ClosePositionRequest): BrokerOrderResult {
        paperPositions.remove(request.symbol.uppercase())
        return BrokerOrderResult(true, null, "", "PAPER_CLOSED", "paper closed ${request.symbol} reason=${request.reason}")
    }

    fun setPaperPosition(symbol: String, info: PositionRiskInfo) {
        paperPositions[symbol.uppercase()] = info
    }

    fun recentOrders(): List<String> = paperOrders.takeLast(20)
}

private val Double.sign: Double get() = when {
    this > 0 -> 1.0
    this < 0 -> -1.0
    else -> 0.0
}
