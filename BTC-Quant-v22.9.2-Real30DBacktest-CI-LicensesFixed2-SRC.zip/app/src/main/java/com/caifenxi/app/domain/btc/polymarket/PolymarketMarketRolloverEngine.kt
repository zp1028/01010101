package com.caifenxi.app.domain.btc.polymarket

/** Prevents stale-window candidates from leaking into the next event window. */
class PolymarketMarketRolloverEngine {
    enum class State { UPCOMING, ACTIVE, ENDING, EXPIRED, RESOLVED, INVALID }
    data class Window(val market: PolyMarket, val state: State, val ageSec: Long, val remainingSec: Long)

    fun classify(market: PolyMarket, nowMs: Long = System.currentTimeMillis(), endingThresholdSec: Long = 30): Window {
        val start = market.startDateMs ?: 0L
        val end = market.endDateMs ?: 0L
        val now = nowMs
        val age = if (start > 0) ((now - start) / 1000L).coerceAtLeast(0) else 0L
        val remaining = if (end > 0) ((end - now) / 1000L).coerceAtLeast(0) else Long.MAX_VALUE
        val state = when {
            market.resolvedOutcome != null -> State.RESOLVED
            market.closed -> State.EXPIRED
            start > 0 && end > 0 && end <= start -> State.INVALID
            start > now -> State.UPCOMING
            end > 0 && end <= now -> State.EXPIRED
            end > 0 && remaining <= endingThresholdSec -> State.ENDING
            else -> State.ACTIVE
        }
        return Window(market, state, age, remaining)
    }

    fun isTradable(window: Window, minSecondsToResolution: Long = 15): Boolean =
        window.state == State.ACTIVE && window.remainingSec >= minSecondsToResolution
}
