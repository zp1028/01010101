package com.caifenxi.app.domain.btc.hs

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.ArrayDeque

/** Immutable compact market/decision snapshots for audit and deterministic replay. */
class HsSnapshotStore(context: Context? = null, private val maxRecords: Int = 1000) {
    data class Record(
        val id: String, val at: Long, val symbol: String, val timeframe: String,
        val mark: Double, val pHat: Double, val direction: String,
        val marketYes: Double, val bid: Double, val ask: Double,
        val edge: Double, val opportunity: Double, val quality: Double,
        val regime: String, val modelVersion: String
    )
    private val rows = ArrayDeque<Record>()
    private val prefs = context?.applicationContext?.getSharedPreferences("btc_hs_snapshot_v1", Context.MODE_PRIVATE)
    init { load() }

    @Synchronized fun append(r: Record) {
        if (r.id.isBlank()) return
        if (rows.any { it.id == r.id }) return
        rows.addLast(r); while (rows.size > maxRecords) rows.removeFirst(); persist()
    }
    @Synchronized fun recent(limit: Int = 100): List<Record> = rows.toList().takeLast(limit.coerceAtMost(maxRecords))
    @Synchronized fun find(id: String): Record? = rows.lastOrNull { it.id == id }
    @Synchronized fun size(): Int = rows.size

    /** 曲线历史持久化：重启后看板曲线（优势+点差 / PHAT）不再从空白起步 */
    @Synchronized fun saveCurveHistory(edge: List<Double>, phat: Map<String, List<Double>>) {
        val p = prefs ?: return
        runCatching {
            val ea = JSONArray()
            edge.takeLast(60).forEach { ea.put(it) }
            val pa = JSONObject()
            phat.forEach { (tf, v) ->
                val a = JSONArray()
                v.takeLast(60).forEach { a.put(it) }
                pa.put(tf, a)
            }
            p.edit().putString("edge_history", ea.toString()).putString("phat_history", pa.toString()).apply()
        }
    }

    @Synchronized fun loadEdgeHistory(): List<Double> = runCatching {
        val a = JSONArray(prefs?.getString("edge_history", "[]") ?: "[]")
        (0 until a.length()).map { a.getDouble(it) }
    }.getOrDefault(emptyList())

    @Synchronized fun loadPhatHistory(): Map<String, List<Double>> = runCatching {
        val o = JSONObject(prefs?.getString("phat_history", "{}") ?: "{}")
        o.keys().asSequence().associateWith { k ->
            val a = o.getJSONArray(k)
            (0 until a.length()).map { a.getDouble(it) }
        }
    }.getOrDefault(emptyMap())

    private fun load() = runCatching {
        val a = JSONArray(prefs?.getString("rows", "[]") ?: "[]")
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            rows.addLast(Record(o.getString("id"),o.getLong("at"),o.getString("symbol"),o.getString("tf"),o.getDouble("mark"),o.getDouble("p"),o.getString("dir"),o.getDouble("my"),o.getDouble("bid"),o.getDouble("ask"),o.getDouble("edge"),o.getDouble("opp"),o.getDouble("q"),o.getString("regime"),o.getString("model")))
        }
        while (rows.size > maxRecords) rows.removeFirst()
    }
    private fun persist() {
        val p = prefs ?: return; val a = JSONArray()
        rows.forEach { r -> a.put(JSONObject().apply { put("id",r.id);put("at",r.at);put("symbol",r.symbol);put("tf",r.timeframe);put("mark",r.mark);put("p",r.pHat);put("dir",r.direction);put("my",r.marketYes);put("bid",r.bid);put("ask",r.ask);put("edge",r.edge);put("opp",r.opportunity);put("q",r.quality);put("regime",r.regime);put("model",r.modelVersion) }) }
        p.edit().putString("rows", a.toString()).apply()
    }
}
