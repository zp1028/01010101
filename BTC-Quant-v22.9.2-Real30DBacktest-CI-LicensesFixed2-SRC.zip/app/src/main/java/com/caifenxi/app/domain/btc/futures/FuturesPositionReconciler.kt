package com.caifenxi.app.domain.btc.futures

import kotlin.math.abs

/** Exchange-authoritative reconciliation state used by foreground UI and background runtime. */
enum class ReconciliationState { UNKNOWN, SYNCING, IN_SYNC, DRIFT, STALE, ERROR }

data class PositionReconciliation(
    val state: ReconciliationState = ReconciliationState.UNKNOWN,
    val localQty: Double = 0.0,
    val exchangeQty: Double = 0.0,
    val localSide: PositionSide = PositionSide.EMPTY,
    val exchangeSide: PositionSide = PositionSide.EMPTY,
    val quantityDrift: Double = 0.0,
    val directionDrift: Boolean = false,
    val lastSuccessfulSyncAt: Long = 0L,
    val lastAttemptAt: Long = 0L,
    val error: String? = null
) {
    val isSafeForAutoExecution: Boolean
        get() = state == ReconciliationState.IN_SYNC
}

object FuturesPositionReconciler {
    private const val QTY_EPS = 0.0000005

    fun compare(local: FuturesPosition?, exchange: PositionRiskInfo?, now: Long = System.currentTimeMillis()): PositionReconciliation {
        val l = local?.takeUnless { it.isEmpty }
        val localQty = l?.quantity ?: 0.0
        val localSide = l?.side ?: PositionSide.EMPTY
        val exchangeQty = abs(exchange?.positionAmt ?: 0.0)
        val exchangeSide = when {
            exchange?.positionAmt ?: 0.0 > QTY_EPS -> PositionSide.LONG
            exchange?.positionAmt ?: 0.0 < -QTY_EPS -> PositionSide.SHORT
            else -> PositionSide.EMPTY
        }
        val qtyDrift = exchangeQty - localQty
        val directionDrift = localSide != PositionSide.EMPTY && exchangeSide != PositionSide.EMPTY && localSide != exchangeSide
        val drift = abs(qtyDrift) > QTY_EPS || (localSide != exchangeSide && (localSide != PositionSide.EMPTY || exchangeSide != PositionSide.EMPTY))
        val syncTime = now
        return PositionReconciliation(
            state = if (drift) ReconciliationState.DRIFT else ReconciliationState.IN_SYNC,
            localQty = localQty,
            exchangeQty = exchangeQty,
            localSide = localSide,
            exchangeSide = exchangeSide,
            quantityDrift = qtyDrift,
            directionDrift = directionDrift,
            lastSuccessfulSyncAt = syncTime,
            lastAttemptAt = syncTime
        )
    }

    fun syncing(previous: PositionReconciliation?, now: Long = System.currentTimeMillis()) =
        (previous ?: PositionReconciliation()).copy(state = ReconciliationState.SYNCING, lastAttemptAt = now, error = null)

    fun error(previous: PositionReconciliation?, message: String, now: Long = System.currentTimeMillis()) =
        (previous ?: PositionReconciliation()).copy(state = ReconciliationState.ERROR, lastAttemptAt = now, error = message)

    fun stale(previous: PositionReconciliation, maxAgeMs: Long = 30_000L, now: Long = System.currentTimeMillis()): PositionReconciliation =
        if (previous.lastSuccessfulSyncAt <= 0L || now - previous.lastSuccessfulSyncAt > maxAgeMs)
            previous.copy(state = ReconciliationState.STALE)
        else previous
}
