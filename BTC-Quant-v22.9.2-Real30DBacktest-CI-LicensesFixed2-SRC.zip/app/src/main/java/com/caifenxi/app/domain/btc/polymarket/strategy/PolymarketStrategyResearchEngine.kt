package com.caifenxi.app.domain.btc.polymarket.strategy

import com.caifenxi.app.domain.btc.BtcDirection
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Honest walk-forward evaluator for the native reimplementations of public GitHub rules.
 * It uses only the row available at decision time and charges entry cost/slippage.
 */
object PolymarketStrategyResearchEngine {
    data class Config(
        val trainRatio: Double = 0.60,
        val minTrain: Int = 24,
        val minTest: Int = 12,
        val feeRate: Double = 0.002,
        val slippage: Double = 0.003,
        val minEntrySeconds: Long = 45L,
        val maxEntrySeconds: Long = 270L,
        val minSecondsToClose: Long = 15L
    )

    private data class Trade(val pnl: Double, val gross: Double, val cost: Double)

    fun walkForward(
        rows: List<PolymarketResearchRow>,
        definitions: List<PolymarketStrategyPool.Definition> = PolymarketStrategyPool.definitions,
        config: Config = Config()
    ): List<PolymarketStrategyResearchMetric> {
        // Split by market/window, never by individual ticks. This prevents the
        // same 5m market from leaking observations into both train and OOS.
        val windows = rows.groupBy { it.strategyWindowId.ifBlank { it.marketId } }
            .values
            .map { it.sortedBy { row -> row.timestampMs } }
            .sortedBy { it.firstOrNull()?.timestampMs ?: Long.MAX_VALUE }
        if (windows.size < 2) return emptyList()
        val split = (windows.size * config.trainRatio).toInt().coerceIn(1, windows.size - 1)
        val train = windows.take(split).flatten()
        val test = windows.drop(split).flatten()
        if (train.size < config.minTrain) return emptyList()
        return definitions.mapNotNull { def ->
            val trainTrades = simulate(def.id, train, config)
            val testTrades = simulate(def.id, test, config)
            if (testTrades.size < config.minTest) return@mapNotNull null
            val testPf = profitFactor(testTrades)
            val testWin = testTrades.count { it.pnl > 0.0 }.toDouble() / testTrades.size
            val expectancy = testTrades.map { it.pnl }.average()
            val net = testTrades.sumOf { it.pnl }
            val dd = maxDrawdown(testTrades.map { it.pnl })
            val mean = expectancy
            val variance = testTrades.map { (it.pnl - mean) * (it.pnl - mean) }.average()
            val sharpeLike = if (variance <= 1e-12) 0.0 else mean / sqrt(variance) * sqrt(testTrades.size.toDouble())
            val trainWin = if (trainTrades.isEmpty()) 0.5 else trainTrades.count { it.pnl > 0.0 }.toDouble() / trainTrades.size
            val stability = (1.0 - abs(testWin - trainWin)).coerceIn(0.0, 1.0)
            val gross = testTrades.sumOf { it.gross }
            val cost = testTrades.sumOf { it.cost }
            val costDrag = if (abs(gross) < 1e-9) cost else (cost / abs(gross)).coerceIn(0.0, 1.0)
            val score = (
                (testPf - 1.0).coerceIn(-1.0, 1.5) * 0.30 +
                ((testWin - 0.5) * 2.0).coerceIn(-1.0, 1.0) * 0.20 +
                sharpeLike.coerceIn(-2.0, 2.0) / 2.0 * 0.20 +
                stability * 0.15 - costDrag * 0.15
            )
            PolymarketStrategyResearchMetric(
                def.id, trainTrades.size + testTrades.size, trainTrades.size, testTrades.size,
                testWin, testPf, expectancy, dd, net, sharpeLike, stability, costDrag, score
            )
        }.sortedByDescending { it.score }
    }

    private fun simulate(
        strategyId: String,
        rows: List<PolymarketResearchRow>,
        config: Config
    ): List<Trade> {
        val out = ArrayList<Trade>()
        val strategyConfig = PolymarketGithubStrategyLogic.Config(
            minEntrySeconds = config.minEntrySeconds,
            maxEntrySeconds = config.maxEntrySeconds,
            minSecondsToClose = config.minSecondsToClose
        )
        // One entry per strategy window, matching the source strategy's max-bet discipline.
        val byWindow = rows.groupBy { it.strategyWindowId.ifBlank { it.marketId } }
        for (windowRows in byWindow.values) {
            val r = windowRows.sortedBy { it.timestampMs }.firstOrNull() ?: continue
            val elapsed = if (r.remainingSec != null) (300L - r.remainingSec).coerceAtLeast(0L) else null
            val ctx = PolymarketGithubStrategyLogic.Context(
                currentBtc = r.currentBtc,
                priceToBeat = r.priceToBeat,
                elapsedSec = elapsed,
                remainingSec = r.remainingSec,
                upPrice = r.upPrice,
                downPrice = r.downPrice,
                btcReturn15m = r.btcReturn15m,
                volumeRatio = r.volumeRatio,
                spread = r.spread
            )
            if (!PolymarketGithubStrategyLogic.entryWindowOpen(ctx, strategyConfig)) continue
            val d = when (strategyId) {
                "PM-BTC-MOMENTUM" -> PolymarketGithubStrategyLogic.btcMomentum(ctx, strategyConfig)
                "PM-BTC-AND-ODDS" -> PolymarketGithubStrategyLogic.btcAndOdds(ctx, strategyConfig)
                "PM-BTC-OR-ODDS" -> PolymarketGithubStrategyLogic.btcOrOdds(ctx, strategyConfig)
                "PM-BTC-MEAN-REVERT" -> PolymarketGithubStrategyLogic.btcMeanRevert(ctx, strategyConfig)
                "PM-ODDS-FAVORITE" -> PolymarketGithubStrategyLogic.oddsFavorite(ctx, strategyConfig)
                "PM-CONTRARIAN" -> PolymarketGithubStrategyLogic.contrarian(ctx, strategyConfig)
                "PM-HIGH-PROB-CONVERGENCE" -> PolymarketGithubStrategyLogic.highProbabilityConvergence(ctx, strategyConfig)
                "PM-MOMENTUM-15M" -> PolymarketGithubStrategyLogic.momentum15m(ctx, strategyConfig)
                else -> null
            } ?: continue
            val entry = if (d.direction == BtcDirection.UP) r.upAsk else r.downAsk
            val win = r.settledYes?.let { if (d.direction == BtcDirection.UP) it else !it } ?: continue
            val cost = entry * config.feeRate + config.slippage
            val gross = if (win) 1.0 - entry else -entry
            out += Trade(gross - cost, gross, cost)
        }
        return out
    }

    private fun profitFactor(trades: List<Trade>): Double {
        if (trades.isEmpty()) return 0.0
        val wins = trades.filter { it.pnl > 0 }.sumOf { it.pnl }
        val losses = -trades.filter { it.pnl < 0 }.sumOf { it.pnl }
        return if (losses <= 1e-9) if (wins > 0) 9.99 else 0.0 else (wins / losses).coerceAtMost(9.99)
    }

    private fun maxDrawdown(pnls: List<Double>): Double {
        var equity = 0.0
        var peak = 0.0
        var maxDd = 0.0
        pnls.forEach { p ->
            equity += p
            peak = maxOf(peak, equity)
            maxDd = maxOf(maxDd, peak - equity)
        }
        return maxDd
    }
}
