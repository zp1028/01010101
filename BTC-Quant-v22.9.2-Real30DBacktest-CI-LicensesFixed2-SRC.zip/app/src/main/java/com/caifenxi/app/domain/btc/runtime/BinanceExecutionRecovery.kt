package com.caifenxi.app.domain.btc.runtime

import com.caifenxi.app.domain.btc.broker.PerpBroker
import com.caifenxi.app.domain.btc.futures.FuturesOpenOrder

/** REST recovery path. Private WS accelerates updates; REST remains authoritative for recovery. */
class BinanceExecutionRecovery(
    private val broker: PerpBroker,
    private val journal: BinanceExecutionJournal,
    private val uncertainty: ExecutionUncertaintyStore,
    private val persistentExecution: BtcPersistentExecutionStore,
    private val ticketStore: BtcExecutionTicketStore,
    private val audit: BtcExecutionAudit
) {
    sealed class Result {
        data object NothingPending : Result()
        data object Resolved : Result()
        data class Blocked(val reason: String) : Result()
    }

    suspend fun recoverAll(): Result {
        val entries = journal.all()
        if (entries.isEmpty()) return Result.NothingPending
        for (entry in entries) {
            val r = recover(entry)
            if (r is Result.Blocked) return r
        }
        return Result.Resolved
    }

    private suspend fun recover(entry: BinanceExecutionJournal.Entry): Result {
        val result = runCatching { broker.queryOrderStatus(entry.symbol, entry.orderId, entry.clientOrderId) }
            .getOrElse { error ->
                audit.add(BtcExecutionAudit.Entry(entry.decisionId, null, "BINANCE_RECOVERY", "UNKNOWN", error.message.orEmpty()))
                return Result.Blocked("存在未确定订单 ${entry.clientOrderId}，REST 对账失败：${error.message ?: "unknown"}")
            }
        val state = normalize(result.status)
        when (state) {
            CanonicalOrderState.OPEN, CanonicalOrderState.PARTIAL, CanonicalOrderState.FILLED -> {
                journal.resolve(entry.clientOrderId)
                uncertainty.resolve(entry.clientOrderId)
                audit.add(BtcExecutionAudit.Entry(entry.decisionId, result.orderId, "BINANCE_RECOVERY", state.name, "client=${entry.clientOrderId}"))
                // Keep persistent idempotency claim: the order exists and must not be recreated.
                return Result.Resolved
            }
            CanonicalOrderState.CANCELED, CanonicalOrderState.REJECTED, CanonicalOrderState.EXPIRED -> {
                journal.resolve(entry.clientOrderId)
                uncertainty.resolve(entry.clientOrderId)
                persistentExecution.clear(entry.decisionId)
                ticketStore.clear(entry.decisionId)
                audit.add(BtcExecutionAudit.Entry(entry.decisionId, result.orderId, "BINANCE_RECOVERY", state.name, "client=${entry.clientOrderId}"))
                return Result.Resolved
            }
            else -> return Result.Blocked("订单 ${entry.clientOrderId} 状态仍未知：${result.status}")
        }
    }

    private fun normalize(status: String): CanonicalOrderState = when (status.uppercase()) {
        "NEW", "ACCEPTED" -> CanonicalOrderState.OPEN
        "PARTIALLY_FILLED" -> CanonicalOrderState.PARTIAL
        "FILLED" -> CanonicalOrderState.FILLED
        "CANCELED", "CANCELLED" -> CanonicalOrderState.CANCELED
        "REJECTED" -> CanonicalOrderState.REJECTED
        "EXPIRED" -> CanonicalOrderState.EXPIRED
        else -> CanonicalOrderState.UNKNOWN
    }
}
