package com.caifenxi.app.domain.btc.runtime

import java.util.concurrent.CopyOnWriteArrayList

/**
 * v21.1 unified trading lifecycle.
 * Backtest, paper and live share the same event vocabulary; brokers remain the only
 * layer allowed to turn an OrderIntent into an external order.
 */
sealed interface TradingEvent {
    val atMs: Long
    data class Market(override val atMs: Long, val symbol: String, val timeframe: String, val price: Double) : TradingEvent
    data class Signal(override val atMs: Long, val direction: String, val probability: Double, val edge: Double) : TradingEvent
    data class Decision(override val atMs: Long, val action: String, val reason: String) : TradingEvent
    data class Risk(override val atMs: Long, val allowed: Boolean, val reason: String) : TradingEvent
    data class OrderIntent(override val atMs: Long, val clientId: String, val side: String, val quantity: Double, val mode: TradingMode) : TradingEvent
    data class Execution(override val atMs: Long, val clientId: String, val status: String, val orderId: String? = null) : TradingEvent
    data class Fill(override val atMs: Long, val clientId: String, val price: Double, val quantity: Double, val fee: Double) : TradingEvent
    data class Position(override val atMs: Long, val symbol: String, val side: String, val quantity: Double, val entry: Double) : TradingEvent
    data class PnL(override val atMs: Long, val realized: Double, val unrealized: Double, val equity: Double) : TradingEvent
}

enum class TradingMode { BACKTEST, PAPER, TESTNET, LIVE }

data class TradingRuntimeSnapshot(
    val mode: TradingMode = TradingMode.PAPER,
    val lastEventAtMs: Long = 0L,
    val stage: String = "待机",
    val action: String = "等待",
    val riskAllowed: Boolean = false,
    val lastClientId: String? = null,
    val eventCount: Long = 0L,
    val executionGate: String = "待检查"
)

/** In-process event bus. UI observes a projection, never the broker directly. */
class TradingEventBus {
    private val listeners = CopyOnWriteArrayList<(TradingEvent) -> Unit>()
    private val history = ArrayDeque<TradingEvent>()
    private val historyLimit = 200
    fun subscribe(listener: (TradingEvent) -> Unit): () -> Unit {
        listeners += listener
        return { listeners -= listener }
    }
    fun publish(event: TradingEvent) {
        synchronized(history) {
            history.addLast(event)
            while (history.size > historyLimit) history.removeFirst()
        }
        listeners.forEach { it(event) }
    }
    fun recent(limit: Int = 50): List<TradingEvent> = synchronized(history) { history.takeLast(limit.coerceIn(1, historyLimit)) }
}

class TradingOrchestrator(private val bus: TradingEventBus = TradingEventBus()) {
    @Volatile private var snapshot = TradingRuntimeSnapshot()
    fun events(): TradingEventBus = bus
    fun snapshot(): TradingRuntimeSnapshot = snapshot

    fun accept(event: TradingEvent) {
        if (event.atMs < snapshot.lastEventAtMs) return
        snapshot = when (event) {
            is TradingEvent.Market -> snapshot.copy(lastEventAtMs = event.atMs, stage = "行情", eventCount = snapshot.eventCount + 1)
            is TradingEvent.Signal -> snapshot.copy(lastEventAtMs = event.atMs, stage = "信号", action = event.direction, eventCount = snapshot.eventCount + 1)
            is TradingEvent.Decision -> snapshot.copy(lastEventAtMs = event.atMs, stage = "决策", action = event.action, eventCount = snapshot.eventCount + 1)
            is TradingEvent.Risk -> snapshot.copy(lastEventAtMs = event.atMs, stage = "风控", riskAllowed = event.allowed, executionGate = if (event.allowed) "通过" else "阻断", eventCount = snapshot.eventCount + 1)
            is TradingEvent.OrderIntent -> snapshot.copy(lastEventAtMs = event.atMs, stage = "订单意图", lastClientId = event.clientId, mode = event.mode, eventCount = snapshot.eventCount + 1)
            is TradingEvent.Execution -> snapshot.copy(lastEventAtMs = event.atMs, stage = "执行", lastClientId = event.clientId, eventCount = snapshot.eventCount + 1)
            is TradingEvent.Fill -> snapshot.copy(lastEventAtMs = event.atMs, stage = "成交", lastClientId = event.clientId, eventCount = snapshot.eventCount + 1)
            is TradingEvent.Position -> snapshot.copy(lastEventAtMs = event.atMs, stage = "持仓", eventCount = snapshot.eventCount + 1)
            is TradingEvent.PnL -> snapshot.copy(lastEventAtMs = event.atMs, stage = "盈亏", eventCount = snapshot.eventCount + 1)
        }
        bus.publish(event)
    }
}
