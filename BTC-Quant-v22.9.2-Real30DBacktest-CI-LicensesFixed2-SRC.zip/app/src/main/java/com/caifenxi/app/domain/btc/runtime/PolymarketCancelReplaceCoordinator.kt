package com.caifenxi.app.domain.btc.runtime

import com.caifenxi.app.domain.btc.TradingSignal
import com.caifenxi.app.domain.btc.broker.EventMarketBroker
import kotlinx.coroutines.delay

/**
 * v21.3 cancel/replace state machine for authenticated prediction-market orders.
 * A replacement is only submitted after venue confirmation that the old order is no longer live.
 * Any indeterminate cancel freezes the intent instead of risking a duplicate live order.
 */
class PolymarketCancelReplaceCoordinator(
    private val broker: EventMarketBroker,
    private val executionGateway: UnifiedExecutionGateway = UnifiedExecutionGateway(prediction = broker),
    private val lifecycleStore: PolymarketOrderLifecycleStore,
    private val now: () -> Long = { System.currentTimeMillis() }
) {
    data class Request(
        val executionId: String,
        val decisionId: String,
        val oldOrderId: String,
        val replacement: TradingSignal.PredictionMarketSignal,
        val maxConfirmPolls: Int = 4,
        val confirmDelayMs: Long = 350L
    )

    data class Result(
        val ok: Boolean,
        val oldOrderId: String,
        val newOrderId: String? = null,
        val frozen: Boolean = false,
        val message: String
    )

    suspend fun replace(request: Request): Result {
        val old = lifecycleStore.get(request.oldOrderId)
            ?: return Result(false, request.oldOrderId, message = "原订单不存在，禁止替换")

        if (old.stage != PolymarketOrderStage.OPEN && old.stage != PolymarketOrderStage.PARTIAL) {
            return Result(false, request.oldOrderId, message = "原订单状态 ${old.stage.name} 不允许替换")
        }

        lifecycleStore.upsert(old.copy(stage = PolymarketOrderStage.REPLACE_REQUESTED, lastMessage = "等待撤单确认"))
        val cancel = executionGateway.cancelPrediction(request.oldOrderId)
        if (!cancel.ok) {
            val frozen = cancel.indeterminate || cancel.httpCode == 0 || cancel.httpCode >= 500
            lifecycleStore.upsert(old.copy(
                stage = if (frozen) PolymarketOrderStage.UNKNOWN else PolymarketOrderStage.ERROR,
                lastMessage = cancel.message
            ))
            return Result(false, request.oldOrderId, frozen = frozen, message = cancel.message)
        }

        var confirmed = false
        var terminal = "UNKNOWN"
        repeat(request.maxConfirmPolls.coerceIn(1, 10)) {
            val status = broker.getOrderStatus(request.oldOrderId)
            terminal = status.status.uppercase()
            if (terminal in setOf("CANCELED", "CANCELLED", "EXPIRED")) {
                confirmed = true
                return@repeat
            }
            if (terminal in setOf("FILLED", "MATCHED")) {
                lifecycleStore.upsert(old.copy(stage = PolymarketOrderStage.FILLED, lastMessage = "撤单后发现已成交，取消替换"))
                return Result(false, request.oldOrderId, message = "原订单已成交，取消替换")
            }
            delay(request.confirmDelayMs.coerceIn(100L, 2_000L))
        }

        if (!confirmed) {
            lifecycleStore.upsert(old.copy(stage = PolymarketOrderStage.UNKNOWN, lastMessage = "撤单未获最终确认，冻结替换"))
            return Result(false, request.oldOrderId, frozen = true, message = "撤单未确认，禁止提交新订单")
        }

        lifecycleStore.upsert(old.copy(stage = PolymarketOrderStage.REPLACED, lastMessage = "旧订单已确认撤销"))
        val submitted = executionGateway.placePrediction(request.replacement)
        if (!submitted.ok || submitted.orderId.isNullOrBlank()) {
            val frozen = submitted.indeterminate || submitted.httpCode == 0 || submitted.httpCode >= 500
            lifecycleStore.upsert(old.copy(stage = if (frozen) PolymarketOrderStage.UNKNOWN else PolymarketOrderStage.ERROR, lastMessage = submitted.message))
            return Result(false, request.oldOrderId, frozen = frozen, message = submitted.message.ifBlank { "替换订单提交失败" })
        }

        lifecycleStore.upsert(
            PolymarketOrderLifecycle(
                executionId = request.executionId,
                decisionId = request.decisionId,
                orderId = submitted.orderId,
                marketId = request.replacement.marketId,
                outcome = request.replacement.outcome,
                requestedPrice = request.replacement.marketPrice,
                requestedSize = request.replacement.positionSize,
                stage = PolymarketOrderStage.SUBMITTING,
                remainingSize = request.replacement.positionSize,
                createdAt = now(),
                updatedAt = now(),
                lastMessage = "替换订单已提交，等待场所确认"
            )
        )
        return Result(true, request.oldOrderId, submitted.orderId, message = "替换订单已提交")
    }
}
