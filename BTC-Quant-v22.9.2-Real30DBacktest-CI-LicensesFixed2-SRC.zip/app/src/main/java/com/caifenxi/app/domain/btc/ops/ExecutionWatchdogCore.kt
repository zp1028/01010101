package com.caifenxi.app.domain.btc.ops

/** Deterministic watchdog action; the watchdog never submits orders itself. */
enum class WatchdogAction { NOOP, PAUSE_NEW_ORDERS, RECONCILE, HEDGE, KILL_SWITCH }

data class WatchdogInput(
    val alerts: List<OpsAlert>,
    val unhedged: Boolean,
    val recoveryBlocked: Boolean,
    val nowMs: Long = System.currentTimeMillis()
)

data class WatchdogDecision(val action: WatchdogAction, val reason: String)

object ExecutionWatchdogCore {
    fun decide(input: WatchdogInput): WatchdogDecision {
        if (input.recoveryBlocked) return WatchdogDecision(WatchdogAction.KILL_SWITCH, "recovery blocked; preserve state")
        if (input.unhedged) return WatchdogDecision(WatchdogAction.HEDGE, "unhedged exposure requires coordinated hedge")
        if (input.alerts.any { it.code == OpsCode.RECONCILIATION_DRIFT || it.code == OpsCode.BROKER_UNAVAILABLE }) {
            return WatchdogDecision(WatchdogAction.RECONCILE, "venue state cannot be trusted until reconciled")
        }
        if (ExecutionOpsCore.shouldBlockNewOrders(input.alerts)) {
            return WatchdogDecision(WatchdogAction.PAUSE_NEW_ORDERS, "critical operational alert")
        }
        return WatchdogDecision(WatchdogAction.NOOP, "runtime healthy")
    }
}
