package com.caifenxi.app.domain.btc.runtime

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

/** Persistent venue-order lifecycle ledger. It records intent and observed venue state separately. */
enum class PolymarketOrderStage {
    CREATED, SUBMITTING, OPEN, PARTIAL, FILLED, CANCELING, CANCELED, REJECTED, EXPIRED, ERROR, REPLACE_REQUESTED, REPLACED, UNKNOWN
}

data class PolymarketOrderLifecycle(
    val executionId: String,
    val decisionId: String,
    val orderId: String,
    val marketId: String,
    val outcome: String,
    val requestedPrice: Double,
    val requestedSize: Double,
    val stage: PolymarketOrderStage,
    val filledSize: Double = 0.0,
    val remainingSize: Double = 0.0,
    val avgFillPrice: Double = 0.0,
    val grossFillCost: Double = 0.0,
    val fees: Double = 0.0,
    val netFillCost: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val lastMessage: String = ""
)

class PolymarketOrderLifecycleStore(context: Context, private val maxEntries: Int = 300) {
    private val prefs = context.applicationContext.getSharedPreferences("btc_poly_order_lifecycle_v1", Context.MODE_PRIVATE)
    private val orders = ConcurrentHashMap<String, PolymarketOrderLifecycle>()

    init { load() }

    @Synchronized fun upsert(order: PolymarketOrderLifecycle) {
        orders[order.orderId] = order.copy(updatedAt = System.currentTimeMillis())
        trim()
        persist()
    }

    fun get(orderId: String): PolymarketOrderLifecycle? = orders[orderId]

    fun recent(limit: Int = 30): List<PolymarketOrderLifecycle> =
        orders.values.sortedByDescending { it.updatedAt }.take(limit.coerceIn(1, maxEntries))

    fun findByExecutionId(executionId: String): PolymarketOrderLifecycle? =
        orders.values.firstOrNull { it.executionId == executionId }

    @Synchronized fun clear(orderId: String) {
        orders.remove(orderId)
        persist()
    }

    private fun trim() {
        if (orders.size <= maxEntries) return
        orders.values.sortedBy { it.updatedAt }.take(orders.size - maxEntries).forEach { orders.remove(it.orderId) }
    }

    private fun load() = runCatching {
        val a = JSONArray(prefs.getString("orders", "[]"))
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val stage = runCatching { PolymarketOrderStage.valueOf(o.optString("stage", "ERROR")) }.getOrDefault(PolymarketOrderStage.ERROR)
            val item = PolymarketOrderLifecycle(
                executionId = o.optString("executionId"),
                decisionId = o.optString("decisionId"),
                orderId = o.optString("orderId"),
                marketId = o.optString("marketId"),
                outcome = o.optString("outcome"),
                requestedPrice = o.optDouble("requestedPrice", 0.0),
                requestedSize = o.optDouble("requestedSize", 0.0),
                stage = stage,
                filledSize = o.optDouble("filledSize", 0.0),
                remainingSize = o.optDouble("remainingSize", 0.0),
                avgFillPrice = o.optDouble("avgFillPrice", 0.0),
                grossFillCost = o.optDouble("grossFillCost", 0.0),
                fees = o.optDouble("fees", 0.0),
                netFillCost = o.optDouble("netFillCost", 0.0),
                createdAt = o.optLong("createdAt", System.currentTimeMillis()),
                updatedAt = o.optLong("updatedAt", System.currentTimeMillis()),
                lastMessage = o.optString("lastMessage")
            )
            if (item.orderId.isNotBlank()) orders[item.orderId] = item
        }
        trim()
    }

    private fun persist() {
        val a = JSONArray()
        orders.values.sortedBy { it.updatedAt }.takeLast(maxEntries).forEach { x ->
            a.put(JSONObject().apply {
                put("executionId", x.executionId)
                put("decisionId", x.decisionId)
                put("orderId", x.orderId)
                put("marketId", x.marketId)
                put("outcome", x.outcome)
                put("requestedPrice", x.requestedPrice)
                put("requestedSize", x.requestedSize)
                put("stage", x.stage.name)
                put("filledSize", x.filledSize)
                put("remainingSize", x.remainingSize)
                put("avgFillPrice", x.avgFillPrice)
                put("grossFillCost", x.grossFillCost)
                put("fees", x.fees)
                put("netFillCost", x.netFillCost)
                put("createdAt", x.createdAt)
                put("updatedAt", x.updatedAt)
                put("lastMessage", x.lastMessage)
            })
        }
        prefs.edit().putString("orders", a.toString()).apply()
    }
}
