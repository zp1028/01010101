package com.caifenxi.app.domain.btc.ops

/** In-memory bounded incident ledger; persistence can be layered on top without changing decisions. */
class ExecutionIncidentLedger(private val maxEntries: Int = 500) {
    private val entries = java.util.ArrayDeque<OpsAlert>()

    @Synchronized fun record(alert: OpsAlert) {
        entries.addLast(alert)
        while (entries.size > maxEntries) entries.removeFirst()
    }

    @Synchronized fun recent(limit: Int = 50): List<OpsAlert> = entries.toList().takeLast(limit.coerceIn(1, maxEntries))
    @Synchronized fun clear() = entries.clear()
}
