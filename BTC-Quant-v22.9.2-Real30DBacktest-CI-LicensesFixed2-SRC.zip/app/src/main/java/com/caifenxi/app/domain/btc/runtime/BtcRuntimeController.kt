package com.caifenxi.app.domain.btc.runtime

import com.caifenxi.app.domain.btc.BinanceDerivativesRepository
import com.caifenxi.app.domain.btc.BinanceMarketRepository
import com.caifenxi.app.domain.btc.BtcPlanEngine
import com.caifenxi.app.domain.btc.BtcSignalFactory
import com.caifenxi.app.domain.btc.BtcDecisionPipeline
import com.caifenxi.app.domain.btc.DerivativesFeatureEngine
import com.caifenxi.app.domain.btc.news.CryptoNewsRepository
import com.caifenxi.app.domain.btc.ai.AiBrain
import com.caifenxi.app.domain.btc.ai.AiPolicy
import com.caifenxi.app.domain.btc.ai.AiPolicyConfig
import com.caifenxi.app.domain.btc.broker.PerpBroker
import com.caifenxi.app.domain.btc.futures.FuturesQuantConfig
import com.caifenxi.app.domain.btc.futures.FuturesQuantEngine
import com.caifenxi.app.domain.btc.risk.BtcRiskEngine
import com.caifenxi.app.domain.btc.plan.BtcLivePlanPerformance
import com.caifenxi.app.domain.btc.plan.BtcPlanPoolStore
import com.caifenxi.app.domain.btc.research.ResearchRegistry
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope

/** P2 runtime loop + P3 derivatives features. Default PAPER; TESTNET needs injected broker. */
class BtcRuntimeController(
    private val market: BinanceMarketRepository = BinanceMarketRepository(),
    private val derivatives: BinanceDerivativesRepository = BinanceDerivativesRepository(),
    private val newsRepo: CryptoNewsRepository = CryptoNewsRepository(),
    private val aiBrain: AiBrain = AiBrain(),
    private val aiPolicy: AiPolicyConfig = AiPolicyConfig(allowLiveAiOrders = false),
    private val engine: BtcPlanEngine = BtcPlanEngine(),
    private val signalFactory: BtcSignalFactory = BtcSignalFactory(),
    private val futuresEngine: FuturesQuantEngine = FuturesQuantEngine(),
    private val risk: BtcRiskEngine = BtcRiskEngine(),
    private val unifiedRisk: UnifiedRiskEngine = UnifiedRiskEngine(),
    private val store: BtcRuntimeStore,
    private val broker: PerpBroker? = null,
    private val executionGateway: UnifiedExecutionGateway = UnifiedExecutionGateway(perp = broker),
    private val gate: BtcExecutionGate = BtcExecutionGate(),
    private val decisionPipeline: BtcDecisionPipeline = BtcDecisionPipeline(),
    private val ticketStore: BtcExecutionTicketStore = BtcExecutionTicketStore(),
    private val persistentExecutionStore: BtcPersistentExecutionStore = BtcPersistentExecutionStore(store.appContext),
    private val executionUncertaintyStore: ExecutionUncertaintyStore = ExecutionUncertaintyStore(store.appContext),
    private val binanceExecutionJournal: BinanceExecutionJournal = BinanceExecutionJournal(store.appContext),
    private val audit: BtcExecutionAudit = BtcExecutionAudit(store.appContext),
    private val livePerformance: BtcLivePlanPerformance = BtcLivePlanPerformance(),
    /** 云控制面：默认 Noop（不联网、零副作用）；接入真实实现后可远程停市/恢复。 */
    private val controlPlane: BtcControlPlane = NoopBtcControlPlane,
    /** 今日已实现盈亏（USDT），用于日损熔断 */
    private val dayRealizedPnlProvider: () -> Double = { 0.0 },
    /** Optional futures-quant config. When supplied, live execution uses these parameters instead of hard-coded factory defaults. */
    private val futuresConfigProvider: () -> FuturesQuantConfig? = { null },
    /** Shared persisted strategy-pool config. The unattended runtime uses the same switches/weights as the UI. */
    private val planPoolProvider: () -> BtcPlanPoolStore.Config = { BtcPlanPoolStore(store.appContext).load() },
    /** Realtime Binance private-stream health can latch a mandatory REST reconciliation. */
    private val privateReconciliationGate: BinancePrivateReconciliationGate? = null,
    /** Canonical private-event projection; WS accelerates, REST remains authoritative. */
    private val privateEventStore: com.caifenxi.app.domain.btc.BinancePrivateEventStore? = null,
    /** Only validated ACTIVE research artifacts may affect runtime weights. */
    private val researchRegistry: ResearchRegistry = ResearchRegistry(store.appContext),
    private val canonicalReconciliation: BinanceCanonicalReconciliation = BinanceCanonicalReconciliation(binanceExecutionJournal, privateEventStore)
) {
    /** 本节点标识（云端控制面按节点分发命令；Noop 实现忽略该值）。 */
    companion object {
        private const val NODE_ID = "btc-quant-default"
    }

    suspend fun runOnce() {
        val cfg = store.config()
        if (!cfg.enabled || store.state().killSwitch) return
        // v22.2: recover every indeterminate Binance submission before generating any new order.
        // If venue state cannot be established, the entire execution loop is frozen.
        if (cfg.runMode != BtcRunMode.PAPER) {
            // v22.3: private WS observations feed the same canonical state machine before REST recovery.
            canonicalReconciliation.applyPrivateEvents()
            val b = broker
            if (b == null) {
                if (binanceExecutionJournal.all().isNotEmpty()) {
                    store.update { it.copy(status = BtcRuntimeStatus.ERROR, lastError = "存在未确定订单但 Broker 不可用，执行冻结") }
                    return
                }
            } else {
                val recovery = BinanceExecutionRecovery(
                    broker = b, journal = binanceExecutionJournal, uncertainty = executionUncertaintyStore,
                    persistentExecution = persistentExecutionStore, ticketStore = ticketStore, audit = audit
                ).recoverAll()
                if (recovery is BinanceExecutionRecovery.Result.Blocked) {
                    store.update { it.copy(status = BtcRuntimeStatus.ERROR, lastError = recovery.reason, lastHeartbeatAt = System.currentTimeMillis()) }
                    return
                }
            }
        }
        // 云控制面：拉取远程命令并执行（KILL/RESUME/STOP 等安全控制）。
        // Noop 返回空列表，任何远程异常都不影响本地执行主循环。
        runCatching {
            val commands = controlPlane.pullCommands(NODE_ID)
            if (commands.isNotEmpty()) {
                val processor = BtcRemoteCommandProcessor(store)
                commands.forEach { cmd ->
                    val ok = processor.apply(cmd)
                    controlPlane.ack(cmd.commandId, ok)
                }
            }
        }
        if (!store.config().enabled || store.state().killSwitch) return
        val reconciliationRequest = privateReconciliationGate?.consume()
        if (reconciliationRequest != null && cfg.runMode != BtcRunMode.PAPER) {
            val b = broker
            if (b == null) {
                store.update { it.copy(status = BtcRuntimeStatus.PAUSED, lastError = "私有WS断档待对账，但Broker不可用，禁止继续执行") }
                return
            }
            val reconciliation = runCatching {
                val position = b.fetchPositionRisk(cfg.symbol)
                val orders = b.fetchOpenOrders(cfg.symbol)
                position to orders
            }.getOrElse { error ->
                audit.add(BtcExecutionAudit.Entry(decisionId = "", executionId = null, stage = "PRIVATE_WS_RECONCILE", outcome = "FAILED", detail = error.message.orEmpty()))
                store.update { it.copy(status = BtcRuntimeStatus.PAUSED, lastError = "私有WS断档，对账失败，暂停执行：${error.message ?: "unknown"}") }
                return
            }
            audit.add(BtcExecutionAudit.Entry(decisionId = "", executionId = null, stage = "PRIVATE_WS_RECONCILE", outcome = "OK", detail = "reason=${reconciliationRequest.reason}; position=${reconciliation.first?.positionAmt ?: 0.0}; openOrders=${reconciliation.second.size}"))
            store.update { it.copy(status = BtcRuntimeStatus.RUNNING, lastError = null, lastHeartbeatAt = System.currentTimeMillis()) }
        }
        coroutineScope {
            val candlesDef = async { runCatching { market.loadKlines(cfg.symbol, cfg.timeframe, 300) }.getOrDefault(emptyList()) }
            val futuresCfgForData = futuresConfigProvider()
            val mtf15Def = async {
                if (futuresCfgForData != null && cfg.timeframe != "15m")
                    runCatching { market.loadKlines(cfg.symbol, "15m", 200) }.getOrDefault(emptyList())
                else emptyList()
            }
            val mtf1hDef = async {
                if (futuresCfgForData != null && cfg.timeframe != "1h")
                    runCatching { market.loadKlines(cfg.symbol, "1h", 200) }.getOrDefault(emptyList())
                else emptyList()
            }
            val fundingDef = async {
                runCatching { derivatives.fundingHistory(cfg.symbol, 100) }.getOrDefault(emptyList())
            }
            val oiDef = async {
                runCatching { derivatives.openInterestHistory(cfg.symbol, cfg.timeframe.ifBlank { "15m" }, 100) }
                    .getOrDefault(emptyList())
            }
            val snapDef = async {
                runCatching { derivatives.snapshot(cfg.symbol) }.getOrNull()
            }
            val candles = candlesDef.await()
            if (candles.isEmpty()) return@coroutineScope
            // Only make a decision from a completed candle. Binance may return the
            // currently-forming candle as the last item; using it would make the
            // signal change intrabar and can create inconsistent execution.
            val decisionIndex = candles.indexOfLast { it.openTime + timeframeMillis(cfg.timeframe) <= System.currentTimeMillis() }
            if (decisionIndex < 0) return@coroutineScope
            val decisionCandles = candles.subList(0, decisionIndex + 1)
            val last = decisionCandles.last()
            val current = store.state()
            // Paper account is stateful and survives process death. Mark the open
            // position before deciding whether this bar is already processed.
            if (cfg.runMode == BtcRunMode.PAPER) {
                val paper = store.paperLedger()
                paper.mark(last.close)
                if (paper.shouldCloseAt(last.close)) {
                    paper.close(last.close)
                    store.update { it.copy(lastError = null, lastHeartbeatAt = System.currentTimeMillis()) }
                }
            }
            if (current.lastBarId == last.openTime) {
                store.update {
                    it.copy(status = BtcRuntimeStatus.RUNNING, lastHeartbeatAt = System.currentTimeMillis())
                }
                return@coroutineScope
            }
            val funding = fundingDef.await()
            val oi = oiDef.await()
            val snap = snapDef.await()
            val mtfCandles = buildMap<String, List<com.caifenxi.app.domain.btc.BtcCandle>> {
                mtf15Def.await().takeIf { it.isNotEmpty() }?.let { put("15m", it) }
                mtf1hDef.await().takeIf { it.isNotEmpty() }?.let { put("1h", it) }
            }
            val prev = decisionCandles.getOrNull(decisionCandles.lastIndex - 1)
            val deriv = DerivativesFeatureEngine.build(
                barTime = last.openTime,
                close = last.close,
                prevClose = prev?.close,
                fundingHistory = funding,
                oiHistory = oi,
                snapshot = snap
            )
            val news = runCatching { newsRepo.snapshot() }.getOrNull()
            // Refresh plan performance once per completed bar. This makes the
            // registry/lifecycle/dynamic-weight stack actually influence live decisions.
            val perf = livePerformance.get(decisionCandles, deriv)
            val pool = planPoolProvider()
            val research = researchRegistry.activeBefore(last.openTime)
            val factorResearchWeights = research?.artifact?.factorWeights?.mapValues { it.value.coerceIn(0.0, 1.0) } ?: emptyMap()
            val strategyResearchWeights = research?.artifact?.strategyWeights?.mapValues { it.value.coerceIn(0.0, 1.0) } ?: emptyMap()
            val (basePlans, baseConsensus) = engine.evaluate(
                decisionCandles, deriv, perf = perf,
                weightOverrides = pool.weightOverrides, enabledPlanIds = pool.enabledPlans,
                factorRuntimeWeights = factorResearchWeights, strategyRuntimeWeights = strategyResearchWeights
            )
            val aiCand = aiBrain.generateCandidate(decisionCandles, basePlans, baseConsensus, news, deriv)
            if (news?.blackSwan == true && aiPolicy.haltOnBlackSwan) {
                store.update { it.copy(
                    status = BtcRuntimeStatus.PAUSED,
                    lastError = "新闻黑天鹅熔断",
                    lastHeartbeatAt = System.currentTimeMillis(),
                    lastBarId = last.openTime
                ) }
                return@coroutineScope
            }
            val aiPlan = AiPolicy.toPlanSignal(aiCand, aiPolicy)
            val (plans, consensus) = if (aiPlan != null) {
                engine.evaluate(
                    decisionCandles, deriv, perf = perf, extraSignals = listOf(aiPlan),
                    weightOverrides = pool.weightOverrides, enabledPlanIds = pool.enabledPlans,
                    factorRuntimeWeights = factorResearchWeights, strategyRuntimeWeights = strategyResearchWeights
                )
            } else basePlans to baseConsensus
            val tradingDecision = if (consensus != null) {
                decisionPipeline.build(cfg.symbol, cfg.timeframe, decisionCandles, plans, consensus, minProbabilityOverride = cfg.minProbability)
            } else null
            val futuresCfg = futuresConfigProvider()
            val signal = if (consensus != null && tradingDecision != null &&
                tradingDecision.action != com.caifenxi.app.domain.btc.DecisionAction.WAIT &&
                tradingDecision.action != com.caifenxi.app.domain.btc.DecisionAction.BLOCK) {
                val rawSignal = signalFactory.buildPerpSignal(
                    cfg.symbol, decisionCandles, plans, consensus, cfg.maxPositionQty,
                    leverageCap = (futuresCfg?.leverage ?: cfg.maxLeverage).coerceAtMost(futuresCfg?.maxLeverage ?: cfg.maxLeverage),
                    stopLossAtrMult = futuresCfg?.stopLossAtrMult ?: 1.5,
                    takeProfitAtrMult = futuresCfg?.takeProfitAtrMult ?: 3.0
                )
                if (futuresCfg != null) {
                    // Higher-timeframe alignment is a hard execution filter, while
                    // the base plan pool remains responsible for direction/edge.
                    val fq = futuresEngine.evaluateMultiTimeframe(
                        consensus, decisionCandles, mtfCandles, futuresCfg,
                        balance = 10_000.0, deriv = deriv
                    )
                    if (fq == null) null else rawSignal
                } else rawSignal
            } else null
            // Publish the latest signal/market diagnostics first, but DO NOT
            // advance lastBarId yet. A failed broker call must remain retryable.
            store.update {
                it.copy(
                    status = BtcRuntimeStatus.RUNNING,
                    lastHeartbeatAt = System.currentTimeMillis(),
                    lastSignal = consensus?.direction,
                    lastError = null,
                    lastFundingRate = deriv.fundingRate,
                    lastOiChangePct = deriv.oiChangePct,
                    lastDerivScore = deriv.derivativesScore
                )
            }
            if (signal == null || consensus == null) {
                store.update {
                    it.copy(
                        lastBarId = last.openTime,
                        processedBars = it.processedBars + 1
                    )
                }
                return@coroutineScope
            }
            val dayPnl = dayRealizedPnlProvider()
            // v9: 风控基准使用真实/纸面账户权益，不再固定 1000U。
            val equity = when (cfg.runMode) {
                BtcRunMode.PAPER -> store.paperLedger().snapshot().equity
                BtcRunMode.TESTNET, BtcRunMode.LIVE -> {
                    val b = broker
                    if (b == null) {
                        store.update { it.copy(status = BtcRuntimeStatus.ERROR, lastError = "Broker 未注入，无法读取账户权益") }
                        return@coroutineScope
                    }
                    runCatching { b.accountSnapshot().totalWalletBalance }
                        .getOrElse { error ->
                            audit.add(BtcExecutionAudit.Entry(decisionId = tradingDecision?.decisionId.orEmpty(), executionId = null, stage = "RECONCILE", outcome = "FAILED", detail = error.message.orEmpty()))
                            store.update { it.copy(status = BtcRuntimeStatus.ERROR, lastError = "账户对账失败：${error.message ?: "unknown"}") }
                            return@coroutineScope
                        }
                }
            }
            val previousPeak = store.state().peakEquityUsdt
            val peak = maxOf(previousPeak, equity)
            val drawdownPct = if (peak > 0.0) ((peak - equity) / peak * 100.0).coerceAtLeast(0.0) else 0.0
            store.update { it.copy(lastEquityUsdt = equity, peakEquityUsdt = peak, currentDrawdownPct = drawdownPct) }
            if (futuresCfg != null) {
                val dailyLossPct = if (equity > 0.0) (-dayPnl / equity * 100.0).coerceAtLeast(0.0) else 0.0
                if (dailyLossPct >= futuresCfg.maxDailyLossPct || drawdownPct >= futuresCfg.maxDrawdownPct) {
                    val reason = if (dailyLossPct >= futuresCfg.maxDailyLossPct)
                        "合约日损百分比熔断 ${"%.2f".format(dailyLossPct)}% >= ${futuresCfg.maxDailyLossPct}%"
                    else "合约回撤熔断 ${"%.2f".format(drawdownPct)}% >= ${futuresCfg.maxDrawdownPct}%"
                    store.update { it.copy(status = BtcRuntimeStatus.PAUSED, lastError = reason) }
                    return@coroutineScope
                }
            }
            val decision = risk.authorizeByEquity(
                consensus = consensus,
                dailyPnlUsdt = dayPnl,
                equityUsdt = equity,
                currentDrawdownPct = drawdownPct,
                requestedNotionalUsdt = signal.positionSize * signal.entry
            )
            audit.add(BtcExecutionAudit.Entry(decisionId = tradingDecision?.decisionId.orEmpty(), executionId = null, stage = "RISK", outcome = if (decision.allowed) "ALLOW" else "BLOCK", detail = decision.reason))
            if (!decision.allowed) {
                store.update { it.copy(status = BtcRuntimeStatus.PAUSED, lastError = decision.reason) }
                return@coroutineScope
            }
            // v22: size first, then apply the single final risk authority.
            val desiredQtyByPct = futuresCfg?.let {
                (equity * it.positionSizePct / 100.0 / signal.entry).coerceAtLeast(0.0)
            }
            val sized = signal.copy(
                positionSize = minOf(signal.positionSize, cfg.maxPositionQty, desiredQtyByPct ?: signal.positionSize),
                leverageCap = signal.leverageCap.coerceAtMost(cfg.maxLeverage).coerceAtMost(futuresCfg?.maxLeverage ?: cfg.maxLeverage)
            )
            // v22: one final risk authority. UNKNOWN is a hard execution block.
            val unifiedDecision = unifiedRisk.evaluate(
                UnifiedRiskInput(
                    mode = when (cfg.runMode) {
                        BtcRunMode.PAPER -> TradingMode.PAPER
                        BtcRunMode.TESTNET -> TradingMode.TESTNET
                        BtcRunMode.LIVE -> TradingMode.LIVE
                    },
                    symbol = sized.symbol,
                    equityUsdt = equity,
                    dailyPnlUsdt = dayPnl,
                    drawdownPct = drawdownPct,
                    requestedNotionalUsdt = signal.positionSize * signal.entry,
                    requestedQty = signal.positionSize,
                    positionDeltaQty = if (sized.direction == com.caifenxi.app.domain.btc.BtcDirection.UP) sized.positionSize else -sized.positionSize,
                    maxOrderNotionalUsdt = cfg.maxNotionalUsdt,
                    maxPositionQty = cfg.maxPositionQty,
                    killSwitch = store.state().killSwitch
                )
            )
            audit.add(BtcExecutionAudit.Entry(decisionId = tradingDecision?.decisionId.orEmpty(), executionId = null, stage = "UNIFIED_RISK", outcome = unifiedDecision.status.name, detail = unifiedDecision.reason))
            if (!unifiedDecision.allowed) {
                store.update { it.copy(status = if (unifiedDecision.status == UnifiedRiskStatus.UNKNOWN) BtcRuntimeStatus.ERROR else BtcRuntimeStatus.PAUSED, lastError = unifiedDecision.reason) }
                return@coroutineScope
            }
            // LIVE/TESTNET 额外硬闸门
            val notional = sized.positionSize * sized.entry
            if (notional > cfg.maxNotionalUsdt) {
                store.update { it.copy(status = BtcRuntimeStatus.PAUSED, lastError = "单笔名义超限: ${"%.2f".format(notional)} > ${"%.2f".format(cfg.maxNotionalUsdt)}") }
                return@coroutineScope
            }
            val liveGate = LiveUnattendedGuard.authorizeOrder(
                cfg = cfg,
                state = store.state(),
                consensus = consensus,
                signal = sized,
                dayRealizedPnl = dayPnl
            )
            if (!liveGate.allowed) {
                store.update {
                    it.copy(
                        status = BtcRuntimeStatus.PAUSED,
                        lastError = "Guard: ${liveGate.reason}",
                        lastHeartbeatAt = System.currentTimeMillis()
                    )
                }
                return@coroutineScope
            }
            val td = tradingDecision ?: return@coroutineScope
            audit.add(BtcExecutionAudit.Entry(decisionId = td.decisionId, executionId = null, stage = "DECISION", outcome = td.action.name, detail = td.context.reason))
            val lastOrderAt = store.state().lastOrderAt
            if (lastOrderAt > 0L && System.currentTimeMillis() - lastOrderAt < cfg.minOrderIntervalSec * 1000L) {
                audit.add(BtcExecutionAudit.Entry(decisionId = td.decisionId, executionId = null, stage = "COOLDOWN", outcome = "BLOCK", detail = "minOrderIntervalSec=${cfg.minOrderIntervalSec}"))
                store.update { it.copy(status = BtcRuntimeStatus.PAUSED, lastBarId = last.openTime, processedBars = it.processedBars + 1, lastError = "执行冷却中：距离上一笔订单不足 ${cfg.minOrderIntervalSec}s") }
                return@coroutineScope
            }
            if (!gate.claimBar(sized.symbol, cfg.timeframe, sized.barId)) return@coroutineScope
            val executionKey = gate.key(sized.symbol, cfg.timeframe, sized.barId)
            if (!persistentExecutionStore.claim(td.decisionId)) {
                // A prior process already claimed this exact decision. Treat it as
                // an idempotency suppression rather than generating another order.
                gate.release(executionKey)
                store.update { it.copy(
                    status = BtcRuntimeStatus.RUNNING,
                    lastBarId = last.openTime,
                    processedBars = it.processedBars + 1,
                    lastError = "幂等保护：该决策已执行/已提交，跳过重复订单",
                    lastHeartbeatAt = System.currentTimeMillis()
                ) }
                return@coroutineScope
            }
            val ticket = ticketStore.claim(td.decisionId, sized.symbol, cfg.timeframe, sized.barId, td.action.name)
            if (ticket == null) {
                persistentExecutionStore.clear(td.decisionId)
                gate.release(executionKey)
                return@coroutineScope
            }
            try {
                audit.add(BtcExecutionAudit.Entry(decisionId = td.decisionId, executionId = ticket.executionId, stage = "EXECUTION", outcome = "START", detail = ticket.clientOrderId))
                if (cfg.runMode != BtcRunMode.PAPER) {
                    binanceExecutionJournal.put(
                        BinanceExecutionJournal.Entry(
                            clientOrderId = ticket.clientOrderId, decisionId = td.decisionId, symbol = sized.symbol,
                            mode = cfg.runMode.name, requestedQty = sized.positionSize,
                            side = if (sized.direction == com.caifenxi.app.domain.btc.BtcDirection.UP) "BUY" else "SELL",
                            createdAt = System.currentTimeMillis(), state = CanonicalOrderState.SUBMITTING
                        )
                    )
                }
                val coreMode = when (cfg.runMode) {
                    BtcRunMode.PAPER -> TradingMode.PAPER
                    BtcRunMode.TESTNET -> TradingMode.TESTNET
                    BtcRunMode.LIVE -> TradingMode.LIVE
                }
                val coreAdapter: TradingCoreAdapter = if (coreMode == TradingMode.PAPER) {
                    TradingCorePaperAdapter(coreMode, store)
                } else {
                    TradingCorePerpAdapter(coreMode, executionGateway)
                }
                val core = TradingCore(
                    unifiedRisk = unifiedRisk,
                    adapters = listOf(coreAdapter),
                    eventSink = { event ->
                        when (event) {
                            is TradingEvent.Risk -> audit.add(BtcExecutionAudit.Entry(td.decisionId, ticket.executionId, "TRADING_CORE_RISK", if (event.allowed) "ALLOW" else "BLOCK", event.reason))
                            is TradingEvent.Execution -> audit.add(BtcExecutionAudit.Entry(td.decisionId, ticket.executionId, "TRADING_CORE_EXECUTION", event.status, "client=${event.clientId};order=${event.orderId}"))
                            else -> Unit
                        }
                    }
                )
                val coreIntent = TradingCoreIntent(
                    decisionId = td.decisionId, clientId = ticket.clientOrderId, symbol = sized.symbol,
                    side = if (sized.direction == com.caifenxi.app.domain.btc.BtcDirection.UP) OrderSide.BUY else OrderSide.SELL,
                    quantity = sized.positionSize, price = sized.entry, mode = coreMode,
                    metadata = mapOf(
                        "planId" to (sized.reasonPlanIds.firstOrNull() ?: "RUNTIME"),
                        "barId" to sized.barId.toString(), "probability" to sized.probability.toString(),
                        "expectedMovePct" to sized.expectedMovePct.toString(), "stopLoss" to sized.stopLoss.toString(),
                        "takeProfit" to sized.takeProfit.toString(), "horizonBars" to sized.horizonBars.toString(),
                        "leverage" to sized.leverageCap.toString(), "confidence" to sized.confidence.toString()
                    )
                )
                val coreRisk = UnifiedRiskInput(
                    mode = coreMode, symbol = sized.symbol, equityUsdt = equity, dailyPnlUsdt = dayPnl,
                    drawdownPct = drawdownPct, requestedNotionalUsdt = sized.positionSize * sized.entry,
                    requestedQty = sized.positionSize,
                    positionDeltaQty = if (sized.direction == com.caifenxi.app.domain.btc.BtcDirection.UP) sized.positionSize else -sized.positionSize,
                    maxOrderNotionalUsdt = cfg.maxNotionalUsdt, maxPositionQty = cfg.maxPositionQty,
                    killSwitch = store.state().killSwitch
                )
                val result = when (cfg.runMode) {
                    BtcRunMode.PAPER -> {
                        val coreResult = core.execute(TradingCoreRequest(coreIntent, coreRisk))
                        if (!coreResult.allowed) {
                            throw IllegalStateException("TradingCore 阻断: ${coreResult.message}")
                        }
                        val execution = coreResult.execution
                        com.caifenxi.app.domain.btc.broker.BrokerOrderResult(
                            success = execution?.status == OrderStatus.FILLED || execution?.status == OrderStatus.OPEN || execution?.status == OrderStatus.PARTIAL,
                            orderId = null, clientOrderId = ticket.clientOrderId,
                            status = execution?.status?.name ?: "UNKNOWN", message = coreResult.message
                        )
                    }
                    BtcRunMode.TESTNET, BtcRunMode.LIVE -> {
                        val b = broker ?: run {
                            store.update {
                                it.copy(
                                    status = BtcRuntimeStatus.ERROR,
                                    lastError = "Broker 未注入，未标记本 bar 已处理"
                                )
                            }
                            gate.release(executionKey)
                            ticketStore.clear(td.decisionId)
                            persistentExecutionStore.clear(td.decisionId)
                            return@coroutineScope
                        }
                        // Broker 侧再次确认当前持仓，避免应用重启/网络重试造成重复加仓。
                        val existingResult = runCatching { b.fetchPositionRisk(sized.symbol) }
                        val existing = existingResult.getOrElse {
                            audit.add(BtcExecutionAudit.Entry(decisionId = td.decisionId, executionId = ticket.executionId, stage = "RECONCILE", outcome = "FAILED", detail = it.message.orEmpty()))
                            throw IllegalStateException("持仓对账失败，拒绝继续下单: ${it.message ?: "unknown"}")
                        }
                        audit.add(BtcExecutionAudit.Entry(decisionId = td.decisionId, executionId = ticket.executionId, stage = "RECONCILE", outcome = "OK", detail = "position=${existing?.positionAmt ?: 0.0}"))
                        if (existing != null && kotlin.math.abs(existing.positionAmt) > 1e-9) {
                            val existingDirection = if (existing.positionAmt > 0) com.caifenxi.app.domain.btc.BtcDirection.UP else com.caifenxi.app.domain.btc.BtcDirection.DOWN
                            if (existingDirection == sized.direction) {
                                gate.release(executionKey)
                                ticketStore.clear(td.decisionId)
                                persistentExecutionStore.clear(td.decisionId)
                                store.update { it.copy(
                                    status = BtcRuntimeStatus.RUNNING,
                                    lastBarId = last.openTime,
                                    processedBars = it.processedBars + 1,
                                    lastError = "已有同向持仓，跳过重复开仓"
                                ) }
                                return@coroutineScope
                            }
                        }
                        // 设杠杆后市价开仓
                        val lev = runCatching { executionGateway.setPerpLeverage(sized.symbol, sized.leverageCap) }.getOrNull()
                        if (lev != null && !lev.success) {
                            gate.release(executionKey)
                            ticketStore.clear(td.decisionId)
                            persistentExecutionStore.clear(td.decisionId)
                            store.update { it.copy(status = BtcRuntimeStatus.ERROR, lastError = "杠杆设置失败: ${lev.message}") }
                            return@coroutineScope
                        }
                        val clientId = ticket.clientOrderId
                        val coreResult = core.execute(TradingCoreRequest(coreIntent, coreRisk))
                        if (!coreResult.allowed) {
                            throw IllegalStateException("TradingCore 阻断: ${coreResult.message}")
                        }
                        val entryExecution = coreResult.execution
                        val entryRes = com.caifenxi.app.domain.btc.broker.BrokerOrderResult(
                            success = entryExecution?.status == OrderStatus.FILLED || entryExecution?.status == OrderStatus.OPEN || entryExecution?.status == OrderStatus.PARTIAL,
                            orderId = entryExecution?.orderId?.toLongOrNull(),
                            clientOrderId = clientId,
                            status = entryExecution?.status?.name ?: "UNKNOWN",
                            message = coreResult.message
                        )
                        if (entryRes.success && cfg.requireBracketOrders) {
                            val closeSide = if (sized.direction == com.caifenxi.app.domain.btc.BtcDirection.UP) "SELL" else "BUY"
                            val sl = executionGateway.placePerpConditional(
                                symbol = sized.symbol, side = closeSide,
                                type = com.caifenxi.app.domain.btc.futures.FuturesOrderType.STOP_MARKET,
                                quantity = sized.positionSize, stopPrice = sized.stopLoss,
                                clientOrderId = ("sl-" + clientId).take(36)
                            )
                            val tp = executionGateway.placePerpConditional(
                                symbol = sized.symbol, side = closeSide,
                                type = com.caifenxi.app.domain.btc.futures.FuturesOrderType.TAKE_PROFIT_MARKET,
                                quantity = sized.positionSize, stopPrice = sized.takeProfit,
                                clientOrderId = ("tp-" + clientId).take(36)
                            )
                            if (!sl.success || !tp.success) {
                                audit.add(BtcExecutionAudit.Entry(decisionId = td.decisionId, executionId = ticket.executionId, stage = "BRACKET", outcome = "FAILED", detail = "SL=${sl.success},TP=${tp.success}"))
                                // Do not leave an unprotected live position. Close and verify the result.
                                val closeRes = runCatching { executionGateway.closePerpPosition(com.caifenxi.app.domain.btc.futures.ClosePositionRequest(sized.symbol, reason = "bracket_failed")) }.getOrNull()
                                val remaining = runCatching { b.fetchPositionRisk(sized.symbol) }.getOrNull()
                                val protectedClosed = closeRes?.success == true && (remaining == null || kotlin.math.abs(remaining.positionAmt) <= 1e-9)
                                audit.add(BtcExecutionAudit.Entry(decisionId = td.decisionId, executionId = ticket.executionId, stage = "BRACKET", outcome = if (protectedClosed) "CLOSED" else "KILL", detail = "close=${closeRes?.success};remaining=${remaining?.positionAmt}"))
                                if (!protectedClosed) {
                                    store.setKillSwitch(true)
                                    throw IllegalStateException("BRACKET_FAILED_FATAL: 无法确认未保护仓位已关闭")
                                }
                                throw IllegalStateException("BRACKET_FAILED: SL/TP 挂单失败，仓位已关闭")
                            }
                            audit.add(BtcExecutionAudit.Entry(decisionId = td.decisionId, executionId = ticket.executionId, stage = "BRACKET", outcome = "SUCCESS", detail = "SL/TP placed"))
                        }
                        entryRes
                    }
                }

                if (result.success) {
                    if (cfg.runMode != BtcRunMode.PAPER) {
                        binanceExecutionJournal.resolve(ticket.clientOrderId)
                        executionUncertaintyStore.resolve(ticket.clientOrderId)
                    }
                    audit.add(BtcExecutionAudit.Entry(decisionId = td.decisionId, executionId = ticket.executionId, stage = "EXECUTION", outcome = "SUCCESS", detail = result.message))
                    store.update {
                        it.copy(
                            status = BtcRuntimeStatus.RUNNING,
                            lastBarId = last.openTime,
                            processedBars = it.processedBars + 1,
                            lastOrderClientId = result.clientOrderId,
                            lastError = null,
                            consecutiveErrors = 0,
                            lastOrderAt = System.currentTimeMillis(),
                            lastHeartbeatAt = System.currentTimeMillis()
                        )
                    }
                } else {
                    val indeterminate = cfg.runMode != BtcRunMode.PAPER && isIndeterminateBrokerResult(result.status, result.message)
                    gate.release(executionKey)
                    if (indeterminate) {
                        executionUncertaintyStore.put(ticket.clientOrderId, td.decisionId, sized.symbol, cfg.runMode.name, result.message)
                        binanceExecutionJournal.put(
                            BinanceExecutionJournal.Entry(
                                clientOrderId = ticket.clientOrderId, decisionId = td.decisionId, symbol = sized.symbol, mode = cfg.runMode.name,
                                requestedQty = sized.positionSize, side = if (sized.direction == com.caifenxi.app.domain.btc.BtcDirection.UP) "BUY" else "SELL",
                                createdAt = System.currentTimeMillis(), state = CanonicalOrderState.UNKNOWN, message = result.message
                            )
                        )
                        audit.add(BtcExecutionAudit.Entry(decisionId = td.decisionId, executionId = ticket.executionId, stage = "EXECUTION", outcome = "UNKNOWN", detail = result.message))
                        store.update { it.copy(status = BtcRuntimeStatus.ERROR, lastError = "订单状态未知，已冻结并等待对账：${result.message}" ) }
                        return@coroutineScope
                    }
                    ticketStore.clear(td.decisionId)
                    persistentExecutionStore.clear(td.decisionId)
                    if (cfg.runMode != BtcRunMode.PAPER) { binanceExecutionJournal.resolve(ticket.clientOrderId) }
                    audit.add(BtcExecutionAudit.Entry(decisionId = td.decisionId, executionId = ticket.executionId, stage = "EXECUTION", outcome = "FAILED", detail = result.message))
                    val errs = store.state().consecutiveErrors + 1
                    val kill = errs >= cfg.maxConsecutiveErrors && cfg.runMode != BtcRunMode.PAPER
                    store.update {
                        it.copy(
                            status = if (kill) BtcRuntimeStatus.KILLED else BtcRuntimeStatus.ERROR,
                            lastError = "订单失败: ${result.status} ${result.message}".trim(),
                            consecutiveErrors = errs,
                            killSwitch = if (kill) true else it.killSwitch
                        )
                    }
                }
            } catch (e: Exception) {
                gate.release(executionKey)
                if (cfg.runMode != BtcRunMode.PAPER) {
                    executionUncertaintyStore.put(ticket.clientOrderId, td.decisionId, sized.symbol, cfg.runMode.name, e.message.orEmpty())
                    binanceExecutionJournal.put(
                        BinanceExecutionJournal.Entry(
                            clientOrderId = ticket.clientOrderId, decisionId = td.decisionId, symbol = sized.symbol, mode = cfg.runMode.name,
                            requestedQty = sized.positionSize, side = if (sized.direction == com.caifenxi.app.domain.btc.BtcDirection.UP) "BUY" else "SELL",
                            createdAt = System.currentTimeMillis(), state = CanonicalOrderState.UNKNOWN, message = e.message.orEmpty()
                        )
                    )
                    audit.add(BtcExecutionAudit.Entry(decisionId = td.decisionId, executionId = ticket.executionId, stage = "EXECUTION", outcome = "UNKNOWN", detail = e.message.orEmpty()))
                } else {
                    ticketStore.clear(td.decisionId)
                    persistentExecutionStore.clear(td.decisionId)
                    if (cfg.runMode != BtcRunMode.PAPER) { binanceExecutionJournal.resolve(ticket.clientOrderId) }
                    audit.add(BtcExecutionAudit.Entry(decisionId = td.decisionId, executionId = ticket.executionId, stage = "EXECUTION", outcome = "EXCEPTION", detail = e.message.orEmpty()))
                }
                val errs = store.state().consecutiveErrors + 1
                val kill = errs >= cfg.maxConsecutiveErrors && cfg.runMode != BtcRunMode.PAPER
                store.update {
                    it.copy(
                        status = if (kill) BtcRuntimeStatus.KILLED else BtcRuntimeStatus.ERROR,
                        lastError = e.message ?: "runtime execution failed",
                        consecutiveErrors = errs,
                        killSwitch = if (kill) true else it.killSwitch
                    )
                }
            }
        }
        // 云控制面：每次执行结束上报心跳（Noop 忽略，不影响本地主循环）。
        runCatching {
            val s = store.state()
            controlPlane.heartbeat(
                BtcHeartbeat(
                    nodeId = NODE_ID,
                    status = s.status.name,
                    symbol = cfg.symbol,
                    timeframe = cfg.timeframe,
                    lastBarId = s.lastBarId,
                    lastHeartbeatAt = System.currentTimeMillis(),
                    killSwitch = s.killSwitch
                )
            )
        }
    }

    private fun timeframeMillis(timeframe: String): Long {
        val m = Regex("(\\d+)([mhdwM])").matchEntire(timeframe)
            ?: return 5L * 60_000L
        val n = m.groupValues[1].toLongOrNull()?.coerceAtLeast(1L) ?: 5L
        return when (m.groupValues[2]) {
            "m" -> n * 60_000L
            "h" -> n * 3_600_000L
            "d" -> n * 86_400_000L
            "w" -> n * 7L * 86_400_000L
            "M" -> n * 30L * 86_400_000L
            else -> 5L * 60_000L
        }
    }
    private fun isIndeterminateBrokerResult(status: String, message: String): Boolean {
        val s = status.uppercase() + " " + message.uppercase()
        return listOf("TIMEOUT", "NETWORK", "CONNECTION", "UNKNOWN", "5XX", "HTTP_5", "IOEXCEPTION", "SOCKET").any { s.contains(it) }
    }

}
