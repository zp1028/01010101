package com.caifenxi.app.domain.btc.execution

import com.caifenxi.app.domain.btc.polymarket.strategy.TwoLegExecutionState
import com.caifenxi.app.domain.btc.polymarket.strategy.TwoLegStage

/**
 * Deterministic coordinator for a two-leg execution. It never treats submission
 * as a fill. Venue observations are reconciled first, then applied exactly once.
 */
class TwoLegExecutionCoordinator(
    private val fillTolerance: Double = 1e-9,
    private val staleAfterMs: Long = 15_000L
) {
    data class Snapshot(
        val state: TwoLegExecutionState,
        val yesOrder: ReconciledOrder?,
        val noOrder: ReconciledOrder?,
        val action: Action,
        val reason: String,
        val updatedAtMs: Long
    )

    enum class Action { WAIT, HEDGE_YES, HEDGE_NO, CANCEL_REMAINDER, UNWIND, PROTECT, CLOSE, BLOCK }

    fun reconcile(
        state: TwoLegExecutionState,
        localYes: ObservedOrder?, venueYes: ObservedOrder?,
        localNo: ObservedOrder?, venueNo: ObservedOrder?,
        nowMs: Long = System.currentTimeMillis()
    ): Snapshot {
        val yes = pair(localYes, venueYes, nowMs)
        val no = pair(localNo, venueNo, nowMs)
        if (yes?.statusResult == ReconcileStatus.ERROR || no?.statusResult == ReconcileStatus.ERROR) {
            return Snapshot(state.copy(stage = TwoLegStage.ERROR, lastAction = "RECONCILE_ERROR", updatedAtMs = nowMs), yes, no, Action.BLOCK, "reconciliation error", nowMs)
        }
        if (yes?.statusResult == ReconcileStatus.STALE || no?.statusResult == ReconcileStatus.STALE) {
            return Snapshot(state.copy(stage = TwoLegStage.BLOCKED, lastAction = "STALE_VENUE_STATE", updatedAtMs = nowMs), yes, no, Action.BLOCK, "venue state stale", nowMs)
        }

        var next = state
        val yesFill = yes?.filledSize ?: state.yesFilled
        val noFill = no?.filledSize ?: state.noFilled
        if (yes != null && kotlin.math.abs(yesFill - state.yesFilled) > fillTolerance) {
            next = next.copy(yesFilled = yesFill)
        }
        if (no != null && kotlin.math.abs(noFill - state.noFilled) > fillTolerance) {
            next = next.copy(noFilled = noFill)
        }
        next = normalizeStage(next, nowMs)

        return when {
            next.fullyFilled -> Snapshot(next.copy(stage = TwoLegStage.PROTECTED, lastAction = "BOTH_LEGS_FILLED", updatedAtMs = nowMs), yes, no, Action.PROTECT, "both legs fully reconciled", nowMs)
            next.unhedgedYes > fillTolerance -> Snapshot(next, yes, no, Action.HEDGE_YES, "YES leg exceeds NO leg", nowMs)
            next.unhedgedNo > fillTolerance -> Snapshot(next, yes, no, Action.HEDGE_NO, "NO leg exceeds YES leg", nowMs)
            (yes?.statusResult == ReconcileStatus.DRIFT || no?.statusResult == ReconcileStatus.DRIFT) -> Snapshot(next.copy(stage = TwoLegStage.BLOCKED, lastAction = "DRIFT", updatedAtMs = nowMs), yes, no, Action.BLOCK, "local/venue drift", nowMs)
            else -> Snapshot(next, yes, no, Action.WAIT, "waiting for fill", nowMs)
        }
    }

    private fun pair(local: ObservedOrder?, venue: ObservedOrder?, nowMs: Long): ReconciledOrder? {
        if (local == null || venue == null) return null
        return ExecutionReconciliationCore.reconcile(local, venue, nowMs, staleAfterMs)
    }

    private fun normalizeStage(state: TwoLegExecutionState, nowMs: Long): TwoLegExecutionState {
        val y = state.yesFilled
        val n = state.noFilled
        val stage = when {
            state.fullyFilled -> TwoLegStage.PROTECTED
            y > n + fillTolerance -> TwoLegStage.LEG_A_OPEN
            n > y + fillTolerance -> TwoLegStage.LEG_B_OPEN
            y > fillTolerance || n > fillTolerance -> TwoLegStage.HEDGING
            else -> state.stage
        }
        return state.copy(stage = stage, lastAction = "RECONCILED", updatedAtMs = nowMs)
    }
}
