package com.caifenxi.app.domain.btc.factor

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import com.caifenxi.app.domain.btc.research.QuantResearchLifecycleEngine

/** Persists the latest research-derived factor weights for the unattended runtime. */
class QuantFactorWeightStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("btc_quant_factor_weights_v1", Context.MODE_PRIVATE)

    data class Entry(val factorId: String, val weight: Double, val score: Double, val icir: Double, val updatedAtMs: Long)

    fun load(): Map<String, Entry> = runCatching {
        val arr = JSONArray(prefs.getString(KEY, "[]"))
        buildMap {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val id = o.getString("id")
                put(id, Entry(id, o.optDouble("weight", 0.0), o.optDouble("score", 0.0), o.optDouble("icir", 0.0), o.optLong("updatedAt", 0L)))
            }
        }
    }.getOrDefault(emptyMap())

    @Synchronized fun save(metrics: Collection<QuantFactorResearchEngine.Metric>, nowMs: Long = System.currentTimeMillis()) {
        val ranked = metrics.sortedByDescending { it.score }
        val max = ranked.maxOfOrNull { it.score }?.coerceAtLeast(1e-9) ?: 1.0
        val arr = JSONArray()
        ranked.forEach { m ->
            val lifecycle = QuantResearchLifecycleEngine.evaluate(m, nowMs)
            val rawQuality = (0.55 * (m.score / max).coerceIn(0.0, 1.0) + 0.30 * (m.icir / 2.0).coerceIn(0.0, 1.0) + 0.15 * m.stability.coerceIn(0.0, 1.0))
            val weight = (rawQuality * lifecycle.weightMultiplier).coerceIn(0.0, 1.0)
            arr.put(JSONObject().apply {
                put("id", m.factorId); put("weight", weight); put("score", m.score); put("icir", m.icir)
                put("lifecycle", lifecycle.status.name); put("samples", m.samples); put("stability", m.stability)
                put("updatedAt", nowMs)
            })
        }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    fun weight(id: String, fallback: Double = 1.0): Double = load()[id]?.weight?.coerceIn(0.0, 1.0) ?: fallback

    companion object { private const val KEY = "entries" }
}
