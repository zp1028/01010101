package com.caifenxi.app.domain.btc.hs

import com.caifenxi.app.domain.btc.BtcCandle
import com.caifenxi.app.domain.btc.MarketRegime
import kotlin.math.abs

/**
 * HS 模型实验室：严格按时间滚动的 OOS 验证。
 * 每一折只评价“训练/观察窗口之后”的未来区间，避免把整段历史一次性当 holdout。
 * 当前五个基准模型为无参数规则模型，因此 WF 的核心是严格的时间隔离与逐折汇总。
 */
class HsModelLab(private val minSamples: Int = 24, private val testWindow: Int = 16) {
    data class ModelScore(val modelId:String,val samples:Int,val hitRate:Double,val brier:Double,val logLoss:Double,val regime:MarketRegime)
    data class RegimeCell(val modelId:String,val regime:MarketRegime,val samples:Int,val hitRate:Double,val brier:Double)
    data class Report(val version:String,val holdoutSamples:Int,val models:List<ModelScore>,val regimeMatrix:List<RegimeCell>)

    fun evaluate(c:List<BtcCandle>):Report {
        if(c.size < minSamples + 45) return Report(VERSION,0,emptyList(),emptyList())
        val start = 35
        val foldSize = testWindow.coerceAtLeast(8)
        val allRows = MODEL_IDS.associateWith { mutableListOf<Pair<Double, Boolean>>() }
        val regimeRows = MODEL_IDS.associateWith { MarketRegime.entries.associateWith { mutableListOf<Pair<Double, Boolean>>() } }
        var cursor = start
        var folds = 0
        while (cursor < c.lastIndex) {
            val end = minOf(cursor + foldSize, c.lastIndex)
            // 当前模型无可训练参数，但每个 fold 都只读取 <= cursor 的历史来决定 regime/prediction，
            // 并只把 [cursor,end) 的未来结果加入 OOS 汇总。
            for (i in cursor until end) {
                val target = c[i + 1].close > c[i].close
                val regime = detect(c, i)
                for (id in MODEL_IDS) {
                    val row = predict(id,c,i) to target
                    allRows.getValue(id).add(row)
                    regimeRows.getValue(id).getValue(regime).add(row)
                }
            }
            folds++
            cursor = end
        }
        if (folds < 2) return Report(VERSION,0,emptyList(),emptyList())
        val models = MODEL_IDS.mapNotNull { id ->
            val rows = allRows.getValue(id)
            if (rows.size < minSamples) null else metrics(id, MarketRegime.RANGE, rows)
        }
        val cells = MODEL_IDS.flatMap { id ->
            MarketRegime.entries.mapNotNull { r ->
                val rows = regimeRows.getValue(id).getValue(r)
                if (rows.size < 8) null else {
                    val m = metrics(id, r, rows)
                    RegimeCell(id, r, m.samples, m.hitRate, m.brier)
                }
            }
        }
        return Report(VERSION, models.maxOfOrNull { it.samples } ?: 0, models, cells)
    }

    fun ensembleProbability(c: List<BtcCandle>, index: Int = c.lastIndex, regime: MarketRegime = detect(c, index), weights: Map<String, Double> = emptyMap()): Double {
        if (c.isEmpty() || index <= 0 || index >= c.size) return 0.5
        val active = if (weights.isEmpty()) MODEL_IDS.associateWith { 1.0 / MODEL_IDS.size } else weights
        val total = active.values.sum().coerceAtLeast(1e-9)
        return active.entries.sumOf { (id, w) -> predict(id, c, index) * w.coerceAtLeast(0.0) }
            .div(total).coerceIn(0.03, 0.97)
    }

    private fun metrics(id:String,r:MarketRegime,rows:List<Pair<Double,Boolean>>):ModelScore {
        val hit=rows.count{(p,y)->(p>=.5)==y}.toDouble()/rows.size
        val b=rows.map{(p,y)->val e=p-if(y)1.0 else 0.0;e*e}.average()
        val ll=rows.map{(p0,y)->val p=p0.coerceIn(1e-6,1-1e-6);if(y)-kotlin.math.ln(p) else -kotlin.math.ln(1-p)}.average()
        return ModelScore(id,rows.size,hit,b,ll,r)
    }

    private fun predict(id:String,c:List<BtcCandle>,i:Int):Double=when(id){
        "TREND"->sig((ema(c,i,9)/ema(c,i,21)-1)*180)
        "MOMENTUM"->sig((c[i].close/c[i-1].close-1)*12+(c[i].close/c[(i-8).coerceAtLeast(0)].close-1)*5)
        "MEAN_REVERSION"->sig((c.subList((i-19).coerceAtLeast(0),i+1).map{it.close}.average()/c[i].close-1)*70)
        "BREAKOUT"->{val hi=c.subList((i-19).coerceAtLeast(0),i).maxOf{it.high};val lo=c.subList((i-19).coerceAtLeast(0),i).minOf{it.low};when{c[i].close>hi->.68;c[i].close<lo->.32;else->.5}}
        "VOLATILITY"->{val range=(c[i].high-c[i].low)/c[i].close.coerceAtLeast(1e-9);val body=(c[i].close-c[i].open)/c[i].close.coerceAtLeast(1e-9);sig(body*70+(range-.008)*15*if(body>=0)1 else -1)}
        else->.5
    }.coerceIn(.03,.97)

    private fun detect(c:List<BtcCandle>,i:Int):MarketRegime {if(i<30)return MarketRegime.RANGE;val close=c[i].close;val e9=ema(c,i,9);val e21=ema(c,i,21);val e50=ema(c,i,50);val atr=c.subList((i-13).coerceAtLeast(1),i+1).map{it.high-it.low}.average()/close;val trend=abs(e9-e50)/close;val hi=c.subList((i-19).coerceAtLeast(0),i).maxOf{it.high};val lo=c.subList((i-19).coerceAtLeast(0),i).minOf{it.low};return when{atr>.02->MarketRegime.HIGH_VOLATILITY;close>hi||close<lo->MarketRegime.BREAKOUT;e9>e21&&e21>e50&&trend>.004->MarketRegime.TREND_UP;e9<e21&&e21<e50&&trend>.004->MarketRegime.TREND_DOWN;else->MarketRegime.RANGE}}
    private fun ema(c:List<BtcCandle>,i:Int,p:Int):Double{val s=(i-p*2).coerceAtLeast(0);var e=c[s].close;val k=2.0/(p+1);for(j in s+1..i)e=c[j].close*k+e*(1-k);return e}
    private fun sig(z:Double)=1.0/(1.0+kotlin.math.exp(-z.coerceIn(-12.0,12.0)))
    companion object{const val VERSION="HS-LAB-2.0-ROLLING-WF";val MODEL_IDS=listOf("TREND","MOMENTUM","MEAN_REVERSION","BREAKOUT","VOLATILITY")}
}
