package com.caifenxi.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.btc.paper.BetDirection
import com.caifenxi.app.domain.btc.paper.MarketOdds
import com.caifenxi.app.domain.btc.paper.PredictionRound
import com.caifenxi.app.domain.btc.paper.SettledBet
import com.caifenxi.app.ui.BtcQuantViewModel
import com.caifenxi.app.ui.theme.CaiTokens
import kotlinx.coroutines.delay

/**
 * 模拟交易工作台。
 * 目标：只保留“周期 → 信号 → 金额 → 执行 → 结算”主链路，避免把实盘配置混进模拟页。
 */
@Composable
fun PaperTradingTab(viewModel: BtcQuantViewModel) {
    val state by viewModel.state.collectAsState()
    val account by viewModel.binaryAccount.collectAsState()
    val stats by viewModel.binaryStats.collectAsState()
    val round by viewModel.currentRound.collectAsState()
    val marketOdds by viewModel.marketOddsList.collectAsState()

    var direction by remember { mutableStateOf(BetDirection.YES) }
    var amount by remember { mutableStateOf("10") }
    var remaining by remember { mutableLongStateOf(viewModel.binaryRemainingSec()) }

    val cycleOptions = listOf(60L to "1分钟", 300L to "5分钟", 900L to "15分钟", 1800L to "30分钟", 3600L to "1小时")

    LaunchedEffect(round?.roundId, viewModel.binaryRoundDurationSec()) {
        while (true) {
            viewModel.tickBinaryRound()
            remaining = viewModel.binaryRemainingSec().coerceAtLeast(0L)
            delay(1000L)
        }
    }

    val price = state.candles.lastOrNull()?.close ?: state.markPrice ?: 0.0
    val liveDirection = viewModel.binaryLiveDirection()
    val liveMove = viewModel.binaryCurrentMovePct()
    val duration = viewModel.binaryRoundDurationSec()
    val total = duration.coerceAtLeast(1L)
    val progress = if (round == null) 0f else (1f - remaining.toFloat() / total.toFloat()).coerceIn(0f, 1f)

    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState())
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("模拟交易", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                Text("不接触真实账户，只验证策略、周期、下注、结算和盈亏链路", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = { viewModel.resetBinaryAccount() }) { Icon(Icons.Filled.Refresh, "重置模拟账户") }
        }

        SectionCard("① 选择模拟周期") {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                cycleOptions.forEach { (seconds, label) ->
                    FilterChip(
                        selected = duration == seconds,
                        onClick = { viewModel.setBinaryRoundDurationSec(seconds) },
                        label = { Text(label, fontSize = 11.sp) }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("当前周期：${round?.let { formatRoundId(it.roundId, duration) } ?: "等待建立"}", fontSize = 11.sp)
        }

        SectionCard("② 当前周期") {
            if (round == null) {
                Text("正在建立模拟周期…", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
                    Column(Modifier.weight(1f)) {
                        Text("剩余时间", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(formatCountdown(remaining), fontSize = 34.sp, fontWeight = FontWeight.Black)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("开窗价", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("%.2f".format(round.openPrice), fontWeight = FontWeight.Bold)
                        Text("现价 %.2f".format(price), fontSize = 11.sp)
                    }
                }
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SignalBadge("实时方向", if (liveDirection == BetDirection.YES) "上涨" else "下跌")
                    SignalBadge("当前涨跌", "%+.2f%%".format(liveMove))
                    SignalBadge("锁定方向", round.lockedDirection?.label ?: "等待信号")
                }
            }
        }

        SectionCard("③ 模拟执行") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DirectionButton("看涨", direction == BetDirection.YES, CaiTokens.Success, Modifier.weight(1f)) { direction = BetDirection.YES }
                DirectionButton("看跌", direction == BetDirection.NO, CaiTokens.Danger, Modifier.weight(1f)) { direction = BetDirection.NO }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = amount,
                onValueChange = { amount = it.filter { c -> c.isDigit() || c == '.' } },
                singleLine = true,
                label = { Text("模拟金额 USDT") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { viewModel.placeBinaryBet(direction, amount.toDoubleOrNull() ?: 10.0) },
                    enabled = round != null,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.PlayArrow, null); Spacer(Modifier.width(5.dp)); Text("执行模拟单")
                }
                OutlinedButton(
                    onClick = { viewModel.executeBinaryAutoBet() },
                    enabled = round != null,
                    modifier = Modifier.weight(1f)
                ) { Text("按策略执行") }
            }
            Text("每个周期最多一笔模拟单；模拟页不会调用实盘下单接口。", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 7.dp))
        }

        SectionCard("④ 模拟账户") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatBox("余额", "%.2f".format(account.balance), Modifier.weight(1f))
                StatBox("净盈亏", "%+.2f".format(account.netProfit), Modifier.weight(1f))
                StatBox("胜率", "%.1f%%".format(account.winRatePct), Modifier.weight(1f))
                StatBox("回撤", "%.1f%%".format(account.maxDrawdownPct), Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            MetricLine("已完成交易", "${account.totalTrades}")
            MetricLine("累计下注", "%.2f USDT".format(account.totalWagered))
            MetricLine("累计返还", "%.2f USDT".format(account.totalPayout))
            MetricLine("当前待结算", "${account.pendingBets.size} 笔")
            MetricLine("周期胜率", "%.1f%%".format(stats.yesRatePct))
        }

        SectionCard("⑤ 市场参考") {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("市场价格仅用于模拟参考", fontSize = 11.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { viewModel.refreshMarketOdds() }) { Text("刷新") }
            }
            marketOdds.take(3).forEach { MarketRow(it) }
            if (marketOdds.isEmpty()) Text("暂无市场报价；仍可使用本地策略模拟。", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        SectionCard("⑥ 最近结算") {
            val settled = account.settledBets.takeLast(8).reversed()
            if (settled.isEmpty()) Text("暂无结算记录", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            settled.forEach { SettledRow(it) }
        }

        Spacer(Modifier.height(32.dp))
    }
}

@Composable private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp)) { Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp); Spacer(Modifier.height(9.dp)); content() }
    }
}

@Composable private fun SignalBadge(label: String, value: String) {
    Surface(shape = RoundedCornerShape(8.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
        Column(Modifier.padding(horizontal = 9.dp, vertical = 6.dp)) { Text(label, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant); Text(value, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
    }
}

@Composable private fun DirectionButton(label: String, selected: Boolean, color: androidx.compose.ui.graphics.Color, modifier: Modifier, onClick: () -> Unit) {
    Surface(onClick = onClick, modifier = modifier, shape = RoundedCornerShape(10.dp), color = if (selected) color.copy(alpha = .15f) else MaterialTheme.colorScheme.surfaceVariant) {
        Box(Modifier.padding(vertical = 13.dp), contentAlignment = Alignment.Center) { Text(label, color = if (selected) color else MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold) }
    }
}

@Composable private fun StatBox(label: String, value: String, modifier: Modifier) {
    Column(modifier.background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp)).padding(8.dp)) { Text(label, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant); Text(value, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
}

@Composable private fun MarketRow(odds: MarketOdds) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(odds.platform, fontSize = 9.sp, fontWeight = FontWeight.Bold); Text(odds.question.take(34), fontSize = 10.sp, maxLines = 1) }
        Text("涨 %.2f".format(odds.yesPrice), fontSize = 10.sp, color = CaiTokens.Success)
        Spacer(Modifier.width(10.dp)); Text("跌 %.2f".format(odds.noPrice), fontSize = 10.sp, color = CaiTokens.Danger)
    }
}

@Composable private fun SettledRow(sb: SettledBet) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(if (sb.bet.direction == BetDirection.YES) "涨" else "跌", fontWeight = FontWeight.Bold, modifier = Modifier.width(30.dp))
        Column(Modifier.weight(1f)) { Text("%.2f USDT · %.1fx".format(sb.bet.amount, sb.bet.odds), fontSize = 10.sp); Text(if (sb.won) "命中 +%.2f".format(sb.profit) else "未命中 %.2f".format(sb.profit), fontSize = 10.sp, color = if (sb.won) CaiTokens.Success else CaiTokens.Danger) }
        Text(if (sb.won) "已赢" else "已输", fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

private fun formatCountdown(sec: Long): String = "%02d:%02d".format(sec / 60, sec % 60)
private fun formatRoundId(id: Long, durationSec: Long): String = "#${id / (durationSec.coerceAtLeast(1L) * 1000L)}"
