package com.caifenxi.app.domain.btc.runtime

/**
 * v22.5 canonical TradingCore.
 *
 * Every execution mode enters through this lifecycle:
 * Decision -> Risk -> Intent -> Adapter -> Result -> Event.
 * Venue-specific brokers never decide whether an order is allowed; they only execute
 * an already-authorized intent. UNKNOWN is terminal for the current execution attempt.
 */

enum class TradingCoreStage {
    DECISION, RISK, INTENT, SUBMISSION, RESULT
}

data class TradingCoreIntent(
    val decisionId: String,
    val clientId: String,
    val symbol: String,
    val side: OrderSide,
    val quantity: Double,
    val price: Double,
    val mode: TradingMode,
    val type: OrderType = OrderType.MARKET,
    val reduceOnly: Boolean = false,
    val metadata: Map<String, String> = emptyMap()
) {
    fun toOrderIntent(): OrderIntentSpec = OrderIntentSpec(
        clientId = clientId,
        symbol = symbol,
        side = side,
        type = type,
        quantity = quantity,
        limitPrice = if (type == OrderType.LIMIT) price else null,
        reduceOnly = reduceOnly,
        mode = mode
    )
}

data class TradingCoreRequest(
    val intent: TradingCoreIntent,
    val risk: UnifiedRiskInput
)

data class TradingCoreResult(
    val stage: TradingCoreStage,
    val risk: UnifiedRiskDecision,
    val execution: ExecutionResult? = null,
    val message: String = ""
) {
    val allowed: Boolean get() = risk.allowed && execution?.status != OrderStatus.REJECTED && execution?.status != OrderStatus.UNKNOWN
}

/** Adapter boundary shared by BACKTEST/PAPER/TESTNET/LIVE. */
interface TradingCoreAdapter {
    val mode: TradingMode

    suspend fun submit(intent: TradingCoreIntent): ExecutionResult
}

/** Adapter for the deterministic local TradingBroker implementation. */
class LocalTradingCoreAdapter(
    override val mode: TradingMode,
    private val broker: TradingBroker,
    private val marketPrice: () -> Double
) : TradingCoreAdapter {
    override suspend fun submit(intent: TradingCoreIntent): ExecutionResult =
        broker.submit(intent.toOrderIntent(), marketPrice())
}

/**
 * Single authority for order authorization and execution dispatch.
 * The adapter registry is explicit: no mode can silently fall back to another mode.
 */
class TradingCore(
    private val unifiedRisk: UnifiedRiskEngine = UnifiedRiskEngine(),
    adapters: Collection<TradingCoreAdapter> = emptyList(),
    private val eventSink: ((TradingEvent) -> Unit)? = null
) {
    private val adaptersByMode = adapters.associateBy { it.mode }

    fun adapter(mode: TradingMode): TradingCoreAdapter? = adaptersByMode[mode]

    suspend fun execute(request: TradingCoreRequest): TradingCoreResult {
        val intent = request.intent
        if (intent.decisionId.isBlank() || intent.clientId.isBlank()) {
            return TradingCoreResult(
                stage = TradingCoreStage.DECISION,
                risk = UnifiedRiskDecision(UnifiedRiskStatus.BLOCK, "decisionId/clientId 为空"),
                message = "执行意图身份无效"
            )
        }
        val riskMode = request.risk.mode
        if (riskMode != null && intent.mode != riskMode) {
            return TradingCoreResult(
                stage = TradingCoreStage.INTENT,
                risk = UnifiedRiskDecision(UnifiedRiskStatus.BLOCK, "TradingMode 与风险上下文不一致"),
                message = "模式不一致"
            )
        }

        val atMs = System.currentTimeMillis()
        eventSink?.invoke(TradingEvent.Decision(atMs, "EXECUTE", "TradingCore v22.5"))

        val riskDecision = unifiedRisk.evaluate(request.risk)
        eventSink?.invoke(TradingEvent.Risk(atMs, riskDecision.allowed, riskDecision.reason))
        if (!riskDecision.allowed) {
            return TradingCoreResult(TradingCoreStage.RISK, riskDecision, message = riskDecision.reason)
        }

        val adapter = adaptersByMode[intent.mode]
            ?: return TradingCoreResult(
                TradingCoreStage.SUBMISSION,
                UnifiedRiskDecision(UnifiedRiskStatus.BLOCK, "未注册 ${intent.mode} TradingCore Adapter"),
                message = "没有隐式模式回退"
            )

        eventSink?.invoke(
            TradingEvent.OrderIntent(
                atMs = atMs,
                clientId = intent.clientId,
                side = intent.side.name,
                quantity = intent.quantity,
                mode = intent.mode
            )
        )

        val execution = runCatching { adapter.submit(intent) }.getOrElse {
            ExecutionResult(
                status = OrderStatus.UNKNOWN,
                clientId = intent.clientId,
                orderId = "UNKNOWN-${intent.clientId}",
                message = "Adapter异常：${it.message ?: "unknown"}"
            )
        }
        eventSink?.invoke(
            TradingEvent.Execution(atMs, intent.clientId, execution.status.name, execution.orderId)
        )
        execution.fill?.let { fill ->
            eventSink?.invoke(TradingEvent.Fill(atMs, fill.clientId, fill.price, fill.quantity, fill.fee))
        }

        return TradingCoreResult(
            stage = TradingCoreStage.RESULT,
            risk = riskDecision,
            execution = execution,
            message = execution.message
        )
    }

}

/** Explicit factory keeps the four execution modes visible at the composition root. */
object TradingCoreModes {
    val all: Set<TradingMode> = TradingMode.values().toSet()
}
