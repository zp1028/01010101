package com.caifenxi.app.domain.btc.hs

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.math.BigInteger
import java.util.concurrent.TimeUnit

/**
 * Optional Chainlink AggregatorV3 adapter over an EVM JSON-RPC endpoint.
 * It never fabricates an oracle price: when URL/feed are absent or the call fails,
 * the result is null and the UI must show Oracle OFFLINE/UNAVAILABLE.
 */
class ChainlinkOracleRepository(
    private val rpcUrl: String,
    private val feedAddress: String,
    private val client: OkHttpClient = OkHttpClient.Builder().connectTimeout(4, TimeUnit.SECONDS).readTimeout(6, TimeUnit.SECONDS).callTimeout(8, TimeUnit.SECONDS).build()
) {
    data class Snapshot(val price: Double, val updatedAt: Long, val roundId: String)

    suspend fun latest(): Snapshot? = withContext(Dispatchers.IO) {
        if (rpcUrl.isBlank() || feedAddress.isBlank()) return@withContext null
        runCatching {
            val call = JSONObject().apply {
                put("jsonrpc", "2.0")
                put("id", 1)
                put("method", "eth_call")
                put("params", org.json.JSONArray().apply {
                    put(JSONObject().apply { put("to", feedAddress); put("data", "0xfeaf968c") })
                    put("latest")
                })
            }
            val req = Request.Builder().url(rpcUrl).post(okhttp3.RequestBody.create("application/json".toMediaType(), call.toString())).build()
            client.newCall(req).execute().use { r ->
                if (!r.isSuccessful) error("HTTP ${r.code}")
                val result = JSONObject(r.body?.string().orEmpty()).optString("result")
                if (result.isBlank() || result == "0x") return@use null
                val hex = result.removePrefix("0x")
                if (hex.length < 64 * 4) return@use null
                // latestRoundData() = roundId, answer, startedAt, updatedAt, answeredInRound
                val answer = BigInteger(hex.substring(64, 128), 16).toLong()
                val updated = BigInteger(hex.substring(192, 256), 16).toLong()
                val round = BigInteger(hex.substring(0, 64), 16).toString()
                if (answer <= 0L || updated <= 0L) return@use null
                Snapshot(answer.toDouble() / 1e8, updated * 1000L, round)
            }
        }.getOrNull()
    }
}
