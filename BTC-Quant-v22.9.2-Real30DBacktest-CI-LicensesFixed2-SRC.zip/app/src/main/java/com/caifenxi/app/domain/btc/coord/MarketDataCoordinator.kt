package com.caifenxi.app.domain.btc.coord

import com.caifenxi.app.domain.btc.BinanceDerivativesRepository
import com.caifenxi.app.domain.btc.BinanceMarketRepository
import com.caifenxi.app.domain.btc.BinanceOrderBookRepository
import com.caifenxi.app.domain.btc.BtcCandle
import com.caifenxi.app.domain.btc.BtcDemoDataProvider
import com.caifenxi.app.domain.btc.BtcDerivativesSnapshot
import com.caifenxi.app.domain.btc.FundingPoint
import com.caifenxi.app.domain.btc.OpenInterestPoint
import com.caifenxi.app.domain.btc.hs.ChainlinkOracleRepository
import com.caifenxi.app.domain.btc.news.CryptoNewsRepository
import com.caifenxi.app.domain.btc.news.NewsSnapshot
import com.caifenxi.app.domain.btc.polymarket.PolyMarket
import com.caifenxi.app.domain.btc.polymarket.PolymarketRepository
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withTimeoutOrNull

/**
 * 行情数据协调器 —— 从 BtcQuantViewModel 拆出的并行拉取职责。
 *
 * 关键点：主行情（K 线）与可选的辅助数据（衍生品/新闻/盘口/Oracle/Polymarket）相互独立。
 * 辅助源长时间不可达时必须在各自预算内降级为空/ null，绝不能拖累主行情，否则整个 Bundle
 * 会被外层超时取消并回退 Demo（曾导致"一直显示演示数据"）。
 */
class MarketDataCoordinator(
    private val marketRepo: BinanceMarketRepository,
    private val derivRepo: BinanceDerivativesRepository,
    private val orderBookRepo: BinanceOrderBookRepository,
    private val newsRepo: CryptoNewsRepository,
    private val polymarketRepo: PolymarketRepository
) {
    data class Bundle(
        val candles5m: List<BtcCandle>,
        val candles15m: List<BtcCandle>,
        val candles1h: List<BtcCandle>,
        val primary: List<BtcCandle>,
        val funding: List<FundingPoint>,
        val oi: List<OpenInterestPoint>,
        val snap: BtcDerivativesSnapshot?,
        val news: NewsSnapshot?,
        val depth: BinanceOrderBookRepository.Snapshot?,
        val oracle: ChainlinkOracleRepository.Snapshot?,
        val polyMarkets: List<PolyMarket>,
        val useDemo: Boolean
    )

    private companion object {
        /** 主行情（K 线）预算：足够覆盖多源回退，又不至于拖住整轮刷新。 */
        const val KLINE_TIMEOUT_MS = 12_000L
        /** 可选辅助源预算：不可达时快速降级，不影响主行情。 */
        const val AUX_TIMEOUT_MS = 6_000L
    }

    /**
     * 带超时的安全取值：超时或普通异常都降级为 default，不影响其它并发源。
     * 注意：外部（整包）取消属于协作式取消，必须原样抛出，否则会让外层总超时失效。
     */
    private suspend fun <T> guarded(ms: Long, default: T, block: suspend () -> T): T =
        try {
            withTimeoutOrNull(ms) { block() } ?: default
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (_: Exception) {
            default
        }

    suspend fun loadParallel(
        symbol: String,
        timeframe: String,
        chainlinkRpc: String,
        chainlinkFeed: String
    ): Bundle = coroutineScope {
        val a5 = async { guarded(KLINE_TIMEOUT_MS, emptyList()) { marketRepo.loadKlines(symbol, "5m", 300) } }
        val a15 = async { guarded(KLINE_TIMEOUT_MS, emptyList()) { marketRepo.loadKlines(symbol, "15m", 300) } }
        val a1h = async { guarded(KLINE_TIMEOUT_MS, emptyList()) { marketRepo.loadKlines(symbol, "1h", 300) } }
        val aFund = async { guarded(AUX_TIMEOUT_MS, emptyList()) { derivRepo.fundingHistory(symbol, 100) } }
        val aOi = async { guarded(AUX_TIMEOUT_MS, emptyList()) { derivRepo.openInterestHistory(symbol, timeframe, 100) } }
        val aSnap = async { guarded(AUX_TIMEOUT_MS, null) { derivRepo.snapshot(symbol) } }
        val aNews = async { guarded(AUX_TIMEOUT_MS, null) { newsRepo.snapshot() } }
        val aDepth = async { guarded(AUX_TIMEOUT_MS, null) { orderBookRepo.snapshot(symbol, 100) } }
        val aOracle = async {
            guarded(AUX_TIMEOUT_MS, null) { ChainlinkOracleRepository(chainlinkRpc, chainlinkFeed).latest() }
        }
        val aPoly = async { guarded(AUX_TIMEOUT_MS, emptyList()) { polymarketRepo.searchCryptoMarkets(40) } }

        var c5 = a5.await(); var c15 = a15.await(); var c1h = a1h.await()
        var funding = aFund.await(); var oi = aOi.await()
        var snap = aSnap.await(); var news = aNews.await()
        val depth = aDepth.await(); val oracle = aOracle.await(); val poly = aPoly.await()

        val primaryRaw = when (timeframe) {
            "5m" -> c5; "1h" -> c1h; else -> c15
        }.ifEmpty { c15.ifEmpty { c5.ifEmpty { c1h } } }
        val useDemo = primaryRaw.size < 2
        if (useDemo) {
            c5 = BtcDemoDataProvider.generateCandles(symbol, "5m", 300)
            c15 = BtcDemoDataProvider.generateCandles(symbol, "15m", 300)
            c1h = BtcDemoDataProvider.generateCandles(symbol, "1h", 300)
            funding = BtcDemoDataProvider.generateFundingHistory(symbol, 100)
            oi = BtcDemoDataProvider.generateOiHistory(symbol, 100)
            snap = BtcDemoDataProvider.generateDerivativesSnapshot(symbol)
            news = BtcDemoDataProvider.generateNewsSnapshot()
        }
        val primary = when (timeframe) {
            "5m" -> c5; "1h" -> c1h; else -> c15
        }
        Bundle(c5, c15, c1h, primary, funding, oi, snap, news, if (useDemo) null else depth, if (useDemo) null else oracle, poly, useDemo)
    }
}
