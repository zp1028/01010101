package com.caifenxi.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.btc.paper.BetDirection
import com.caifenxi.app.domain.btc.runtime.BtcRunMode
import com.caifenxi.app.domain.btc.runtime.BtcRuntimeStatus
import com.caifenxi.app.ui.BtcQuantViewModel
import com.caifenxi.app.ui.theme.CaiTokens
import kotlinx.coroutines.delay

/**
 * 自动交易工作台：把“启动、信号、执行、停止、日志”做成单一闭环。
 * 模拟模式与实盘模式明确分离，避免用户误以为模拟页就是实盘页。
 */
@Composable
fun AutoTradeTab(viewModel: BtcQuantViewModel) {
    val state by viewModel.state.collectAsState()
    val runtimeState by viewModel.runtimeState.collectAsState()
    val runtimeConfig by viewModel.runtimeConfig.collectAsState()
    val round by viewModel.currentRound.collectAsState()
    val account by viewModel.binaryAccount.collectAsState()
    val edge by viewModel.edgeAssessment.collectAsState()
    val lastExecution by viewModel.lastExecution.collectAsState()
    val logs by viewModel.autoTradeLog.collectAsState()
    val readiness by viewModel.readiness.collectAsState()

    var remaining by remember { mutableLongStateOf(viewModel.binaryRemainingSec()) }
    LaunchedEffect(round?.roundId, viewModel.binaryRoundDurationSec(), runtimeState.status) {
        while (true) {
            if (runtimeState.status == BtcRuntimeStatus.RUNNING) viewModel.tickBinaryRound()
            remaining = viewModel.binaryRemainingSec().coerceAtLeast(0L)
            delay(1000L)
        }
    }

    val running = runtimeState.status == BtcRuntimeStatus.RUNNING
    val paperMode = runtimeConfig.runMode == BtcRunMode.PAPER
    val price = state.candles.lastOrNull()?.close ?: state.markPrice ?: 0.0

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().padding(16.dp, 12.dp, 16.dp, 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("自动交易", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                Text("自动评估 → 风控 → 执行 → 结算；模拟与实盘分开", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            StatusPill(if (running) "运行中" else "已停止", running)
        }

        WorkCard("① 运行模式") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = paperMode, onClick = { viewModel.updateRuntimeConfig(runMode = BtcRunMode.PAPER, liveAutoAuthorized = false) }, label = { Text("模拟自动") })
                FilterChip(selected = runtimeConfig.runMode == BtcRunMode.TESTNET, onClick = { viewModel.updateRuntimeConfig(runMode = BtcRunMode.TESTNET) }, label = { Text("测试网") })
                FilterChip(selected = runtimeConfig.runMode == BtcRunMode.LIVE, onClick = { viewModel.updateRuntimeConfig(runMode = BtcRunMode.LIVE) }, label = { Text("实盘") })
            }
            Text(
                when (runtimeConfig.runMode) {
                    BtcRunMode.PAPER -> "模拟模式：只记账，不提交交易所订单。"
                    BtcRunMode.TESTNET -> "测试网：使用交易所测试环境，仍经过执行门禁。"
                    BtcRunMode.LIVE -> "实盘：必须同时满足凭据、数据质量、风险门禁和显式授权。"
                },
                fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 7.dp)
            )
        }

        WorkCard("② 一键挂机") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        viewModel.updateRuntimeConfig(runMode = if (paperMode) BtcRunMode.PAPER else runtimeConfig.runMode, liveAutoAuthorized = false)
                        viewModel.setRuntimeEnabled(true, if (paperMode) BtcRunMode.PAPER else runtimeConfig.runMode)
                        viewModel.refresh()
                    },
                    enabled = !running,
                    modifier = Modifier.weight(1f)
                ) { Icon(Icons.Filled.PlayArrow, null); Spacer(Modifier.width(5.dp)); Text("启动挂机") }
                OutlinedButton(onClick = { viewModel.setRuntimeEnabled(false) }, enabled = running, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.Stop, null); Spacer(Modifier.width(5.dp)); Text("停止挂机")
                }
                OutlinedButton(onClick = { viewModel.executeAutoTradeTick() }, modifier = Modifier.weight(1f)) { Text("立即执行") }
            }
            Text("轮询间隔：${runtimeConfig.pollSeconds} 秒 · 当前模式：${if (paperMode) "模拟" else runtimeConfig.runMode.name}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 7.dp))
            if (runtimeState.killSwitch) Text("安全停机已触发：请先解除 Kill Switch 后再启动。", color = MaterialTheme.colorScheme.error, fontSize = 11.sp, modifier = Modifier.padding(top = 5.dp))
        }

        WorkCard("③ 当前信号") {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("BTC ${state.symbol}", fontWeight = FontWeight.Bold)
                    Text("现价 %.2f · 周期 %s · 剩余 %s".format(price, viewModel.binaryRoundDurationSec().let { "${it / 60}分钟" }, formatCountdown(remaining)), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                val dir = edge?.chosenDirection ?: viewModel.binaryLiveDirection()
                SignalPill(if (dir == BetDirection.YES) "看涨" else "看跌", dir == BetDirection.YES)
            }
            Spacer(Modifier.height(8.dp))
            edge?.let {
                MetricLine("模型概率", "涨 %.1f%% / 跌 %.1f%%".format(it.modelProbYes * 100, it.modelProbNo * 100))
                MetricLine("市场概率", "涨 %.1f%% / 跌 %.1f%%".format(it.marketProbYes * 100, it.marketProbNo * 100))
                MetricLine("优势", "涨 %+.2f%% / 跌 %+.2f%%".format(it.edgeYes * 100, it.edgeNo * 100))
                MetricLine("执行判断", if (it.shouldBet) "允许 · ${it.chosenDirection?.label ?: "无"}" else "跳过 · ${it.reason}")
            } ?: Text("等待模型与市场数据", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        WorkCard("④ 风控与账户") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatBox("余额", "%.2f".format(account.balance), Modifier.weight(1f))
                StatBox("净盈亏", "%+.2f".format(account.netProfit), Modifier.weight(1f))
                StatBox("胜率", "%.1f%%".format(account.winRatePct), Modifier.weight(1f))
                StatBox("回撤", "%.1f%%".format(account.maxDrawdownPct), Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            MetricLine("运行状态", runtimeState.status.name)
            MetricLine("连续失败", "${runtimeState.consecutiveErrors} / ${runtimeConfig.maxConsecutiveErrors}")
            MetricLine("最大单笔", "%.2f USDT".format(runtimeConfig.maxNotionalUsdt))
            readiness?.let { MetricLine("模拟可运行", if (it.readyForPaper) "是" else "否") }
        }

        WorkCard("⑤ 最近一次执行") {
            lastExecution?.let {
                MetricLine("结果", if (it.success) "成功" else "失败")
                MetricLine("方向 / 金额", "${it.direction.label} · %.2f USDT".format(it.amount))
                MetricLine("订单", it.orderId ?: "本地模拟单")
                Text(it.message, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 5.dp))
            } ?: Text("尚未执行", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        WorkCard("⑥ 执行日志") {
            logs.take(8).forEach { entry ->
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(entry.mode, fontSize = 9.sp, modifier = Modifier.width(56.dp))
                    Text(entry.direction, fontWeight = FontWeight.Bold, fontSize = 10.sp, modifier = Modifier.width(42.dp))
                    Text("%.2f".format(entry.betAmount), fontSize = 10.sp, modifier = Modifier.width(55.dp))
                    Text(entry.result, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                }
            }
            if (logs.isEmpty()) Text("暂无执行记录", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(30.dp))
    }
}

@Composable private fun WorkCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp)) { Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp); Spacer(Modifier.height(8.dp)); content() }
    }
}

@Composable private fun StatusPill(text: String, active: Boolean) {
    Surface(shape = RoundedCornerShape(50), color = if (active) CaiTokens.Success.copy(alpha = .14f) else MaterialTheme.colorScheme.surfaceVariant) { Text(text, color = if (active) CaiTokens.Success else MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) }
}

@Composable private fun SignalPill(text: String, up: Boolean) {
    Surface(shape = RoundedCornerShape(8.dp), color = (if (up) CaiTokens.Success else CaiTokens.Danger).copy(alpha = .13f)) { Text(text, color = if (up) CaiTokens.Success else CaiTokens.Danger, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)) }
}

@Composable private fun StatBox(label: String, value: String, modifier: Modifier) {
    Column(modifier.background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp)).padding(8.dp)) { Text(label, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant); Text(value, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
}

private fun formatCountdown(sec: Long): String = "%02d:%02d".format(sec / 60, sec % 60)
