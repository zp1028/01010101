package com.caifenxi.app.domain.btc.research

import android.content.Context
import java.security.MessageDigest
import org.json.JSONArray
import org.json.JSONObject

/**
 * Canonical research lifecycle registry.
 * Only VALIDATED/ACTIVE artifacts may be exposed to runtime consumers.
 * Activation is atomic and rollback-safe; a corrupt or incomplete artifact never becomes active.
 */
class ResearchRegistry(context: Context) {
    enum class Status { CANDIDATE, VALIDATED, ACTIVE, RETIRED }

    data class Record(
        val artifact: ResearchArtifact,
        val status: Status,
        val artifactHash: String,
        val validationAtMs: Long,
        val validationNote: String = "",
        val activatedAtMs: Long = 0L
    )

    private val prefs = context.applicationContext.getSharedPreferences("btc_research_registry_v2", Context.MODE_PRIVATE)
    private val lock = Any()

    fun registerCandidate(artifact: ResearchArtifact, nowMs: Long = System.currentTimeMillis()): Record = synchronized(lock) {
        val record = Record(artifact, Status.CANDIDATE, hash(ResearchArtifactCodec.encode(artifact)), 0L)
        saveRecord(record)
        record
    }

    fun validate(artifactId: String, note: String = "validated", nowMs: Long = System.currentTimeMillis()): Record? = synchronized(lock) {
        val old = records().firstOrNull { it.artifact.artifactId == artifactId } ?: return null
        val a = old.artifact
        if (!isSane(a)) return null
        val updated = old.copy(status = Status.VALIDATED, validationAtMs = nowMs, validationNote = note)
        saveRecord(updated)
        updated
    }

    /** Activate only a previously validated artifact. The previous ACTIVE is retired atomically. */
    fun activate(artifactId: String, nowMs: Long = System.currentTimeMillis()): Boolean = synchronized(lock) {
        val target = records().firstOrNull { it.artifact.artifactId == artifactId && it.status == Status.VALIDATED } ?: return false
        if (!isSane(target.artifact) || target.artifact.datasetCutoffMs <= 0L) return false
        val next = records().map {
            when {
                it.artifact.artifactId == artifactId -> it.copy(status = Status.ACTIVE, activatedAtMs = nowMs)
                it.status == Status.ACTIVE -> it.copy(status = Status.RETIRED)
                else -> it
            }
        }
        persist(next)
        true
    }

    fun activeBefore(cutoffMs: Long): Record? = synchronized(lock) {
        records().filter { it.status == Status.ACTIVE && it.artifact.datasetCutoffMs <= cutoffMs }
            .maxByOrNull { it.artifact.datasetCutoffMs }
    }

    fun active(): Record? = synchronized(lock) { records().filter { it.status == Status.ACTIVE }.maxByOrNull { it.activatedAtMs } }

    fun records(): List<Record> = synchronized(lock) { load() }

    private fun saveRecord(record: Record) {
        val next = load().filterNot { it.artifact.artifactId == record.artifact.artifactId } + record
        persist(next.takeLast(100))
    }

    private fun persist(items: List<Record>) {
        val arr = JSONArray()
        items.forEach { r ->
            arr.put(JSONObject().apply {
                put("artifact", ResearchArtifactCodec.encode(r.artifact))
                put("status", r.status.name)
                put("artifactHash", r.artifactHash)
                put("validationAtMs", r.validationAtMs)
                put("validationNote", r.validationNote)
                put("activatedAtMs", r.activatedAtMs)
            })
        }
        // Atomic activation pointer is separate from history; SharedPreferences commit avoids
        // a process-death window between history and active selection.
        prefs.edit().putString("records", arr.toString()).commit()
    }

    private fun load(): List<Record> = runCatching {
        val arr = JSONArray(prefs.getString("records", "[]") ?: "[]")
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val a = ResearchArtifactCodec.decode(o.getString("artifact"))
                val expected = hash(ResearchArtifactCodec.encode(a))
                val h = o.optString("artifactHash")
                if (h.isNotBlank() && h == expected) add(Record(a, Status.valueOf(o.getString("status")), h, o.optLong("validationAtMs"), o.optString("validationNote"), o.optLong("activatedAtMs")))
            }
        }
    }.getOrDefault(emptyList())

    companion object {
        fun isSane(a: ResearchArtifact): Boolean =
            a.artifactId.isNotBlank() && a.datasetCutoffMs > 0L &&
            a.featureVersion.isNotBlank() && a.modelVersion.isNotBlank() &&
            a.factorWeights.values.all { it.isFinite() && it >= 0.0 } &&
            a.strategyWeights.values.all { it.isFinite() && it >= 0.0 } &&
            a.fusionWeights.values.all { it.isFinite() && it >= 0.0 } &&
            a.fusionWeights.values.sum() > 0.0

        fun hash(raw: String): String = MessageDigest.getInstance("SHA-256")
            .digest(raw.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
    }
}
