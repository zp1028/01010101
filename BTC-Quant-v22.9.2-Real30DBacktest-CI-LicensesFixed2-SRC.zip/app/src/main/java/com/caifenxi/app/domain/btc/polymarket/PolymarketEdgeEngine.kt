package com.caifenxi.app.domain.btc.polymarket

import com.caifenxi.app.domain.btc.BtcConsensus
import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.TradingSignal
import com.caifenxi.app.domain.btc.hs.HsCostEngine

/**
 * Probability engine: modelP from BTC consensus + optional news bias,
 * trade only when edge vs executable price exceeds costs.
 */
class PolymarketEdgeEngine(
    private val minEdge: Double = 0.08,
    private val maxSpread: Double = 0.08,
    private val costBuffer: Double = 0.0
) {
    fun modelYesProbability(consensus: BtcConsensus?, newsBias: Double = 0.0): Double {
        val base = when (consensus?.direction) {
            BtcDirection.UP -> 0.50 + (consensus.probability - 0.5) * 0.8
            BtcDirection.DOWN -> 0.50 - (consensus.probability - 0.5) * 0.8
            BtcDirection.FLAT, null -> 0.50
        }
        return (base + newsBias * 0.1).coerceIn(0.05, 0.95)
    }

    fun evaluateMarket(
        market: PolyMarket,
        bookYes: PolyOrderBook?,
        bookNo: PolyOrderBook?,
        modelYes: Double,
        nowMs: Long = System.currentTimeMillis()
    ): List<PolyEdgeOpportunity> {
        if (market.closed || !market.enableOrderBook) return emptyList()
        val window = PolymarketMarketRolloverEngine().classify(market, nowMs)
        if (!PolymarketMarketRolloverEngine().isTradable(window)) return emptyList()
        val yesBook = bookYes ?: return emptyList()
        val noBook = bookNo
        val ttr = market.endDateMs?.let { ((it - nowMs) / 1000L).coerceAtLeast(0) } ?: 86_400L
        val out = mutableListOf<PolyEdgeOpportunity>()

        fun opportunity(outcome: String, tokenId: String, modelP: Double, book: PolyOrderBook, fallbackBid: Double? = null): PolyEdgeOpportunity {
            val ask = book.bestAsk
            val bid = book.bestBid ?: fallbackBid
            if (ask == null) return PolyEdgeOpportunity(market, outcome, tokenId, 0.0, modelP, 0.0, 0.0, 0.0, book.spread, 0.0, ttr, "NO_TRADE", "orderbook has no ask")
            val depth = book.asks.take(10).sumOf { it.price * it.size }
            val liq = liquidityScore(book)
            val micro = PolymarketMicrostructureEngine.calculate(book, 10)
            val pressureAdjustment = micro.pressure * 0.015
            val costs = HsCostEngine.estimate(ask, bid, depth)
            val rawEdge = (modelP + pressureAdjustment) - ask
            val edge = rawEdge - costs.total - costBuffer
            val action = if (edge >= minEdge && book.spread <= maxSpread && liq >= 0.3) "BUY" else "NO_TRADE"
            return PolyEdgeOpportunity(
                market = market, outcome = outcome, tokenId = tokenId,
                marketP = ask, modelP = modelP, tradePrice = ask,
                edge = edge, ev = edge, spread = book.spread,
                liquidityScore = liq, timeToResolutionSec = ttr,
                action = action,
                reason = "model=${"%.4f".format(modelP)} micro=${"%.3f".format(micro.pressure)} ask=${"%.4f".format(ask)} raw=${"%.4f".format(rawEdge)} cost=${"%.4f".format(costs.total)} net=${"%.4f".format(edge)}"
            )
        }

        out += opportunity("YES", market.yesTokenId, modelYes.coerceIn(0.0, 1.0), yesBook)
        if (noBook != null) {
            out += opportunity("NO", market.noTokenId, (1.0 - modelYes).coerceIn(0.0, 1.0), noBook)
        }
        return out
    }

    fun toSignal(op: PolyEdgeOpportunity, size: Double = 10.0): TradingSignal.PredictionMarketSignal? {
        if (op.action != "BUY") return null
        return TradingSignal.PredictionMarketSignal(
            venue = "POLYMARKET",
            marketId = op.market.conditionId,
            outcome = op.outcome,
            marketPrice = op.marketP,
            modelProbability = op.modelP,
            edge = op.edge,
            expectedValue = op.ev,
            liquidityScore = op.liquidityScore,
            spread = op.spread,
            timeToResolutionSec = op.timeToResolutionSec,
            action = "BUY"
        )
    }

    private fun liquidityScore(book: PolyOrderBook?): Double {
        if (book == null) return 0.2
        val depth = (book.bids.take(5).sumOf { it.size } + book.asks.take(5).sumOf { it.size })
        return (depth / 500.0).coerceIn(0.0, 1.0)
    }
}
