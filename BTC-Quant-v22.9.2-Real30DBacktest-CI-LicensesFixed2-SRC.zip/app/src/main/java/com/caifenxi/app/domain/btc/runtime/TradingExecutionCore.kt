package com.caifenxi.app.domain.btc.runtime

import kotlin.math.max

/** v21.2 unified order/execution semantics shared by paper, backtest and live adapters. */
enum class OrderSide { BUY, SELL }
enum class OrderType { MARKET, LIMIT }
enum class OrderStatus { CREATED, SUBMITTING, OPEN, PARTIAL, FILLED, CANCELED, REJECTED, UNKNOWN }

data class OrderIntentSpec(
    val clientId: String,
    val symbol: String,
    val side: OrderSide,
    val type: OrderType = OrderType.MARKET,
    val quantity: Double,
    val limitPrice: Double? = null,
    val reduceOnly: Boolean = false,
    val mode: TradingMode = TradingMode.PAPER
)

data class ExecutionFill(
    val clientId: String,
    val orderId: String,
    val symbol: String,
    val side: OrderSide,
    val price: Double,
    val quantity: Double,
    val fee: Double,
    val atMs: Long
)

data class PaperPosition(
    val symbol: String,
    val quantity: Double = 0.0,
    val averageEntry: Double = 0.0,
    val realizedPnl: Double = 0.0
) {
    val side: OrderSide? get() = when {
        quantity > 0.0 -> OrderSide.BUY
        quantity < 0.0 -> OrderSide.SELL
        else -> null
    }
}

data class PaperAccount(
    val startingCash: Double,
    val cash: Double,
    val equity: Double,
    val peakEquity: Double,
    val realizedPnl: Double,
    val unrealizedPnl: Double,
    val fees: Double,
    val usedMargin: Double = 0.0,
    val availableMargin: Double = cash
) {
    val drawdownPct: Double
        get() = if (peakEquity <= 0.0) 0.0 else ((peakEquity - equity) / peakEquity * 100.0).coerceAtLeast(0.0)
}

interface TradingBroker {
    fun submit(intent: OrderIntentSpec, marketPrice: Double, atMs: Long = System.currentTimeMillis()): ExecutionResult
    fun cancel(clientId: String, atMs: Long = System.currentTimeMillis()): ExecutionResult
    fun mark(symbol: String, marketPrice: Double, atMs: Long = System.currentTimeMillis()): PaperAccount
    fun account(): PaperAccount
    fun position(symbol: String): PaperPosition
}

data class ExecutionResult(
    val status: OrderStatus,
    val clientId: String,
    val orderId: String,
    val fill: ExecutionFill? = null,
    val message: String = ""
)

/** Deterministic paper broker: market orders fill immediately with configurable fee/slippage. */
class PaperTradingBroker(
    startingCash: Double = 10_000.0,
    private val feeRate: Double = 0.0004,
    private val slippageBps: Double = 1.0,
    marginRate: Double = 1.0
) : TradingBroker {
    private val orders = linkedMapOf<String, ExecutionResult>()
    private val pendingIntents = linkedMapOf<String, OrderIntentSpec>()
    private val accounting = TradingAccountingEngine(startingCash, marginRate)

    override fun submit(intent: OrderIntentSpec, marketPrice: Double, atMs: Long): ExecutionResult {
        orders[intent.clientId]?.let { return it }
        if (marketPrice <= 0.0 || intent.quantity <= 0.0) {
            return reject(intent, "无效价格或数量")
        }
        val decision = UnifiedFillEngine.evaluate(
            intent,
            FillMarketState(bid = marketPrice, ask = marketPrice, last = marketPrice),
            FillModelConfig(feeRate = feeRate, slippageBps = slippageBps)
        )
        if (decision.status == OrderStatus.REJECTED || decision.status == OrderStatus.UNKNOWN) {
            return reject(intent, decision.reason, decision.status)
        }
        if (decision.status == OrderStatus.OPEN) {
            val result = ExecutionResult(OrderStatus.OPEN, intent.clientId, "PAPER-${intent.clientId}", message = decision.reason)
            orders[intent.clientId] = result
            pendingIntents[intent.clientId] = intent
            return result
        }
        return applyFill(intent, decision.price, decision.quantity, decision.fee, atMs, decision.status, decision.reason)
    }

    fun onMarket(symbol: String, marketPrice: Double, atMs: Long = System.currentTimeMillis()) {
        if (marketPrice <= 0.0) return
        accounting.mark(symbol, marketPrice)
        val pending = orders.values.filter { it.status == OrderStatus.OPEN }
        pending.forEach { old ->
            val intent = pendingIntents[old.clientId] ?: return@forEach
            if (intent.symbol != symbol) return@forEach
            val decision = UnifiedFillEngine.evaluate(
                intent,
                FillMarketState(marketPrice, marketPrice, marketPrice),
                FillModelConfig(feeRate = feeRate, slippageBps = slippageBps)
            )
            if (decision.status == OrderStatus.FILLED || decision.status == OrderStatus.PARTIAL) {
                applyFill(intent, decision.price, decision.quantity, decision.fee, atMs, decision.status, decision.reason)
            }
        }
    }

    private fun applyFill(intent: OrderIntentSpec, price: Double, quantity: Double, fee: Double, atMs: Long, status: OrderStatus, message: String): ExecutionResult {
        return try {
            val fill = accounting.applyFill(intent, price, quantity, fee, atMs)
            val result = ExecutionResult(status, intent.clientId, fill.orderId, fill, message)
            orders[intent.clientId] = result
            pendingIntents.remove(intent.clientId)
            result
        } catch (e: IllegalStateException) {
            reject(intent, e.message ?: "会计引擎拒绝")
        }
    }

    override fun cancel(clientId: String, atMs: Long): ExecutionResult {
        val old = orders[clientId] ?: return ExecutionResult(OrderStatus.UNKNOWN, clientId, "UNKNOWN-$clientId", message = "订单不存在")
        if (old.status == OrderStatus.FILLED) return old
        val result = old.copy(status = OrderStatus.CANCELED, message = "模拟撤单")
        orders[clientId] = result
        pendingIntents.remove(clientId)
        return result
    }

    override fun mark(symbol: String, marketPrice: Double, atMs: Long): PaperAccount = accounting.mark(symbol, marketPrice)
    override fun account(): PaperAccount = accounting.account()
    override fun position(symbol: String): PaperPosition = accounting.position(symbol)

    private fun reject(intent: OrderIntentSpec, reason: String, status: OrderStatus = OrderStatus.REJECTED): ExecutionResult {
        val result = ExecutionResult(status, intent.clientId, "PAPER-${intent.clientId}", message = reason)
        orders[intent.clientId] = result
        return result
    }
}
