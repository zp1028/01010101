package com.caifenxi.app.domain.btc.strategy

import com.caifenxi.app.domain.btc.MarketRegime

/** Runtime hierarchy: regime -> factor quality -> strategy allocation. */
class RegimeFactorStrategyMatrix {
    data class Allocation(val regime: MarketRegime, val factorWeights: Map<String, Double>, val strategyWeights: Map<String, Double>)

    fun allocate(regime: MarketRegime, factorQuality: Map<String, Double>, strategyQuality: Map<String, Double>, strategyFactors: Map<String, List<String>>): Allocation {
        val factors = factorQuality.mapValues { (_, v) -> v.coerceIn(0.0, 1.0) }
        val regimeMultiplier = when (regime) {
            MarketRegime.TREND_UP, MarketRegime.TREND_DOWN -> 1.0
            MarketRegime.RANGE -> 0.85
            MarketRegime.BREAKOUT -> 1.10
            MarketRegime.HIGH_VOLATILITY -> 0.75
        }
        val strategies = strategyQuality.mapValues { (id, q) ->
            val factorMean = strategyFactors[id].orEmpty().mapNotNull { factors[it] }.average().takeIf { !it.isNaN() } ?: 0.5
            (q.coerceIn(0.0, 1.0) * 0.55 + factorMean * 0.45) * regimeMultiplier
        }
        return Allocation(regime, normalize(factors), normalize(strategies))
    }

    private fun normalize(values: Map<String, Double>): Map<String, Double> {
        val sum = values.values.sum().coerceAtLeast(1e-9)
        return values.mapValues { (it.value / sum).coerceIn(0.0, 1.0) }
    }
}
