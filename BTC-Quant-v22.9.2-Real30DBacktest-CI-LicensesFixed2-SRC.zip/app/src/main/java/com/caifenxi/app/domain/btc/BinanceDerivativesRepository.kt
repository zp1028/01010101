package com.caifenxi.app.domain.btc

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Live + historical derivatives data (Mark / Funding / OI).
 * Point-in-time consumers must filter by timestamp themselves.
 */
class BinanceDerivativesRepository(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(6, TimeUnit.SECONDS)
        .callTimeout(8, TimeUnit.SECONDS)
        .build()
) {
    private val bases = listOf(
        "https://fapi.binance.com",
        "https://api.binance.com"
    )

    suspend fun snapshot(symbol: String = "BTCUSDT"): BtcDerivativesSnapshot = withContext(Dispatchers.IO) {
        var lastError: Exception? = null
        for (base in bases) {
            try {
                val premium = getJsonObject("$base/fapi/v1/premiumIndex?symbol=$symbol")
                val oi = getJsonObject("$base/fapi/v1/openInterest?symbol=$symbol")
                return@withContext BtcDerivativesSnapshot(
                    symbol = symbol,
                    markPrice = premium.optString("markPrice", "0").toDoubleOrNull() ?: 0.0,
                    indexPrice = premium.optString("indexPrice", "0").toDoubleOrNull() ?: 0.0,
                    fundingRate = premium.optString("lastFundingRate", "0").toDoubleOrNull() ?: 0.0,
                    nextFundingTime = premium.optLong("nextFundingTime", 0L),
                    openInterest = oi.optString("openInterest", "0").toDoubleOrNull() ?: 0.0
                )
            } catch (e: Exception) {
                lastError = e
                continue
            }
        }
        // 合约站 451 时，用现货价充当标记价，保证看板有真实行情数字
        val spot = fetchSpotPrice(symbol)
        return@withContext BtcDerivativesSnapshot(
            symbol = symbol,
            markPrice = spot,
            indexPrice = spot,
            fundingRate = 0.0,
            nextFundingTime = 0L,
            openInterest = 0.0
        )
    }

    private fun fetchSpotPrice(symbol: String): Double {
        val urls = listOf(
            "https://data-api.binance.vision/api/v3/ticker/price?symbol=${symbol.uppercase()}",
            "https://api.binance.us/api/v3/ticker/price?symbol=${symbol.uppercase()}",
            "https://api.binance.com/api/v3/ticker/price?symbol=${symbol.uppercase()}"
        )
        for (url in urls) {
            try {
                val obj = getJsonObject(url)
                val px = obj.optString("price", "0").toDoubleOrNull() ?: 0.0
                if (px > 0.0) return px
            } catch (_: Exception) {
            }
        }
        return 0.0
    }

    /** Recent funding settlements, oldest → newest. */
    suspend fun fundingHistory(symbol: String = "BTCUSDT", limit: Int = 100): List<FundingPoint> =
        withContext(Dispatchers.IO) {
            var lastError: Exception? = null
            for (base in bases) {
                try {
                    val arr = getJsonArray("$base/fapi/v1/fundingRate?symbol=$symbol&limit=$limit")
                    return@withContext buildList {
                        for (i in 0 until arr.length()) {
                            val o = arr.getJSONObject(i)
                            add(
                                FundingPoint(
                                    symbol = symbol,
                                    fundingTime = o.optLong("fundingTime"),
                                    fundingRate = o.optString("fundingRate", "0").toDoubleOrNull() ?: 0.0,
                                    markPrice = o.optString("markPrice").toDoubleOrNull()
                                )
                            )
                        }
                    }.sortedBy { it.fundingTime }
                } catch (e: Exception) {
                    lastError = e
                    continue
                }
            }
            return@withContext emptyList()
        }

    /**
     * OI history. period: 5m,15m,30m,1h,2h,4h,6h,12h,1d
     * Public futures data endpoint.
     */
    suspend fun openInterestHistory(
        symbol: String = "BTCUSDT",
        period: String = "15m",
        limit: Int = 100
    ): List<OpenInterestPoint> = withContext(Dispatchers.IO) {
        var lastError: Exception? = null
        for (base in bases) {
            try {
                val url = "$base/futures/data/openInterestHist?symbol=$symbol&period=$period&limit=$limit"
                val arr = getJsonArray(url)
                return@withContext buildList {
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        add(
                            OpenInterestPoint(
                                symbol = symbol,
                                timestamp = o.optLong("timestamp"),
                                sumOpenInterest = o.optString("sumOpenInterest", "0").toDoubleOrNull() ?: 0.0,
                                sumOpenInterestValue = o.optString("sumOpenInterestValue", "0").toDoubleOrNull() ?: 0.0
                            )
                        )
                    }
                }.sortedBy { it.timestamp }
            } catch (e: Exception) {
                lastError = e
                continue
            }
        }
        return@withContext emptyList()
    }

    private fun getJsonObject(url: String): JSONObject {
        val req = Request.Builder().url(url).header("User-Agent", "BTCQuant/11.0").get().build()
        client.newCall(req).execute().use { resp ->
            val body = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) error("HTTP ${resp.code}: ${body.take(200)}")
            return JSONObject(body)
        }
    }

    private fun getJsonArray(url: String): JSONArray {
        val req = Request.Builder().url(url).header("User-Agent", "BTCQuant/11.0").get().build()
        client.newCall(req).execute().use { resp ->
            val body = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) error("HTTP ${resp.code}: ${body.take(200)}")
            return JSONArray(body)
        }
    }
}
