package com.caifenxi.app.domain.btc.backtest

import kotlin.math.max
import kotlin.math.min

/** v21.6 deterministic event-sequence replay. It keeps book state between updates instead of replaying isolated snapshots. */
object OrderBookEventReplayEngine {
    enum class Side { BID, ASK }
    sealed interface Event { val timeMs: Long
        data class Upsert(override val timeMs: Long, val side: Side, val price: Double, val size: Double) : Event
        data class Delete(override val timeMs: Long, val side: Side, val price: Double) : Event
        data class Trade(override val timeMs: Long, val price: Double, val size: Double, val aggressor: Side) : Event
    }
    data class Level(val price: Double, val size: Double)
    data class Book(val timeMs: Long, val bids: List<Level>, val asks: List<Level>)
    data class ReplayFill(val timeMs: Long, val price: Double, val size: Double)
    data class ReplayResult(val fills: List<ReplayFill>, val filledSize: Double, val avgPrice: Double, val unfilledSize: Double, val vwapSlippageBps: Double, val eventsApplied: Int)

    fun replay(events: List<Event>, side: Side, size: Double, limitPrice: Double? = null, referencePrice: Double? = null): ReplayResult {
        if (size <= 0.0) return ReplayResult(emptyList(), 0.0, 0.0, 0.0, 0.0, 0)
        val ordered = events.sortedWith(compareBy<Event> { it.timeMs }.thenBy { eventOrder(it) })
        val bids = linkedMapOf<Double, Double>()
        val asks = linkedMapOf<Double, Double>()
        val fills = mutableListOf<ReplayFill>()
        var remaining = size
        var applied = 0
        for (event in ordered) {
            when (event) {
                is Event.Upsert -> if (event.price > 0.0) (if (event.side == Side.BID) bids else asks)[event.price] = event.size.coerceAtLeast(0.0)
                is Event.Delete -> (if (event.side == Side.BID) bids else asks).remove(event.price)
                is Event.Trade -> {
                    // A trade consumes the displayed side opposite the aggressor.
                    val consumed = if (event.aggressor == Side.BID) asks else bids
                    val current = consumed[event.price] ?: 0.0
                    if (current > 0.0) consumed[event.price] = max(0.0, current - event.size)
                }
            }
            applied++
            if (remaining <= 1e-12) break
            val levels = if (side == Side.BID) asks.entries.sortedBy { it.key } else bids.entries.sortedByDescending { it.key }
            for ((price, available) in levels) {
                if (remaining <= 1e-12) break
                val executable = if (side == Side.BID) limitPrice == null || price <= limitPrice else limitPrice == null || price >= limitPrice
                if (!executable) break
                val take = min(remaining, available.coerceAtLeast(0.0))
                if (take > 0.0) {
                    fills += ReplayFill(event.timeMs, price, take)
                    remaining -= take
                    val book = if (side == Side.BID) asks else bids
                    val left = (book[price] ?: 0.0) - take
                    if (left <= 1e-12) book.remove(price) else book[price] = left
                }
            }
        }
        val filled = fills.sumOf { it.size }
        val avg = if (filled > 0.0) fills.sumOf { it.price * it.size } / filled else 0.0
        val ref = referencePrice ?: run {
            val bid = bids.keys.maxOrNull(); val ask = asks.keys.minOrNull()
            if (bid != null && ask != null) (bid + ask) / 2.0 else null
        }
        val slip = if (ref != null && ref > 0.0 && filled > 0.0) ((if (side == Side.BID) avg - ref else ref - avg) / ref) * 10_000.0 else 0.0
        return ReplayResult(fills, filled, avg, remaining.coerceAtLeast(0.0), slip, applied)
    }

    private fun eventOrder(event: Event): Int = when (event) { is Event.Delete -> 0; is Event.Upsert -> 1; is Event.Trade -> 2 }
}
