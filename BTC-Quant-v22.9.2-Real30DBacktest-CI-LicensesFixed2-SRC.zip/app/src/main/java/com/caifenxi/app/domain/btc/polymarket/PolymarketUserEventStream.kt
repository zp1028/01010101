package com.caifenxi.app.domain.btc.polymarket

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture

/**
 * Authenticated Polymarket CLOB user-channel stream.
 *
 * This is the private order/trade observation leg only. It does not sign or
 * submit orders. L2 credentials are used exactly as documented by Polymarket.
 * REST remains the recovery/reconciliation source of truth.
 */
class PolymarketUserEventStream(
    private val apiKey: String,
    private val apiSecret: String,
    private val passphrase: String,
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build(),
    private val url: String = "wss://ws-subscriptions-clob.polymarket.com/ws/user"
) {
    interface Listener {
        fun onConnected() {}
        fun onOrder(event: UserOrderEvent) {}
        fun onTrade(event: UserTradeEvent) {}
        fun onError(message: String, throwable: Throwable? = null) {}
        fun onClosed() {}
    }

    data class UserOrderEvent(
        val id: String,
        val market: String,
        val assetId: String,
        val side: String,
        val originalSize: Double,
        val sizeMatched: Double,
        val price: Double,
        val type: String,
        val status: String,
        val timestampMs: Long
    )

    data class UserTradeEvent(
        val id: String,
        val market: String,
        val assetId: String,
        val side: String,
        val size: Double,
        val price: Double,
        val feeRateBps: Double,
        val status: String,
        val transactionHash: String,
        val timestampMs: Long
    )

    @Volatile private var socket: WebSocket? = null
    @Volatile private var listener: Listener? = null
    private val lastEventIds = ConcurrentHashMap.newKeySet<String>()
    private val scheduler = Executors.newSingleThreadScheduledExecutor { r ->
        Thread(r, "polymarket-user-ws").apply { isDaemon = true }
    }
    @Volatile private var reconnectTask: ScheduledFuture<*>? = null
    @Volatile private var pingTask: ScheduledFuture<*>? = null
    @Volatile private var desiredMarkets: Set<String> = emptySet()
    @Volatile private var reconnectEnabled: Boolean = false
    @Volatile private var reconnectAttempt: Int = 0

    fun connect(markets: Collection<String> = emptyList(), listener: Listener): WebSocket? {
        if (apiKey.isBlank() || apiSecret.isBlank() || passphrase.isBlank()) {
            listener.onError("Polymarket user stream requires L2 apiKey/secret/passphrase")
            return null
        }
        this.listener = listener
        desiredMarkets = markets.filter { it.isNotBlank() }.toSet()
        reconnectEnabled = true
        reconnectAttempt = 0
        cancelTasks()
        socket?.close(1000, "replace")
        val request = Request.Builder().url(url).build()
        val ws = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                socket = webSocket
                val auth = JSONObject()
                    .put("apiKey", apiKey)
                    .put("secret", apiSecret)
                    .put("passphrase", passphrase)
                webSocket.send(JSONObject().put("auth", auth).put("type", "user").toString())
                reconnectAttempt = 0
                if (desiredMarkets.isNotEmpty()) subscribe(webSocket, desiredMarkets)
                startPingLoop()
                listener.onConnected()
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (text.equals("PONG", true) || text.equals("pong", true)) return
                runCatching { JSONObject(text) }
                    .onSuccess { parse(it, listener) }
                    .onFailure { listener.onError("Polymarket user WS JSON parse failed", it) }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (socket === webSocket) socket = null
                stopPingLoop()
                listener.onError("Polymarket user WS failure: ${t.message}", t)
                scheduleReconnect()
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (socket === webSocket) socket = null
                stopPingLoop()
                listener.onClosed()
                scheduleReconnect()
            }
        })
        socket = ws
        return ws
    }

    fun subscribe(markets: Collection<String>): Boolean = socket?.let { subscribe(it, markets) } ?: false

    fun unsubscribe(markets: Collection<String>): Boolean = socket?.let { ws ->
        val ids = markets.filter { it.isNotBlank() }.distinct()
        if (ids.isEmpty()) false else ws.send(JSONObject()
            .put("operation", "unsubscribe")
            .put("markets", org.json.JSONArray(ids))
            .toString()).also { if (it) desiredMarkets = desiredMarkets - ids.toSet() }
    } ?: false

    fun ping(): Boolean = socket?.send("PING") ?: false

    fun close() {
        reconnectEnabled = false
        cancelTasks()
        socket?.close(1000, "client shutdown")
        socket = null
        listener = null
        desiredMarkets = emptySet()
        lastEventIds.clear()
    }

    private fun subscribe(ws: WebSocket, markets: Collection<String>): Boolean {
        val ids = markets.filter { it.isNotBlank() }.distinct()
        if (ids.isEmpty()) return false
        return ws.send(JSONObject()
            .put("operation", "subscribe")
            .put("markets", org.json.JSONArray(ids))
            .toString()).also { if (it) desiredMarkets = desiredMarkets + ids }
    }

    private fun startPingLoop() {
        stopPingLoop()
        pingTask = scheduler.scheduleAtFixedRate({
            runCatching { socket?.send("PING") }
        }, 5, 10, TimeUnit.SECONDS)
    }

    private fun stopPingLoop() {
        pingTask?.cancel(false)
        pingTask = null
    }

    private fun scheduleReconnect() {
        if (!reconnectEnabled || listener == null || socket != null) return
        reconnectTask?.cancel(false)
        val delay = (1L shl reconnectAttempt.coerceAtMost(4)).coerceAtMost(15L)
        reconnectAttempt = (reconnectAttempt + 1).coerceAtMost(4)
        reconnectTask = scheduler.schedule({
            if (reconnectEnabled && socket == null) {
                val l = listener ?: return@schedule
                connect(desiredMarkets, l)
            }
        }, delay, TimeUnit.SECONDS)
    }

    private fun cancelTasks() {
        reconnectTask?.cancel(false)
        reconnectTask = null
        stopPingLoop()
    }

    private fun parse(o: JSONObject, listener: Listener) {
        val type = o.optString("event_type").lowercase()
        val id = o.optString("id")
        if (id.isNotBlank() && !lastEventIds.add("$type:$id")) return
        val tsRaw = o.optLong("timestamp", o.optLong("last_update", System.currentTimeMillis()))
        val ts = if (tsRaw < 10_000_000_000L) tsRaw * 1000L else tsRaw
        when (type) {
            "order" -> listener.onOrder(UserOrderEvent(
                id = id,
                market = o.optString("market"),
                assetId = o.optString("asset_id"),
                side = o.optString("side"),
                originalSize = number(o, "original_size"),
                sizeMatched = number(o, "size_matched"),
                price = number(o, "price"),
                type = o.optString("type"),
                status = o.optString("status"),
                timestampMs = ts
            ))
            "trade" -> listener.onTrade(UserTradeEvent(
                id = id,
                market = o.optString("market"),
                assetId = o.optString("asset_id"),
                side = o.optString("side"),
                size = number(o, "size"),
                price = number(o, "price"),
                feeRateBps = number(o, "fee_rate_bps"),
                status = o.optString("status"),
                transactionHash = o.optString("transaction_hash"),
                timestampMs = ts
            ))
        }
        if (lastEventIds.size > 5000) lastEventIds.clear()
    }

    private fun number(o: JSONObject, key: String): Double = when (val v = o.opt(key)) {
        is Number -> v.toDouble()
        is String -> v.toDoubleOrNull() ?: 0.0
        else -> 0.0
    }
}
