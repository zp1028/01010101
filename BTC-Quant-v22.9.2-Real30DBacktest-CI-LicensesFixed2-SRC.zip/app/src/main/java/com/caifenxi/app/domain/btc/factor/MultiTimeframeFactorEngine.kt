package com.caifenxi.app.domain.btc.factor

import com.caifenxi.app.domain.btc.BtcCandle
import com.caifenxi.app.domain.btc.DerivativesFeatures

/** Aligns independently calculated PIT factor snapshots across timeframes. */
class MultiTimeframeFactorEngine {
    data class Snapshot(val anchorTime: Long, val byTimeframe: Map<String, QuantFactorEngine.Snapshot>, val alignment: Double, val composite: Double)

    fun calculate(series: Map<String, List<BtcCandle>>, deriv: DerivativesFeatures? = null, symbol: String = "BTCUSDT"): Snapshot? {
        val snaps = series.mapNotNull { (tf, candles) -> QuantFactorEngine.calculate(candles, deriv, symbol, tf)?.let { tf to it } }.toMap()
        if (snaps.isEmpty()) return null
        val anchor = snaps.values.maxOf { it.barTime }
        val trend = snaps.values.map { it.value("TREND-COMPOSITE") }
        val momentum = snaps.values.map { it.value("MOMENTUM-COMPOSITE") }
        val alignedTrend = signedAgreement(trend)
        val alignedMomentum = signedAgreement(momentum)
        val composite = (snaps.values.map { it.composite }.average() * 0.5 + alignedTrend * 0.3 + alignedMomentum * 0.2).coerceIn(-1.0, 1.0)
        return Snapshot(anchor, snaps, ((alignedTrend + alignedMomentum) / 2.0).coerceIn(-1.0, 1.0), composite)
    }

    private fun signedAgreement(values: List<Double>): Double {
        if (values.isEmpty()) return 0.0
        val mean = values.average()
        val agreement = values.count { if (mean >= 0) it >= 0 else it <= 0 }.toDouble() / values.size
        return (mean * (0.5 + agreement * 0.5)).coerceIn(-1.0, 1.0)
    }
}
