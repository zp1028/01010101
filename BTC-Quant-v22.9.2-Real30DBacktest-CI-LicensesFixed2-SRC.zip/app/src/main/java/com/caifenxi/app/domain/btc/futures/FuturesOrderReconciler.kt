package com.caifenxi.app.domain.btc.futures

/**
 * Validates that live protective orders match the currently open exchange position.
 * The exchange is authoritative; this class never invents or places orders.
 */
object FuturesOrderReconciler {
    data class Result(
        val state: State,
        val openOrders: List<FuturesOpenOrder>,
        val stopOrders: List<FuturesOpenOrder>,
        val takeProfitOrders: List<FuturesOpenOrder>,
        val trailingOrders: List<FuturesOpenOrder>,
        val orphanProtectiveOrders: List<FuturesOpenOrder>,
        val message: String
    )

    enum class State { UNKNOWN, NO_POSITION, PROTECTED, PARTIAL_PROTECTION, ORPHAN_PROTECTION, ERROR }

    fun reconcile(position: PositionRiskInfo?, orders: List<FuturesOpenOrder>): Result {
        if (position == null || !position.isOpen) {
            val protective = orders.filter { it.reduceOnly && it.type != FuturesOrderType.MARKET }
            return Result(
                if (protective.isEmpty()) State.NO_POSITION else State.ORPHAN_PROTECTION,
                orders, emptyList(), emptyList(), emptyList(), protective,
                if (protective.isEmpty()) "无持仓，无保护单" else "检测到无持仓但仍存在保护单"
            )
        }
        val protective = orders.filter { it.reduceOnly && it.type != FuturesOrderType.MARKET }
        val stops = protective.filter { it.type == FuturesOrderType.STOP_MARKET }
        val tps = protective.filter { it.type == FuturesOrderType.TAKE_PROFIT_MARKET }
        val trails = protective.filter { it.type == FuturesOrderType.TRAILING_STOP_MARKET }
        val qty = kotlin.math.abs(position.positionAmt)
        val protectedQty = protective.sumOf { it.origQty.coerceAtLeast(it.executedQty) }.coerceAtLeast(0.0)
        val hasStop = stops.any { it.origQty + 0.0000005 >= qty }
        val hasTp = tps.any { it.origQty + 0.0000005 >= qty } || trails.any { it.origQty + 0.0000005 >= qty }
        val state = when {
            hasStop && hasTp -> State.PROTECTED
            protective.isNotEmpty() && protectedQty > 0.0 -> State.PARTIAL_PROTECTION
            else -> State.PARTIAL_PROTECTION
        }
        return Result(state, orders, stops, tps, trails, emptyList(),
            when (state) {
                State.PROTECTED -> "SL/TP 保护完整"
                else -> "保护单不完整：持仓=${"%.6f".format(qty)} BTC，保护数量=${"%.6f".format(protectedQty)} BTC"
            })
    }
}
