package com.caifenxi.app.domain.btc.polymarket.research

import com.caifenxi.app.domain.btc.polymarket.strategy.PolymarketStrategyPool

/** Converts OOS results into a conservative automatic strategy lifecycle. */
object PolymarketStrategyLifecycleEngine {
    data class Decision(
        val strategyId: String,
        val status: PolymarketStrategyPool.Status,
        val weightMultiplier: Double,
        val reason: String
    )

    fun evaluate(metric: PolymarketWalkForwardEngine.StrategyMetric?, definition: PolymarketStrategyPool.Definition): Decision {
        if (metric == null || metric.settled < 20) {
            val keep = definition.status
            val w = when (keep) {
                PolymarketStrategyPool.Status.ACTIVE -> 1.0
                PolymarketStrategyPool.Status.SHADOW -> 0.65
                PolymarketStrategyPool.Status.DOWNWEIGHT -> 0.35
                PolymarketStrategyPool.Status.RETIRED -> 0.0
                PolymarketStrategyPool.Status.CANDIDATE -> 0.0
            }
            return Decision(definition.id, keep, w, "OOS样本不足，保持原始生命周期")
        }
        if (metric.lookaheadViolations > 0) return Decision(definition.id, PolymarketStrategyPool.Status.RETIRED, 0.0, "发现时间穿越/未来数据")
        if (metric.maxDrawdown > 0.35 || metric.profitFactor < 0.85) return Decision(definition.id, PolymarketStrategyPool.Status.DOWNWEIGHT, 0.35, "OOS风险或PF不足")
        if (metric.winRate >= 0.56 && metric.profitFactor >= 1.15 && metric.stability >= 0.55 && metric.avgEdge > 0.02 && metric.costDrag <= 0.08) {
            return Decision(definition.id, PolymarketStrategyPool.Status.ACTIVE, (1.0 + metric.score * 1.5).coerceIn(0.75, 2.25), "多折OOS稳定、成本后仍通过")
        }
        return Decision(definition.id, PolymarketStrategyPool.Status.SHADOW, 0.65, "继续观察多折OOS表现")
    }
}
