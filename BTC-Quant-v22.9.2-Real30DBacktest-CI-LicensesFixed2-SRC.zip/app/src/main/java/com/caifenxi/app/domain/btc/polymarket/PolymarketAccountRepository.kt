package com.caifenxi.app.domain.btc.polymarket

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.util.concurrent.TimeUnit

data class PolymarketPosition(
    val asset: String,
    val conditionId: String,
    val size: Double,
    val avgPrice: Double,
    val currentValue: Double,
    val cashPnl: Double,
    val percentPnl: Double,
    val curPrice: Double,
    val redeemable: Boolean,
    val mergeable: Boolean,
    val outcome: String,
    val oppositeAsset: String,
    val endDate: String,
    val negativeRisk: Boolean
)

data class PolymarketActivity(
    val timestampMs: Long,
    val conditionId: String,
    val type: String,
    val size: Double,
    val usdcSize: Double,
    val transactionHash: String,
    val price: Double,
    val asset: String,
    val side: String,
    val outcome: String
)

/** Public Data API account reconciliation. It is intentionally read-only. */
class PolymarketAccountRepository(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .callTimeout(10, TimeUnit.SECONDS)
        .build(),
    private val baseUrl: String = "https://data-api.polymarket.com"
) {
    suspend fun positions(user: String, limit: Int = 500): List<PolymarketPosition> = withContext(Dispatchers.IO) {
        val url = "$baseUrl/positions?user=${user.trim()}&limit=${limit.coerceIn(0, 500)}"
        val arr = getArray(url)
        buildList {
            for (i in 0 until arr.length()) {
                val x = arr.optJSONObject(i) ?: continue
                add(PolymarketPosition(
                    asset = x.optString("asset"), conditionId = x.optString("conditionId"),
                    size = x.optDouble("size"), avgPrice = x.optDouble("avgPrice"),
                    currentValue = x.optDouble("currentValue"), cashPnl = x.optDouble("cashPnl"),
                    percentPnl = x.optDouble("percentPnl"), curPrice = x.optDouble("curPrice"),
                    redeemable = x.optBoolean("redeemable"), mergeable = x.optBoolean("mergeable"),
                    outcome = x.optString("outcome"), oppositeAsset = x.optString("oppositeAsset"),
                    endDate = x.optString("endDate"), negativeRisk = x.optBoolean("negativeRisk")
                ))
            }
        }
    }

    suspend fun activity(user: String, limit: Int = 100, offset: Int = 0): List<PolymarketActivity> = withContext(Dispatchers.IO) {
        val url = "$baseUrl/activity?user=${user.trim()}&limit=${limit.coerceIn(0, 500)}&offset=${offset.coerceAtLeast(0)}"
        val arr = getArray(url)
        buildList {
            for (i in 0 until arr.length()) {
                val x = arr.optJSONObject(i) ?: continue
                val sec = x.optLong("timestamp", 0L)
                add(PolymarketActivity(
                    timestampMs = if (sec < 10_000_000_000L) sec * 1000 else sec,
                    conditionId = x.optString("conditionId"), type = x.optString("type"),
                    size = x.optDouble("size"), usdcSize = x.optDouble("usdcSize"),
                    transactionHash = x.optString("transactionHash"), price = x.optDouble("price"),
                    asset = x.optString("asset"), side = x.optString("side"), outcome = x.optString("outcome")
                ))
            }
        }
    }

    private fun getArray(url: String): JSONArray {
        val req = Request.Builder().url(url).get().build()
        client.newCall(req).execute().use { r ->
            val body = r.body?.string().orEmpty()
            if (!r.isSuccessful) error("HTTP ${r.code} ${body.take(160)}")
            return JSONArray(body)
        }
    }
}
