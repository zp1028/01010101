package com.caifenxi.app.domain.btc.runtime

import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.runtime.BtcRuntimeStore

/** Paper adapter for the same TradingCore lifecycle; it writes to the persisted paper ledger. */
class TradingCorePaperAdapter(
    override val mode: TradingMode,
    private val store: BtcRuntimeStore
) : TradingCoreAdapter {
    override suspend fun submit(intent: TradingCoreIntent): ExecutionResult {
        val direction = if (intent.side == OrderSide.BUY) BtcDirection.UP else BtcDirection.DOWN
        val opened = store.paperLedger().open(
            symbol = intent.symbol,
            direction = direction,
            entry = intent.price,
            quantity = intent.quantity,
            leverage = intent.metadata["leverage"]?.toIntOrNull() ?: 1,
            stopLoss = intent.metadata["stopLoss"]?.toDoubleOrNull() ?: intent.price,
            takeProfit = intent.metadata["takeProfit"]?.toDoubleOrNull() ?: intent.price
        )
        return ExecutionResult(
            status = if (opened) OrderStatus.FILLED else OrderStatus.REJECTED,
            clientId = intent.clientId,
            orderId = "PAPER-${intent.clientId}",
            message = if (opened) "paper position opened" else "paper position already active"
        )
    }
}
