package com.caifenxi.app.domain.btc.backtest

import kotlin.math.min

/** Deterministic level-2 replay/matching model for research. */
object L2OrderBookReplayEngine {
    enum class Side { BUY, SELL }
    enum class Tif { IOC, FOK }
    data class Level(val price: Double, val size: Double)
    data class Snapshot(val timeMs: Long, val bids: List<Level>, val asks: List<Level>)
    data class Order(val side: Side, val size: Double, val limitPrice: Double? = null, val tif: Tif = Tif.IOC)
    data class Fill(val price: Double, val size: Double)
    data class Result(val fills: List<Fill>, val filledSize: Double, val avgPrice: Double, val unfilledSize: Double, val vwapSlippageBps: Double)

    fun replay(snapshot: Snapshot, order: Order, referencePrice: Double? = null): Result {
        if (order.size <= 0.0) return Result(emptyList(), 0.0, 0.0, 0.0, 0.0)
        val levels = if (order.side == Side.BUY) snapshot.asks.sortedBy { it.price } else snapshot.bids.sortedByDescending { it.price }
        val fills = mutableListOf<Fill>(); var remaining = order.size
        for (level in levels) {
            if (remaining <= 1e-12) break
            val executable = if (order.side == Side.BUY) {
                order.limitPrice == null || level.price <= order.limitPrice
            } else order.limitPrice == null || level.price >= order.limitPrice
            if (!executable) break
            val take = min(remaining, level.size.coerceAtLeast(0.0)); if (take <= 0) continue
            fills += Fill(level.price, take); remaining -= take
        }
        if (order.tif == Tif.FOK && remaining > 1e-12) return Result(emptyList(), 0.0, 0.0, order.size, 0.0)
        val filled = fills.sumOf { it.size }; val avg = if (filled > 0) fills.sumOf { it.price * it.size } / filled else 0.0
        val ref = referencePrice ?: snapshot.bids.maxByOrNull { it.price }?.price?.let { b -> snapshot.asks.minByOrNull { it.price }?.price?.let { a -> (a+b)/2 } }
        val slipBps = if (ref != null && ref > 0 && filled > 0) ((if (order.side == Side.BUY) avg-ref else ref-avg)/ref)*10_000.0 else 0.0
        return Result(fills, filled, avg, remaining.coerceAtLeast(0.0), slipBps)
    }
}
