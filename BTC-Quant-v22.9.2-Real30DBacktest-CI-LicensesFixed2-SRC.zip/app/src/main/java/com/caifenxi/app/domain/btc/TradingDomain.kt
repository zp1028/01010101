package com.caifenxi.app.domain.btc

sealed interface TradingSignal {
    data class ContractSignal(
        val planId: String,
        val barId: Long,
        val symbol: String,
        val direction: BtcDirection,
        val probability: Double,
        val expectedMovePct: Double,
        val entry: Double,
        val stopLoss: Double,
        val takeProfit: Double,
        val horizonBars: Int,
        val positionSize: Double,
        val leverageCap: Int,
        val confidence: Double,
        val reasonPlanIds: List<String> = emptyList(),
        val factorScore: Double = 0.0,
        val factorIds: List<String> = emptyList()
    ) : TradingSignal

    data class PredictionMarketSignal(
        val venue: String,
        val marketId: String,
        val outcome: String,
        val marketPrice: Double,
        val modelProbability: Double,
        val edge: Double,
        val expectedValue: Double,
        val liquidityScore: Double,
        val spread: Double,
        val timeToResolutionSec: Long,
        val action: String,
        val strategyId: String = "",
        val positionSize: Double = 10.0
    ) : TradingSignal

    data class EventContractSignal(
        val venue: String,
        val windowId: String,
        val underlying: String,
        val expiry: Long,
        val direction: BtcDirection,
        val premium: Double,
        val pWin: Double,
        val edgeAfterPremium: Double,
        val action: String
    ) : TradingSignal
}
