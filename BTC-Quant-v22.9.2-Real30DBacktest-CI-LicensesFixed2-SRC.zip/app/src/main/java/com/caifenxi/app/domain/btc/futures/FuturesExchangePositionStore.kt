package com.caifenxi.app.domain.btc.futures

import android.content.Context
import org.json.JSONObject

/** Persists the last exchange-authoritative futures position snapshot. */
class FuturesExchangePositionStore(context: Context) {
    private val prefs = context.getSharedPreferences("btc_futures_exchange_position_v1", Context.MODE_PRIVATE)

    fun save(risk: PositionRiskInfo?, source: String, syncedAt: Long = System.currentTimeMillis(), syncError: String? = null) {
        val o = JSONObject()
            .put("source", source)
            .put("syncedAt", syncedAt)
            .put("syncError", syncError)
        if (risk == null || !risk.isOpen) {
            o.put("open", false)
        } else {
            o.put("open", true)
                .put("symbol", risk.symbol)
                .put("positionAmt", risk.positionAmt)
                .put("entryPrice", risk.entryPrice)
                .put("markPrice", risk.markPrice)
                .put("unRealizedProfit", risk.unRealizedProfit)
                .put("liquidationPrice", risk.liquidationPrice)
                .put("leverage", risk.leverage)
                .put("maxNotionalValue", risk.maxNotionalValue)
                .put("marginType", risk.marginType)
                .put("notional", risk.notional)
                .put("isolatedWallet", risk.isolatedWallet)
                .put("updateTime", risk.updateTime)
        }
        prefs.edit().putString("snapshot", o.toString()).apply()
    }

    fun load(): ExchangePositionSnapshot? = runCatching {
        val o = JSONObject(prefs.getString("snapshot", "{}") ?: "{}")
        if (!o.optBoolean("open", false)) return@runCatching ExchangePositionSnapshot.empty(
            o.optString("source", "UNKNOWN"), o.optLong("syncedAt", 0L)
        )
        val risk = PositionRiskInfo(
            symbol = o.optString("symbol", "BTCUSDT"),
            positionAmt = o.optDouble("positionAmt", 0.0),
            entryPrice = o.optDouble("entryPrice", 0.0),
            markPrice = o.optDouble("markPrice", 0.0),
            unRealizedProfit = o.optDouble("unRealizedProfit", 0.0),
            liquidationPrice = o.optDouble("liquidationPrice", 0.0),
            leverage = o.optString("leverage", "1"),
            maxNotionalValue = o.optString("maxNotionalValue", "0"),
            marginType = o.optString("marginType", "isolated"),
            notional = o.optDouble("notional", 0.0),
            isolatedWallet = o.optDouble("isolatedWallet", 0.0),
            updateTime = o.optLong("updateTime", 0L)
        )
        ExchangePositionSnapshot(risk, o.optString("source", "UNKNOWN"), o.optLong("syncedAt", 0L), o.optString("syncError", null))
    }.getOrNull()
}

data class ExchangePositionSnapshot(
    val risk: PositionRiskInfo?,
    val source: String,
    val syncedAt: Long,
    val syncError: String? = null
) {
    val isOpen: Boolean get() = risk?.isOpen == true
    val ageMs: Long get() = if (syncedAt > 0L) (System.currentTimeMillis() - syncedAt).coerceAtLeast(0L) else Long.MAX_VALUE
    val isStale: Boolean get() = ageMs > 30_000L
    companion object {
        fun empty(source: String, syncedAt: Long) = ExchangePositionSnapshot(null, source, syncedAt)
    }
}
