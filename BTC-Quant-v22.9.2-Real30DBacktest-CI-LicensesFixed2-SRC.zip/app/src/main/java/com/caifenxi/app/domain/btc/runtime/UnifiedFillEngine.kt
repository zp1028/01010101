package com.caifenxi.app.domain.btc.runtime

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** v21.6 deterministic fill semantics shared by paper/replay adapters. */
data class FillMarketState(
    val bid: Double,
    val ask: Double,
    val last: Double,
    val availableBidQty: Double = Double.POSITIVE_INFINITY,
    val availableAskQty: Double = Double.POSITIVE_INFINITY
) {
    val mid: Double get() = if (bid > 0.0 && ask > 0.0) (bid + ask) / 2.0 else last
}

data class FillModelConfig(
    val feeRate: Double = 0.0004,
    val slippageBps: Double = 1.0,
    val partialFillRatio: Double = 1.0,
    val makerFeeRate: Double? = null
)

data class FillDecision(
    val status: OrderStatus,
    val price: Double = 0.0,
    val quantity: Double = 0.0,
    val fee: Double = 0.0,
    val reason: String = ""
)

object UnifiedFillEngine {
    fun evaluate(intent: OrderIntentSpec, market: FillMarketState, config: FillModelConfig = FillModelConfig()): FillDecision {
        if (intent.quantity <= 0.0) return FillDecision(OrderStatus.REJECTED, reason = "数量必须大于0")
        val reference = if (intent.side == OrderSide.BUY) market.ask else market.bid
        if (reference <= 0.0) return FillDecision(OrderStatus.UNKNOWN, reason = "盘口价格不可用")
        val limit = intent.limitPrice
        if (intent.type == OrderType.LIMIT && limit == null) return FillDecision(OrderStatus.REJECTED, reason = "限价单缺少价格")
        if (intent.type == OrderType.LIMIT) {
            val executable = if (intent.side == OrderSide.BUY) reference <= limit!! else reference >= limit!!
            if (!executable) return FillDecision(OrderStatus.OPEN, reason = "等待限价触发")
        }
        val cap = if (intent.side == OrderSide.BUY) market.availableAskQty else market.availableBidQty
        val quantity = min(intent.quantity, cap).coerceAtLeast(0.0) * config.partialFillRatio.coerceIn(0.0, 1.0)
        if (quantity <= 1e-12) return FillDecision(OrderStatus.OPEN, reason = "盘口流动性不足")
        val slip = max(0.0, config.slippageBps) / 10_000.0
        val price = when (intent.type) {
            OrderType.MARKET -> reference * if (intent.side == OrderSide.BUY) 1.0 + slip else 1.0 - slip
            OrderType.LIMIT -> limit!!
        }
        val feeRate = config.makerFeeRate ?: config.feeRate
        val fee = abs(price * quantity) * max(0.0, feeRate)
        val status = if (quantity + 1e-12 >= intent.quantity) OrderStatus.FILLED else OrderStatus.PARTIAL
        return FillDecision(status, price, quantity, fee, if (status == OrderStatus.FILLED) "成交" else "部分成交")
    }
}
