package com.caifenxi.app.domain.btc.polymarket.strategy

/**
 * Atomic two-leg lifecycle. A leg is never considered protected merely because
 * the other leg was submitted; protection starts only after both fills reconcile.
 */
enum class TwoLegStage { DETECTED, SUBMITTING, LEG_A_OPEN, LEG_B_OPEN, HEDGING, PROTECTED, UNWINDING, CLOSED, BLOCKED, ERROR }

data class TwoLegExecutionState(
    val executionId: String,
    val marketId: String,
    val yesTokenId: String,
    val noTokenId: String,
    val targetSize: Double,
    val yesFilled: Double = 0.0,
    val noFilled: Double = 0.0,
    val stage: TwoLegStage = TwoLegStage.DETECTED,
    val lastAction: String = "",
    val updatedAtMs: Long = System.currentTimeMillis()
) {
    val balancedSize: Double get() = minOf(yesFilled, noFilled)
    val unhedgedYes: Double get() = (yesFilled - noFilled).coerceAtLeast(0.0)
    val unhedgedNo: Double get() = (noFilled - yesFilled).coerceAtLeast(0.0)
    val fullyFilled: Boolean get() = yesFilled + 1e-9 >= targetSize && noFilled + 1e-9 >= targetSize
}

object PolymarketTwoLegExecutionStateMachine {
    fun onFill(state: TwoLegExecutionState, yes: Boolean, fillSize: Double, nowMs: Long = System.currentTimeMillis()): TwoLegExecutionState {
        if (fillSize <= 0 || state.stage == TwoLegStage.CLOSED || state.stage == TwoLegStage.BLOCKED) return state
        val y = if (yes) (state.yesFilled + fillSize).coerceAtMost(state.targetSize) else state.yesFilled
        val n = if (!yes) (state.noFilled + fillSize).coerceAtMost(state.targetSize) else state.noFilled
        val nextStage = when {
            y >= state.targetSize && n >= state.targetSize -> TwoLegStage.PROTECTED
            y > n -> TwoLegStage.LEG_A_OPEN
            n > y -> TwoLegStage.LEG_B_OPEN
            y > 0 || n > 0 -> TwoLegStage.HEDGING
            else -> state.stage
        }
        return state.copy(yesFilled = y, noFilled = n, stage = nextStage, lastAction = if (yes) "YES_FILL" else "NO_FILL", updatedAtMs = nowMs)
    }

    fun markUnwinding(state: TwoLegExecutionState, reason: String, nowMs: Long = System.currentTimeMillis()) =
        state.copy(stage = TwoLegStage.UNWINDING, lastAction = reason, updatedAtMs = nowMs)

    fun close(state: TwoLegExecutionState, reason: String = "closed", nowMs: Long = System.currentTimeMillis()) =
        state.copy(stage = TwoLegStage.CLOSED, lastAction = reason, updatedAtMs = nowMs)
}
