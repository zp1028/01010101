package com.caifenxi.app.domain.btc

import com.caifenxi.app.domain.btc.news.NewsItem
import com.caifenxi.app.domain.btc.news.NewsSnapshot
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

/**
 * Demo / 离线模式数据提供者。
 * 当网络不可达时（如中国大陆无代理环境），生成逼真的合成 BTC K 线 + 衍生品数据，
 * 使策略引擎、回测、模拟交易等核心功能可正常演示运行。
 */
object BtcDemoDataProvider {

    private const val DEFAULT_PRICE = 65000.0
    private const val VOLATILITY_PCT = 0.008  // 0.8% per candle

    /** 生成 300 根合成 K 线（约 25h @5m, 62h @15m, 125h @30m, 250h @1h） */
    fun generateCandles(
        symbol: String = "BTCUSDT",
        interval: String = "15m",
        count: Int = 300,
        seedPrice: Double = DEFAULT_PRICE
    ): List<BtcCandle> {
        val intervalMs = intervalToMillis(interval)
        val now = System.currentTimeMillis()
        // 对齐到当前正在形成的 bar 起点，保证多周期时间对齐（否则 15m/1h 会被误判为 STALE）
        val lastOpen = now - (now % intervalMs)
        val startTime = lastOpen - (count - 1) * intervalMs
        // 用当前分钟做种子：同一分钟内可复现，跨分钟会演变，避免看板“永远同一根图”
        val random = Random((now / 60_000L).toInt())

        var price = seedPrice
        return (0 until count).map { i ->
            val t = i.toDouble() / count
            // 合成趋势：轻微上升趋势 + 周期性波动
            val trend = sin(t * 2.0 * PI * 3.0) * 0.003 // 3个周期
            val noise = (random.nextDouble() - 0.5) * VOLATILITY_PCT * 2.0
            val change = trend + noise
            price *= (1.0 + change)
            price = price.coerceIn(seedPrice * 0.85, seedPrice * 1.15)

            val open = price * (1.0 + (random.nextDouble() - 0.5) * 0.001)
            val close = price
            val high = maxOf(open, close) * (1.0 + random.nextDouble() * VOLATILITY_PCT * 0.5)
            val low = minOf(open, close) * (1.0 - random.nextDouble() * VOLATILITY_PCT * 0.5)
            val volume = random.nextDouble() * 500.0 + 100.0

            BtcCandle(
                openTime = startTime + i * intervalMs,
                open = round4(open),
                high = round4(high),
                low = round4(low.coerceAtLeast(0.01)),
                close = round4(close),
                volume = round2(volume)
            )
        }
    }

    /** 合成衍生品快照 */
    fun generateDerivativesSnapshot(symbol: String = "BTCUSDT", markPrice: Double = DEFAULT_PRICE): BtcDerivativesSnapshot =
        BtcDerivativesSnapshot(
            symbol = symbol,
            markPrice = markPrice,
            indexPrice = markPrice * 0.9998,
            fundingRate = (Random.nextDouble() - 0.5) * 0.0005,
            nextFundingTime = System.currentTimeMillis() + 8 * 3600 * 1000L,
            openInterest = Random.nextDouble() * 50000.0 + 30000.0
        )

    /** 合成 Funding 历史 */
    fun generateFundingHistory(symbol: String = "BTCUSDT", count: Int = 100): List<FundingPoint> {
        val now = System.currentTimeMillis()
        val interval = 8 * 3600 * 1000L // 8h funding
        return (0 until count).map { i ->
            FundingPoint(
                symbol = symbol,
                fundingTime = now - (count - i) * interval,
                fundingRate = (Random.nextDouble() - 0.5) * 0.0005,
                markPrice = DEFAULT_PRICE * (1.0 + (Random.nextDouble() - 0.5) * 0.02)
            )
        }
    }

    /** 合成 OI 历史 */
    fun generateOiHistory(symbol: String = "BTCUSDT", count: Int = 100): List<OpenInterestPoint> {
        val now = System.currentTimeMillis()
        val interval = 15 * 60 * 1000L // 15m
        return (0 until count).map { i ->
            OpenInterestPoint(
                symbol = symbol,
                timestamp = now - (count - i) * interval,
                sumOpenInterest = 35000.0 + Random.nextDouble() * 20000.0,
                sumOpenInterestValue = 2.2e9 + Random.nextDouble() * 0.5e9
            )
        }
    }

    /** 合成新闻快照 */
    fun generateNewsSnapshot(): NewsSnapshot {
        val now = System.currentTimeMillis()
        val headlines = listOf(
            NewsItem(
                id = "demo-1",
                title = "BTC ETF inflows hit $500M daily record",
                summary = "Institutional investors continue to accumulate Bitcoin through ETF products",
                source = "demo",
                publishedAt = now - 3600_000L,
                entities = listOf("BTC", "ETF"),
                tags = listOf("macro", "institutional"),
                sentiment = 0.7,
                impactScore = 0.8
            ),
            NewsItem(
                id = "demo-2",
                title = "Fed signals potential rate cut in Q3",
                summary = "Federal Reserve minutes suggest dovish shift in monetary policy",
                source = "demo",
                publishedAt = now - 7200_000L,
                entities = listOf("Fed", "rate"),
                tags = listOf("macro", "policy"),
                sentiment = 0.5,
                impactScore = 0.6
            ),
            NewsItem(
                id = "demo-3",
                title = "Bitcoin halving event expected next month",
                summary = "Network difficulty adjustment incoming with block reward reduction",
                source = "demo",
                publishedAt = now - 1800_000L,
                entities = listOf("BTC", "halving"),
                tags = listOf("technical", "supply"),
                sentiment = 0.4,
                impactScore = 0.5
            )
        )
        return NewsSnapshot(
            asOf = now,
            items = headlines,
            netSentiment = headlines.map { it.sentiment * it.impactScore }.sum() / headlines.sumOf { it.impactScore },
            highImpactCount = 1,
            blackSwan = false,
            topHeadlines = headlines.map { it.title }
        )
    }

    private fun intervalToMillis(interval: String): Long {
        val num = interval.filter { it.isDigit() }.toIntOrNull() ?: 15
        return when {
            interval.endsWith("m") -> num * 60_000L
            interval.endsWith("h") -> num * 3600_000L
            interval.endsWith("d") -> num * 86400_000L
            interval.endsWith("w") -> num * 7 * 86400_000L
            else -> 15 * 60_000L
        }
    }

    private fun round4(v: Double) = kotlin.math.round(v * 10000.0) / 10000.0
    private fun round2(v: Double) = kotlin.math.round(v * 100.0) / 100.0
}
