package com.caifenxi.app.domain.btc.engine

import java.util.concurrent.ConcurrentHashMap

/**
 * Process-local idempotency guard. Keys are deterministic decision/order intents,
 * so a repeated scheduler tick cannot submit the same intent twice.
 */
class ExecutionIdempotency(private val ttlMs: Long = 10 * 60_000L) {
    private val seen = ConcurrentHashMap<String, Long>()

    fun tryAcquire(key: String, nowMs: Long = System.currentTimeMillis()): Boolean {
        if (key.isBlank()) return false
        cleanup(nowMs)
        return seen.putIfAbsent(key, nowMs) == null
    }

    fun release(key: String) { seen.remove(key) }

    fun contains(key: String, nowMs: Long = System.currentTimeMillis()): Boolean {
        cleanup(nowMs)
        return seen.containsKey(key)
    }

    private fun cleanup(nowMs: Long) {
        seen.entries.removeIf { nowMs - it.value > ttlMs }
    }
}
