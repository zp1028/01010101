package com.caifenxi.app.domain.btc.hs

import android.content.Context
import java.util.ArrayDeque

import com.caifenxi.app.domain.btc.BtcCandle
import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.BtcPlanEngine
import com.caifenxi.app.domain.btc.DerivativesFeatures
import com.caifenxi.app.domain.btc.BinanceOrderBookRepository
import com.caifenxi.app.domain.btc.polymarket.PolyOrderBook
import com.caifenxi.app.domain.btc.polymarket.PolyMarket
import com.caifenxi.app.domain.btc.MarketRegime
import com.caifenxi.app.domain.btc.factor.QuantFactorEngine
import com.caifenxi.app.domain.btc.factor.QuantFactorWeightStore
import com.caifenxi.app.domain.btc.plan.BtcProbabilityCalibrator
import com.caifenxi.app.domain.btc.plan.DynamicWeightEngine
import kotlin.math.abs
import kotlin.math.max

/**
 * HS Prediction Engine —— 机器学习风格概率预测核心
 *
 * 流水线：
 *  1. 多周期特征（趋势/动量/结构/波动/量/衍生品）
 *  2. 计划池加权共识 → 原始 p
 *  3. 贝叶斯粒子滤波更新（观测 = 共识 + 盘口倾斜）
 *  4. 概率校准（BtcProbabilityCalibrator 增强版）
 *  5. 相对 Polymarket 盘口计算 edge / alpha / spread
 *  6. 半凯利仓位 + bucket
 *  7. 输出 HsPredictionSnapshot（直接驱动看板）
 *
 * 设计参考：GLM / GPT / FABLE5 类模型的“概率输出 + 校准 + 决策”范式，
 * 但在本地用可解释的集成 + 贝叶斯滤波实现，避免黑盒依赖。
 */
class HsPredictionEngine(
    context: Context? = null,
    private val planEngine: BtcPlanEngine = BtcPlanEngine(),
    private val particleFilter: BayesParticleFilter = BayesParticleFilter(nParticles = 64),
    private val configProvider: () -> HsRuntimeConfig = { HsRuntimeConfigHolder.current },
    private val mlModel5m: BtcMlProbabilityModel = BtcMlProbabilityModel.forTimeframe("5m", HsRuntimeConfig.Default, context),
    private val mlModel15m: BtcMlProbabilityModel = BtcMlProbabilityModel.forTimeframe("15m", HsRuntimeConfig.Default, context),
    private val mlModel1h: BtcMlProbabilityModel = BtcMlProbabilityModel.forTimeframe("1h", HsRuntimeConfig.Default, context),
    private val modelPool5m: HsModelPool = HsModelPool(context, "5m"),
    private val modelPool15m: HsModelPool = HsModelPool(context, "15m"),
    private val modelPool1h: HsModelPool = HsModelPool(context, "1h"),
    private val feedback: HsFeedbackStore = HsFeedbackStore(context),
    private val fusionFeedback: FusionFeedbackStore = FusionFeedbackStore(context),
    private val modelLab: HsModelLab = HsModelLab(),
    private val shadow: HsShadowTradingStore = HsShadowTradingStore(context),
    private val lifecycleStore: HsModelLifecycleStore = HsModelLifecycleStore(context),
    private val snapshotStore: HsSnapshotStore = HsSnapshotStore(context),
    private val factorWeightStore: QuantFactorWeightStore? = context?.let { QuantFactorWeightStore(it) }
) {
    private fun cfg() = configProvider()
    private fun poolFor(tf: String) = when (tf) {
        "5m" -> modelPool5m
        "1h" -> modelPool1h
        else -> modelPool15m
    }
    private fun mlFor(tf: String) = when (tf) {
        "5m" -> mlModel5m
        "1h" -> mlModel1h
        else -> mlModel15m
    }
    private val phatHistory = mutableMapOf<String, ArrayDeque<Double>>()
    private val edgeHistory = ArrayDeque<Double>(60)
    private var curveHistoryRestored = false

    /** 首次评估前把落盘的曲线历史读回内存，避免重启后曲线从空白起步 */
    private fun restoreCurveHistoryOnce() {
        if (curveHistoryRestored) return
        curveHistoryRestored = true
        runCatching {
            snapshotStore.loadEdgeHistory().takeLast(60).forEach { edgeHistory.addLast(it) }
            snapshotStore.loadPhatHistory().forEach { (tf, list) ->
                val q = phatHistory.getOrPut(tf) { ArrayDeque<Double>(60) }
                list.takeLast(60).forEach { q.addLast(it) }
            }
        }
    }
    private data class PredictionMemory(val barId: Long, val close: Double, val pUp: Double)
    private data class FusionPredictionMemory(
        val barId: Long, val pUp: Double, val model: Double, val factor: Double, val strategy: Double, val disagreement: Double
    )
    private val memory = mutableMapOf<String, PredictionMemory>()
    private val fusionMemory = mutableMapOf<String, FusionPredictionMemory>()
    private val logs = ArrayDeque<String>(32)

    fun evaluate(
        candles5m: List<BtcCandle>,
        candles15m: List<BtcCandle>,
        candles1h: List<BtcCandle>,
        deriv: DerivativesFeatures? = null,
        marketYesPrice5m: Double = 0.50,
        marketYesPrice15m: Double = 0.50,
        marketYesPrice1h: Double = 0.50,
        balance: Double = 0.0,
        available: Double = 0.0,
        openNotional: Double = 0.0,
        todayPnl: Double = 0.0,
        pnl30d: Double = 0.0,
        maxDd: Double = 0.0,
        newsScore: Double = 0.0,
        markPrice: Double = 0.0,
        chainlinkPrice: Double = 0.0,
        perf: Map<String, DynamicWeightEngine.PlanPerf> = emptyMap(),
        binanceOrderBook: BinanceOrderBookRepository.Snapshot? = null,
        polyBooks: Map<String, PolyOrderBook> = emptyMap(),
        polyNoBooks: Map<String, PolyOrderBook> = emptyMap(),
        polyMarkets: Map<String, PolyMarket> = emptyMap(),
        oracleUpdatedAt: Long = 0L,
        oracleLive: Boolean = false,
        dataMode: String = "LIVE"
    ): HsPredictionSnapshot {
        val t0 = System.currentTimeMillis()
        val runtimeConfig = cfg()
        // 设置页修改后立即作用于三个 ML 实例；不再永久锁死 HsRuntimeConfig.Default。
        mlModel5m.updateConfig(runtimeConfig)
        mlModel15m.updateConfig(runtimeConfig)
        mlModel1h.updateConfig(runtimeConfig)
        restoreCurveHistoryOnce()
        log("FETCH   multi-tf candles ready 5m=${candles5m.size} 15m=${candles15m.size} 1h=${candles1h.size}")

        val lab5 = modelLab.evaluate(candles5m)
        val lab15 = modelLab.evaluate(candles15m)
        val lab1h = modelLab.evaluate(candles1h)
        recordFeedback("5m", candles5m); recordFusionFeedback("5m", candles5m)
        val tf5 = buildTf("5m", candles5m, deriv, marketYesPrice5m, perf, polyBooks["5m"], polyNoBooks["5m"], binanceOrderBook, newsScore, lab5)
        recordFeedback("15m", candles15m); recordFusionFeedback("15m", candles15m)
        val tf15 = buildTf("15m", candles15m, deriv, marketYesPrice15m, perf, polyBooks["15m"], polyNoBooks["15m"], binanceOrderBook, newsScore, lab15)
        recordFeedback("1h", candles1h); recordFusionFeedback("1h", candles1h)
        val tf1h = buildTf("1h", candles1h, deriv, marketYesPrice1h, perf, polyBooks["1h"], polyNoBooks["1h"], binanceOrderBook, newsScore, lab1h)
        val modelLabReport = lab15
        val feedbackMetrics = mapOf(
            "TREND" to feedback.modelMetrics("15m"),
            "MOMENTUM" to feedback.modelMetrics("15m"),
            "MEAN_REVERSION" to feedback.modelMetrics("15m"),
            "BREAKOUT" to feedback.modelMetrics("15m"),
            "VOLATILITY" to feedback.modelMetrics("15m")
        )
        val lifecycle = HsModelLifecycle.evaluate(modelLabReport, feedbackMetrics)
        lifecycleStore.save(lifecycle)
        val modelWeights = HsModelWeightEngine.weights(modelLabReport, tf15.regime)
            .filterKeys { lifecycle.activeModels.isEmpty() || it in lifecycle.activeModels }

        val now = System.currentTimeMillis()
        val alignErr = HsTimeAlign.maxAlignErrorMs(candles5m, candles15m, candles1h)
        val quality = HsDataQualityEngine.evaluate(
            candle5m = candles5m.size,
            candle15m = candles15m.size,
            candle1h = candles1h.size,
            orderBookAgeMs = binanceOrderBook?.let { now - it.fetchedAt },
            polyLive = polyBooks.values.any { it.bids.isNotEmpty() && it.asks.isNotEmpty() },
            oracleLive = oracleLive,
            oracleAgeMs = if (oracleLive && oracleUpdatedAt > 0L) now - oracleUpdatedAt else null,
            config = cfg(),
            tfAlignErrorMs = if (alignErr == Long.MAX_VALUE) 0L else alignErr
        )
        if (!quality.liveTradeAllowed) {
            log("GATE    LIVE blocked: ${quality.blockReasons.joinToString("; ")}")
        }
        log("DATA    quality=${"%.2f".format(quality.score)} live=${quality.liveCount}/${quality.sources.size} safe=${quality.decisionSafe}")

        // 综合观测喂给贝叶斯粒子（加权：15m 主，5m/1h 辅）
        val tfWeights = dynamicTfWeights(tf5, tf15, tf1h)
        val oracleBias = if (oracleLive && markPrice > 0.0 && chainlinkPrice > 0.0) {
            ((chainlinkPrice - markPrice) / markPrice).coerceIn(-0.03, 0.03)
        } else 0.0
        val obs = (tf5.pHat * tfWeights[0] + tf15.pHat * tfWeights[1] + tf1h.pHat * tfWeights[2] + oracleBias * 0.35)
            .coerceIn(0.02, 0.98)
        if (oracleLive) log("ORACLE  chainlink=${"%.2f".format(chainlinkPrice)} mark=${"%.2f".format(markPrice)} bias=${"%+.4f".format(oracleBias)}")
        val conf = listOf(tf5, tf15, tf1h).map { (abs(it.pHat - 0.5) * 2) * (0.65 + it.modelHitRate * 0.35) }
            .average().coerceIn(0.2, 0.95)
        val field = particleFilter.update(obs, conf)
        log("PHAT    5m=${"%.3f".format(tf5.pHat)} 15m=${"%.3f".format(tf15.pHat)} 1h=${"%.3f".format(tf1h.pHat)} weights=${tfWeights.joinToString("/") { "%.2f".format(it) }}")
        log("BAYES   mean=${"%.3f".format(field.mean)} trigger=+${"%.1f".format(field.trigger)} ess=${"%.0f".format(field.effectiveSampleSize)}")

        data class Candidate(val tf: String, val phat: Double, val direction: BtcDirection, val edge: Double, val liquidity: Double, val spread: Double, val hit: Double, val brier: Double, val halfKelly: Double)
        fun candidate(tf: String, x: TimeframePhat): Candidate {
            val upEdge = x.edgeAsk; val downEdge = x.edgeBid
            val dir = if (upEdge >= downEdge) BtcDirection.UP else BtcDirection.DOWN
            val edge = max(upEdge, downEdge)
            val p = if (dir == BtcDirection.UP) x.pHat else 1.0 - x.pHat
            return Candidate(tf,p,dir,edge,x.liquidityScore,x.spread,x.modelHitRate,x.brierScore,x.halfKelly)
        }
        val candidates = listOf(candidate("5m",tf5), candidate("15m",tf15), candidate("1h",tf1h))
        val primaryCandidate = candidates.maxWithOrNull(compareBy<Candidate> { it.edge }.thenBy { it.liquidity }) ?: candidate("15m",tf15)
        val primary = primaryCandidate.direction
        val primaryPhat = primaryCandidate.phat
        appendHistory("5m", tf5.pHat); appendHistory("15m", tf15.pHat); appendHistory("1h", tf1h.pHat)
        val aggEdge = primaryCandidate.edge
        val opportunity = HsOpportunityEngine.evaluate(
            pHat = primaryCandidate.phat, netEdge = primaryCandidate.edge,
            liquidity = primaryCandidate.liquidity, spread = primaryCandidate.spread,
            modelHitRate = primaryCandidate.hit, brier = primaryCandidate.brier,
            dataQuality = quality.score, regime = if (primaryCandidate.tf == "5m") tf5.regime.name else if (primaryCandidate.tf == "1h") tf1h.regime.name else tf15.regime.name,
            drawdownPct = abs(maxDd),
            config = cfg(),
            liveTradeAllowed = quality.liveTradeAllowed
        )
        edgeHistory.addLast(aggEdge)
        while (edgeHistory.size > 60) edgeHistory.removeFirst()
        // 每 5 次评估把曲线历史落盘一次：重启后看板曲线不再从空白起步
        if (edgeHistory.size % 5 == 0) {
            runCatching { snapshotStore.saveCurveHistory(edgeHistory.toList(), phatHistory.mapValues { it.value.toList() }) }
        }

        val volatilityPct = candles15m.takeLast(14).let { rows ->
            if (rows.isEmpty() || rows.last().close <= 0.0) 0.0 else rows.map { it.high - it.low }.average() / rows.last().close
        }
        val sizing = HsOpportunitySizing.calculate(
            equityUsdt = balance,
            netEdge = aggEdge,
            halfKelly = primaryCandidate.halfKelly,
            liquidity = primaryCandidate.liquidity,
            volatilityPct = volatilityPct,
            drawdownPct = abs(maxDd) / 100.0,
            config = cfg(),
            opportunityMultiplier = opportunity.finalMultiplier
        )
        val shadowStats = shadow.stats()
        val attribution = HsAttributionEngine.shadow(shadow.recent(500))
        val snapshotSeed = listOf(
            candles5m.lastOrNull()?.openTime ?: 0L,
            candles15m.lastOrNull()?.openTime ?: 0L,
            candles1h.lastOrNull()?.openTime ?: 0L,
            markPrice, chainlinkPrice, tf5.pHat, tf15.pHat, tf1h.pHat,
            binanceOrderBook?.fetchedAt ?: 0L,
            polyBooks["5m"]?.bestBid ?: 0.0, polyBooks["5m"]?.bestAsk ?: 0.0,
            polyBooks["15m"]?.bestBid ?: 0.0, polyBooks["15m"]?.bestAsk ?: 0.0,
            polyBooks["1h"]?.bestBid ?: 0.0, polyBooks["1h"]?.bestAsk ?: 0.0
        ).joinToString("|")
        val snapshotId = "HS-${sha256(snapshotSeed)}"
        snapshotStore.append(HsSnapshotStore.Record(snapshotId, System.currentTimeMillis(), "BTCUSDT", primaryCandidate.tf, markPrice, primaryPhat, primary.name, if (primaryCandidate.tf == "5m") marketYesPrice5m else if (primaryCandidate.tf == "1h") marketYesPrice1h else marketYesPrice15m, if (primaryCandidate.tf == "5m") (polyBooks["5m"]?.bestBid ?: 0.0) else if (primaryCandidate.tf == "1h") (polyBooks["1h"]?.bestBid ?: 0.0) else (polyBooks["15m"]?.bestBid ?: 0.0), if (primaryCandidate.tf == "5m") (polyBooks["5m"]?.bestAsk ?: 0.0) else if (primaryCandidate.tf == "1h") (polyBooks["1h"]?.bestAsk ?: 0.0) else (polyBooks["15m"]?.bestAsk ?: 0.0), aggEdge, opportunity.score, quality.score, if (primaryCandidate.tf == "5m") tf5.regime.name else if (primaryCandidate.tf == "1h") tf1h.regime.name else tf15.regime.name, modelLabReport.version))
        log("LAB     ${modelLabReport.version} holdout=${modelLabReport.holdoutSamples} models=${modelLabReport.models.size}")
        val fusionMetrics = fusionFeedback.metrics(primaryCandidate.tf)
        val runtimeFusionWeightsBase = fusionFeedback.weights(primaryCandidate.tf)
        val driftControl = RegimeDriftControlEngine.evaluate(fusionMetrics, primaryCandidate.regime)
        val primaryCandles = if (primaryCandidate.tf == "5m") candles5m else if (primaryCandidate.tf == "1h") candles1h else candles15m
        val componentMetrics = fusionFeedback.componentMetrics(primaryCandidate.tf)
        val driftAttribution = FusionDriftAttributionEngine.evaluate(
            primaryCandles, fusionMetrics, componentMetrics, primaryCandidate.regime.name, tf15.regime.name
        )
        val attributionWeights = FusionDriftAttributionEngine.adjustWeights(runtimeFusionWeightsBase, driftAttribution)
        val runtimeFusionWeights = RegimeDriftControlEngine.adjustWeights(attributionWeights, driftControl)
        log("FUSION  ${primaryCandidate.tf} samples=${fusionMetrics.samples} weights=${"%.2f/%.2f/%.2f".format(runtimeFusionWeights.model, runtimeFusionWeights.factor, runtimeFusionWeights.strategy)} brier=${"%.4f".format(fusionMetrics.recentBrier)} drift=${driftControl.state.name}")
        log("ATTRIB  ${driftAttribution.reason}")
        log("MODEL   pool=${HsModelPool.VERSION} 5m/15m/1h independently trained; runtime fusion enabled")
        log("SHADOW  closed=${shadowStats.closed} hit=${"%.1f%%".format(shadowStats.hitRate * 100)}")
        log("SIZE    ${"%.2f%%".format(sizing.riskFraction * 100)} / ${"%.2f".format(sizing.notionalUsdt)} USDT")
        log("EDGE    aggregate=${"%+.1f%%".format(aggEdge * 100)} primary=$primary")
        log("SYNC    snapshot emitted in ${System.currentTimeMillis() - t0}ms")

        return HsPredictionSnapshot(
            updatedAt = System.currentTimeMillis(),
            markPrice = markPrice,
            chainlinkPrice = chainlinkPrice,
            tf5m = safeTf(tf5.copy(trigger = field.trigger * 0.9), quality.decisionSafe, quality.liveTradeAllowed),
            tf15m = safeTf(tf15.copy(trigger = field.trigger), quality.decisionSafe, quality.liveTradeAllowed),
            tf1h = safeTf(tf1h.copy(trigger = field.trigger * 0.85), quality.decisionSafe, quality.liveTradeAllowed),
            balance = balance,
            available = available,
            openNotional = openNotional,
            todayPnl = todayPnl,
            pnl30d = pnl30d,
            maxDrawdownPct = maxDd,
            bayesTrigger = field.trigger,
            bayesMean = field.mean,
            bayesStd = field.std,
            particleCount = field.particles.size,
            particles = field.particles,
            aggregateEdge = aggEdge,
            primaryDirection = primary,
            primaryPhat = primaryPhat,
            newsScore = newsScore,
            systemsOnline = (dataMode == "LIVE" || dataMode == "LIVE_ACCOUNT") && quality.decisionSafe,
            apiLiveSamples = "${quality.liveCount}/${quality.sources.size}",
            engineLog = logs.toList().takeLast(12),
            dataMode = dataMode,
            dataFreshnessMs = binanceOrderBook?.let { System.currentTimeMillis() - it.fetchedAt } ?: 0L,
            binanceDepthBid = binanceOrderBook?.bidDepth ?: 0.0,
            binanceDepthAsk = binanceOrderBook?.askDepth ?: 0.0,
            binanceDepthImbalance = binanceOrderBook?.imbalance ?: 0.0,
            binanceMicroPrice = binanceOrderBook?.microPrice ?: 0.0,
            binanceSpread = binanceOrderBook?.spread ?: 0.0,
            polymarketBookLive = polyBooks.values.any { it.bids.isNotEmpty() && it.asks.isNotEmpty() },
            oracleLive = oracleLive,
            oracleUpdatedAt = oracleUpdatedAt,
            phatHistory = phatHistory.mapValues { it.value.toList() },
            edgeHistory = edgeHistory.toList(),
            opportunityScore = opportunity.score,
            dataQualityScore = quality.score,
            fusion = tf15.fusion,
            fusionFeedbackMetrics = fusionMetrics,
            fusionRuntimeWeights = runtimeFusionWeights,
            regimeDrift = driftControl,
            driftAttribution = driftAttribution,
            dataQuality = quality,
            modelLab = modelLabReport,
            modelLabByTimeframe = mapOf("5m" to lab5, "15m" to lab15, "1h" to lab1h),
            modelWeights = modelWeights,
            shadowStats = shadowStats,
            positionSizing = sizing,
            snapshotHistory = snapshotStore.recent(100),
            polymarketPanels = polyMarkets.mapValues { (tf, market) ->
                HsPolymarketPanel(tf, market, polyBooks[tf]?.bids.orEmpty(), polyBooks[tf]?.asks.orEmpty(), polyNoBooks[tf]?.bids.orEmpty(), polyNoBooks[tf]?.asks.orEmpty(), System.currentTimeMillis())
            },
            decisionExplanation = HsDecisionExplanation(
                decision = opportunity.label,
                direction = primary.name,
                headline = "Net Edge ${"%+.2f%%".format(aggEdge * 100)} · Opportunity ${"%.0f%%".format(opportunity.score * 100)}",
                reasons = opportunity.reasons,
                risks = opportunity.risks,
                metrics = listOf(
                    "p_hat" to "${"%.1f%%".format(primaryPhat * 100)}",
                    "net edge" to "${"%+.2f%%".format(aggEdge * 100)}",
                    "liquidity" to "${"%.0f%%".format(max(tf5.liquidityScore, max(tf15.liquidityScore, tf1h.liquidityScore)) * 100)}",
                    "data quality" to "${"%.0f%%".format(quality.score * 100)}",
                    "multiplier" to "${"%.2f".format(opportunity.finalMultiplier)}x"
                )
            )
        )
    }

    private fun fusionFactorWeights(): Map<String, Double> =
        runCatching { factorWeightStore?.load()?.mapValues { it.value.weight } ?: emptyMap() }.getOrDefault(emptyMap())

    private fun strategyConfidence(consensus: com.caifenxi.app.domain.btc.BtcConsensus?): Double =
        consensus?.consensusStrength?.coerceIn(0.0, 1.0) ?: 0.0

    private fun buildTf(
        tf: String,
        candles: List<BtcCandle>,
        deriv: DerivativesFeatures?,
        marketYes: Double,
        perf: Map<String, DynamicWeightEngine.PlanPerf>,
        polyBook: PolyOrderBook?,
        polyNoBook: PolyOrderBook?,
        binanceBook: BinanceOrderBookRepository.Snapshot?,
        newsScore: Double,
        modelLabReport: HsModelLab.Report
    ): TimeframePhat {
        if (candles.size < 40) {
            return emptyTf(tf, marketYes)
        }
        val (signals, consensus) = planEngine.evaluate(candles, deriv, perf, factorRuntimeWeights = fusionFactorWeights())
        val planP = when (consensus?.direction) {
            BtcDirection.UP -> consensus.probability
            BtcDirection.DOWN -> 1.0 - consensus.probability
            else -> 0.50
        }.coerceIn(0.05, 0.95)
        val ml = mlFor(tf).fitAndPredict(candles)
        val modelPool = poolFor(tf).fit(candles)
        val poolProbability = if (modelPool.members.isEmpty()) ml.probability else modelPool.probability
        val regimeForEnsemble = consensus?.regime ?: MarketRegime.RANGE
        val ensemble = modelLab.ensembleProbability(candles, candles.lastIndex, regimeForEnsemble, HsModelWeightEngine.weights(modelLabReport, regimeForEnsemble))
        val brier = feedback.metrics(tf).first
        val liveHit = feedback.metrics(tf).second
        val factorSnapshot = QuantFactorEngine.calculate(candles, deriv, "BTCUSDT", tf)
        val modelProbability = (0.60 * poolProbability + 0.40 * ensemble).coerceIn(0.03, 0.97)
        val modelConfidence = (0.60 * modelPool.confidence + 0.40 * (1.0 - brier.coerceIn(0.0, 1.0) * 2.0)).coerceIn(0.15, 1.0)
        val fusionMetrics = fusionFeedback.metrics(tf)
        val baseFusionWeights = fusionFeedback.weights(tf)
        val driftControl = RegimeDriftControlEngine.evaluate(fusionMetrics, regimeForEnsemble)
        val componentMetrics = fusionFeedback.componentMetrics(tf)
        val driftAttribution = FusionDriftAttributionEngine.evaluate(candles, fusionMetrics, componentMetrics, regimeForEnsemble.name, null)
        val attributionWeights = FusionDriftAttributionEngine.adjustWeights(baseFusionWeights, driftAttribution)
        val fusionWeights = RegimeDriftControlEngine.adjustWeights(attributionWeights, driftControl)
        val fusion = ModelFactorStrategyFusionEngine.fuse(
            modelProbability = modelProbability,
            modelConfidence = modelConfidence,
            modelDisagreement = modelPool.disagreement,
            factor = factorSnapshot,
            factorWeights = fusionFactorWeights(),
            strategyProbability = planP,
            strategyConfidence = (0.45 + 0.55 * strategyConfidence(consensus)).coerceIn(0.25, 1.0),
            regime = regimeForEnsemble,
            modelWeight = fusionWeights.model,
            factorWeight = fusionWeights.factor,
            strategyWeight = fusionWeights.strategy
        )
        var pHat = fusion.probability
        val bookImbalance = polyBook?.let { depthImbalance(it) } ?: 0.0
        val btcImbalance = binanceBook?.imbalance ?: 0.0
        pHat += (bookImbalance * 0.025) + (btcImbalance * 0.02)
        pHat += 0.025 * newsScore.coerceIn(-1.0, 1.0)
        pHat = pHat.coerceIn(0.03, 0.97)
        val calibrated = BtcProbabilityCalibrator.calibrate(
            baseProbability = pHat,
            direction = if (pHat >= 0.5) BtcDirection.UP else BtcDirection.DOWN,
            signals = signals
        )
        pHat = (0.5 + (calibrated - 0.5) * 0.90).coerceIn(0.03, 0.97)

        val bookAsk = polyBook?.bestAsk
        val bookBid = polyBook?.bestBid
        val hasExecutableBook = polyBook != null && (bookAsk != null || bookBid != null)
        val executableAsk = (bookAsk ?: 0.50).coerceIn(0.01, 0.99)
        val executableBid = bookBid?.coerceIn(0.01, 0.99)
        val depthQuote = polyBook?.asks?.take(5)?.sumOf { it.price * it.size } ?: 0.0
        val costs = HsCostEngine.estimate(executableAsk, executableBid, depthQuote, feeRate = cfg().feeRate, latencySec = cfg().latencySec)
        val edgeAsk = if (hasExecutableBook) pHat - executableAsk else 0.0
        val noAsk = polyNoBook?.bestAsk ?: executableBid?.let { 1.0 - it }
        val edgeBid = if (hasExecutableBook && noAsk != null) (1.0 - pHat) - noAsk else 0.0
        val netAsk = if (hasExecutableBook) edgeAsk - costs.total else 0.0
        val netBid = if (hasExecutableBook && noAsk != null) edgeBid - costs.total else 0.0
        val spread = polyBook?.spread ?: 0.0
        fun kellyFor(probability: Double, price: Double?): Double {
            if (!hasExecutableBook || price == null || price <= 0.0 || price >= 1.0) return 0.0
            val odds = ((1.0 - price) / price).coerceAtLeast(0.0)
            return if (odds > 0.0) ((odds * probability - (1.0 - probability)) / odds).coerceIn(0.0, 1.0) else 0.0
        }
        val kellyYes = kellyFor(pHat, executableAsk)
        val kellyNo = kellyFor(1.0 - pHat, noAsk)
        val kelly = max(kellyYes, kellyNo)
        val halfKelly = kelly * 0.5
        val bucket = (halfKelly * 100.0).coerceIn(0.0, 40.0)
        val atrProxy = candles.takeLast(14).map { it.high - it.low }.average() / candles.last().close
        val alpha = if (hasExecutableBook) max(netAsk, netBid) * (1.0 + atrProxy * 20.0) else 0.0
        val liquidity = polyBook?.let { liquidityScore(it) } ?: 0.0
        val bestNetEdge = max(netAsk, netBid)
        val confidence = abs(pHat - 0.5) * 2.0
        val multiplier = if (hasExecutableBook && bestNetEdge > 0.0) {
            (0.5 + bestNetEdge * 10.0) * (0.65 + liquidity * 0.35) * (0.75 + confidence * 0.5)
        } else 0.0
        val action = when {
            !hasExecutableBook -> "NO_MARKET_DATA"
            bestNetEdge >= 0.05 && liquidity >= 0.30 -> if (netAsk >= netBid) "BUY_YES" else "BUY_NO"
            bestNetEdge > 0.0 -> "WATCH"
            else -> "NO_TRADE"
        }.let { if (it.startsWith("BUY")) it else it }
        val polyBidDepth = polyBook?.bids?.take(10)?.sumOf { it.size } ?: 0.0
        val polyAskDepth = polyBook?.asks?.take(10)?.sumOf { it.size } ?: 0.0
        fusionMemory[tf] = FusionPredictionMemory(
            candles.last().openTime, pHat, fusion.modelComponent, fusion.factorComponent, fusion.strategyComponent, fusion.disagreement
        )
        memory[tf] = PredictionMemory(candles.last().openTime, candles.last().close, pHat)
        shadow.observe(
            id = "$tf|${candles.last().openTime}",
            timeframe = tf,
            barId = candles.last().openTime,
            entry = candles.last().close,
            direction = if (pHat >= 0.5) BtcDirection.UP else BtcDirection.DOWN,
            probability = if (pHat >= 0.5) pHat else 1.0 - pHat,
            modelVersion = ml.modelVersion
        )

        return TimeframePhat(
            timeframe = tf,
            pHat = pHat,
            edgeAsk = edgeAsk,
            edgeBid = edgeBid,
            kelly = kelly,
            halfKelly = halfKelly,
            bucket = bucket,
            spread = spread,
            alpha = alpha,
            depthBid = polyBidDepth,
            depthAsk = polyAskDepth,
            trigger = 0.0,
            regime = consensus?.regime ?: MarketRegime.RANGE,
            mlProbability = ml.probability,
            mlSamples = ml.samples,
            mlModelVersion = ml.modelVersion,
            brierScore = brier,
            modelHitRate = if (liveHit > 0.0) liveHit else ml.hitRate,
            marketYes = if (hasExecutableBook) executableAsk else marketYes,
            bestBid = executableBid,
            bestAsk = bookAsk,
            netEdge = bestNetEdge,
            costEstimate = costs.total,
            liquidityScore = liquidity,
            positionMultiplier = multiplier.coerceIn(0.0, 2.0),
            action = action,
            opportunityScore = HsOpportunityEngine.evaluate(
                pHat = if (pHat >= 0.5) pHat else 1.0 - pHat,
                netEdge = bestNetEdge,
                liquidity = liquidity,
                spread = spread,
                modelHitRate = if (liveHit > 0.0) liveHit else ml.hitRate,
                brier = brier,
                dataQuality = 1.0,
                regime = (consensus?.regime ?: MarketRegime.RANGE).name,
                drawdownPct = 0.0
            ).score,
            dataQualityScore = 1.0,
            fusion = fusion
        )
    }

    private fun safeTf(tf: TimeframePhat, decisionSafe: Boolean, liveTradeAllowed: Boolean = decisionSafe): TimeframePhat {
        // 非买入动作不拦截；LIVE 交易未放行时强制阻断买入
        if (!tf.action.startsWith("BUY")) return tf
        if (liveTradeAllowed && decisionSafe) return tf
        return tf.copy(action = "BLOCKED_DATA", positionMultiplier = 0.0)
    }

    private fun appendHistory(tf: String, p: Double) {
        val q = phatHistory.getOrPut(tf) { ArrayDeque<Double>(60) }
        q.addLast(p.coerceIn(0.0, 1.0))
        while (q.size > 60) q.removeFirst()
    }

    private fun consensusStrength(consensus: com.caifenxi.app.domain.btc.BtcConsensus?): Double =
        consensus?.consensusStrength?.coerceIn(0.0, 1.0) ?: 0.0

    private fun dynamicTfWeights(a: TimeframePhat, b: TimeframePhat, c: TimeframePhat): List<Double> {
        val scores = listOf(a, b, c).map { tf ->
            val quality = (0.5 + tf.modelHitRate * 0.5) * (1.0 - tf.brierScore.coerceIn(0.0, 1.0))
            val edge = (abs(tf.netEdge) * 4.0).coerceIn(0.0, 0.35)
            (quality + edge).coerceAtLeast(0.05)
        }
        val sum = scores.sum().coerceAtLeast(1e-9)
        return scores.map { it / sum }
    }

    private fun depthImbalance(book: PolyOrderBook): Double {
        val bid = book.bids.take(10).sumOf { it.size }
        val ask = book.asks.take(10).sumOf { it.size }
        return if (bid + ask <= 0.0) 0.0 else (bid - ask) / (bid + ask)
    }

    private fun liquidityScore(book: PolyOrderBook): Double {
        val quote = book.bids.take(10).sumOf { it.price * it.size } + book.asks.take(10).sumOf { it.price * it.size }
        return (quote / 500.0).coerceIn(0.0, 1.0)
    }

    private fun recordFusionFeedback(tf: String, candles: List<BtcCandle>) {
        val last = candles.lastOrNull() ?: return
        val prev = fusionMemory[tf] ?: return
        if (last.openTime <= prev.barId || last.close <= 0.0) return
        val previousClose = memory[tf]?.close ?: last.close
        fusionFeedback.observe(
            FusionFeedbackStore.Record(
                id = "FUSION-$tf-${prev.barId}", timeframe = tf, predictedUp = prev.pUp,
                actualUp = last.close > previousClose,
                modelComponent = prev.model, factorComponent = prev.factor,
                strategyComponent = prev.strategy, disagreement = prev.disagreement, at = last.openTime
            )
        )
        fusionMemory.remove(tf)
    }

    private fun recordFeedback(tf: String, candles: List<BtcCandle>) {
        val last = candles.lastOrNull() ?: return
        val prev = memory[tf]
        if (prev != null && last.openTime > prev.barId && last.close > 0.0 && prev.close > 0.0) {
            feedback.observe(tf, prev.pUp, last.close > prev.close)
            shadow.settle("$tf|${prev.barId}", last.high, last.low, last.close)
        }
    }

    private fun emptyTf(tf: String, marketYes: Double) = TimeframePhat(
        timeframe = tf,
        pHat = 0.5,
        edgeAsk = 0.5 - marketYes,
        edgeBid = marketYes - 0.5,
        kelly = 0.0,
        halfKelly = 0.0,
        bucket = 0.0,
        spread = 0.02,
        alpha = 0.0,
        depthBid = 0.0,
        depthAsk = 0.0,
        trigger = 0.0,
        regime = MarketRegime.RANGE
    )

    private fun sha256(value: String): String {
        val bytes = java.security.MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }.take(20)
    }

    private fun log(msg: String) {
        val ts = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US)
            .format(java.util.Date())
        logs.addLast("$ts  $msg")
        while (logs.size > 24) logs.removeFirst()
    }
}
