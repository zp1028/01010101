package com.caifenxi.app.domain.btc

import com.caifenxi.app.domain.btc.futures.TakeProfitLevel
import kotlin.math.max

/** Converts research consensus into a typed Perp signal. It does not place orders. */
class BtcSignalFactory {

    /**
     * Original signal builder for consensus-based perp entry.
     */
    fun buildPerpSignal(
        symbol: String,
        candles: List<BtcCandle>,
        plans: List<BtcPlanSignal>,
        consensus: BtcConsensus,
        requestedPositionSize: Double,
        leverageCap: Int = 3,
        stopLossAtrMult: Double = 1.5,
        takeProfitAtrMult: Double = 3.0
    ): TradingSignal.ContractSignal? {
        if (candles.isEmpty() || consensus.direction == BtcDirection.FLAT) return null
        val last = candles.last()
        val atr = calcATR(candles, 14).coerceAtLeast(last.close * 0.001)
        val stopDistance = atr * stopLossAtrMult
        val targetDistance = atr * takeProfitAtrMult
        val entry = last.close
        val sl = if (consensus.direction == BtcDirection.UP) entry - stopDistance else entry + stopDistance
        val tp = if (consensus.direction == BtcDirection.UP) entry + targetDistance else entry - targetDistance
        return TradingSignal.ContractSignal(
            planId = plans.maxByOrNull { it.contribution * it.confidence }?.planId ?: "BTC-CONSENSUS",
            barId = last.openTime,
            symbol = symbol,
            direction = consensus.direction,
            probability = consensus.probability,
            expectedMovePct = consensus.expectedMovePct,
            entry = entry,
            stopLoss = max(0.0, sl),
            takeProfit = max(0.0, tp),
            horizonBars = 12,
            positionSize = requestedPositionSize,
            leverageCap = leverageCap,
            confidence = consensus.probability,
            reasonPlanIds = plans.filter { it.direction == consensus.direction }.sortedByDescending { it.contribution }.take(5).map { it.planId },
            factorScore = plans.filter { it.direction == consensus.direction }.sortedByDescending { kotlin.math.abs(it.contribution) }.firstOrNull()?.factorScore ?: 0.0,
            factorIds = plans.filter { it.direction == consensus.direction }.flatMap { it.factorIds }.distinct().take(8)
        )
    }

    /**
     * Build a multi-level take profit ladder for futures quant.
     * 50% at 2:1 R:R, 50% at 3:1 R:R (let profits run).
     */
    fun buildMultiTakeProfit(
        entry: Double,
        atr: Double,
        isLong: Boolean,
        tpMult: Double = 3.0
    ): List<TakeProfitLevel> {
        val tp1Dist = atr * tpMult * 0.6
        val tp2Dist = atr * tpMult
        return listOf(
            TakeProfitLevel(
                price = if (isLong) entry + tp1Dist else entry - tp1Dist,
                qtyFraction = 0.5
            ),
            TakeProfitLevel(
                price = if (isLong) entry + tp2Dist else entry - tp2Dist,
                qtyFraction = 0.5
            )
        )
    }

    /**
     * Calculate trailing stop delta (in bps) from percentage.
     * e.g. 3% → 300 bps for Binance TRAILING_STOP_MARKET.
     */
    fun trailingStopToBps(trailingPct: Double): Double = trailingPct * 100.0

    /**
     * Calculate simplified liquidation price for a position.
     * For ISOLATED margin: liqPrice ≈ entry ± (margin / qty)
     */
    fun estimateLiquidationPrice(
        entry: Double,
        margin: Double,
        qty: Double,
        isLong: Boolean
    ): Double {
        if (qty <= 0.0) return 0.0
        val liqDist = margin / qty
        return if (isLong) max(0.0, entry - liqDist) else entry + liqDist
    }

    /**
     * Dynamically select leverage based on ATR percentage.
     * High volatility → reduce leverage; low volatility → can increase.
     */
    fun selectLeverage(
        baseLeverage: Int,
        atrPct: Double,
        maxLeverage: Int = 3
    ): Int = when {
        atrPct > 0.015 -> max(1, baseLeverage - 1)
        atrPct > 0.012 -> max(1, baseLeverage - 1)
        atrPct < 0.004 -> minOf(baseLeverage + 1, maxLeverage)
        else -> baseLeverage
    }.coerceAtMost(maxLeverage)

    /**
     * Shared ATR calculation.
     */
    private fun calcATR(candles: List<BtcCandle>, period: Int): Double {
        if (candles.size < 2) return 0.0
        val trs = candles.zipWithNext().map { (prev, curr) ->
            maxOf(
                curr.high - curr.low,
                maxOf(kotlin.math.abs(curr.high - prev.close), kotlin.math.abs(curr.low - prev.close))
            )
        }
        return trs.takeLast(period).average()
    }
}
