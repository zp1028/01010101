from __future__ import annotations
import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PYROOT = ROOT / 'app' / 'src' / 'main' / 'python'
MAIN = PYROOT / 'app' / 'main.py'

required = {
    '/api/v1/runtime/status', '/api/v1/runtime/ready', '/api/v1/datahub/snapshot',
    '/api/v1/strategies', '/api/v1/backtest/run', '/api/v1/quant/snapshot',
    '/api/v1/risk/evaluate', '/api/v1/paper/orders', '/api/v1/research/overview',
    '/api/v1/diagnostics', '/health'
}

def route_paths(tree):
    paths = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for dec in node.decorator_list:
                if isinstance(dec, ast.Call) and isinstance(dec.func, ast.Attribute):
                    if dec.func.attr in {'get','post','put','delete','patch'} and dec.args:
                        if isinstance(dec.args[0], ast.Constant) and isinstance(dec.args[0].value, str):
                            paths.add(dec.args[0].value)
    return paths

files = list(PYROOT.rglob('*.py'))
for f in files:
    ast.parse(f.read_text(encoding='utf-8'), filename=str(f))

main_tree = ast.parse(MAIN.read_text(encoding='utf-8'), filename=str(MAIN))
paths = route_paths(main_tree)
for f in files:
    paths |= route_paths(ast.parse(f.read_text(encoding='utf-8'), filename=str(f)))
missing = sorted(required - paths)
if missing:
    raise SystemExit('SMOKE_FAIL missing routes: ' + ', '.join(missing))

idx = ROOT / 'app' / 'src' / 'main' / 'assets' / 'static' / 'index.html'
html = idx.read_text(encoding='utf-8')
for label in ['Command', 'Market', 'Quant', 'Strategy', 'Backtest', 'Research']:
    if label not in html:
        raise SystemExit(f'SMOKE_FAIL missing UI section: {label}')

print(f'SMOKE_OK python_files={len(files)} routes={len(paths)} ui_sections=6')
