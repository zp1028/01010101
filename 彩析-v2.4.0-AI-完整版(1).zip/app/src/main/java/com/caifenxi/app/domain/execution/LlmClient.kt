package com.caifenxi.app.domain.execution

import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import kotlin.coroutines.resume

/**
 * 多模态 LLM 客户端
 * 支持 OpenAI (GPT-4o/4o-mini)、Anthropic (Claude)、Google (Gemini)
 */
class LlmClient(private val config: LlmConfig) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    val isReady: Boolean
        get() = config.apiKey.isNotBlank() && config.model.isNotBlank()

    /**
     * 发送多模态请求（截图 + 文本）
     */
    suspend fun chat(prompt: LlmPrompt): LlmResponse = suspendCancellableCoroutine { cont ->
        val startTime = System.currentTimeMillis()

        when (config.provider) {
            LlmProvider.OPENAI -> callOpenAI(prompt, cont, startTime)
            LlmProvider.ANTHROPIC -> callAnthropic(prompt, cont, startTime)
            LlmProvider.GOOGLE -> callGoogle(prompt, cont, startTime)
        }
    }

    private fun callOpenAI(
        prompt: LlmPrompt,
        cont: kotlin.coroutines.Continuation<LlmResponse>,
        startTime: Long
    ) {
        val messages = JSONArray().apply {
            put(JSONObject().apply {
                put("role", "system")
                put("content", prompt.system)
            })
            put(JSONObject().apply {
                put("role", "user")
                put("content", JSONArray().apply {
                    put(JSONObject().apply {
                        put("type", "image_url")
                        put("image_url", JSONObject().apply {
                            put("url", "data:image/jpeg;base64,${prompt.imageBase64}")
                            put("detail", config.imageDetail)
                        })
                    })
                    put(JSONObject().apply {
                        put("type", "text")
                        put("text", prompt.userText)
                    })
                })
            })
        }

        val body = JSONObject().apply {
            put("model", config.model)
            put("messages", messages)
            put("max_tokens", config.maxTokens)
            put("temperature", config.temperature)
            put("response_format", JSONObject().apply {
                put("type", "json_object")
            })
        }

        val request = Request.Builder()
            .url("${config.baseUrl}/chat/completions")
            .header("Authorization", "Bearer ${config.apiKey}")
            .header("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: java.io.IOException) {
                cont.resume(LlmResponse.Error("网络错误: ${e.message}", System.currentTimeMillis() - startTime))
            }
            override fun onResponse(call: Call, response: Response) {
                val text = response.body?.string() ?: "{}"
                val duration = System.currentTimeMillis() - startTime
                try {
                    val content = JSONObject(text)
                        .getJSONArray("choices")
                        .getJSONObject(0)
                        .getJSONObject("message")
                        .getString("content")
                    cont.resume(LlmResponse.Success(content, duration))
                } catch (e: Exception) {
                    cont.resume(LlmResponse.Error("解析失败: ${e.message}", duration))
                }
            }
        })
    }

    private fun callAnthropic(
        prompt: LlmPrompt,
        cont: kotlin.coroutines.Continuation<LlmResponse>,
        startTime: Long
    ) {
        val body = JSONObject().apply {
            put("model", config.model)
            put("max_tokens", config.maxTokens)
            put("temperature", config.temperature)
            put("messages", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", JSONArray().apply {
                        put(JSONObject().apply {
                            put("type", "image")
                            put("source", JSONObject().apply {
                                put("type", "base64")
                                put("media_type", "image/jpeg")
                                put("data", prompt.imageBase64)
                            })
                        })
                        put(JSONObject().apply {
                            put("type", "text")
                            put("text", "${prompt.system}

${prompt.userText}")
                        })
                    })
                })
            })
        }

        val request = Request.Builder()
            .url("${config.baseUrl}/messages")
            .header("x-api-key", config.apiKey)
            .header("anthropic-version", "2023-06-01")
            .header("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: java.io.IOException) {
                cont.resume(LlmResponse.Error("网络错误: ${e.message}", System.currentTimeMillis() - startTime))
            }
            override fun onResponse(call: Call, response: Response) {
                val text = response.body?.string() ?: "{}"
                val duration = System.currentTimeMillis() - startTime
                try {
                    val content = JSONObject(text)
                        .getJSONArray("content")
                        .getJSONObject(0)
                        .getString("text")
                    cont.resume(LlmResponse.Success(content, duration))
                } catch (e: Exception) {
                    cont.resume(LlmResponse.Error("解析失败: ${e.message}", duration))
                }
            }
        })
    }

    private fun callGoogle(
        prompt: LlmPrompt,
        cont: kotlin.coroutines.Continuation<LlmResponse>,
        startTime: Long
    ) {
        // Google Gemini API 实现
        val body = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("inlineData", JSONObject().apply {
                                put("mimeType", "image/jpeg")
                                put("data", prompt.imageBase64)
                            })
                        })
                        put(JSONObject().apply {
                            put("text", "${prompt.system}

${prompt.userText}")
                        })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("maxOutputTokens", config.maxTokens)
                put("temperature", config.temperature)
            })
        }

        val request = Request.Builder()
            .url("${config.baseUrl}/models/${config.model}:generateContent?key=${config.apiKey}")
            .header("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: java.io.IOException) {
                cont.resume(LlmResponse.Error("网络错误: ${e.message}", System.currentTimeMillis() - startTime))
            }
            override fun onResponse(call: Call, response: Response) {
                val text = response.body?.string() ?: "{}"
                val duration = System.currentTimeMillis() - startTime
                try {
                    val content = JSONObject(text)
                        .getJSONArray("candidates")
                        .getJSONObject(0)
                        .getJSONObject("content")
                        .getJSONArray("parts")
                        .getJSONObject(0)
                        .getString("text")
                    cont.resume(LlmResponse.Success(content, duration))
                } catch (e: Exception) {
                    cont.resume(LlmResponse.Error("解析失败: ${e.message}", duration))
                }
            }
        })
    }

    data class LlmConfig(
        val provider: LlmProvider = LlmProvider.OPENAI,
        val baseUrl: String = "https://api.openai.com/v1",
        val apiKey: String = "",
        val model: String = "gpt-4o-mini",
        val maxTokens: Int = 512,
        val temperature: Double = 0.1,
        val imageDetail: String = "low"
    )

    enum class LlmProvider { OPENAI, ANTHROPIC, GOOGLE }
}

sealed class LlmResponse {
    data class Success(val content: String, val durationMs: Long) : LlmResponse()
    data class Error(val message: String, val durationMs: Long) : LlmResponse()
}

data class LlmPrompt(
    val system: String,
    val userText: String,
    val imageBase64: String
)
