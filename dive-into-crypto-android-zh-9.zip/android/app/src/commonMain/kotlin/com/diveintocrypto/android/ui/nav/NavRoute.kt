package com.diveintocrypto.android.ui.nav

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Article
import androidx.compose.material.icons.automirrored.rounded.Article
import androidx.compose.material.icons.outlined.AddAlert
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.PieChart
import androidx.compose.material.icons.outlined.QueryStats
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.rounded.AddAlert
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.PieChart
import androidx.compose.material.icons.rounded.QueryStats
import androidx.compose.material.icons.rounded.Search
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * 8 routes — paper-trading bindings stripped; each screen now consumes real
 * Binance public APIs. `inBottomBar = true` for the 4 primary
 * destinations; the rest live behind the "More" overflow sheet.
 *
 * `slug` is the internal NavController route key for each destination;
 * `label` is the user-facing display copy.
 */
enum class NavRoute(
    val slug: String,
    val label: String,
    val iconOutlined: ImageVector,
    val iconFilled: ImageVector,
    val inBottomBar: Boolean,
) {
    PANEL("panel", "面板", Icons.Outlined.Dashboard, Icons.Rounded.Dashboard, inBottomBar = true),
    SCANNER("scanner", "扫描", Icons.Outlined.Search, Icons.Rounded.Search, inBottomBar = true),
    POSITIONS("positions", "OI · L/S", Icons.Outlined.PieChart, Icons.Rounded.PieChart, inBottomBar = true),
    SIGNALS("signals", "信号", Icons.Outlined.Notifications, Icons.Rounded.Notifications, inBottomBar = true),
    ALERTS("alerts", "警报", Icons.Outlined.AddAlert, Icons.Rounded.AddAlert, inBottomBar = false),
    PORTFOLIO("portfolio", "投资组合", Icons.Outlined.AccountBalanceWallet, Icons.Rounded.AccountBalanceWallet, inBottomBar = false),
    PERFORMANCE("performance", "排行榜", Icons.Outlined.QueryStats, Icons.Rounded.QueryStats, inBottomBar = false),
    LOGS("logs", "网络日志", Icons.AutoMirrored.Outlined.Article, Icons.AutoMirrored.Rounded.Article, inBottomBar = false),
    APPEARANCE("appearance", "外观", Icons.Outlined.Palette, Icons.Rounded.Palette, inBottomBar = false),
    SETTINGS("settings", "设置", Icons.Outlined.Info, Icons.Rounded.Info, inBottomBar = false);

    companion object {
        val Default = SCANNER
        val BottomBarRoutes: List<NavRoute> = values().filter { it.inBottomBar }
        val OverflowRoutes: List<NavRoute> = values().filter { !it.inBottomBar }
    }
}
