package com.caifenxi.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.caifenxi.app.ui.ExecutorViewModel
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.theme.CaiTokens

@Composable
fun ExecutorControlScreen(vm: ExecutorViewModel = viewModel()) {
    val executorStatus by vm.executorStatus.collectAsState()
    val currentTask by vm.currentTask.collectAsState()
    val executorStats by vm.executorStats.collectAsState()
    
    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = CaiTokens.ScreenHPadding, vertical = CaiTokens.S16)
    ) {
        Text("执行器控制中心", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(CaiTokens.S16))
        
        // 执行状态卡片
        GlobalCard {
            Text("执行状态", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(CaiTokens.S8))
            
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("当前状态", fontWeight = FontWeight.SemiBold)
                    Text(
                        when (executorStatus) {
                            ExecutorViewModel.ExecutorStatus.IDLE -> "空闲"
                            ExecutorViewModel.ExecutorStatus.RUNNING -> "运行中"
                            ExecutorViewModel.ExecutorStatus.COMPLETED -> "已完成"
                            ExecutorViewModel.ExecutorStatus.FAILED -> "失败"
                            ExecutorViewModel.ExecutorStatus.CANCELLED -> "已取消"
                        },
                        color = when (executorStatus) {
                            ExecutorViewModel.ExecutorStatus.IDLE -> MaterialTheme.colorScheme.onSurfaceVariant
                            ExecutorViewModel.ExecutorStatus.RUNNING -> MaterialTheme.colorScheme.secondary
                            ExecutorViewModel.ExecutorStatus.COMPLETED -> MaterialTheme.colorScheme.primary
                            ExecutorViewModel.ExecutorStatus.FAILED -> MaterialTheme.colorScheme.error
                            ExecutorViewModel.ExecutorStatus.CANCELLED -> MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )
                }
                
                Column {
                    Text("当前任务", fontWeight = FontWeight.SemiBold)
                    Text(
                        currentTask?.taskId.takeIf { it?.isNotEmpty() == true } ?: "无",
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
        }
        
        Spacer(Modifier.height(CaiTokens.S16))
        
        // 统计信息卡片
        GlobalCard {
            Text("执行统计", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(CaiTokens.S8))
            
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("总任务数", fontWeight = FontWeight.SemiBold)
                    Text(executorStats.totalTasks.toString(), fontSize = 24.sp)
                }
                Column {
                    Text("成功任务", fontWeight = FontWeight.SemiBold)
                    Text(executorStats.successfulTasks.toString(), color = MaterialTheme.colorScheme.secondary)
                }
                Column {
                    Text("失败任务", fontWeight = FontWeight.Bold)
                    Text(executorStats.failedTasks.toString(), color = MaterialTheme.colorScheme.error)
                }
                Column {
                    Text("成功率", fontWeight = FontWeight.SemiBold)
                    Text("${executorStats.successRatePercent.toInt()}%", color = MaterialTheme.colorScheme.secondary)
                }
            }
        }
        
        Spacer(Modifier.height(CaiTokens.S16))
        
        // 控制按钮
        GlobalCard {
            Text("控制面板", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(CaiTokens.S8))
            
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)) {
                PrimaryButton(
                    text = "开始测试任务",
                    enabled = executorStatus == ExecutorViewModel.ExecutorStatus.IDLE,
                    modifier = Modifier.weight(1f)
                ) {
                    val testTask = vm.generateTestTask()
                    vm.startTask(testTask)
                }
                
                PrimaryButton(
                    text = "停止当前任务",
                    enabled = executorStatus == ExecutorViewModel.ExecutorStatus.RUNNING,
                    modifier = Modifier.weight(1f),
                    ghost = true
                ) {
                    currentTask?.taskId?.let { vm.stopTask(it) }
                }
                
                PrimaryButton(
                    text = "停止所有任务",
                    enabled = executorStatus != ExecutorViewModel.ExecutorStatus.IDLE,
                    modifier = Modifier.weight(1f),
                    ghost = true
                ) {
                    vm.stopAllTasks()
                }
            }
            
            Spacer(Modifier.height(CaiTokens.S8))
            
            PrimaryButton(
                text = "清空日志",
                enabled = executorStats.totalTasks > 0,
                modifier = Modifier.fillMaxWidth(),
                ghost = true
            ) {
                vm.clearLogs()
            }
        }
        
        Spacer(Modifier.height(CaiTokens.S16))
        
        // 当前任务详情
        if (currentTask != null) {
            GlobalCard {
                Text("当前任务详情", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(CaiTokens.S8))
                
                val task = currentTask!!
                Column {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("任务ID:", fontWeight = FontWeight.SemiBold)
                        Text(task.taskId)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("彩种:", fontWeight = FontWeight.SemiBold)
                        Text(task.lotteryKey)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("目标期号:", fontWeight = FontWeight.SemiBold)
                        Text(task.targetIssue)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("下注类别:", fontWeight = FontWeight.SemiBold)
                        Text(task.betCommand.category)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("下注方向:", fontWeight = FontWeight.SemiBold)
                        Text(task.betCommand.direction)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("下注金额:", fontWeight = FontWeight.SemiBold)
                        Text("${task.betCommand.amount}元")
                    }
                }
            }
        }
    }
} }
}