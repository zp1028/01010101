package com.caifenxi.app.data.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.caifenxi.app.domain.model.ManualMark
import kotlinx.serialization.Serializable

@Entity(
    tableName = "manual_marks",
    primaryKeys = ["lotteryKey", "category"]
)
@Serializable
data class ManualMarkEntity(
    val lotteryKey: String,
    val category: String,
    val direction: String,
    val updatedAt: Long
) {
    fun toDomain(): ManualMark = ManualMark(
        lotteryKey = lotteryKey,
        category = category,
        direction = direction,
        updatedAt = updatedAt
    )

    companion object {
        fun fromDomain(mark: ManualMark): ManualMarkEntity = ManualMarkEntity(
            lotteryKey = mark.lotteryKey,
            category = mark.category,
            direction = mark.direction,
            updatedAt = mark.updatedAt
        )
    }
}
