package com.caifenxi.app.service

import android.content.Context
import android.graphics.Color as AndroidColor
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView

/**
 * 在点击坐标显示短暂红点 + 标签（如「大」），用于确认实际点击位置。
 * 优先 TYPE_ACCESSIBILITY_OVERLAY，失败则尝试应用悬浮窗类型。
 */
object ClickFeedbackOverlay {

    private val handler = Handler(Looper.getMainLooper())

    fun show(context: Context, x: Float, y: Float, label: String, fromA11y: Boolean) {
        handler.post {
            try {
                showInternal(context.applicationContext, x, y, label, fromA11y)
            } catch (_: Exception) {
            }
        }
    }

    private fun showInternal(context: Context, x: Float, y: Float, label: String, fromA11y: Boolean) {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val size = dp(context, 48)
        val type = when {
            fromA11y && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1 ->
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ->
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else ->
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
        }
        val lp = WindowManager.LayoutParams(
            size,
            size,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = (x - size / 2f).toInt()
            this.y = (y - size / 2f).toInt()
        }

        val ring = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(AndroidColor.argb(180, 244, 67, 54))
            setStroke(dp(context, 3), AndroidColor.WHITE)
        }
        val box = FrameLayout(context).apply {
            background = ring
        }
        val tv = TextView(context).apply {
            text = label
            setTextColor(AndroidColor.WHITE)
            textSize = 12f
            gravity = android.view.Gravity.CENTER
        }
        box.addView(
            tv,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )

        try {
            wm.addView(box, lp)
        } catch (_: Exception) {
            return
        }
        handler.postDelayed({
            try {
                if (box.isAttachedToWindow) wm.removeViewImmediate(box)
            } catch (_: Exception) {
            }
        }, 650)
    }

    private fun dp(context: Context, v: Int): Int =
        (v * context.resources.displayMetrics.density).toInt()
}
