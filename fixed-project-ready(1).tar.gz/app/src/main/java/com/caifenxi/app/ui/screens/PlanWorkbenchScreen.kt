package com.caifenxi.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanRuntime
import com.caifenxi.app.domain.model.PlanPredictionRecord
import com.caifenxi.app.domain.plan.AlgoChartPlans
import com.caifenxi.app.domain.plan.LotteryPlanPools
import com.caifenxi.app.domain.plan.NovaPlanAnalytics
import com.caifenxi.app.domain.plan.WorkbenchBacktestCache
import com.caifenxi.app.domain.model.BetSourceType
import com.caifenxi.app.domain.plan.PlanPool
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PageHeader
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.theme.CaiTokens
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.material3.OutlinedTextField
import androidx.compose.ui.platform.ClipboardManager
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString

private enum class WorkbenchTab(val label: String) {
    DETAIL("计划详情"),
    REVERSE("相反计划"),
    HISTORY("历史开奖"),
    TREND("计划走势"),
    GUIDE("计划攻略")
}

private enum class WorkbenchSource(val label: String) {
    ALL("全部计划"), LEGACY("原计划"), NOVA("新计划"), CANDIDATE("候选池"), CUSTOM("自定义"), MODEL("算法模型")
}

private enum class WorkbenchLevel(val label: String, val source: WorkbenchSource?) {
    HALL("计划大厅", null),
    BASIC("基础计划", WorkbenchSource.LEGACY),   // 原计划池
    COMBO("新计划池", WorkbenchSource.NOVA),     // 正式新计划（原「组合计划」易误解为空）
    EXTREME("极限候选", WorkbenchSource.CANDIDATE) // 候选策略池
}

private enum class LeaderboardTab(val label: String) {
    HIT_STREAK("最高连中"), HIT_RATE("最高胜率"), MISS_STREAK("最高连挂"),
    CURRENT_HIT("当前连中"), CURRENT_MISS("当前连挂")
}


/** 回测用历史切片：今日=按最新期号日期前缀；最近=全量供 chart 内部再截断 */
private fun sliceHistoryForMode(history: List<DrawRecord>, mode: String): List<DrawRecord> {
    if (history.isEmpty()) return history
    if (mode != "今日") return history
    val latest = history.lastOrNull()?.issue.orEmpty()
    val dayKey = when {
        latest.length >= 8 -> latest.take(8)
        latest.length >= 6 -> latest.take(6)
        else -> latest.take(4)
    }
    val day = history.filter { it.issue.startsWith(dayKey) }
    return if (day.size >= 6) day else history.takeLast(minOf(200, history.size))
}

/**
 * 完整珠段次数：例如 ✘✔✔✘✔✔✘ 中「双珠连中」出现 2 次。
 * wantHit=true 统计连中珠；false 统计连挂珠。runLen=珠数。
 */
private fun maxRunStreak(flags: List<Boolean>, wantHit: Boolean): Int {
    var max = 0
    var cur = 0
    flags.forEach {
        if (it == wantHit) {
            cur++
            max = maxOf(max, cur)
        } else cur = 0
    }
    return max
}


private fun outputCountFor(plan: PlanDefinition, vm: MainViewModel): Int? = when (plan.playType) {
    "组合" -> vm.prefs.value.comboPredCount.coerceIn(1, 20)
    "数字", "位置", "定位" -> vm.prefs.value.positionTopN.coerceIn(1, 20)
    "三军", "鱼虾蟹", "二同号", "二不同号", "三不同号", "三连号", "三同号", "长牌" ->
        vm.prefs.value.pointsTopN.coerceIn(1, 20)
    else -> null
}

private fun runtimeStreaks(report: NovaPlanAnalytics.ChartReport): IntArray {
    // 连中/连挂是“实际开奖期”口径，不能因为二三期回测存在 roundResults 就误用轮次结果。
    // 连中跳/连挂跳另由 jumpCache 使用 roundResults 统计。
    val flags = report.points.map { it.hit }
    var hit = 0; var miss = 0; var maxHit = 0; var maxMiss = 0
    flags.asReversed().forEach { f ->
        if (f) { if (miss > 0) return@forEach; hit++ }
        else { if (hit > 0) return@forEach; miss++ }
    }
    maxHit = maxRunStreak(flags, true)
    maxMiss = maxRunStreak(flags, false)
    return intArrayOf(hit, miss, maxHit, maxMiss)
}

private fun countZhuSegments(flags: List<Boolean>, runLen: Int, wantHit: Boolean): Int {
    if (runLen <= 0 || flags.isEmpty()) return 0
    var count = 0
    var i = 0
    while (i < flags.size) {
        if (flags[i] != wantHit) { i++; continue }
        var j = i
        while (j < flags.size && flags[j] == wantHit) j++
        val len = j - i
        // 完整珠段：长度恰好为 runLen，且被另一侧夹住（或在序列端点）
        if (len == runLen) {
            val leftOk = i == 0 || flags[i - 1] != wantHit
            val rightOk = j == flags.size || flags[j] != wantHit
            if (leftOk && rightOk) count++
        }
        i = j
    }
    return count
}

@Composable
fun PlanWorkbenchScreen(vm: MainViewModel) {
    // 状态挂在 PlanViewModel：切底部 Tab 再回来不丢回测与筛选；支持按开奖自动滚动更新
    val pvm = vm.planVM
    var sourceName by pvm.workbenchSourceName
    var levelName by pvm.workbenchLevelName
    var category by pvm.workbenchCategory
    var positionFilter by pvm.workbenchPositionFilter
    var selectedId by pvm.workbenchSelectedId
    var tabName by pvm.workbenchTabName
    var leaderboardTabName by pvm.workbenchLeaderboardTab
    var periods by pvm.workbenchPeriods
    var periodMode by pvm.workbenchPeriodMode
    var resultLimit by pvm.workbenchResultLimit
    var allPeriodsSelected by pvm.workbenchAllPeriods
    var cycleFilter by pvm.workbenchCycleFilter
    var backtestStage by pvm.workbenchBacktestStage
    var hitLian by pvm.workbenchHitLian
    var missLian by pvm.workbenchMissLian
    var hitJump by pvm.workbenchHitJump
    var missJump by pvm.workbenchMissJump
    var report by pvm.workbenchReport
    var running by remember { mutableStateOf(false) }
    var runtimeCache by pvm.workbenchRuntimeCache
    var jumpCache by pvm.workbenchJumpCache
    var jumpMaxCache by pvm.workbenchJumpMaxCache
    var batchRunning by pvm.workbenchBatchRunning
    var batchProgress by pvm.workbenchBatchProgress
    var planSearch by pvm.workbenchPlanSearch
    var planTier by pvm.workbenchPlanTier
    var historyPage by pvm.workbenchHistoryPage
    var statusHint by pvm.workbenchStatusHint
    var detailMode by pvm.workbenchDetailMode
    var autoRefresh by pvm.workbenchAutoRefresh
    val refreshTok = pvm.workbenchRefreshToken.value
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current

    val source = WorkbenchSource.entries.find { it.name == sourceName } ?: WorkbenchSource.ALL
    val level = WorkbenchLevel.entries.find { it.name == levelName } ?: WorkbenchLevel.HALL
    val tab = WorkbenchTab.entries.find { it.name == tabName } ?: WorkbenchTab.DETAIL
    val leaderboardTab = LeaderboardTab.entries.find { it.name == leaderboardTabName } ?: LeaderboardTab.HIT_STREAK

    val lottery = vm.currentLottery.value
    val history = vm.history.value.sortedWith(compareBy<DrawRecord> { it.issue.toLongOrNull() ?: Long.MIN_VALUE }.thenBy { it.issue })
    val custom = vm.customPlans.value.filter { it.lotteryKey == lottery.key }.map { it.toDefinition() }
    // 实验室临时生成计划：不混入工作台「全部/新计划」主池，避免和正式计划混淆统计
    val generated = vm.planVM.generatedNovaPlans.value.filter { LotteryPlanPools.belongsTo(it, lottery.type) }
    // 新计划只取正式池，不含实验室生成物
    val nova = remember(lottery.type) { LotteryPlanPools.novaPlansFor(lottery.type).distinctBy { it.planId } }
    val candidates = remember(lottery.type) { (
        com.caifenxi.app.domain.plan.PlanAppStylePool.extreme(lottery.type) + when (lottery.type) {
            com.caifenxi.app.domain.model.LotteryType.PKS -> com.caifenxi.app.domain.plan.NovaPlanPool.CANDIDATES
            com.caifenxi.app.domain.model.LotteryType.YDH -> com.caifenxi.app.domain.plan.NovaYdhPlanPool.CANDIDATES
            com.caifenxi.app.domain.model.LotteryType.K3 -> com.caifenxi.app.domain.plan.NovaK3PlanPool.CANDIDATES
            com.caifenxi.app.domain.model.LotteryType.PC28 -> com.caifenxi.app.domain.plan.NovaPc28PlanPool.CANDIDATES
            com.caifenxi.app.domain.model.LotteryType.LUCK20 -> com.caifenxi.app.domain.plan.NovaLuck20PlanPool.CANDIDATES
            else -> emptyList()
        }
    ).distinctBy { it.planId } }
    val legacy = remember(lottery.type) { LotteryPlanPools.legacyPlansFor(lottery.type) }
    // 算法模型（经验/形态/融合）= 实验室口径，仅在「算法模型」筛选下出现，不进计划大厅
    val models = if (lottery.type.name in listOf("YDH", "K3")) emptyList() else AlgoChartPlans.EXPERIENCE + AlgoChartPlans.PATTERN + AlgoChartPlans.FUSION

    // 局部函数须在使用前声明（Kotlin 不支持前向引用），统一从 runtimeCache 读取运行态
    fun resolveRuntime(planId: String): PlanRuntime {
        runtimeCache[planId]?.let { return it }
        return vm.planVM.runtimeForPlan(planId)
    }

    // 计划大厅/全部：仅正式原计划 + 正式新计划 + 用户自定义；不含实验室生成、不含候选池、不含算法模型
    val all = (legacy + nova + custom).distinctBy { it.planId }
    val sourcePlans = when (source) {
        WorkbenchSource.ALL -> all
        WorkbenchSource.LEGACY -> legacy
        WorkbenchSource.NOVA -> nova
        WorkbenchSource.CANDIDATE -> candidates
        WorkbenchSource.CUSTOM -> custom
        WorkbenchSource.MODEL -> models
    }
    val favoriteIds = vm.favoritePlanIds(lottery.key)
    val playOptions = listOf("全部") + sourcePlans.map { it.playType }.distinct().sorted()
    val positionOptions = listOf("全部") + sourcePlans.mapNotNull { p ->
        if (p.positionIndex >= 0) "位置${p.positionIndex + 1}" else null
    }.distinct().sortedBy { it.removePrefix("位置").toIntOrNull() ?: 0 }
    // 先得到“不含连中/连挂条件”的候选集。
    // 旧逻辑直接拿 PlanRuntime 默认值(0)筛选，导致用户一点击 1/2/3 连中/连挂就瞬间变成空列表。
    // 现在把这批计划作为筛选回测的输入，统一回测完成后再按真实结果过滤。
    val streakFilterBase = sourcePlans.asSequence()
        .filter { category == "全部" || category == "★ 收藏" || it.playType == category }
        .filter { positionFilter == "全部" || "位置${it.positionIndex + 1}" == positionFilter }
        .filter { cycleFilter == 0 || it.cyclePeriods == cycleFilter }
        .let { seq -> if (category == "★ 收藏") seq.filter { it.planId in favoriteIds } else seq }
        .let { seq ->
            val q = planSearch.trim()
            if (q.isEmpty()) seq
            else seq.filter {
                it.planName.contains(q, ignoreCase = true) ||
                    it.planId.contains(q, ignoreCase = true) ||
                    it.playType.contains(q, ignoreCase = true) ||
                    it.algorithm.contains(q, ignoreCase = true)
            }
        }
        .let { seq ->
            when (planTier) {
                "精选" -> seq.filter {
                    it.planId.startsWith("APP-") || it.category.contains("App") ||
                        it.algorithm in setOf("LUZHU", "GENZHU", "SHUANGZHU", "SANZHU", "YILOU_BU", "SHA_RE", "FANZHU", "CHANGLOONG", "DINGBAN")
                }
                "扩展" -> seq.filter {
                    !it.planId.startsWith("APP-") && !it.planId.startsWith("APPX-") &&
                        it.algorithm !in setOf("LUZHU", "GENZHU", "SHUANGZHU", "SANZHU", "YILOU_BU", "SHA_RE", "FANZHU", "CHANGLOONG", "DINGBAN")
                }
                "极限App" -> seq.filter { it.planId.startsWith("APPX-") || it.category.contains("极限") }
                else -> seq
            }
        }
        .distinctBy { it.planId }
        .toList()

    val streakFilterActive = hitLian > 0 || missLian > 0 || hitJump > 0 || missJump > 0
    val filtered = streakFilterBase.asSequence()
        .let { seq ->
            if (!streakFilterActive) seq
            else seq.filter { p ->
                val rt = resolveRuntime(p.planId)
                val (jh, jm) = jumpCache[p.planId] ?: (0 to 0)
                // 未回测的计划不能被当成“0连中/0连挂”参与精确筛选。
                // 自动回测完成后 Compose 会重新计算这里。
                if (rt.sampleCount <= 0 && p.planId !in runtimeCache) return@filter false
                (hitLian == 0 || rt.consecutiveHit >= hitLian) &&
                    (missLian == 0 || rt.consecutiveMiss >= missLian) &&
                    (hitJump == 0 || jh >= hitJump) &&
                    (missJump == 0 || jm >= missJump)
            }
        }
        .take(resultLimit)
        .toList()
    val selected = filtered.firstOrNull { it.planId == selectedId } ?: filtered.firstOrNull()

    val leaderboardRows = filtered.map { p -> p to resolveRuntime(p.planId) }
        .sortedWith(when (leaderboardTab) {
            LeaderboardTab.HIT_STREAK -> compareByDescending<Pair<PlanDefinition, PlanRuntime>> { it.second.maxConsecutiveHit }.thenByDescending { it.second.hitRate }.thenByDescending { it.second.sampleCount }
            LeaderboardTab.HIT_RATE -> compareByDescending<Pair<PlanDefinition, PlanRuntime>> { if (it.second.sampleCount >= 5) it.second.hitRate else -1.0 }.thenByDescending { it.second.score }.thenByDescending { it.second.sampleCount }
            LeaderboardTab.MISS_STREAK -> compareByDescending<Pair<PlanDefinition, PlanRuntime>> { it.second.maxConsecutiveMiss }.thenByDescending { it.second.sampleCount }
            LeaderboardTab.CURRENT_HIT -> compareByDescending<Pair<PlanDefinition, PlanRuntime>> { it.second.consecutiveHit }.thenByDescending { it.second.maxConsecutiveHit }.thenByDescending { it.second.sampleCount }
            LeaderboardTab.CURRENT_MISS -> compareByDescending<Pair<PlanDefinition, PlanRuntime>> { it.second.consecutiveMiss }.thenByDescending { it.second.maxConsecutiveMiss }.thenByDescending { it.second.sampleCount }
        }).take(20)

    LaunchedEffect(lottery.key, all.size, candidates.size, models.size, generated.size) {
        // 收藏校验可含候选/模型/已生成；但主列表展示不混入实验室临时计划
        vm.pruneFavoritePlans((all + candidates + custom + models + generated).map { it.planId }.toSet(), lottery.key)
    }

    // 详情打开时禁止自动改选中项，避免「打开计划却跳来跳去刷很多页」
    LaunchedEffect(source, level, category, positionFilter, cycleFilter, hitLian, missLian, hitJump, missJump, lottery.key) {
        if (detailMode) return@LaunchedEffect
        if (selectedId != null && selectedId !in filtered.map { it.planId }) {
            selectedId = null
        }
    }

    LaunchedEffect(lottery.key) {
        vm.loadCustomPlans()
    }

    val latestIssueKey = history.lastOrNull()?.issue.orEmpty()
    LaunchedEffect(autoRefresh, refreshTok, latestIssueKey, lottery.key, periods, backtestStage, periodMode) {
        if (!autoRefresh) return@LaunchedEffect
        if (history.size < 6) return@LaunchedEffect
        if (latestIssueKey.isBlank()) return@LaunchedEffect
        pvm.notifyWorkbenchNewIssue(latestIssueKey)
        val cachedIds = runtimeCache.keys.toList()
        if (cachedIds.isEmpty() && selectedId == null) return@LaunchedEffect
        val planMap = (all + candidates + models + generated + custom).associateBy { it.planId }
        val toRefresh = (cachedIds + listOfNotNull(selectedId)).distinct().mapNotNull { planMap[it] }
        if (toRefresh.isEmpty() || batchRunning) return@LaunchedEffect
        statusHint = "新期 $latestIssueKey · 滚动更新 ${toRefresh.size} 个计划…"
        val map = LinkedHashMap<String, PlanRuntime>()
        for (plan in toRefresh) {
            try {
                val histSnap = sliceHistoryForMode(history, periodMode)
                val periodsSnap = if (periodMode == "今日" || allPeriodsSelected) histSnap.size.coerceAtLeast(1) else periods
                val rep = withContext(Dispatchers.Default) {
                    NovaPlanAnalytics.chartBacktest(
                        plan = plan,
                        history = histSnap,
                        periods = periodsSnap.coerceAtLeast(1),
                        stake = 10.0,
                        stage = backtestStage.coerceIn(1, 3),
                        invert = false,
                        outputCount = outputCountFor(plan, vm)
                    )
                }
                val rs = runtimeStreaks(rep)
                map[plan.planId] = PlanRuntime(
                    planId = plan.planId,
                    sampleCount = rep.hits + rep.misses,
                    hitCount = rep.hits,
                    consecutiveMiss = rs[1],
                    consecutiveHit = rs[0],
                    maxConsecutiveMiss = rs[3],
                    maxConsecutiveHit = rs[2],
                    lastPrediction = rep.points.lastOrNull()?.prediction,
                    lastTargetIssue = rep.points.lastOrNull()?.issue
                )
                jumpCache = jumpCache + (plan.planId to (rep.currentHitStreak to rep.currentMissStreak))
                jumpMaxCache = jumpMaxCache + (plan.planId to (rep.maxHitStreak to rep.maxMissStreak))
                if (plan.planId == selectedId) report = rep
            } catch (_: Exception) {
            }
        }
        if (map.isNotEmpty()) {
            runtimeCache = runtimeCache + map
            statusHint = "已按新期 $latestIssueKey 滚动更新 ${map.size} 个计划"
        }
    }

    fun runPlanBacktest(plan: PlanDefinition, stageOverride: Int? = null) {
        if (history.size < 6) return
        val st = (stageOverride ?: backtestStage).coerceIn(1, 3)
        val histSnap = sliceHistoryForMode(history, periodMode)
        val periodsSnap = if (periodMode == "今日" || allPeriodsSelected) histSnap.size.coerceAtLeast(1) else periods
        val lastIssue = histSnap.lastOrNull()?.issue.orEmpty()
        val outputCount = outputCountFor(plan, vm)
        val cacheKey = WorkbenchBacktestCache.key(plan.planId, st, periodsSnap, lastIssue, histSnap.size, false, outputCount ?: 0)
        WorkbenchBacktestCache.get(cacheKey)?.let { cached ->
            report = cached
            val pts = cached.points
            val st = runtimeStreaks(cached)
            runtimeCache = runtimeCache + (plan.planId to PlanRuntime(
                planId = plan.planId,
                sampleCount = cached.hits + cached.misses,
                hitCount = cached.hits,
                consecutiveMiss = st[1],
                consecutiveHit = st[0],
                maxConsecutiveMiss = st[3],
                maxConsecutiveHit = st[2],
                lastPrediction = pts.lastOrNull()?.prediction,
                lastTargetIssue = pts.lastOrNull()?.issue
            ))
            jumpCache = jumpCache + (plan.planId to (cached.currentHitStreak to cached.currentMissStreak))
            jumpMaxCache = jumpMaxCache + (plan.planId to (cached.maxHitStreak to cached.maxMissStreak))
            return
        }
        val oc = outputCountFor(plan, vm)
        running = true
        report = null
        scope.launch {
            try {
                val rep = withContext(Dispatchers.Default) {
                    NovaPlanAnalytics.chartBacktest(
                        plan = plan,
                        history = histSnap,
                        periods = periodsSnap,
                        stake = 10.0,
                        stage = st,
                        invert = false,
                        outputCount = oc
                    )
                }
                WorkbenchBacktestCache.put(cacheKey, rep)
                report = rep
                val pts = rep.points
                val st = runtimeStreaks(rep)
                runtimeCache = runtimeCache + (plan.planId to PlanRuntime(
                    planId = plan.planId,
                    sampleCount = rep.hits + rep.misses,
                    hitCount = rep.hits,
                    consecutiveMiss = st[1],
                    consecutiveHit = st[0],
                    maxConsecutiveMiss = st[3],
                    maxConsecutiveHit = st[2],
                    lastPrediction = pts.lastOrNull()?.prediction,
                    lastTargetIssue = pts.lastOrNull()?.issue
                ))
                jumpCache = jumpCache + (plan.planId to (rep.currentHitStreak to rep.currentMissStreak))
                jumpMaxCache = jumpMaxCache + (plan.planId to (rep.maxHitStreak to rep.maxMissStreak))
            } catch (e: Exception) {
                report = null
                statusHint = "回测失败：${e.message ?: "未知错误"}"
            } finally {
                running = false
            }
        }
    }

    // 连中/连挂/连中跳/连挂跳是“结果型筛选”，必须先有该计划的统一回测结果。
    // 用户刚点筛选时自动对当前基础计划集回测一次，避免筛选结果为空。
    LaunchedEffect(hitLian, missLian, hitJump, missJump, lottery.key, periods, backtestStage, periodMode, category, positionFilter, cycleFilter, planTier, planSearch) {
        if (!streakFilterActive || history.size < 6 || batchRunning) return@LaunchedEffect
        val need = streakFilterBase.filter { it.planId !in runtimeCache || runtimeCache[it.planId]?.sampleCount == 0 }
        if (need.isEmpty()) return@LaunchedEffect
        pvm.cancelWorkbenchBatch()
        batchRunning = true
        batchProgress = "0/${need.size}"
        pvm.setWorkbenchBatchJob(scope.launch {
            val map = LinkedHashMap<String, PlanRuntime>()
            try {
                need.forEachIndexed { idx, plan ->
                    ensureActive()
                    val rep = withContext(Dispatchers.Default) {
                        NovaPlanAnalytics.chartBacktest(
                            plan = plan,
                            history = history,
                            periods = if (allPeriodsSelected) history.size.coerceAtLeast(1) else periods.coerceAtLeast(1),
                            stake = 10.0,
                            stage = backtestStage.coerceIn(1, 3),
                            invert = false,
                            outputCount = outputCountFor(plan, vm)
                        )
                    }
                    val rs = runtimeStreaks(rep)
                    map[plan.planId] = PlanRuntime(
                        planId = plan.planId, sampleCount = rep.hits + rep.misses, hitCount = rep.hits,
                        consecutiveMiss = rs[1], consecutiveHit = rs[0],
                        maxConsecutiveMiss = rs[3], maxConsecutiveHit = rs[2],
                        lastPrediction = rep.points.lastOrNull()?.prediction,
                        lastTargetIssue = rep.points.lastOrNull()?.issue
                    )
                    jumpCache = jumpCache + (plan.planId to (rep.currentHitStreak to rep.currentMissStreak))
                    jumpMaxCache = jumpMaxCache + (plan.planId to (rep.maxHitStreak to rep.maxMissStreak))
                    batchProgress = "${idx + 1}/${need.size}"
                }
                runtimeCache = runtimeCache + map
                batchProgress = "筛选回测完成${map.size}个"
            } catch (e: kotlinx.coroutines.CancellationException) {
                runtimeCache = runtimeCache + map
                throw e
            } catch (e: Exception) {
                statusHint = "筛选回测失败：${e.message ?: "未知错误"}"
            } finally {
                batchRunning = false
                pvm.setWorkbenchBatchJob(null)
            }
        })
    }

    // 仅在详情模式且已选计划时回测，避免一进工作台就卡死主线程
    LaunchedEffect(selectedId, lottery.key, periods, backtestStage, detailMode, periodMode) {
        if (!detailMode) return@LaunchedEffect
        val id = selectedId ?: return@LaunchedEffect
        // 用 all 池查找，避免 filtered 变化导致选中计划找不到又乱跳
        val p = all.firstOrNull { it.planId == id }
            ?: filtered.firstOrNull { it.planId == id }
            ?: return@LaunchedEffect
        if (history.size >= 6) {
            runPlanBacktest(p, backtestStage)
        }
    }

    /** 统一回测：可取消；结果写入 runtimeCache */
    fun runBatchBacktest() {
        if (batchRunning || history.size < 6) return
        val targets = (if (streakFilterActive) streakFilterBase else filtered)
            .take(resultLimit.coerceAtLeast(20))
        if (targets.isEmpty()) return
        pvm.cancelWorkbenchBatch()
        batchRunning = true
        batchProgress = "0/${targets.size}"
        pvm.setWorkbenchBatchJob(scope.launch {
            val map = LinkedHashMap<String, PlanRuntime>()
            try {
                targets.forEachIndexed { idx, plan ->
                    ensureActive()
                    val oc = outputCountFor(plan, vm)
                    val rep = withContext(Dispatchers.Default) {
                        NovaPlanAnalytics.chartBacktest(
                            plan = plan,
                            history = history,
                            periods = if (allPeriodsSelected) history.size.coerceAtLeast(1) else periods.coerceAtLeast(1),
                            stake = 10.0,
                            stage = backtestStage.coerceIn(1, 3),
                            invert = false,
                            outputCount = oc
                        )
                    }
                    map[plan.planId] = PlanRuntime(
                        planId = plan.planId,
                        sampleCount = rep.hits + rep.misses,
                        hitCount = rep.hits,
                        consecutiveMiss = runtimeStreaks(rep)[1],
                        consecutiveHit = runtimeStreaks(rep)[0],
                        maxConsecutiveMiss = runtimeStreaks(rep)[3],
                        maxConsecutiveHit = runtimeStreaks(rep)[2],
                        lastPrediction = rep.points.lastOrNull()?.prediction,
                        lastTargetIssue = rep.points.lastOrNull()?.issue
                    )
                    jumpCache = jumpCache + (plan.planId to (rep.currentHitStreak to rep.currentMissStreak))
                    jumpMaxCache = jumpMaxCache + (plan.planId to (rep.maxHitStreak to rep.maxMissStreak))
                    batchProgress = "${idx + 1}/${targets.size}"
                }
                runtimeCache = runtimeCache + map
                batchProgress = "完成${map.size}个"
                selected?.let { runPlanBacktest(it) }
            } catch (e: kotlinx.coroutines.CancellationException) {
                runtimeCache = runtimeCache + map
                batchProgress = "已取消·已保存${map.size}个"
                throw e
            } finally {
                batchRunning = false
                pvm.setWorkbenchBatchJob(null)
            }
        })
    }

    fun cancelBatchBacktest() {
        pvm.cancelWorkbenchBatch()
        pvm.setWorkbenchBatchJob(null)
        batchRunning = false
        if (!batchProgress.startsWith("完成") && !batchProgress.startsWith("已取消")) {
            batchProgress = "已取消"
        }
    }

    if (detailMode && selected != null) {
        // —— 全屏详情页：不再堆在列表底部 ——
        PlanDetailFullPage(
            plan = selected,
            report = report,
            history = history,
            running = running,
            backtestStage = backtestStage,
            periods = periods,
            tab = tab,
            onTab = { tabName = it.name },
            onBack = { detailMode = false; report = null },
            onStage = { s ->
                if (s != backtestStage) {
                    backtestStage = s
                    report = null
                    // 立即按新口径重算，避免仍显示一期胜率
                    WorkbenchBacktestCache.clear()
                    runPlanBacktest(selected, s)
                }
            },
            onRefresh = { runPlanBacktest(selected, backtestStage) },
            onPeriodsChange = { n ->
                periods = n
                // 期数变更后立刻按新期数重算（含二期/三期口径）
                runPlanBacktest(selected, backtestStage)
            },
            onFavorite = { vm.togglePlanFavorite(selected.planId) },
            isFavorite = vm.isPlanFavorite(selected.planId),
            resolveRuntime = { resolveRuntime(it) },
            sourceLabel = sourceLabel(selected, legacy, nova, candidates, custom, models),
            candidates = candidates,
            clipboard = clipboard,
            vm = vm,
            nextIssue = vm.nextIssueText.value,
            historyPage = historyPage,
            onHistoryPage = { historyPage = it },
            onSetBotSource = {
                val cfg = vm.botConfig.value
                vm.saveBotConfig(
                    cfg.copy(
                        sourceType = BetSourceType.FAVORITE.id,
                        sourceId = selected.planId,
                        sourceIdDx = selected.planId,
                        sourceIdDs = selected.planId,
                        sourceIdCombo = selected.planId,
                        rollingPredict = true
                    )
                )
                if (!vm.isPlanFavorite(selected.planId)) vm.togglePlanFavorite(selected.planId)
                statusHint = "已设为挂机来源并收藏：${selected.planName}"
            }
        )
    } else LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = CaiTokens.S12, vertical = CaiTokens.S8),
        verticalArrangement = Arrangement.spacedBy(CaiTokens.S8),
        contentPadding = PaddingValues(bottom = CaiTokens.ScreenBottom)
    ) {
        item {
            GlobalCard {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(lottery.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        CaptionMuted("计划工作台 · ${com.caifenxi.app.domain.model.LotteryPlayCatalog.summaryText(lottery.type)}")
                        val histN = history.size
                        val next = vm.nextIssueText.value
                        CaptionMuted(
                            if (histN < 6) "历史不足(${histN}期)，请先同步开奖"
                            else "历史${histN}期 · 下期 ${if (next.isBlank() || next == "-") "—" else next}"
                        )
                    }
                    Text("★ ${favoriteIds.size}", color = CaiTokens.Warning, fontWeight = FontWeight.Bold)
                }
            }
        }
        item {
            val levelCounts = mapOf(
                WorkbenchLevel.HALL to all.size,
                WorkbenchLevel.BASIC to legacy.size,
                WorkbenchLevel.COMBO to nova.size,
                WorkbenchLevel.EXTREME to candidates.size
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                WorkbenchLevel.entries.forEach { l ->
                    val cnt = levelCounts[l] ?: 0
                    Column(
                        Modifier.weight(1f).clickable {
                            levelName = l.name
                            sourceName = (l.source ?: WorkbenchSource.ALL).name
                            category = "全部"
                            positionFilter = "全部"
                            hitLian = 0; hitJump = 0
                            missLian = 0; missJump = 0
                            selectedId = null
                            // 极限候选数量大，自动放宽条数
                            if (l == WorkbenchLevel.EXTREME) resultLimit = 500
                        }.padding(vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            l.label,
                            fontWeight = if (level == l) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 13.sp,
                            color = if (level == l) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            "${cnt}个",
                            fontSize = 11.sp,
                            color = if (cnt == 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (level == l) HorizontalDivider(Modifier.padding(top = 4.dp), thickness = 3.dp)
                    }
                }
            }
            if (sourcePlans.isEmpty()) {
                CaptionMuted(
                    when (level) {
                        WorkbenchLevel.BASIC -> "基础计划（原计划池）当前彩种无数据"
                        WorkbenchLevel.COMBO -> "新计划池当前彩种无正式计划"
                        WorkbenchLevel.EXTREME -> "极限候选池当前彩种无候选策略"
                        else -> "计划大厅暂无计划"
                    }
                )
            } else {
                CaptionMuted(
                    when (level) {
                        WorkbenchLevel.BASIC -> "基础计划=原计划池 · ${legacy.size}个"
                        WorkbenchLevel.COMBO -> "新计划池=正式Nova · ${nova.size}个（不含实验室生成/候选）"
                        WorkbenchLevel.EXTREME -> "极限候选=策略候选池 · ${candidates.size}个 · 建议点「统一回测」填充连跳数据"
                        else -> "计划大厅=原计划+新计划+自定义 · ${all.size}个"
                    }
                )
            }
        }
        item {
            GlobalCard {
                Text("玩法分类", fontWeight = FontWeight.Bold)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    playOptions.forEach { c ->
                        FilterChip(selected = category == c, onClick = { category = c; selectedId = null }, label = { Text(c) })
                    }
                    FilterChip(selected = category == "★ 收藏", onClick = { category = "★ 收藏"; selectedId = null }, label = { Text("★ 收藏 ${favoriteIds.size}") })
                }
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    positionOptions.forEach { p ->
                        FilterChip(selected = positionFilter == p, onClick = { positionFilter = p; selectedId = null }, label = { Text(p) })
                    }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    WorkbenchSource.entries.filter { it == WorkbenchSource.CUSTOM || it == WorkbenchSource.MODEL }.forEach { s ->
                        FilterChip(selected = source == s, onClick = { sourceName = s.name; category = "全部"; positionFilter = "全部"; selectedId = null }, label = { Text(s.label) })
                    }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("全部", "精选", "极限App", "扩展").forEach { tier ->
                        FilterChip(
                            selected = planTier == tier,
                            onClick = { planTier = tier; selectedId = null },
                            label = { Text(tier) }
                        )
                    }
                }
                CaptionMuted("精选=路珠/双珠等App口径；极限App=多窗口变体；扩展=矩阵统计计划")
                CaptionMuted(
                    if (periodMode == "今日") "回测范围：今日自然日（按期号日期，约0点后新一天）"
                    else "回测范围：最近 ${periods} 期（非自然日；可在走势里改期数）"
                )
                if (statusHint.isNotEmpty()) CaptionMuted(statusHint)
            }
        }
        item {
            GlobalCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    WorkbenchFilterButton("回测期数", if (allPeriodsSelected) "全部" else "${periods}期", Modifier.weight(1f)) {
                        val opts = listOf(100, 200, 500, 1000, 2000, 3000, 5000, 8000)
                        if (allPeriodsSelected) { allPeriodsSelected = false; periods = 100 }
                        else {
                            val idx = opts.indexOf(periods)
                            if (idx >= 0 && idx < opts.lastIndex) periods = opts[idx + 1]
                            else allPeriodsSelected = true
                        }
                    }
                    WorkbenchFilterButton("计划数量", if (resultLimit >= 9999) "全部" else "≤${resultLimit}", Modifier.weight(1f)) { resultLimit = when (resultLimit) { 50 -> 100; 100 -> 200; 200 -> 500; 500 -> 1000; 1000 -> 9999; else -> 50 } }
                    WorkbenchFilterButton("计划周期", if (cycleFilter == 0) "全部" else "${cycleFilter}期", Modifier.weight(1f)) { cycleFilter = when (cycleFilter) { 0 -> 1; 1 -> 2; 2 -> 3; 3 -> 5; else -> 0 } }
                    WorkbenchFilterButton(
                        "回测范围",
                        if (periodMode == "今日") "今日0点起" else "最近${periods}期",
                        Modifier.weight(1f)
                    ) {
                        periodMode = if (periodMode == "今日") "最近" else "今日"
                        report = null
                        WorkbenchBacktestCache.clear()
                    }
                    WorkbenchFilterButton(
                        "回测口径",
                        when (backtestStage) { 2 -> "二期"; 3 -> "三期"; else -> "一期" },
                        Modifier.weight(1f)
                    ) {
                        backtestStage = when (backtestStage) { 1 -> 2; 2 -> 3; else -> 1 }
                        report = null
                        runtimeCache = emptyMap(); jumpCache = emptyMap(); jumpMaxCache = emptyMap()
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    WorkbenchFilterButton(
                        "当前连中",
                        if (hitLian <= 0) "不限" else "${hitLian}连中",
                        Modifier.weight(1f)
                    ) {
                        hitLian = if (hitLian >= 9) 0 else hitLian + 1
                        missLian = 0
                    }
                    WorkbenchFilterButton(
                        "当前连挂",
                        if (missLian <= 0) "不限" else "${missLian}连挂",
                        Modifier.weight(1f)
                    ) {
                        missLian = if (missLian >= 9) 0 else missLian + 1
                        hitLian = 0
                    }
                    WorkbenchFilterButton(
                        "连中跳",
                        if (hitJump <= 0) "不限" else "${hitJump}次",
                        Modifier.weight(1f)
                    ) {
                        hitJump = if (hitJump >= 9) 0 else hitJump + 1
                        missJump = 0
                    }
                    WorkbenchFilterButton(
                        "连挂跳",
                        if (missJump <= 0) "不限" else "${missJump}次",
                        Modifier.weight(1f)
                    ) {
                        missJump = if (missJump >= 9) 0 else missJump + 1
                        hitJump = 0
                    }
                    WorkbenchFilterButton("重置筛选", "清空", Modifier.weight(1f)) {
                        hitLian = 0; missLian = 0; hitJump = 0; missJump = 0
                        planSearch = ""; planTier = "全部"; cycleFilter = 0
                    }
                }
                CaptionMuted("连中/连挂=每期中挂连续；连中跳/连挂跳=周期（轮）连续，二者不同")
                Text(
                    buildString {
                        if (hitLian > 0) append("连中${hitLian} ")
                        if (missLian > 0) append("连挂${missLian} ")
                        if (hitJump > 0) append("连中跳${hitJump} ")
                        if (missJump > 0) append("连挂跳${missJump} ")
                        if (isEmpty()) append("点选 1～9 筛选（需先统一回测）")
                    },
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("连中", fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterVertically))
                    (1..9).forEach { n ->
                        FilterChip(selected = hitLian == n, onClick = { hitLian = n; missLian = 0 }, label = { Text("$n") })
                    }
                    FilterChip(selected = hitLian == 0 && missLian == 0 && hitJump == 0 && missJump == 0, onClick = {
                        hitLian = 0; missLian = 0; hitJump = 0; missJump = 0
                    }, label = { Text("不限") })
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("连挂", fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterVertically))
                    (1..9).forEach { n ->
                        FilterChip(selected = missLian == n, onClick = { missLian = n; hitLian = 0 }, label = { Text("$n") })
                    }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("连中跳", fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterVertically))
                    (1..9).forEach { n ->
                        FilterChip(selected = hitJump == n, onClick = { hitJump = n; missJump = 0 }, label = { Text("$n") })
                    }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("连挂跳", fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterVertically))
                    (1..9).forEach { n ->
                        FilterChip(selected = missJump == n, onClick = { missJump = n; hitJump = 0 }, label = { Text("$n") })
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    PrimaryButton(
                        "开始搜索",
                        {
                            selectedId = null
                            detailMode = false
                            report = null
                            statusHint = "已筛选 ${filtered.size} 条，点列表进入详情"
                        },
                        Modifier.weight(1f),
                        enabled = filtered.isNotEmpty()
                    )
                    PrimaryButton(
                        if (batchRunning) "回测中 $batchProgress" else "统一回测",
                        { runBatchBacktest() },
                        Modifier.weight(1f),
                        enabled = !batchRunning && filtered.isNotEmpty() && history.size >= 6
                    )
                    if (batchRunning) {
                        PrimaryButton("取消", { cancelBatchBacktest() }, Modifier.weight(0.7f), ghost = true)
                    }
                }
                CaptionMuted(
                    buildString {
                        append("当前 ${source.label} · ${filtered.size} 个结果 · 正式 ${all.size} · 候选 ${candidates.size}")
                        if (generated.isNotEmpty()) append(" · 实验室生成${generated.size}条(不混入主池)")
                        if (hitLian > 0) append(" · 连中${hitLian}")
                        if (missLian > 0) append(" · 连挂${missLian}")
                        if (hitJump > 0) append(" · 连中跳${hitJump}")
                        if (missJump > 0) append(" · 连挂跳${missJump}")
                        if (runtimeCache.isNotEmpty()) append(" · 已缓存回测${runtimeCache.size}")
                        if (batchProgress.isNotEmpty()) append(" · $batchProgress")
                    }
                )
                CaptionMuted("连中/连挂按实际开奖期统计；连中跳/连挂跳按轮统计。筛选表示至少达到所选连续次数")
                Row(
                    Modifier.fillMaxWidth().padding(top = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("开奖后自动滚动更新回测", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f), fontSize = 13.sp)
                    Switch(checked = autoRefresh, onCheckedChange = { autoRefresh = it })
                }
                CaptionMuted(
                    if (autoRefresh) "已开启：切走再回来保留结果；新期只增量刷新已回测计划，不全量重跑，避免卡死"
                    else "已关闭自动：需手动点「统一回测」。切 Tab 仍保留已回测缓存"
                )
            }
        }
        item {
            GlobalCard {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    LeaderboardTab.entries.forEach { t ->
                        FilterChip(selected = leaderboardTab == t, onClick = { leaderboardTabName = t.name }, label = { Text(t.label) })
                    }
                }
            }
        }
        item {
            val chunks = leaderboardRows.chunked(2)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                chunks.forEach { pair ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        pair.forEach { (p, rt) ->
                            GlobalCard(Modifier.weight(1f).clickable { selectedId = p.planId; tabName = WorkbenchTab.DETAIL.name; report = null; detailMode = true }) {
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Text(p.planName.take(11), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                    Text(if (p.planId in favoriteIds) "★" else "☆", color = CaiTokens.Warning)
                                }
                                when (leaderboardTab) {
                                    LeaderboardTab.HIT_STREAK -> Text("最高连中${rt.maxConsecutiveHit}次")
                                    LeaderboardTab.HIT_RATE -> Text(if (rt.sampleCount > 0) "中奖率${"%.0f".format(rt.hitRate * 100)}%" else "中奖率—")
                                    LeaderboardTab.MISS_STREAK -> Text("最高连挂${rt.maxConsecutiveMiss}次")
                                    LeaderboardTab.CURRENT_HIT -> Text(if (rt.consecutiveHit > 0) "连中${rt.consecutiveHit}次" else "连中0")
                                    LeaderboardTab.CURRENT_MISS -> Text(if (rt.consecutiveMiss > 0) "连挂${rt.consecutiveMiss}次" else "连挂0")
                                }
                                CaptionMuted("${p.playType} · ${if (p.positionIndex >= 0) "位置${p.positionIndex + 1}" else "不定位"}")
                            }
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
        item {
            GlobalCard {
                Text("计划列表 · ${filtered.size}个", fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = planSearch,
                    onValueChange = { planSearch = it; selectedId = null },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    singleLine = true,
                    placeholder = { Text("搜索计划名/ID/玩法/算法") }
                )
                if (filtered.isEmpty()) {
                    CaptionMuted(
                        when {
                            planSearch.isNotBlank() -> "无匹配「$planSearch」的计划，请改关键词或重置筛选"
                            sourcePlans.isEmpty() -> "当前分类下没有计划，请切换「基础/新计划池/极限候选」"
                            else -> "筛选后无结果，可点重置筛选或切换玩法"
                        }
                    )
                } else {
                    CaptionMuted("共 ${filtered.size} 条，列表虚拟滚动，可点进详情")
                }
            }
        }
        if (filtered.isNotEmpty()) {
            items(filtered.size, key = { filtered[it].planId }) { idx ->
                val p = filtered[idx]
                val rt = resolveRuntime(p.planId)
                val selectedRow = p.planId == selected?.planId
                GlobalCard(
                    Modifier.clickable {
                        selectedId = p.planId
                        tabName = WorkbenchTab.DETAIL.name
                        report = null
                        detailMode = true
                        historyPage = 40
                    }
                ) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            if (p.planId in favoriteIds) "★" else "☆",
                            color = CaiTokens.Warning,
                            modifier = Modifier.padding(end = 6.dp)
                        )
                        Column(Modifier.weight(1f)) {
                            Text(
                                p.planName,
                                fontWeight = if (selectedRow) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedRow) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                fontSize = 13.sp,
                                maxLines = 1
                            )
                            if (rt.sampleCount > 0) {
                                val (jh, jm) = jumpCache[p.planId] ?: (0 to 0)
                                val lianText = when {
                                    rt.consecutiveHit > 0 -> "连中${rt.consecutiveHit}"
                                    rt.consecutiveMiss > 0 -> "连挂${rt.consecutiveMiss}"
                                    else -> "连中0"
                                }
                                val jumpText = when {
                                    jh > 0 -> "连中跳${jh}次"
                                    jm > 0 -> "连挂跳${jm}次"
                                    else -> "连跳0次"
                                }
                                Text(
                                    "当前 $lianText · $jumpText",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                CaptionMuted("${p.playType} · 历史/今日最大进详情")
                            } else {
                                CaptionMuted("${p.playType} · 回测后显示连中/连跳")
                            }
                        }
                    }
                }
            }
        }

        item {
            GlobalCard {
                CaptionMuted(
                    when {
                        history.size < 6 -> "开奖历史不足，请先在首页/历史页同步数据后再回测"
                        filtered.isEmpty() -> "当前筛选无计划，可切换「精选/扩展」或重置筛选"
                        else -> "点击上方计划进入独立详情（下期预测 · 回测 · 挂机绑定）"
                    }
                )
            }
        }
    }
}

/** 珠数文案：1珠 / 双珠 / 三珠 / N珠 + 连中|连挂跳 */
private fun zhuLabel(n: Int, kind: String): String = when {
    n <= 0 -> "全部"
    n == 1 -> "1珠${kind}跳"
    n == 2 -> "双珠${kind}跳"
    n == 3 -> "三珠${kind}跳"
    else -> "${n}珠${kind}跳"
}

@Composable
private fun WorkbenchFilterButton(title: String, value: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier,
        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 8.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, fontSize = 11.sp)
            Text(value, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

private fun sourceLabel(p: PlanDefinition, legacy: List<PlanDefinition>, nova: List<PlanDefinition>, candidates: List<PlanDefinition>, custom: List<PlanDefinition>, models: List<PlanDefinition>): String = when {
    legacy.any { it.planId == p.planId } -> "原计划池"
    nova.any { it.planId == p.planId } -> "新计划池"
    candidates.any { it.planId == p.planId } -> "候选策略池"
    custom.any { it.planId == p.planId } -> "自定义计划"
    models.any { it.planId == p.planId } -> "算法模型"
    else -> "计划"
}


@Composable
private fun PlanDetailCard(plan: PlanDefinition, report: NovaPlanAnalytics.ChartReport?) {
    GlobalCard {
        Text("计划详情", fontWeight = FontWeight.Bold)
        DetailRow("计划ID", plan.planId)
        DetailRow("计划名称", plan.planName)
        DetailRow("玩法", plan.playType)
        DetailRow("分类", plan.category)
        DetailRow("算法", plan.algorithm)
        DetailRow("样本窗口", "${plan.window}期")
        DetailRow("执行周期", "${plan.cyclePeriods}期")
        DetailRow("命中基准", "${"%.1f".format(plan.baselineValue * 100)}%")
        DetailRow("共识参与", if (plan.participateConsensus) "是" else "否")
        report?.let {
            HorizontalDivider(Modifier.padding(vertical = 6.dp))
            Text("最近回测", fontWeight = FontWeight.SemiBold)
            DetailRow("回测期数", "${it.periods}期")
            DetailRow("命中", "${it.hits} / ${it.misses}")
            DetailRow("命中率", "${"%.2f".format(it.hitRate * 100)}%")
            DetailRow("累计收益", "${"%.2f".format(it.netProfit)}")
            DetailRow("历史最大连中", "${if (it.maxPeriodHitStreak > 0) it.maxPeriodHitStreak else it.maxHitStreak}次")
            DetailRow("历史最大连挂", "${if (it.maxPeriodMissStreak > 0) it.maxPeriodMissStreak else it.maxMissStreak}次")
            DetailRow("历史最大连中跳", "${it.maxHitStreak}次")
            DetailRow("历史最大连挂跳", "${it.maxMissStreak}次")
            DetailRow("最大回撤", "${"%.2f".format(it.maxDrawdown)}")
        }
    }
}

/**
 * 全屏计划详情（独立页，不堆在列表底部）
 */
@Composable
private fun PlanDetailFullPage(
    plan: PlanDefinition,
    report: NovaPlanAnalytics.ChartReport?,
    history: List<DrawRecord>,
    running: Boolean,
    backtestStage: Int,
    periods: Int,
    tab: WorkbenchTab,
    onTab: (WorkbenchTab) -> Unit,
    onBack: () -> Unit,
    onStage: (Int) -> Unit,
    onRefresh: () -> Unit,
    onPeriodsChange: (Int) -> Unit,
    onFavorite: () -> Unit,
    isFavorite: Boolean,
    resolveRuntime: (String) -> PlanRuntime,
    sourceLabel: String,
    candidates: List<PlanDefinition>,
    clipboard: ClipboardManager,
    vm: MainViewModel,
    nextIssue: String,
    historyPage: Int = 40,
    onHistoryPage: (Int) -> Unit = {},
    onSetBotSource: () -> Unit = {}
) {
    val planRt = resolveRuntime(plan.planId)
    val pts = report?.points.orEmpty()
    // 胜率/连跳只认当前报告（禁止回落到一期缓存）
    val hits = report?.hits ?: 0
    val misses = report?.misses ?: 0
    val total = hits + misses
    val rate = if (total > 0) hits * 100.0 / total else 0.0
    // 一期按期连续；二期/三期按轮连续（来自 ChartReport 轮统计）
    val curHit = report?.currentHitStreak
        ?: if (pts.isNotEmpty()) pts.takeLastWhile { it.hit }.size else 0
    val curMiss = report?.currentMissStreak
        ?: if (pts.isNotEmpty()) pts.takeLastWhile { !it.hit }.size else 0
    // 历史最大连中/连挂=期级；历史最大连中跳/连挂跳=轮级
    val maxHitPeriod = report?.maxPeriodHitStreak?.takeIf { it > 0 } ?: report?.maxHitStreak ?: 0
    val maxMissPeriod = report?.maxPeriodMissStreak?.takeIf { it > 0 } ?: report?.maxMissStreak ?: 0
    val maxHitJump = report?.maxHitStreak ?: 0
    val maxMissJump = report?.maxMissStreak ?: 0
    val maxHit = maxHitJump
    val maxMiss = maxMissJump
    val zhuFlags = remember(report, backtestStage, pts) {
        when {
            backtestStage >= 2 && report?.roundResults?.isNotEmpty() == true -> report.roundResults
            else -> pts.map { it.hit }
        }
    }
    val zhuHit2 = remember(zhuFlags) { countZhuSegments(zhuFlags, 2, true) }
    val zhuMiss2 = remember(zhuFlags) { countZhuSegments(zhuFlags, 2, false) }
    val zhuHit3 = remember(zhuFlags) { countZhuSegments(zhuFlags, 3, true) }
    val zhuMiss3 = remember(zhuFlags) { countZhuSegments(zhuFlags, 3, false) }
    // 实时开奖态：MainViewModel 已由后台心跳/前台恢复持续更新。
    // 这里同时监听最新期号、开奖号码和下期期号，开奖后立即触发 Compose 重组。
    val latestDraw = vm.latest.value
    val countdown = vm.countdownText.value
    val currentLottery = vm.currentLottery.value
    // 二/三期必须分别读取各自目标期的“锁定预测”，绝不能只取下一期一期预测。
    // 例如三期轮可能是：一期=大、二期=小、三期=大；同时每一期还可能对应不同倍投结果。
    val stagePredictions = remember(
        plan.planId,
        latestDraw?.issue,
        nextIssue,
        backtestStage,
        vm.planVM.currentPredictions.value,
        vm.planVM.novaCurrentPredictions.value,
        vm.planHistory.value,
        vm.planVM.novaPlanHistory.value
    ) {
        val all = (vm.planVM.currentPredictions.value + vm.planVM.novaCurrentPredictions.value +
            vm.planHistory.value + vm.planVM.novaPlanHistory.value)
            .filter { it.planId == plan.planId }
        val locked = all.filter { !it.settled && it.targetIssue == nextIssue }.firstOrNull()
        val settled = all.filter { it.settled && it.hit != null }
            .sortedByDescending { it.targetIssue.toLongOrNull() ?: Long.MIN_VALUE }

        // 当前实际下一期对应哪个倍投阶段：连续“前一期未中”的长度 + 1。
        // 上一期命中后立即回到一期；不会把未来47/48期当成当前46期的二/三期。
        var previousMisses = 0
        var expected = nextIssue.toLongOrNull()?.minus(1L)
        for (rec in settled) {
            val n = rec.targetIssue.toLongOrNull() ?: continue
            if (expected != null && n == expected) {
                if (rec.hit == true) break
                previousMisses++
                expected = expected - 1L
            } else if (expected == null || n < expected) {
                break
            }
        }
        val activeStage = if (backtestStage <= 1) 1 else
            (previousMisses + 1).coerceIn(1, backtestStage.coerceIn(1, 3))

        val fallback = if (locked == null && history.size >= 5) {
            NovaPlanAnalytics.predict(plan, history, outputCountFor(plan, vm))?.output
        } else null
        val activeRecord = locked ?: fallback?.let { out ->
            PlanPredictionRecord(
                planId = plan.planId,
                lotteryKey = history.lastOrNull()?.lotteryKey.orEmpty(),
                targetIssue = nextIssue,
                cutoffIssue = history.lastOrNull()?.issue.orEmpty(),
                output = out,
                scoreAtPredict = 0.0,
                weightAtPredict = 0.0,
                planName = plan.planName,
                category = plan.category,
                algorithmId = plan.algorithm,
                paramSummary = "实时计算 · window=${plan.window} · cycle=${plan.cyclePeriods}",
                sourceType = if (plan.planId.startsWith("NOVA")) "NOVA" else "LEGACY",
                playType = plan.playType,
                positionIndex = plan.positionIndex
            )
        }

        (1..backtestStage.coerceIn(1, 3)).map { leg ->
            Triple(leg, nextIssue, if (leg == activeStage) activeRecord else null)
        }
    }
    // 历史记录顶部必须始终能显示“下期预测”。
    // 优先使用已经锁定的下一期记录；如果实时记录尚未写入，则即时按当前历史计算一期预测，
    // 这样开奖刷新/Compose 重组时不会因为 currentPredictions 暂时为空而让下期预测消失。
    val nextPred = stagePredictions.firstOrNull { it.first == 1 }?.third?.output
        ?: run {
            val oc = outputCountFor(plan, vm)
            if (nextIssue.isNotBlank() && nextIssue != "-" && history.size >= 6) {
                NovaPlanAnalytics.predict(plan, history, oc)?.output
            } else null
        }
    val lastSettled = pts.lastOrNull()
    val stageLabel = when (backtestStage) { 2 -> "二期"; 3 -> "三期"; else -> "一期" }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = CaiTokens.S12, vertical = CaiTokens.S8),
        verticalArrangement = Arrangement.spacedBy(CaiTokens.S8),
        contentPadding = PaddingValues(bottom = CaiTokens.ScreenBottom)
    ) {
        item {
            GlobalCard {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    PrimaryButton("← 返回列表", onBack, ghost = true)
                    Spacer(Modifier.weight(1f))
                    Text(if (isFavorite) "★" else "☆", color = CaiTokens.Warning, modifier = Modifier.clickable(onClick = onFavorite))
                }
                Text(plan.planName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                CaptionMuted("${currentLottery.name} · $sourceLabel · ${plan.playType} · 计划周期${plan.cyclePeriods}期 · 回测口径$stageLabel")
            }
        }
        item {
            // 对标截图的实时开奖头部：只读当前彩种的 MainViewModel 数据，不跨彩种复用。
            GlobalCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Column(Modifier.weight(1f)) {
                        CaptionMuted("最新开奖")
                        Text("第${latestDraw?.issue ?: "—"}期", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        val nums = latestDraw?.numbers.orEmpty()
                        if (nums.isNotEmpty()) {
                            Row(
                                Modifier.padding(top = 7.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                nums.take(10).forEach { n ->
                                    Surface(
                                        shape = MaterialTheme.shapes.extraLarge,
                                        color = MaterialTheme.colorScheme.errorContainer
                                    ) {
                                        Text(
                                            n.toString(),
                                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp
                                        )
                                    }
                                }
                            }
                        } else {
                            CaptionMuted("暂无开奖号码")
                        }
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        CaptionMuted("下一期")
                        Text(
                            if (nextIssue.isNotBlank() && nextIssue != "-") "第${nextIssue}期" else "等待开奖",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            countdown,
                            modifier = Modifier.padding(top = 5.dp),
                            fontSize = 21.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = { vm.softRefreshLatest() }) {
                        Text("↻ 刷新开奖结果")
                    }
                }
                CaptionMuted(
                    if (latestDraw?.drawTime?.isNotBlank() == true)
                        "开奖时间 ${latestDraw.drawTime.take(19).replace('T', ' ')} · 数据实时同步中"
                    else "数据实时同步中"
                )
            }
        }
        item {
            GlobalCard {
                Text("回测口径（切换会重算胜率与历史）", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(1 to "一期", 2 to "二期", 3 to "三期").forEach { (s, lab) ->
                        FilterChip(
                            selected = backtestStage == s,
                            onClick = { onStage(s) },
                            label = { Text(lab) }
                        )
                    }
                }
                CaptionMuted(
                    when (backtestStage) {
                        2 -> "二期轮口径：锁一次预测最多追2期；任一期中=本轮中，两期全挂=本轮挂。胜率=中轮/总轮（高于一期属正常）。"
                        3 -> "三期轮口径：锁一次预测最多追3期；任一期中=本轮中，三期全挂=本轮挂。胜率=中轮/总轮（高于一期属正常）。"
                        else -> "一期：每期独立预测、独立结算。胜率=中期/总期。"
                    }
                )
            }
        }
        item {
            GlobalCard(containerColor = MaterialTheme.colorScheme.secondaryContainer) {
                // 重要：二期/三期每一把都是独立的目标期预测，允许结果不同；
                // 同时保留各自锁定的预测/倍投口径，不能统一显示成“一期预测”。
                Text(
                    if (backtestStage == 1) "下一期预测" else "下一轮预测结果",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(6.dp))
                if (backtestStage >= 2 && stagePredictions.isNotEmpty()) {
                    CaptionMuted("当前期按实际滚动轮次显示；二期/三期不会提前使用未来期号")
                }
                stagePredictions.forEach { (leg, issue, rec) ->
                    val label = when (leg) {
                        1 -> "一期预测"
                        2 -> "二期预测"
                        else -> "三期预测"
                    }
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            label,
                            modifier = Modifier.width(82.dp),
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )
                        Text(
                            when {
                                rec != null -> rec.output
                                leg == stagePredictions.firstOrNull { it.third != null }?.first -> "计算中…"
                                else -> "未进入"
                            },
                            modifier = Modifier.weight(1f),
                            fontSize = if (leg == 1) 20.sp else 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    if (rec != null && rec.paramSummary.isNotBlank()) {
                        CaptionMuted("对应开奖期：第${issue}期 · 锁定参数：${rec.paramSummary}")
                    } else if (issue.isNotBlank() && issue != "-") {
                        CaptionMuted("对应开奖期：第${issue}期")
                    }
                    if (leg < backtestStage.coerceIn(1, 3)) HorizontalDivider()
                }
                if (lastSettled != null) {
                    CaptionMuted(
                        "最近回测 ${lastSettled.issue.takeLast(6)}：${lastSettled.prediction} → ${if (lastSettled.hit) "中" else "挂"}"
                    )
                }
                CaptionMuted("一期始终是当前期；二/三期只在前一把未中时进入。中间任一期命中后，下一轮从命中期滚动；未完成不计挂。")
                // —— 连跳面板（对标竞品：次数清晰、周期统计）——
                val unit = if (backtestStage >= 2) "次" else "次" // 统一显示「次」
                val todayFlags = remember(pts, history) {
                    val latest = history.lastOrNull()?.issue.orEmpty()
                    val dayKey = when {
                        latest.length >= 8 -> latest.take(8)
                        latest.length >= 6 -> latest.take(6)
                        else -> latest.take(4)
                    }
                    val dayPts = pts.filter { it.issue.startsWith(dayKey) }
                    if (dayPts.isNotEmpty()) dayPts.map { it.hit }
                    else pts.takeLast(minOf(120, pts.size)).map { it.hit }
                }
                // 二期三期优先用轮序列算今日最大
                val todayHitMax = if (backtestStage >= 2 && report?.roundResults?.isNotEmpty() == true) {
                    maxRunStreak(report.roundResults.takeLast(minOf(60, report.roundResults.size)), true)
                } else maxRunStreak(todayFlags, true)
                val todayMissMax = if (backtestStage >= 2 && report?.roundResults?.isNotEmpty() == true) {
                    maxRunStreak(report.roundResults.takeLast(minOf(60, report.roundResults.size)), false)
                } else maxRunStreak(todayFlags, false)
                Spacer(Modifier.height(8.dp))
                GlobalCard {
                    // 当前状况统一按轮口径；一期时轮=期。
                    val streaks = report?.let { runtimeStreaks(it) } ?: intArrayOf(0, 0, 0, 0)
                    val periodHit = streaks[0]
                    val periodMiss = streaks[1]
                    Text(
                        "当前 连中${periodHit} / 连挂${periodMiss}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Text(
                        when {
                            curHit > 0 -> "当前连中跳：${curHit}次"
                            curMiss > 0 -> "当前连挂跳：${curMiss}次"
                            else -> "当前连跳：0次"
                        },
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = when {
                            curHit > 0 -> MaterialTheme.colorScheme.primary
                            curMiss > 0 -> MaterialTheme.colorScheme.error
                            else -> MaterialTheme.colorScheme.onSurface
                        }
                    )
                    CaptionMuted("连中/连挂=每期中挂；连中跳/连挂跳=周期统计（二期三期按轮）")
                    Spacer(Modifier.height(6.dp))
                    val todayPeriodHitMax = maxRunStreak(todayFlags, true)
                    val todayPeriodMissMax = maxRunStreak(todayFlags, false)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("今日最大连中：${todayPeriodHitMax}次", fontSize = 13.sp)
                        Text("今日最大连挂：${todayPeriodMissMax}次", fontSize = 13.sp)
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("历史最大连中：${maxHitPeriod}次", fontSize = 13.sp)
                        Text("历史最大连挂：${maxMissPeriod}次", fontSize = 13.sp)
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("今日最大连中跳：${maxOf(todayHitMax, curHit)}次", fontSize = 13.sp)
                        Text("今日最大连挂跳：${maxOf(todayMissMax, curMiss)}次", fontSize = 13.sp)
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("历史最大连中跳：${maxHitJump}次", fontSize = 13.sp)
                        Text("历史最大连挂跳：${maxMissJump}次", fontSize = 13.sp)
                    }
                    if (zhuHit2 + zhuMiss2 + zhuHit3 + zhuMiss3 > 0) {
                        Spacer(Modifier.height(4.dp))
                        CaptionMuted("完整珠段 双珠中${zhuHit2}/挂${zhuMiss2} · 三珠中${zhuHit3}/挂${zhuMiss3}")
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    if (running) "正在按【$stageLabel】重算…"
                    else if (report == null) "尚未回测"
                    else "【$stageLabel】中${hits} 挂${misses} · 胜率 ${"%.2f".format(rate)}%",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    WorkbenchTab.entries.forEach { t ->
                        FilterChip(selected = tab == t, onClick = { onTab(t) }, label = { Text(t.label) })
                    }
                }
            }
        }
        when (tab) {
            WorkbenchTab.DETAIL -> {
                item { PlanDetailCard(plan, report) }
                item { PlanHistoryListCard(plan, report, history, limit = historyPage.coerceAtMost(80), stage = backtestStage, pendingIssue = nextIssue, pendingPrediction = nextPred.orEmpty()) }
                item {
                    if ((report?.points?.size ?: 0) > historyPage) {
                        PrimaryButton("加载更多历史", {
                            onHistoryPage((historyPage + 40).coerceAtMost(report?.points?.size ?: historyPage))
                        }, Modifier.fillMaxWidth(), ghost = true)
                    }
                }
            }
            WorkbenchTab.REVERSE -> item { ReversePlanCard(plan, history, periods, vm, stage = backtestStage) }
            WorkbenchTab.HISTORY -> {
                item { PlanHistoryListCard(plan, report, history, limit = historyPage.coerceAtLeast(40), stage = backtestStage, pendingIssue = nextIssue, pendingPrediction = nextPred.orEmpty(), pendingStage = stagePredictions.firstOrNull { it.third != null }?.first ?: 1) }
                item {
                    PrimaryButton("加载更多历史", {
                        onHistoryPage((historyPage + 50).coerceAtMost(500))
                    }, Modifier.fillMaxWidth(), ghost = true)
                }
            }
            WorkbenchTab.TREND -> item {
                TrendCard(report, periods, onPeriodsChange = onPeriodsChange, onRun = onRefresh)
            }
            WorkbenchTab.GUIDE -> item { GuideCard(plan) }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                PrimaryButton(if (isFavorite) "已收藏" else "收藏", onFavorite, Modifier.weight(1f), ghost = true)
                PrimaryButton("复制预测", {
                    clipboard.setText(AnnotatedString("${plan.planName} ${nextPred ?: "—"} ${plan.playType}"))
                }, Modifier.weight(1f), ghost = true)
                PrimaryButton(if (running) "回测中…" else "刷新回测", onRefresh, Modifier.weight(1f), enabled = !running && history.size >= 6)
            }
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                PrimaryButton("设为挂机来源", onSetBotSource, Modifier.weight(1f))
                PrimaryButton("相反计划", { onTab(WorkbenchTab.REVERSE) }, Modifier.weight(1f), ghost = true)
            }
            CaptionMuted("设为挂机：写入挂机「收藏计划」来源并开启滚动现算；请到挂机页确认开关。")
        }
    }
}

/**
 * 历史开奖列表。号码过多（快乐8）只显示前几个；二期/三期显示追号轮次标记。
 */
private fun nextIssueLabel(issue: String, offset: Int): String {
    val n = issue.toLongOrNull() ?: return ""
    return (n + offset).toString().padStart(issue.length, '0')
}

@Composable
private fun PlanHistoryListCard(
    plan: PlanDefinition,
    report: NovaPlanAnalytics.ChartReport?,
    history: List<DrawRecord>,
    limit: Int,
    stage: Int = 1,
    pendingIssue: String = "",
    pendingPrediction: String = "",
    pendingStage: Int = 1
) {
    val cycle = plan.cyclePeriods.coerceAtLeast(1)
    val drawByIssue = remember(history) { history.associateBy { it.issue } }

    fun issueRange(firstIssue: String, count: Int): String {
        val endIssue = nextIssueLabel(firstIssue, count - 1)
        val first = firstIssue.takeLast(4)
        val last = endIssue.takeLast(4)
        return if (count <= 1 || first == last) first else "$first-$last"
    }

    fun previousIssueLabel(issue: String, offset: Int): String {
        if (offset <= 0) return issue
        val m = Regex("^(.*?)(\\d+)$").find(issue) ?: return issue
        val prefix = m.groupValues[1]
        val digits = m.groupValues[2]
        val n = digits.toLongOrNull() ?: return issue
        return prefix + (n - offset).coerceAtLeast(0).toString().padStart(digits.length, '0')
    }

    fun shortPrediction(raw: String): String {
        val cleaned = raw.removePrefix("反:")
            .substringAfter(":", raw)
            .trim()
        return cleaned.split("/", "、", ",", "，")
            .firstOrNull()?.trim()
            .orEmpty()
            .ifBlank { cleaned.take(12) }
    }

    fun numberText(issue: String): String {
        val nums = drawByIssue[issue]?.numbers.orEmpty()
        return when {
            nums.size > 6 -> nums.take(5).joinToString(",") + "…"
            nums.isNotEmpty() -> nums.joinToString(",")
            else -> ""
        }
    }

    GlobalCard {
        Text(
            "历史记录（按轮结算）· ${when (stage) { 2 -> "二期追号"; 3 -> "三期追号"; else -> "一期计划" }}",
            fontWeight = FontWeight.Bold
        )
        CaptionMuted("每轮期号连续展示；开奖后自动结算并生成下一期预测。历史开奖不会覆盖预测文字。")

        // 当前进行中的轮次：始终按照完整计划期数展示，例如 0948-0950（3/3）。
        if (pendingIssue.isNotBlank() && pendingIssue != "-" && pendingPrediction.isNotBlank()) {
            // 当前未开奖期是窗口的最后一把：二期46对应45-46，三期46对应44-46。
            // 不能再从46向未来拼47/48。
            val activePendingStage = pendingStage.coerceIn(1, stage.coerceIn(1, 3))
            val startIssue = previousIssueLabel(pendingIssue, activePendingStage - 1)
            val range = issueRange(startIssue, activePendingStage)
            val detail = buildString {
                repeat(activePendingStage) { offset ->
                    if (offset > 0) append("   ")
                    val issue = nextIssueLabel(startIssue, offset)
                    val draw = drawByIssue[issue]
                    append(issue.takeLast(4)).append("：")
                    if (draw == null) append("待开奖")
                    else append(numberText(issue).ifBlank { "已开奖" })
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(vertical = 7.dp),
                verticalAlignment = Alignment.Top
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "$range ($activePendingStage/$stage) ${plan.playType}(${shortPrediction(pendingPrediction)})",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(detail, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                }
                Spacer(Modifier.width(8.dp))
                Text(
                    if (activePendingStage > 1) "待定" else "待开奖",
                    modifier = Modifier.widthIn(min = 42.dp),
                    textAlign = TextAlign.End,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            HorizontalDivider()
        }

        if (report == null || report.points.isEmpty()) {
            CaptionMuted(if (history.size < 6) "历史数据不足，无法回测" else "正在生成历史结算…")
            return@GlobalCard
        }

        // report.points 是实际参与轮次的逐期结算点：首把命中立即结束，否则继续到 stage 把。
        // 历史列表仍按“完整计划范围”显示，所以 0939 命中 0940 时显示为 0939-0941，而不是 0939-0940。
        data class RoundRow(val points: List<NovaPlanAnalytics.ChartPoint>)
        val groups = mutableListOf<RoundRow>()
        var current = mutableListOf<NovaPlanAnalytics.ChartPoint>()
        report.points.forEach { point ->
            current += point
            if (stage <= 1 || point.hit || current.size >= stage) {
                groups += RoundRow(current.toList())
                current = mutableListOf()
            }
        }
        if (current.isNotEmpty()) groups += RoundRow(current.toList())

        groups.takeLast(limit).asReversed().forEach { row ->
            val first = row.points.first()
            val hitIndex = row.points.indexOfFirst { it.hit }
            val plannedStage = stage.coerceAtLeast(1)
            // 已结束轮次按真实消费的把数显示：首把中=1期，第二把中=2期，全挂=完整期数。
            val actualCount = row.points.size.coerceIn(1, plannedStage)
            val rangeLabel = issueRange(first.issue, actualCount)
            val prediction = shortPrediction(first.prediction)

            val resultText = when {
                hitIndex >= 0 && plannedStage >= 2 -> "中（第${hitIndex + 1}把中）"
                hitIndex >= 0 -> "中"
                row.points.size < plannedStage -> "待定"
                else -> "挂（${plannedStage}/${plannedStage}把全挂）"
            }
            val resultColor = when {
                hitIndex >= 0 -> MaterialTheme.colorScheme.primary
                row.points.size < plannedStage -> MaterialTheme.colorScheme.primary
                else -> MaterialTheme.colorScheme.error
            }

            // 第二行专门放“每一期”的开奖结果，避免长字符串与预测/状态横向挤压、遮挡。
            val detail = buildString {
                repeat(actualCount) { offset ->
                    if (offset > 0) append("   ")
                    val issue = nextIssueLabel(first.issue, offset)
                    val point = row.points.firstOrNull { it.issue == issue }
                    val draw = drawByIssue[issue]
                    append(issue.takeLast(4)).append("：")
                    when {
                        point != null && point.hit -> append("中")
                        point != null -> append("挂")
                        draw != null -> append("已开奖")
                        else -> append("待开奖")
                    }
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(vertical = 6.dp),
                verticalAlignment = Alignment.Top
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "$rangeLabel (${row.points.size}/$plannedStage) ${plan.playType}($prediction)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(2.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            detail,
                            modifier = Modifier.weight(1f),
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            "  " + (row.points.firstOrNull { it.hit }?.let { p -> numberText(p.issue) } ?: numberText(first.issue)),
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1
                        )
                    }
                }
                Spacer(Modifier.width(8.dp))
                Text(
                    resultText,
                    modifier = Modifier.widthIn(min = 72.dp),
                    textAlign = TextAlign.End,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = resultColor,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            HorizontalDivider()
        }

        CaptionMuted(
            if (stage >= 2)
                "二期/三期：一轮从连续期号开始，任一期命中即结束并计中；全部计划期数均挂才计挂；未开奖的后续期保持待开奖。"
            else
                "一期：每期独立预测、独立结算；最新目标期未开奖时显示待开奖。"
        )
    }
}

@Composable
private fun ReversePlanCard(plan: PlanDefinition, history: List<DrawRecord>, periods: Int, vm: MainViewModel, stage: Int = 1) {
    val reverse = remember(plan.planId, history.size, periods, stage) {
        NovaPlanAnalytics.chartBacktest(plan, history, periods, 10.0, stage = stage, invert = true, outputCount = when (plan.playType) { "组合" -> vm.prefs.value.comboPredCount; "数字", "位置", "定位" -> vm.prefs.value.positionTopN; else -> null })
    }
    GlobalCard {
        Text("相反计划", fontWeight = FontWeight.Bold)
        CaptionMuted("正投计划 ${plan.planName} 的方向/对错取反后的独立统计，不修改原计划。")
        DetailRow("计划名称", reverse.plan.planName)
        DetailRow("回测期数", "${reverse.periods}期")
        DetailRow("命中率", "${"%.2f".format(reverse.hitRate * 100)}%")
        DetailRow("累计收益", "${"%.2f".format(reverse.netProfit)}")
        DetailRow("最大连中", "${reverse.maxHitStreak}期")
        DetailRow("最大连挂", "${reverse.maxMissStreak}期")
    }
}

@Composable
private fun TrendCard(report: NovaPlanAnalytics.ChartReport?, periods: Int, onPeriodsChange: (Int) -> Unit, onRun: () -> Unit) {
    GlobalCard {
        Text("计划走势", fontWeight = FontWeight.Bold)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(100, 200, 500, 1000, 2000, 5000, 10000).forEach { n -> FilterChip(selected = periods == n, onClick = { onPeriodsChange(n) }, label = { Text("${n}期") }) }
        }
        PrimaryButton("刷新走势", onRun, Modifier.fillMaxWidth(), ghost = true)
        if (report == null || report.points.size < 2) {
            CaptionMuted("暂无走势数据")
        } else {
            val points = report.points.takeLast(150)
            val lineColor = MaterialTheme.colorScheme.primary
            Canvas(Modifier.fillMaxWidth().height(180.dp).padding(top = 8.dp)) {
                val min = points.minOf { it.cumulativeProfit }
                val max = points.maxOf { it.cumulativeProfit }
                val range = (max - min).coerceAtLeast(1.0)
                val path = Path()
                points.forEachIndexed { i, p ->
                    val x = if (points.size == 1) 0f else size.width * i / (points.size - 1)
                    val y = size.height - ((p.cumulativeProfit - min) / range * size.height).toFloat()
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawPath(path = path, color = lineColor, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 4f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${points.first().issue}", fontSize = 11.sp)
                Text("${points.last().issue}", fontSize = 11.sp)
            }
            DetailRow("当前趋势", report.currentTrend)
            DetailRow("累计收益", "${"%.2f".format(report.netProfit)}")
            DetailRow("最大回撤", "${"%.2f".format(report.maxDrawdown)}")
        }
    }
}

@Composable
private fun GuideCard(plan: PlanDefinition) {
    GlobalCard {
        Text("计划攻略", fontWeight = FontWeight.Bold)
        CaptionMuted("这里展示当前计划的计算口径，方便在工作台直接理解计划，而不需要跳到其它页面。")
        DetailRow("计划类型", plan.playType)
        DetailRow("计算算法", plan.algorithm)
        DetailRow("历史窗口", "最近 ${plan.window} 期")
        DetailRow("输出形式", plan.outputFormat.name)
        DetailRow("命中标准", plan.hitCriteria.name)
        DetailRow("基础概率", "${"%.1f".format(plan.baselineValue * 100)}%")
        Text("回测规则", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
        CaptionMuted("采用 walk-forward：预测某一期时只使用该期之前的开奖数据；每期独立结算，避免把未来开奖号码泄漏到历史预测。")
        CaptionMuted("过关斩将、正投/反投等资金模式属于图表回测层，不改变计划本身的预测算法。")
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        Text(label, modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
        Text(value, modifier = Modifier.weight(1.7f), fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}
