package com.caifenxi.app.data.config

import com.caifenxi.app.data.db.dao.ConsensusDao
import com.caifenxi.app.data.db.entity.ConsensusEntity
import com.caifenxi.app.domain.model.ConsensusRecord
import com.caifenxi.app.domain.model.ConsensusStats
import com.caifenxi.app.data.config.StreakCalc

class ConsensusStore(private val dao: ConsensusDao) {

    suspend fun loadAll(lotteryKey: String? = null): List<ConsensusRecord> {
        return if (lotteryKey == null) {
            emptyList()
        } else {
            dao.getByLottery(lotteryKey).map { it.toDomain() }
        }
    }

    suspend fun loadBySource(lotteryKey: String, poolSource: String): List<ConsensusRecord> {
        return dao.getByLotteryAndSource(lotteryKey, poolSource).map { it.toDomain() }
    }

    suspend fun saveAll(list: List<ConsensusRecord>) {
        if (list.isEmpty()) return
        val lotteryKey = list.first().lotteryKey
        dao.deleteByLottery(lotteryKey)
        dao.upsertAll(list.map { ConsensusEntity.fromDomain(it) })
    }

    suspend fun upsert(record: ConsensusRecord) {
        val source = record.poolSource.ifBlank { "LEGACY" }
        val existing = dao.getByLotteryIssueCategorySource(
            record.lotteryKey, record.targetIssue, record.category, source
        )
        if (existing != null) {
            if (existing.result != "待开" && record.result == "待开") return
        }
        dao.upsert(ConsensusEntity.fromDomain(record.copy(poolSource = source)))
    }

    suspend fun clear(lotteryKey: String? = null) {
        if (lotteryKey == null) {
            dao.deleteAll()
        } else {
            dao.deleteByLottery(lotteryKey)
        }
    }

    suspend fun clearBySource(lotteryKey: String, poolSource: String) {
        dao.deleteByLotteryAndSource(lotteryKey, poolSource)
    }

    suspend fun stats(lotteryKey: String): ConsensusStats {
        return computeStats(loadAll(lotteryKey))
    }

    suspend fun statsBySource(lotteryKey: String, poolSource: String): ConsensusStats {
        return computeStats(loadBySource(lotteryKey, poolSource))
    }

    companion object {
        private val MAIN_CATS = setOf("大小", "单双", "组合")

        fun computeStats(all: List<ConsensusRecord>): ConsensusStats {
            val settled = all.filter { it.result == "对" || it.result == "错" }

            val periodResults = settled
                .filter { it.category in MAIN_CATS }
                .groupBy { it.targetIssue }
                .mapNotNull { (_, rows) ->
                    val byCat = rows.groupBy { it.category }.mapValues { (_, rs) ->
                        rs.maxByOrNull { it.createdAt } ?: rs.last()
                    }
                    if (byCat.isEmpty()) return@mapNotNull null
                    val allHit = byCat.values.all { it.result == "对" }
                    val anyMiss = byCat.values.any { it.result == "错" }
                    if (!allHit && !anyMiss) return@mapNotNull null
                    val result = if (allHit) "对" else "错"
                    val ts = byCat.values.maxOf { it.createdAt }
                    Triple(byCat.values.first().targetIssue, result, ts)
                }
                .sortedWith(compareBy({ it.third }, { it.first }))

            val hit = periodResults.count { it.second == "对" }
            val miss = periodResults.count { it.second == "错" }
            val periodChrono = periodResults.map { it.second }
            val (recent, maxH, maxM) = StreakCalc.streaksOf(periodChrono)
            val (w2, w2Hit, w2Miss) = StreakCalc.windowRates(periodChrono, 2)
            val (w3, w3Hit, w3Miss) = StreakCalc.windowRates(periodChrono, 3)

            val byCat = settled.groupBy { it.category }.mapValues { (_, rows) ->
                val gChrono = StreakCalc.chronoOf(rows, { it.targetIssue }, { it.createdAt }, { it.id })
                StreakCalc.buildCategoryStats(gChrono.map { it.result })
            }

            val pendingIssues = all
                .filter { it.result == "待开" && it.category in MAIN_CATS }
                .map { it.targetIssue }
                .toSet()
                .size

            return ConsensusStats(
                total = periodResults.size + pendingIssues,
                pending = pendingIssues,
                hit = hit,
                miss = miss,
                hitRate = if (hit + miss == 0) 0.0 else hit.toDouble() / (hit + miss),
                byCategory = byCat,
                recentStreak = recent,
                maxHitStreak = maxH,
                maxMissStreak = maxM,
                twoWindows = w2,
                twoHitRate = if (w2 > 0) w2Hit.toDouble() / w2 else 0.0,
                twoMissRate = if (w2 > 0) w2Miss.toDouble() / w2 else 0.0,
                threeWindows = w3,
                threeHitRate = if (w3 > 0) w3Hit.toDouble() / w3 else 0.0,
                threeMissRate = if (w3 > 0) w3Miss.toDouble() / w3 else 0.0
            )
        }
    }
}
