package com.caifenxi.app.data.config

import android.content.Context
import com.caifenxi.app.data.db.CaiDatabase
import com.caifenxi.app.data.db.entity.ConsensusEntity
import com.caifenxi.app.data.db.entity.ManualMarkEntity
import com.caifenxi.app.data.db.entity.StatEntity
import com.caifenxi.app.domain.model.ConsensusRecord
import com.caifenxi.app.domain.model.ManualMark
import com.caifenxi.app.domain.model.StatRecord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json

/**
 * 从 LegacyJsonBackup 导入旧数据到 Room。
 * 一次性操作,导入完成后标记已导入,避免重复导入。
 */
object LegacyJsonImporter {
    private const val IMPORT_DONE = "legacy_import_done_v1"
    private val json = Json { ignoreUnknownKeys = true }

    /**
     * 执行一次性导入。如果已导入过则跳过。
     * @return 导入的记录数统计
     */
    suspend fun importOnce(context: Context, database: CaiDatabase): ImportResult = withContext(Dispatchers.IO) {
        val prefs = context.getSharedPreferences("caifenxi_legacy_backup", Context.MODE_PRIVATE)
        if (prefs.getBoolean(IMPORT_DONE, false)) {
            return@withContext ImportResult(0, 0, 0, alreadyDone = true)
        }

        var statCount = 0
        var consensusCount = 0
        var manualCount = 0

        try {
            // 导入统计记录
            val statsJson = prefs.getString("caifenxi_stats:stat_records_json", null)
            if (!statsJson.isNullOrBlank()) {
                try {
                    val records = json.decodeFromString<List<StatRecord>>(statsJson)
                    val entities = records.map { StatEntity.fromDomain(it) }
                    database.statDao().upsertAll(entities)
                    statCount = entities.size
                } catch (e: Exception) {
                    android.util.Log.e("LegacyJsonImporter", "Failed to import stats", e)
                }
            }

            // 导入共识记录
            val consensusJson = prefs.getString("caifenxi_consensus:consensus_records", null)
            if (!consensusJson.isNullOrBlank()) {
                try {
                    val records = json.decodeFromString<List<ConsensusRecord>>(consensusJson)
                    val entities = records.map { ConsensusEntity.fromDomain(it) }
                    database.consensusDao().upsertAll(entities)
                    consensusCount = entities.size
                } catch (e: Exception) {
                    android.util.Log.e("LegacyJsonImporter", "Failed to import consensus", e)
                }
            }

            // 导入手动标记
            val manualJson = prefs.getString("caifenxi_manual:manual_marks", null)
            if (!manualJson.isNullOrBlank()) {
                try {
                    val records = json.decodeFromString<List<ManualMark>>(manualJson)
                    val entities = records.map { ManualMarkEntity.fromDomain(it) }
                    database.manualMarkDao().upsertAll(entities)
                    manualCount = entities.size
                } catch (e: Exception) {
                    android.util.Log.e("LegacyJsonImporter", "Failed to import manual marks", e)
                }
            }

            // 标记导入完成
            prefs.edit().putBoolean(IMPORT_DONE, true).apply()
        } catch (e: Exception) {
            android.util.Log.e("LegacyJsonImporter", "Import failed", e)
        }

        ImportResult(statCount, consensusCount, manualCount, alreadyDone = false)
    }

    data class ImportResult(
        val statCount: Int,
        val consensusCount: Int,
        val manualCount: Int,
        val alreadyDone: Boolean
    ) {
        val totalCount: Int get() = statCount + consensusCount + manualCount
    }
}
