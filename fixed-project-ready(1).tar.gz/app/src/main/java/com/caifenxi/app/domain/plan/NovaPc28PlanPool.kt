package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.LotteryType
import com.caifenxi.app.domain.model.PlanDefinition

/** PC28：和值两面、组合、特殊形态与三个号码位置独立计划。 */
object NovaPc28PlanPool {
    val ALL: List<PlanDefinition> get() = PlanPoolV2.all(LotteryType.PC28)
    val CANDIDATES: List<PlanDefinition> get() = PlanPoolV2.candidates(LotteryType.PC28)
    fun find(planId: String): PlanDefinition? = PlanPoolV2.find(planId)
}
