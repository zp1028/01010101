package com.caifenxi.app.domain.execution

/**
 * 统一执行指令（BetCommand）。
 * 所有执行器（WebView / 无障碍）只接收统一指令，不在执行器内计算倍投/一期二期三期。
 *
 * cmdId 是整个执行系统第一主键：
 * 同一彩种同一期可能多次重试，每次重试都是新 cmdId（retryOf 指向旧任务）。
 */
data class BetCommand(
    /** 唯一执行任务ID */
    val cmdId: String,
    val lotteryKey: String,
    val issue: String,
    /** 一期/二期/三期（1/2/3） */
    val stage: Int = 1,
    /** 轮内第几腿（0 起） */
    val leg: Int = 0,
    /** 要执行的注项（大小/单双/组合/数字/文案） */
    val bets: List<BetAction> = emptyList(),
    /** 输入金额文本（由彩析算好，执行器只负责输入） */
    val amountText: String? = null,
    val source: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    /** 过期时间，超过后不得继续执行 */
    val expireAt: Long = 0L,
    val options: Map<String, String> = emptyMap()
) {
    val isExpired: Boolean
        get() = expireAt > 0L && System.currentTimeMillis() > expireAt
}

/** 单个注项动作 */
data class BetAction(
    /** 大小 / 单双 / 组合 / 数字 / 文案 */
    val category: String,
    val value: String,
    /** 动作附加区域/参数（页面适配用），透传 */
    val extra: Map<String, String> = emptyMap()
) {
    companion object {
        const val CAT_DX = "大小"
        const val CAT_DS = "单双"
        const val CAT_COMBO = "组合"
        const val CAT_NUMBER = "数字"
        const val CAT_TEXT = "文案"
    }
}
