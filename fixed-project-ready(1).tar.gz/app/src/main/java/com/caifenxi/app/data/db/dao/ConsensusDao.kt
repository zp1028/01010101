package com.caifenxi.app.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.caifenxi.app.data.db.entity.ConsensusEntity

@Dao
interface ConsensusDao {
    @Query("SELECT * FROM consensus WHERE lotteryKey = :lotteryKey ORDER BY createdAt DESC")
    suspend fun getByLottery(lotteryKey: String): List<ConsensusEntity>

    @Query("SELECT * FROM consensus ORDER BY lotteryKey ASC, createdAt DESC")
    suspend fun getAll(): List<ConsensusEntity>

    @Query("SELECT * FROM consensus WHERE lotteryKey = :lotteryKey AND category = :category ORDER BY createdAt DESC")
    suspend fun getByLotteryAndCategory(lotteryKey: String, category: String): List<ConsensusEntity>

    @Query(
        "SELECT * FROM consensus WHERE lotteryKey = :lotteryKey AND targetIssue = :targetIssue " +
            "AND category = :category AND poolSource = :poolSource LIMIT 1"
    )
    suspend fun getByLotteryIssueCategorySource(
        lotteryKey: String,
        targetIssue: String,
        category: String,
        poolSource: String
    ): ConsensusEntity?

    @Query(
        "SELECT * FROM consensus WHERE lotteryKey = :lotteryKey AND poolSource = :poolSource " +
            "ORDER BY createdAt DESC"
    )
    suspend fun getByLotteryAndSource(lotteryKey: String, poolSource: String): List<ConsensusEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(consensus: ConsensusEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(consensus: List<ConsensusEntity>)

    @Query("DELETE FROM consensus WHERE lotteryKey = :lotteryKey")
    suspend fun deleteByLottery(lotteryKey: String)

    @Query("DELETE FROM consensus WHERE lotteryKey = :lotteryKey AND poolSource = :poolSource")
    suspend fun deleteByLotteryAndSource(lotteryKey: String, poolSource: String)

    @Query("DELETE FROM consensus")
    suspend fun deleteAll()

    @Query("SELECT COUNT(*) FROM consensus WHERE lotteryKey = :lotteryKey")
    suspend fun countByLottery(lotteryKey: String): Int
}
