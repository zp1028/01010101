package com.caifenxi.app.ui.screens

import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.caifenxi.app.domain.execution.BetCommand
import com.caifenxi.app.domain.execution.BetAction
import com.caifenxi.app.domain.execution.ExecutionResult
import com.caifenxi.app.ui.ExecutorViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * WebView与Android的通信桥接器
 * 负责将预测结果传递给WebView，并接收执行结果
 */
class WebExecutorBridge(
    private val viewModel: ExecutorViewModel,
    private val onCommandExecuted: (BetCommand, ExecutionResult) -> Unit
) {

    // 当前预测结果
    private val _predictionResult = MutableStateFlow<PredictionResult?>(null)
    val predictionResult: StateFlow<PredictionResult?> = _predictionResult.asStateFlow()

    // 执行状态
    private val _executionStatus = MutableStateFlow(ExecutionStatus.IDLE)
    val executionStatus: StateFlow<ExecutionStatus> = _executionStatus.asStateFlow()

    // 执行进度
    private val _executionProgress = MutableStateFlow(0f)
    val executionProgress: StateFlow<Float> = _executionProgress.asStateFlow()

    // 执行日志
    private val _executionLogs = MutableStateFlow<List<String>>(emptyList())
    val executionLogs: StateFlow<List<String>> = _executionLogs.asStateFlow()

    /**
     * 设置预测结果
     */
    fun setPredictionResult(result: PredictionResult) {
        _predictionResult.value = result
        addLog("已接收预测结果: ${result.prediction}")
    }

    /**
     * 开始执行下注
     */
    fun startBetExecution() {
        val prediction = _predictionResult.value ?: run {
            addLog("错误: 没有预测结果")
            return
        }

        _executionStatus.value = ExecutionStatus.RUNNING
        _executionProgress.value = 0f

        // 构建下注命令
        val betCommand = BetCommand(
            cmdId = "bet_${System.currentTimeMillis()}",
            lotteryKey = prediction.lotteryType,
            issue = prediction.issue,
            amount = prediction.amount,
            odds = prediction.odds,
            betTime = System.currentTimeMillis()
        )

        // 添加预测信息到命令
        betCommand.bets.addAll(
            listOf(
                BetAction(
                    category = BetAction.CAT_DX,
                    value = prediction.predictionDx,
                    odds = prediction.odds
                ),
                BetAction(
                    category = BetAction.CAT_DS,
                    value = prediction.predictionDs,
                    odds = prediction.odds
                )
            )
        )

        // 添加位置数字（如果有）
        prediction.positionNumbers.forEach { number ->
            betCommand.bets.add(
                BetAction(
                    category = BetAction.CAT_NUMBER,
                    value = number,
                    odds = prediction.odds
                )
            )
        }

        // 执行下注
        viewModel.startTask(betCommand)
        addLog("开始执行下注命令")
    }

    /**
     * 停止执行
     */
    fun stopExecution() {
        _executionStatus.value = ExecutionStatus.STOPPED
        _executionProgress.value = 0f
        addLog("已停止执行")
    }

    /**
     * 重置状态
     */
    fun reset() {
        _predictionResult.value = null
        _executionStatus.value = ExecutionStatus.IDLE
        _executionProgress.value = 0f
        _executionLogs.value = emptyList()
        addLog("已重置状态")
    }

    /**
     * 添加日志
     */
    private fun addLog(message: String) {
        val timestamp = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
            .format(java.util.Date())
        _executionLogs.value = _executionLogs.value + "[$timestamp] $message"
    }

    /**
     * 更新执行进度
     */
    fun updateProgress(progress: Float) {
        _executionProgress.value = progress.coerceIn(0f, 1f)
    }

    /**
     * 处理执行结果
     */
    fun handleExecutionResult(result: ExecutionResult) {
        when (result.success) {
            true -> {
                _executionStatus.value = ExecutionStatus.COMPLETED
                addLog("执行成功: ${result.message}")
            }
            false -> {
                _executionStatus.value = ExecutionStatus.FAILED
                addLog("执行失败: ${result.message}")
            }
        }
    }

    /**
     * 执行状态枚举
     */
    enum class ExecutionStatus {
        IDLE,      // 空闲
        RUNNING,   // 执行中
        COMPLETED, // 已完成
        FAILED,    // 失败
        STOPPED    // 已停止
    }

    /**
     * 预测结果数据类
     */
    data class PredictionResult(
        val lotteryType: String,
        val issue: String,
        val predictionDx: String,
        val predictionDs: String,
        val amount: Double,
        val odds: Double,
        val positionNumbers: List<String> = emptyList(),
        val predictionTime: Long = System.currentTimeMillis()
    )
}

/**
 * WebView接口，用于从WebView调用Android方法
 */
class WebViewInterface(
    private val bridge: WebExecutorBridge
) {

    @JavascriptInterface
    fun onBetCommandReceived(command: String) {
        // 从WebView接收下注命令
        bridge.addLog("从WebView收到命令: $command")
    }

    @JavascriptInterface
    fun onBetResultReceived(success: Boolean, message: String) {
        // 从WebView接收执行结果
        val result = ExecutionResult(
            cmdId = "web_${System.currentTimeMillis()}",
            success = success,
            message = message,
            resultData = emptyMap()
        )
        bridge.handleExecutionResult(result)
    }

    @JavascriptInterface
    fun onPageLoaded(url: String) {
        bridge.addLog("网页已加载: $url")
    }

    @JavascriptInterface
    fun onElementFound(elementType: String, count: Int) {
        bridge.addLog("找到$elementType元素: $count个")
        // 更新进度
        when (elementType) {
            "betButton" -> bridge.updateProgress(0.2f)
            "amountInput" -> bridge.updateProgress(0.4f)
            "submitButton" -> bridge.updateProgress(0.8f)
            "confirmButton" -> bridge.updateProgress(1.0f)
        }
    }

    @JavascriptInterface
    fun onError(error: String) {
        bridge.addLog("网页错误: $error")
    }
}