package com.caifenxi.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.caifenxi.app.CaiFenXiApplication
import com.caifenxi.app.util.AndroidCompat
import com.caifenxi.app.util.RuntimeLog

/**
 * Device reboot compatibility: schedule the safe periodic worker first instead
 * of blindly starting a foreground service from the background. This avoids
 * Android 12+ background-start restrictions while still restoring sync later.
 */
class BootCompletedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) return

        try {
            val app = CaiFenXiApplication.instance
            if (app.configStore.loadPrefs().autoRefresh) {
                SyncScheduler.schedule(context.applicationContext)
                RuntimeLog.info("Boot", "已恢复后台同步计划: $action")
            }
        } catch (e: Exception) {
            RuntimeLog.warn("Boot", "恢复后台同步计划失败: ${e.javaClass.simpleName}")
        }
    }
}
