package com.caifenxi.app.ui.screens

import android.webkit.WebView
import com.caifenxi.app.util.RuntimeLog
import kotlinx.coroutines.delay

/**
 * 网页适配器，负责识别不同博彩网站的页面结构并执行下注
 */
class WebPageAdapter(
    private val webView: WebView,
    private val onProgressUpdate: (Float) -> Unit,
    private val onElementFound: (String, Int) -> Unit
) {

    // 网站类型识别
    private var websiteType: WebsiteType = WebsiteType.UNKNOWN

    // 执行状态
    private var isExecuting = false

    /**
     * 网站类型枚举
     */
    enum class WebsiteType {
        UNKNOWN,
        PK10_BET,
        K3_BET,
        PC28_BET,
        LUCKY20_BET,
        CUSTOM
    }

    /**
     * 初始化页面
     */
    fun initialize() {
        injectJavaScriptInterface()
        detectWebsiteType()
    }

    /**
     * 注入JavaScript接口
     */
    private fun injectJavaScriptInterface() {
        val jsInterface = WebViewInterface(WebExecutorBridge(null, { _, _ -> }))
        webView.addJavascriptInterface(jsInterface, "Android")
    }

    /**
     * 检测网站类型
     */
    private fun detectWebsiteType() {
        val js = """
            function detectWebsiteType() {
                const title = document.title || '';
                const url = window.location.href || '';
                const bodyText = document.body.textContent || '';
                
                let type = 'UNKNOWN';
                
                // PK10 相关特征
                if (title.includes('PK10') || url.includes('pk10') || bodyText.includes('PK10')) {
                    type = 'PK10_BET';
                }
                // 快三相关特征
                else if (title.includes('快三') || url.includes('k3') || bodyText.includes('快三')) {
                    type = 'K3_BET';
                }
                // PC28相关特征
                else if (title.includes('PC28') || url.includes('pc28') || bodyText.includes('PC28')) {
                    type = 'PC28_BET';
                }
                // 幸运20相关特征
                else if (title.includes('幸运20') || url.includes('lucky20') || bodyText.includes('幸运20')) {
                    type = 'LUCKY20_BET';
                }
                
                return type;
            }
            
            window.Android.onPageLoaded(window.location.href);
            window.Android.onElementFound('websiteType', 1);
            return detectWebsiteType();
        """.trimIndent()

        webView.evaluateJavascript(js) { result ->
            websiteType = WebsiteType.values().find { it.name == result } ?: WebsiteType.UNKNOWN
            RuntimeLog.info("WebPageAdapter", "检测到网站类型: $websiteType")
        }
    }

    /**
     * 执行下注
     */
    suspend fun executeBet(
        predictionDx: String,
        predictionDs: String,
        amount: String,
        positionNumbers: List<String> = emptyList()
    ): Boolean {
        if (isExecuting) {
            RuntimeLog.warn("WebPageAdapter", "正在执行中，忽略重复调用")
            return false
        }

        isExecuting = true
        try {
            RuntimeLog.info("WebPageAdapter", "开始执行下注: dx=$predictionDx ds=$predictionDs amount=$amount")
            
            // 步骤1: 查找下注按钮
            if (!findAndClickBetButton()) {
                RuntimeLog.error("WebPageAdapter", "未找到下注按钮")
                return false
            }
            
            // 步骤2: 查找金额输入框
            if (!findAndInputAmount(amount)) {
                RuntimeLog.error("WebPageAdapter", "未找到金额输入框")
                return false
            }
            
            // 步骤3: 选择大小
            if (!selectBetType(predictionDx, "大小")) {
                RuntimeLog.error("WebPageAdapter", "未找到大小选项")
                return false
            }
            
            // 步骤4: 选择单双
            if (!selectBetType(predictionDs, "单双")) {
                RuntimeLog.error("WebPageAdapter", "未找到单双选项")
                return false
            }
            
            // 步骤5: 选择位置数字
            positionNumbers.forEach { number ->
                if (!selectPositionNumber(number)) {
                    RuntimeLog.warn("WebPageAdapter", "位置数字 $number 选择失败")
                }
            }
            
            // 步骤6: 提交下注
            if (!submitBet()) {
                RuntimeLog.error("WebPageAdapter", "提交下注失败")
                return false
            }
            
            RuntimeLog.info("WebPageAdapter", "下注执行成功")
            return true
            
        } catch (e: Exception) {
            RuntimeLog.error("WebPageAdapter", "下注执行异常: ${e.message}")
            return false
        } finally {
            isExecuting = false
        }
    }

    /**
     * 查找并点击下注按钮
     */
    private fun findAndClickBetButton(): Boolean {
        val js = """
            function findBetButton() {
                const selectors = [
                    'button:contains("下注")',
                    'button:contains("投注")',
                    'button:contains("Bet")',
                    '.bet-button',
                    '.submit-btn',
                    'input[type="submit"]',
                    '[onclick*="bet"]',
                    '[onclick*="submit"]'
                ];
                
                for (let selector of selectors) {
                    const elements = document.querySelectorAll(selector);
                    for (let el of elements) {
                        if (el.offsetParent && el.offsetParent.style.display !== 'none') {
                            el.click();
                            window.Android.onElementFound('betButton', 1);
                            return true;
                        }
                    }
                }
                return false;
            }
            
            return findBetButton();
        """.trimIndent()

        return executeJsFunction(js, "查找下注按钮")
    }

    /**
     * 查找并输入金额
     */
    private fun findAndInputAmount(amount: String): Boolean {
        val js = """
            function inputAmount(amount) {
                const inputs = document.querySelectorAll('input[type="number"], input[type="text"], input');
                for (let input of inputs) {
                    if (input.offsetParent && input.offsetParent.style.display !== 'none') {
                        input.value = amount;
                        input.dispatchEvent(new Event('input', {bubbles: true}));
                        input.dispatchEvent(new Event('change', {bubbles: true}));
                        window.Android.onElementFound('amountInput', 1);
                        return true;
                    }
                }
                return false;
            }
            
            return inputAmount('$amount');
        """.trimIndent()

        return executeJsFunction(js, "输入金额")
    }

    /**
     * 选择下注类型
     */
    private fun selectBetType(value: String, type: String): Boolean {
        val js = """
            function selectBetType(value, type) {
                const buttons = document.querySelectorAll('button, .btn, [class*="button"], [class*="btn"]');
                for (let btn of buttons) {
                    if (btn.textContent && btn.textContent.includes(value)) {
                        btn.click();
                        window.Android.onElementFound('${type}Button', 1);
                        return true;
                    }
                }
                return false;
            }
            
            return selectBetType('$value', '$type');
        """.trimIndent()

        return executeJsFunction(js, "选择$type")
    }

    /**
     * 选择位置数字
     */
    private fun selectPositionNumber(number: String): Boolean {
        val js = """
            function selectPositionNumber(num) {
                const buttons = document.querySelectorAll('button, .btn, [class*="button"], [class*="btn"]');
                for (let btn of buttons) {
                    if (btn.textContent && btn.textContent.includes(num)) {
                        btn.click();
                        return true;
                    }
                }
                return false;
            }
            
            return selectPositionNumber('$number');
        """.trimIndent()

        return executeJsFunction(js, "选择位置数字")
    }

    /**
     * 提交下注
     */
    private fun submitBet(): Boolean {
        val js = """
            function submitBet() {
                const submitButtons = document.querySelectorAll('button:contains("确认"), button:contains("提交"), button:contains("确认下注"), button:contains("提交下注")');
                for (let btn of submitButtons) {
                    if (btn.offsetParent && btn.offsetParent.style.display !== 'none') {
                        btn.click();
                        window.Android.onElementFound('submitButton', 1);
                        return true;
                    }
                }
                return false;
            }
            
            return submitBet();
        """.trimIndent()

        return executeJsFunction(js, "提交下注")
    }

    /**
     * 执行JavaScript函数
     */
    private fun executeJsFunction(js: String, operation: String): Boolean {
        return try {
            webView.evaluateJavascript(js) { result ->
                if (result == "true") {
                    RuntimeLog.info("WebPageAdapter", "$operation 成功")
                    onProgressUpdate(1.0f)
                } else {
                    RuntimeLog.error("WebPageAdapter", "$operation 失败")
                    onProgressUpdate(0f)
                }
            }
            true
        } catch (e: Exception) {
            RuntimeLog.error("WebPageAdapter", "$operation 异常: ${e.message}")
            false
        }
    }

    /**
     * 清理状态
     */
    fun cleanup() {
        isExecuting = false
        RuntimeLog.info("WebPageAdapter", "状态已清理")
    }
}