package com.caifenxi.app.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.caifenxi.app.ui.screens.BetScreen
import com.caifenxi.app.ui.screens.HistoryScreen
import com.caifenxi.app.ui.screens.HomeScreen
import com.caifenxi.app.ui.screens.LabScreen
import com.caifenxi.app.ui.screens.PlanScreen
import com.caifenxi.app.ui.screens.PredictScreen
import com.caifenxi.app.ui.screens.MoreScreen
import com.caifenxi.app.ui.screens.NovaPlanScreen
import com.caifenxi.app.ui.screens.ChartScreen
import com.caifenxi.app.ui.screens.PlanWorkbenchScreen
import com.caifenxi.app.ui.screens.WebBetScreen
import com.caifenxi.app.ui.screens.ExecutorControlScreen
import com.caifenxi.app.ui.screens.ExecutorLogScreen
import com.caifenxi.app.ui.components.GlobalStatusBar

private enum class Tab(val route: String, val label: String, val icon: ImageVector) {
    Home("home", "首页", Icons.Filled.Home),
    Predict("predict", "预测", Icons.Filled.Analytics),
    Plan("plan", "原计划", Icons.Filled.ListAlt),
    Nova("nova", "新计划", Icons.Filled.ListAlt),
    Chart("chart", "图表", Icons.Filled.ShowChart),
    Workbench("workbench", "工作台", Icons.Filled.ListAlt),
    Bet("bet", "挂机", Icons.Filled.ListAlt),
    More("more", "更多", Icons.Filled.MoreHoriz),
}

@Composable
fun CaiFenXiApp(viewModel: MainViewModel) {
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route

    val lottery = viewModel.currentLottery.value
    val history = viewModel.history.value
    val latest = history.lastOrNull()?.issue ?: "-"
    val target = viewModel.nextIssueText.value
    val status = viewModel.statusText.value
    val err = viewModel.errorMessage.value

    Scaffold(
        topBar = {
            GlobalStatusBar(
                lotteryName = lottery.name,
                latestIssue = latest,
                targetIssue = target,
                statusText = status,
                errorMessage = err,
                historySize = history.size,
                onSync = { viewModel.loadData() }
            )
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                Tab.entries.forEach { tab ->
                    NavigationBarItem(
                        selected = currentRoute == tab.route,
                        onClick = {
                            navController.navigate(tab.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label, fontSize = 11.sp) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Tab.Home.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(Tab.Home.route) { HomeScreen(viewModel) }
            composable(Tab.Predict.route) { PredictScreen(viewModel) }
            composable("more") { MoreScreen(viewModel, navController) }
            composable("stats") { HistoryScreen(viewModel) }
            composable("lab") { LabScreen(viewModel) }
            composable("settings") { com.caifenxi.app.ui.screens.SettingsScreen(viewModel) { navController.navigate("accessibility") } }
            composable("accessibility") { com.caifenxi.app.ui.screens.AccessibilityScreen(viewModel) }
            composable(Tab.Plan.route) { PlanScreen(viewModel) { navController.navigate(Tab.Nova.route) { launchSingleTop = true } } }
            composable(Tab.Nova.route) { NovaPlanScreen(viewModel) }
            composable(Tab.Chart.route) { ChartScreen(viewModel) }
            composable(Tab.Workbench.route) { PlanWorkbenchScreen(viewModel) }
            composable(Tab.Bet.route) { BetScreen(viewModel) }
            composable("web_bet") { WebBetScreen(viewModel) { navController.popBackStack() } }

            composable("executor_control") { ExecutorControlScreen() }
            composable("executor_logs") { ExecutorLogScreen() }
        }
    }
}