package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.LotteryType
import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanHitCriteria
import com.caifenxi.app.domain.model.PlanOutputFormat

/**
 * 模仿主流「计划 App」的计划命名与策略口径：
 * 路珠长龙、遗漏回补、连中跟/连挂反、双珠/三珠反向、定板、杀热等。
 * 与 PlanPoolV2 矩阵海量生成区分：数量精简、名称可读、周期明确。
 */
object PlanAppStylePool {

    private val basicCache = java.util.concurrent.ConcurrentHashMap<LotteryType, List<PlanDefinition>>()
    private val extremeCache = java.util.concurrent.ConcurrentHashMap<LotteryType, List<PlanDefinition>>()

    private data class Spec(
        val code: String,
        val title: String,
        val algo: String,
        val window: Int,
        val cycle: Int,
        val play: String,
        val pos: Int = -1
    )

    private fun specsFor(type: LotteryType): List<Spec> {
        val base = mutableListOf<Spec>()
        val plays = when (type) {
            LotteryType.K3 -> listOf("大小", "单双")
            LotteryType.YDH -> listOf("大小", "单双", "龙虎")
            LotteryType.PC28, LotteryType.LUCK20 -> listOf("大小", "单双", "组合")
            else -> listOf("大小", "单双", "组合")
        }
        plays.forEach { play ->
            base += Spec("LZ", "路珠长龙跟踪", "LUZHU", 30, 1, play)
            base += Spec("LZ2", "路珠两期定", "LUZHU", 50, 2, play)
            base += Spec("GZ", "连中跟连挂反", "GENZHU", 40, 1, play)
            base += Spec("YL", "遗漏回补", "YILOU_BU", 60, 1, play)
            base += Spec("SR", "杀热侧", "SHA_RE", 20, 1, play)
            base += Spec("FZ", "反珠切面", "FANZHU", 30, 1, play)
            base += Spec("S2", "双珠连挂反向", "SHUANGZHU", 40, 1, play)
            base += Spec("S3", "三珠连挂反向", "SANZHU", 50, 1, play)
            base += Spec("DB", "定板节奏", "DINGBAN", 24, 3, play)
            base += Spec("CL", "长龙续跟", "CHANGLOONG", 80, 1, play)
        }
        // 个位/定位类（PK 名次）
        if (type == LotteryType.PKS) {
            listOf(0 to "冠军", 1 to "亚军", 2 to "第三").forEach { (idx, label) ->
                base += Spec("W$idx", "${label}单双·路珠", "LUZHU", 30, 1, "名次单双", idx)
                base += Spec("W${idx}S2", "${label}单双·双珠反", "SHUANGZHU", 40, 1, "名次单双", idx)
                base += Spec("W${idx}YL", "${label}单双·遗漏", "YILOU_BU", 50, 1, "名次单双", idx)
            }
        }
        return base
    }

    fun basic(type: LotteryType): List<PlanDefinition> = basicCache.getOrPut(type) {
        specsFor(type).map { s ->
            val id = "APP-${type.name}-${s.play}-${s.pos}-${s.code}-W${s.window}-C${s.cycle}"
            val posTag = if (s.pos >= 0) "·位${s.pos + 1}" else ""
            PlanDefinition(
                planId = id,
                planName = "${s.title}·${s.play}$posTag·${s.cycle}期",
                category = "计划App风格",
                algorithm = s.algo,
                window = s.window,
                cyclePeriods = s.cycle,
                playType = s.play,
                positionIndex = s.pos,
                outputFormat = PlanOutputFormat.DIRECTION,
                hitCriteria = PlanHitCriteria.DIRECTION_MATCH,
                baselineValue = if (s.play == "组合") 0.25 else 0.50,
                participateConsensus = s.play in listOf("大小", "单双", "组合", "龙虎"),
                participateCombo = s.play == "组合",
                supportedTypes = setOf(type)
            )
        }
    }

    /** 新计划池优先展示的 App 风格核心集 */
    fun core(type: LotteryType): List<PlanDefinition> = basic(type)

    /** 极限：全量 App 风格变体（窗口×周期×算法），结果按彩种缓存，只生成一次 */
    fun extreme(type: LotteryType): List<PlanDefinition> = extremeCache.getOrPut(type) {
        val windows = listOf(15, 25, 40, 60, 100)
        val cycles = listOf(1, 2, 3)
        val algos = listOf(
            "LUZHU" to "路珠",
            "GENZHU" to "跟注",
            "YILOU_BU" to "遗漏",
            "SHUANGZHU" to "双珠",
            "SANZHU" to "三珠",
            "SHA_RE" to "杀热",
            "FANZHU" to "反珠",
            "CHANGLOONG" to "长龙"
        )
        val plays = when (type) {
            LotteryType.K3 -> listOf("大小", "单双")
            else -> listOf("大小", "单双", "组合")
        }
        val out = ArrayList<PlanDefinition>()
        plays.forEach { play ->
            algos.forEach { (algo, tag) ->
                windows.forEach { w ->
                    cycles.forEach { c ->
                        val id = "APPX-${type.name}-$play-$algo-W$w-C$c"
                        out += PlanDefinition(
                            planId = id,
                            planName = "$tag·${play}·${w}窗·${c}周",
                            category = "计划App极限",
                            algorithm = algo,
                            window = w,
                            cyclePeriods = c,
                            playType = play,
                            positionIndex = -1,
                            outputFormat = PlanOutputFormat.DIRECTION,
                            hitCriteria = PlanHitCriteria.DIRECTION_MATCH,
                            baselineValue = if (play == "组合") 0.25 else 0.50,
                            weightCap = 0.85,
                            participateConsensus = play != "组合",
                            participateCombo = play == "组合",
                            supportedTypes = setOf(type)
                        )
                    }
                }
            }
        }
        out
    }
}
