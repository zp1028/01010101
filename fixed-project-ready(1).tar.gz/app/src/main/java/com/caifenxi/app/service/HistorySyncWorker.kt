package com.caifenxi.app.service

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.caifenxi.app.CaiFenXiApplication
import com.caifenxi.app.domain.engine.ConsensusEngine
import com.caifenxi.app.domain.engine.PredictEngine
import com.caifenxi.app.domain.engine.StatsEngine
import com.caifenxi.app.domain.model.LotteryConfig
import com.caifenxi.app.domain.plan.PlanEngine
import kotlin.coroutines.coroutineContext
import kotlinx.coroutines.Job

/**
 * 后台同步 Worker:
 * 1. 拉取开奖历史并缓存到 Room
 * 2. 结算统计记录与共识记录(只结算「待开」,重复运行安全)
 * 3. 生成下一期计划预测并写入待开共识(供 App 内展示)
 * 4. 同步完成后发送通知
 */
class HistorySyncWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val app = CaiFenXiApplication.instance
        val prefs = app.configStore.loadPrefs()
        val config = LotteryConfig.findByKey(prefs.selectedLotteryKey) ?: LotteryConfig.CATALOG.first()
        return try {
            val workLimit = prefs.workingHistoryLimit.coerceIn(
                com.caifenxi.app.domain.model.ApiConfig.WORKING_HISTORY_MIN,
                com.caifenxi.app.domain.model.ApiConfig.WORKING_HISTORY_MAX
            )
            val (rows, _, _) = app.drawRepository.fetchAndCacheHistory(config, workLimit = workLimit)
            if (rows.isEmpty()) return Result.retry()

            // 2. 结算统计与共识(只结算「待开」,幂等)
            val key = config.key
            StatsEngine.settleWithDraws(app.statStore, key, rows)
            ConsensusEngine.settleWithDraws(app.consensusStore, key, rows)

            // 3. 生成下一期计划预测与共识(独立实例,写入持久化的 ConsensusStore)
            if (rows.size >= 40) {
                runCatching {
                    val engine = PlanEngine()
                    // 加载用户自定义计划(与前台保持一致)
                    val customPlans = app.customPlanDao.getByLottery(key)
                        .filter { it.enabled }
                        .map { it.toDomain().toDefinition() }
                    engine.setCustomPlans(customPlans)
                    // 限 500 期 + 协作取消:Worker 被 stop 后不再继续占 CPU
                    engine.backtest(rows, prefs, minWarm = 30, forceFull = false) {
                        coroutineContext[Job]?.isActive != true
                    }
                    val target = PredictEngine.suggestNextIssue(rows.last().issue)
                    val cutoff = rows.last().issue
                    val preds = engine.predictForNext(rows, prefs, target, cutoff)
                    if (preds.isNotEmpty()) {
                        val consensus = engine.consensus(key, target, preds)
                        if (consensus.isNotEmpty()) {
                            ConsensusEngine.recordPending(app.consensusStore, key, target, consensus, poolSource = "LEGACY")
                        }
                    }
                }
            }

            // 4. 同步完成通知
            val latest = rows.last()
            val summary = listOfNotNull(latest.dx, latest.ds, latest.combo)
                .joinToString(" ") + " " + latest.numbers.take(5).joinToString(",")
            NotificationHelper.notifySyncDone(applicationContext, rows.size, latest.issue, summary)
            Result.success()
        } catch (e: Exception) {
            if (runAttemptCount >= 3) Result.failure() else Result.retry()
        }
    }
}
