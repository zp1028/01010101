package com.caifenxi.app.domain.execution

/**
 * 统一执行任务（第一阶段：cmdId 第一主键 + 彩种/期号隔离 + 生命周期）。
 *
 * 一次具体执行 = 一个 cmdId；
 * 同一彩种同一期可能多次重试，每次是独立任务，通过 retryOf 串起历史。
 */
data class ExecutionTask(
    /** 唯一任务ID（整个系统第一主键） */
    val cmdId: String,
    /** 彩种标识 */
    val lotteryKey: String,
    /** 目标期号 */
    val issue: String,
    /** 一期/二期/三期口径（1/2/3），仅透传，不在此计算 */
    val stage: Int = 1,
    /** 轮内第几腿（0 起） */
    val leg: Int = 0,
    /** 大小：大/小/null=不执行 */
    val dx: String? = null,
    /** 单双：单/双/null=不执行 */
    val ds: String? = null,
    /** 金额文本（倍投/自由输入由彩析算好传入） */
    val amountText: String? = null,
    /** 组合：大单/大双/小单/小双 */
    val combo: String? = null,
    /** 位置号码（数字玩法） */
    val predNumbers: List<String> = emptyList(),
    /** 文案动作（网站「确认」「投注」等），由适配层转成动作 */
    val textActions: List<String> = emptyList(),
    /** 来源说明（挂机/悬浮窗/手动） */
    val source: String = "",
    /** 执行器：webview / accessibility */
    val executor: String = "",
    val status: TaskStatus = TaskStatus.CREATED,
    val retryCount: Int = 0,
    /** 若为重试任务，指向被重试的原 cmdId */
    val retryOf: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val expireAt: Long = 0L,
    val lastError: String? = null,
    val result: String? = null
) {
    enum class TaskStatus {
        CREATED,
        PUBLISHED,
        RECEIVED,
        VALIDATING,
        READY,
        EXECUTING,
        VERIFYING,
        SUCCESS,
        FAILED,
        UNKNOWN,
        EXPIRED,
        CANCELLED
    }

    val isTerminal: Boolean
        get() = status in TERMINAL

    fun copyState(
        status: TaskStatus = this.status,
        updatedAt: Long = System.currentTimeMillis(),
        lastError: String? = this.lastError,
        result: String? = this.result
    ): ExecutionTask = copy(
        status = status,
        updatedAt = updatedAt,
        lastError = lastError,
        result = result
    )

    companion object {
        val TERMINAL = setOf(
            TaskStatus.SUCCESS,
            TaskStatus.FAILED,
            TaskStatus.UNKNOWN,
            TaskStatus.EXPIRED,
            TaskStatus.CANCELLED
        )
    }
}
