package com.caifenxi.app.domain.execution

/**
 * 执行器统一接口。
 *
 * 彩析核心负责：预测/计划/倍投/金额/一期二期三期；
 * 执行器只负责：接收 BetCommand → 页面交互 → 返回 ExecutionResult。
 */
interface Executor {

    /** 执行器标识：webview / accessibility */
    val id: String

    val isAvailable: Boolean

    /**
     * 执行统一指令。
     *
     * @param onResult 无论 SUCCESS/FAILED/UNKNOWN/TIMEOUT 都会回调一次（幂等）。
     * @return true 表示已受理（异步进行中），false 表示拒绝受理（如未连接）。
     */
    fun execute(command: BetCommand, onResult: (ExecutionResult) -> Unit): Boolean

    /** 取消执行中的任务（若能安全取消） */
    fun cancel(cmdId: String)

    /** 查询任务当前执行状态（页面刷新/断线恢复用） */
    fun queryState(cmdId: String): ExecutionResult?
}
