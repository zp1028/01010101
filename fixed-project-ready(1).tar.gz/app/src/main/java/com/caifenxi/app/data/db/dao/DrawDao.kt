package com.caifenxi.app.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.caifenxi.app.data.db.entity.DrawEntity

@Dao
interface DrawDao {
    @Query("SELECT * FROM draws WHERE lotteryKey = :key ORDER BY CAST(issue AS INTEGER) ASC")
    suspend fun getByLottery(key: String): List<DrawEntity>

    /** 最新 limit 条(期号倒序),调用方再 reverse 成升序工作窗口 */
    @Query("SELECT * FROM draws WHERE lotteryKey = :key ORDER BY CAST(issue AS INTEGER) DESC LIMIT :limit")
    suspend fun getRecentDesc(key: String, limit: Int): List<DrawEntity>

    @Query("SELECT COUNT(*) FROM draws WHERE lotteryKey = :key")
    suspend fun countByLottery(key: String): Int

    /** 分页读取历史，避免一次性加载全部开奖记录。 */
    @Query("SELECT * FROM draws WHERE lotteryKey = :key ORDER BY CAST(issue AS INTEGER) DESC LIMIT :limit OFFSET :offset")
    suspend fun getPageDesc(key: String, limit: Int, offset: Int): List<DrawEntity>

    @Query("SELECT * FROM draws ORDER BY lotteryKey ASC, CAST(issue AS INTEGER) ASC")
    suspend fun getAll(): List<DrawEntity>

    @Query("SELECT * FROM draws WHERE lotteryKey = :key ORDER BY CAST(issue AS INTEGER) DESC LIMIT 1")
    suspend fun getLatest(key: String): DrawEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<DrawEntity>)

    @Query("DELETE FROM draws WHERE lotteryKey = :key")
    suspend fun clearLottery(key: String)

    @Query("DELETE FROM draws")
    suspend fun deleteAll()
}
