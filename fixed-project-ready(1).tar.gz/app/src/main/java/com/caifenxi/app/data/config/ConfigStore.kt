package com.caifenxi.app.data.config

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.caifenxi.app.domain.model.UserPrefs
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class ConfigStore(context: Context) {

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    private val plain = context.getSharedPreferences("caifenxi_prefs", Context.MODE_PRIVATE)

    /**
     * 加密存储仅用于 AI Key（可选功能）。
     * 修复启动闪退：原实现直接在构造器中创建 EncryptedSharedPreferences，
     * 部分机型/应用重装/系统还原后密钥库异常会在 Application.onCreate 中抛错，
     * 导致打开应用即闪退。改为惰性创建 + 失败降级为明文存储，主流程不受影响。
     */
    private val securePrefs: SharedPreferences? by lazy {
        try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context,
                "caifenxi_secure_prefs",
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (_: Exception) {
            // 密钥库不可用时降级为明文（仅影响 AI Key 的存储加密级别）
            null
        }
    }

    fun loadPrefs(): UserPrefs {
        val raw = plain.getString(KEY_PREFS, null) ?: return UserPrefs()
        return try {
            json.decodeFromString<UserPrefs>(raw)
        } catch (_: Exception) {
            UserPrefs()
        }
    }

    fun savePrefs(p: UserPrefs) {
        plain.edit().putString(KEY_PREFS, json.encodeToString(p)).apply()
        // API Key 单独加密存
        if (p.aiApiKey.isNotBlank()) {
            try {
                securePrefs?.edit()?.putString(KEY_AI, p.aiApiKey)?.apply()
            } catch (_: Exception) {
            }
        }
    }

    fun loadAiKey(): String = try {
        securePrefs?.getString(KEY_AI, "") ?: ""
    } catch (_: Exception) {
        ""
    }

    companion object {
        private const val KEY_PREFS = "user_prefs_json"
        private const val KEY_AI = "ai_api_key"
    }
}
