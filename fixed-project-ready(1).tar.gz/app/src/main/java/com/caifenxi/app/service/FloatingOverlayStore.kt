package com.caifenxi.app.service

import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Serializable
data class FloatingPlanItem(
    val planId: String,
    val planName: String,
    val category: String = "",
    val dx: String? = null,
    val ds: String? = null
)

/**
 * 悬浮窗快照：只接受同一彩种下单调向前的最新开奖状态。
 * CALCULATING 只代表后台正在生成新目标；UI 不会拿它覆盖上一份 READY 结果。
 */
@Serializable
data class FloatingSnapshot(
    val lotteryKey: String = "",
    val lotteryName: String = "彩析",
    val latestIssue: String = "-",
    val targetIssue: String = "-",
    val latestDrawTime: String = "",
    val latestDx: String? = null,
    val latestDs: String? = null,
    val consensusDx: String? = null,
    val consensusDs: String? = null,
    /** 组合预测，如 大单 */
    val consensusCombo: String? = null,
    val algoCombo: String? = null,
    /** Nova 共识：大小 / 单双 / 组合 */
    val novaConsensusDx: String? = null,
    val novaConsensusDs: String? = null,
    val novaConsensusCombo: String? = null,
    /** 预测号码，逗号分隔，如 12,25,33 */
    val predNumbers: String? = null,
    val algoDx: String? = null,
    val algoDs: String? = null,
    val previousConsensusDx: String? = null,
    val previousConsensusDs: String? = null,
    val previousDxResult: String? = null,
    val previousDsResult: String? = null,
    val plans: List<FloatingPlanItem> = emptyList(),
    val status: String = "CALCULATING",
    val version: Long = 0L,
    val updatedAt: Long = 0L
)

object FloatingOverlayStore {
    private const val PREFS = "floating_overlay"
    private const val KEY = "snapshot"
    private const val KEY_READY = "last_ready_snapshot"
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    /**
     * 原子地提交快照：
     * 1. 新开奖期号更大 -> 接受
     * 2. 同一期 READY 优先于 CALCULATING
     * 3. 同状态用 version/updatedAt 较新的覆盖
     * 这样前台 MainViewModel 的旧异步任务不会把后台刚出的新结果覆盖掉。
     */
    @Synchronized
    fun save(context: Context, snapshot: FloatingSnapshot) {
        val sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val current = sp.getString(KEY, null)?.let { raw ->
            try { json.decodeFromString<FloatingSnapshot>(raw) } catch (_: Exception) { null }
        }
        val finalSnapshot = if (current != null && sameGeneration(current, snapshot)) {
            mergeSnapshot(current, snapshot)
        } else snapshot
        if (current != null && !shouldReplace(current, finalSnapshot)) return
        val editor = sp.edit().putString(KEY, json.encodeToString(finalSnapshot))
        if (finalSnapshot.status == "READY") editor.putString(KEY_READY, json.encodeToString(finalSnapshot))
        editor.apply()
    }

    fun loadLastReady(context: Context): FloatingSnapshot? {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_READY, null) ?: return null
        return try { json.decodeFromString<FloatingSnapshot>(raw) } catch (_: Exception) { null }
    }

    fun load(context: Context): FloatingSnapshot? {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, null) ?: return null
        return try { json.decodeFromString<FloatingSnapshot>(raw) } catch (_: Exception) { null }
    }


    private fun sameGeneration(a: FloatingSnapshot, b: FloatingSnapshot): Boolean {
        return a.lotteryKey == b.lotteryKey &&
            a.latestIssue == b.latestIssue &&
            a.targetIssue == b.targetIssue &&
            a.status == b.status
    }

    private fun mergeSnapshot(old: FloatingSnapshot, next: FloatingSnapshot): FloatingSnapshot {
        val planMap = LinkedHashMap<String, FloatingPlanItem>()
        old.plans.forEach { planMap[it.planId + "|" + it.category] = it }
        next.plans.forEach { incoming ->
            val key = incoming.planId + "|" + incoming.category
            val previous = planMap[key]
            planMap[key] = if (previous == null) incoming else previous.copy(
                planName = incoming.planName.ifBlank { previous.planName },
                dx = incoming.dx ?: previous.dx,
                ds = incoming.ds ?: previous.ds
            )
        }
        return next.copy(
            latestDx = next.latestDx ?: old.latestDx,
            latestDs = next.latestDs ?: old.latestDs,
            consensusDx = next.consensusDx ?: old.consensusDx,
            consensusDs = next.consensusDs ?: old.consensusDs,
            algoDx = next.algoDx ?: old.algoDx,
            algoDs = next.algoDs ?: old.algoDs,
            previousConsensusDx = next.previousConsensusDx ?: old.previousConsensusDx,
            previousConsensusDs = next.previousConsensusDs ?: old.previousConsensusDs,
            previousDxResult = next.previousDxResult ?: old.previousDxResult,
            previousDsResult = next.previousDsResult ?: old.previousDsResult,
            plans = planMap.values.toList(),
            version = maxOf(old.version, next.version),
            updatedAt = maxOf(old.updatedAt, next.updatedAt)
        )
    }
    private fun shouldReplace(old: FloatingSnapshot, next: FloatingSnapshot): Boolean {
        if (old.lotteryKey.isNotBlank() && next.lotteryKey != old.lotteryKey) return true
        val oldIssue = old.latestIssue.toLongOrNull()
        val newIssue = next.latestIssue.toLongOrNull()
        if (oldIssue != null && newIssue != null) {
            if (newIssue > oldIssue) return true
            if (newIssue < oldIssue) return false
        } else if (old.latestIssue != "-" && next.latestIssue != old.latestIssue) {
            return next.updatedAt >= old.updatedAt
        }
        if (old.status == "READY" && next.status == "CALCULATING") return false
        if (old.status == "CALCULATING" && next.status == "READY") return true
        return next.version >= old.version
    }
}

/** 发布统一悬浮窗快照；提交时由 FloatingOverlayStore 做版本/期号防倒退。 */
suspend fun publishFloatingSnapshot(
    context: Context,
    lotteryName: String,
    lotteryKey: String,
    latestIssue: String,
    latestDrawTime: String,
    latestDx: String?,
    latestDs: String?,
    targetIssue: String,
    consensus: List<com.caifenxi.app.domain.model.ModelConsensus>,
    predictions: List<com.caifenxi.app.domain.model.PlanPredictionRecord>,
    algoDx: String? = null,
    algoDs: String? = null,
    algoCombo: String? = null,
    predNumbers: String? = null,
    novaConsensus: List<com.caifenxi.app.domain.model.ModelConsensus> = emptyList(),
    status: String = "READY"
) {
    val app = com.caifenxi.app.CaiFenXiApplication.instance
    val records = try { app.consensusStore.loadAll(lotteryKey) } catch (_: Exception) { emptyList() }
    val prevDx = records.firstOrNull { it.targetIssue == latestIssue && it.category == "大小" }
    val prevDs = records.firstOrNull { it.targetIssue == latestIssue && it.category == "单双" }
    val consensusCombo = consensus.firstOrNull { it.category == "组合" }?.leadingDirection
        ?.split("/", "、", ",")?.map { it.trim() }?.firstOrNull {
            it in listOf("大单", "大双", "小单", "小双")
        }
    val novaDx = novaConsensus.firstOrNull { it.category == "大小" }?.leadingDirection
        ?.takeIf { it == "大" || it == "小" }
    val novaDs = novaConsensus.firstOrNull { it.category == "单双" }?.leadingDirection
        ?.takeIf { it == "单" || it == "双" }
    val novaCombo = novaConsensus.firstOrNull { it.category == "组合" }?.leadingDirection
        ?.split("/", "、", ",")?.map { it.trim() }?.firstOrNull {
            it in listOf("大单", "大双", "小单", "小双")
        }
    // 位置/任选共识 → 号码列表
    val consensusNums = consensus
        .filter { it.category.startsWith("位置-") || it.category.contains("号码") || it.category.contains("任选") }
        .flatMap { c ->
            c.leadingDirection.split("/", "、", ",", " ").map { it.trim() }.filter { it.toIntOrNull() != null }
        }
        .distinct()
        .take(20)
    val numsJoined = predNumbers?.takeIf { it.isNotBlank() }
        ?: consensusNums.takeIf { it.isNotEmpty() }?.joinToString(",")
    val now = System.currentTimeMillis()
    val snap = FloatingSnapshot(
        lotteryKey = lotteryKey,
        lotteryName = lotteryName,
        latestIssue = latestIssue,
        targetIssue = targetIssue,
        latestDrawTime = latestDrawTime,
        latestDx = latestDx,
        latestDs = latestDs,
        consensusDx = consensus.firstOrNull { it.category == "大小" }?.leadingDirection,
        consensusDs = consensus.firstOrNull { it.category == "单双" }?.leadingDirection,
        consensusCombo = consensusCombo,
        algoCombo = algoCombo,
        novaConsensusDx = novaDx,
        novaConsensusDs = novaDs,
        novaConsensusCombo = novaCombo,
        predNumbers = numsJoined,
        algoDx = algoDx,
        algoDs = algoDs,
        previousConsensusDx = prevDx?.leadingDirection,
        previousConsensusDs = prevDs?.leadingDirection,
        previousDxResult = prevDx?.result,
        previousDsResult = prevDs?.result,
        plans = predictions
            .filter { it.category == "大小" || it.category == "单双" }
            .groupBy { it.planId }
            .map { (_, rows) ->
                val first = rows.first()
                FloatingPlanItem(
                    planId = first.planId,
                    planName = first.planName.ifBlank { first.planId },
                    category = if (rows.any { it.category == "大小" } && rows.any { it.category == "单双" }) "大小+单双"
                    else rows.first().category,
                    dx = rows.firstOrNull { it.category == "大小" }?.output,
                    ds = rows.firstOrNull { it.category == "单双" }?.output
                )
            },
        status = status,
        version = now,
        updatedAt = now
    )
    FloatingOverlayStore.save(context, snap)
    // 预测 READY 时尝试真实自动点击（无障碍）
    if (status == "READY") {
        try {
            AutoBetController.onPredictionReady(context, snap)
        } catch (_: Exception) {
        }
    }
}
