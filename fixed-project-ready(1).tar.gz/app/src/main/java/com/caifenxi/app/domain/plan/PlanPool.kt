package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.*

/**
 * 原计划池 V2：保留旧计划ID兼容，同时为每个彩种/玩法/位置补齐30个独立核心计划。
 * 原池与 Nova 池统计完全分离；相同算法也不会共用运行态。
 */
object PlanPool {
    const val STRATEGY_VERSION = "PLAN-POOL-V2.0-LEGACY"

    private fun old(): List<PlanDefinition> = listOf(
        bin("S-FREQ-010", "大小10期频率", "大小", "FREQ", 10),
        bin("S-FREQ-020", "大小20期频率", "大小", "FREQ", 20),
        bin("S-FREQ-050", "大小50期频率", "大小", "FREQ", 50),
        bin("S-EWMA", "大小EWMA", "大小", "EWMA", 30),
        bin("S-MKV1", "大小一阶转移", "大小", "MKV1", 50),
        bin("S-MULTI", "大小多周期融合", "大小", "MSF", 100),
        bin("D-FREQ-010", "单双10期频率", "单双", "FREQ", 10),
        bin("D-FREQ-020", "单双20期频率", "单双", "FREQ", 20),
        bin("D-FREQ-050", "单双50期频率", "单双", "FREQ", 50),
        bin("D-EWMA", "单双EWMA", "单双", "EWMA", 30),
        bin("D-MKV1", "单双一阶转移", "单双", "MKV1", 50),
        bin("D-MULTI", "单双多周期融合", "单双", "MSF", 100),
        num("N-FREQ-010", "号码10期频率", 10), num("N-FREQ-020", "号码20期频率", 20),
        num("N-FREQ-050", "号码50期频率", 50), num("N-FREQ-100", "号码100期频率", 100),
        num("N-FREQ-200", "号码200期频率", 200), num("N-FREQ-500", "号码500期频率", 500),
        num("N-EWMA", "号码EWMA", 50, "EWMA"), num("N-OMIT", "号码遗漏", 80, "OMIT"),
        num("N-CHOT", "号码冷热", 50, "HOTCOLD"), num("N-MULTI", "号码多周期融合", 100, "ENSEMBLE")
    )

    /** 所有彩种的原计划核心池；UI按当前彩种过滤。 */
    val ALL: List<PlanDefinition> by lazy {
        old() + LotteryType.entries.filter { it != LotteryType.OTHER }.flatMap { PlanPoolV2.legacy(it) }
    }

    private fun bin(id: String, name: String, cat: String, algo: String, w: Int) =
        PlanDefinition(id, name, cat, algo, w, playType = cat, outputFormat = PlanOutputFormat.DIRECTION, hitCriteria = PlanHitCriteria.DIRECTION_MATCH, participateConsensus = true)

    private fun num(id: String, name: String, w: Int, algo: String = "FREQ") =
        PlanDefinition(id, name, "号码", algo, w, playType = "数字", outputFormat = PlanOutputFormat.NUMBER_SCORES, hitCriteria = PlanHitCriteria.TOP20_HIT, participateConsensus = false, baselineValue = 0.2)
}
