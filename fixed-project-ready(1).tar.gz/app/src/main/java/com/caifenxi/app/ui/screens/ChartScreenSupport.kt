package com.caifenxi.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.plan.NovaPlanAnalytics
import com.caifenxi.app.ui.components.CaptionMuted
import kotlin.math.roundToInt

internal fun chartFmtMoney(v: Double): String = if (v >= 0) "+${"%.2f".format(v)}" else "${"%.2f".format(v)}"

/** 多计划对比分色（与图例一致） */
internal fun chartSeriesColor(index: Int): Color {
    val palette = listOf(
        Color(0xFF1565C0),
        Color(0xFF6A1B9A),
        Color(0xFF00838F),
        Color(0xFFEF6C00),
        Color(0xFFAD1457)
    )
    return palette[index % palette.size]
}

@Composable
internal fun ChartFilterLine(title: String, options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(top = 5.dp)) {
        CaptionMuted(title)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            options.forEach { option ->
                FilterChip(selected = selected == option, onClick = { onSelect(option) }, label = { Text(option) })
            }
        }
    }
}

@Composable
internal fun ChartCurve(
    reports: List<NovaPlanAnalytics.ChartReport>,
    mode: String,
    onPointClick: (NovaPlanAnalytics.ChartPoint) -> Unit
) {
    val chartHeight = 240.dp
    val chartSecondaryColor = MaterialTheme.colorScheme.secondary
    val key = reports.map { it.plan.planId to it.points.size }
    var scale by remember(key) { mutableFloatStateOf(1f) }
    var offsetX by remember(key) { mutableFloatStateOf(0f) }
    var offsetY by remember(key) { mutableFloatStateOf(0f) }

    val green = Color(0xFF2E7D32)
    val red = Color(0xFFC62828)
    val amber = Color(0xFFF9A825)

    val isHitRateMode = mode == "对错率" || mode == "命中率"
    val baselineValue = if (isHitRateMode) 50.0 else 0.0
    /** 对错率/命中率纵轴最高显示到 70% 胜率 */
    val hitRateCap = 70.0

    val prepared = remember(reports, mode) {
        reports.map { r ->
            val values = r.points.map { p -> chartValueAt(mode, p) }
            val idxs = downsampleKeepExtremes(values, maxPoints = 400)
            r to idxs
        }
    }

    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            CaptionMuted(
                if (scale <= 1.01f) {
                    if (isHitRateMode) "零轴=50% · 纵轴最高70% · 双指缩放（轻点查看节点）"
                    else "绿涨红跌 · 虚线参考 · 黄虚线最大回撤 · 色带连对/连错"
                } else "拖动查看细节 · 当前${"%.1f".format(scale)}x"
            )
            if (scale > 1.01f || kotlin.math.abs(offsetX) > 1f || kotlin.math.abs(offsetY) > 1f) {
                TextButton(onClick = { scale = 1f; offsetX = 0f; offsetY = 0f }) { Text("复位") }
            }
        }
        Box(
            Modifier
                .fillMaxWidth()
                .height(chartHeight)
                .clip(RoundedCornerShape(8.dp))
                .pointerInput(prepared.map { it.second.size } to mode) {
                    // 单套手势：缩放/拖动；轻点（几乎无位移）才点选，降低双 pointerInput 冲突闪退
                    detectTransformGestures { _, pan, zoom, _ ->
                        val zooming = kotlin.math.abs(zoom - 1f) > 0.01f
                        val panning = pan.getDistance() > 2f
                        if (zooming || panning) {
                            val newScale = (scale * zoom).coerceIn(1f, 3f)
                            val ratio = if (scale > 0f) newScale / scale else 1f
                            scale = newScale
                            if (newScale <= 1.01f) {
                                scale = 1f
                                offsetX = 0f
                                offsetY = 0f
                            } else {
                                val maxX = size.width * (newScale - 1f)
                                val maxY = size.height * (newScale - 1f) * 0.35f
                                offsetX = (offsetX * ratio + pan.x).coerceIn(-maxX, maxX)
                                offsetY = (offsetY * ratio + pan.y).coerceIn(-maxY, maxY)
                            }
                        }
                    }
                }
                .pointerInput(prepared.map { it.second.size } to mode) {
                    detectTapGestures { pos ->
                        try {
                            val first = prepared.firstOrNull() ?: return@detectTapGestures
                            val (r, idxs) = first
                            if (idxs.isEmpty() || r.points.isEmpty()) return@detectTapGestures
                            val w = size.width.coerceAtLeast(1)
                            val idx = ((pos.x / w) * idxs.size).toInt().coerceIn(0, idxs.lastIndex)
                            val pointIdx = idxs[idx].coerceIn(0, r.points.lastIndex)
                            onPointClick(r.points[pointIdx])
                        } catch (_: Exception) {
                        }
                    }
                }
        ) {
            Canvas(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        translationX = offsetX
                        translationY = offsetY
                        transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0.5f, 0.5f)
                    }
            ) {
                if (prepared.isEmpty() || prepared.all { it.second.isEmpty() }) return@Canvas
                val padL = 36f
                val padR = 10f
                val padT = 14f
                val padB = 14f
                val cw = (size.width - padL - padR).coerceAtLeast(1f)
                val ch = (size.height - padT - padB).coerceAtLeast(1f)
                val maxCount = prepared.maxOf { it.second.size }.coerceAtLeast(1)

                fun x(i: Int): Float =
                    if (maxCount <= 1) padL + cw / 2f else padL + cw * i / (maxCount - 1)

                val allValues = prepared.flatMap { (r, idxs) ->
                    idxs.map { chartValueAt(mode, r.points[it]) }
                }
                val modeMin = allValues.minOrNull() ?: baselineValue
                val modeMax = allValues.maxOrNull() ?: baselineValue
                val viewHi: Double
                val viewLo: Double
                if (isHitRateMode) {
                    // 纵轴固定上沿 70% 胜率；下沿不低于数据最低与约 30% 区间，零轴 50%
                    viewHi = hitRateCap
                    viewLo = minOf(modeMin, 30.0, baselineValue).coerceAtMost(baselineValue - 5.0)
                } else {
                    val modeLo = minOf(baselineValue, modeMin)
                    val modeHi = maxOf(baselineValue, modeMax)
                    val rawRange = (modeHi - modeLo).coerceAtLeast(1e-6)
                    val padValue = rawRange * 0.10
                    viewHi = modeHi + padValue
                    viewLo = modeLo - padValue
                }
                val viewRange = (viewHi - viewLo).coerceAtLeast(1e-6)

                fun y(v: Double): Float {
                    val vv = if (isHitRateMode) v.coerceAtMost(hitRateCap) else v
                    return padT + ch * (((viewHi - vv) / viewRange).toFloat().coerceIn(0f, 1f))
                }

                val zeroY = y(baselineValue)
                val gridColor = Color(0xFFB0B0B0)
                val zeroColor = Color(0xFF666666)

                // 连对/连错色带（仅收益类）
                val primary = prepared.firstOrNull()
                if (primary != null && primary.second.isNotEmpty() && !isHitRateMode &&
                    (mode == "累计收益" || mode == "单期盈亏" || mode == "涨跌趋势")
                ) {
                    val hits = primary.second.map { primary.first.points[it].hit }
                    val (hitS, hitE) = findLongestBoolStreak(hits, true)
                    val (missS, missE) = findLongestBoolStreak(hits, false)
                    if (hitS >= 0 && hitE >= hitS) {
                        drawRect(
                            color = green.copy(alpha = 0.10f),
                            topLeft = Offset(x(hitS), padT),
                            size = androidx.compose.ui.geometry.Size((x(hitE) - x(hitS)).coerceAtLeast(1f), ch)
                        )
                    }
                    if (missS >= 0 && missE >= missS) {
                        drawRect(
                            color = red.copy(alpha = 0.10f),
                            topLeft = Offset(x(missS), padT),
                            size = androidx.compose.ui.geometry.Size((x(missE) - x(missS)).coerceAtLeast(1f), ch)
                        )
                    }
                }

                // 水平虚线 + Y 轴刻度文字
                val levels = if (isHitRateMode) {
                    listOf(viewLo, 40.0, 50.0, 60.0, 70.0).filter { it in viewLo..viewHi || kotlin.math.abs(it - 50.0) < 0.01 }
                        .distinctBy { "%.1f".format(it) }
                } else {
                    listOf(
                        baselineValue,
                        viewLo + viewRange * 0.25,
                        viewLo + viewRange * 0.50,
                        viewLo + viewRange * 0.75,
                        viewHi
                    ).distinctBy { "%.4f".format(it) }
                }

                val textPaint = android.graphics.Paint().apply {
                    isAntiAlias = true
                    textSize = 22f
                    color = android.graphics.Color.parseColor("#888888")
                }
                val paintGreen = android.graphics.Paint().apply {
                    isAntiAlias = true
                    textSize = 22f
                    color = android.graphics.Color.parseColor("#2E7D32")
                }
                val paintRed = android.graphics.Paint().apply {
                    isAntiAlias = true
                    textSize = 22f
                    color = android.graphics.Color.parseColor("#C62828")
                }

                levels.forEach { level ->
                    val yy = y(level)
                    val isBase = kotlin.math.abs(level - baselineValue) < 1e-6
                    drawLine(
                        color = if (isBase) zeroColor else gridColor,
                        start = Offset(padL, yy),
                        end = Offset(size.width - padR, yy),
                        strokeWidth = if (isBase) 1.8f else 1.0f,
                        pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(
                            if (isBase) floatArrayOf(8f, 6f) else floatArrayOf(4f, 6f)
                        )
                    )
                    val label = if (isHitRateMode) {
                        "${"%.0f".format(level)}%"
                    } else if (kotlin.math.abs(level) >= 100) {
                        "%.0f".format(level)
                    } else {
                        "%.1f".format(level)
                    }
                    drawContext.canvas.nativeCanvas.drawText(label, 4f, yy + 6f, textPaint)
                }

                prepared.forEachIndexed { seriesIdx, (r, idxs) ->
                    if (idxs.isEmpty()) return@forEachIndexed
                    val series = idxs.map { chartValueAt(mode, r.points[it]) }
                    val seriesColor = if (prepared.size > 1) chartSeriesColor(seriesIdx) else null

                    if (mode == "累计收益" && series.size > 1 && prepared.size == 1) {
                        val fillPath = Path()
                        fillPath.moveTo(x(0), zeroY)
                        series.forEachIndexed { i, v -> fillPath.lineTo(x(i), y(v)) }
                        fillPath.lineTo(x(series.lastIndex), zeroY)
                        fillPath.close()
                        val last = series.last()
                        drawPath(fillPath, color = (if (last >= baselineValue) green else red).copy(alpha = 0.08f))
                    }

                    if (mode == "累计收益" || mode == "单期盈亏" || mode == "涨跌趋势" || mode == "回撤" || isHitRateMode) {
                        for (i in 1 until idxs.size) {
                            val prevV = series[i - 1]
                            val curV = series[i]
                            val c = when {
                                seriesColor != null -> seriesColor
                                mode == "回撤" -> if (curV >= prevV) red else green
                                isHitRateMode -> if (curV >= prevV) green else red
                                kotlin.math.abs(curV - prevV) < 1e-12 -> chartSecondaryColor
                                curV > prevV -> green
                                else -> red
                            }
                            drawLine(
                                c,
                                Offset(x(i - 1), y(prevV)),
                                Offset(x(i), y(curV)),
                                if (seriesColor != null) 2.8f else 3.4f,
                                cap = StrokeCap.Round
                            )
                        }
                    } else {
                        val path = Path()
                        series.forEachIndexed { i, v ->
                            if (i == 0) path.moveTo(x(i), y(v)) else path.lineTo(x(i), y(v))
                        }
                        drawPath(
                            path,
                            seriesColor ?: chartSecondaryColor,
                            style = Stroke(width = 3.2f, cap = StrokeCap.Round)
                        )
                    }

                    val hiLocal = series.indices.maxByOrNull { series[it] } ?: -1
                    val loLocal = series.indices.minByOrNull { series[it] } ?: -1
                    if (hiLocal >= 0) drawCircle(green, 4f, Offset(x(hiLocal), y(series[hiLocal])))
                    if (loLocal >= 0) drawCircle(red, 4f, Offset(x(loLocal), y(series[loLocal])))

                    // 对错率：标出最高/最低对错率点
                    if (isHitRateMode && prepared.size == 1) {
                        if (hiLocal >= 0) {
                            drawContext.canvas.nativeCanvas.drawText(
                                "最高${"%.0f".format(series[hiLocal])}%",
                                x(hiLocal).coerceAtMost(size.width - 120f),
                                (y(series[hiLocal]) - 8f).coerceAtLeast(18f),
                                paintGreen
                            )
                        }
                        if (loLocal >= 0 && loLocal != hiLocal) {
                            drawContext.canvas.nativeCanvas.drawText(
                                "最低${"%.0f".format(series[loLocal])}%",
                                x(loLocal).coerceAtMost(size.width - 120f),
                                (y(series[loLocal]) + 22f).coerceAtMost(size.height - 4f),
                                paintRed
                            )
                        }
                    }

                    if ((mode == "累计收益" || mode == "回撤") && prepared.size == 1) {
                        val (peakI, troughI) = findMaxDrawdownPair(series)
                        if (peakI >= 0 && troughI > peakI) {
                            drawLine(
                                color = amber,
                                start = Offset(x(peakI), y(series[peakI])),
                                end = Offset(x(troughI), y(series[troughI])),
                                strokeWidth = 2.2f,
                                pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
                            )
                            drawCircle(amber, 4f, Offset(x(peakI), y(series[peakI])), style = Stroke(width = 2f))
                            drawCircle(amber, 4f, Offset(x(troughI), y(series[troughI])))
                        }
                    }

                    if (idxs.size <= 90 && prepared.size == 1) {
                        series.forEachIndexed { i, v ->
                            val hit = r.points[idxs[i]].hit
                            drawCircle(if (hit) green else red, 2.2f, Offset(x(i), y(v)))
                        }
                    }
                }
            }
        }
        reports.forEach { r ->
            if (isHitRateMode) {
                CaptionMuted(
                    "${r.plan.planName} · 对错率 ${(r.hitRate * 100).roundToInt()}% · 最高 ${(r.maxHitRate * 100).roundToInt()}% · 最低 ${(r.minHitRate * 100).roundToInt()}% · 相对50% ${"%.1f".format((r.hitRate - 0.5) * 100)}pt"
                )
            } else {
                CaptionMuted(
                    "${r.plan.planName} · 最高 ${chartFmtMoney(r.maxPeak)} · 最低 ${chartFmtMoney(r.minTrough)} · 当前 ${chartFmtMoney(r.points.lastOrNull()?.cumulativeProfit ?: 0.0)} · 回撤 ${chartFmtMoney(r.maxDrawdown)}"
                )
            }
        }
    }
}

/** 图表 Y 值：对错率/命中率用百分比 0~100，50 为零轴 */
private fun chartValueAt(mode: String, p: NovaPlanAnalytics.ChartPoint): Double = when (mode) {
    "单期盈亏" -> p.periodProfit
    "对错率", "命中率" -> p.hitRate * 100.0
    "涨跌趋势" -> if (p.periodProfit > 0) 1.0 else if (p.periodProfit < 0) -1.0 else 0.0
    "回撤" -> p.drawdown
    else -> p.cumulativeProfit
}

private fun downsampleKeepExtremes(values: List<Double>, maxPoints: Int): List<Int> {
    val n = values.size
    if (n <= maxPoints) return values.indices.toList()
    if (maxPoints < 3) return listOf(0, n - 1)
    val bucket = ((n - 1).toFloat() / (maxPoints - 1)).coerceAtLeast(1f)
    val out = ArrayList<Int>(maxPoints + 8)
    out.add(0)
    var b = 0
    while (true) {
        val start = (b * bucket).toInt().coerceIn(0, n - 1)
        val end = (((b + 1) * bucket).toInt() - 1).coerceIn(start, n - 1)
        if (start >= n - 1) break
        var minI = start
        var maxI = start
        for (i in start..end) {
            if (values[i] < values[minI]) minI = i
            if (values[i] > values[maxI]) maxI = i
        }
        if (minI < maxI) {
            if (out.last() != minI) out.add(minI)
            if (out.last() != maxI) out.add(maxI)
        } else {
            if (out.last() != maxI) out.add(maxI)
            if (out.last() != minI) out.add(minI)
        }
        if (end >= n - 1) break
        b++
        if (out.size >= maxPoints * 2) break
    }
    if (out.last() != n - 1) out.add(n - 1)
    if (out.size <= maxPoints) return out
    val step = (out.size - 1).toFloat() / (maxPoints - 1)
    val slim = ArrayList<Int>(maxPoints)
    var prev = -1
    for (i in 0 until maxPoints) {
        val idx = out[(i * step).toInt().coerceIn(0, out.lastIndex)]
        if (idx != prev) {
            slim.add(idx)
            prev = idx
        }
    }
    if (slim.last() != n - 1) slim.add(n - 1)
    return slim
}

private fun findMaxDrawdownPair(series: List<Double>): Pair<Int, Int> {
    if (series.size < 2) return -1 to -1
    var bestPeak = 0
    var bestTrough = 0
    var bestDd = 0.0
    var runningPeakIdx = 0
    for (i in series.indices) {
        if (series[i] > series[runningPeakIdx]) runningPeakIdx = i
        val dd = series[runningPeakIdx] - series[i]
        if (dd > bestDd) {
            bestDd = dd
            bestPeak = runningPeakIdx
            bestTrough = i
        }
    }
    return if (bestDd > 0.0 && bestTrough > bestPeak) bestPeak to bestTrough else -1 to -1
}

private fun findLongestBoolStreak(flags: List<Boolean>, target: Boolean): Pair<Int, Int> {
    var bestS = -1
    var bestE = -1
    var curS = -1
    for (i in flags.indices) {
        if (flags[i] == target) {
            if (curS < 0) curS = i
            if (bestS < 0 || i - curS > bestE - bestS) {
                bestS = curS
                bestE = i
            }
        } else curS = -1
    }
    return bestS to bestE
}
