package com.caifenxi.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.ui.theme.CaiTokens

/** 统一数字/百分比/金额格式 */
object UiFormat {
    fun pct(rate: Double, digits: Int = 0): String {
        if (rate.isNaN()) return "-"
        return "%.${digits}f%%".format(rate * 100)
    }

    fun money(v: Double): String =
        if (v >= 0) "+%.2f".format(v) else "%.2f".format(v)

    fun issue(raw: String?): String =
        raw?.takeIf { it.isNotBlank() && it != "-" }?.let { "第${it}期" } ?: "第-期"

    fun count(n: Int, unit: String = "期"): String = "$n$unit"
}

val ProfitGreen = Color(0xFF2E7D32)
val LossRed = Color(0xFFC62828)
val PendingAmber = Color(0xFFF9A825)

/**
 * 全局顶栏状态：彩种 · 最新期 · 同步状态
 */
@Composable
fun GlobalStatusBar(
    lotteryName: String,
    latestIssue: String,
    targetIssue: String,
    statusText: String,
    errorMessage: String?,
    historySize: Int,
    onSync: (() -> Unit)? = null
) {
    val bg = if (errorMessage != null) LossRed.copy(alpha = 0.12f)
    else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
    Column(
        Modifier
            .fillMaxWidth()
            .background(bg)
            .padding(horizontal = CaiTokens.ScreenHPadding, vertical = 8.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    "$lotteryName · ${UiFormat.issue(latestIssue)}",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    "目标 ${UiFormat.issue(targetIssue)} · 样本 ${UiFormat.count(historySize)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            if (onSync != null) {
                TextButton(onClick = onSync) { Text("同步", fontSize = 12.sp) }
            }
        }
        val line = errorMessage?.let { "⚠ $it" } ?: statusText
        if (line.isNotBlank()) {
            Text(
                line,
                fontSize = 11.sp,
                color = if (errorMessage != null) LossRed else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/** 标准空态 */
@Composable
fun EmptyStateBlock(
    title: String,
    subtitle: String = "",
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 24.dp, horizontal = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        if (subtitle.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            CaptionMuted(subtitle)
        }
        if (actionLabel != null && onAction != null) {
            Spacer(Modifier.height(12.dp))
            PrimaryButton(actionLabel, onAction, Modifier.fillMaxWidth(0.7f))
        }
    }
}

/** 加载中块 */
@Composable
fun LoadingBlock(text: String = "计算中…") {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        CircularProgressIndicator(Modifier.padding(end = 10.dp), strokeWidth = 2.dp)
        Text(text, style = MaterialTheme.typography.bodySmall)
    }
}

/** 结论条：图表/回测顶部固定结论 */
@Composable
fun ConclusionStrip(
    lines: List<String>,
    modifier: Modifier = Modifier
) {
    if (lines.isEmpty()) return
    GlobalCard(modifier = modifier, containerColor = MaterialTheme.colorScheme.secondaryContainer) {
        Text("结论", fontWeight = FontWeight.Bold, fontSize = 13.sp)
        lines.forEach {
            Text(it, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

/** 预测大卡片：驾驶舱主视觉 */
@Composable
fun PredictionHeroCard(
    targetIssue: String,
    dx: String?,
    ds: String?,
    combo: String?,
    extraLines: List<String> = emptyList(),
    footer: String = ""
) {
    GlobalCard(containerColor = MaterialTheme.colorScheme.primaryContainer) {
        Text("下期预测 · ${UiFormat.issue(targetIssue)}", fontWeight = FontWeight.Bold)
        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = 10.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            HeroDir("大小", dx)
            HeroDir("单双", ds)
            HeroDir("组合", combo)
        }
        extraLines.forEach {
            Text(it, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        }
        if (footer.isNotBlank()) {
            CaptionMuted(footer)
        }
    }
}

@Composable
private fun HeroDir(label: String, value: String?) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            value?.takeIf { it.isNotBlank() } ?: "—",
            fontWeight = FontWeight.Bold,
            fontSize = 22.sp,
            color = MaterialTheme.colorScheme.onPrimaryContainer
        )
    }
}

/** 策略摘要行 */
@Composable
fun StrategySummaryCard(
    title: String,
    rows: List<Pair<String, String>>,
    content: @Composable ColumnScope.() -> Unit = {}
) {
    GlobalCard {
        Text(title, fontWeight = FontWeight.Bold)
        rows.forEach { (k, v) ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(k, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(v, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        content()
    }
}


/** 统一页头：标题 + 彩种玩法副标题 */
@Composable
fun PageHeader(
    title: String,
    lotteryName: String = "",
    playSummary: String = "",
    subtitle: String = ""
) {
    Column(Modifier.fillMaxWidth().padding(bottom = 6.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        val sub = buildList {
            if (lotteryName.isNotBlank()) add(lotteryName)
            if (playSummary.isNotBlank()) add(playSummary)
            if (subtitle.isNotBlank()) add(subtitle)
        }.joinToString(" · ")
        if (sub.isNotBlank()) CaptionMuted(sub)
    }
}

/** 命中率着色文本 */
@Composable
fun RateText(rate: Double, prefix: String = "") {
    val color = when {
        rate >= 0.55 -> ProfitGreen
        rate <= 0.45 -> LossRed
        else -> MaterialTheme.colorScheme.onSurface
    }
    Text(
        "$prefix${UiFormat.pct(rate)}",
        color = color,
        fontWeight = FontWeight.SemiBold,
        fontSize = 13.sp
    )
}
