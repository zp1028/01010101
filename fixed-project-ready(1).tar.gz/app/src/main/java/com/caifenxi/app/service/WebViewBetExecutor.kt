package com.caifenxi.app.service

import android.os.Handler
import android.os.Looper
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import com.caifenxi.app.util.RuntimeLog

/**
 * WebView 精准自动下注执行器
 * 通过 WebView 自身事件循环 + JS 注入执行点击/输入，作为无障碍之外的备用执行通道。
 * 注意：所有 evaluateJavascript 均为异步，这里只负责投递指令并返回是否受理。
 */
class WebViewBetExecutor {

    private var webView: WebView? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    fun initWebView(webView: WebView) {
        this.webView = webView
        setupWebView()
    }

    private fun setupWebView() {
        webView?.apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                cacheMode = WebSettings.LOAD_NO_CACHE
                setSupportZoom(true)
                builtInZoomControls = true
                displayZoomControls = false
            }
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    RuntimeLog.info("WebViewBet", "投注页加载完成，准备注入下注逻辑")
                    injectBettingJS()
                }
            }
        }
    }

    private fun injectBettingJS() {
        val js = """
            // 精准下注注入器
            window.caiFenXiBet = {
                betDx: function(dx) {
                    const buttons = document.querySelectorAll('button, .btn, [class*="button"], [class*="btn"], span, div');
                    for (let btn of buttons) {
                        if (btn.textContent && btn.textContent.includes(dx)) {
                            btn.click();
                            return true;
                        }
                    }
                    return false;
                },
                betDs: function(ds) {
                    const buttons = document.querySelectorAll('button, .btn, [class*="button"], [class*="btn"], span, div');
                    for (let btn of buttons) {
                        if (btn.textContent && btn.textContent.includes(ds)) {
                            btn.click();
                            return true;
                        }
                    }
                    return false;
                },
                inputAmount: function(amount) {
                    const inputs = document.querySelectorAll('input[type="number"], input[type="text"], input');
                    for (let input of inputs) {
                        if (input.offsetParent && input.offsetParent.style.display !== 'none') {
                            input.value = amount;
                            input.dispatchEvent(new Event('input', {bubbles: true}));
                            input.dispatchEvent(new Event('change', {bubbles: true}));
                            return true;
                        }
                    }
                    return false;
                },
                clickCombo: function(combo) {
                    const elements = document.querySelectorAll('label, span, div, button');
                    for (let el of elements) {
                        if (el.textContent && el.textContent.trim() === combo) {
                            el.click();
                            return true;
                        }
                    }
                    return false;
                },
                clickPositionNumber: function(num) {
                    const buttons = document.querySelectorAll('button, .btn, [class*="button"], [class*="btn"], span, div');
                    for (let btn of buttons) {
                        if (btn.textContent && btn.textContent.includes(num)) {
                            btn.click();
                            return true;
                        }
                    }
                    return false;
                },
                waitForElement: function(selector, timeout = 5000) {
                    return new Promise((resolve) => {
                        const start = Date.now();
                        const check = () => {
                            const elements = document.querySelectorAll(selector);
                            if (elements.length > 0) {
                                resolve(true);
                            } else if (Date.now() - start < timeout) {
                                setTimeout(check, 100);
                            } else {
                                resolve(false);
                            }
                        };
                        check();
                    });
                }
            };
            
            // 注入完成通知
            console.log('caiFenXiBet 注入完成');
            window.Android?.onBetCommandReceived('JS injection completed');
        """.trimIndent()
        webView?.evaluateJavascript(js, { result ->
            RuntimeLog.info("WebViewBet", "JS 注入完成: $result")
        })
    }

    /** 受理一次下注指令序列；仅主线程投递，不阻塞调用方 */
    fun executeWebViewBet(
        dx: String?,
        ds: String?,
        amountText: String?,
        combo: String?,
        predNumbers: List<String> = emptyList()
    ): Boolean {
        val wv = webView ?: return false
        RuntimeLog.info("WebViewBet", "开始 WebView 下注: dx=$dx ds=$ds amount=$amountText combo=$combo")
        
        return mainHandler.post {
            try {
                var allOk = true
                
                // 1. 等待页面加载完成
                Thread.sleep(1000)
                
                // 2. 查找并点击下注按钮
                if (dx != null) {
                    val dxResult = wv.evaluateJavascript("window.caiFenXiBet.betDx('$dx')", null)
                    allOk = allOk && (dxResult != null)
                }
                
                // 3. 查找并点击单双按钮
                if (ds != null) {
                    val dsResult = wv.evaluateJavascript("window.caiFenXiBet.betDs('$ds')", null)
                    allOk = allOk && (dsResult != null)
                }
                
                // 4. 输入金额
                if (amountText != null) {
                    val amountResult = wv.evaluateJavascript("window.caiFenXiBet.inputAmount('$amountText')", null)
                    allOk = allOk && (amountResult != null)
                }
                
                // 5. 点击组合（如果有）
                if (combo != null) {
                    val comboResult = wv.evaluateJavascript("window.caiFenXiBet.clickCombo('$combo')", null)
                    allOk = allOk && (comboResult != null)
                }
                
                // 6. 点击位置数字
                predNumbers.forEach { num ->
                    val numResult = wv.evaluateJavascript("window.caiFenXiBet.clickPositionNumber('$num')", null)
                    allOk = allOk && (numResult != null)
                }
                
                if (allOk) {
                    RuntimeLog.info("WebViewBet", "WebView 下注指令已投递成功")
                } else {
                    RuntimeLog.warn("WebViewBet", "WebView 下注部分失败")
                }
                
                return allOk
            } catch (e: Exception) {
                RuntimeLog.error("WebViewBet", "WebView 执行异常: ${e.message}")
                false
            }
        }
    }

    fun clearWebView() {
        webView = null
    }
}