# 彩析 - GitHub 构建指南

## 项目信息
- **包名**: com.caifenxi.app
- **版本**: 2.3.4 (versionCode: 34)
- **最小SDK**: 24
- **目标SDK**: 35
- **编译SDK**: 35

## 环境要求
- Java 17+
- Gradle 8.9+
- Android Build Tools 35.0.0+

## 构建步骤

### 1. 下载 Gradle Wrapper
```bash
curl -L -o gradlew https://github.com/gradle/gradle/raw/v8.9/gradlew
chmod +x gradlew
```

### 2. 下载 Gradle Wrapper JAR
```bash
mkdir -p gradle/wrapper
curl -L -o gradle/wrapper/gradle-wrapper.jar https://github.com/gradle/gradle/raw/v8.9/gradle/wrapper/gradle-wrapper.jar
```

### 3. 构建 APK
```bash
./gradlew assembleRelease
```

### 4. 签名 APK (可选)
```bash
./gradlew assembleRelease -Pandroid.injected.signing.store.file=keystore.jks -Pandroid.injected.signing.store.password=storepass -Pandroid.injected.signing.key.alias=keyalias -Pandroid.injected.signing.key.password=keypass
```

## 构建产物
- **位置**: `app/build/outputs/apk/release/`
- **文件名**: `app-release-unsigned.apk` (未签名) 或 `app-release.apk` (已签名)

## 项目结构
```
source_code/
├── app/                    # 主应用模块
│   ├── src/main/          # 主源码
│   │   ├── java/          # Kotlin 源码
│   │   ├── res/           # 资源文件
│   │   └── AndroidManifest.xml
│   └── build.gradle.kts  # 应用构建配置
├── gradle/                # Gradle 配置
│   └── wrapper/          # Gradle Wrapper
├── gradle.properties     # 全局属性
├── settings.gradle.kts    # 项目设置
└── build.gradle.kts      # 项目构建配置
```

## 注意事项
1. 确保网络连接正常，用于下载 Gradle 依赖
2. 首次构建可能需要较长时间下载依赖
3. 构建过程中确保有足够的磁盘空间
4. 如需签名，请准备有效的 keystore 文件