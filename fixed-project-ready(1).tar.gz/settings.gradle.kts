pluginManagement {
    repositories {
        // CI（GitHub Actions 等海外环境）优先官方源，避免阿里云未同步的插件版本解析失败
        gradlePluginPortal()
        google()
        mavenCentral()
        // 国内本地构建可走阿里云镜像作为补充
        maven { url = uri("https://maven.aliyun.com/repository/gradle-plugin") }
        maven { url = uri("https://maven.aliyun.com/repository/google") }
        maven { url = uri("https://maven.aliyun.com/repository/central") }
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven { url = uri("https://maven.aliyun.com/repository/google") }
        maven { url = uri("https://maven.aliyun.com/repository/central") }
    }
}

rootProject.name = "CaiFenXi"
include(":app")
