# P4 新闻 + AI JSON

## 行为
1. `CryptoNewsRepository` 拉取公开趋势/标题（无正文抓取），本地词典情绪。
2. `AiBrain` 生成 **强制 JSON** 候选（本地规则合成，schema 与 LLM 一致）。
3. `AiJsonParser` 解析失败 → 丢弃。
4. `AiPolicy.allowLiveAiOrders=false` 默认：AI **不进实盘下单**。
5. 黑天鹅新闻 → 运行时 PAUSED。
6. AI 可作为 `BTC-AI-ASSISTED` 低权重计划进入共识（研究/PAPER）。

## JSON 示例
```json
{
  "barId": 0,
  "direction": "up|down|skip",
  "confidence": 0.0,
  "expectedMovePct": 0.0,
  "reasons": [],
  "invalidIf": [],
  "suggestedSizePct": 0.25,
  "newsBias": 0.0,
  "source": "local-rules-brain"
}
```
