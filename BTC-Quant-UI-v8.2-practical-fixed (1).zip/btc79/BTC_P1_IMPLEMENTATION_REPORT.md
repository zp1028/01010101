# BTC Quant P1 实现报告

本次在既有 BTC Quant 工程基础上补齐 P1 核心闭环：

- 独立 BTC 计划注册表：Turtle/Donchian、EMA、MACD、MTF Pullback、RSI Range、BB/ATR、VWAP/Volume、Funding、AI Assist。
- 永续回测账本：PnL、胜率、Profit Factor、最大回撤、持仓时间、MFE、MAE、手续费、滑点、Funding 成本。
- Walk-forward 分段接口。
- 独立风险引擎：日亏、总回撤、置信度、波动风险、名义仓位、杠杆上限、Kill Switch。
- 独立 PerpBroker 接口。
- Binance USDⓈ-M Demo Futures Broker：签名订单、撤单、账户快照、clientOrderId 幂等入口。
- TradingSignal 明确拆分 Contract / EventContract / PredictionMarket，避免一个 UP 信号跨产品直接下单。

## 仍然需要后续阶段

P2：云端调度、心跳、告警、模拟/实盘隔离、远程只平仓/全停。
P3：真实 Funding/OI/清算、Mark Price、Regime 分桶、组合暴露。
P4：新闻服务与结构化 AI JSON。
P5：Polymarket CLOB 全流程。
P6：事件合约与币安预测市场 Broker（以官方稳定 API 能力为上线前置条件）。
P7：计划竞争、降相关、动态权重、组合优化。

## 构建验证

需要在具备 Gradle 依赖网络的 CI 环境执行 `./gradlew :app:assembleDebug`。本地当前环境曾因无法访问 Gradle Distribution 导致 wrapper 下载失败，因此不能把本次源码标记为“已编译通过”。

## 产品壳分离

本分支已把 Launcher/Application 从原“彩析”运行时中拆出：

- Application：`BtcQuantApplication`
- applicationId：`com.caifenxi.btcquant`
- App Label：`BTC Quant`
- Launcher 仅进入 BTC Quant 工作台
- 不初始化彩票 API、计划引擎、无障碍、WebView 自动下注等旧运行时
- 保留旧源码文件仅作为历史工程文件，不进入 BTC Quant 启动链路
