# BTC-Quant-UI v8.2-practical 静态审计修复说明

- **审计报告**：`BTC-Quant-UI-v8.2-全量静态交叉引用审计报告.md`
- **修复范围**：审计报告全部发现项（H-01~H-04、M-02、L-01~L-04）
- **修复后工程**：本 ZIP（根目录 `btc79/`）
- **验证方式**：静态交叉引用全量复验（沙箱无 Android SDK，未执行 Gradle 编译）

---

## 一、修复项总览

| 编号 | 审计发现 | 修复动作 | 状态 |
|---|---|---|---|
| H-01 | 双 Application 并存，`CaiFenXiApplication.instance` 未初始化即被 17 文件引用 | `CaiFenXiApplication` 改 `open class`；`BtcQuantApplication` 继承它，`onCreate()` 先 `super.onCreate()` 完成旧体系单例初始化，再调度 watchdog | ✅ |
| H-02 | `AutoBetAccessibilityService` 未注册，整条无障碍执行链路失效 | Manifest 注册服务，挂接 `BIND_ACCESSIBILITY_SERVICE` 权限、`android.accessibilityservice` intent-filter 与 `@xml/accessibility_service_config` | ✅ |
| H-03 | `DataSyncService`、`ClickRegionPickActivity` 显式启动但未注册 | Manifest 补注册（service 用 dataSync 前台类型；activity 非导出、配置可旋转） | ✅ |
| H-04 | `FileProvider` 未注册，导出分享静默失败 | Manifest 注册 `${applicationId}.fileprovider`（= `com.caifenxi.btcquant.fileprovider`，与 `SettingsScreen.kt:526` 代码一致）+ `@xml/file_paths` | ✅ |
| M-02 | 合约实盘 Broker 未接线、`BinanceDemoPerpBroker` 废弃残留 | `BrokerFactory.eventContract(creds)` 按 polymarket 密钥/dryRun 自动选择实盘 `BinanceEventContractBroker` 或 Paper；`MultiEngineOrchestrator.fromCredentials` 改走工厂；删除 `BinanceDemoPerpBroker` | ✅ |
| L-01 | 版本标识三方不一致 | `PACKAGE_VERSION.txt`=v8.2-practical、`versionName`=8.2-practical、`rootProject.name`=BTC-Quant-UI、`app_name`=BTC Quant 且 Manifest label 引用 `@string/app_name` | ✅ |
| L-02 | 4 个孤儿资源 | mipmap icon 接入 Manifest；`app_name` 被 label 引用；两个 xml 配置被 H-02/H-04 组件引用 | ✅ |
| L-03 | 13 个纯死代码类 | 删除类内死代码 + 云控制面契约接线（详见下表） | ✅ |
| L-04 | `kotlinx-datetime` 冗余依赖 | `app/build.gradle.kts` 移除该行 | ✅ |

> M-01（旧彩析 UI 树不可达）：按 H-01 决策"保留并统一初始化"，旧树文件**保留**（其初始化依赖已由 H-01 修复消除崩溃地雷），整树删除留待日后独立决策，避免大范围删除引入回归风险。

---

## 二、逐项修复详情

### H-01 统一 Application 初始化

**做法选择**：经澄清问题未获答复，按安全默认"保留并统一初始化"执行（不删除旧体系，不切换 Manifest 注册类）：

- `CaiFenXiApplication.kt:34`：`class` → `open class`（其余初始化逻辑原样保留）
- `BtcQuantApplication.kt`：改为 `class BtcQuantApplication : CaiFenXiApplication()`，`onCreate()` 首行 `super.onCreate()`（该调用完成旧体系全部单例构建并给 `CaiFenXiApplication.instance` 赋值），随后照旧调度 `BtcWatchdogWorker` 周期任务

**效果**：`CaiFenXiApplication.instance`（CaiFenXiApplication.kt:136）不再可能 UninitializedPropertyAccessException；Manifest 仍注册 `BtcQuantApplication`，`BtcQuantViewModel.kt:81` 的 `getApplication<BtcQuantApplication>()` 类型安全不受影响。

### H-02 / H-03 / H-04 组件注册（AndroidManifest.xml）

新增注册与权限：

- `<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />`
- `AutoBetAccessibilityService`：`exported=true` + `android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE"` + intent-filter（`android.accessibilityservice.AccessibilityService`）+ meta-data `@xml/accessibility_service_config`
- `DataSyncService`：`exported=false`、`foregroundServiceType="dataSync"`（权限 `FOREGROUND_SERVICE_DATA_SYNC` 已存在）
- `ClickRegionPickActivity`：`exported=false` + 通用 theme/configChanges
- `BootCompletedReceiver`：`exported=true`，过滤 `BOOT_COMPLETED` / `MY_PACKAGE_REPLACED`
- `FileProvider`（androidx.core.content.FileProvider）：`authorities="${applicationId}.fileprovider"`、`grantUriPermissions=true`、meta-data `@xml/file_paths`
- `application` icon：`@drawable/ic_launcher` → `@mipmap/ic_launcher`（自适应图标链；drawable 版仍被 `BtcQuantRuntimeService.kt:95` 通知图标保留使用，两者均非孤儿）

### M-02 Broker 实盘接线

- `BrokerCredentials.kt`：`BrokerFactory.eventContract()` 改为 `eventContract(creds: BrokerCredentials = BrokerCredentials())`——`polymarketDryRun || polymarketApiKey.isBlank()` 时返回 `PaperEventContractBroker()`，否则返回 `BinanceEventContractBroker(polymarketApiKey, polymarketApiSecret)`
- `MultiEngineOrchestrator.kt:182`：`BrokerFactory.eventContract(creds)`（原无条件 Paper）
- `BinanceFuturesBroker.kt`：删除零引用类 `BinanceDemoPerpBroker`（377-394 行整段，含过期注释）

### L-03 死代码清理与云控制面接线

| 处理 | 对象 |
|---|---|
| 整文件删除（6） | `automation/SmartRetryPolicy.kt`、`domain/execution/ExecutionEvent.kt`、`domain/execution/ExecutionVerifier.kt`、`domain/plan/PredictionSourceRegistry.kt`、`ui/screens/AiSettingsActivity.kt`、`domain/btc/runtime/BtcOrderReconciler.kt` |
| 类内删除（连带 4） | `BtcBacktestModels.kt`：`WalkForwardResult` + `WalkForwardWindow`；`FuturesModels.kt`：`FuturesOrder` + `FuturesOrderSide`（`FuturesOrderType` 有引用，保留）；`domain/plan/PredictionSource.kt` 整文件（`PredictionSourceType`/`PredictionSourceSelection` 仅互引，零外部引用） |
| 云控制面接线 | `BtcRuntimeController` 新增 `controlPlane: BtcControlPlane = NoopBtcControlPlane` 构造参数；`runOnce()` 起始 pullCommands→`BtcRemoteCommandProcessor.apply`→ack，末尾上报 `BtcHeartbeat` 心跳。默认 Noop 零副作用、异常隔离（runCatching），不影响本地执行主循环 |
| 保留决策 | `BootCompletedReceiver`（有真实功能，转为注册保留而非删除）；`BtcControlPlane`/`NoopBtcControlPlane`/`BtcRemoteCommandProcessor`/`BtcHeartbeat`（契约与实现类接线保留） |

复核修正：审计报告将 `FuturesOrder` 列为纯死代码，经完整词边界复核其唯一引用为定义自身 → 仍按 L-03 删除，但**不删除**有引用的 `FuturesOrderType`。

### L-01 / L-02 / L-04 卫生修复

- `PACKAGE_VERSION.txt`：`v7.8-practical` → `BTC-Quant-UI v8.2-practical`
- `app/build.gradle.kts`：`versionName` `1.0.0-P1` → `8.2-practical`（versionCode 40 保留）；删除 `implementation("org.jetbrains.kotlinx:kotlinx-datetime:0.6.0")`
- `res/values/strings.xml`：`app_name` `彩析` → `BTC Quant`（Manifest label 已改引用 `@string/app_name`，标签随资源统一）
- `settings.gradle.kts`：`rootProject.name` `CaiFenXi` → `BTC-Quant-UI`

---

## 三、修复后全量复验结果

| 维度 | 结果 |
|---|---|
| import 引用完整性 | ✅ 同工程 797 条 import 零断裂 |
| 类/函数/变量交叉引用 | ✅ 未引用顶层类型 **0**（审计 13 → 0；新增连带孤儿已清） |
| Manifest 组件 ↔ 类 | ✅ 注册 6 类（Application+2 Service+2 Activity+Receiver+Provider）全部对应源码类存在，XML 合法 |
| R 资源引用 | ✅ 全部 `R.*` 引用可解析 |
| 孤儿资源 | ✅ 0（4 个审计孤儿全部消除） |
| Gradle 依赖 | ✅ `kotlinx-datetime` 移除，无残留 |
| 主链路 | ✅ `MainActivity → BtcQuantScreen → BtcQuantViewModel → domain/btc.*` 自洽，`BtcQuantApplication` 类型引用安全 |
| Room | ✅ 未触碰，9 Entity / 7 DAO 注册不变 |

**语法校验**：受影响 8 个 Kotlin 文件括号配平通过；`BtcRuntimeStore` 的 `config()/saveConfig()/setKillSwitch()` 与命令处理器引用一致。

## 四、已知限制

- 沙箱无 Android SDK / Gradle，未执行真实编译；以上为静态复验结果
- KSP 生成代码（Room/序列化）通过注册面与注解面核对，未实际编译
- 云控制面接入仅验证契约接线与 Noop 路径；真实云端实现需自行注入
- H-01 采用"保留并统一初始化"默认路线；如需彻底移除旧体系，可后续再评估整树删除（M-01）