# P5 / P6 / P7 完成说明

## P5 Polymarket
- `PolymarketRepository`: Gamma 发现 + CLOB order book
- `PolymarketEdgeEngine`: modelP vs 可成交价 Edge，独立 `PredictionMarketSignal`
- `PolymarketClobBroker`: 默认 dry-run，实盘需凭证

## P6 Event Contract
- `EventContractEngine`: Higher/Lower + Premium EV
- `PaperEventContractBroker`: API 未就绪前纸面执行
- 信号类型 `EventContractSignal` 与永续隔离

## P7 Portfolio
- `PortfolioRiskEngine`: 日亏、名义、同向 BTC 暴露、分引擎限额
- `MultiEngineOrchestrator`: 单 tick 共享特征，分信号分 Broker

## 仍须人工配置
- Polymarket 钱包 / API 签名
- 币安事件合约正式交易 API（若有）
- `AiPolicy.allowLiveAiOrders` 与 LIVE Broker
