package com.caifenxi.app.domain.btc.broker

import com.caifenxi.app.domain.btc.TradingSignal
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

interface EventContractBroker {
    suspend fun place(signal: TradingSignal.EventContractSignal): BrokerResult
    suspend fun probeApiAvailable(): Boolean = false
}

/** PAPER until official Event Contract trade endpoint is confirmed and keys injected. */
class PaperEventContractBroker : EventContractBroker {
    override suspend fun place(signal: TradingSignal.EventContractSignal): BrokerResult =
        BrokerResult(
            ok = true,
            orderId = "EVT-PAPER-${signal.windowId.take(24)}",
            message = "paper ${signal.direction} premium=${signal.premium} edge=${"%.3f".format(signal.edgeAfterPremium)}"
        )
}

/**
 * Attempts known Binance public hosts for product presence.
 * Does NOT place live event orders (API surface varies by region/app).
 */
class BinanceEventContractBroker(
    private val apiKey: String = "",
    private val secretKey: String = "",
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()
) : EventContractBroker {
    override suspend fun place(signal: TradingSignal.EventContractSignal): BrokerResult {
        if (apiKey.isBlank()) {
            return PaperEventContractBroker().place(signal)
        }
        // No stable documented fapi path for Event Contracts trading as of integration —
        // refuse live to avoid wrong endpoints.
        return BrokerResult(
            false,
            null,
            "事件合约官方交易 REST 未固化：已拒绝实盘。信号已生成 window=${signal.windowId}"
        )
    }

    override suspend fun probeApiAvailable(): Boolean = withContext(Dispatchers.IO) {
        // Futures ping only proves network; event product is App-centric
        runCatching {
            val req = Request.Builder().url("https://fapi.binance.com/fapi/v1/ping").get().build()
            client.newCall(req).execute().use { it.isSuccessful }
        }.getOrDefault(false)
    }
}
