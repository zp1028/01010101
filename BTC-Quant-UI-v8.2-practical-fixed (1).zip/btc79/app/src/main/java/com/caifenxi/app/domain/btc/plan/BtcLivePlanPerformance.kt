package com.caifenxi.app.domain.btc.plan

import com.caifenxi.app.domain.btc.BtcCandle
import com.caifenxi.app.domain.btc.DerivativesFeatures
import com.caifenxi.app.domain.btc.backtest.BacktestConfig
import com.caifenxi.app.domain.btc.backtest.BtcBacktestEngine

/**
 * Refreshes live plan performance once per completed bar, not every polling tick.
 * This makes dynamic weights useful in Runtime without repeatedly running backtests.
 */
class BtcLivePlanPerformance(
    private val registry: BtcPlanRegistry = BtcPlanRegistry(),
    private val backtest: BtcBacktestEngine = BtcBacktestEngine(),
    private val lookbackBars: Int = 220
) {
    private var cachedBarId: Long = Long.MIN_VALUE
    private var cached: Map<String, DynamicWeightEngine.PlanPerf> = emptyMap()

    fun get(candles: List<BtcCandle>, deriv: DerivativesFeatures? = null): Map<String, DynamicWeightEngine.PlanPerf> {
        val barId = candles.lastOrNull()?.openTime ?: return cached
        if (barId == cachedBarId) return cached
        val data = if (candles.size > lookbackBars) candles.takeLast(lookbackBars) else candles
        val results = registry.enabled().mapNotNull { def ->
            runCatching {
                backtest.run(
                    planId = def.id,
                    candles = data,
                    config = BacktestConfig(walkForwardTrainBars = 120, walkForwardTestBars = 40),
                )
            }.getOrNull()
        }
        cached = DynamicWeightEngine.fromBacktest(results)
        cachedBarId = barId
        return cached
    }
}
