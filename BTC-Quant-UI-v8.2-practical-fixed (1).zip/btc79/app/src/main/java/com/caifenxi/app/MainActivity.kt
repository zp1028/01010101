package com.caifenxi.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.caifenxi.app.ui.BtcQuantViewModel
import com.caifenxi.app.ui.screens.BtcQuantScreen
import com.caifenxi.app.ui.theme.CaiTheme

class MainActivity : ComponentActivity() {
    private val viewModel: BtcQuantViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CaiTheme(darkTheme = isSystemInDarkTheme()) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    BtcQuantScreen(viewModel)
                }
            }
        }
    }
}
