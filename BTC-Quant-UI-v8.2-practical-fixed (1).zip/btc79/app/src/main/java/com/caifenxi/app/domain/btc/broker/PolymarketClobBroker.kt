package com.caifenxi.app.domain.btc.broker

import com.caifenxi.app.domain.btc.TradingSignal
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

interface EventMarketBroker {
    suspend fun place(signal: TradingSignal.PredictionMarketSignal): BrokerResult
    suspend fun cancel(orderId: String): BrokerResult = BrokerResult(false, null, "cancel not implemented")
}

data class BrokerResult(
    val ok: Boolean,
    val orderId: String? = null,
    val message: String = ""
)

/**
 * Polymarket CLOB order adapter.
 *
 * Full production signing uses EIP-712 / L2 HMAC headers per Polymarket docs.
 * This implementation:
 * - dryRun: local accept
 * - with apiKey: POST order JSON skeleton to CLOB (will fail without valid signature — surfaces real API errors)
 */
class PolymarketClobBroker(
    private val dryRun: Boolean = true,
    private val apiKey: String = "",
    private val apiSecret: String = "",
    private val passphrase: String = "",
    private val clobBase: String = "https://clob.polymarket.com",
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()
) : EventMarketBroker {

    override suspend fun place(signal: TradingSignal.PredictionMarketSignal): BrokerResult = withContext(Dispatchers.IO) {
        if (signal.action != "BUY") return@withContext BrokerResult(false, null, "action=${signal.action}")
        if (dryRun || apiKey.isBlank()) {
            return@withContext BrokerResult(
                true,
                "POLY-DRY-${signal.marketId.take(8)}",
                "dry-run ${signal.outcome}@${signal.marketPrice} edge=${signal.edge}"
            )
        }
        // Order body shape aligned with CLOB open API (signature fields still required by server)
        val body = JSONObject()
            .put("tokenID", signal.marketId) // callers should pass token id in marketId when live
            .put("price", signal.marketPrice)
            .put("size", 5)
            .put("side", "BUY")
            .put("feeRateBps", 0)
            .put("nonce", System.currentTimeMillis())
            .put("expiration", 0)
            .put("type", "GTC")
            .toString()
        val req = Request.Builder()
            .url("$clobBase/order")
            .post(body.toRequestBody("application/json".toMediaType()))
            .header("Content-Type", "application/json")
            .header("POLY_API_KEY", apiKey)
            // POLY_SIGNATURE / POLY_TIMESTAMP / POLY_PASSPHRASE need wallet signer — not embedded
            .apply {
                if (passphrase.isNotBlank()) header("POLY_PASSPHRASE", passphrase)
            }
            .build()
        try {
            client.newCall(req).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                if (resp.isSuccessful) {
                    val id = runCatching { JSONObject(text).optString("orderID") }.getOrNull()
                    BrokerResult(true, id, text.take(200))
                } else {
                    BrokerResult(false, null, "CLOB ${resp.code}: ${text.take(240)}（需完整 L1/L2 签名）")
                }
            }
        } catch (e: Exception) {
            BrokerResult(false, null, e.message ?: "poly place error")
        }
    }

    override suspend fun cancel(orderId: String): BrokerResult = withContext(Dispatchers.IO) {
        if (dryRun) return@withContext BrokerResult(true, orderId, "dry-run cancel")
        BrokerResult(false, orderId, "live cancel needs signed DELETE")
    }
}
