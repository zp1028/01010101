package com.caifenxi.app.domain.btc.broker

import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.TradingSignal
import com.caifenxi.app.domain.btc.futures.ClosePositionRequest
import com.caifenxi.app.domain.btc.futures.FuturesOrderType
import com.caifenxi.app.domain.btc.futures.LeverageResult
import com.caifenxi.app.domain.btc.futures.MarginMode
import com.caifenxi.app.domain.btc.futures.PositionRiskInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

enum class BinanceFuturesEndpoint(val baseUrl: String, val label: String) {
    /** Binance Futures Demo Trading */
    DEMO("https://demo-fapi.binance.com", "demo"),
    /** Classic USDⓈ-M testnet */
    TESTNET("https://testnet.binancefuture.com", "testnet"),
    /** Production — only when user explicitly enables LIVE */
    MAINNET("https://fapi.binance.com", "mainnet")
}

/**
 * Signed USDⓈ-M Futures REST adapter.
 * Keys MUST be injected at runtime (EncryptedSharedPreferences / server), never baked into APK.
 */
class BinanceFuturesBroker(
    private val apiKey: String,
    private val secretKey: String,
    private val endpoint: BinanceFuturesEndpoint = BinanceFuturesEndpoint.DEMO,
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()
) : PerpBroker {

    override suspend fun place(signal: TradingSignal.ContractSignal, clientOrderId: String): BrokerOrderResult =
        withContext(Dispatchers.IO) {
            try {
                require(apiKey.isNotBlank() && secretKey.isNotBlank()) { "缺少 API Key" }
                require(clientOrderId.length in 1..36) { "clientOrderId 长度非法" }
                require(signal.direction != BtcDirection.FLAT) { "FLAT 不可下单" }
                val side = if (signal.direction == BtcDirection.UP) "BUY" else "SELL"
                val qty = formatQty(signal.positionSize)
                val params = linkedMapOf(
                    "symbol" to signal.symbol.uppercase(),
                    "side" to side,
                    "type" to "MARKET",
                    "quantity" to qty,
                    "newClientOrderId" to clientOrderId.take(36),
                    "newOrderRespType" to "RESULT",
                    "timestamp" to System.currentTimeMillis().toString(),
                    "recvWindow" to "5000"
                )
                // reduceOnly not set — one-way mode open
                val json = signed("POST", "/fapi/v1/order", params)
                BrokerOrderResult(
                    success = true,
                    orderId = json.optLong("orderId").takeIf { it != 0L },
                    clientOrderId = json.optString("clientOrderId", clientOrderId),
                    status = json.optString("status", "UNKNOWN"),
                    message = "ok ${endpoint.label}"
                )
            } catch (e: Exception) {
                BrokerOrderResult(false, null, clientOrderId, "ERROR", e.message ?: "place failed")
            }
        }

    override suspend fun cancel(symbol: String, orderId: Long?, clientOrderId: String?): BrokerOrderResult =
        withContext(Dispatchers.IO) {
            try {
                val params = linkedMapOf(
                    "symbol" to symbol.uppercase(),
                    "timestamp" to System.currentTimeMillis().toString(),
                    "recvWindow" to "5000"
                )
                orderId?.let { params["orderId"] = it.toString() }
                clientOrderId?.let { params["origClientOrderId"] = it }
                val json = signed("DELETE", "/fapi/v1/order", params)
                BrokerOrderResult(
                    true,
                    json.optLong("orderId").takeIf { it != 0L },
                    json.optString("clientOrderId", clientOrderId.orEmpty()),
                    json.optString("status", "CANCELED")
                )
            } catch (e: Exception) {
                BrokerOrderResult(false, null, clientOrderId.orEmpty(), "ERROR", e.message ?: "cancel failed")
            }
        }

    override suspend fun accountSnapshot(): BrokerAccountSnapshot = withContext(Dispatchers.IO) {
        val json = signed("GET", "/fapi/v2/account", linkedMapOf(
            "timestamp" to System.currentTimeMillis().toString(),
            "recvWindow" to "5000"
        ))
        BrokerAccountSnapshot(
            availableBalance = json.optString("availableBalance", "0").toDoubleOrNull() ?: 0.0,
            totalWalletBalance = json.optString("totalWalletBalance", "0").toDoubleOrNull() ?: 0.0,
            unrealizedPnl = json.optString("totalUnrealizedProfit", "0").toDoubleOrNull() ?: 0.0
        )
    }

    override suspend fun setLeverage(symbol: String, leverage: Int): LeverageResult =
        withContext(Dispatchers.IO) {
            try {
                require(leverage in 1..125) { "leverage out of range: $leverage" }
                val params = linkedMapOf(
                    "symbol" to symbol.uppercase(),
                    "leverage" to leverage.toString(),
                    "timestamp" to System.currentTimeMillis().toString(),
                    "recvWindow" to "5000"
                )
                val json = signed("POST", "/fapi/v1/leverage", params)
                LeverageResult(
                    success = true,
                    leverage = json.optInt("leverage", leverage),
                    maxNotionalValue = json.optString("maxNotionalValue", "0").toDoubleOrNull() ?: 0.0,
                    message = "leverage set to ${json.optInt("leverage", leverage)}x ${endpoint.label}"
                )
            } catch (e: Exception) {
                LeverageResult(false, leverage, 0.0, e.message ?: "setLeverage failed")
            }
        }

    override suspend fun setMarginMode(symbol: String, mode: MarginMode): BrokerOrderResult =
        withContext(Dispatchers.IO) {
            try {
                val params = linkedMapOf(
                    "symbol" to symbol.uppercase(),
                    "marginType" to mode.binanceValue,
                    "timestamp" to System.currentTimeMillis().toString(),
                    "recvWindow" to "5000"
                )
                val json = signed("POST", "/fapi/v1/marginType", params)
                BrokerOrderResult(
                    success = true,
                    clientOrderId = "",
                    status = json.optString("msg", "ok"),
                    message = "marginType=${mode.binanceValue} ${endpoint.label}"
                )
            } catch (e: Exception) {
                // No-change response code -1104 is expected when already set
                val msg = e.message.orEmpty()
                if (msg.contains("-4046") || msg.contains("No need to change")) {
                    BrokerOrderResult(true, null, "", "NO_CHANGE", "already ${mode.binanceValue}")
                } else {
                    BrokerOrderResult(false, null, "", "ERROR", msg.ifEmpty { "setMarginMode failed" })
                }
            }
        }

    override suspend fun fetchPositionRisk(symbol: String): PositionRiskInfo? =
        withContext(Dispatchers.IO) {
            try {
                val params = linkedMapOf(
                    "symbol" to symbol.uppercase(),
                    "timestamp" to System.currentTimeMillis().toString(),
                    "recvWindow" to "5000"
                )
                val arr = signedArray("GET", "/fapi/v2/positionRisk", params)
                if (arr.length() == 0) return@withContext null
                val row = arr.optJSONObject(0) ?: return@withContext null
                val posAmt = row.optString("positionAmt", "0").toDoubleOrNull() ?: 0.0
                if (posAmt == 0.0) return@withContext null
                PositionRiskInfo(
                    symbol = row.optString("symbol", symbol),
                    positionAmt = posAmt,
                    entryPrice = row.optString("entryPrice", "0").toDoubleOrNull() ?: 0.0,
                    markPrice = row.optString("markPrice", "0").toDoubleOrNull() ?: 0.0,
                    unRealizedProfit = row.optString("unRealizedProfit", "0").toDoubleOrNull() ?: 0.0,
                    liquidationPrice = row.optString("liquidationPrice", "0").toDoubleOrNull() ?: 0.0,
                    leverage = row.optString("leverage", "1"),
                    maxNotionalValue = row.optString("maxNotionalValue", "0"),
                    marginType = row.optString("marginType", "isolated")
                )
            } catch (e: Exception) {
                null
            }
        }

    override suspend fun placeConditionalOrder(
        symbol: String,
        side: String,
        type: FuturesOrderType,
        quantity: Double,
        stopPrice: Double?,
        trailingDelta: Double?,
        reduceOnly: Boolean,
        clientOrderId: String
    ): BrokerOrderResult = withContext(Dispatchers.IO) {
        try {
            require(clientOrderId.length in 1..36) { "clientOrderId length invalid" }
            require(type != FuturesOrderType.MARKET && type != FuturesOrderType.LIMIT) {
                "use place() for MARKET/LIMIT; this is for conditional orders only"
            }
            val params = linkedMapOf(
                "symbol" to symbol.uppercase(),
                "side" to side,
                "type" to type.binanceValue,
                "quantity" to formatQty(quantity),
                "newClientOrderId" to clientOrderId.take(36),
                "newOrderRespType" to "RESULT",
                "timestamp" to System.currentTimeMillis().toString(),
                "recvWindow" to "5000"
            )
            stopPrice?.let { params["stopPrice"] = "%.2f".format(it) }
            trailingDelta?.let { params["trailingDelta"] = "%.0f".format(it) }
            if (reduceOnly) params["reduceOnly"] = "true"
            // TRAILING_STOP_MARKET uses workingType=MARK_PRICE by default; STOP_MARKET needs stopPrice
            if (type == FuturesOrderType.STOP_MARKET || type == FuturesOrderType.TAKE_PROFIT_MARKET) {
                require(stopPrice != null) { "$type requires stopPrice" }
                params["workingType"] = "MARK_PRICE"
            }
            val json = signed("POST", "/fapi/v1/order", params)
            BrokerOrderResult(
                success = true,
                orderId = json.optLong("orderId").takeIf { it != 0L },
                clientOrderId = json.optString("clientOrderId", clientOrderId),
                status = json.optString("status", "NEW"),
                message = "${type.binanceValue} ${endpoint.label}"
            )
        } catch (e: Exception) {
            BrokerOrderResult(false, null, clientOrderId, "ERROR", e.message ?: "conditional order failed")
        }
    }

    override suspend fun closePosition(request: ClosePositionRequest): BrokerOrderResult =
        withContext(Dispatchers.IO) {
            try {
                // Fetch current position to determine side and qty
                val risk = fetchPositionRisk(request.symbol)
                if (risk == null || risk.positionAmt == 0.0) {
                    return@withContext BrokerOrderResult(
                        true, null, "", "NO_POSITION", "no open position for ${request.symbol}"
                    )
                }
                val closeSide = if (risk.positionAmt > 0.0) "SELL" else "BUY"
                val closeQty = formatQty(kotlin.math.abs(risk.positionAmt))
                val params = linkedMapOf(
                    "symbol" to request.symbol.uppercase(),
                    "side" to closeSide,
                    "type" to "MARKET",
                    "quantity" to closeQty,
                    "newClientOrderId" to "close-${System.currentTimeMillis()}".take(36),
                    "newOrderRespType" to "RESULT",
                    "timestamp" to System.currentTimeMillis().toString(),
                    "recvWindow" to "5000"
                )
                if (request.reduceOnly) params["reduceOnly"] = "true"
                val json = signed("POST", "/fapi/v1/order", params)
                BrokerOrderResult(
                    success = true,
                    orderId = json.optLong("orderId").takeIf { it != 0L },
                    clientOrderId = json.optString("clientOrderId", ""),
                    status = json.optString("status", "FILLED"),
                    message = "closed ${request.symbol} ${closeSide} qty=$closeQty reason=${request.reason}"
                )
            } catch (e: Exception) {
                BrokerOrderResult(false, null, "", "ERROR", e.message ?: "closePosition failed")
            }
        }

    /** Public connectivity check (no signature). */
    suspend fun ping(): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val req = Request.Builder().url("${endpoint.baseUrl}/fapi/v1/ping").get().build()
            client.newCall(req).execute().use { it.isSuccessful }
        }.getOrDefault(false)
    }



    private fun signedArray(method: String, path: String, params: LinkedHashMap<String, String>): JSONArray {
        val query = params.entries.joinToString("&") { "${enc(it.key)}=${enc(it.value)}" }
        val signature = hmac(query, secretKey)
        val url = "${endpoint.baseUrl}$path?$query&signature=$signature"
        val b = Request.Builder().url(url).header("X-MBX-APIKEY", apiKey)
        when (method) {
            "POST" -> b.post(FormBody.Builder().build())
            "DELETE" -> b.delete()
            else -> b.get()
        }
        client.newCall(b.build()).execute().use { resp ->
            val body = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) error("Binance ${endpoint.label} ${resp.code}: ${body.take(300)}")
            return JSONArray(body)
        }
    }

    private fun signed(method: String, path: String, params: LinkedHashMap<String, String>): JSONObject {
        val query = params.entries.joinToString("&") { "${enc(it.key)}=${enc(it.value)}" }
        val signature = hmac(query, secretKey)
        val url = "${endpoint.baseUrl}$path?$query&signature=$signature"
        val b = Request.Builder().url(url).header("X-MBX-APIKEY", apiKey)
        when (method) {
            "POST" -> b.post(FormBody.Builder().build())
            "DELETE" -> b.delete()
            else -> b.get()
        }
        client.newCall(b.build()).execute().use { resp ->
            val body = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) error("Binance ${endpoint.label} ${resp.code}: ${body.take(300)}")
            return JSONObject(body)
        }
    }

    private fun formatQty(q: Double): String {
        // BTCUSDT step often 0.001 — keep 3dp default; exchange filters still apply
        return "%.3f".format(q.coerceAtLeast(0.001))
    }

    private fun enc(s: String) = URLEncoder.encode(s, Charsets.UTF_8.name())
    private fun hmac(data: String, secret: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        return mac.doFinal(data.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
    }
}

/** No network; for PAPER mode. */
class PaperPerpBroker : PerpBroker {
    private var paperLeverage = 3
    private var paperMarginMode = MarginMode.ISOLATED
    private var paperBalance = 10_000.0
    private val paperPositions = mutableMapOf<String, PositionRiskInfo>()

    override suspend fun place(signal: TradingSignal.ContractSignal, clientOrderId: String) =
        BrokerOrderResult(true, null, clientOrderId, "PAPER_FILLED", "paper ${signal.direction} qty=${signal.positionSize}")

    override suspend fun cancel(symbol: String, orderId: Long?, clientOrderId: String?) =
        BrokerOrderResult(true, orderId, clientOrderId.orEmpty(), "PAPER_CANCELED")

    override suspend fun accountSnapshot() = BrokerAccountSnapshot(paperBalance, paperBalance, 0.0)

    override suspend fun setLeverage(symbol: String, leverage: Int): LeverageResult {
        paperLeverage = leverage
        return LeverageResult(true, leverage, 50000.0, "paper leverage set to ${leverage}x")
    }

    override suspend fun setMarginMode(symbol: String, mode: MarginMode): BrokerOrderResult {
        paperMarginMode = mode
        return BrokerOrderResult(true, null, "", "PAPER_OK", "paper marginType=${mode.binanceValue}")
    }

    override suspend fun fetchPositionRisk(symbol: String): PositionRiskInfo? = paperPositions[symbol]

    override suspend fun placeConditionalOrder(
        symbol: String,
        side: String,
        type: FuturesOrderType,
        quantity: Double,
        stopPrice: Double?,
        trailingDelta: Double?,
        reduceOnly: Boolean,
        clientOrderId: String
    ): BrokerOrderResult = BrokerOrderResult(
        true, System.currentTimeMillis(), clientOrderId, "PAPER_NEW",
        "paper ${type.binanceValue} side=$side qty=$quantity stop=$stopPrice reduceOnly=$reduceOnly"
    )

    override suspend fun closePosition(request: ClosePositionRequest): BrokerOrderResult {
        paperPositions.remove(request.symbol)
        return BrokerOrderResult(true, null, "", "PAPER_CLOSED", "paper closed ${request.symbol} reason=${request.reason}")
    }

    /** Paper-only helper: simulate position for PAPER mode monitoring. */
    fun setPaperPosition(symbol: String, info: PositionRiskInfo) {
        paperPositions[symbol] = info
    }
}
