package com.caifenxi.app.domain.btc.ai

import com.caifenxi.app.domain.btc.BtcCandle
import com.caifenxi.app.domain.btc.BtcConsensus
import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.BtcPlanSignal
import com.caifenxi.app.domain.btc.DerivativesFeatures
import com.caifenxi.app.domain.btc.news.NewsSnapshot
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

/**
 * P4 "brain" layer.
 *
 * Default: local rules synthesizer that EMITS the same forced JSON schema as an LLM would.
 * Optional: if [llmEndpoint] + [llmApiKey] provided, posts context and parses JSON only.
 *
 * NEVER places orders. LIVE gate must ignore AI unless explicitly enabled in config.
 */
class AiBrain(
    private val llmEndpoint: String? = null,
    private val llmApiKey: String? = null
) {
    fun generateCandidate(
        candles: List<BtcCandle>,
        plans: List<BtcPlanSignal>,
        consensus: BtcConsensus?,
        news: NewsSnapshot?,
        deriv: DerivativesFeatures?
    ): AiPlanCandidate {
        val barId = candles.lastOrNull()?.openTime ?: 0L
        val local = localSynthesize(barId, plans, consensus, news, deriv)
        // Optional remote LLM path reserved — parse failure falls back to local
        val remote = if (!llmEndpoint.isNullOrBlank() && !llmApiKey.isNullOrBlank()) {
            null // keep offline-first in this build; wire HTTP later without blocking PAPER
        } else null
        return remote ?: local
    }

    fun toForcedJson(c: AiPlanCandidate): String {
        val o = JSONObject()
        o.put("barId", c.barId)
        o.put(
            "direction",
            when (c.direction) {
                BtcDirection.UP -> "up"
                BtcDirection.DOWN -> "down"
                BtcDirection.FLAT -> "skip"
            }
        )
        o.put("confidence", c.confidence)
        o.put("expectedMovePct", c.expectedMovePct)
        o.put("reasons", JSONArray(c.reasons))
        o.put("invalidIf", JSONArray(c.invalidIf))
        o.put("suggestedSizePct", c.suggestedSizePct)
        o.put("newsBias", c.newsBias)
        o.put("source", c.source)
        return o.toString()
    }

    private fun localSynthesize(
        barId: Long,
        plans: List<BtcPlanSignal>,
        consensus: BtcConsensus?,
        news: NewsSnapshot?,
        deriv: DerivativesFeatures?
    ): AiPlanCandidate {
        val reasons = mutableListOf<String>()
        val invalid = mutableListOf<String>()
        var score = consensus?.let {
            when (it.direction) {
                BtcDirection.UP -> it.probability
                BtcDirection.DOWN -> -it.probability
                BtcDirection.FLAT -> 0.0
            }
        } ?: 0.0
        reasons += "consensus=${consensus?.direction} p=${"%.2f".format(consensus?.probability ?: 0.0)}"

        val newsBias = news?.netSentiment ?: 0.0
        score += newsBias * 0.25
        reasons += "newsSentiment=${"%.2f".format(newsBias)}"
        if (news?.blackSwan == true) {
            invalid += "black_swan_news"
            score *= 0.2
            reasons += "BLACK_SWAN_HALT"
        }

        deriv?.let {
            score += it.derivativesScore * 0.2
            reasons += "derivScore=${"%.2f".format(it.derivativesScore)} fundingZ=${"%.2f".format(it.fundingZScore)}"
            if (it.fundingExtreme) reasons += "funding_extreme"
        }

        val topPlans = plans.sortedByDescending { abs(it.contribution) }.take(3)
        topPlans.forEach { reasons += "plan ${it.planId}:${it.direction}@${"%.2f".format(it.contribution)}" }

        val direction = when {
            score > 0.12 -> BtcDirection.UP
            score < -0.12 -> BtcDirection.DOWN
            else -> BtcDirection.FLAT
        }
        if (consensus?.regime?.name?.contains("HIGH_VOL") == true) {
            invalid += "high_volatility_chop"
        }
        val conf = abs(score).coerceIn(0.0, 1.0)
        val json = toForcedJson(
            AiPlanCandidate(
                barId = barId,
                direction = direction,
                confidence = conf,
                expectedMovePct = consensus?.expectedMovePct ?: 0.0,
                reasons = reasons,
                invalidIf = invalid,
                suggestedSizePct = if (conf > 0.7) 0.4 else 0.2,
                newsBias = newsBias,
                source = "local-rules-brain"
            )
        )
        // Round-trip parse guarantees schema validity
        return AiJsonParser.parse(json, barId) ?: AiPlanCandidate(
            barId, BtcDirection.FLAT, 0.0, 0.0, listOf("parse_failed"), listOf("invalid_json"), 0.0, 0.0
        )
    }
}
