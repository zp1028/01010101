package com.caifenxi.app.domain.btc.paper

/**
 * 二元期权预测下注 — 核心模型
 *
 * 机制：每 5 分钟一个周期，预测窗口结束时 BTC 价格比开始时涨(Yes)或跌(No)。
 * 结算：单次价格快照，只取窗口结束瞬间的价格判定胜负。
 * 风险：无爆仓、无资金费率、无杠杆、无止损止盈；亏损上限 = 投入本金。
 */

/** 预测方向 */
enum class BetDirection(val label: String) {
    YES("Yes \u00b7 涨"),
    NO("No \u00b7 跌")
}

/** 周期状态 */
enum class RoundPhase { OPEN, SETTLING, SETTLED }

/** 5 分钟预测周期 */
data class PredictionRound(
    val roundId: Long,              // 周期唯一 ID（通常用 startTime 做ID）
    val startTime: Long,            // 窗口开始时间戳（毫秒）
    val endTime: Long,              // 窗口结束时间戳（毫秒）
    val openPrice: Double,          // 窗口开始价格快照
    val closePrice: Double? = null, // 窗口结束价格快照（结算前为 null）
    val phase: RoundPhase = RoundPhase.OPEN,
    val result: BetDirection? = null,  // 结算结果（close > open = YES，close < open = NO，相等 = NO）
    val source: String = "BINANCE",   // 价格来源：BINANCE / POLYMARKET
    val lockedDirection: BetDirection? = null  // 周期开始时锁定的预测方向，周期内不变
) {
    /** 周期时长（秒） */
    val durationSec: Long get() = (endTime - startTime) / 1000

    /** 距离结束倒计时（秒），如果已结束返回 0 */
    fun remainingSec(now: Long): Long = ((endTime - now) / 1000).coerceAtLeast(0)

    /** 是否在窗口内（可下注） */
    fun isOpen(now: Long): Boolean = now >= startTime && now < endTime && phase == RoundPhase.OPEN

    /** 是否已锁定方向 */
    fun isDirectionLocked(): Boolean = lockedDirection != null

    /** 是否已在本周期下过注 */
    fun hasBet(): Boolean = lockedDirection != null
}

/** 日级控制配置 */
data class DailyControlConfig(
    val dailyStopLossPct: Double = 5.0,      // 日最大亏损百分比（占日初余额）
    val dailyTakeProfitPct: Double = 10.0,   // 日目标盈利百分比（占日初余额）
    val maxDailyBets: Int = 60,              // 日最大下注次数（5min周期 x 12 = 288上限，保守60）
    val enabled: Boolean = true
) {
    /** 日最大亏损金额 */
    fun dailyStopLossAmount(startBalance: Double): Double = startBalance * dailyStopLossPct / 100.0
    /** 日目标盈利金额 */
    fun dailyTakeProfitAmount(startBalance: Double): Double = startBalance * dailyTakeProfitPct / 100.0
}

/** 日级盈亏统计 */
data class DailyStats(
    val date: String,                  // 日期 YYYY-MM-DD
    val startBalance: Double,           // 日初余额
    val currentBalance: Double,         // 当前余额
    val totalBets: Int = 0,             // 总下注次数
    val wins: Int = 0,                  // 胜次数
    val losses: Int = 0,                // 负次数
    val totalWagered: Double = 0.0,     // 累计下注金额
    val totalPayout: Double = 0.0,      // 累计拿回金额
    val peakBalance: Double = 0.0,      // 日内峰值余额
    val maxDrawdown: Double = 0.0,      // 日内最大回撤（金额）
    val stopLossHit: Boolean = false,   // 是否触达日止损
    val takeProfitHit: Boolean = false, // 是否触达日止盈
    val autoStopped: Boolean = false    // 是否自动停机
) {
    /** 日净盈亏 */
    val netProfit: Double get() = currentBalance - startBalance
    /** 日净盈亏百分比 */
    val netProfitPct: Double get() = if (startBalance > 0) netProfit * 100.0 / startBalance else 0.0
    /** 日胜率 */
    val winRatePct: Double get() = if (totalBets > 0) wins * 100.0 / totalBets else 0.0
    /** 日内回撤百分比 */
    val maxDrawdownPct: Double get() = if (peakBalance > 0) maxDrawdown * 100.0 / peakBalance else 0.0
    /** 是否盈利 */
    val isProfitable: Boolean get() = netProfit > 0
    /** 盈亏比（平均赢 / 平均输） */
    val profitFactor: Double get() {
        val grossWin = totalPayout - totalWagered
        return if (totalBets > 0) grossWin / (totalWagered - totalPayout + grossWin).coerceAtLeast(0.001) else 0.0
    }
}

/** 单笔下注 */
data class Bet(
    val betId: String,              // 下注唯一 ID
    val roundId: Long,              // 关联周期 ID
    val direction: BetDirection,   // YES（涨）或 NO（跌）
    val amount: Double,             // 下注金额（USDT）
    val odds: Double,               // 赔率（如 1.9 表示赢了拿回 amount * 1.9）
    val placedAt: Long,             // 下注时间戳
    val source: BetSource = BetSource.PAPER,  // 下注来源
    val platformMarketId: String? = null       // Polymarket/币安的市场 ID
) {
    /** 如果赢，可得收益 = amount * (odds - 1) */
    val potentialPayout: Double get() = amount * odds

    /** 如果赢，净收益 = amount * (odds - 1) */
    val potentialProfit: Double get() = amount * (odds - 1.0)

    /** 如果输，亏损 = amount（即投入本金） */
    val maxLoss: Double get() = amount
}

/** 下注来源 */
enum class BetSource(val label: String) {
    PAPER("Paper \u00b7 模拟"),
    POLYMARKET("Polymarket"),
    BINANCE("Binance \u00b7 预测")
}

/** 已结算的下注记录 */
data class SettledBet(
    val bet: Bet,
    val round: PredictionRound,
    val won: Boolean,               // 是否赢
    val payout: Double,             // 实际拿回金额（赢 = amount * odds，输 = 0）
    val profit: Double,             // 净盈亏（赢 = amount*(odds-1)，输 = -amount）
    val settledAt: Long             // 结算时间戳
)

/** 账户状态 */
data class BinaryOptionAccount(
    val initialBalance: Double = 10_000.0,
    val balance: Double = 10_000.0,
    val pendingBets: List<Bet> = emptyList(),       // 等待结算的下注
    val settledBets: List<SettledBet> = emptyList(),  // 已结算的下注
    val totalWagered: Double = 0.0,                  // 累计下注金额
    val totalPayout: Double = 0.0,                   // 累计拿回金额
    val winCount: Int = 0,
    val lossCount: Int = 0,
    val maxBalance: Double = 10_000.0,
    val maxDrawdownPct: Double = 0.0
) {
    val totalTrades: Int get() = winCount + lossCount
    val winRatePct: Double get() = if (totalTrades > 0) winCount * 100.0 / totalTrades else 0.0
    val netProfit: Double get() = totalPayout - totalWagered
    val roiPct: Double get() = if (initialBalance > 0) netProfit * 100.0 / initialBalance else 0.0
    val profitFactor: Double get() {
        val gross = settledBets.filter { it.profit > 0 }.sumOf { it.profit }
        val loss = settledBets.filter { it.profit < 0 }.sumOf { -it.profit }
        return if (loss > 0) gross / loss else if (gross > 0) Double.MAX_VALUE else 0.0
    }
    val avgBetSize: Double get() = if (totalTrades > 0) totalWagered / totalTrades else 0.0

    /** 检查指定周期是否已有待结算下注（防止同周期重复下注） */
    fun hasBetForRound(roundId: Long): Boolean = pendingBets.any { it.roundId == roundId }
}

/** 二元期权配置 */
data class BinaryOptionConfig(
    val initialBalance: Double = 10_000.0,
    val roundDurationSec: Long = 300,    // 每周期 5 分钟 = 300 秒
    val defaultOdds: Double = 1.9,       // 默认赔率（仅作回退用，实际赔率由市场定价决定）
    val minBet: Double = 1.0,             // 最小下注 1 USDT
    val maxBet: Double = 1000.0,          // 单笔最大下注
    val maxPendingBetsPerRound: Int = 1,  // 每周期最多下注数
    val platformFeePct: Double = 0.0,     // 平台手续费（Polymarket 可能有）
    val fixedBetAmount: Double = 1.0,      // 固定下注金额 1 USDT/注（不使用凯利动态份额）
    val minEdgeThreshold: Double = 0.01   // edge > 1% 才下注，否则跳过
) {
    /** 周期时长（毫秒） */
    val roundDurationMs: Long get() = roundDurationSec * 1000
}

/** 下注请求 */
data class BetRequest(
    val direction: BetDirection,
    val amount: Double,
    val odds: Double,
    val source: BetSource = BetSource.PAPER,
    val platformMarketId: String? = null,
    val timestamp: Long
)

/** 下注结果 */
sealed class BetResult {
    data class Accepted(val bet: Bet) : BetResult()
    data class Rejected(val reason: String) : BetResult()
}

/** 市场赔率信息（从 Polymarket/币安获取） */
data class MarketOdds(
    val platform: String,          // POLYMARKET / BINANCE
    val marketId: String,          // 市场标识
    val question: String,          // 市场问题（如 "BTC 5min Up?"）
    val yesOdds: Double,           // Yes 赔率
    val noOdds: Double,            // No 赔率
    val yesPrice: Double,          // Yes 份额价格（0-1，Polymarket 格式）
    val noPrice: Double,           // No 份额价格
    val liquidity: Double,         // 流动性（USDT）
    val volume24h: Double,          // 24h 交易量
    val endTime: Long,              // 市场结束时间
    val resolved: Boolean = false   // 是否已结算
) {
    /** 赔率 = 1 / price */
    companion object {
        fun priceToOdds(price: Double): Double = if (price > 0) 1.0 / price else 0.0
        fun oddsToPrice(odds: Double): Double = if (odds > 0) 1.0 / odds else 0.0
    }
}

/** 周期统计摘要 */
data class RoundStats(
    val totalRounds: Int = 0,
    val yesWins: Int = 0,           // 结果为涨的周期数
    val noWins: Int = 0,            // 结果为跌的周期数
    val userWins: Int = 0,          // 用户赢的次数
    val userLosses: Int = 0,        // 用户输的次数
    val bestStreak: Int = 0,        // 最长连胜
    val currentStreak: Int = 0,     // 当前连续结果
    val totalWagered: Double = 0.0,
    val totalPayout: Double = 0.0
) {
    val winRatePct: Double get() = if (userWins + userLosses > 0) userWins * 100.0 / (userWins + userLosses) else 0.0
    val yesRatePct: Double get() = if (totalRounds > 0) yesWins * 100.0 / totalRounds else 0.0
    val roiPct: Double get() = if (totalWagered > 0) (totalPayout - totalWagered) * 100.0 / totalWagered else 0.0
}

/**
 * Edge 评估结果 — 比较模型概率与市场定价，选择定价错误方向下注
 *
 * 核心逻辑：不是"预测涨跌方向"，而是"找定价错误"。
 * edge = 模型概率 - 市场隐含概率
 * 选 edge 为正且超过阈值的方向，否则跳过该周期。
 */
data class EdgeAssessment(
    val modelProbYes: Double,        // 模型计算的 YES 概率 (0~1)
    val modelProbNo: Double,         // 模型计算的 NO 概率 (0~1)
    val marketProbYes: Double,       // 市场隐含 YES 概率 = yesPrice
    val marketProbNo: Double,        // 市场隐含 NO 概率 = noPrice
    val marketYesOdds: Double,       // YES 赔率 = 1 / yesPrice
    val marketNoOdds: Double,        // NO 赔率 = 1 / noPrice
    val edgeYes: Double,             // YES 方向 edge = modelProbYes - marketProbYes
    val edgeNo: Double,              // NO 方向 edge = modelProbNo - marketProbNo
    val chosenDirection: BetDirection?, // 最终选择的下注方向（null = 不下注）
    val chosenOdds: Double,           // 选择方向的变动赔率
    val chosenEdge: Double,           // 选择方向的 edge 值
    val chosenModelProb: Double,      // 选择方向的模型概率
    val betAmount: Double,            // 固定下注金额 = 1 USDT
    val shouldBet: Boolean,           // 是否应该下注（edge > 阈值）
    val evPerBet: Double,             // 单笔期望值 EV = modelProb * (odds - 1) - (1 - modelProb)
    val reason: String                // 决策说明
) {
    companion object {
        /** 无市场数据时跳过 */
        fun noMarket(reason: String): EdgeAssessment = EdgeAssessment(
            modelProbYes = 0.5, modelProbNo = 0.5,
            marketProbYes = 0.5, marketProbNo = 0.5,
            marketYesOdds = 1.0, marketNoOdds = 1.0,
            edgeYes = 0.0, edgeNo = 0.0,
            chosenDirection = null, chosenOdds = 0.0, chosenEdge = 0.0,
            chosenModelProb = 0.0, betAmount = 0.0, shouldBet = false,
            evPerBet = 0.0, reason = reason
        )
    }
}
