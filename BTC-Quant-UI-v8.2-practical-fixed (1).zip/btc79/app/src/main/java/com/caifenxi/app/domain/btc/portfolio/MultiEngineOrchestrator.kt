package com.caifenxi.app.domain.btc.portfolio

import com.caifenxi.app.domain.btc.BinanceDerivativesRepository
import com.caifenxi.app.domain.btc.BinanceMarketRepository
import com.caifenxi.app.domain.btc.BtcPlanEngine
import com.caifenxi.app.domain.btc.BtcSignalFactory
import com.caifenxi.app.domain.btc.DerivativesFeatureEngine
import com.caifenxi.app.domain.btc.TradingSignal
import com.caifenxi.app.domain.btc.ai.AiBrain
import com.caifenxi.app.domain.btc.ai.AiPolicy
import com.caifenxi.app.domain.btc.ai.AiPolicyConfig
import com.caifenxi.app.domain.btc.broker.BrokerResult
import com.caifenxi.app.domain.btc.broker.EventContractBroker
import com.caifenxi.app.domain.btc.broker.EventMarketBroker
import com.caifenxi.app.domain.btc.broker.PaperEventContractBroker
import com.caifenxi.app.domain.btc.broker.PerpBroker
import com.caifenxi.app.domain.btc.broker.PolymarketClobBroker
import com.caifenxi.app.domain.btc.event.EventContractEngine
import com.caifenxi.app.domain.btc.event.EventExpiryWindow
import com.caifenxi.app.domain.btc.futures.FuturesQuantConfig
import com.caifenxi.app.domain.btc.futures.FuturesQuantEngine
import com.caifenxi.app.domain.btc.futures.FuturesSignal
import com.caifenxi.app.domain.btc.news.CryptoNewsRepository
import com.caifenxi.app.domain.btc.polymarket.PolymarketEdgeEngine
import com.caifenxi.app.domain.btc.polymarket.PolymarketRepository
import com.caifenxi.app.domain.btc.risk.BtcRiskEngine
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope

data class OrchestratorReport(
    val perpSignal: TradingSignal.ContractSignal?,
    val perpResult: BrokerResult?,
    val futuresSignal: FuturesSignal? = null,
    val eventSignal: TradingSignal.EventContractSignal?,
    val eventResult: BrokerResult?,
    val polySignals: List<TradingSignal.PredictionMarketSignal>,
    val polyResults: List<BrokerResult>,
    val notes: List<String>
)

/**
 * Single tick across engines with shared features but isolated signals + portfolio shell.
 */
class MultiEngineOrchestrator(
    private val market: BinanceMarketRepository = BinanceMarketRepository(),
    private val derivRepo: BinanceDerivativesRepository = BinanceDerivativesRepository(),
    private val newsRepo: CryptoNewsRepository = CryptoNewsRepository(),
    private val planEngine: BtcPlanEngine = BtcPlanEngine(),
    private val signalFactory: BtcSignalFactory = BtcSignalFactory(),
    private val aiBrain: AiBrain = AiBrain(),
    private val aiPolicy: AiPolicyConfig = AiPolicyConfig(allowLiveAiOrders = false),
    private val perpRisk: BtcRiskEngine = BtcRiskEngine(),
    private val portfolio: PortfolioRiskEngine = PortfolioRiskEngine(),
    private val eventEngine: EventContractEngine = EventContractEngine(),
    private val polyRepo: PolymarketRepository = PolymarketRepository(),
    private val polyEdge: PolymarketEdgeEngine = PolymarketEdgeEngine(),
    private val perpBroker: PerpBroker? = null,
    private val eventBroker: EventContractBroker = PaperEventContractBroker(),
    private val polyBroker: EventMarketBroker = PolymarketClobBroker(dryRun = true),
    private val futuresEngine: FuturesQuantEngine = FuturesQuantEngine(),
    private val futuresConfig: FuturesQuantConfig = FuturesQuantConfig(),
    private val enableEvent: Boolean = true,
    private val enablePoly: Boolean = true,
    private val enableFutures: Boolean = false
) {
    suspend fun tick(
        symbol: String = "BTCUSDT",
        timeframe: String = "15m",
        portfolioState: PortfolioState = PortfolioState(),
        eventWindow: EventExpiryWindow = EventExpiryWindow.M30
    ): OrchestratorReport = coroutineScope {
        val notes = mutableListOf<String>()
        val candlesDef = async { market.loadKlines(symbol, timeframe, 300) }
        val fundingDef = async { runCatching { derivRepo.fundingHistory(symbol) }.getOrDefault(emptyList()) }
        val oiDef = async { runCatching { derivRepo.openInterestHistory(symbol, timeframe) }.getOrDefault(emptyList()) }
        val newsDef = async { runCatching { newsRepo.snapshot() }.getOrNull() }
        val candles = candlesDef.await()
        if (candles.size < 80) {
            return@coroutineScope OrchestratorReport(null, null, null, null, null, emptyList(), emptyList(), listOf("kline不足"))
        }
        val last = candles.last()
        val prev = candles.getOrNull(candles.lastIndex - 1)
        val deriv = DerivativesFeatureEngine.build(last.openTime, last.close, prev?.close, fundingDef.await(), oiDef.await())
        val news = newsDef.await()
        if (news?.blackSwan == true) {
            return@coroutineScope OrchestratorReport(null, null, null, null, null, emptyList(), emptyList(), listOf("新闻黑天鹅：全引擎停开"))
        }
        val (basePlans, baseConsensus) = planEngine.evaluate(candles, deriv)
        val ai = aiBrain.generateCandidate(candles, basePlans, baseConsensus, news, deriv)
        val aiPlan = AiPolicy.toPlanSignal(ai, aiPolicy)
        val (plans, consensus) = if (aiPlan != null) planEngine.evaluate(candles, deriv, extraSignals = listOf(aiPlan))
        else basePlans to baseConsensus

        // --- Perp ---
        var perpSig: TradingSignal.ContractSignal? = null
        var perpRes: BrokerResult? = null
        var futuresSig: FuturesSignal? = null
        if (consensus != null) {
            val s = signalFactory.buildPerpSignal(symbol, candles, plans, consensus, 0.001)
            if (s != null) {
                val r1 = perpRisk.authorize(consensus, 0.0, 0.0, 5.0)
                val r2 = portfolio.authorizePerp(s, portfolioState, last.close)
                if (r1.allowed && r2.allowed) {
                    perpSig = s
                    perpRes = if (perpBroker != null) {
                        val cid = "P-${s.planId}-${s.barId}"
                        runCatching {
                            val r = perpBroker.place(s, cid)
                            BrokerResult(r.success, r.clientOrderId, r.message.ifBlank { r.status })
                        }.getOrElse { BrokerResult(false, null, it.message ?: "err") }
                    } else BrokerResult(true, "PERP-PAPER", "paper perp ${s.direction}")
                } else notes += "perp拒绝: ${r1.reason}/${r2.reason}"
            }

            // --- Futures quant signal (shared consensus, independent execution) ---
            if (enableFutures) {
                futuresSig = futuresEngine.evaluateSignal(
                    consensus = consensus,
                    candles = candles,
                    config = futuresConfig,
                    balance = 10_000.0,
                    deriv = deriv
                )
                if (futuresSig != null) {
                    notes += "futures signal: ${futuresSig.direction} lev=${futuresSig.leverage}x conf=${"%.0f%%".format(futuresSig.confidence * 100)}"
                }
            }
        }

        // --- Event contract ---
        var eventSig: TradingSignal.EventContractSignal? = null
        var eventRes: BrokerResult? = null
        if (enableEvent && consensus != null) {
            val q = eventEngine.quote(symbol, eventWindow, consensus, candles)
            if (q != null) {
                val sig = eventEngine.toSignal(q, "${symbol}-${eventWindow}-${last.openTime}")
                if (sig != null) {
                    val pr = portfolio.authorizeEvent(sig, portfolioState)
                    if (pr.allowed) {
                        eventSig = sig
                        eventRes = eventBroker.place(sig)
                    } else notes += "event拒绝: ${pr.reason}"
                } else notes += "event无足够edge"
            }
        }

        // --- Polymarket ---
        val polySigs = mutableListOf<TradingSignal.PredictionMarketSignal>()
        val polyResults = mutableListOf<BrokerResult>()
        if (enablePoly) {
            val modelYes = polyEdge.modelYesProbability(consensus, news?.netSentiment ?: 0.0)
            val markets = runCatching { polyRepo.searchCryptoMarkets(10) }.getOrElse {
                notes += "poly发现失败: ${it.message}"
                emptyList()
            }
            for (m in markets.take(3)) {
                val bookYes = runCatching { polyRepo.orderBook(m.yesTokenId) }.getOrNull()
                val bookNo = runCatching { polyRepo.orderBook(m.noTokenId) }.getOrNull()
                val opps = polyEdge.evaluateMarket(m, bookYes, bookNo, modelYes)
                for (op in opps.filter { it.action == "BUY" }.take(1)) {
                    val sig = polyEdge.toSignal(op) ?: continue
                    val pr = portfolio.authorizeProb(sig, portfolioState, sizeUsdt = 10.0)
                    if (!pr.allowed) {
                        notes += "poly拒绝 ${m.slug}: ${pr.reason}"
                        continue
                    }
                    polySigs += sig
                    polyResults += polyBroker.place(sig)
                }
            }
        }

        OrchestratorReport(perpSig, perpRes, futuresSig, eventSig, eventRes, polySigs, polyResults, notes)
    }

    companion object {
        fun fromCredentials(
            creds: com.caifenxi.app.domain.btc.broker.BrokerCredentials,
            paperPerp: Boolean = false
        ): MultiEngineOrchestrator = MultiEngineOrchestrator(
            perpBroker = com.caifenxi.app.domain.btc.broker.BrokerFactory.perp(creds, forcePaper = paperPerp),
            eventBroker = com.caifenxi.app.domain.btc.broker.BrokerFactory.eventContract(creds),
            polyBroker = com.caifenxi.app.domain.btc.broker.BrokerFactory.polymarket(creds)
        )
    }
}
