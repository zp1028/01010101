package com.caifenxi.app.domain.btc.plan

import com.caifenxi.app.domain.btc.BtcPlanFamily
import com.caifenxi.app.domain.btc.BtcPlanSignal
import com.caifenxi.app.domain.btc.DerivativesFeatures
import com.caifenxi.app.domain.btc.MarketRegime
import com.caifenxi.app.domain.btc.backtest.BacktestResult
import kotlin.math.exp

/**
 * Adjusts plan weights from:
 * 1) base family weight
 * 2) rolling sample-out performance (PF / DD)
 * 3) regime fit
 * 4) derivatives regime (boost/cut FUNDING-FADE etc.)
 */
object DynamicWeightEngine {

    data class PlanPerf(
        val planId: String,
        val profitFactor: Double,
        val maxDrawdownPct: Double,
        val winRatePct: Double,
        val samples: Int
    )

    fun fromBacktest(results: List<BacktestResult>): Map<String, PlanPerf> =
        results.groupBy { it.planId }.mapValues { (id, list) ->
            // Prefer recent out-of-sample windows. This prevents an old strong
            // regime from permanently dominating live weights.
            val ordered = list.sortedBy { it.trades.lastOrNull()?.barId ?: Long.MIN_VALUE }
            val recent = ordered.takeLast(3)
            val weights = recent.mapIndexed { index, _ -> (index + 1).toDouble() }
            val w = weights.sum().coerceAtLeast(1.0)
            PlanPerf(
                planId = id,
                profitFactor = recent.mapIndexed { i, r -> r.profitFactor * weights[i] }.sum() / w,
                maxDrawdownPct = recent.mapIndexed { i, r -> r.maxDrawdownPct * weights[i] }.sum() / w,
                winRatePct = recent.mapIndexed { i, r -> r.winRatePct * weights[i] }.sum() / w,
                samples = recent.sumOf { it.sampleSize }
            )
        }

    fun performanceMultiplier(perf: PlanPerf?): Double {
        if (perf == null || perf.samples < 20) return 1.0
        val pfTerm = ((perf.profitFactor - 1.0).coerceIn(-0.5, 1.5)) * 0.35
        val ddPenalty = (perf.maxDrawdownPct / 40.0).coerceIn(0.0, 1.0) * -0.25
        val wrTerm = ((perf.winRatePct - 50.0) / 100.0).coerceIn(-0.2, 0.2)
        return (1.0 + pfTerm + ddPenalty + wrTerm).coerceIn(0.45, 1.75)
    }

    fun regimeMultiplier(family: BtcPlanFamily, regime: MarketRegime): Double = when (regime) {
        MarketRegime.TREND_UP, MarketRegime.TREND_DOWN -> when (family) {
            BtcPlanFamily.TREND, BtcPlanFamily.STRUCTURE -> 1.20
            BtcPlanFamily.MOMENTUM -> 1.10
            BtcPlanFamily.VOLUME -> 1.05
            BtcPlanFamily.VOLATILITY -> 0.95
            BtcPlanFamily.DERIVATIVES -> 0.90
            BtcPlanFamily.AI -> 0.80
        }
        MarketRegime.RANGE -> when (family) {
            BtcPlanFamily.MOMENTUM -> 1.15 // mean-revert styles live here
            BtcPlanFamily.TREND -> 0.70
            BtcPlanFamily.STRUCTURE -> 0.85
            BtcPlanFamily.VOLATILITY -> 0.90
            else -> 1.0
        }
        MarketRegime.BREAKOUT, MarketRegime.HIGH_VOLATILITY -> when (family) {
            BtcPlanFamily.VOLATILITY, BtcPlanFamily.STRUCTURE -> 1.20
            BtcPlanFamily.TREND -> 1.05
            BtcPlanFamily.DERIVATIVES -> 1.10
            else -> 0.95
        }
    }

    fun derivativesMultiplier(planId: String, family: BtcPlanFamily, deriv: DerivativesFeatures?): Double {
        if (deriv == null) return if (family == BtcPlanFamily.DERIVATIVES) 0.6 else 1.0
        return when {
            planId.contains("FUNDING") || family == BtcPlanFamily.DERIVATIVES -> {
                if (deriv.fundingExtreme) 1.35 else 0.75
            }
            family == BtcPlanFamily.TREND -> {
                // Price-OI alignment supports trend plans
                1.0 + (deriv.priceOiAlign * 0.15)
            }
            else -> 1.0
        }.coerceIn(0.5, 1.6)
    }

    fun apply(
        signals: List<BtcPlanSignal>,
        regime: MarketRegime,
        deriv: DerivativesFeatures?,
        perf: Map<String, PlanPerf> = emptyMap()
    ): List<BtcPlanSignal> {
        return signals.map { s ->
            val mult = performanceMultiplier(perf[s.planId]) *
                regimeMultiplier(s.family, regime) *
                derivativesMultiplier(s.planId, s.family, deriv)
            val newWeight = (s.weight * mult).coerceIn(0.2, 2.5)
            val newContribution = s.rawScore * s.confidence * newWeight * s.regimeFit
            s.copy(weight = newWeight, contribution = newContribution)
        }.sortedByDescending { abs(it.contribution) }
    }

    private fun abs(v: Double) = if (v < 0) -v else v
}
