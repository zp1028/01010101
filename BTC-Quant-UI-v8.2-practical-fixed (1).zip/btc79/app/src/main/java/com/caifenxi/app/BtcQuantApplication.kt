package com.caifenxi.app

import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.caifenxi.app.service.btc.BtcWatchdogWorker
import java.util.concurrent.TimeUnit

/**
 * BTC Quant 产品入口（Manifest 注册类）。
 *
 * 继承 [CaiFenXiApplication] 统一初始化：
 *  - 父类 onCreate 会完成旧体系全局单例构建并给 `CaiFenXiApplication.instance` 赋值，
 *    避免审计 H-01：旧路径 17 处引用 `CaiFenXiApplication.instance` 触发
 *    UninitializedPropertyAccessException；
 *  - 本类在 super.onCreate() 之后负责 BTC Quant 自身的 watchdog 周期任务调度。
 */
class BtcQuantApplication : CaiFenXiApplication() {
    override fun onCreate() {
        super.onCreate()
        instance = this
        val request = PeriodicWorkRequestBuilder<BtcWatchdogWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "btc-quant-watchdog",
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }

    companion object {
        @Volatile
        lateinit var instance: BtcQuantApplication
            private set
    }
}