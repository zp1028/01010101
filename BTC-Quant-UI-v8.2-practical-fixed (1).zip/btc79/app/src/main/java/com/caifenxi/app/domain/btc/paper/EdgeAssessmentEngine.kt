package com.caifenxi.app.domain.btc.paper

import com.caifenxi.app.domain.btc.BtcConsensus
import com.caifenxi.app.domain.btc.BtcDirection

/**
 * Edge 评估引擎 — 核心决策层
 *
 * 核心逻辑：不是"预测涨跌方向"，而是"找定价错误"。
 *
 * 1. 模型计算方向概率（来自 BtcConsensus）
 * 2. 获取市场定价（Polymarket YES/NO 价格 = 市场隐含概率）
 * 3. 计算 edge = 模型概率 - 市场隐含概率
 * 4. 选 edge 更大且 > minEdgeThreshold 的方向下注
 * 5. edge 不足则跳过该周期
 *
 * 变动赔率：赔率 = 1 / 市场价格，由实时市场定价决定
 * 固定下注：1 USDT/注，不使用凯利公式动态份额
 */
class EdgeAssessmentEngine(
    private val fixedBetAmount: Double = 1.0,
    private val minEdgeThreshold: Double = 0.01,
    private val defaultOdds: Double = 1.9
) {

    /**
     * 评估当前周期是否值得下注，以及下注哪个方向。
     *
     * @param consensus 策略池共识（含 direction, probability, consensusStrength）
     * @param marketOdds 市场赔率信息（来自 Polymarket/Binance）
     * @return EdgeAssessment 含两个方向的 edge、选择的方向、变动赔率
     */
    fun assess(
        consensus: BtcConsensus?,
        marketOdds: MarketOdds?
    ): EdgeAssessment {

        // === 无市场数据时，回退到默认赔率 ===
        if (marketOdds == null) {
            return assessNoMarket(consensus)
        }

        // === Step 1: 模型概率 ===
        val modelProbYes: Double = when (consensus?.direction) {
            BtcDirection.UP -> consensus.probability.coerceIn(0.01, 0.99)
            BtcDirection.DOWN -> (1.0 - consensus.probability).coerceIn(0.01, 0.99)
            BtcDirection.FLAT, null -> 0.50
        }
        val modelProbNo = 1.0 - modelProbYes

        // === Step 2: 市场隐含概率 = 份额价格 ===
        val marketProbYes = marketOdds.yesPrice.coerceIn(0.01, 0.99)
        val marketProbNo = marketOdds.noPrice.coerceIn(0.01, 0.99)

        // === Step 3: 赔率 = 1 / 价格 ===
        val marketYesOdds = MarketOdds.priceToOdds(marketProbYes)
        val marketNoOdds = MarketOdds.priceToOdds(marketProbNo)

        // === Step 4: 计算 edge ===
        val edgeYes = modelProbYes - marketProbYes
        val edgeNo = modelProbNo - marketProbNo

        // === Step 5: 选 edge 更大且 > 阈值的方向 ===
        val chosenDirection: BetDirection?
        val chosenOdds: Double
        val chosenEdge: Double
        val chosenModelProb: Double
        val shouldBet: Boolean

        if (edgeYes >= edgeNo && edgeYes > minEdgeThreshold) {
            // YES 方向 edge 更大且超过阈值
            chosenDirection = BetDirection.YES
            chosenOdds = marketYesOdds
            chosenEdge = edgeYes
            chosenModelProb = modelProbYes
            shouldBet = true
        } else if (edgeNo > edgeYes && edgeNo > minEdgeThreshold) {
            // NO 方向 edge 更大且超过阈值
            chosenDirection = BetDirection.NO
            chosenOdds = marketNoOdds
            chosenEdge = edgeNo
            chosenModelProb = modelProbNo
            shouldBet = true
        } else {
            // 两个方向 edge 均不足，跳过
            chosenDirection = null
            chosenOdds = 0.0
            chosenEdge = maxOf(edgeYes, edgeNo)
            chosenModelProb = if (edgeYes >= edgeNo) modelProbYes else modelProbNo
            shouldBet = false
        }

        // === Step 6: 计算单笔 EV ===
        // EV = P_win * (odds - 1) - P_lose * 1
        val evPerBet = if (shouldBet && chosenDirection != null) {
            chosenModelProb * (chosenOdds - 1.0) - (1.0 - chosenModelProb)
        } else 0.0

        // === 决策说明 ===
        val reason = if (shouldBet) {
            buildString {
                append("Bet ${chosenDirection!!.name} @ ${"%.2f".format(chosenOdds)}x")
                append(" edge=+${"%.1f%%".format(chosenEdge * 100)}")
                append(" model=${"%.0f%%".format(chosenModelProb * 100)}")
                append(" mkt=${"%.0f%%".format(if (chosenDirection == BetDirection.YES) marketProbYes else marketProbNo)}")
                append(" EV=+${"%.3f".format(evPerBet)}")
            }
        } else {
            "SKIP: edgeYes=${"%.1f%%".format(edgeYes * 100)} edgeNo=${"%.1f%%".format(edgeNo * 100)} < ${"%.1f%%".format(minEdgeThreshold * 100)}"
        }

        return EdgeAssessment(
            modelProbYes = modelProbYes,
            modelProbNo = modelProbNo,
            marketProbYes = marketProbYes,
            marketProbNo = marketProbNo,
            marketYesOdds = marketYesOdds,
            marketNoOdds = marketNoOdds,
            edgeYes = edgeYes,
            edgeNo = edgeNo,
            chosenDirection = chosenDirection,
            chosenOdds = chosenOdds,
            chosenEdge = chosenEdge,
            chosenModelProb = chosenModelProb,
            betAmount = if (shouldBet) fixedBetAmount else 0.0,
            shouldBet = shouldBet,
            evPerBet = evPerBet,
            reason = reason
        )
    }

    /**
     * 无市场数据时的回退评估：用默认赔率 + 共识方向
     */
    private fun assessNoMarket(consensus: BtcConsensus?): EdgeAssessment {
        val modelProbYes: Double = when (consensus?.direction) {
            BtcDirection.UP -> consensus.probability.coerceIn(0.01, 0.99)
            BtcDirection.DOWN -> (1.0 - consensus.probability).coerceIn(0.01, 0.99)
            BtcDirection.FLAT, null -> 0.50
        }
        val modelProbNo = 1.0 - modelProbYes
        val marketProbYes = MarketOdds.oddsToPrice(defaultOdds)
        val marketProbNo = marketProbYes

        val edgeYes = modelProbYes - marketProbYes
        val edgeNo = modelProbNo - marketProbNo

        val chosenDirection: BetDirection?
        val chosenEdge: Double
        val chosenModelProb: Double

        if (edgeYes >= edgeNo && edgeYes > minEdgeThreshold) {
            chosenDirection = BetDirection.YES
            chosenEdge = edgeYes
            chosenModelProb = modelProbYes
        } else if (edgeNo > edgeYes && edgeNo > minEdgeThreshold) {
            chosenDirection = BetDirection.NO
            chosenEdge = edgeNo
            chosenModelProb = modelProbNo
        } else {
            chosenDirection = null
            chosenEdge = maxOf(edgeYes, edgeNo)
            chosenModelProb = if (edgeYes >= edgeNo) modelProbYes else modelProbNo
        }

        val shouldBet = chosenDirection != null
        val evPerBet = if (shouldBet) {
            chosenModelProb * (defaultOdds - 1.0) - (1.0 - chosenModelProb)
        } else 0.0

        return EdgeAssessment(
            modelProbYes = modelProbYes,
            modelProbNo = modelProbNo,
            marketProbYes = marketProbYes,
            marketProbNo = marketProbNo,
            marketYesOdds = defaultOdds,
            marketNoOdds = defaultOdds,
            edgeYes = edgeYes,
            edgeNo = edgeNo,
            chosenDirection = chosenDirection,
            chosenOdds = if (shouldBet) defaultOdds else 0.0,
            chosenEdge = chosenEdge,
            chosenModelProb = chosenModelProb,
            betAmount = if (shouldBet) fixedBetAmount else 0.0,
            shouldBet = shouldBet,
            evPerBet = evPerBet,
            reason = if (shouldBet) {
                "Bet ${chosenDirection!!.name} @ ${"%.2f".format(defaultOdds)}x (no-market fallback) edge=+${"%.1f%%".format(chosenEdge * 100)}"
            } else {
                "SKIP (no-market): edge < ${"%.1f%%".format(minEdgeThreshold * 100)}"
            }
        )
    }

    /**
     * 批量预览：不同市场定价下的 edge 变化，供 UI 展示
     */
    fun previewMatrix(
        modelProbYes: Double,
        marketPrices: List<Pair<Double, Double>>  // (yesPrice, noPrice)
    ): List<EdgeAssessment> = marketPrices.map { (yesP, noP) ->
        val marketProbYes = yesP.coerceIn(0.01, 0.99)
        val marketProbNo = noP.coerceIn(0.01, 0.99)
        val modelProbNo = 1.0 - modelProbYes
        val edgeYes = modelProbYes - marketProbYes
        val edgeNo = modelProbNo - marketProbNo
        val chosenDir = if (edgeYes >= edgeNo && edgeYes > minEdgeThreshold) BetDirection.YES
            else if (edgeNo > edgeYes && edgeNo > minEdgeThreshold) BetDirection.NO
            else null
        val chosenOdds = if (chosenDir == BetDirection.YES) MarketOdds.priceToOdds(marketProbYes)
            else if (chosenDir == BetDirection.NO) MarketOdds.priceToOdds(marketProbNo)
            else 0.0
        EdgeAssessment(
            modelProbYes = modelProbYes, modelProbNo = modelProbNo,
            marketProbYes = marketProbYes, marketProbNo = marketProbNo,
            marketYesOdds = MarketOdds.priceToOdds(marketProbYes),
            marketNoOdds = MarketOdds.priceToOdds(marketProbNo),
            edgeYes = edgeYes, edgeNo = edgeNo,
            chosenDirection = chosenDir, chosenOdds = chosenOdds,
            chosenEdge = if (chosenDir == BetDirection.YES) edgeYes else if (chosenDir == BetDirection.NO) edgeNo else 0.0,
            chosenModelProb = if (chosenDir == BetDirection.YES) modelProbYes else if (chosenDir == BetDirection.NO) modelProbNo else 0.0,
            betAmount = if (chosenDir != null) fixedBetAmount else 0.0,
            shouldBet = chosenDir != null,
            evPerBet = if (chosenDir != null) {
                val p = if (chosenDir == BetDirection.YES) modelProbYes else modelProbNo
                p * (chosenOdds - 1.0) - (1.0 - p)
            } else 0.0,
            reason = "mkt_yes=${"%.0f%%".format(marketProbYes * 100)}"
        )
    }
}
