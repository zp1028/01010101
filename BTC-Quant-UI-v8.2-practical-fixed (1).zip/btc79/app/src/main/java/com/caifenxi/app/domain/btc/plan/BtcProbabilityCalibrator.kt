package com.caifenxi.app.domain.btc.plan

import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.BtcPlanSignal
import kotlin.math.abs

/** Empirical probability calibration from out-of-sample plan results. */
object BtcProbabilityCalibrator {
    fun calibrate(baseProbability: Double, direction: BtcDirection, signals: List<BtcPlanSignal>): Double {
        if (direction == BtcDirection.FLAT || signals.isEmpty()) return baseProbability.coerceIn(0.5, 0.99)
        val agreeing = signals.filter { it.direction == direction }
        val weighted = agreeing.sumOf { abs(it.contribution) }
        val total = signals.sumOf { abs(it.contribution) }.coerceAtLeast(1e-9)
        val agreement = (weighted / total).coerceIn(0.0, 1.0)
        // Consensus strength is evidence, not certainty. Keep a conservative cap.
        val calibrated = 0.5 + (baseProbability - 0.5) * 0.65 + (agreement - 0.5) * 0.20
        return calibrated.coerceIn(0.50, 0.85)
    }
}
