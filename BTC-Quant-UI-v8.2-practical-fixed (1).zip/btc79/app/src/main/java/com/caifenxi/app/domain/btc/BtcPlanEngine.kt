package com.caifenxi.app.domain.btc

import com.caifenxi.app.domain.btc.plan.DynamicWeightEngine
import com.caifenxi.app.domain.btc.plan.BtcPlanRegistry
import com.caifenxi.app.domain.btc.plan.BtcProbabilityCalibrator
import com.caifenxi.app.domain.btc.plan.BtcPlanLifecycleEngine
import com.caifenxi.app.domain.btc.plan.BtcPlanStatus
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Rule plan pool → weighted consensus.
 * Optional [deriv] injects P3 funding/OI factors and dynamic weights.
 */
class BtcPlanEngine(
    private val registry: BtcPlanRegistry = BtcPlanRegistry()
) {

    fun evaluate(
        candles: List<BtcCandle>,
        deriv: DerivativesFeatures? = null,
        perf: Map<String, DynamicWeightEngine.PlanPerf> = emptyMap(),
        extraSignals: List<BtcPlanSignal> = emptyList()
    ): Pair<List<BtcPlanSignal>, BtcConsensus?> {
        if (candles.size < 80) return emptyList<BtcPlanSignal>() to null
        val close = candles.map { it.close }
        val ema9 = ema(close, 9)
        val ema21 = ema(close, 21)
        val ema50 = ema(close, 50)
        val rsi = rsi(close, 14)
        val macd = ema9.last() - ema21.last()
        val macdBase = max(abs(close.last()) * 0.0001, abs(ema21.last() - ema50.last()))
        val atrPct = atr(candles, 14) / close.last()
        val volRatio = candles.takeLast(20).map { it.volume }.average() /
            candles.dropLast(20).takeLast(80).map { it.volume }.average().coerceAtLeast(1e-9)
        val trendScore = clampSigned((ema9.last() - ema50.last()) / max(close.last() * 0.003, 1e-9))
        val momentumScore = clampSigned((rsi.last() - 50.0) / 18.0 + macd / macdBase * 0.35)
        val structureScore = structureScore(candles)
        val volumeScore = clampSigned((volRatio - 1.0) * 1.4 * trendScore)
        val volatilityScore = clampSigned((atrPct - 0.004) * 120.0 * trendScore)
        val derivativesScore = deriv?.derivativesScore ?: 0.0

        val regime = when {
            atrPct > 0.012 -> MarketRegime.HIGH_VOLATILITY
            abs(trendScore) > 0.65 && abs(macd) > macdBase * 0.55 ->
                if (trendScore > 0) MarketRegime.TREND_UP else MarketRegime.TREND_DOWN
            abs(structureScore) > 0.7 && volRatio > 1.25 -> MarketRegime.BREAKOUT
            else -> MarketRegime.RANGE
        }

        val familyScores = mapOf(
            BtcPlanFamily.TREND to trendScore,
            BtcPlanFamily.MOMENTUM to momentumScore,
            BtcPlanFamily.STRUCTURE to structureScore,
            BtcPlanFamily.VOLUME to volumeScore,
            BtcPlanFamily.VOLATILITY to volatilityScore,
            BtcPlanFamily.DERIVATIVES to derivativesScore,
            BtcPlanFamily.AI to 0.0
        )

        // The registry is the single source of truth for enabled plans.
        // Each registered plan receives its family's live feature score, while
        // its own baseWeight and historical performance remain independent.
        val baseSignals = registry.enabled().mapNotNull { definition ->
            val score = familyScores[definition.family] ?: return@mapNotNull null
            if (definition.family == BtcPlanFamily.AI && score == 0.0) return@mapNotNull null
            val fit = regimeFit(definition.family, regime, score)
            val lifecycle = perf[definition.id]?.let { BtcPlanLifecycleEngine.evaluate(definition, it) }
            if (lifecycle?.status == BtcPlanStatus.RETIRED) return@mapNotNull null
            val lifecycleMultiplier = when (lifecycle?.status) {
                BtcPlanStatus.PROMOTED -> 1.10
                BtcPlanStatus.ACTIVE -> 1.00
                BtcPlanStatus.WATCH -> 0.80
                BtcPlanStatus.DOWNWEIGHT -> 0.55
                BtcPlanStatus.RETIRED -> 0.0
                null -> 1.00
            }
            val baseWeight = definition.baseWeight
            val effectiveBaseWeight = (if (definition.family == BtcPlanFamily.DERIVATIVES && deriv?.fundingExtreme == true) {
                baseWeight * 1.20
            } else baseWeight) * lifecycleMultiplier
            val direction = signedDirection(score)
            val confidence = clamp01(abs(score) * 0.85 + fit * 0.15)
            val contribution = score * confidence * effectiveBaseWeight * fit
            BtcPlanSignal(
                planId = definition.id,
                name = definition.name,
                family = definition.family,
                direction = direction,
                rawScore = score,
                confidence = confidence,
                weight = effectiveBaseWeight,
                hitRate = perf[definition.id]?.winRatePct?.div(100.0) ?: 0.5,
                samples = perf[definition.id]?.samples ?: candles.size,
                regimeFit = fit,
                contribution = contribution
            )
        }

        val signals = DynamicWeightEngine.apply(baseSignals + extraSignals, regime, deriv, perf)
        val consensus = buildConsensus(signals, regime, trendScore, atrPct)
        return signals to consensus
    }

    private fun buildConsensus(
        signals: List<BtcPlanSignal>,
        regime: MarketRegime,
        trendScore: Double,
        atrPct: Double
    ): BtcConsensus {
        var up = 0.0
        var down = 0.0
        var flat = 0.0
        signals.forEach { s ->
            when (s.direction) {
                BtcDirection.UP -> up += abs(s.contribution)
                BtcDirection.DOWN -> down += abs(s.contribution)
                BtcDirection.FLAT -> flat += abs(s.contribution) * 0.5
            }
        }
        val total = (up + down + flat).coerceAtLeast(1e-9)
        val direction = when {
            up > down * 1.15 && up > flat -> BtcDirection.UP
            down > up * 1.15 && down > flat -> BtcDirection.DOWN
            else -> BtcDirection.FLAT
        }
        val strength = when (direction) {
            BtcDirection.UP -> up / total
            BtcDirection.DOWN -> down / total
            BtcDirection.FLAT -> flat / total
        }
        val probability = clamp01(0.5 + (strength - 0.33) * 0.9)
        val calibratedProbability = BtcProbabilityCalibrator.calibrate(probability, direction, signals)
        return BtcConsensus(
            direction = direction,
            probability = calibratedProbability,
            consensusStrength = strength,
            upScore = up / total,
            downScore = down / total,
            flatScore = flat / total,
            regime = regime,
            trendScore = trendScore,
            volatility = atrPct,
            expectedMovePct = atrPct * 100.0 * 1.6,
            riskScore = clamp01(atrPct / 0.02)
        )
    }

    private fun regimeFit(family: BtcPlanFamily, regime: MarketRegime, score: Double): Double {
        val base = when (regime) {
            MarketRegime.TREND_UP, MarketRegime.TREND_DOWN -> when (family) {
                BtcPlanFamily.TREND, BtcPlanFamily.STRUCTURE -> 1.0
                BtcPlanFamily.MOMENTUM -> 0.9
                BtcPlanFamily.DERIVATIVES -> 0.75
                else -> 0.8
            }
            MarketRegime.RANGE -> when (family) {
                BtcPlanFamily.MOMENTUM -> 1.0
                BtcPlanFamily.TREND -> 0.55
                BtcPlanFamily.DERIVATIVES -> 0.7
                else -> 0.75
            }
            MarketRegime.BREAKOUT, MarketRegime.HIGH_VOLATILITY -> when (family) {
                BtcPlanFamily.VOLATILITY, BtcPlanFamily.STRUCTURE -> 1.0
                BtcPlanFamily.DERIVATIVES -> 0.95
                else -> 0.85
            }
        }
        return clamp01(base * (0.65 + abs(score) * 0.35))
    }

    private fun structureScore(candles: List<BtcCandle>): Double {
        val win = candles.takeLast(8)
        val higherHigh = win.zipWithNext().count { it.second.high >= it.first.high }
        val higherLow = win.zipWithNext().count { it.second.low >= it.first.low }
        val lowerHigh = win.zipWithNext().count { it.second.high <= it.first.high }
        val lowerLow = win.zipWithNext().count { it.second.low <= it.first.low }
        val bull = (higherHigh + higherLow).toDouble() / (win.size * 2)
        val bear = (lowerHigh + lowerLow).toDouble() / (win.size * 2)
        return clampSigned((bull - bear) * 2.2)
    }

    private fun ema(values: List<Double>, period: Int): List<Double> {
        val k = 2.0 / (period + 1)
        val out = MutableList(values.size) { 0.0 }
        var prev = values.take(period).average()
        for (i in values.indices) {
            prev = if (i < period - 1) values.take(i + 1).average() else values[i] * k + prev * (1 - k)
            out[i] = prev
        }
        return out
    }

    private fun rsi(values: List<Double>, period: Int): List<Double> {
        val out = MutableList(values.size) { 50.0 }
        if (values.size <= period) return out
        var gain = 0.0
        var loss = 0.0
        for (i in 1..period) {
            val d = values[i] - values[i - 1]
            if (d >= 0) gain += d else loss -= d
        }
        gain /= period; loss /= period
        out[period] = if (loss == 0.0) 100.0 else 100 - 100 / (1 + gain / loss)
        for (i in period + 1 until values.size) {
            val d = values[i] - values[i - 1]
            val g = max(d, 0.0); val l = max(-d, 0.0)
            gain = (gain * (period - 1) + g) / period
            loss = (loss * (period - 1) + l) / period
            out[i] = if (loss == 0.0) 100.0 else 100 - 100 / (1 + gain / loss)
        }
        return out
    }

    private fun atr(c: List<BtcCandle>, period: Int): Double {
        val trs = c.zipWithNext().map { (p, x) ->
            max(x.high - x.low, max(abs(x.high - p.close), abs(x.low - p.close)))
        }
        return trs.takeLast(period).average()
    }

    private fun clampSigned(v: Double) = v.coerceIn(-1.0, 1.0)
}
