package com.caifenxi.app.domain.btc

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray

class BinanceMarketRepository(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
        .build(),
    private val baseUrl: String = "https://fapi.binance.com"
) {
    suspend fun loadKlines(symbol: String, interval: String, limit: Int = 300): List<BtcCandle> = withContext(Dispatchers.IO) {
        require(symbol.matches(Regex("[A-Za-z0-9._-]{3,20}"))) { "非法交易对: $symbol" }
        require(interval.matches(Regex("[0-9]+[mhdwM]"))) { "非法周期: $interval" }
        val safeLimit = limit.coerceIn(80, 1500)
        val url = "$baseUrl/fapi/v1/klines?symbol=${symbol.uppercase()}&interval=$interval&limit=$safeLimit"
        val request = Request.Builder().url(url).get().build()
        client.newCall(request).execute().use { response ->
            check(response.isSuccessful) { "行情请求失败: HTTP ${response.code}" }
            val body = response.body?.string().orEmpty()
            val arr = JSONArray(body)
            buildList(arr.length()) {
                var previousTime = Long.MIN_VALUE
                for (i in 0 until arr.length()) {
                    val k = arr.getJSONArray(i)
                    val openTime = k.getLong(0)
                    val open = k.getString(1).toDouble()
                    val high = k.getString(2).toDouble()
                    val low = k.getString(3).toDouble()
                    val close = k.getString(4).toDouble()
                    val volume = k.getString(5).toDouble()
                    if (openTime <= previousTime) continue
                    if (listOf(open, high, low, close, volume).any { !it.isFinite() }) continue
                    if (high < low || high < maxOf(open, close) || low > minOf(open, close)) continue
                    add(BtcCandle(openTime, open, high, low, close, volume))
                    previousTime = openTime
                }
            }
        }
    }
}
