package com.caifenxi.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.btc.paper.BetDirection
import com.caifenxi.app.domain.btc.paper.BinaryOptionAccount
import com.caifenxi.app.domain.btc.paper.BinaryOptionStats
import com.caifenxi.app.domain.btc.paper.PredictionRound
import com.caifenxi.app.domain.btc.paper.SettledBet
import com.caifenxi.app.ui.BtcQuantViewModel
import com.caifenxi.app.ui.theme.CaiTokens

/**
 * 二元期权预测下注 Tab
 *
 * 功能：5 分钟周期倒计时 / Yes-No 下注 / 赔率展示 / 结算历史 / 收益统计 / 市场赔率
 */
@Composable
fun PaperTradingTab(viewModel: BtcQuantViewModel) {
    val state by viewModel.state.collectAsState()
    val binaryAccount by viewModel.binaryAccount.collectAsState()
    val binaryStats by viewModel.binaryStats.collectAsState()
    val currentRound by viewModel.currentRound.collectAsState()
    val betLog by viewModel.betLog.collectAsState()
    val marketOdds by viewModel.marketOddsList.collectAsState()

    var betDirection by remember { mutableStateOf(BetDirection.YES) }
    var betAmount by remember { mutableStateOf("10") }

    // 每秒刷新周期倒计时
    LaunchedEffect(currentRound?.roundId) {
        while (true) {
            viewModel.tickBinaryRound()
            kotlinx.coroutines.delay(1000)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
    ) {
        // 标题
        Row(
            Modifier.fillMaxWidth().padding(24.dp, 18.dp, 24.dp, 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("预测下注", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                Text(
                    "二元期权 \u00b7 5min 周期 \u00b7 Yes/No \u00b7 亏损上限 = 本金",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = { viewModel.resetBinaryAccount() }) {
                Icon(Icons.Filled.Refresh, "Reset")
            }
        }

        // === 当前周期 + 倒计时 ===
        CurrentRoundCard(
            round = currentRound,
            viewModel = viewModel,
            state = state
        )

        Spacer(Modifier.height(8.dp))

        // === 下注面板 ===
        Card(
            Modifier.padding(horizontal = 24.dp, vertical = 4.dp).fillMaxWidth(),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(Modifier.padding(16.dp)) {
                SectionTitleInline("下注")
                val lastPrice = state.candles.lastOrNull()?.close ?: state.markPrice ?: 0.0
                MetricLine("当前 BTC", "%.2f USDT".format(lastPrice))

                val liveDir = viewModel.binaryLiveDirection()
                val liveMove = viewModel.binaryCurrentMovePct()
                MetricLine("实时方向", liveDir.label)
                MetricLine("实时涨跌", "%.2f%%".format(liveMove))

                Spacer(Modifier.height(8.dp))

                // Yes / No 方向选择
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // YES 按钮
                    BetDirectionButton(
                        text = "YES",
                        subtitle = "涨",
                        selected = betDirection == BetDirection.YES,
                        color = CaiTokens.Success,
                        onClick = { betDirection = BetDirection.YES },
                        modifier = Modifier.weight(1f)
                    )
                    // NO 按钮
                    BetDirectionButton(
                        text = "NO",
                        subtitle = "跌",
                        selected = betDirection == BetDirection.NO,
                        color = CaiTokens.Danger,
                        onClick = { betDirection = BetDirection.NO },
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(Modifier.height(8.dp))

                // 下注金额
                OutlinedTextField(
                    value = betAmount,
                    onValueChange = { betAmount = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("下注金额 (USDT)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(4.dp))
                Text(
                    "亏损上限 = 下注本金 \u00b7 赢则拿回 金额 \u00d7 赔率",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(Modifier.height(8.dp))

                // 下注按钮
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        val amt = betAmount.toDoubleOrNull() ?: 10.0
                        viewModel.placeBinaryBet(betDirection, amt, 1.9)
                    }) {
                        Icon(Icons.Filled.PlayArrow, null)
                        Spacer(Modifier.width(6.dp))
                        Text("下注 ${betDirection.label}")
                    }
                    OutlinedButton(onClick = { viewModel.executeBinaryAutoBet() }) {
                        Text("自动信号下注")
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        // === 账户统计 ===
        Card(
            Modifier.padding(horizontal = 24.dp, vertical = 4.dp).fillMaxWidth(),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(Modifier.padding(16.dp)) {
                SectionTitleInline("账户统计")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatMini("胜率", "%.1f%%".format(binaryStats.winRate), CaiTokens.Success)
                    StatMini("盈亏比", "%.2f".format(binaryStats.profitFactor), CaiTokens.Warning)
                    StatMini("回撤", "%.1f%%".format(binaryStats.maxDrawdownPct), CaiTokens.Danger)
                }
                Spacer(Modifier.height(8.dp))
                MetricLine("余额", "%.2f USDT".format(binaryAccount.balance))
                MetricLine("净盈亏", "%.2f USDT".format(binaryAccount.netProfit))
                MetricLine("投资回报", "%.2f%%".format(binaryAccount.roiPct))
                MetricLine("总交易", "${binaryAccount.totalTrades}")
                MetricLine("赢/输", "${binaryAccount.winCount} / ${binaryAccount.lossCount}")
                MetricLine("累计下注", "%.2f USDT".format(binaryAccount.totalWagered))
                MetricLine("累计拿回", "%.2f USDT".format(binaryAccount.totalPayout))
                MetricLine("待结算", "${binaryAccount.pendingBets.size} 笔")
                MetricLine("总周期", "${binaryStats.totalRounds}")
                MetricLine("涨率", "%.1f%%".format(binaryStats.yesRatePct))
                MetricLine("连胜", "${binaryStats.bestStreak}（当前 ${binaryStats.currentStreak}）")
            }
        }

        Spacer(Modifier.height(8.dp))

        // === 市场赔率 ===
        Card(
            Modifier.padding(horizontal = 24.dp, vertical = 4.dp).fillMaxWidth(),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(Modifier.padding(16.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    SectionTitleInline("市场赔率")
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { viewModel.refreshMarketOdds() }) {
                        Text("刷新", fontSize = 11.sp)
                    }
                }
                if (marketOdds.isEmpty()) {
                    Text(
                        "点击「刷新」获取 Polymarket + Binance 市场赔率",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                } else {
                    marketOdds.take(10).forEach { odds ->
                        MarketOddsRow(odds)
                        if (marketOdds.indexOf(odds) < marketOdds.size - 1) {
                            HorizontalDivider(Modifier.padding(vertical = 4.dp))
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        // === 结算历史 ===
        Card(
            Modifier.padding(horizontal = 24.dp, vertical = 4.dp).fillMaxWidth(),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(Modifier.padding(16.dp)) {
                SectionTitleInline("结算历史 (${binaryAccount.settledBets.size})")
                val settled = binaryAccount.settledBets
                if (settled.isEmpty()) {
                    Text(
                        "暂无已结算下注",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                } else {
                    settled.takeLast(20).reversed().forEach { sb ->
                        SettledBetRow(sb)
                        if (settled.indexOf(sb) < settled.size - 1) {
                            HorizontalDivider(Modifier.padding(vertical = 4.dp))
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        // === 操作日志 ===
        Card(
            Modifier.padding(horizontal = 24.dp, vertical = 4.dp).fillMaxWidth(),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(Modifier.padding(16.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    SectionTitleInline("操作日志")
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { viewModel.clearBetLog() }) { Text("清空", fontSize = 11.sp) }
                }
                if (betLog.isEmpty()) {
                    Text(
                        "暂无日志",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                } else {
                    betLog.take(15).forEach { entry ->
                        Text(entry, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(vertical = 2.dp))
                    }
                }
            }
        }

        Spacer(Modifier.height(40.dp))
    }
}

@Composable
private fun CurrentRoundCard(
    round: PredictionRound?,
    viewModel: BtcQuantViewModel,
    state: com.caifenxi.app.domain.btc.BtcDashboardState
) {
    Card(
        Modifier.padding(horizontal = 24.dp, vertical = 4.dp).fillMaxWidth(),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            SectionTitleInline("当前 5 分钟周期")
            if (round != null) {
                val now = System.currentTimeMillis()
                val remaining = (round.endTime - now) / 1000
                val remainingMin = remaining / 60
                val remainingSec = remaining % 60

                MetricLine("周期 ID", "#${round.roundId / 300_000}")
                MetricLine("开窗价格", "%.2f USDT".format(round.openPrice))
                MetricLine("倒计时", "%d:%02d".format(remainingMin, remainingSec))

                // 进度条
                val progress = (1.0 - remaining.toDouble() / 300.0).coerceIn(0.0, 1.0).toFloat()
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                )

                // 实时方向
                val liveDir = viewModel.binaryLiveDirection()
                val liveMove = viewModel.binaryCurrentMovePct()
                val dirColor = if (liveDir == BetDirection.YES) CaiTokens.Success else CaiTokens.Danger
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = dirColor.copy(alpha = 0.12f)
                ) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            liveDir.label,
                            color = dirColor,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "%.2f%%".format(liveMove),
                            color = dirColor,
                            fontSize = 12.sp
                        )
                    }
                }
            } else {
                Text("等待周期开启...", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun BetDirectionButton(
    text: String,
    subtitle: String,
    selected: Boolean,
    color: androidx.compose.ui.graphics.Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (selected) color.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
        onClick = onClick,
        modifier = modifier
    ) {
        Column(
            Modifier.padding(vertical = 12.dp, horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text, fontSize = 20.sp, fontWeight = FontWeight.Black,
                color = if (selected) color else MaterialTheme.colorScheme.onSurfaceVariant)
            Text(subtitle, fontSize = 11.sp,
                color = if (selected) color else MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun StatMini(label: String, value: String, color: androidx.compose.ui.graphics.Color) {
    Column(
        Modifier.clip(RoundedCornerShape(8.dp)).background(color.copy(alpha = 0.12f)).padding(8.dp)
    ) {
        Text(label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = color)
    }
}

@Composable
private fun MarketOddsRow(odds: com.caifenxi.app.domain.btc.paper.MarketOdds) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // 平台
        Surface(shape = RoundedCornerShape(4.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)) {
            Text(
                odds.platform,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
            )
        }
        Spacer(Modifier.width(6.dp))
        // 问题
        Column(Modifier.weight(1f)) {
            Text(odds.question.take(40), fontSize = 11.sp, maxLines = 1)
            Text("流动 %.0f | 24h %.0f".format(odds.liquidity, odds.volume24h), fontSize = 9.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        // 赔率
        Column(horizontalAlignment = Alignment.End) {
            Text("Yes %.1fx".format(odds.yesOdds), fontSize = 10.sp, color = CaiTokens.Success, fontWeight = FontWeight.Bold)
            Text("No %.1fx".format(odds.noOdds), fontSize = 10.sp, color = CaiTokens.Danger, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SettledBetRow(sb: SettledBet) {
    val dirColor = if (sb.bet.direction == BetDirection.YES) CaiTokens.Success else CaiTokens.Danger
    val resultColor = if (sb.won) CaiTokens.Success else CaiTokens.Danger

    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(shape = RoundedCornerShape(4.dp), color = dirColor.copy(alpha = 0.15f)) {
            Text(
                sb.bet.direction.name,
                color = dirColor,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
            )
        }
        Spacer(Modifier.width(6.dp))
        Column(Modifier.weight(1f)) {
            Text(
                "%.0f USDT @ %.1fx \u00b7 %.2f\u2192%.2f".format(
                    sb.bet.amount, sb.bet.odds, sb.round.openPrice, sb.round.closePrice ?: 0.0
                ),
                fontSize = 11.sp
            )
            Text(
                (if (sb.won) "WIN \u2192 +%.2f USDT" else "LOSS \u2192 -%.2f USDT").format(sb.profit),
                fontSize = 10.sp,
                color = resultColor,
                fontWeight = FontWeight.Bold
            )
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(
                "%.2f USDT".format(sb.payout),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = resultColor
            )
            Text(if (sb.won) "赢" else "输", fontSize = 10.sp, color = resultColor)
        }
    }
}
