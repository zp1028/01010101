package com.caifenxi.app.domain.btc.runtime

import com.caifenxi.app.domain.btc.BtcDirection

/** Runtime state is deliberately separate from trading signals. */
enum class BtcRunMode { PAPER, TESTNET, LIVE }
enum class BtcRuntimeStatus { STOPPED, RUNNING, PAUSED, KILLED, ERROR }

data class BtcRuntimeConfig(
    val symbol: String = "BTCUSDT",
    val timeframe: String = "5m",
    val runMode: BtcRunMode = BtcRunMode.PAPER,
    val enabled: Boolean = false,
    val maxPositionQty: Double = 0.001,
    val pollSeconds: Long = 20L
)

data class BtcRuntimeState(
    val status: BtcRuntimeStatus = BtcRuntimeStatus.STOPPED,
    val lastHeartbeatAt: Long = 0L,
    val lastBarId: Long = 0L,
    val lastSignal: BtcDirection? = BtcDirection.FLAT,
    val lastOrderClientId: String? = null,
    val lastError: String? = null,
    val killSwitch: Boolean = false,
    val processedBars: Long = 0L,
    val lastFundingRate: Double? = null,
    val lastOiChangePct: Double? = null,
    val lastDerivScore: Double? = null
)
