package com.caifenxi.app.domain.btc.runtime

import java.util.concurrent.ConcurrentHashMap

/** Idempotency gate: one execution claim per symbol/timeframe/bar, regardless of plan changes. */
class BtcExecutionGate {
    private val seen = ConcurrentHashMap.newKeySet<String>()

    fun key(planId: String, symbol: String, timeframe: String, barId: Long): String =
        key(symbol, timeframe, barId)

    fun key(symbol: String, timeframe: String, barId: Long): String =
        "$symbol|$timeframe|$barId"

    fun claim(planId: String, symbol: String, timeframe: String, barId: Long): Boolean =
        seen.add(key(symbol, timeframe, barId))

    fun claimBar(symbol: String, timeframe: String, barId: Long): Boolean =
        seen.add(key(symbol, timeframe, barId))

    fun release(key: String) { seen.remove(key) }
}
