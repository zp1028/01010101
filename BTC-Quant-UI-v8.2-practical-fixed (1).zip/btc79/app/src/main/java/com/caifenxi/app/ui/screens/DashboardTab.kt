package com.caifenxi.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.btc.BtcDashboardState
import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.MarketRegime
import com.caifenxi.app.ui.BtcQuantViewModel
import com.caifenxi.app.ui.components.CandlestickChart
import com.caifenxi.app.ui.components.SectionTitle
import com.caifenxi.app.ui.theme.CaiTokens

/**
 * 看板 Tab：行情总览 + 共识方向 + 衍生品因子 + 新闻 AI
 */
@Composable
fun DashboardTab(viewModel: BtcQuantViewModel) {
    val state by viewModel.state.collectAsState()
    var timeframe by remember { mutableStateOf(state.timeframe.ifBlank { "15m" }) }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
    ) {
        Header(state) { viewModel.refresh(timeframe = timeframe) }
        if (state.loading) {
            LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 24.dp))
        }
        state.error?.let {
            Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(24.dp, 8.dp))
        }
        PriceHero(state)
        ChartCard(state)
        RegimeStrip(state)
        MultiTimeframeHint(timeframe) {
            timeframe = it
            viewModel.refresh(timeframe = it)
        }
        DirectionCard(state)
        DerivativesCard(state)
        NewsAiCard(state)
        Spacer(Modifier.height(40.dp))
    }
}

@Composable
private fun Header(state: BtcDashboardState, refresh: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(24.dp, 18.dp, 24.dp, 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("BTC QUANT", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
            Text(
                "${state.symbol} \u00b7 加密量化交易工作台",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        IconButton(onClick = refresh) {
            Icon(Icons.Filled.Refresh, contentDescription = "刷新")
        }
    }
}

@Composable
private fun PriceHero(state: BtcDashboardState) {
    val last = state.candles.lastOrNull()?.close
    Card(
        Modifier.padding(horizontal = 24.dp, vertical = 6.dp).fillMaxWidth(),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(Modifier.padding(18.dp)) {
            Text("最新价", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                last?.let { "%,.2f".format(it) } ?: "\u2014",
                fontSize = 28.sp,
                fontWeight = FontWeight.Black
            )
            val mark = state.markPrice
            if (mark != null) {
                Text("Mark " + "%,.2f".format(mark), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(
                "更新 ${if (state.updatedAt == 0L) "\u2014" else fmtTime(state.updatedAt)}",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ChartCard(state: BtcDashboardState) {
    if (state.candles.isEmpty()) return
    Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
        CandlestickChart(
            candles = state.candles,
            showEma9 = true,
            showEma21 = true,
            showEma50 = true,
            showVolume = true
        )
    }
}

@Composable
private fun RegimeStrip(state: BtcDashboardState) {
    val r = state.consensus?.regime
    Row(Modifier.padding(horizontal = 24.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        AssistChip(onClick = {}, label = { Text(r?.label() ?: "环境 \u2014") })
        AssistChip(onClick = {}, label = { Text("波动 ${(state.consensus?.volatility ?: 0.0).times(100).let { "%.2f%%".format(it) }}") })
        if (state.fundingExtreme) {
            AssistChip(onClick = {}, label = { Text("费率极端") }, colors = AssistChipDefaults.assistChipColors(containerColor = MaterialTheme.colorScheme.errorContainer))
        }
        if (state.newsBlackSwan) {
            AssistChip(onClick = {}, label = { Text("新闻黑天鹅") }, colors = AssistChipDefaults.assistChipColors(containerColor = MaterialTheme.colorScheme.errorContainer))
        }
    }
}

@Composable
private fun DirectionCard(state: BtcDashboardState) {
    val c = state.consensus
    val dir = c?.direction ?: BtcDirection.FLAT
    val color = when (dir) {
        BtcDirection.UP -> CaiTokens.Success
        BtcDirection.DOWN -> CaiTokens.Danger
        BtcDirection.FLAT -> CaiTokens.Warning
    }
    Card(
        Modifier.padding(horizontal = 24.dp, vertical = 8.dp).fillMaxWidth(),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(Modifier.padding(18.dp)) {
            SectionTitleInline("共识方向（计划池加权）")
            Text(dir.name, color = color, fontSize = 26.sp, fontWeight = FontWeight.Black)
            Text(
                "概率 %.0f%% \u00b7 强度 %.0f%% \u00b7 预期波动 %.2f%%".format(
                    (c?.probability ?: 0.0) * 100,
                    (c?.consensusStrength ?: 0.0) * 100,
                    c?.expectedMovePct ?: 0.0
                ),
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { (c?.probability ?: 0.5).toFloat() },
                modifier = Modifier.fillMaxWidth().height(8.dp)
            )
        }
    }
}

@Composable
private fun DerivativesCard(state: BtcDashboardState) {
    Card(
        Modifier.padding(horizontal = 24.dp, vertical = 6.dp).fillMaxWidth(),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(Modifier.padding(18.dp)) {
            SectionTitleInline("衍生品因子（Funding / OI）")
            MetricLine("资金费率", state.fundingRate?.let { "%.6f".format(it) } ?: "\u2014")
            MetricLine("费率 Z", state.fundingZScore?.let { "%.2f".format(it) } ?: "\u2014")
            MetricLine("OI 变化%", state.oiChangePct?.let { "%.2f".format(it) } ?: "\u2014")
            MetricLine("衍生品综合分", state.derivativesScore?.let { "%.2f".format(it) } ?: "\u2014")
            Text("已进入计划池 BTC-FUNDING-FADE 与动态权重", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun NewsAiCard(state: BtcDashboardState) {
    Card(
        Modifier.padding(horizontal = 24.dp, vertical = 8.dp).fillMaxWidth(),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(Modifier.padding(18.dp)) {
            SectionTitleInline("新闻 + AI 信号（默认不进实盘）")
            MetricLine("新闻情绪", state.newsNetSentiment?.let { "%.2f".format(it) } ?: "\u2014")
            MetricLine("黑天鹅", if (state.newsBlackSwan) "是 \u00b7 挂机应停开" else "否")
            MetricLine("AI方向", state.aiDirection?.name ?: "\u2014")
            MetricLine("AI置信", state.aiConfidence?.let { "%.0f%%".format(it * 100) } ?: "\u2014")
            MetricLine("AI可实盘", if (state.aiLiveAllowed) "允许" else "禁止（策略默认）")
            if (state.newsHeadlines.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text("头条", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                state.newsHeadlines.take(3).forEach {
                    Text("\u00b7 $it", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            state.aiJson?.let {
                Spacer(Modifier.height(6.dp))
                Text("AI JSON", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Text(it, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 6)
            }
        }
    }
}
