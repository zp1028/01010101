package com.caifenxi.app.domain.btc.news

/**
 * Lightweight lexicon sentiment for crypto headlines (no network model required).
 * Used as baseline before optional LLM enrichment.
 */
object NewsSentiment {
    private val bull = listOf(
        "surge", "rally", "soar", "breakout", "etf inflow", "approval", "all-time high", "ath",
        "bull", "adoption", "partnership", "upgrade", "买入", "上涨", "突破", "利好", "通过", "流入"
    )
    private val bear = listOf(
        "crash", "hack", "exploit", "sec charge", "ban", "lawsuit", "liquidation", "outflow",
        "bear", "collapse", "fraud", "下跌", "黑客", "爆仓", "监管", "起诉", "流出", "崩盘"
    )
    private val highImpact = listOf(
        "hack", "etf", "fed", "rate", "sec", "binance", "blackrock", "liquidation",
        "黑客", "加息", "降息", "监管", "etf"
    )

    fun score(title: String, summary: String = ""): Pair<Double, Double> {
        val t = (title + " " + summary).lowercase()
        var s = 0.0
        bull.forEach { if (t.contains(it)) s += 0.25 }
        bear.forEach { if (t.contains(it)) s -= 0.35 }
        var impact = 0.25
        highImpact.forEach { if (t.contains(it)) impact += 0.2 }
        return s.coerceIn(-1.0, 1.0) to impact.coerceIn(0.0, 1.0)
    }

    fun entities(text: String): List<String> {
        val keys = listOf("BTC", "ETH", "SOL", "BNB", "SEC", "ETF", "Fed", "比特币", "以太坊")
        val u = text.uppercase()
        return keys.filter { u.contains(it.uppercase()) }.distinct()
    }

    fun tags(text: String): List<String> {
        val t = text.lowercase()
        return buildList {
            if (listOf("etf", "sec", "fed", "rate", "监管", "加息").any { t.contains(it) }) add("macro")
            if (listOf("hack", "exploit", "黑客").any { t.contains(it) }) add("security")
            if (listOf("etf", "inflow", "outflow").any { t.contains(it) }) add("flow")
            if (listOf("btc", "bitcoin", "比特币").any { t.contains(it) }) add("btc")
        }
    }
}
