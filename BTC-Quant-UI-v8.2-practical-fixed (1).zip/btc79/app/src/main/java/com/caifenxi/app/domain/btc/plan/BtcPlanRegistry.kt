package com.caifenxi.app.domain.btc.plan

import com.caifenxi.app.domain.btc.BtcPlanFamily

data class BtcPlanDefinition(
    val id: String,
    val name: String,
    val family: BtcPlanFamily,
    val enabled: Boolean = true,
    val minSamples: Int = 100,
    val minProfitFactor: Double = 1.05,
    val maxDrawdownPct: Double = 15.0,
    val baseWeight: Double = 1.0
)

class BtcPlanRegistry(
    definitions: List<BtcPlanDefinition> = defaultPlans()
) {
    private val plans = definitions.associateBy { it.id }

    fun all(): List<BtcPlanDefinition> = plans.values.toList()
    fun enabled(): List<BtcPlanDefinition> = plans.values.filter { it.enabled }
    fun get(id: String): BtcPlanDefinition? = plans[id]

    companion object {
        fun defaultPlans(): List<BtcPlanDefinition> = listOf(
            BtcPlanDefinition("BTC-TURTLE", "Turtle / Donchian", BtcPlanFamily.STRUCTURE, baseWeight = 1.10),
            BtcPlanDefinition("BTC-EMA-TREND", "EMA Trend", BtcPlanFamily.TREND, baseWeight = 1.15),
            BtcPlanDefinition("BTC-MACD", "MACD Momentum", BtcPlanFamily.MOMENTUM, baseWeight = 1.00),
            BtcPlanDefinition("BTC-MTF-PULLBACK", "Multi-TF Pullback", BtcPlanFamily.STRUCTURE, baseWeight = 1.15),
            BtcPlanDefinition("BTC-RSI-RANGE", "RSI Mean Revert", BtcPlanFamily.MOMENTUM, baseWeight = 0.85),
            BtcPlanDefinition("BTC-BB-ATR", "BB Squeeze / ATR Breakout", BtcPlanFamily.VOLATILITY, baseWeight = 0.95),
            BtcPlanDefinition("BTC-VWAP-VOLUME", "VWAP Volume", BtcPlanFamily.VOLUME, baseWeight = 0.90),
            BtcPlanDefinition("BTC-FUNDING-FADE", "Funding Fade", BtcPlanFamily.DERIVATIVES, baseWeight = 0.75),
            BtcPlanDefinition("BTC-AI-ASSISTED", "AI Assisted", BtcPlanFamily.AI, enabled = false, baseWeight = 0.50)
        )
    }
}
