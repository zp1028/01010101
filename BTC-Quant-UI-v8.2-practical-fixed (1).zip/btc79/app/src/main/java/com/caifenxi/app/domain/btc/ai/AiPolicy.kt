package com.caifenxi.app.domain.btc.ai

import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.BtcPlanFamily
import com.caifenxi.app.domain.btc.BtcPlanSignal

/**
 * AI may only emit candidates. LIVE trading requires explicit allow flag.
 */
data class AiPolicyConfig(
    /** When false, AI signal never becomes order intent. */
    val allowLiveAiOrders: Boolean = false,
    /** Minimum confidence to surface as plan weight. */
    val minConfidence: Double = 0.55,
    /** Max weight contribution vs rule plans. */
    val maxWeight: Double = 0.65,
    /** If news black swan, force FLAT. */
    val haltOnBlackSwan: Boolean = true
)

object AiPolicy {
    fun toPlanSignal(candidate: AiPlanCandidate, cfg: AiPolicyConfig = AiPolicyConfig()): BtcPlanSignal? {
        if (candidate.direction == BtcDirection.FLAT) return null
        if (candidate.confidence < cfg.minConfidence) return null
        if (candidate.invalidIf.any { it.contains("black_swan") } && cfg.haltOnBlackSwan) return null
        val score = when (candidate.direction) {
            BtcDirection.UP -> candidate.confidence
            BtcDirection.DOWN -> -candidate.confidence
            BtcDirection.FLAT -> 0.0
        }
        val w = cfg.maxWeight * candidate.confidence
        return BtcPlanSignal(
            planId = "BTC-AI-ASSISTED",
            name = "AI辅助候选",
            family = BtcPlanFamily.AI,
            direction = candidate.direction,
            rawScore = score.coerceIn(-1.0, 1.0),
            confidence = candidate.confidence,
            weight = w,
            hitRate = 0.5,
            samples = 0,
            regimeFit = 0.7,
            contribution = score * candidate.confidence * w * 0.7
        )
    }

    fun mayExecuteLive(cfg: AiPolicyConfig, candidate: AiPlanCandidate): Boolean {
        if (!cfg.allowLiveAiOrders) return false
        if (!candidate.isTradableCandidate) return false
        if (candidate.invalidIf.isNotEmpty() && cfg.haltOnBlackSwan) return false
        return true
    }
}
