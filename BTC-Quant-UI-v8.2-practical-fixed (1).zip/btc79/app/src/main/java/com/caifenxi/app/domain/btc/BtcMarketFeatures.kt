package com.caifenxi.app.domain.btc

/** Point-in-time feature snapshot. Values are computed only from bars <= barTime. */
data class BtcMarketFeatures(
    val barTime: Long,
    val symbol: String,
    val timeframe: String,
    val close: Double,
    val ema9: Double,
    val ema21: Double,
    val ema50: Double,
    val rsi14: Double,
    val atrPct: Double,
    val volumeRatio: Double,
    val trendScore: Double,
    val volatilityScore: Double,
    val regime: MarketRegime,
    val featureVersion: String = "features-v2",
    // P3 derivatives (nullable for pure OHLC backtests)
    val fundingRate: Double? = null,
    val fundingZScore: Double? = null,
    val fundingExtreme: Boolean = false,
    val oiChangePct: Double? = null,
    val oiTrend: Double? = null,
    val priceOiAlign: Double? = null,
    val derivativesScore: Double? = null
) {
    fun withDerivatives(d: DerivativesFeatures): BtcMarketFeatures = copy(
        fundingRate = d.fundingRate,
        fundingZScore = d.fundingZScore,
        fundingExtreme = d.fundingExtreme,
        oiChangePct = d.oiChangePct,
        oiTrend = d.oiTrend,
        priceOiAlign = d.priceOiAlign,
        derivativesScore = d.derivativesScore
    )
}
