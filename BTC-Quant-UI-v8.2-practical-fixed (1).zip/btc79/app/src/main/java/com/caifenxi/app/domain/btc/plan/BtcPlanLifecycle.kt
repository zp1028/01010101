package com.caifenxi.app.domain.btc.plan

/** Practical lifecycle state used by live ranking/UI. */
enum class BtcPlanStatus { ACTIVE, WATCH, PROMOTED, DOWNWEIGHT, RETIRED }

data class BtcPlanLifecycle(
    val planId: String,
    val status: BtcPlanStatus,
    val score: Double,
    val reason: String
)

object BtcPlanLifecycleEngine {
    fun evaluate(def: BtcPlanDefinition, perf: DynamicWeightEngine.PlanPerf?): BtcPlanLifecycle {
        if (!def.enabled) return BtcPlanLifecycle(def.id, BtcPlanStatus.RETIRED, 0.0, "策略已禁用")
        if (perf == null || perf.samples < def.minSamples) {
            return BtcPlanLifecycle(def.id, BtcPlanStatus.WATCH, 0.0, "样本不足(${perf?.samples ?: 0}/${def.minSamples})")
        }
        val ddScore = (1.0 - perf.maxDrawdownPct / def.maxDrawdownPct).coerceIn(-1.0, 1.0)
        val pfScore = ((perf.profitFactor - 1.0) / 0.5).coerceIn(-1.0, 1.0)
        val wrScore = ((perf.winRatePct - 50.0) / 15.0).coerceIn(-1.0, 1.0)
        val score = pfScore * 0.45 + wrScore * 0.30 + ddScore * 0.25
        val status = when {
            perf.profitFactor >= def.minProfitFactor && perf.maxDrawdownPct <= def.maxDrawdownPct && score >= 0.55 -> BtcPlanStatus.PROMOTED
            perf.profitFactor < 0.90 || perf.maxDrawdownPct > def.maxDrawdownPct -> BtcPlanStatus.DOWNWEIGHT
            else -> BtcPlanStatus.ACTIVE
        }
        val reason = "PF=${"%.2f".format(perf.profitFactor)}, WR=${"%.1f%%".format(perf.winRatePct)}, DD=${"%.1f%%".format(perf.maxDrawdownPct)}"
        return BtcPlanLifecycle(def.id, status, score, reason)
    }
}
