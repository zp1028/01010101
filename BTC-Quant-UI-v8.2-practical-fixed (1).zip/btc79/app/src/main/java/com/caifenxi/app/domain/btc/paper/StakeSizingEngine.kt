package com.caifenxi.app.domain.btc.paper

/**
 * 固定份额引擎 — 1 USDT/注，不使用凯利公式
 *
 * 用户策略：固定 1 USDT 每次周期下注。
 * 变动赔率下，单笔盈利随市场定价变化（0.25x ~ 4.00x 不等），
 * 单笔亏损始终 = 1 USDT（投入本金）。
 *
 * 本引擎保留 EV 计算能力（供 UI 展示），但下注金额固定返回 1.0。
 */
class StakeSizingEngine(
    private val fixedBetAmount: Double = 1.0
) {

    data class StakeSuggestion(
        val recommended: Boolean,
        val amount: Double,
        val fractionOfBalance: Double,
        val kellyValue: Double,
        val adjustedKelly: Double,
        val expectedProfit: Double,
        val maxLoss: Double,
        val expectedValue: Double,
        val winProbability: Double,
        val odds: Double,
        val reason: String
    ) {
        companion object {
            fun notRecommended(
                reason: String,
                winProbability: Double = 0.0,
                odds: Double = 0.0
            ) = StakeSuggestion(
                recommended = false, amount = 0.0, fractionOfBalance = 0.0,
                kellyValue = 0.0, adjustedKelly = 0.0,
                expectedProfit = 0.0, maxLoss = 0.0, expectedValue = 0.0,
                winProbability = winProbability, odds = odds, reason = reason
            )
        }
    }

    /**
     * 固定 1 USDT 下注建议。
     * 赔率由市场定价决定（变动赔率），金额固定不变。
     */
    fun calculate(
        balance: Double,
        odds: Double,
        consensusProbability: Double,
        consensusStrength: Double = 1.0
    ): StakeSuggestion {
        if (balance < fixedBetAmount) {
            return StakeSuggestion.notRecommended("余额不足（需 %.0f, 可用 %.2f）".format(fixedBetAmount, balance), consensusProbability, odds)
        }
        if (odds <= 1.0) {
            return StakeSuggestion.notRecommended("赔率无效（<= 1.0）", consensusProbability, odds)
        }

        val p = consensusProbability.coerceIn(0.01, 0.99)
        val b = odds - 1.0
        val ev = p * b - (1.0 - p)
        val kelly = (b * p - (1.0 - p)) / b

        val amount = fixedBetAmount
        val expectedProfit = amount * b
        val maxLoss = amount
        val fractionPct = if (balance > 0) amount * 100.0 / balance else 0.0

        val recommended = ev > 0.0

        return StakeSuggestion(
            recommended = recommended,
            amount = amount,
            fractionOfBalance = fractionPct,
            kellyValue = kelly,
            adjustedKelly = kelly,
            expectedProfit = expectedProfit,
            maxLoss = maxLoss,
            expectedValue = ev,
            winProbability = p,
            odds = odds,
            reason = if (recommended) {
                "Fixed %.0fU @ %.2fx · EV=+%.3f · Win=%.0f%%".format(amount, odds, ev, p * 100)
            } else {
                "Fixed %.0fU @ %.2fx · EV=%.3f (negative) · skip".format(amount, odds, ev)
            }
        )
    }

    fun quickSizing(
        balance: Double,
        odds: Double,
        consensusProbability: Double,
        consensusStrength: Double = 1.0
    ): Double {
        val suggestion = calculate(balance, odds, consensusProbability, consensusStrength)
        return if (suggestion.recommended) suggestion.amount else 0.0
    }

    fun previewTable(
        balance: Double,
        odds: Double,
        confidences: List<Pair<Double, Double>>
    ): List<StakeSuggestion> = confidences.map { (p, s) ->
        calculate(balance, odds, p, s)
    }

    fun kellyValue(odds: Double, winProbability: Double): Double {
        if (odds <= 1.0 || winProbability <= 0.0 || winProbability >= 1.0) return 0.0
        val b = odds - 1.0
        val p = winProbability
        return (b * p - (1.0 - p)) / b
    }

    fun expectedValue(odds: Double, winProbability: Double): Double {
        if (odds <= 1.0) return 0.0
        val b = odds - 1.0
        return winProbability * b - (1.0 - winProbability)
    }
}
