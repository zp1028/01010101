package com.caifenxi.app.domain.btc.paper

import android.content.Context
import com.caifenxi.app.domain.btc.BtcDirection
import org.json.JSONObject
import kotlin.math.max

/**
 * Persistent paper futures ledger. It is deliberately independent from live brokers:
 * fills, equity and open position survive process death and can be reconciled on restart.
 */
class PaperTradeLedger(context: Context) {
    private val prefs = context.getSharedPreferences("btc_paper_ledger", Context.MODE_PRIVATE)
    private var cash: Double = prefs.getString("cash", "10000")?.toDoubleOrNull() ?: 10000.0
    private var realized: Double = prefs.getString("realized", "0")?.toDoubleOrNull() ?: 0.0
    private var fees: Double = prefs.getString("fees", "0")?.toDoubleOrNull() ?: 0.0
    private var peakEquity: Double = prefs.getString("peak", cash.toString())?.toDoubleOrNull() ?: cash
    private var maxDrawdownPct: Double = prefs.getString("maxDd", "0")?.toDoubleOrNull() ?: 0.0
    private var position: PaperPosition? = loadPosition()

    @Synchronized
    fun open(symbol: String, direction: BtcDirection, entry: Double, quantity: Double, leverage: Int, stopLoss: Double? = null, takeProfit: Double? = null, feeRate: Double = 0.0004): Boolean {
        if (position != null || entry <= 0.0 || quantity <= 0.0) return false
        val notional = entry * quantity
        val fee = notional * feeRate
        cash -= fee
        fees += fee
        position = PaperPosition(symbol, direction, entry, quantity, leverage, System.currentTimeMillis(), entry, 0.0, stopLoss, takeProfit)
        persist()
        return true
    }

    @Synchronized
    fun mark(markPrice: Double, feeRate: Double = 0.0004): PaperSnapshot {
        val p = position ?: return snapshot()
        if (markPrice <= 0.0) return snapshot()
        val sign = if (p.direction == BtcDirection.UP) 1.0 else -1.0
        val unrealized = (markPrice - p.entry) * p.quantity * sign
        val equity = cash + unrealized
        updateRisk(equity)
        position = p.copy(lastMark = markPrice, unrealized = unrealized)
        persist()
        return snapshot()
    }

    @Synchronized
    fun close(markPrice: Double, feeRate: Double = 0.0004): PaperSnapshot {
        val p = position ?: return snapshot()
        if (markPrice <= 0.0) return snapshot()
        val sign = if (p.direction == BtcDirection.UP) 1.0 else -1.0
        val gross = (markPrice - p.entry) * p.quantity * sign
        val exitFee = markPrice * p.quantity * feeRate
        realized += gross - exitFee
        cash += gross - exitFee
        fees += exitFee
        position = null
        updateRisk(cash)
        persist()
        return snapshot()
    }

    @Synchronized
    fun snapshot(): PaperSnapshot {
        val p = position
        val equity = cash + (p?.unrealized ?: 0.0)
        val drawdown = if (peakEquity > 0) ((peakEquity - equity) / peakEquity * 100.0).coerceAtLeast(0.0) else 0.0
        return PaperSnapshot(cash, equity, realized, fees, peakEquity, maxDrawdownPct, drawdown, p)
    }

    private fun updateRisk(equity: Double) {
        peakEquity = max(peakEquity, equity)
        val dd = if (peakEquity > 0) ((peakEquity - equity) / peakEquity * 100.0).coerceAtLeast(0.0) else 0.0
        maxDrawdownPct = max(maxDrawdownPct, dd)
    }

    fun shouldCloseAt(markPrice: Double): Boolean {
        val p = position ?: return false
        return if (p.direction == BtcDirection.UP) {
            (p.stopLoss != null && markPrice <= p.stopLoss) || (p.takeProfit != null && markPrice >= p.takeProfit)
        } else {
            (p.stopLoss != null && markPrice >= p.stopLoss) || (p.takeProfit != null && markPrice <= p.takeProfit)
        }
    }

    private fun persist() {
        val e = prefs.edit()
            .putString("cash", cash.toString())
            .putString("realized", realized.toString())
            .putString("fees", fees.toString())
            .putString("peak", peakEquity.toString())
            .putString("maxDd", maxDrawdownPct.toString())
        if (position == null) e.remove("position") else e.putString("position", JSONObject().apply {
            val p = position!!
            putString("symbol", p.symbol); putString("direction", p.direction.name); putDouble("entry", p.entry)
            putDouble("quantity", p.quantity); putInt("leverage", p.leverage); putLong("openTime", p.openTime); putDouble("lastMark", p.lastMark); putDouble("unrealized", p.unrealized); p.stopLoss?.let { putDouble("stopLoss", it) }; p.takeProfit?.let { putDouble("takeProfit", it) }
        }.toString())
        e.apply()
    }

    private fun loadPosition(): PaperPosition? = runCatching {
        val o = JSONObject(prefs.getString("position", "") ?: "")
        PaperPosition(o.getString("symbol"), BtcDirection.valueOf(o.getString("direction")), o.getDouble("entry"), o.getDouble("quantity"), o.getInt("leverage"), o.getLong("openTime"), o.optDouble("lastMark", o.getDouble("entry")), o.optDouble("unrealized", 0.0), if (o.has("stopLoss")) o.getDouble("stopLoss") else null, if (o.has("takeProfit")) o.getDouble("takeProfit") else null)
    }.getOrNull()
}

data class PaperPosition(
    val symbol: String,
    val direction: BtcDirection,
    val entry: Double,
    val quantity: Double,
    val leverage: Int,
    val openTime: Long,
    val lastMark: Double,
    val unrealized: Double,
    val stopLoss: Double?,
    val takeProfit: Double?
)

data class PaperSnapshot(
    val cash: Double,
    val equity: Double,
    val realizedPnl: Double,
    val fees: Double,
    val peakEquity: Double,
    val maxDrawdownPct: Double,
    val currentDrawdownPct: Double,
    val position: PaperPosition?
)
