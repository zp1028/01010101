package com.caifenxi.app.domain.btc.broker

import com.caifenxi.app.domain.btc.TradingSignal
import com.caifenxi.app.domain.btc.futures.ClosePositionRequest
import com.caifenxi.app.domain.btc.futures.FuturesOrderType
import com.caifenxi.app.domain.btc.futures.LeverageResult
import com.caifenxi.app.domain.btc.futures.MarginMode
import com.caifenxi.app.domain.btc.futures.PositionRiskInfo

interface PerpBroker {
    suspend fun place(signal: TradingSignal.ContractSignal, clientOrderId: String): BrokerOrderResult
    suspend fun cancel(symbol: String, orderId: Long? = null, clientOrderId: String? = null): BrokerOrderResult
    suspend fun accountSnapshot(): BrokerAccountSnapshot

    /**
     * Set leverage for a symbol before opening a position.
     * Must be called once per symbol or when leverage changes.
     */
    suspend fun setLeverage(symbol: String, leverage: Int): LeverageResult

    /**
     * Set margin mode (ISOLATED or CROSSED) for a symbol.
     */
    suspend fun setMarginMode(symbol: String, mode: MarginMode): BrokerOrderResult

    /**
     * Query current position risk for a symbol.
     * Returns null if no open position.
     */
    suspend fun fetchPositionRisk(symbol: String): PositionRiskInfo?

    /**
     * Place a conditional order (STOP_MARKET / TAKE_PROFIT_MARKET / TRAILING_STOP_MARKET).
     * Used for automated SL/TP bracket after market entry.
     */
    suspend fun placeConditionalOrder(
        symbol: String,
        side: String,               // "BUY" or "SELL"
        type: FuturesOrderType,     // STOP_MARKET / TAKE_PROFIT_MARKET / TRAILING_STOP_MARKET
        quantity: Double,
        stopPrice: Double? = null,
        trailingDelta: Double? = null, // for TRAILING_STOP_MARKET (bps)
        reduceOnly: Boolean = true,
        clientOrderId: String
    ): BrokerOrderResult

    /**
     * Close an entire position using reduceOnly MARKET order.
     */
    suspend fun closePosition(request: ClosePositionRequest): BrokerOrderResult
}

data class BrokerOrderResult(
    val success: Boolean,
    val orderId: Long? = null,
    val clientOrderId: String,
    val status: String,
    val message: String = ""
)

data class BrokerAccountSnapshot(
    val availableBalance: Double,
    val totalWalletBalance: Double,
    val unrealizedPnl: Double
)
