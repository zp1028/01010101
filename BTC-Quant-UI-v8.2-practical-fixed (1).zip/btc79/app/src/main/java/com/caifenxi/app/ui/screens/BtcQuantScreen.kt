package com.caifenxi.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import com.caifenxi.app.ui.BtcQuantViewModel

private enum class QuantTab(val label: String, val icon: ImageVector) {
    DASHBOARD("看板", Icons.Filled.Insights),
    STRATEGY("策略", Icons.Filled.Analytics),
    TRADE("交易", Icons.Filled.AccountBalance),
    AUTO_TRADE("自注", Icons.Filled.AutoGraph),
    PAPER("模拟", Icons.Filled.MonetizationOn),
    BACKTEST("回测", Icons.Filled.History),
    FUTURES("合约", Icons.Filled.ShowChart),
    SETTINGS("设置", Icons.Filled.Settings)
}

/**
 * BTC 量化交易主界面：多 Tab 架构（看板 / 策略 / 交易 / 自注 / 模拟 / 回测 / 设置）
 */
@Composable
fun BtcQuantScreen(viewModel: BtcQuantViewModel) {
    var selectedTab by remember { mutableIntStateOf(0) }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        PrimaryTabRow(
            selectedTabIndex = selectedTab,
        ) {
            QuantTab.entries.forEach { tab ->
                Tab(
                    selected = selectedTab == tab.ordinal,
                    onClick = { selectedTab = tab.ordinal },
                    text = { Text(tab.label) },
                    icon = { Icon(tab.icon, contentDescription = tab.label) }
                )
            }
        }

        when (selectedTab) {
            QuantTab.DASHBOARD.ordinal -> DashboardTab(viewModel)
            QuantTab.STRATEGY.ordinal -> StrategyTab(viewModel)
            QuantTab.TRADE.ordinal -> TradeTab(viewModel)
            QuantTab.AUTO_TRADE.ordinal -> AutoTradeTab(viewModel)
            QuantTab.PAPER.ordinal -> PaperTradingTab(viewModel)
            QuantTab.BACKTEST.ordinal -> BacktestTab(viewModel)
            QuantTab.FUTURES.ordinal -> FuturesQuantTab(viewModel)
            QuantTab.SETTINGS.ordinal -> SettingsTab(viewModel)
        }
    }
}
