package com.caifenxi.app.domain.btc.polymarket

import com.caifenxi.app.domain.btc.BtcConsensus
import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.TradingSignal
import kotlin.math.abs

/**
 * Probability engine: modelP from BTC consensus + optional news bias,
 * trade only when edge vs executable price exceeds costs.
 */
class PolymarketEdgeEngine(
    private val minEdge: Double = 0.08,
    private val maxSpread: Double = 0.08,
    private val costBuffer: Double = 0.02
) {
    fun modelYesProbability(consensus: BtcConsensus?, newsBias: Double = 0.0): Double {
        val base = when (consensus?.direction) {
            BtcDirection.UP -> 0.50 + (consensus.probability - 0.5) * 0.8
            BtcDirection.DOWN -> 0.50 - (consensus.probability - 0.5) * 0.8
            BtcDirection.FLAT, null -> 0.50
        }
        return (base + newsBias * 0.1).coerceIn(0.05, 0.95)
    }

    fun evaluateMarket(
        market: PolyMarket,
        bookYes: PolyOrderBook?,
        bookNo: PolyOrderBook?,
        modelYes: Double,
        nowMs: Long = System.currentTimeMillis()
    ): List<PolyEdgeOpportunity> {
        if (market.closed || !market.enableOrderBook) return emptyList()
        val ttr = market.endDateMs?.let { ((it - nowMs) / 1000L).coerceAtLeast(0) } ?: 86_400L
        val out = mutableListOf<PolyEdgeOpportunity>()
        // YES
        val yesAsk = bookYes?.bestAsk ?: market.yesPrice
        val yesSpread = bookYes?.spread ?: abs(market.yesPrice - (1 - market.noPrice))
        val yesLiq = liquidityScore(bookYes)
        val edgeYes = modelYes - yesAsk - costBuffer
        out += PolyEdgeOpportunity(
            market = market,
            outcome = "YES",
            tokenId = market.yesTokenId,
            marketP = yesAsk,
            modelP = modelYes,
            tradePrice = yesAsk,
            edge = edgeYes,
            ev = edgeYes,
            spread = yesSpread,
            liquidityScore = yesLiq,
            timeToResolutionSec = ttr,
            action = if (edgeYes >= minEdge && yesSpread <= maxSpread && yesLiq >= 0.3) "BUY" else "NO_TRADE",
            reason = "modelYes=$modelYes ask=$yesAsk edge=$edgeYes"
        )
        // NO
        val modelNo = 1.0 - modelYes
        val noAsk = bookNo?.bestAsk ?: market.noPrice
        val noSpread = bookNo?.spread ?: abs(market.noPrice - (1 - market.yesPrice))
        val noLiq = liquidityScore(bookNo)
        val edgeNo = modelNo - noAsk - costBuffer
        out += PolyEdgeOpportunity(
            market = market,
            outcome = "NO",
            tokenId = market.noTokenId,
            marketP = noAsk,
            modelP = modelNo,
            tradePrice = noAsk,
            edge = edgeNo,
            ev = edgeNo,
            spread = noSpread,
            liquidityScore = noLiq,
            timeToResolutionSec = ttr,
            action = if (edgeNo >= minEdge && noSpread <= maxSpread && noLiq >= 0.3) "BUY" else "NO_TRADE",
            reason = "modelNo=$modelNo ask=$noAsk edge=$edgeNo"
        )
        return out
    }

    fun toSignal(op: PolyEdgeOpportunity, size: Double = 10.0): TradingSignal.PredictionMarketSignal? {
        if (op.action != "BUY") return null
        return TradingSignal.PredictionMarketSignal(
            venue = "POLYMARKET",
            marketId = op.market.conditionId,
            outcome = op.outcome,
            marketPrice = op.marketP,
            modelProbability = op.modelP,
            edge = op.edge,
            expectedValue = op.ev,
            liquidityScore = op.liquidityScore,
            spread = op.spread,
            timeToResolutionSec = op.timeToResolutionSec,
            action = "BUY"
        )
    }

    private fun liquidityScore(book: PolyOrderBook?): Double {
        if (book == null) return 0.2
        val depth = (book.bids.take(5).sumOf { it.size } + book.asks.take(5).sumOf { it.size })
        return (depth / 500.0).coerceIn(0.0, 1.0)
    }
}
