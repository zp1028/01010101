package com.caifenxi.app.domain.btc.broker

import android.content.Context
import android.content.SharedPreferences

/**
 * Runtime credentials. Prefer EncryptedSharedPreferences in production;
 * this uses private prefs as a minimal adapter (do not commit real keys).
 */
data class BrokerCredentials(
    val binanceApiKey: String = "",
    val binanceSecret: String = "",
    val binanceEndpoint: BinanceFuturesEndpoint = BinanceFuturesEndpoint.DEMO,
    val polymarketApiKey: String = "",
    val polymarketApiSecret: String = "",
    val polymarketPassphrase: String = "",
    val polymarketDryRun: Boolean = true
)

class BrokerCredentialStore(context: Context) {
    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("btc_broker_creds", Context.MODE_PRIVATE)

    fun load(): BrokerCredentials = BrokerCredentials(
        binanceApiKey = sp.getString("b_key", "").orEmpty(),
        binanceSecret = sp.getString("b_sec", "").orEmpty(),
        binanceEndpoint = runCatching {
            BinanceFuturesEndpoint.valueOf(sp.getString("b_ep", "DEMO")!!)
        }.getOrDefault(BinanceFuturesEndpoint.DEMO),
        polymarketApiKey = sp.getString("p_key", "").orEmpty(),
        polymarketApiSecret = sp.getString("p_sec", "").orEmpty(),
        polymarketPassphrase = sp.getString("p_pass", "").orEmpty(),
        polymarketDryRun = sp.getBoolean("p_dry", true)
    )

    fun save(c: BrokerCredentials) {
        sp.edit()
            .putString("b_key", c.binanceApiKey.trim())
            .putString("b_sec", c.binanceSecret.trim())
            .putString("b_ep", c.binanceEndpoint.name)
            .putString("p_key", c.polymarketApiKey.trim())
            .putString("p_sec", c.polymarketApiSecret.trim())
            .putString("p_pass", c.polymarketPassphrase.trim())
            .putBoolean("p_dry", c.polymarketDryRun)
            .apply()
    }

    fun clear() {
        sp.edit().clear().apply()
    }
}

object BrokerFactory {
    fun perp(creds: BrokerCredentials, forcePaper: Boolean = false): PerpBroker {
        if (forcePaper) return PaperPerpBroker()
        if (creds.binanceApiKey.isBlank() || creds.binanceSecret.isBlank()) return PaperPerpBroker()
        return BinanceFuturesBroker(creds.binanceApiKey, creds.binanceSecret, creds.binanceEndpoint)
    }

    fun polymarket(creds: BrokerCredentials): EventMarketBroker =
        PolymarketClobBroker(
            dryRun = creds.polymarketDryRun || creds.polymarketApiKey.isBlank(),
            apiKey = creds.polymarketApiKey,
            apiSecret = creds.polymarketApiSecret,
            passphrase = creds.polymarketPassphrase
        )

    /**
     * Event Contract 合约市场 Broker 选择：
     * - 未配 polymarket 实盘密钥或 dryRun=true → Paper（不会真金白银下单）；
     * - 已配密钥（polymarketDryRun=false）→ Binance 实盘合约 Broker。
     */
    fun eventContract(creds: BrokerCredentials = BrokerCredentials()): EventContractBroker =
        if (creds.polymarketDryRun || creds.polymarketApiKey.isBlank()) {
            PaperEventContractBroker()
        } else {
            BinanceEventContractBroker(
                apiKey = creds.polymarketApiKey,
                secretKey = creds.polymarketApiSecret
            )
        }
}
