package com.caifenxi.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.ui.BtcQuantViewModel
import com.caifenxi.app.ui.components.SectionTitle

/**
 * 设置 Tab：链路说明 + 应用信息
 */
@Composable
fun SettingsTab(viewModel: BtcQuantViewModel) {
    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
    ) {
        SectionTitle("链路互通说明")
        Card(
            Modifier.padding(horizontal = 24.dp, vertical = 8.dp).fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(Modifier.padding(18.dp)) {
                Text(
                    """
                    1. 刷新行情 -> K线 + Funding/OI + 新闻
                    2. 计划池加权 -> 共识方向
                    3. AI 只出 JSON 候选，默认不可实盘
                    4. 挂机服务读同一套特征与共识
                    5. 多引擎用同一共识，分通道下单/纸面
                    6. 密钥配置决定 PAPER 还是 DEMO/TESTNET/MAINNET
                    """.trimIndent(),
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        SectionTitle("关于")
        Card(
            Modifier.padding(horizontal = 24.dp, vertical = 8.dp).fillMaxWidth()
        ) {
            Column(Modifier.padding(18.dp)) {
                Text("BTC Quant", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("加密货币量化交易 + Polymarket 预测市场", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("币安合约行情 / 六维计划引擎 / AI 候选 / 多引擎编排 / 风控熔断", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.height(40.dp))
    }
}
