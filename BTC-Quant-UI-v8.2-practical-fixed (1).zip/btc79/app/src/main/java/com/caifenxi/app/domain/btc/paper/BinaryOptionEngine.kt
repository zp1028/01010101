package com.caifenxi.app.domain.btc.paper

import kotlin.math.abs
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 二元期权预测下注引擎
 *
 * 职责：
 * - 周期管理：每 5 分钟开一个窗口，记录开窗价格快照
 * - 方向锁定：周期开始时锁定一次预测方向，周期内不变
 * - 下注：在窗口开放期间接受 Yes/No 下注，防止同周期重复下注
 * - 结算：窗口结束时取收盘价格快照，判定涨跌，结算所有挂单
 * - 日级追踪：日净盈亏 / 胜率 / 回撤 / 止盈止损控制
 *
 * 无杠杆、无止损止盈（单笔）、无资金费率、无强平。亏损上限 = 下注本金。
 * 日级盈亏控制：日亏损达阈值自动停机，日盈利达目标可选停机。
 */
class BinaryOptionEngine(
    private val config: BinaryOptionConfig = BinaryOptionConfig(),
    private val dailyConfig: DailyControlConfig = DailyControlConfig()
) {
    private var account: BinaryOptionAccount = BinaryOptionAccount(
        initialBalance = config.initialBalance,
        balance = config.initialBalance,
        maxBalance = config.initialBalance
    )

    /** 当前活跃周期 */
    private var currentRound: PredictionRound? = null

    /** 历史已结算周期 */
    private val roundHistory = mutableListOf<PredictionRound>()

    /** 周期统计 */
    private var roundStats = RoundStats()

    /** 连胜计数器（内部） */
    private var currentWinStreak = 0
    private var bestWinStreak = 0

    /** 日级统计 */
    private var dailyStats: DailyStats = DailyStats(
        date = todayStr(),
        startBalance = config.initialBalance,
        currentBalance = config.initialBalance,
        peakBalance = config.initialBalance
    )

    /** 历史日级统计 */
    private val dailyHistory = mutableListOf<DailyStats>()

    fun account(): BinaryOptionAccount = account
    fun currentRound(): PredictionRound? = currentRound
    fun roundHistory(): List<PredictionRound> = roundHistory.toList()
    fun roundStats(): RoundStats = roundStats
    fun dailyStats(): DailyStats = dailyStats
    fun dailyHistory(): List<DailyStats> = dailyHistory.toList()

    /** 重置账户和所有历史 */
    fun reset() {
        account = BinaryOptionAccount(
            initialBalance = config.initialBalance,
            balance = config.initialBalance,
            maxBalance = config.initialBalance
        )
        currentRound = null
        roundHistory.clear()
        roundStats = RoundStats()
        currentWinStreak = 0
        bestWinStreak = 0
        dailyStats = DailyStats(
            date = todayStr(),
            startBalance = config.initialBalance,
            currentBalance = config.initialBalance,
            peakBalance = config.initialBalance
        )
        dailyHistory.clear()
    }

    /**
     * 根据当前时间戳和价格，确保有正确的活跃周期。
     * 如果当前没有周期或周期已过期，则创建新周期并结算旧周期。
     *
     * @param now 当前时间戳（毫秒）
     * @param currentPrice 当前 BTC 价格
     * @param lockedDirection 新周期锁定的预测方向（由策略池在周期开始时计算一次），null 表示不锁定
     * @return 当前活跃周期（可能刚创建或仍有效的旧周期）
     */
    fun ensureRound(now: Long, currentPrice: Double, lockedDirection: BetDirection? = null): PredictionRound {
        // 没有当前周期 -> 创建新周期
        val round = currentRound
        if (round == null) {
            return startNewRound(now, currentPrice, lockedDirection)
        }

        // 当前周期是否已过期
        if (now >= round.endTime) {
            // 结算旧周期（用当前价格作为收盘快照）
            settleRound(now, currentPrice)
            // 开新周期
            return startNewRound(now, currentPrice, lockedDirection)
        }

        // 周期仍有效 -> 不改变已锁定的方向
        return round
    }

    /**
     * 开启新的 5 分钟周期。
     * 周期对齐到 5 分钟边界（如 14:05:00, 14:10:00...）
     * 方向在创建时锁定，周期内不再改变。
     */
    private fun startNewRound(now: Long, openPrice: Double, lockedDirection: BetDirection?): PredictionRound {
        // 对齐到 5 分钟边界
        val roundDurationMs = config.roundDurationMs
        val alignedStart = (now / roundDurationMs) * roundDurationMs
        val alignedEnd = alignedStart + roundDurationMs

        val round = PredictionRound(
            roundId = alignedStart,
            startTime = alignedStart,
            endTime = alignedEnd,
            openPrice = openPrice,
            source = "BINANCE",
            lockedDirection = lockedDirection
        )
        currentRound = round
        return round
    }

    /**
     * 结算当前周期：用收盘价格快照判定涨跌，结算所有挂单。
     * 同时更新日级统计，检查止盈止损。
     *
     * @param now 结算时间戳
     * @param closePrice 窗口结束时的价格快照
     */
    private fun settleRound(now: Long, closePrice: Double) {
        val round = currentRound ?: return

        // 确保日级统计是当天的
        ensureDailyStats(now)

        // 判定结果：涨 = YES，跌或平 = NO
        val result = if (closePrice > round.openPrice) {
            BetDirection.YES
        } else {
            BetDirection.NO  // 价格下跌或持平，算 NO（跌）
        }

        // 更新周期
        val settledRound = round.copy(
            closePrice = closePrice,
            phase = RoundPhase.SETTLED,
            result = result
        )
        roundHistory.add(settledRound)

        // 结算该周期的所有挂单
        val betsToSettle = account.pendingBets.filter { it.roundId == round.roundId }
        val newSettled = mutableListOf<SettledBet>()
        var totalPayoutThisRound = 0.0

        for (bet in betsToSettle) {
            val won = bet.direction == result
            val payout = if (won) bet.potentialPayout else 0.0
            val profit = if (won) bet.potentialProfit else -bet.amount

            val settled = SettledBet(
                bet = bet,
                round = settledRound,
                won = won,
                payout = payout,
                profit = profit,
                settledAt = now
            )
            newSettled.add(settled)
            totalPayoutThisRound += payout

            // 更新连胜
            if (won) {
                currentWinStreak++
                if (currentWinStreak > bestWinStreak) bestWinStreak = currentWinStreak
            } else {
                currentWinStreak = 0
            }
        }

        // 更新账户
        val newBalance = account.balance + totalPayoutThisRound
        val newMaxBalance = maxOf(account.maxBalance, newBalance)
        val drawdown = if (newMaxBalance > 0) {
            (newMaxBalance - newBalance) * 100.0 / newMaxBalance
        } else 0.0

        account = account.copy(
            balance = newBalance,
            pendingBets = account.pendingBets.filter { it.roundId != round.roundId },
            settledBets = account.settledBets + newSettled,
            totalPayout = account.totalPayout + totalPayoutThisRound,
            winCount = account.winCount + newSettled.count { it.won },
            lossCount = account.lossCount + newSettled.count { !it.won },
            maxBalance = newMaxBalance,
            maxDrawdownPct = maxOf(account.maxDrawdownPct, drawdown)
        )

        // 更新周期统计
        roundStats = roundStats.copy(
            totalRounds = roundStats.totalRounds + 1,
            yesWins = roundStats.yesWins + if (result == BetDirection.YES) 1 else 0,
            noWins = roundStats.noWins + if (result == BetDirection.NO) 1 else 0,
            userWins = roundStats.userWins + newSettled.count { it.won },
            userLosses = roundStats.userLosses + newSettled.count { !it.won },
            bestStreak = bestWinStreak,
            currentStreak = currentWinStreak,
            totalWagered = roundStats.totalWagered + betsToSettle.sumOf { it.amount },
            totalPayout = roundStats.totalPayout + totalPayoutThisRound
        )

        // === 更新日级统计 ===
        updateDailyStats(newSettled, now)

        // 清除当前周期
        currentRound = null
    }

    /**
     * 在当前周期内下注。
     * 检查方向锁定、同周期防重复、日级止盈止损。
     *
     * @param req 下注请求
     * @param now 当前时间戳
     * @return 下注结果
     */
    fun placeBet(req: BetRequest, now: Long): BetResult {
        val round = currentRound

        // 检查是否有活跃周期
        if (round == null) {
            return BetResult.Rejected("当前无活跃周期")
        }

        // 检查周期是否仍在开放
        if (!round.isOpen(now)) {
            return BetResult.Rejected("周期已结束，等待新周期")
        }

        // === 防止同周期重复下注 ===
        if (account.hasBetForRound(round.roundId)) {
            return BetResult.Rejected("本周期已下注，等待结算后下周期再下注")
        }

        // === 日级止盈止损检查 ===
        ensureDailyStats(now)
        if (dailyConfig.enabled) {
            if (dailyStats.autoStopped) {
                return BetResult.Rejected("日级自动停机中（${dailyStats.autoStoppedReason()}），次日恢复")
            }
            if (dailyStats.totalBets >= dailyConfig.maxDailyBets) {
                return BetResult.Rejected("已达日最大下注次数 ${dailyConfig.maxDailyBets}")
            }
            // 检查日止损
            val dailyLossLimit = dailyConfig.dailyStopLossAmount(dailyStats.startBalance)
            if (dailyStats.netProfit <= -dailyLossLimit) {
                dailyStats = dailyStats.copy(stopLossHit = true, autoStopped = true)
                return BetResult.Rejected("日止损触发: 亏损 %.2f USDT >= 限额 %.2f".format(
                    -dailyStats.netProfit, dailyLossLimit
                ))
            }
            // 检查日止盈
            val dailyProfitTarget = dailyConfig.dailyTakeProfitAmount(dailyStats.startBalance)
            if (dailyStats.netProfit >= dailyProfitTarget) {
                dailyStats = dailyStats.copy(takeProfitHit = true, autoStopped = true)
                return BetResult.Rejected("日止盈触发: 盈利 %.2f USDT >= 目标 %.2f".format(
                    dailyStats.netProfit, dailyProfitTarget
                ))
            }
        }

        // 检查下注金额
        if (req.amount < config.minBet) {
            return BetResult.Rejected("下注金额低于最小值 ${config.minBet} USDT")
        }
        if (req.amount > config.maxBet) {
            return BetResult.Rejected("下注金额超过最大值 ${config.maxBet} USDT")
        }

        // 检查余额
        if (req.amount > account.balance) {
            return BetResult.Rejected("余额不足: 需 %.2f, 可用 %.2f".format(req.amount, account.balance))
        }

        // 创建下注
        val bet = Bet(
            betId = "${round.roundId}_${now}_${req.direction.name}",
            roundId = round.roundId,
            direction = req.direction,
            amount = req.amount,
            odds = req.odds,
            placedAt = now,
            source = req.source,
            platformMarketId = req.platformMarketId
        )

        // 扣除余额
        val platformFee = req.amount * config.platformFeePct / 100.0
        val deductedAmount = req.amount + platformFee

        // totalWagered is the actual cash cost, including platform fee.
        // This keeps ROI / net profit consistent with the account balance.
        account = account.copy(
            balance = account.balance - deductedAmount,
            pendingBets = account.pendingBets + bet,
            totalWagered = account.totalWagered + deductedAmount
        )

        return BetResult.Accepted(bet)
    }

    // === 日级统计方法 ===

    /** 确保日级统计是当天的，跨日则归档旧统计并新建 */
    private fun ensureDailyStats(now: Long) {
        val today = todayStr(now)
        if (dailyStats.date != today) {
            // 归档昨天
            dailyHistory.add(dailyStats.copy())
            // 新的一天
            dailyStats = DailyStats(
                date = today,
                startBalance = account.balance,
                currentBalance = account.balance,
                peakBalance = account.balance
            )
        }
    }

    /** 结算后更新日级统计 */
    private fun updateDailyStats(settledBets: List<SettledBet>, now: Long) {
        ensureDailyStats(now)

        val newWins = settledBets.count { it.won }
        val newLosses = settledBets.count { !it.won }
        val newWagered = settledBets.sumOf { it.bet.amount }
        val newPayout = settledBets.sumOf { it.payout }
        val newBalance = account.balance
        val newPeak = maxOf(dailyStats.peakBalance, newBalance)
        val drawdown = newPeak - newBalance

        dailyStats = dailyStats.copy(
            currentBalance = newBalance,
            totalBets = dailyStats.totalBets + settledBets.size,
            wins = dailyStats.wins + newWins,
            losses = dailyStats.losses + newLosses,
            totalWagered = dailyStats.totalWagered + newWagered,
            totalPayout = dailyStats.totalPayout + newPayout,
            peakBalance = newPeak,
            maxDrawdown = maxOf(dailyStats.maxDrawdown, drawdown)
        )

        // 检查止盈止损
        if (dailyConfig.enabled && !dailyStats.autoStopped) {
            val dailyLossLimit = dailyConfig.dailyStopLossAmount(dailyStats.startBalance)
            val dailyProfitTarget = dailyConfig.dailyTakeProfitAmount(dailyStats.startBalance)

            if (dailyStats.netProfit <= -dailyLossLimit) {
                dailyStats = dailyStats.copy(stopLossHit = true, autoStopped = true)
            } else if (dailyStats.netProfit >= dailyProfitTarget) {
                dailyStats = dailyStats.copy(takeProfitHit = true, autoStopped = true)
            }
        }
    }

    /** 检查是否应该停止自动下注（日级控制） */
    fun shouldStopAutoTrading(): Boolean {
        if (!dailyConfig.enabled) return false
        return dailyStats.autoStopped || dailyStats.totalBets >= dailyConfig.maxDailyBets
    }

    /** 获取日级停机原因 */
    fun dailyStopReason(): String? {
        if (!dailyStats.autoStopped) return null
        return when {
            dailyStats.stopLossHit -> "日止损触发 (亏损 %.2f USDT = %.1f%%)".format(
                -dailyStats.netProfit, -dailyStats.netProfitPct
            )
            dailyStats.takeProfitHit -> "日止盈触发 (盈利 %.2f USDT = +%.1f%%)".format(
                dailyStats.netProfit, dailyStats.netProfitPct
            )
            else -> "日最大下注次数达上限"
        }
    }

    // === 原有辅助方法 ===

    /**
     * 手动结算当前周期（用于测试或强制结算）。
     */
    fun forceSettle(now: Long, closePrice: Double) {
        settleRound(now, closePrice)
    }

    /**
     * 获取当前周期的倒计时（秒）。
     */
    fun remainingSeconds(now: Long): Long {
        return currentRound?.remainingSec(now) ?: 0L
    }

    /**
     * 获取当前价格相对于开窗价格的涨跌幅（%）。
     */
    fun currentMovePct(currentPrice: Double): Double {
        val round = currentRound ?: return 0.0
        if (round.openPrice <= 0) return 0.0
        return (currentPrice - round.openPrice) * 100.0 / round.openPrice
    }

    /**
     * 根据当前价格预测当前会涨还是跌（实时判断，非最终结算）。
     */
    fun currentLiveDirection(currentPrice: Double): BetDirection {
        val round = currentRound ?: return BetDirection.YES
        return if (currentPrice >= round.openPrice) BetDirection.YES else BetDirection.NO
    }

    /**
     * 统计摘要。
     */
    fun statsSummary(): BinaryOptionStats {
        val s = roundStats
        val settled = account.settledBets
        val wins = settled.filter { it.won }
        val losses = settled.filter { !it.won }
        val avgWin = if (wins.isNotEmpty()) wins.map { it.profit }.average() else 0.0
        val avgLoss = if (losses.isNotEmpty()) losses.map { it.profit }.average() else 0.0
        val avgBet = if (settled.isNotEmpty()) settled.map { it.bet.amount }.average() else 0.0

        return BinaryOptionStats(
            balance = account.balance,
            netProfit = account.netProfit,
            roiPct = account.roiPct,
            winRate = account.winRatePct,
            profitFactor = account.profitFactor,
            maxDrawdownPct = account.maxDrawdownPct,
            totalTrades = account.totalTrades,
            winCount = account.winCount,
            lossCount = account.lossCount,
            avgWinProfit = avgWin,
            avgLossProfit = avgLoss,
            avgBetSize = avgBet,
            pendingBets = account.pendingBets.size,
            totalRounds = s.totalRounds,
            yesRatePct = s.yesRatePct,
            bestStreak = s.bestStreak,
            currentStreak = s.currentStreak,
            totalWagered = account.totalWagered,
            totalPayout = account.totalPayout
        )
    }

    /** 生成当天日期字符串 */
    private fun todayStr(now: Long = System.currentTimeMillis()): String {
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(now))
    }
}

/** DailyStats 扩展：停机原因 */
private fun DailyStats.autoStoppedReason(): String {
    return when {
        stopLossHit -> "日止损"
        takeProfitHit -> "日止盈"
        else -> "已达日最大下注次数"
    }
}

/** 二元期权统计摘要（供 UI 使用） */
data class BinaryOptionStats(
    val balance: Double,
    val netProfit: Double,
    val roiPct: Double,
    val winRate: Double,
    val profitFactor: Double,
    val maxDrawdownPct: Double,
    val totalTrades: Int,
    val winCount: Int,
    val lossCount: Int,
    val avgWinProfit: Double,
    val avgLossProfit: Double,
    val avgBetSize: Double,
    val pendingBets: Int,
    val totalRounds: Int,
    val yesRatePct: Double,
    val bestStreak: Int,
    val currentStreak: Int,
    val totalWagered: Double,
    val totalPayout: Double
)
