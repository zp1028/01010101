# 平台接入口连通状态（本版）

## 币安 USDⓈ-M
| 能力 | 类 | 状态 |
|------|-----|------|
| K线/行情 | BinanceMarketRepository | ✅ 公共 REST |
| Mark/Funding/OI | BinanceDerivativesRepository | ✅ 公共 REST |
| 签名下单/撤单/账户 | BinanceFuturesBroker | ✅ HMAC-SHA256（需注入 Key） |
| 端点 | DEMO / TESTNET / MAINNET | ✅ 可选 |
| PAPER | PaperPerpBroker | ✅ 无密钥 |

密钥：`BrokerCredentialStore`（运行时写入，禁止写死进 APK）

## Polymarket
| 能力 | 状态 |
|------|------|
| Gamma 市场发现 | ✅ |
| CLOB 盘口 | ✅ |
| 下单 | dry-run 默认；有 API Key 时 POST `/order` 骨架（完整 EIP-712/L2 签名需钱包层） |

## 币安事件合约
| 能力 | 状态 |
|------|------|
| 信号/EV | ✅ EventContractEngine |
| 下单 | Paper / 拒绝未固化 REST（避免错端点） |

## 工厂
`BrokerFactory.perp / polymarket / eventContract`
`MultiEngineOrchestrator.fromCredentials`

## 安全
- 不把 Key 打进资源文件
- MAINNET 仅在用户显式配置 endpoint=MAINNET 且非 forcePaper 时走真单
