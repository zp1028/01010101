# BTC Quant V2 — 第一阶段代码实现

## 已实现
- 独立 `domain.btc` 领域包，不复用彩票 `PlanPoolV2`。
- Binance Futures 公共 K 线读取器（无 API Key，仅行情）。
- BTC 计划引擎：趋势、动量、K 线结构、量价、波动五类计划。
- 市场状态：趋势、震荡、突破、高波动。
- 计划池动态适配：根据市场状态调整计划权重。
- 滚动历史方向命中率用于计划校准。
- UP / DOWN / FLAT 三向共识，而非强制二选一。
- 方向概率、共识强度、预期波动、风险评分。
- ContractSignal 与 PredictionMarketSignal 完全分离。
- 新 BTC UI：价格、市场状态、方向概率、共识条、K 线结构图、计划竞争列表、多周期切换。

## 未在这一阶段接入
- CEX 私有 API 下单、杠杆、仓位和真实资金操作。
- Polymarket 订单执行。
- AI/新闻作为实盘决策源。
- 持久化的计划生命周期数据库。

## 下一阶段
1. 计划池持久化：每个计划独立记录信号、MFE/MAE、PF、回撤、持仓时间。
2. 真正的 walk-forward 回测与样本外评分。
3. 计划相关性去重与多周期协调。
4. OI / Funding / Liquidation / VWAP / Order Book 特征层。
5. 独立 Prediction Market Engine：market probability vs model probability vs edge。
6. Broker 层只接受已校验的 Signal，不接受 AI 原文。
