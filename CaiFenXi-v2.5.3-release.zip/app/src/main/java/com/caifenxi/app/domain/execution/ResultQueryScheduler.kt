package com.caifenxi.app.domain.execution

import com.caifenxi.app.service.WebViewBetExecutor
import com.caifenxi.app.util.RuntimeLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import java.util.concurrent.ConcurrentHashMap

/**
 * v2.5.3: 独立结果查询调度器。
 *
 * 职责：与下注执行链路完全解耦，专门处理 COMMITTED_UNKNOWN 状态的工单。
 * 当 BetScheduler 收到 COMMITTED_UNKNOWN 结果时，将工单转交此模块后续查询。
 *
 * 查询手段（按优先级）：
 * 1. 余额接口对比（通过 WebViewBetExecutor 的 SiteAdapter.balanceSnapshotScript）
 *    — 对比下注前余额与当前余额，若差额≈下注金额且为扣款，判定成功。
 * 2. 订单列表/成功提示 JS 轻量查询（占位，需接入实际站点 API）
 *
 * 查询成功 → markPlaced() 迁移到 placedIssues + 更新 repository
 * 查询超时（2 分钟）→ 移除队列，日志提示人工兜底
 *
 * 设计原则：
 * - 只查询，绝不再点击任何下注按钮
 * - 独立 CoroutineScope，不阻塞 BetScheduler 执行队列
 * - 同一彩种+期号只允许一个查询任务
 */
object ResultQueryScheduler {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    /** 轮询间隔（毫秒）：前 30 秒每 3 秒一次，之后每 8 秒一次 */
    private const val POLL_INTERVAL_FAST_MS = 3_000L
    private const val POLL_INTERVAL_SLOW_MS = 8_000L

    /** 最大查询时长（毫秒），超时后放弃 */
    private const val MAX_QUERY_DURATION_MS = 120_000L

    /** 正在查询的彩种/期号任务 */
    private val activeQueries = ConcurrentHashMap<String, QueryJob>()

    /** WebViewBetExecutor 引用（由 CaiFenXiApplication 注入） */
    @Volatile
    private var webViewExecutor: WebViewBetExecutor? = null

    /** ExecutionRepository 引用（由 BetScheduler 传入） */
    @Volatile
    private var repository: ExecutionRepository? = null

    private data class QueryJob(
        val lotteryKey: String,
        val issue: String,
        val cmdId: String,
        val amountText: String,
        val balanceBefore: String,
        val startTime: Long,
        val job: Job
    )

    /**
     * 注入依赖（App 启动时由 CaiFenXiApplication 调用）。
     */
    fun bind(executor: WebViewBetExecutor, repo: ExecutionRepository? = null) {
        webViewExecutor = executor
        repository = repo
        RuntimeLog.info("ResultQuery", "已绑定执行器和仓库")
    }

    /**
     * 将 COMMITTED_UNKNOWN 工单加入查询队列。
     * 由 BetScheduler 在执行完成且结果为 COMMITTED_UNKNOWN 时调用。
     *
     * @param lotteryKey 彩种
     * @param issue 期号
     * @param cmdId 原始工单 ID
     * @param amountText 下注金额（用于余额对比）
     * @param balanceBefore 下注前余额（用于余额对比）
     */
    fun enqueue(
        lotteryKey: String,
        issue: String,
        cmdId: String,
        amountText: String,
        balanceBefore: String = ""
    ) {
        val key = "$lotteryKey|$issue"

        // 已在查询中 → 不重复入队
        if (activeQueries.containsKey(key)) {
            RuntimeLog.info("ResultQuery", "已在查询队列中，跳过 $key cmdId=$cmdId")
            return
        }

        // 已确认成功 → 不需要查询
        if (ExecutionTicketStore.isIssuePlaced(lotteryKey, issue)) {
            RuntimeLog.info("ResultQuery", "本期已确认成功，跳过查询 $key")
            return
        }

        val job = scope.launch {
            val startTime = System.currentTimeMillis()
            RuntimeLog.info(
                "ResultQuery",
                "开始结果查询 $key cmdId=$cmdId 金额=$amountText 余额前=$balanceBefore"
            )

            var querySuccess = false
            var lastError: String? = null
            var lastBalance: String? = null
            var stableCount = 0

            while (System.currentTimeMillis() - startTime < MAX_QUERY_DURATION_MS) {
                if (!isActive(lotteryKey, issue)) break

                val elapsed = System.currentTimeMillis() - startTime
                val interval = if (elapsed < 30_000L) POLL_INTERVAL_FAST_MS else POLL_INTERVAL_SLOW_MS

                try {
                    val result = queryOnce(lotteryKey, issue, amountText, balanceBefore)
                    when (result) {
                        is QueryResult.Success -> {
                            querySuccess = true
                            lastBalance = result.balance
                            break
                        }
                        is QueryResult.StillPending -> {
                            // 余额连续稳定判定：连续 2 次读数一致且与 balanceBefore 不同，视为成功
                            if (lastBalance != null && lastBalance == result.balance && lastBalance != balanceBefore) {
                                stableCount++
                                if (stableCount >= 2) {
                                    RuntimeLog.info(
                                        "ResultQuery",
                                        "余额连续稳定 $stableCount 次，判定成功 $key"
                                    )
                                    querySuccess = true
                                    break
                                }
                            } else {
                                stableCount = 0
                            }
                            lastBalance = result.balance
                        }
                        is QueryResult.QueryFailed -> {
                            lastError = result.reason
                            stableCount = 0
                        }
                    }
                } catch (e: Exception) {
                    lastError = e.message
                    RuntimeLog.warn("ResultQuery", "查询异常 $key: ${e.message}")
                }

                delay(interval)
            }

            if (querySuccess) {
                // 查询确认成功 → 迁移到 placedIssues + 同步 repository
                ExecutionTicketStore.markPlaced(lotteryKey, issue)
                val successResult = ExecutionResult.committedSuccess(
                    cmdId,
                    "结果查询确认成功（余额=$lastBalance）",
                    durationMs = System.currentTimeMillis() - startTime
                )
                ExecutionTicketStore.updateStatus(
                    cmdId, "SUCCESS",
                    "结果查询确认成功",
                    balanceAfter = lastBalance ?: "queried"
                )
                repository?.complete(cmdId, successResult)
                RuntimeLog.info(
                    "ResultQuery",
                    "查询确认成功 $key cmdId=$cmdId → markPlaced 余额=$lastBalance"
                )
            } else {
                // 超时 → 人工兜底
                val elapsed = System.currentTimeMillis() - startTime
                RuntimeLog.warn(
                    "ResultQuery",
                    "查询超时(${elapsed}ms)，需人工确认 $key cmdId=$cmdId lastError=$lastError"
                )
                ExecutionTicketStore.updateStatus(
                    cmdId, "COMMITTED_UNKNOWN",
                    "结果查询超时，需人工确认是否下注成功（已永久锁定本期，不会自动重试）"
                )
            }

            activeQueries.remove(key)
        }

        activeQueries[key] = QueryJob(lotteryKey, issue, cmdId, amountText, balanceBefore, System.currentTimeMillis(), job)
    }

    /**
     * 单次查询：通过 WebView JS 读取余额并与下注前余额对比。
     * 判定逻辑：
     * 1. 余额可读且非空
     * 2. 若 balanceBefore 有值，当前余额与 balanceBefore 的差额 ≈ amountText（扣款方向）→ 成功
     * 3. 否则返回 StillPending，由外层连续稳定判定确认
     */
    private suspend fun queryOnce(
        lotteryKey: String,
        issue: String,
        amountText: String,
        balanceBefore: String
    ): QueryResult {
        val executor = webViewExecutor
        if (executor == null || !executor.isAvailable) {
            return QueryResult.QueryFailed("WebView 未连接，无法查询")
        }

        val adapter = executor.siteAdapter
        val balJs = adapter.balanceSnapshotScript

        return withContext(Dispatchers.Main) {
            try {
                val wv = executor.getWebViewForQuery()
                if (wv == null) {
                    return@withContext QueryResult.QueryFailed("WebView 引用为空")
                }

                val balanceResult = executeJsSuspend(wv, balJs)
                val balance = balanceResult?.trim()?.trim('"') ?: ""

                if (balance.isBlank() || balance == "null") {
                    return@withContext QueryResult.QueryFailed("余额读取为空")
                }

                RuntimeLog.info("ResultQuery", "余额查询: $balance $lotteryKey/$issue")

                // 余额对比判定
                if (balanceBefore.isNotBlank() && balanceBefore != "null") {
                    val beforeVal = parseBalanceNumber(balanceBefore)
                    val afterVal = parseBalanceNumber(balance)
                    val amtVal = amountText.toDoubleOrNull()

                    if (beforeVal != null && afterVal != null && amtVal != null && amtVal > 0) {
                        val delta = beforeVal - afterVal  // 扣款 = 余额减少
                        val deltaAbs = kotlin.math.abs(delta)
                        val amtAbs = kotlin.math.abs(amtVal)
                        // 容差 15%：余额减少量 ≈ 下注金额
                        val matched = delta > 0 && kotlin.math.abs(deltaAbs - amtAbs) < amtAbs * 0.15
                        if (matched) {
                            RuntimeLog.info(
                                "ResultQuery",
                                "余额对比成功: 前=$beforeVal 后=$afterVal 差=$delta 金额=$amtVal $key"
                            )
                            return@withContext QueryResult.Success(balance)
                        }
                    }
                }

                QueryResult.StillPending(balance)
            } catch (e: Exception) {
                QueryResult.QueryFailed("JS 查询异常: ${e.message}")
            }
        }
    }

    /** 解析余额字符串（去掉币种符号、千分位逗号） */
    private fun parseBalanceNumber(raw: String): Double? {
        if (raw.isBlank() || raw == "null") return null
        val cleaned = raw.replace(",", "").replace("¥", "").replace("$", "")
            .replace("￥", "").replace(" ", "").trim()
        return cleaned.toDoubleOrNull()
    }

    /**
     * 在 WebView 上执行 JS 并等待结果（suspend 封装）。
     */
    private suspend fun executeJsSuspend(
        wv: android.webkit.WebView,
        script: String
    ): String? = suspendCancellableCoroutine { cont ->
        wv.evaluateJavascript(script) { result ->
            if (cont.isActive) cont.resume(result)
        }
    }

    private fun isActive(lotteryKey: String, issue: String): Boolean =
        activeQueries.containsKey("$lotteryKey|$issue")

    /** 停止所有查询任务（挂机停止时调用） */
    fun stopAll() {
        activeQueries.values.forEach { it.job.cancel() }
        activeQueries.clear()
        RuntimeLog.info("ResultQuery", "所有查询任务已停止")
    }

    /** 查询结果 */
    private sealed class QueryResult {
        /** 查询确认成功 */
        data class Success(val balance: String) : QueryResult()
        /** 仍在等待结果，继续轮询 */
        data class StillPending(val balance: String) : QueryResult()
        /** 查询本身失败 */
        data class QueryFailed(val reason: String) : QueryResult()
    }
}
