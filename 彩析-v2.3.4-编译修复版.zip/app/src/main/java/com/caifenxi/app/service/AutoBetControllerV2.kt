package com.caifenxi.app.service

import android.content.Context
import android.os.Looper
import com.caifenxi.app.CaiFenXiApplication
import com.caifenxi.app.data.local.UserPrefs
import com.caifenxi.app.domain.execution.*
import com.caifenxi.app.domain.model.*
import com.caifenxi.app.util.RuntimeLog
import kotlinx.coroutines.runBlocking

/**
 * V2.0 生产级自动下注控制器
 *
 * 改造要点：
 * 1. 删除所有 SharedPreferences 全局状态（KEY_INFLIGHT_*, KEY_PENDING_*, KEY_LAST_*, KEY_PLACED_*, KEY_CHASE_*）
 * 2. 状态全部持久化到 ExecutionTaskManager + ExecutionRepository
 * 3. 只负责「彩析计算 → 生成 BetCommand」，不直接操作控件
 * 4. 通过 BetScheduler 派发执行
 */
object AutoBetController {

    // ========== V2.0 新增依赖 ==========
    private var taskManager: ExecutionTaskManager? = null
    private var repository: ExecutionRepository? = null
    private var scheduler: BetScheduler? = null

    /** 初始化注入（Application.onCreate 中调用） */
    fun init(taskManager: ExecutionTaskManager, repository: ExecutionRepository, scheduler: BetScheduler) {
        this.taskManager = taskManager
        this.repository = repository
        this.scheduler = scheduler
    }

    // ========== 保留：倍投/金额计算逻辑（无状态） ==========

    data class AmountDecision(val text: String?, val kind: String)
    data class AmountStrategyInfo(
        val lastHit: Boolean?,
        val lastHitLabel: String,
        val chaseUsed: Boolean,
        val nextAmountText: String?,
        val nextAmountKind: String,
        val lastPredIssue: String,
        val lastPredDx: String,
        val lastPredDs: String
    )

    /** V2.0：从 ExecutionRepository 读取上期结果，替代 SharedPreferences */
    fun onNewPrediction(context: Context, snap: FloatingSnapshot) {
        val prefs = try {
            CaiFenXiApplication.instance.configStore.loadPrefs()
        } catch (_: Exception) {
            return
        }
        val repo = repository ?: return
        val mgr = taskManager ?: return
        val sched = scheduler ?: return

        val lotteryKey = snap.lotteryKey
        val targetIssue = snap.targetIssue

        // V2.0 新增：检查彩种是否被阻塞（有 UNKNOWN 任务）
        if (runBlocking { repo.isLotteryBlocked(lotteryKey) }) {
            RuntimeLog.warn("AutoBet", "【阻塞】$lotteryKey 存在 UNKNOWN 任务，暂停自动执行")
            return
        }

        // V2.0 新增：检查是否已存在同彩种同期待执行/执行中的任务
        val pending = runBlocking { repo.findPendingByLottery(lotteryKey) }
        if (pending.any { it.issue == targetIssue }) {
            RuntimeLog.info("AutoBet", "期号已存在待执行任务 issue=$targetIssue，跳过")
            return
        }

        // 1. 彩析计算（方向/期数/金额）
        val (dx, ds) = resolveClickTargets(prefs, snap)
        val combo = resolveCombo(snap, prefs)
        val numbers = resolvePredNumbers(snap)
        val amountDecision = resolveAmountDecision(context, prefs)

        if (dx == null && ds == null && combo == null && numbers.isEmpty()) {
            RuntimeLog.info("AutoBet", "无有效点击方向 issue=$targetIssue")
            return
        }

        // 2. 构建 BetCommand
        val bets = buildList {
            dx?.let { add(BetAction(BetAction.CAT_DX, it)) }
            ds?.let { add(BetAction(BetAction.CAT_DS, it)) }
            combo?.let { add(BetAction(BetAction.CAT_COMBO, it)) }
            numbers.forEach { add(BetAction(BetAction.CAT_NUMBER, it)) }
        }

        val stage = resolveWorkbenchStage(context, prefs)
        val lossStreak = runBlocking {
            val last = repo.findLastSuccess(lotteryKey)
            last?.let { calculateLossStreak(repo, lotteryKey, it) } ?: 0
        }

        val command = BetCommand(
            lotteryKey = lotteryKey,
            issue = targetIssue,
            bets = bets,
            amountText = amountDecision.text,
            stage = stage,
            leg = lossStreak,
            expireAt = System.currentTimeMillis() + 120_000, // 2分钟过期
            meta = mapOf(
                "amountKind" to amountDecision.kind,
                "source" to describeClickSource(context, prefs, lotteryKey),
                "reverseMode" to isReverseBetMode(prefs).toString()
            )
        )

        // 3. 创建 ExecutionTask（状态=CREATED）并持久化
        val task = runBlocking { repo.create(command) }
        RuntimeLog.info("AutoBet", "生成任务 cmdId=${task.cmdId} issue=$targetIssue 金额=${amountDecision.text ?: "-"} kind=${amountDecision.kind}")

        // 4. 交给调度器（不再直接操作控件）
        sched.dispatch(task)
    }

    /** V2.0：开奖后结算，更新 chase 计数 */
    fun onDrawResult(context: Context, lotteryKey: String, issue: String, actualDx: String?, actualDs: String?) {
        val repo = repository ?: return
        val lastSuccess = runBlocking { repo.findLastSuccess(lotteryKey) } ?: return

        // 比对预测与实际开奖
        val hit = checkHit(lastSuccess, actualDx, actualDs)
        RuntimeLog.info("AutoBet", "开奖比对 issue=$issue hit=$hit")

        // 更新 chase 状态（通过新任务 meta 传递，或单独存储）
        // V2.0 简化：chase 计数作为 AmountDecision 的输入，不存全局变量
    }

    // ========== 保留：金额策略计算（纯函数，无状态） ==========

    private fun resolveAmountDecision(context: Context, prefs: UserPrefs): AmountDecision {
        if (!prefs.autoInputEnabled) return AmountDecision(null, "未启用")
        val base = prefs.autoInputBaseAmount
        val multAmount = prefs.autoInputMultAmount

        // V2.0：从 Repository 读取上期结果，替代 SharedPreferences
        val lastHit = runBlocking {
            val repo = repository ?: return@runBlocking null
            val last = repo.findLastSuccess(prefs.lastLotteryKey ?: "")
            last?.result?.let { it.code == ExecutionResult.Code.SUCCESS }
        }

        val lossStreak = 0 // V2.0：从 Repository 历史计算，简化版先置0
        val stage = resolveWorkbenchStage(context, prefs)

        if (lastHit == true) {
            return AmountDecision(formatAmount(base), if (stage >= 2) "工作台${stage}期·基数" else "复原")
        }
        if (stage >= 2) {
            val leg = lossStreak % stage
            val amount = amountForWorkbenchLeg(base, multAmount, leg)
            val label = if (leg == 0) "工作台${stage}期·轮首" else "工作台${stage}期·第${leg + 1}腿"
            return AmountDecision(formatAmount(amount), label)
        }
        val chaseMax = prefs.autoInputChaseMax.coerceIn(1, 20)
        val pos = (lossStreak - 1).coerceAtLeast(0) % (chaseMax + 1)
        return if (pos < chaseMax) {
            AmountDecision(formatAmount(multAmount), "倍投(${pos + 1}/$chaseMax)")
        } else {
            AmountDecision(formatAmount(base), "复原(间隔)")
        }
    }

    private fun resolveWorkbenchStage(context: Context, prefs: UserPrefs): Int {
        if (!prefs.autoClickFollowBetSource) return 1
        val lotteryKey = prefs.lastLotteryKey ?: return 1
        return try {
            if (Looper.myLooper() == Looper.getMainLooper()) {
                1 // 主线程不查库
            } else {
                runBlocking {
                    val cfg = CaiFenXiApplication.instance.database.betDao().getBotConfig(lotteryKey)
                    cfg?.rollingStage?.coerceIn(1, 3) ?: 1
                }
            }
        } catch (_: Exception) { 1 }
    }

    private fun amountForWorkbenchLeg(base: Double, multAmount: Double, leg: Int): Double {
        if (leg <= 0) return base
        val ratio = if (base > 1e-9) (multAmount / base).coerceAtLeast(1.0) else 2.0
        var a = base
        repeat(leg) { a *= ratio }
        return a
    }

    private fun formatAmount(v: Double): String {
        val r = (v * 100).toLong() / 100.0
        return if (r == r.toLong().toDouble()) r.toLong().toString() else "%.2f".format(r)
    }

    // ========== 保留：方向解析（纯函数） ==========

    fun isReverseBetMode(prefs: UserPrefs): Boolean =
        prefs.autoClickBetMode.equals("reverse", ignoreCase = true)

    fun betModeLabel(prefs: UserPrefs): String = if (isReverseBetMode(prefs)) "反投" else "正投"

    fun invertDx(dx: String?): String? = when (dx?.trim()) { "大" -> "小"; "小" -> "大"; else -> dx }
    fun invertDs(ds: String?): String? = when (ds?.trim()) { "单" -> "双"; "双" -> "单"; else -> ds }
    fun invertCombo(combo: String?): String? = when (combo?.trim()) {
        "大单" -> "小双"; "大双" -> "小单"; "小单" -> "大双"; "小双" -> "大单"; else -> combo
    }

    fun resolveClickTargets(prefs: UserPrefs, snap: FloatingSnapshot): Triple<String?, String?, String?> {
        val (rawDx, rawDs) = resolvePrediction(prefs, snap)
        val rawCombo = resolveCombo(snap, prefs)
        return if (isReverseBetMode(prefs)) {
            Triple(invertDx(rawDx), invertDs(rawDs), invertCombo(rawCombo))
        } else {
            Triple(rawDx, rawDs, rawCombo)
        }
    }

    fun resolveCombo(snap: FloatingSnapshot, prefs: UserPrefs? = null): String? {
        val candidates = listOf(snap.consensusCombo, snap.novaConsensusCombo, snap.algoCombo)
        for (c in candidates) {
            val t = c?.trim()
            if (t in listOf("大单", "大双", "小单", "小双")) return t
        }
        return null
    }

    fun resolvePredNumbers(snap: FloatingSnapshot): List<String> =
        snap.predNumbers.orEmpty().split(",", "、", "/", " ")
            .map { it.trim() }.filter { it.toIntOrNull() != null }.distinct().take(20)

    fun resolvePrediction(prefs: UserPrefs, snap: FloatingSnapshot): Pair<String?, String?> {
        val candidates = listOf(
            snap.consensusDx to snap.consensusDs,
            snap.novaConsensusDx to snap.novaConsensusDs,
            snap.algoDx to snap.algoDs
        )
        for ((dx, ds) in candidates) {
            val validDx = dx?.takeIf { it == "大" || it == "小" }
            val validDs = ds?.takeIf { it == "单" || it == "双" }
            if (validDx != null || validDs != null) return validDx to validDs
        }
        return null to null
    }

    fun describeClickSource(context: Context, prefs: UserPrefs, lotteryKey: String): String {
        return if (prefs.autoClickFollowBetSource) "跟随挂机" else "悬浮窗"
    }

    // ========== V2.0 新增：辅助方法 ==========

    private fun checkHit(task: ExecutionTask, actualDx: String?, actualDs: String?): Boolean {
        val bets = task.command.bets
        var checked = false
        var ok = true
        bets.forEach { bet ->
            when (bet.category) {
                BetAction.CAT_DX -> {
                    checked = true
                    if (actualDx == null || actualDx != bet.value) ok = false
                }
                BetAction.CAT_DS -> {
                    checked = true
                    if (actualDs == null || actualDs != bet.value) ok = false
                }
            }
        }
        return checked && ok
    }

    private suspend fun calculateLossStreak(repo: ExecutionRepository, lotteryKey: String, lastSuccess: ExecutionTask): Int {
        // V2.0：从 Repository 历史计算连错次数
        // 简化实现：返回 lastSuccess.command.leg
        return lastSuccess.command.leg
    }

    /** V2.0：获取某彩种的策略信息（悬浮窗展示用） */
    fun getStrategyInfo(lotteryKey: String): AmountStrategyInfo {
        val repo = repository ?: return AmountStrategyInfo(null, "未知", false, null, "", "", "", "")
        val last = runBlocking { repo.findLastSuccess(lotteryKey) }
        return AmountStrategyInfo(
            lastHit = last?.result?.let { it.code == ExecutionResult.Code.SUCCESS },
            lastHitLabel = if (last?.result?.code == ExecutionResult.Code.SUCCESS) "对" else "错",
            chaseUsed = false,
            nextAmountText = null,
            nextAmountKind = "",
            lastPredIssue = last?.issue ?: "",
            lastPredDx = last?.command?.bets?.find { it.category == BetAction.CAT_DX }?.value ?: "",
            lastPredDs = last?.command?.bets?.find { it.category == BetAction.CAT_DS }?.value ?: ""
        )
    }
}
