package com.caifenxi.app.data.repository

import com.caifenxi.app.data.db.CaiDatabase
import com.caifenxi.app.data.db.entity.ExecutionTaskEntity
import com.caifenxi.app.domain.execution.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * V2.0 生产级执行仓库实现
 * 内存缓存 + Room 持久化，支持崩溃恢复
 */
class ExecutionRepositoryImpl(
    private val db: CaiDatabase
) : ExecutionRepository {

    private val dao = db.executionTaskDao()
    private val json = Json { ignoreUnknownKeys = true }

    override suspend fun create(command: BetCommand): ExecutionTask {
        val task = ExecutionTask(
            cmdId = command.cmdId,
            lotteryKey = command.lotteryKey,
            issue = command.issue,
            stage = command.stage,
            leg = command.leg,
            state = ExecutionTask.State.CREATED,
            command = command,
            createdAt = System.currentTimeMillis()
        )
        dao.insert(task.toEntity())
        return task
    }

    override suspend fun transition(cmdId: String, from: ExecutionTask.State, to: ExecutionTask.State): Boolean {
        return dao.casUpdateState(cmdId, from.name, to.name) > 0
    }

    override suspend fun findById(cmdId: String): ExecutionTask? {
        return dao.getById(cmdId)?.toDomain()
    }

    override suspend fun findPendingByLottery(lotteryKey: String): List<ExecutionTask> {
        return dao.getByLotteryAndStates(
            lotteryKey, 
            listOf("CREATED", "LOCKED", "EXECUTING", "VERIFYING")
        ).map { it.toDomain() }
    }

    override suspend fun findUnknowns(): List<ExecutionTask> {
        return dao.getUnknowns().map { it.toDomain() }
    }

    override suspend fun findLastSuccess(lotteryKey: String): ExecutionTask? {
        return dao.getLastSuccess(lotteryKey)?.toDomain()
    }

    override suspend fun isLotteryBlocked(lotteryKey: String): Boolean {
        return dao.hasUnknownForLottery(lotteryKey)
    }

    override suspend fun complete(cmdId: String, result: ExecutionResult): Boolean {
        val state = when (result.code) {
            ExecutionResult.ResultCode.SUCCESS -> ExecutionTask.State.SUCCESS
            ExecutionResult.ResultCode.FAILED -> ExecutionTask.State.FAILED
            ExecutionResult.ResultCode.UNKNOWN -> ExecutionTask.State.UNKNOWN
            ExecutionResult.ResultCode.EXPIRED -> ExecutionTask.State.EXPIRED
            else -> ExecutionTask.State.UNKNOWN
        }
        return dao.complete(
            cmdId, 
            state.name, 
            json.encodeToString(result),
            System.currentTimeMillis()
        ) > 0
    }

    override suspend fun expire(cmdId: String): Boolean {
        return dao.casUpdateState(cmdId, ExecutionTask.State.CREATED.name, ExecutionTask.State.EXPIRED.name) > 0 ||
               dao.casUpdateState(cmdId, ExecutionTask.State.LOCKED.name, ExecutionTask.State.EXPIRED.name) > 0
    }

    override suspend fun acknowledgeUnknown(cmdId: String): Boolean {
        return dao.acknowledgeUnknown(cmdId) > 0
    }

    override fun observeLotteryTasks(lotteryKey: String): Flow<List<ExecutionTask>> {
        return dao.observeByLottery(lotteryKey).map { list -> list.map { it.toDomain() } }
    }

    override fun observeUnknowns(): Flow<List<ExecutionTask>> {
        return dao.observeUnknowns().map { list -> list.map { it.toDomain() } }
    }

    // ========== Entity ↔ Domain 转换 ==========

    private fun ExecutionTask.toEntity(): ExecutionTaskEntity = ExecutionTaskEntity(
        cmdId = cmdId,
        lotteryKey = lotteryKey,
        issue = issue,
        stage = stage,
        leg = leg,
        state = state.name,
        commandJson = json.encodeToString(command),
        resultJson = result?.let { json.encodeToString(it) },
        retryOf = retryOf,
        createdAt = createdAt,
        lockedAt = lockedAt,
        executedAt = executedAt,
        verifiedAt = verifiedAt,
        completedAt = if (isTerminal) System.currentTimeMillis() else null
    )

    private fun ExecutionTaskEntity.toDomain(): ExecutionTask = ExecutionTask(
        cmdId = cmdId,
        lotteryKey = lotteryKey,
        issue = issue,
        stage = stage,
        leg = leg,
        state = ExecutionTask.State.valueOf(state),
        command = json.decodeFromString(commandJson),
        result = resultJson?.let { json.decodeFromString(it) },
        retryOf = retryOf,
        createdAt = createdAt,
        lockedAt = lockedAt,
        executedAt = executedAt,
        verifiedAt = verifiedAt
    )
}
