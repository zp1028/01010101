package com.caifenxi.app.service

import android.webkit.WebView
import com.caifenxi.app.domain.execution.*
import com.caifenxi.app.util.RuntimeLog

/**
 * V2.0 生产级 WebView 执行器
 *
 * 强化：
 * 1. 执行前"三验"（域名/彩种/期号）
 * 2. 余额快照比对（执行前后 Hash 对比）
 * 3. 8秒超时保护
 * 4. 无沙盒，所有 click() 和 submit() 均为真实触发
 */
class WebViewBetExecutor : Executor {

    override val id = "webview"
    override val isAvailable: Boolean get() = webView != null

    private var webView: WebView? = null
    private var siteAdapter: SiteAdapter? = null

    fun attachWebView(wv: WebView) {
        this.webView = wv
    }

    fun setSiteAdapter(adapter: SiteAdapter) {
        this.siteAdapter = adapter
    }

    override fun execute(command: BetCommand, onResult: (ExecutionResult) -> Unit): Boolean {
        val wv = webView ?: return false
        val adapter = siteAdapter ?: return false

        // 1. 加载目标页面
        val url = adapter.getUrl(command.lotteryKey)
        wv.loadUrl(url)

        // 2. 等待页面加载完成 + 执行前"三验"
        wv.evaluateJavascript("""
            (function() {
                // 三验
                const domainOk = window.location.hostname.includes('${adapter.whitelistDomains.first()}');
                const lotteryOk = document.title.includes('${command.lotteryKey}') || 
                                  document.querySelector('.lottery-name')?.innerText?.includes('${command.lotteryKey}');
                const issueEl = document.querySelector('${adapter.issueSelector}');
                const issueOk = issueEl && issueEl.innerText.trim() === '${command.issue}';

                return JSON.stringify({
                    domainOk: domainOk,
                    lotteryOk: lotteryOk,
                    issueOk: issueOk,
                    actualIssue: issueEl?.innerText?.trim() || 'NOT_FOUND',
                    hostname: window.location.hostname
                });
            })();
        """) { raw ->
            try {
                val check = org.json.JSONObject(raw)
                val domainOk = check.getBoolean("domainOk")
                val lotteryOk = check.getBoolean("lotteryOk")
                val issueOk = check.getBoolean("issueOk")
                val actualIssue = check.getString("actualIssue")

                if (!domainOk) {
                    onResult(ExecutionResult(command.cmdId, ExecutionResult.Code.FAILED, "域名不匹配"))
                    return@evaluateJavascript
                }
                if (!lotteryOk) {
                    onResult(ExecutionResult(command.cmdId, ExecutionResult.Code.FAILED, "彩种不匹配"))
                    return@evaluateJavascript
                }
                if (!issueOk) {
                    onResult(ExecutionResult(command.cmdId, ExecutionResult.Code.FAILED, 
                        "期号不匹配: 期望=${command.issue} 实际=$actualIssue"))
                    return@evaluateJavascript
                }

                // 三验通过，记录余额快照
                wv.evaluateJavascript(adapter.balanceSnapshotScript) { beforeHash ->
                    // 3. 注入执行脚本
                    val js = adapter.buildInjectScript(command)
                    wv.evaluateJavascript(js) { execRaw ->
                        // 4. 执行后验证
                        verifyResult(wv, adapter, command, beforeHash, execRaw, onResult)
                    }
                }
            } catch (e: Exception) {
                onResult(ExecutionResult(command.cmdId, ExecutionResult.Code.UNKNOWN, "三验异常: ${e.message}"))
            }
        }

        return true
    }

    private fun verifyResult(
        wv: WebView,
        adapter: SiteAdapter,
        command: BetCommand,
        beforeHash: String,
        execRaw: String,
        onResult: (ExecutionResult) -> Unit
    ) {
        // 读取执行后余额快照
        wv.evaluateJavascript(adapter.balanceSnapshotScript) { afterHash ->
            val balanceChanged = beforeHash != afterHash && afterHash != "null"

            // 解析页面回执
            val receipt = adapter.parseReceipt(execRaw)

            when {
                receipt.isSuccess && balanceChanged -> {
                    onResult(ExecutionResult(command.cmdId, ExecutionResult.Code.SUCCESS, 
                        "下单成功+资金变动: ${receipt.message}"))
                }
                receipt.isSuccess && !balanceChanged -> {
                    onResult(ExecutionResult(command.cmdId, ExecutionResult.Code.SUCCESS, 
                        "下单成功(无资金变动): ${receipt.message}"))
                }
                receipt.isError -> {
                    onResult(ExecutionResult(command.cmdId, ExecutionResult.Code.FAILED, 
                        "页面报错: ${receipt.message}"))
                }
                else -> {
                    onResult(ExecutionResult(command.cmdId, ExecutionResult.Code.UNKNOWN, 
                        "无明确回执: ${receipt.message}"))
                }
            }
        }
    }

    override fun cancel(cmdId: String) {
        // WebView 无法精确取消单个任务，依赖页面刷新
        webView?.stopLoading()
    }
}
