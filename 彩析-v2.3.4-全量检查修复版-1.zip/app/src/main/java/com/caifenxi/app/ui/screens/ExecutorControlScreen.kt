package com.caifenxi.app.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.viewmodel.compose.viewModel
import com.caifenxi.app.domain.execution.ExecutorManager
import com.caifenxi.app.ui.ExecutorViewModel
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.theme.CaiTokens

@Composable
fun ExecutorControlScreen(executorViewModel: ExecutorViewModel = viewModel()) {
    val logs by executorViewModel.executorLogs.collectAsState()
    val status by executorViewModel.executorStatus.collectAsState()
    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = CaiTokens.ScreenHPadding, vertical = CaiTokens.S16)
    ) {
        Text("执行器控制", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(CaiTokens.S16))
        GlobalCard {
            Text("状态: ${status.name}", fontWeight = FontWeight.Bold)
            Text("模式: ${ExecutorManager.getMode()}")
            Text("可用: ${ExecutorManager.availableExecutorIds().joinToString().ifBlank { "无" }}")
            Spacer(Modifier.height(CaiTokens.S8))
            PrimaryButton(
                text = "测试任务",
                onClick = { executorViewModel.startTask(executorViewModel.generateTestTask()) }
            )
            Spacer(Modifier.height(CaiTokens.S8))
            PrimaryButton(
                text = "清空日志",
                onClick = { executorViewModel.clearLogs() }
            )
        }
        Spacer(Modifier.height(CaiTokens.S12))
        GlobalCard {
            Text("最近日志", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(CaiTokens.S8))
            if (logs.isEmpty()) {
                Text("暂无", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                logs.takeLast(12).forEach {
                    Text(it, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
