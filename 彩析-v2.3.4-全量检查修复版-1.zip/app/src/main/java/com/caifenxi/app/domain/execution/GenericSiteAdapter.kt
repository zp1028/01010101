package com.caifenxi.app.domain.execution

/**
 * 通用站点适配：不绑死具体域名，用 DOM 评分识别真正的大小单双下注按钮。
 * 过滤历史/说明里同名文字；供 WebView evaluateJavascript 注入。
 */
object GenericSiteAdapter : SiteAdapter {

    override val siteId: String = "generic"

    override val whitelistDomains: List<String> = emptyList()

    override fun getUrl(lotteryKey: String): String = "about:blank"

    override val issueSelector: String =
        "[class*='issue'],[class*='period'],[id*='issue'],[id*='period'],.qihao,.issue,.period"

    override val balanceSnapshotScript: String = """
        (function(){
          var t = document.body ? (document.body.innerText||'') : '';
          var m = t.match(/(余额|可用|金额)[^0-9]{0,6}([0-9]+(?:\.[0-9]+)?)/);
          return m ? m[2] : String((t.length||0));
        })()
    """.trimIndent()

    override fun buildInjectScript(command: BetCommand): String {
        val betsJson = command.bets.joinToString(",") { bet ->
            """{"cat":${jsonStr(bet.category)},"value":${jsonStr(bet.value)}}"""
        }
        val amount = command.amountText?.let { jsonStr(it) } ?: "null"
        val issue = jsonStr(command.issue)
        val dryRun = command.options["dryRun"] == "1" || command.options["dryRun"] == "true"
        return """
            (function(){
              var CMD = {
                cmdId: ${jsonStr(command.cmdId)},
                issue: $issue,
                amount: $amount,
                dryRun: ${if (dryRun) "true" else "false"},
                bets: [$betsJson]
              };
              $CORE_JS
              return JSON.stringify(window.__caiFenXiRunCommand(CMD));
            })()
        """.trimIndent()
    }

    override fun parseReceipt(rawJson: String): ExecutionReceipt {
        val raw = rawJson.trim().removeSurrounding("\"").replace("\\\"", "\"")
        if (raw.isBlank() || raw == "null") {
            return ExecutionReceipt(false, true, "空回执")
        }
        return try {
            val ok = raw.contains("\"ok\":true") || raw.contains("\"ok\": true")
            val err = raw.contains("\"ok\":false") || raw.contains("\"ok\": false")
            val msg = Regex("\"message\"\\s*:\\s*\"([^\"]*)\"").find(raw)?.groupValues?.getOrNull(1)
                ?: raw.take(120)
            ExecutionReceipt(isSuccess = ok, isError = err && !ok, message = msg)
        } catch (e: Exception) {
            ExecutionReceipt(false, true, "解析失败: ${e.message}")
        }
    }

    private fun jsonStr(s: String): String =
        "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n") + "\""

    /** 核心识别与点击逻辑（评分选真按钮） */
    private val CORE_JS: String = """
function __cfxNorm(s){ return (s||'').replace(/\s+/g,'').trim(); }
function __cfxVisible(el){
  if(!el||el.disabled) return false;
  var st=window.getComputedStyle(el);
  if(st.display==='none'||st.visibility==='hidden'||st.opacity==='0') return false;
  var r=el.getBoundingClientRect();
  return r.width>4&&r.height>4&&r.bottom>0&&r.top<innerHeight&&r.right>0&&r.left<innerWidth;
}
function __cfxBlob(el){
  var bits=[el.className&&String(el.className), el.id,
    el.getAttribute('data-type'), el.getAttribute('data-play'),
    el.getAttribute('aria-label'), el.name];
  return bits.filter(Boolean).join(' ').toLowerCase();
}
function __cfxPath(el){
  var s='', cur=el, d=0;
  while(cur&&d<8){ s+=' '+__cfxBlob(cur); cur=cur.parentElement; d++; }
  return s.toLowerCase();
}
var __CFX_BET_HINTS=['bet','play','wager','order','touzhu','xz','chip','game-bet','betting','handicap','盘口','投注','下注'];
var __CFX_NOISE=['history','record','trend','chart','help','rule','notice','news','draw','open','result','统计','历史','走势','说明','开奖','记录'];
function __cfxScore(el, label){
  if(!__cfxVisible(el)) return -1e9;
  var text=__cfxNorm(el.innerText||el.textContent||el.value||'');
  if(text!==label && !(text.length<=4 && text.indexOf(label)>=0)) return -1e9;
  if(text.length>6) return -1e9;
  var rect=el.getBoundingClientRect();
  var blob=__cfxPath(el);
  var score=0;
  var tag=(el.tagName||'').toLowerCase();
  if(tag==='button'||tag==='a') score+=40;
  if(el.getAttribute('role')==='button') score+=30;
  if(typeof el.onclick==='function'||el.hasAttribute('ng-click')||el.hasAttribute('@click')) score+=20;
  if(tag==='input'&&/button|submit/.test(el.type||'')) score+=35;
  if(tag==='div'||tag==='span'||tag==='li'||tag==='label') score+=8;
  for(var i=0;i<__CFX_BET_HINTS.length;i++){ if(blob.indexOf(__CFX_BET_HINTS[i])>=0) score+=25; }
  for(var j=0;j<__CFX_NOISE.length;j++){ if(blob.indexOf(__CFX_NOISE[j])>=0) score-=60; }
  var area=rect.width*rect.height;
  if(rect.width>=28&&rect.width<=240&&rect.height>=24&&rect.height<=100) score+=25;
  if(area<200||area>80000) score-=20;
  var cy=rect.top+rect.height/2;
  if(cy>innerHeight*0.2&&cy<innerHeight*0.95) score+=10;
  if(cy<innerHeight*0.12) score-=25;
  var parent=el.parentElement;
  if(parent){
    var sib=__cfxNorm(parent.innerText||'');
    if((label==='大'||label==='小')&&sib.indexOf('大')>=0&&sib.indexOf('小')>=0) score+=20;
    if((label==='单'||label==='双')&&sib.indexOf('单')>=0&&sib.indexOf('双')>=0) score+=20;
  }
  if(/active|selected|on|checked|current/.test(blob)) score+=5;
  return score;
}
function __cfxFindBest(label){
  var nodes=document.querySelectorAll('button,a,div,span,li,input,label');
  var best=null, bestScore=30;
  for(var i=0;i<nodes.length;i++){
    var sc=__cfxScore(nodes[i], label);
    if(sc>bestScore){ bestScore=sc; best=nodes[i]; }
  }
  return best?{el:best,score:bestScore}:null;
}
function __cfxHighlight(el, ok){
  if(!el) return;
  var prev=el.style.outline;
  el.style.outline=ok?'3px solid #00c853':'3px solid #ff1744';
  setTimeout(function(){ el.style.outline=prev; }, 1200);
}
function __cfxClick(el){
  el.scrollIntoView({block:'center',inline:'center'});
  var o={bubbles:true,cancelable:true,view:window};
  el.dispatchEvent(new MouseEvent('mouseover',o));
  el.dispatchEvent(new MouseEvent('mousedown',o));
  el.dispatchEvent(new MouseEvent('mouseup',o));
  el.dispatchEvent(new MouseEvent('click',o));
  if(typeof el.click==='function') el.click();
}
function __cfxFindConfirm(){
  var texts=['确认','立即下注','马上投注','提交','下注','确认投注','确定','立即投注'];
  var nodes=document.querySelectorAll('button,a,div,span,input');
  var best=null, bestScore=20;
  for(var i=0;i<nodes.length;i++){
    var el=nodes[i];
    if(!__cfxVisible(el)) continue;
    var text=__cfxNorm(el.innerText||el.value||'');
    var hit=false;
    for(var t=0;t<texts.length;t++){ if(text===texts[t]||text.indexOf(texts[t])>=0){ hit=true; break; } }
    if(!hit||text.length>12) continue;
    var sc=10, blob=__cfxPath(el);
    for(var h=0;h<__CFX_BET_HINTS.length;h++) if(blob.indexOf(__CFX_BET_HINTS[h])>=0) sc+=20;
    for(var n=0;n<__CFX_NOISE.length;n++) if(blob.indexOf(__CFX_NOISE[n])>=0) sc-=40;
    var r=el.getBoundingClientRect();
    if(r.width>60&&r.height>28) sc+=15;
    if(sc>bestScore){ bestScore=sc; best=el; }
  }
  return best;
}
function __cfxInputAmount(amount){
  if(!amount) return {ok:true,message:'无金额'};
  var inputs=document.querySelectorAll('input[type=text],input[type=number],input:not([type])');
  var target=null;
  for(var i=0;i<inputs.length;i++){
    var el=inputs[i];
    if(!__cfxVisible(el)) continue;
    var blob=__cfxPath(el)+' '+(el.placeholder||'');
    if(/金额|额度|amount|money|bet|投注|下注/.test(blob) || true){
      if(!target) target=el;
      if(/金额|额度|amount|money|bet|投注|下注/.test(blob)){ target=el; break; }
    }
  }
  if(!target){
    // 尝试点整额筹码
    var chip=__cfxFindBest(String(amount));
    if(chip){ __cfxHighlight(chip.el,true); __cfxClick(chip.el); return {ok:true,message:'点筹码'+amount}; }
    return {ok:false,message:'未找到金额框'};
  }
  target.focus();
  target.value=String(amount);
  target.dispatchEvent(new Event('input',{bubbles:true}));
  target.dispatchEvent(new Event('change',{bubbles:true}));
  return {ok:true,message:'已填金额'+amount};
}
window.__caiFenXiRunCommand=function(CMD){
  var steps=[];
  try{
    if(!CMD||!CMD.bets||!CMD.bets.length){
      return {ok:false,message:'指令无注项',steps:steps};
    }
    for(var i=0;i<CMD.bets.length;i++){
      var bet=CMD.bets[i];
      var label=bet.value;
      if(!label) continue;
      var hit=__cfxFindBest(label);
      if(!hit){
        steps.push({step:label,ok:false,detail:'未找到可靠按钮'});
        return {ok:false,message:'未找到真正的【'+label+'】下注钮',steps:steps};
      }
      __cfxHighlight(hit.el,true);
      if(!CMD.dryRun) __cfxClick(hit.el);
      steps.push({step:label,ok:true,score:hit.score});
    }
    var amt=__cfxInputAmount(CMD.amount);
    steps.push({step:'amount',ok:!!amt.ok,detail:amt.message});
    if(!amt.ok) return {ok:false,message:amt.message,steps:steps};
    var conf=__cfxFindConfirm();
    if(conf){
      __cfxHighlight(conf,true);
      if(!CMD.dryRun) __cfxClick(conf);
      steps.push({step:'confirm',ok:true});
    }else{
      steps.push({step:'confirm',ok:false,detail:'未找到确认钮'});
    }
    return {
      ok:true,
      message:(CMD.dryRun?'[dryRun]':'')+'已处理 '+CMD.bets.map(function(b){return b.value;}).join('/'),
      steps:steps
    };
  }catch(e){
    return {ok:false,message:String(e&&e.message||e),steps:steps};
  }
};
""".trimIndent()
}
