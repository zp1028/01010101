package com.caifenxi.app.domain.execution

import com.caifenxi.app.service.WebViewBetExecutor
import com.caifenxi.app.util.RuntimeLog
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * V2.0 生产级下注调度器
 *
 * 职责：
 * 1. 接收 CREATED 状态的 ExecutionTask
 * 2. 按优先级和彩种隔离调度执行
 * 3. 管理执行器生命周期（WebView / Accessibility）
 * 4. 超时控制、失败重试（仅明确 FAILED 才重试，UNKNOWN 不重试）
 */
class BetScheduler(
    private val repository: ExecutionRepository,
    private val webViewExecutor: WebViewBetExecutor,
    private val accessibilityExecutor: Executor? = null,
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
) {
    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning

    /** 调度队列：按彩种隔离，避免交叉干扰 */
    private val queues = mutableMapOf<String, ArrayDeque<ExecutionTask>>()
    private val activeJobs = mutableMapOf<String, Job>()

    /** 注入 WebView 实例（由 UI 层提供） */
    fun attachWebView(webView: android.webkit.WebView) {
        webViewExecutor.attachWebView(webView)
    }

    /** 派发任务 */
    fun dispatch(task: ExecutionTask) {
        val key = task.lotteryKey
        queues.getOrPut(key) { ArrayDeque() }.addLast(task)
        RuntimeLog.info("Scheduler", "派发任务 cmdId=${task.cmdId} $key/${task.issue} 队列长度=${queues[key]?.size}")
        triggerNext(key)
    }

    /** 启动调度 */
    fun start() {
        _isRunning.value = true
        RuntimeLog.info("Scheduler", "调度器启动")
    }

    /** 停止调度（不清除队列，暂停执行） */
    fun stop() {
        _isRunning.value = false
        activeJobs.values.forEach { it.cancel() }
        RuntimeLog.info("Scheduler", "调度器停止")
    }

    private fun triggerNext(lotteryKey: String) {
        if (!_isRunning.value) return
        if (activeJobs[lotteryKey]?.isActive == true) return

        val queue = queues[lotteryKey] ?: return
        val task = queue.removeFirstOrNull() ?: return

        activeJobs[lotteryKey] = scope.launch {
            executeTask(task)
            // 执行完成后触发下一个
            triggerNext(lotteryKey)
        }
    }

    private suspend fun executeTask(task: ExecutionTask) {
        val cmd = task.command ?: return
        RuntimeLog.info("Scheduler", "开始执行 cmdId=${cmd.cmdId} ${cmd.lotteryKey}/${cmd.issue}")

        // 1. 检查过期
        if (System.currentTimeMillis() > cmd.expireAt) {
            repository.expire(cmd.cmdId)
            RuntimeLog.warn("Scheduler", "任务过期 cmdId=${cmd.cmdId}")
            return
        }

        // 2. 检查彩种阻塞
        if (repository.isLotteryBlocked(cmd.lotteryKey) && task.state == ExecutionTask.State.CREATED) {
            RuntimeLog.warn("Scheduler", "彩种阻塞，任务挂起 cmdId=${cmd.cmdId}")
            // 重新放回队列头部
            queues.getOrPut(cmd.lotteryKey) { ArrayDeque() }.addFirst(task)
            delay(5000)
            return
        }

        // 3. 选择执行器（优先 WebView）
        val executor = if (webViewExecutor.isAvailable) webViewExecutor else accessibilityExecutor
        if (executor == null) {
            val result = ExecutionResult(
                cmdId = cmd.cmdId,
                code = ExecutionResult.ResultCode.FAILED,
                message = "无可用执行器"
            )
            repository.complete(cmd.cmdId, result)
            return
        }

        // 4. 状态流转：CREATED → LOCKED
        if (!repository.transition(cmd.cmdId, ExecutionTask.State.CREATED, ExecutionTask.State.LOCKED)) {
            RuntimeLog.warn("Scheduler", "状态流转失败 cmdId=${cmd.cmdId}")
            return
        }

        // 5. 执行（带 8 秒超时）
        val result = try {
            withTimeout(8000) {
                suspendCancellableCoroutine<ExecutionResult> { continuation ->
                    val success = executor.execute(cmd) { res ->
                        continuation.resume(res) {}
                    }
                    if (!success) {
                        continuation.resume(
                            ExecutionResult(cmdId = cmd.cmdId, code = ExecutionResult.ResultCode.FAILED, message = "执行器拒绝"),
                            {}
                        )
                    }
                }
            }
        } catch (e: TimeoutCancellationException) {
            ExecutionResult(cmdId = cmd.cmdId, code = ExecutionResult.ResultCode.UNKNOWN, message = "执行超时(8s)")
        } catch (e: Exception) {
            ExecutionResult(cmdId = cmd.cmdId, code = ExecutionResult.ResultCode.UNKNOWN, message = "异常: ${e.message}")
        }

        // 6. 完成处理
        repository.complete(cmd.cmdId, result)
        RuntimeLog.info("Scheduler", "执行完成 cmdId=${cmd.cmdId} result=${result.code.name}")

        // 7. V2.0：UNKNOWN 状态触发彩种阻塞，暂停后续执行
        if (result.code == ExecutionResult.ResultCode.UNKNOWN) {
            RuntimeLog.error("Scheduler", "【阻塞】${cmd.lotteryKey} 出现 UNKNOWN，暂停该彩种后续执行，等待人工确认")
            // 不清除队列，但阻塞触发后 triggerNext 会检查 isLotteryBlocked
        }

        // 8. V2.0：明确 FAILED 才自动重试（生成新 cmdId，避免混淆）
        if (result.code == ExecutionResult.ResultCode.FAILED) {
            val retryCmd = cmd.copy(
                cmdId = BetCommand.generateCmdId(cmd.lotteryKey, cmd.issue),
                expireAt = System.currentTimeMillis() + 60_000
            )
            val retryTask = repository.create(retryCmd)
            // 延迟 3 秒后重试
            delay(3000)
            dispatch(retryTask)
            RuntimeLog.info("Scheduler", "自动重试原cmdId=${cmd.cmdId} 新cmdId=${retryCmd.cmdId}")
        }
    }

    /** 获取某彩种的待执行任务数 */
    fun getQueueSize(lotteryKey: String): Int = queues[lotteryKey]?.size ?: 0

    /** 清空某彩种队列（用户手动取消时） */
    fun clearQueue(lotteryKey: String) {
        queues[lotteryKey]?.clear()
        activeJobs[lotteryKey]?.cancel()
        RuntimeLog.info("Scheduler", "清空队列 $lotteryKey")
    }
}
