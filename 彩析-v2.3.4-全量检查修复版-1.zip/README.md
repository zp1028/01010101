# 彩析 CaiFenXi 2.3.4

工作台计划预测 + 挂机一期/二期/三期倍投 + 内置 WebView 执行台。

- `versionName` 2.3.4 / `versionCode` 34
- 最低 Android 7.0（API 24），compile/target SDK 35

> 预测与自动执行仅供统计、回测和研究，不构成投注建议。

## 用 Git 仓库构建 APK

### 1. 环境

- JDK 17
- Android SDK（platforms;android-35，build-tools 35.0.0）
- 本仓库已含 Gradle Wrapper 8.9

### 2. 克隆

```bash
git clone <你的仓库地址> CaiFenXi
cd CaiFenXi
```

### 3. 配置 SDK

```bash
cp local.properties.example local.properties
# 编辑 sdk.dir 为本机 Android SDK 路径
```

Android Studio：直接 Open 本目录，会自动生成 `local.properties`。

### 4. 本地出包

```bash
chmod +x ./gradlew
./gradlew assembleDebug
# 产物: app/build/outputs/apk/debug/app-debug.apk

./gradlew assembleRelease
# 产物: app/build/outputs/apk/release/app-release-unsigned.apk
```

或运行 `./build.sh`。

### 5. GitHub Actions 出包

1. 把本仓库推到 GitHub（源码在仓库根目录，不要只传 zip）
2. 打开 Actions → **Build APK** → Run workflow
3. 下载 Artifact `caifenxi-debug-apk`

正式签名包用 **Build Release APK**，需在仓库 Secrets 配置：

- `ANDROID_KEYSTORE_B64`
- `ANDROID_KEYSTORE_PASS`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASS`

打 tag 也会触发正式包：`git tag v2.3.4 && git push origin v2.3.4`

## 目录

```
app/                 Android 应用
gradle/wrapper/      Gradle 8.9 Wrapper
.github/workflows/   CI 构建 APK
```

## 主要入口

- 工作台：计划与回测
- 挂机：选计划、一期/二期/三期、金额倍投、执行方式
- 网页：全屏 WebView 执行台与工单/余额校验
